// Ödenek Gönderme / Tenkis ana çerçevesi (ButceMuhasebe/OdenekGondermeTenkisFrame): "Belge Düzenleme" ve "Belge Arama"
// sekmeleri. Belge Arama sekmesi ilk açılışta yüklenir. Listeden bir belge açılınca (OgBelgeAc) Belge Düzenleme sekmesine
// geçilir ve belge oradaki formda okunur (eski çerçevedeki sekme geçişi).
$(function () {
    'use strict';

    var $kok = $('.og-cerceve');
    if (!$kok.length) return;

    function sekmeAc(ad) {
        $kok.find('.og-sekmeler a').each(function () {
            var secili = $(this).attr('data-sekme') === ad;
            $(this).attr('aria-selected', secili ? 'true' : 'false').parent().toggleClass('active', secili);
        });
        $kok.find('iframe.og-alt-cerceve').each(function () {
            var secili = $(this).attr('data-sekme') === ad;
            if (secili && !this.getAttribute('src') && this.getAttribute('data-src')) this.setAttribute('src', this.getAttribute('data-src'));
            $(this).prop('hidden', !secili);
        });
    }

    $kok.on('click', '.og-sekmeler a', function (e) {
        e.preventDefault();
        sekmeAc($(this).attr('data-sekme'));
    });

    // Liste sayfası (aynı kökten) çağırır.
    window.OgBelgeAc = function (yil, belgeNo) {
        sekmeAc('form');
        var form = document.getElementById('cerceveForm');
        var w = form && form.contentWindow;
        if (w && typeof w.OgBelgeYukle === 'function') w.OgBelgeYukle(yil, belgeNo);
    };
});
