// Ödenek Gönderme / Tenkis belge arama (ButceMuhasebe/OdenekGondermeTenkisSorgu; eski aynı adlı Ext.NET sayfası).
// Süzgeçlerle belgeler listelenir; seçili belgelerde durum işlemleri (muhasebata gönder, iptal, tahsis, icmal no ...),
// liste / belge / icmal çıktıları ve belge tarihçesi. Belge numarasına tıklanınca belge çerçevenin "Belge Düzenleme"
// sekmesinde açılır (window.parent.OgBelgeAc). Uçlar: /api/odenekgonderme/* (Muhasebe/OdenekGondermeUclari.cs).
$(function () {
    'use strict';

    var $kok = $('.og-liste');
    if (!$kok.length) return; // yetkisiz kullanıcıya yalnızca uyarı basılır

    var BT = parseInt($kok.attr('data-bt'), 10) || 0;
    var TALEP = $kok.attr('data-talep') || '';
    var UC = 'api/odenekgonderme/';
    var tutar2 = new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    var tanim = {};
    var sonKriter = null;   // son listelemenin kıstasları (yazdırma ve işlemler aynı yıl ile)

    function p(ek) { return $.extend({ bt: BT, talep: TALEP }, ek || {}); }
    function mesaj(metin, tur) { Sgb.bildirim(metin, tur); }
    function hataGoster(xhr) {
        if (xhr && xhr.status === 401) return;
        mesaj(xhr && xhr.status === 403 ? 'Bu işlem için yetkiniz yok.' : 'İşlem yapılamadı.', 'danger');
    }
    function para(v) { return v === null || v === undefined || v === '' ? '' : tutar2.format(Number(v) || 0); }
    function sayiMetin(s) { s = $.trim(s || ''); return s.indexOf(',') >= 0 ? s.replace(/\./g, '').replace(',', '.') : s; }

    // ---------------------------------------------------------------- açılır menüler (Bootstrap 3 görünümü, betiksiz)

    $kok.on('click', '.og-menu > .dropdown-toggle', function (e) {
        e.stopPropagation();
        var $g = $(this).parent();
        var acik = $g.hasClass('open');
        $kok.find('.og-menu.open').removeClass('open').children('.dropdown-toggle').attr('aria-expanded', 'false');
        if (!acik) $g.addClass('open').children('.dropdown-toggle').attr('aria-expanded', 'true');
    });
    $(document).on('click', function () { $kok.find('.og-menu.open').removeClass('open').children('.dropdown-toggle').attr('aria-expanded', 'false'); });
    $kok.on('click', '.dropdown-menu a', function (e) { e.preventDefault(); });

    // ---------------------------------------------------------------- onay sorusu

    var dlgSoru = document.getElementById('dlgSoru');
    var soruIsi = null;
    function sor(metin, evet, is) {
        $('#soruMetin').text(metin);
        $('#btnSoruEvet').text(evet || 'Evet');
        soruIsi = is;
        dlgSoru.showModal();
    }
    $('#btnSoruEvet').on('click', function () {
        dlgSoru.close();
        var is = soruIsi;
        soruIsi = null;
        if (is) is();
    });
    $('dialog').on('click', '[data-kapat]', function () { $(this).closest('dialog')[0].close(); });

    // ---------------------------------------------------------------- kıstaslar

    var muhBirim = Sgb.muhasebeBirim('#muhBirim', {
        kimlik: { muhasebe: 'txtMuhasebe', birim: 'txtBirim', kurumsal: 'txtKurumsal', ad: 'lblBirimAd' },
        yil: function () { return parseInt($('#ddlYil').val(), 10) || 0; }
    });

    // "13.01.31.00- Ad" -> "13.01.31.00"
    function kodAl(metin) {
        var s = $.trim(metin || '');
        var i = s.indexOf('-');
        return $.trim(i > 0 ? s.substring(0, i) : s);
    }
    function alanKod(alan) { return kodAl($('.kod-alan[data-alan="' + alan + '"] input').val()); }

    function kriter() {
        var d = muhBirim.deger();
        return p({
            yil: $('#ddlYil').val(), durum: $('#ddlDurum').val(),
            muhasebe: d.muhasebe || '', birim: d.birim,
            icmalNo: $.trim($('#txtIcmalNoK').val()), icmalTarihi: $('#txtIcmalTarihi').val(),
            belgeNo1: $.trim($('#txtBelgeNo1').val()), belgeNo2: $.trim($('#txtBelgeNo2').val()),
            belgeTarihi1: $('#txtBelgeTarihi1').val(), belgeTarihi2: $('#txtBelgeTarihi2').val(),
            durumTarihi1: $('#txtDurumTarihi1').val(), durumTarihi2: $('#txtDurumTarihi2').val(),
            kur: alanKod('kur'), fon: alanKod('fon'), fin: alanKod('fin'), eko: alanKod('eko'), peb: alanKod('peb'),
            islemYapan: $.trim($('#txtIslemYapan').val()), aciklama: $.trim($('#txtAciklamaK').val()),
            tutarbe: sayiMetin($('#txtTutarBE').val()), tutarke: sayiMetin($('#txtTutarKE').val()),
            surecno: $.trim($('#txtSurecNo').val()), dortDuzeyDegisim: $('#chkDortDuzey').prop('checked') ? 'true' : 'false'
        });
    }

    function yil() { return parseInt((sonKriter || {}).yil || $('#ddlYil').val(), 10) || 0; }

    // Kod ağaçları (Ödenek Durum sayfalarıyla aynı alanlar ve pencere).
    var dlgKod = document.getElementById('dlgKod');
    var agaclar = {};
    var aktifAlan = null;
    function agacAc($alan) {
        var y = parseInt($('#ddlYil').val(), 10) || 0;
        if (y <= 0) { mesaj('Yıl seçiniz.', 'warning'); return; }
        var tur = $alan.attr('data-tur');
        var ad = $alan.find('label').text();
        aktifAlan = $alan;
        $('#dlgKodBaslik').text(ad + ' Seçimi');
        $('#agacKutu > ul').prop('hidden', true);
        var a = agaclar[tur];
        dlgKod.showModal();
        if (!a) {
            a = agaclar[tur] = { $ul: $('<ul></ul>').attr('aria-label', ad + ' ağacı').appendTo('#agacKutu'), yil: y };
            a.agac = Sgb.agac(a.$ul[0], {
                yukle: function (ust) {
                    return Sgb.al(UC + 'kodlar', p({ yil: a.yil, tur: tur, ust: ust ? ust.kod : '' })).then(function (v) {
                        if (v.hata) { mesaj(v.hata, 'danger'); return []; }
                        return v.dugumler;
                    });
                },
                secilince: function (d) {
                    dlgKod.close();
                    if (aktifAlan) aktifAlan.find('input').val(d.ad).trigger('change');
                },
                seciliMi: function (d) { return !!aktifAlan && kodAl(aktifAlan.find('input').val()) === d.kod; },
                ilkAcik: true,
                bosMetin: 'Kod bulunamadı.',
                hata: hataGoster
            });
        } else {
            a.$ul.prop('hidden', false);
            if (a.yil !== y) { a.yil = y; a.agac.yenile(); }
        }
    }
    $('.kod-alan .kod-sec').on('click', function () { agacAc($(this).closest('.kod-alan')); });
    $('.kod-alan .kod-temizle').on('click', function () { $(this).closest('.kod-alan').find('input').val('').trigger('focus'); });
    $('.kod-alan input').on('keydown', function (e) {
        if (e.key === 'ArrowDown' && e.altKey) { e.preventDefault(); agacAc($(this).closest('.kod-alan')); }
    });

    $('#btnKriterTemizle').on('click', function () {
        $('#frmKriter').find('input[type="text"], input[type="date"]').val('');
        $('#chkDortDuzey').prop('checked', false);
        muhBirim.ata({});
        if (tanim.varsayilanDurum) $('#ddlDurum').val(String(tanim.varsayilanDurum));
    });

    // ---------------------------------------------------------------- liste

    function belgeAc(d) {
        if (window.parent && window.parent !== window && typeof window.parent.OgBelgeAc === 'function') {
            window.parent.OgBelgeAc(yil(), d.belgeNo);
            return;
        }
        window.open('OdenekGondermeTenkisMPExt?' + $.param({ belgetur: BT, talep: TALEP, yil: yil(), belgeNo: d.belgeNo }), '_blank');
    }

    function bagHucre(is) {
        return function (x) {
            if (!x.data) return x.value;
            return $('<a href="#"></a>').text(x.value || '').on('click', function (e) { e.preventDefault(); e.stopPropagation(); is(x.data); })[0];
        };
    }

    var grid = Sgb.grid('#grdListe', {
        columnDefs: [
            { field: 'belgeNo', headerName: 'Belge No', width: 130, cellRenderer: bagHucre(belgeAc) },
            { field: 'belgeTarih', headerName: 'Belge Tarihi', width: 110, valueFormatter: function (x) { return Sgb.tarih(x.value); } },
            { field: 'muhasebe', headerName: 'Muhasebe', width: 220, tooltipField: 'muhasebe' },
            { field: 'birim', headerName: 'Birim', width: 220, tooltipField: 'birim' },
            { field: 'tutar', headerName: 'Tutar', width: 140, type: 'rightAligned', valueFormatter: function (x) { return para(x.value); } },
            { field: 'icmalNo', headerName: 'İcmal No', width: 90, type: 'rightAligned' },
            { field: 'icmalTarih', headerName: 'İcmal Tarihi', width: 110, valueFormatter: function (x) { return Sgb.tarih(x.value); } },
            { field: 'muhasebatNo', headerName: 'Muhasebat No', width: 110, hide: true },
            { field: 'muhasebatTarih', headerName: 'Muhasebat Tarihi', width: 120, hide: true, valueFormatter: function (x) { return Sgb.tarih(x.value); } },
            { field: 'durum', headerName: 'Durum', width: 200, cellRenderer: bagHucre(tarihceAc), tooltipValueGetter: function () { return 'Belge tarihçesi'; } },
            { field: 'islemTarih', headerName: 'Durum Tarihi', width: 110, hide: true, valueFormatter: function (x) { return Sgb.tarih(x.value); } },
            { field: 'islemKisi', headerName: 'İşlemi Yapan', width: 120, hide: true }
        ],
        rowSelection: { mode: 'multiRow', checkboxes: true, headerCheckbox: true, enableClickSelection: false },
        getRowId: function (x) { return x.data.belgeNo; },
        pagination: true,
        paginationPageSize: 50,
        paginationPageSizeSelector: [20, 50, 100, 200],
        overlayNoRowsTemplate: '<span>Kıstasları seçip Listele\'ye basınız.</span>',
        onRowClicked: function (e) { if (e.data) ayrintiGoster(e.data); }
    });

    function ozetYaz() {
        var adet = 0, toplam = 0;
        grid.forEachNode(function (n) { adet++; toplam += Number(n.data.tutar) || 0; });
        $('#lblListeOzet').text(adet ? adet + ' belge, toplam ' + tutar2.format(toplam) : '');
    }

    function listele(sessiz) {
        var k = kriter();
        if (!(parseInt(k.yil, 10) > 0) || !(parseInt(k.durum, 10) > 0)) { mesaj('Sorgulama için yıl alanını boş bırakamazsınız.', 'warning'); return; }
        var $d = $('#btnListele').prop('disabled', true);
        grid.deselectAll();
        $('#pnlAyrinti').prop('hidden', true);
        grid.setGridOption('loading', true);
        Sgb.al(UC + 'liste', k)
            .done(function (v) {
                if (v.hata) { mesaj(v.hata, 'danger'); grid.setGridOption('rowData', []); ozetYaz(); return; }
                sonKriter = k;
                grid.setGridOption('overlayNoRowsTemplate', '<span>Verilen kriterlere uygun kayıt bulunamadı.</span>');
                grid.setGridOption('rowData', v.satirlar || []);
                ozetYaz();
                if (!sessiz && !(v.satirlar || []).length) mesaj('Verilen kriterlere uygun kayıt bulunamadı.', 'info');
            })
            .fail(hataGoster)
            .always(function () { $d.prop('disabled', false); grid.setGridOption('loading', false); });
    }

    $('#frmKriter').on('submit', function (e) { e.preventDefault(); listele(false); });

    // ---------------------------------------------------------------- satır ayrıntısı (eski satır açıcı)

    var ayrintiGrid = Sgb.grid('#grdAyrinti', {
        columnDefs: [
            { field: 'tertip', headerName: 'Tertip', width: 320 },
            { field: 'tutar', headerName: 'Tutar', width: 150, type: 'rightAligned', valueFormatter: function (x) { return para(x.value); } }
        ],
        overlayNoRowsTemplate: '<span>Tertip yok.</span>'
    });

    function ayrintiGoster(d) {
        $('#pnlAyrinti').prop('hidden', false);
        $('#lblAyrintiBelge').text(d.belgeNo);
        $('#lblAyrintiAciklama').text(d.aciklama || '');
        $('#lblAyrintiIptal').text(d.iptalNeden || '');
        ayrintiGrid.setGridOption('rowData', []);
        ayrintiGrid.setGridOption('loading', true);
        Sgb.al(UC + 'liste/detay', p({ yil: yil(), belgeNo: d.belgeNo }))
            .done(function (v) {
                if (v.hata) { mesaj(v.hata, 'danger'); return; }
                ayrintiGrid.setGridOption('rowData', v.satirlar || []);
            })
            .fail(hataGoster)
            .always(function () { ayrintiGrid.setGridOption('loading', false); });
    }

    // ---------------------------------------------------------------- tarihçe (eski BelgeTarihce.aspx)

    var dlgTarihce = document.getElementById('dlgTarihce');
    var tarihceGrid = null;
    function tarihceAc(d) {
        if (!tarihceGrid) {
            tarihceGrid = Sgb.grid('#grdTarihce', {
                columnDefs: [
                    { field: 'sira', headerName: 'Sıra', width: 70, type: 'rightAligned' },
                    { field: 'islemTarih', headerName: 'İşlem Tarih', width: 170 },
                    { field: 'islem', headerName: 'İşlem', width: 220, tooltipField: 'islem' },
                    { field: 'islemYapan', headerName: 'İşlemi Yapan', width: 130 },
                    { field: 'islemYapanAd', headerName: 'İşlem Yapan Ad', width: 180 }
                ],
                overlayNoRowsTemplate: '<span>Tarihçe kaydı yok.</span>'
            });
        }
        $('#lblTarihceBelge').text('');
        tarihceGrid.setGridOption('rowData', []);
        dlgTarihce.showModal();
        tarihceGrid.setGridOption('loading', true);
        Sgb.al(UC + 'tarihce', p({ yil: yil(), belgeNo: d.belgeNo }))
            .done(function (v) {
                if (v.hata) { mesaj(v.hata, 'danger'); return; }
                $('#lblTarihceBelge').text(v.belge || '');
                tarihceGrid.setGridOption('rowData', v.satirlar || []);
            })
            .fail(hataGoster)
            .always(function () { tarihceGrid.setGridOption('loading', false); });
    }

    // ---------------------------------------------------------------- yazdırma

    $('.liste-yazdir').on('click', function () {
        var k = kriter();
        if (!(parseInt(k.yil, 10) > 0) || !(parseInt(k.durum, 10) > 0)) { mesaj('Sorgulama için yıl alanını boş bırakamazsınız.', 'warning'); return; }
        Sgb.indir(UC + 'liste/yazdir', $.extend(k, { tur: $(this).attr('data-tur') }));
    });

    function seciliBelgeler() { return $.map(grid.getSelectedRows(), function (r) { return r.belgeNo; }); }

    $('#mnBelgeYazdir').on('click', function () {
        var b = seciliBelgeler();
        if (!b.length) { mesaj('Listeden herhangi bir belge seçilmediği için işlem yapılamadı.', 'info'); return; }
        Sgb.indir(UC + 'belgeler-yazdir', p({ yil: yil(), belgeler: b.join(';') }));
    });

    $('#mnIcmalYazdir').on('click', function () {
        var no = $.trim($('#txtIcmalNo').val());
        if (!(parseInt(no, 10) > 0)) { mesaj('Yazdırılacak İcmal numarası belirtilmemiş.', 'warning'); return; }
        Sgb.indir(UC + 'icmal-yazdir', p({ yil: yil(), icmalNo: no }));
    });

    $('#mnIcmalEvrak').on('click', function () {
        sor('İcmal için evrak oluşturulacak. Onaylıyor musunuz?', 'Evrak Oluştur', function () {
            Sgb.gonder(UC + 'icmal-evrak', { belgeTur: BT, talep: TALEP, yil: yil(), icmalNo: $.trim($('#txtIcmalNo').val()) })
                .done(function (v) { mesaj(v.basarili ? v.bilgi : v.hata, v.basarili ? 'success' : 'warning'); })
                .fail(hataGoster);
        });
    });

    // ---------------------------------------------------------------- durum işlemleri (eski BelgeDurumDegisikligi)

    function durumGonder(islem, ek) {
        var b = seciliBelgeler();
        if (!b.length) { mesaj('Listeden herhangi bir belge seçilmediği için işlem yapılamadı.', 'info'); return; }
        Sgb.gonder(UC + 'durum', $.extend({ belgeTur: BT, talep: TALEP, yil: yil(), islem: islem, belgeler: b }, ek || {}))
            .done(function (v) {
                if (!v.basarili) { mesaj(v.hata || 'İşlem yapılamadı.', 'danger'); return; }
                if (v.icmalNo) $('#txtIcmalNo').val(v.icmalNo);
                mesaj(v.bilgi || 'İşlem tamamlandı.', 'success');
                if (islem !== 'ebutce') listele(true);
            })
            .fail(hataGoster);
    }

    $('.durum-islem').on('click', function () {
        var islem = $(this).attr('data-islem');
        if (!seciliBelgeler().length) { mesaj('Listeden herhangi bir belge seçilmediği için işlem yapılamadı.', 'info'); return; }
        sor('İşlem yapılacak. Onaylıyor musunuz?', 'Evet', function () {
            durumGonder(islem, islem === 'icmalno' ? { icmalNo: $.trim($('#txtIcmalNo').val()) } : null);
        });
    });

    var dlgIptal = document.getElementById('dlgIptal');
    $('#mnIptal').on('click', function () {
        if (!seciliBelgeler().length) { mesaj('Listeden herhangi bir belge seçilmediği için işlem yapılamadı.', 'info'); return; }
        $('#txtIptalGerekce').val('');
        dlgIptal.showModal();
    });
    $('#frmIptal').on('submit', function (e) {
        e.preventDefault();
        var gerekce = $.trim($('#txtIptalGerekce').val());
        dlgIptal.close();
        sor('İşlem yapılacak. Onaylıyor musunuz?', 'İptal Et', function () { durumGonder('iptal', { gerekce: gerekce }); });
    });

    // Birimlere Aç / Kapa (eski btnIslemAcKapa_Click; belge seçimi gerekmez).
    $('.ac-kapa').on('click', function () {
        var islem = $(this).attr('data-islem');
        sor(islem === 'kapa' ? 'Belge girişi birimlere kapatılacak. Onaylıyor musunuz?' : 'Belge girişi birimlere açılacak. Onaylıyor musunuz?', 'Evet', function () {
            Sgb.gonder(UC + 'durum', { belgeTur: BT, talep: TALEP, yil: parseInt($('#ddlYil').val(), 10) || 0, islem: islem })
                .done(function (v) { mesaj(v.basarili ? v.bilgi : v.hata, v.basarili ? 'success' : 'danger'); })
                .fail(hataGoster);
        });
    });

    // ---------------------------------------------------------------- açılış (eski Page_Load)

    Sgb.al(UC + 'tanim', p())
        .done(function (t) {
            if (t.hata) { mesaj(t.hata, 'danger'); return; }
            tanim = t;
            var $y = $('#ddlYil').empty();
            $.each(t.yillar || [], function (i, y) { $('<option></option>').val(y).text(y).appendTo($y); });
            $y.val(String(t.yil));
            var $d = $('#ddlDurum').empty();
            $.each(t.durumlar || [], function (i, d) { $('<option></option>').val(d.kod).text(d.ad).appendTo($d); });
            $d.val(String(t.varsayilanDurum));
            $('.kod-alan[data-alan="kur"] input').val(t.kurum || '');

            // Düğme görünürlükleri (eski Page_Load).
            var talep = !!TALEP;
            $('#mnYeniYap').prop('hidden', !t.yonetici);
            $('#grpDiger').prop('hidden', !t.yonetici);
            $('#mnTahsis, #mnMuhasebat').prop('hidden', talep);
            $('#grpIcmal').prop('hidden', talep);
            $('#mnSgb').prop('hidden', !t.sgbGoster);
            if (t.muhasebatYok) {
                $('#mnSgb, #mnMuhasebat, #mnEbutce, #mnDegisim, #mnMuhAldi').prop('hidden', true);
                $('#mnOnayla').prop('hidden', false);
            }
        })
        .fail(hataGoster);
});
