﻿<%@ Page Language="C#" CodeBehind="KadroKontenjanSorgu.aspx.cs" Inherits="InsanKaynaklari.KadroKontenjanSorgu" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript" src="../Personel/ModulScripts/Ortak.js?mc=03022015"></script>
    <script type="text/javascript" language="javascript">
        var islemTurRenderer = function (value) {
            var r = storeIslemTur.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.IslemAd;
        };

        var unvanRenderer = function (value) {
            var r = storeUnvan.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.UnvanAd;
        };

        var kadroDereceRenderer = function (value) {
            var r = storeKadroDerece.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.DereceAd;
        };

        var OrgBirimDoldur = function (node) {
            var orgBirim = { harcamaMi: 1, yetkiliOlduguMuhasebeBirim: hdnYetkiliBirim.value };
            nodeLoadOrgBirimParam(node, orgBirim);
        };
        var birimRenderer = function (value) {
            if (hdnBirimKod.value == value)
                return hdnBirimAd.value;
            else
                return "";
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnBirimKod" runat="server" />
    <ext:Hidden ID="hdnBirimAd" runat="server" />
    <ext:Hidden ID="hdnYetkiliBirim" runat="server" />
    <ext:Store runat="server" ID="storeIslemTur">
        <Reader>
            <ext:JsonReader IDProperty="IslemKod">
                <Fields>
                    <ext:RecordField Name="IslemKod">
                    </ext:RecordField>
                    <ext:RecordField Name="IslemAd">
                    </ext:RecordField>
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeUnvan">
        <Reader>
            <ext:JsonReader IDProperty="UnvanKod">
                <Fields>
                    <ext:RecordField Name="UnvanKod" />
                    <ext:RecordField Name="UnvanAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeKadroDerece">
        <Reader>
            <ext:JsonReader IDProperty="DereceKod">
                <Fields>
                    <ext:RecordField Name="DereceKod" />
                    <ext:RecordField Name="DereceAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <West Split="true" UseSplitTips="true" MarginsSummary="5">
                    <ext:Panel ID="pnlAna" runat="server" Collapsible="true" Width="250" AutoScroll="true">
                        <Items>
                            <ext:FitLayout ID="FitLayout" runat="server">
                                <Items>
                                    <ext:PropertyGrid ID="pgFiltre" runat="server" Border="false">
                                        <Source>
                                            <ext:PropertyGridParameter Name="birim" DisplayName="<%$ Resources:InsanKaynaklari,FRMPRM026%>">
                                                <Renderer Fn="birimRenderer" />
                                                <Editor>
                                                    <ext:DropDownField ID="ddlBirim" runat="server" Editable="false" TriggerIcon="Ellipsis"
                                                        Mode="ValueText">
                                                        <Component>
                                                            <ext:Panel ID="Panel5" runat="server" Width="400">
                                                                <Items>
                                                                    <ext:TreePanel ID="trpBirim" runat="server" Height="250" AutoWidth="true" AutoScroll="true"
                                                                        Border="false" RootVisible="false">
                                                                        <Root>
                                                                            <ext:AsyncTreeNode NodeID="0" Expanded="true" Icon="Note" />
                                                                        </Root>
                                                                        <Loader>
                                                                            <ext:PageTreeLoader OnNodeLoad="NodeLoad" />
                                                                        </Loader>
                                                                        <Listeners>
                                                                            <Click Handler="#{ddlBirim}.setValue(node.id, node.text, false);#{hdnBirimKod}.setValue(node.id);#{hdnBirimAd}.setValue(node.text); #{ddlBirim}.collapse();" />
                                                                        </Listeners>
                                                                    </ext:TreePanel>
                                                                </Items>
                                                            </ext:Panel>
                                                        </Component>
                                                    </ext:DropDownField>
                                                </Editor>
                                            </ext:PropertyGridParameter>
                                            <ext:PropertyGridParameter Name="islemTur" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD011 %>">
                                                <Renderer Fn="islemTurRenderer" />
                                                <Editor>
                                                    <ext:ComboBox ID="cmbIslemTur" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                        ForceSelection="true" StoreID="storeIslemTur" DisplayField="IslemAd" ValueField="IslemKod" />
                                                </Editor>
                                            </ext:PropertyGridParameter>
                                            <ext:PropertyGridParameter Name="islemTarih" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD012 %>">
                                                <Editor>
                                                    <ext:DateField ID="txtIslemTarih" runat="server" />
                                                </Editor>
                                            </ext:PropertyGridParameter>
                                            <ext:PropertyGridParameter Name="dayanakTarih" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD017 %>">
                                                <Editor>
                                                    <ext:DateField ID="txtDayanakTarih" runat="server" />
                                                </Editor>
                                            </ext:PropertyGridParameter>
                                            <ext:PropertyGridParameter Name="dayanakNo" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD018 %>">
                                                <Editor>
                                                    <ext:TextField ID="txtDayanakNo" runat="server" />
                                                </Editor>
                                            </ext:PropertyGridParameter>
                                            <ext:PropertyGridParameter Name="unvan" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD019 %>">
                                                <Renderer Fn="unvanRenderer" />
                                                <Editor>
                                                    <ext:ComboBox ID="cmbUnvan" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                        ForceSelection="true" StoreID="storeUnvan" DisplayField="UnvanAd" ValueField="UnvanKod"
                                                        ListWidth="250" />
                                                </Editor>
                                            </ext:PropertyGridParameter>
                                            <ext:PropertyGridParameter Name="kadroDerece" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD020 %>">
                                                <Renderer Fn="kadroDereceRenderer" />
                                                <Editor>
                                                    <ext:ComboBox ID="cmbKadroDerece" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                        ForceSelection="true" StoreID="storeKadroDerece" DisplayField="DereceAd" ValueField="DereceKod" />
                                                </Editor>
                                            </ext:PropertyGridParameter>
                                            <ext:PropertyGridParameter Name="aciklama" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD013 %>">
                                                <Editor>
                                                    <ext:TextField ID="txtAciklama" runat="server" />
                                                </Editor>
                                            </ext:PropertyGridParameter>
                                        </Source>
                                        <Listeners>
                                            <Render Handler="function() { this.getStore().sortInfo = undefined; this.getColumnModel().config[0].sortable = false;this.getColumnModel().config[1].sortable = false;}" />
                                            <SortChange Handler="this.getStore().sortInfo = undefined;" />
                                        </Listeners>
                                        <View>
                                            <ext:GridView ID="GridView1" ForceFit="true" runat="server" />
                                        </View>
                                    </ext:PropertyGrid>
                                </Items>
                            </ext:FitLayout>
                        </Items>
                    </ext:Panel>
                </West>
                <Center MarginsSummary="5">
                    <ext:GridPanel ID="grdListe" runat="server" ForceFit="true" StartCollapsed="false">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server">
                                <Items>
                                    <ext:Button ID="btnListe" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMKAD007 %>"
                                        Icon="TableGo">
                                        <DirectEvents>
                                            <Click OnEvent="btnListe_Click" Timeout="120000">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, FRMKAD002 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <View>
                            <ext:GroupingView ID="GroupingView1" HideGroupedColumn="true" runat="server" ForceFit="true"
                                StartCollapsed="false" EnableRowBody="true">
                            </ext:GroupingView>
                        </View>
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:ImageCommandColumn Width="20">
                                    <Commands>
                                        <ext:ImageCommand Icon="TableEdit" CommandName="giris">
                                        </ext:ImageCommand>
                                    </Commands>
                                </ext:ImageCommandColumn>
                                <ext:Column DataIndex="kod" Hidden="true" Header="Kod">
                                </ext:Column>
                                <ext:Column DataIndex="birimKod" Hidden="true" Header="Birim Kod">
                                </ext:Column>
                                <ext:Column DataIndex="birim" Header="<%$ Resources:InsanKaynaklari, FRMKAD008 %>">
                                </ext:Column>
                                <ext:Column DataIndex="siraNo" Header="<%$ Resources:InsanKaynaklari, FRMKAD009 %>">
                                </ext:Column>
                                <ext:Column DataIndex="islemTur" Header="<%$ Resources:InsanKaynaklari, FRMKAD011 %>">
                                </ext:Column>
                                <ext:Column DataIndex="islemTarih" Header="<%$ Resources:InsanKaynaklari, FRMKAD012 %>">
                                </ext:Column>
                                <ext:Column DataIndex="dayanakTarih" Header="<%$ Resources:InsanKaynaklari, FRMKAD017 %>">
                                </ext:Column>
                                <ext:Column DataIndex="dayanakNo" Header="<%$ Resources:InsanKaynaklari, FRMKAD018 %>">
                                </ext:Column>
                                <ext:Column DataIndex="aciklama" Header="<%$ Resources:InsanKaynaklari, FRMKAD013 %>">
                                </ext:Column>
                            </Columns>
                        </ColumnModel>
                        <Listeners>
                            <Command Handler="window.parent.GirisAc(record.data.kod);" />
                        </Listeners>
                        <Store>
                            <ext:Store ID="storeListe" runat="server">
                                <Reader>
                                    <ext:JsonReader>
                                        <Fields>
                                            <ext:RecordField Name="kod">
                                            </ext:RecordField>
                                            <ext:RecordField Name="birimKod">
                                            </ext:RecordField>
                                            <ext:RecordField Name="birim">
                                            </ext:RecordField>
                                            <ext:RecordField Name="siraNo">
                                            </ext:RecordField>
                                            <ext:RecordField Name="islemTur">
                                            </ext:RecordField>
                                            <ext:RecordField Name="islemTarih">
                                            </ext:RecordField>
                                            <ext:RecordField Name="dayanakTarih">
                                            </ext:RecordField>
                                            <ext:RecordField Name="dayanakNo">
                                            </ext:RecordField>
                                            <ext:RecordField Name="aciklama">
                                            </ext:RecordField>
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="250" HideRefresh="true"
                                StoreID="storeListe">
                                <Items>
                                    <ext:Label ID="Label1" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMKAD021 %>" />
                                    <ext:ToolbarSpacer ID="ToolbarSpacer1" runat="server" Width="10" />
                                    <ext:ComboBox ID="cmbPageSize" runat="server" Width="60">
                                        <Items>
                                            <ext:ListItem Text="50" />
                                            <ext:ListItem Text="100" />
                                            <ext:ListItem Text="250" />
                                            <ext:ListItem Text="500" />
                                            <ext:ListItem Text="1000" />
                                        </Items>
                                        <SelectedItem Value="250" />
                                        <Listeners>
                                            <Select Handler="#{PagingToolbar1}.pageSize = parseInt(this.getValue()); #{PagingToolbar1}.doLoad();" />
                                        </Listeners>
                                    </ext:ComboBox>
                                </Items>
                            </ext:PagingToolbar>
                        </BottomBar>
                    </ext:GridPanel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
