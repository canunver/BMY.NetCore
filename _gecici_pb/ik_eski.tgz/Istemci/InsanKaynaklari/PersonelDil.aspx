﻿<%@ Page Language="C#" CodeBehind="PersonelDil.aspx.cs" Inherits="InsanKaynaklari.PersonelDil" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                function (btn) {
                    if (btn == "yes") {
                        Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                    }
                });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };
        function ZorunluAlanKontrol() {
            if (!FPanel1.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return FPanel1.isValid();
        }     
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden runat="server" ID="hdnPKod" />
    <ext:Hidden runat="server" ID="hdnKod" />
    <ext:Hidden runat="server" ID="hdnSil" />
    <ext:Store ID="StoreDil" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreDilBelgeTur" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="DILKOD" />
                    <ext:RecordField Name="DILAD" />
                    <ext:RecordField Name="PUAN" />
                    <ext:RecordField Name="TARIH" Type="Date" />
                    <ext:RecordField Name="DUZEY" />
                    <ext:RecordField Name="DONEMAY" />
                    <ext:RecordField Name="DONEMYIL" />
                    <ext:RecordField Name="BELGETUR" />
                    <ext:RecordField Name="BELGETURAD" />
                    <ext:RecordField Name="BELGETARIHI" Type="Date" />
                    <ext:RecordField Name="BELGENO" />
                    <ext:RecordField Name="BORDROYAESAS" />
                    <ext:RecordField Name="DILSEVIYESI" />
                    <ext:RecordField Name="KURUMFAYDALANIYOR" />
                </Fields>
            </ext:JsonReader>
        </Reader>
        <SortInfo Field="BELGETARIHI" Direction="DESC" />
    </ext:Store>
    <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click" ViewStateMode="Enabled" Before="return ZorunluAlanKontrol();">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="<%$Resources:InsanKaynaklari,FRMPKS075 %>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                Icon="Delete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnTemizle_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="Button1" Icon="Lightbulb" runat="server">
                                <Listeners>
                                    <MouseOver Handler="wndYardim.show();" />
                                    <MouseOut Handler="wndYardim.hide();" />
                                </Listeners>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="FPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        Region="Center">
                        <Items>
                            <ext:ComboBox runat="server" ID="ddlDil" FieldLabel="<%$Resources:InsanKaynaklari,FRMPDL001%>"
                                Mode="Local" TriggerAction="All" NoteAlign="Top" Width="260" StoreID="StoreDil"
                                DisplayField="AD" ValueField="KOD" Editable="false">
                            </ext:ComboBox>
                            <ext:CompositeField ID="cmpBelge" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPDL020%>">
                                <Items>
                                    <ext:ComboBox runat="server" ID="ddlBelgeTuru" Note="<%$Resources:InsanKaynaklari,FRMPDL006%>"
                                        NoteAlign="Top" Width="100" StoreID="StoreDilBelgeTur" DisplayField="AD" ValueField="KOD">
                                    </ext:ComboBox>
                                    <ext:TextField runat="server" ID="txtBelgeNo" Width="60" Note="<%$Resources:InsanKaynaklari,FRMPDL007%>"
                                        NoteAlign="Top">
                                    </ext:TextField>
                                    <ext:DateField runat="server" ID="txtBelgeTarihi" Note="<%$Resources:InsanKaynaklari,FRMPDL008%>"
                                        NoteAlign="Top" Width="90">
                                    </ext:DateField>
                                </Items>
                            </ext:CompositeField>
                            <ext:CompositeField ID="cmpDonem" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPDL009%>">
                                <Items>
                                    <ext:ComboBox runat="server" ID="ddlDonemAy" Note="<%$Resources:InsanKaynaklari,FRMPDL004%>"
                                        NoteAlign="Top" Width="100" Editable="true">
                                    </ext:ComboBox>
                                    <ext:ComboBox ID="ddlDonemYil" runat="server" Note="<%$ Resources:InsanKaynaklari, FRMPDL005%>"
                                        NoteAlign="Top" Width="60" Editable="true">
                                    </ext:ComboBox>
                                    <ext:DateField runat="server" ID="txtTarih" Note="<%$Resources:InsanKaynaklari,FRMPDL008%>"
                                        NoteAlign="Top" Width="90">
                                    </ext:DateField>
                                </Items>
                            </ext:CompositeField>
                            <ext:CompositeField ID="cmpDerece" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPDL010%>">
                                <Items>
                                    <ext:ComboBox runat="server" ID="ddlDuzey" Note="<%$Resources:InsanKaynaklari,FRMPDL002%>"
                                        NoteAlign="Top" Width="100" Editable="false">
                                        <Items>
                                            <ext:ListItem Text="" Value="0" />
                                            <ext:ListItem Text="<%$Resources:InsanKaynaklari,FRMPDLD000%>" Value="A+" />
                                            <ext:ListItem Text="<%$Resources:InsanKaynaklari,FRMPDLD001%>" Value="A" />
                                            <ext:ListItem Text="<%$Resources:InsanKaynaklari,FRMPDLD002%>" Value="B" />
                                            <ext:ListItem Text="<%$Resources:InsanKaynaklari,FRMPDLD003%>" Value="C" />
                                            <ext:ListItem Text="<%$Resources:InsanKaynaklari,FRMPDLD004%>" Value="D" />
                                        </Items>
                                    </ext:ComboBox>
                                    <ext:TextField runat="server" ID="txtPuan" Note="<%$Resources:InsanKaynaklari,FRMPDL003%>"
                                        NoteAlign="Top" Width="60">
                                    </ext:TextField>
                                </Items>
                            </ext:CompositeField>
                            <ext:ComboBox runat="server" ID="txtDilSeviyesi" FieldLabel="<%$Resources:InsanKaynaklari,FRMPDL030%>"
                                Width="160" Editable="true">
                                <Items>
                                    <ext:ListItem Text="" Value="" />
                                    <ext:ListItem Text="Alt" Value="Alt" />
                                    <ext:ListItem Text="Çok İyi" Value="Çok İyi" />
                                    <ext:ListItem Text="İyi" Value="İyi" />
                                    <ext:ListItem Text="Orta" Value="Orta" />
                                </Items>
                            </ext:ComboBox>
                            <%--           <ext:TextField runat="server" ID="txtDilSeviyesi" Width="160" FieldLabel="<%$Resources:InsanKaynaklari,FRMPDL030%>"
                                NoteAlign="Top">
                            </ext:TextField>--%>
                            <ext:Checkbox runat="server" ID="chkBordroyaEsas" BoxLabel="<%$Resources:InsanKaynaklari,FRMPDL021%>"
                                NoteAlign="Top" Width="285" />
                            <ext:Checkbox runat="server" ID="chkKurumFaydalaniyor1" BoxLabel="Kurum Faydalanıyor"
                                NoteAlign="Top" Width="285" />
                            <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                Frame="true" FieldLabel="<%$Resources:InsanKaynaklari,FRMPDL022 %>" TrackMouseOver="true"
                                StoreID="BelgeStore" HideHeaders="true" AutoHeight="true" Width="350">
                                <ColumnModel ID="ColumnModel2" runat="server">
                                    <Columns>
                                        <ext:RowNumbererColumn />
                                        <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Header="<%$Resources:InsanKaynaklari,FRMPDL022 %>"
                                            Width="250" />
                                        <ext:CommandColumn Width="30">
                                            <Commands>
                                                <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$Resources:InsanKaynaklari,FRMPDL024 %>" />
                                            </Commands>
                                        </ext:CommandColumn>
                                        <ext:CommandColumn Width="30">
                                            <Commands>
                                                <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$Resources:InsanKaynaklari,FRMPDL023 %>" />
                                            </Commands>
                                        </ext:CommandColumn>
                                    </Columns>
                                </ColumnModel>
                                <Listeners>
                                    <Command Fn="KomutCalistir" />
                                </Listeners>
                                <SelectionModel>
                                    <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                    </ext:RowSelectionModel>
                                </SelectionModel>
                                <TopBar>
                                    <ext:Toolbar ID="Toolbar2" runat="server">
                                        <Items>
                                            <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                ButtonText="Belge Ekle">
                                                <DirectEvents>
                                                    <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                </DirectEvents>
                                            </ext:FileUploadField>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                            </ext:GridPanel>
                        </Items>
                    </ext:FormPanel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" Width="420" AutoExpandColumn="DILAD"
                        Border="true" Region="East">
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column DataIndex="DILAD" Header="<%$Resources:InsanKaynaklari,FRMPDL011%>" />
                                <ext:Column DataIndex="BELGETURAD" Header="<%$Resources:InsanKaynaklari,FRMPDL029%>" Width="90"/>
                                <ext:Column DataIndex="PUAN" Header="<%$Resources:InsanKaynaklari,FRMPDL012%>" Align="Right" Width="50" />
                                <ext:DateColumn DataIndex="TARIH" Header="Tarih" Format="dd/m/Y" Width="80"/>
                                <ext:CheckColumn DataIndex="BORDROYAESAS" Header="Bord. Es." Width="70"/>
                                <ext:CheckColumn DataIndex="KURUMFAYDALANIYOR" Header="Kur. Fay." Width="70"/>
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                <DirectEvents>
                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                        <ExtraParams>
                                            <ext:Parameter Name="RowValue" Value="Ext1.encode(#{grdListe}.getRowsValues({selectedOnly:true}))"
                                                Mode="Raw" />
                                        </ExtraParams>
                                    </RowSelect>
                                </DirectEvents>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <ext:Window ID="wndYardim" runat="server" Hidden="true" Closable="false" Frame="true"
        Width="380" Height="140" X="220" Y="10">
        <Items>
            <ext:Label ID="Label1" runat="server" Icon="Lightbulb" Text="Sertifika ile aldığınız yabancı dil bilgilerinizi veya KPDS, ÜDS gibi sınav bilgilerinizi ilgili alanlara girerek kayıt ediniz, sertifikanız olmadan da bildiğiniz dil varsa girebilirsiniz, kayıt ettikleriniz sağdaki listede gözükecektir. Kaydedip bitirdiğiniz bilgilerden sonra yine bu formu kullanarak başka (birden fazla bildiğiniz diller için) dil bilgisi kayıtlarınızı yapabilirsiniz. Tarihi tam olarak bilmiyorsanız 01.01.YIL olarak giriş yapınız." />
        </Items>
    </ext:Window>
    </form>
</body>
</html>
