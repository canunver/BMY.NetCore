﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelMaasParam.aspx.cs"
    Inherits="InsanKaynaklari.PersonelMaasParam" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
</script>
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="rm1" runat="server" />
        <ext:Viewport ID="Viewport1" runat="server" Layout="RowLayout">
            <Items>
                <ext:Panel runat="server" Layout="ColumnLayout" RowHeight="1">
                    <Items>
                        <ext:Panel runat="server" ColumnWidth="0.4" Flex="1" Layout="RowLayout">
                            <Items>
                                <ext:FormPanel runat="server" Height="150" ID="frmSendika" Padding="5">
                                    <TopBar>
                                        <ext:Toolbar runat="server">
                                            <Items>
                                                <ext:Button ID="btnSendikaKaydet" runat="server" Text="Sendika Bilgisi Kaydet" Icon="Accept">
                                                    <DirectEvents>
                                                        <Click OnEvent="btnSendikaKaydet_Click">
                                                            <ExtraParams>
                                                                <ext:Parameter Name="satirlar" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdGelirler}.getRowsValues())">
                                                                </ext:Parameter>
                                                            </ExtraParams>
                                                        </Click>
                                                    </DirectEvents>
                                                </ext:Button>
                                            </Items>
                                        </ext:Toolbar>
                                    </TopBar>
                                    <Items>
                                        <ext:ComboBox runat="server" ID="cmbSendikalar" FieldLabel="Sendika" ValueField="kod" DisplayField="ad">
                                            <Store>
                                                <ext:Store runat="server" ID="stoSendikalar">
                                                    <Reader>
                                                        <ext:JsonReader>
                                                            <Fields>
                                                                <ext:RecordField Name="kod" Type="Int" />
                                                                <ext:RecordField Name="ad" Type="String" />
                                                            </Fields>
                                                        </ext:JsonReader>
                                                    </Reader>
                                                </ext:Store>
                                            </Store>
                                        </ext:ComboBox>
                                        <ext:TextField runat="server" ID="tfSenKesOran" FieldLabel="Kesinti Oranı" />
                                    </Items>
                                </ext:FormPanel>
                                <ext:GridPanel ID="grdGelirler" runat="server" Border="true" Title="Gelirler"
                                    Flex="1" LabelWidth="150" AutoExpandColumn="aciklama" ClicksToEdit="1" RowHeight="1">
                                    <TopBar>
                                        <ext:Toolbar runat="server">
                                            <Items>
                                                <ext:Button ID="btnKaydetGelirler" runat="server" Text="Değ. Değerleri Kaydet" Icon="Accept">
                                                    <DirectEvents>
                                                        <Click OnEvent="btnKaydetGelirler_Click">
                                                            <ExtraParams>
                                                                <ext:Parameter Name="satirlar" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdGelirler}.getRowsValues())">
                                                                </ext:Parameter>
                                                            </ExtraParams>
                                                        </Click>
                                                    </DirectEvents>
                                                </ext:Button>
                                            </Items>
                                        </ext:Toolbar>
                                    </TopBar>
                                    <Store>
                                        <ext:Store ID="stoGelirler" runat="server">
                                            <Reader>
                                                <ext:JsonReader>
                                                    <Fields>
                                                        <ext:RecordField Type="String" Name="degiskenAd">
                                                        </ext:RecordField>
                                                        <ext:RecordField Type="String" Name="aciklama">
                                                        </ext:RecordField>
                                                        <ext:RecordField Type="String" Name="degerGenel">
                                                        </ext:RecordField>
                                                    </Fields>
                                                </ext:JsonReader>
                                            </Reader>
                                        </ext:Store>
                                    </Store>
                                    <ColumnModel>
                                        <Columns>
                                            <ext:Column DataIndex="aciklama" ColumnID="aciklama" Header="Açıklama" />
                                            <ext:Column DataIndex="degerGenel" ColumnID="degerGenel" Header="Değer">
                                                <Editor>
                                                    <ext:TextField runat="server" SelectOnFocus="true">
                                                    </ext:TextField>
                                                </Editor>
                                            </ext:Column>
                                        </Columns>
                                    </ColumnModel>
                                </ext:GridPanel>
                            </Items>
                        </ext:Panel>
                        <ext:GridPanel ID="grdMatrahlar" runat="server" Border="true" ColumnWidth="0.6" Title="Matrahlar"
                            Flex="1" ClicksToEdit="1">
                            <TopBar>
                                <ext:Toolbar ID="Toolbar1" runat="server">
                                    <Items>
                                        <ext:Label runat="server" Text="Yıl: ">
                                        </ext:Label>
                                        <ext:SpinnerField runat="server" ID="txtYil">
                                        </ext:SpinnerField>
                                        <ext:Button ID="btnListele" runat="server" Text="Listele" Icon="Lightning">
                                            <DirectEvents>
                                                <Click OnEvent="btnListele_Click">
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:Button ID="btnSatirAc" runat="server" Text="Satır Ekle" Icon="Add">
                                            <Listeners>
                                                <Click Handler="grdMatrahlar.addRecord({surecNo:'000000000'});" />
                                            </Listeners>
                                        </ext:Button>
                                        <ext:Button ID="btnKaydetMatrah" runat="server" Text="Kaydet" Icon="Accept">
                                            <DirectEvents>
                                                <Click OnEvent="btnKaydetMatrah_Click">
                                                    <ExtraParams>
                                                        <ext:Parameter Name="satirlar" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdMatrahlar}.getRowsValues())">
                                                        </ext:Parameter>
                                                    </ExtraParams>
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:Button ID="btnYazdir" runat="server" Text="Bordro Yazdır" Icon="Printer">
                                            <DirectEvents>
                                                <Click OnEvent="btnYazdir_Click" IsUpload="true">
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                    </Items>
                                </ext:Toolbar>
                            </TopBar>
                            <Store>
                                <ext:Store runat="server" ID="stoMatrahlar">
                                    <Reader>
                                        <ext:JsonReader>
                                            <Fields>
                                                <ext:RecordField Name="surecNo" Type="String" />
                                                <ext:RecordField Name="matrahTurAd" Type="String" />
                                                <ext:RecordField Name="tarihDT" Type="Date" />
                                                <ext:RecordField Name="deger" Type="Float" />
                                            </Fields>
                                        </ext:JsonReader>
                                    </Reader>
                                </ext:Store>
                            </Store>
                            <ColumnModel>
                                <Columns>
                                    <ext:Column DataIndex="surecNo" ColumnID="surecNo" Header="Süreç No">
                                    </ext:Column>
                                    <ext:Column DataIndex="matrahTurAd" ColumnID="matrahTurAd" Header="Matrah Türü">
                                        <Editor>
                                            <ext:SelectBox runat="server" DisplayField="ad" ValueField="ad" Width="400">
                                                <Store>
                                                    <ext:Store runat="server" ID="stoMatrahTur">
                                                        <Reader>
                                                            <ext:JsonReader>
                                                                <Fields>
                                                                    <ext:RecordField Name="ad" Type="String" />
                                                                </Fields>
                                                            </ext:JsonReader>
                                                        </Reader>
                                                    </ext:Store>
                                                </Store>
                                            </ext:SelectBox>
                                        </Editor>
                                    </ext:Column>
                                    <ext:DateColumn DataIndex="tarihDT" ColumnID="tarihDT" Header="Tarih" Format="dd.MM.yyyy">
                                        <Editor>
                                            <ext:DateField runat="server">
                                            </ext:DateField>
                                        </Editor>
                                    </ext:DateColumn>
                                    <ext:NumberColumn DataIndex="deger" ColumnID="deger" Header="Değer" Format="0.000,00/i"
                                        Align="Right">
                                        <Editor>
                                            <ext:NumberField runat="server" SelectOnFocus="true">
                                            </ext:NumberField>
                                        </Editor>
                                    </ext:NumberColumn>
                                </Columns>
                            </ColumnModel>
                        </ext:GridPanel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
    </form>
</body>
</html>
