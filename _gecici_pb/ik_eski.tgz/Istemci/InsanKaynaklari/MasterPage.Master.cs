﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;
using System.Web.UI.WebControls;
using System.Web.Services;
using TNS.KYM;


namespace InsanKaynaklari
{
    public partial class MasterPage : System.Web.UI.MasterPage
    {
        TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int pkod = TNS.OrtakFonksiyonlar.ConvertToInt((Request.QueryString["pKod"] + "").Trim(), 0);

                Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
                TNS.ObjectArray dler = new ObjectArray();
                dler = servisIKY.PersonelListele(kul, new TNS.IKY.Personel { kod = pkod }, true, true);

                if (!dler.sonuc.islemSonuc)
                {
                    lblGenelBilgi.Text = dler.sonuc.hataStr;
                    return;
                }

                if (dler.objeler.Count > 0)
                {
                    TNS.IKY.Personel d = (TNS.IKY.Personel)dler.objeler[0];
                    imgPersonel.Src = d.resimYol;
                    lblGenelBilgi.Text = " Adı: " + d.adSoyad + "<br> Birim: " + d.kadro.birimAd + "<br> Statü: " + d.kadro.personelTipAd + "<br> Unvan: " + d.kadro.unvanAd;
                }
            }
        }
    }
}