﻿using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;
using TNS.KYM;
using Aspose.Words;
using System.Data;
using System.Collections.Generic;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Kişisel Sınıfı
    /// </summary>
    public partial class PersonelNufus : istemciUzayi.GenelSayfa
    {
    }
}