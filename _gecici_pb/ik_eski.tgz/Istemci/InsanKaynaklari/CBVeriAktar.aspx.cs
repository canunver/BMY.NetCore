﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS.IKY;
using OrtakClass;
using TNS;
using TNS.KYM;

namespace InsanKaynaklari
{
    public partial class CBVeriAktar : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI))
            {
                GenelIslemler.MesajKutusu("Hata", "Yetkiniz Yoktur.");
                return;
            }
                
            int tip   = OrtakFonksiyonlar.ConvertToInt((Request.QueryString["tip"] + "").Trim(),0);

            Sonuc sonuc = servisIKY.CBVerileriniAktar(kullanan, tip);

            if(sonuc.islemSonuc)
                GenelIslemler.MesajKutusu("Bilgi", sonuc.bilgiStr);
            else
                GenelIslemler.MesajKutusu("Hata", sonuc.hataStr + sonuc.bilgiStr); 
        }
    }
}