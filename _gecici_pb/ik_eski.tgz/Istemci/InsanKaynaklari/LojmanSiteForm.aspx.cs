﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;
using System.Xml;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class LojmanSiteForm : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.LojmanSite001;
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            if (!IsPostBack)
            {
                Listele();
                //Genel.SozlukDoldur(ddlYetkiTip, yetkiTipStore, OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.SITEYONETICITIPI, 0).ToString().PadLeft(2, '0'), false);
            }
        }

        protected void Listele()
        {
            ObjectArray oa = servis.LojmanSiteListele(kullanan, new LojmanSite());
            if (!oa.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, oa.sonuc.hataStr);
                return;
            }
            
            stoLojmanSiteListe.DataSource = oa.objeler;
            stoLojmanSiteListe.DataBind();
        }

        void Oku()
        {
            LojmanSite form = new LojmanSite();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
            ObjectVAN ov = servis.LojmanSiteOku(kullanan, form);
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                form = (LojmanSite)ov.o;
                txtKod.Text = form.kod.ToString();
                txtsiteAdi.Text = form.siteAdi;
                txtmahalle.Text = form.mahalle;
                txtcadde.Text = form.cadde;
                txtsokak.Text = form.sokak;
                txtsemt.Text = form.semt;
                txtilce.Text = form.ilce;
                txtil.Text = form.il;
                chkyakitKesilecek.Checked = (form.yakitKesilecek == 1);
                txtkesintiTipi.Text = form.kesintiTipi;
                txtkesintiCevreGideri.Text = form.kesintiCevreGideri.ToString();
                txtkesintiSuGideri.Text = form.kesintiSuGideri.ToString();
                txtkesintiDiger.Text = form.kesintiDiger.ToString();
                txtkesintiDigerAciklama.Text = form.kesintiDigerAciklama;
                txtkesintiOrtakGider.Text = form.kesintiOrtakGider.ToString();
            }
            else if (!ov.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite002);
        }

        void Kaydet(DirectEventArgs e)
        {
            LojmanSite form = new LojmanSite();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
            form.siteAdi = txtsiteAdi.Text;
            form.mahalle = txtmahalle.Text;
            form.cadde = txtcadde.Text;
            form.sokak = txtsokak.Text;
            form.semt = txtsemt.Text;
            form.ilce = txtilce.Text;
            form.il = txtil.Text;
            form.yakitKesilecek = chkyakitKesilecek.Checked ? 1 : 0;
            form.kesintiTipi = txtkesintiTipi.Text;
            form.kesintiCevreGideri = OrtakFonksiyonlar.ConvertToInt(txtkesintiCevreGideri.Text, 0);
            form.kesintiSuGideri = OrtakFonksiyonlar.ConvertToInt(txtkesintiSuGideri.Text, 0);
            form.kesintiDiger = OrtakFonksiyonlar.ConvertToInt(txtkesintiDiger.Text, 0);
            form.kesintiDigerAciklama = txtkesintiDigerAciklama.Text;
            form.kesintiOrtakGider = OrtakFonksiyonlar.ConvertToInt(txtkesintiOrtakGider.Text, 0);
            Sonuc sonuc = servis.LojmanSiteKaydet(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite003);
                Listele();
            }
        }

        /// <summary>
        /// Lojman Site kodu olarak verilen değeri, txtkod alanına atar ve okuma işlemini çağırır.
        /// </summary>
        /// <param name="kod">Personel tipi kodu </param>
        [DirectMethod]
        public void Goster(int kod)
        {
            txtKod.Text = kod.ToString();
            Oku();
            YetkiListesi();
        }

        public void YetkiListesi()
        {
            ObjectArray list = servis.SiteYetkilileriListele(kullanan, new IKYSiteYetki { yetkiliOlduguSiteKod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0) });
            yetkiListeStore.DataSource = list.objeler;
            yetkiListeStore.DataBind();
        }

        [DirectMethod]
        public void YetkiListele(int siteKod)
        {
            txtKod.Text = siteKod.ToString();
            YetkiListesi();
        }

        /// <summary>
        /// Listele tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnOku_Click(object sender, DirectEventArgs e)
        {
            Oku();
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        /// <summary>
        /// Yazdir tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
        }

        /// <summary>
        /// Yeni tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYeni_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        /// <summary>
        /// Sil tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtKod.Text))
            {
                GenelIslemler.BilgiYaz(this, "Silmek istediğiniz siteyi seçiniz.");
                return;
            }
            Sonuc sonuc = servis.LojmanSiteSil(kullanan, OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0));
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite042);
                Listele();
            }
        }

        protected void Temizle()
        {
            txtKod.Clear();
            txtcadde.Clear();
            txtil.Clear();
            txtilce.Clear();
            txtkesintiCevreGideri.Clear();
            txtkesintiDiger.Clear();
            txtkesintiDigerAciklama.Clear();
            txtkesintiOrtakGider.Clear();
            txtkesintiSuGideri.Clear();
            txtkesintiTipi.Clear();
            txtmahalle.Clear();
            txtsemt.Clear();
            txtsiteAdi.Clear();
            txtsokak.Clear();
            chkyakitKesilecek.Clear();
        }

        protected void btnYetkiKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            if (OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0) == 0)
                hata += "Site bilgisi olmadığından kayıt yapamazsınız.";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            string listeBilgileri = e.ExtraParams["YetkiListeBilgileri"];
            Newtonsoft.Json.Linq.JObject[] satirlar = (Newtonsoft.Json.Linq.JObject[])JSON.Deserialize(listeBilgileri, typeof(Newtonsoft.Json.Linq.JObject[]));

            //if (listeBilgileri.Trim().Length > 0)
            //{
            if (satirlar.Length > 0)
            {
                ObjectArray pler = new ObjectArray();

                //XmlNode xml = JSON.DeserializeXmlNode("{records:{record:" + listeBilgileri + "}}");
                //foreach (XmlNode row in xml.SelectNodes("records/record"))
                //{
                foreach (Newtonsoft.Json.Linq.JObject satir in satirlar)
                {
                    IKYSiteYetki y = new IKYSiteYetki();
                    y.kod = Genel.DegerAlInt(satir, "kod");
                    y.yetkiliOlduguSiteKod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
                    y.pkod = Genel.DegerAlInt(satir, "pkod");
                    y.aktif = Genel.DegerAlInt(satir, "aktif");
                    y.tip = Genel.DegerAlInt(satir, "tip");

                    if (y.kod > 0 || y.aktif == 1)
                        pler.objeler.Add(y);
                }
                Sonuc sonuc = new Sonuc();

                if (pler.ObjeSayisi > 0)
                    sonuc = servis.LojmanSiteYetkiKaydet(kullanan, (TNS.IKY.IKYSiteYetki[])pler.objeler.ToArray(typeof(TNS.IKY.IKYSiteYetki)));
                else
                    sonuc = new Sonuc(false, "Kayıt edilecek veri bulunamadı.", "");

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    YetkiListesi();
                    GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.FRMIZD016);
                }
            }
        }

        [DirectMethod]
        public void AktifPasifYap(int kod, int aktif)
        {
            string hata = "";
            if (kod == 0)
                hata = "Yetki seçiniz.<br>";
          
            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }
            Sonuc sonuc = servis.LojmanSiteYetkiAktifPasifYap(kullanan, new IKYSiteYetki { kod = kod, aktif = aktif });
            if (sonuc.islemSonuc)
            {
                YetkiListesi();
                string metin = "Pasif";
                if (aktif == 1)
                    metin = "Aktif";
                GenelIslemler.MesajKutusu(this, metin+ " yapma işlemi başarılı.");
            }
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }
    }
}
