﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="TabletPersonelDetay.aspx.cs"
    Inherits="InsanKaynaklari.TabletPersonelDetay" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="height: 100%;">
<head runat="server">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Personel Detay</title>
    <link href="../App_themes/BootStrap/css/bootstrap.css" rel="stylesheet" />
    <link href="../App_themes/BootStrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../App_themes/BootStrap/css/sidebar.css" rel="stylesheet">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="../App_themes/BootStrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../App_themes/BootStrap/js/bootstrap.js"></script>
    <style type="text/css">
        .inset
        {
            overflow: auto;
            height: 100%;
            margin-top: 5px;
        }
        .content-header
        {
            margin-left: -30px;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
        }
        .hucre
        {
            font-weight: bold;
            width: 225px;
        }
        .linkler
        {
            color: White;
        }
        .sidebar-nav li a
        {
            padding-left: 20px;
        }
               
        @media (max-width:767px)
        {
            .content-header
            {
                height: 70px;
            }
            .baslik
            {
                margin-left: 0;
            }
            .baslik2
            {
                margin-left: -30px;
            }
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function () {
            $("#menu-toggle").click(function (e) {
                e.preventDefault();
                if (screen.width < 768) {
                    $("#baslik").toggleClass("baslik baslik2");
                }
                $("#wrapper").toggleClass("active");
            });
        });
        function GoMail(adres) {
            window.location = "mailto:" + adres;
        }
        function LinkeBas(menuNo) {
            $("#personelMenu li").removeClass('active');
            $("#personelMenu li").eq(menuNo - 1).addClass('active');
        }
    </script>
</head>
<body style="background-color: #b8e2ff; height: 100%;">
    <form id="form1" runat="server">
    <asp:HiddenField runat="server" ID="hdnKod" />
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <nav id="spy">
                <ul class="sidebar-nav nav" id="personelMenu">
                    <li class="sidebar-brand"><a href="#"><span>MENÜ</span></a> </li>
                    <li><a class="linkler" href="TabletPersonelArama.aspx?sorgu=<%= Request.QueryString["sorgu"] %>&dondu=<%= Request.QueryString["dondu"] %>&aktiflik=<%= Request.QueryString["aktiflik"] %>&tipler=<%= Request.QueryString["tipler"] %>&resim=<%= Request.QueryString["resim"] %>">
                        Arama Sayfası</a></li>
                        <li><a class="linkler" href="PersonelAramaR.aspx">
                        Yeni Sayfa</a></li>
                  <%--  <li><a href="#" onclick="LinkeBas(3);" class="linkler">xx</a></li>--%>
                    <li>
                        <asp:LinkButton runat="server" ID="LinkButton2" OnClick="btnKisiselListele" OnClientClick="LinkeBas(3)"
                            CssClass="linkler">Personel Bilgisi</asp:LinkButton></li>
                    <li>
                        <asp:LinkButton runat="server" ID="LinkButton4" OnClick="NufusListele" OnClientClick="LinkeBas(4)"
                            CssClass="linkler">Nüfus Bilgisi</asp:LinkButton></li>
                    <li>
                        <asp:LinkButton runat="server" ID="LinkButton1" OnClick="IletisimListele" CssClass="linkler">İletişim/Adres Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="lnkAskerlik">
                        <asp:LinkButton runat="server" ID="LinkButton3" OnClick="AskerlikListele" CssClass="linkler">Askerlik Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li1">
                        <asp:LinkButton runat="server" ID="LinkButton5" OnClick="OgrenimListele" CssClass="linkler">Ögrenim Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li2">
                        <asp:LinkButton runat="server" ID="LinkButton6" OnClick="AileListele" CssClass="linkler">Aile Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li3">
                        <asp:LinkButton runat="server" ID="LinkButton7" OnClick="KursListele" CssClass="linkler">Kurs Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li4">
                        <asp:LinkButton runat="server" ID="LinkButton8" OnClick="DilListele" CssClass="linkler">Dil Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li5">
                        <asp:LinkButton runat="server" ID="LinkButton9" OnClick="HizmetListele" CssClass="linkler">Hizmet Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li6">
                        <asp:LinkButton runat="server" ID="lnkTakdir" OnClick="TakdirCezaListele" CssClass="linkler">Takdir Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li9">
                        <asp:LinkButton runat="server" ID="lnkCeza" OnClick="TakdirCezaListele" CssClass="linkler">Ceza Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li7">
                        <asp:LinkButton runat="server" ID="LinkButton11" OnClick="MemuriyetListele" CssClass="linkler">Memuriyet Bilgisi</asp:LinkButton></li>
                    <li runat="server" id="Li8">
                        <asp:LinkButton runat="server" ID="LinkButton12" OnClick="TümBilgileriListele" CssClass="linkler">Tüm Bilgiler</asp:LinkButton></li>
                </ul>
            </nav>
        </div>
        <%--  <div class="canvas" style="background-color: #b8e2ff">--%>
        <div id="page-content-wrapper" style="padding-top: 60px; padding-left: 0">
            <div id="baslik" class="content-header" style="background-color: Black;">
                <%--style="background-color: #F8F8F8;">--%>
                <div class="col-xs-2 col-sm-1 col-md-1">
                    <h1 id="home">
                        <a id="menu-toggle" href="#" class="glyphicon glyphicon-align-justify btn-menu toggle"
                            style="padding-top: 10px; color: White;"></a>
                    </h1>
                </div>
                <div class="col-xs-10 col-sm-11 col-md-11">
                    <img runat="server" id="img2" class="img-responsive col-xs-2 col-sm-1 col-md-1" style="padding: 15px 5px 5px 20px;
                        height: 64px; width: 48px;" />
                    <asp:Label class="col-xs-9 col-sm-10 col-md-10" runat="server" ID="lblAd" Style="color: White;"></asp:Label>
                </div>
            </div>
            <%--<div class="navbar navbar-inverse navbar-fixed-top">
                <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false"
                    data-target=".navmenu" data-canvas=".canvas">
                    <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar">
                    </span>
                </button>
            </div>--%>
            <div class="page-content inset" data-spy="scroll" data-target="#spy">
                <div class="row">
                    <div class="col-xs-18 col-sm-12 col-md-9">
                        <div class="tab-content">
                            <div id="ozluk" class="panel panel-primary tab-pane fade in active" runat="server">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Personel Bilgisi</b></h3>
                                </div>
                                <div class="panel-body" id="pnlozluk">
                                    <div class="row">
                                        <img runat="server" id="img1" class="img-responsive col-xs-3 col-sm-3 col-md-3" style="padding-bottom: 10px" />
                                        <asp:Label runat="server" ID="lblGenelBilgi" class="col-xs-9 col-sm-9 col-md-9"></asp:Label>
                                    </div>
                                    <table class="table table-condensed" id="tblOzluk">
                                        <tbody>
                                            <tr>
                                                <td class="hucre">
                                                    TC No
                                                </td>
                                                <td runat="server" id="ptc">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Unvanı
                                                </td>
                                                <td runat="server" id="punvan">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Kadro Tarihi
                                                </td>
                                                <td runat="server" id="pKadroTarihi">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Mail Adres
                                                </td>
                                                <td runat="server" id="pMail">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Birimi
                                                </td>
                                                <td runat="server" id="pBirim">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Cep Telefon
                                                </td>
                                                <td runat="server" id="pCep">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Harici Telefon
                                                </td>
                                                <td runat="server" id="pIsTel">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div id="nufus" class="panel panel-danger tab-pane fade  in active" runat="server">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Nüfus Bilgisi</b>
                                    </h3>
                                </div>
                                <div class="panel-body" id="Div2">
                                    <table class="table table-condensed" id="Table1">
                                        <tbody>
                                            <tr>
                                                <td class="hucre">
                                                    Cinsiyeti
                                                </td>
                                                <td runat="server" id="nCinsiyet" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Cüz Seri No
                                                </td>
                                                <td runat="server" id="nCSeriNo" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Baba Adı
                                                </td>
                                                <td runat="server" id="nBabaAd" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Ana Adı
                                                </td>
                                                <td runat="server" id="nAnaAd" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Doğum Yeri
                                                </td>
                                                <td runat="server" id="nDogumYeri" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Doğum Tarihi
                                                </td>
                                                <td runat="server" id="nDogumTarihi" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Medeni Hali
                                                </td>
                                                <td runat="server" id="nMedeniHal" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Dini
                                                </td>
                                                <td runat="server" id="nDin" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    İli
                                                </td>
                                                <td runat="server" id="nIl" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    İlçesi
                                                </td>
                                                <td runat="server" id="nIlce" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Mahalle/Köyü
                                                </td>
                                                <td runat="server" id="nMahalle" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Cilt No / Aile No
                                                </td>
                                                <td runat="server" id="nCilt" style="width: %100">
                                                </td>
                                            </tr>
                                            <%--<tr>
                                            <td class="hucre">
                                                Aile No
                                            </td>
                                            <td runat="server" id="nAileNo" style="width: %100">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="hucre">
                                                Birey No
                                            </td>
                                            <td runat="server" id="nBireyNo" style="width: %100">
                                            </td>
                                        </tr>--%>
                                            <tr>
                                                <td class="hucre">
                                                    Cüz. Ver. Yer.
                                                </td>
                                                <td runat="server" id="nCuzdanVerYer" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Cüz. Ver. Nedeni
                                                </td>
                                                <td runat="server" id="nCuzdanVerNeden" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Cüz. Ver. Tarihi
                                                </td>
                                                <td runat="server" id="nCuzdanVerTarih" style="width: %100">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Cüz. Kayıt No
                                                </td>
                                                <td runat="server" id="nKayitNo" style="width: %100">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div id="adres" class="panel panel-default tab-pane fade in active" runat="server">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>İletişim/Adres Bilgisi </b>
                                    </h3>
                                </div>
                                <div class="panel-body" id="pnlIletisim">
                                    <table class="table table-condensed" id="Table2">
                                        <tbody>
                                            <tr>
                                                <td class="hucre">
                                                    Adres
                                                </td>
                                                <td runat="server" id="iAdres">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    İş Tel
                                                </td>
                                                <td runat="server" id="iIsTel">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Cep Tel 1
                                                </td>
                                                <td runat="server" id="iCepTel">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    E-Posta
                                                </td>
                                                <td runat="server" id="iMail">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Cep Tel 2
                                                </td>
                                                <td runat="server" id="iCepTel2">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Fax
                                                </td>
                                                <td runat="server" id="iFax">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Lojman
                                                </td>
                                                <td runat="server" id="iLojman">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Görüntülü
                                                </td>
                                                <td runat="server" id="iGoruntulu">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Telsiz/Kademe
                                                </td>
                                                <td runat="server" id="iTelsiz">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div id="askerlik" class="panel panel-warning tab-pane fade in active" runat="server">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Askerlik Bilgisi</b>
                                    </h3>
                                </div>
                                <div class="panel-body" id="Div1">
                                    <table class="table table-condensed" id="Table3">
                                        <tbody>
                                            <tr>
                                                <td class="hucre">
                                                    Durumu
                                                </td>
                                                <td runat="server" id="aDurum">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Başlangıç Tarihi
                                                </td>
                                                <td runat="server" id="aBaslangic">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Bitiş Tairihi
                                                </td>
                                                <td runat="server" id="aBitis">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    İntikal Tarihi
                                                </td>
                                                <td runat="server" id="aIntikal">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Şubesi
                                                </td>
                                                <td runat="server" id="aSube">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Sınıfı
                                                </td>
                                                <td runat="server" id="aSinif">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Belge No
                                                </td>
                                                <td runat="server" id="aBelgeNo">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Belge Tarihi
                                                </td>
                                                <td runat="server" id="aBelgeTarihi">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Asteğmen Nasbı
                                                </td>
                                                <td runat="server" id="aNasp">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Sayılmayan Gün
                                                </td>
                                                <td runat="server" id="aSayilmayanGun">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Açıklama
                                                </td>
                                                <td runat="server" id="aAciklama">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div id="ogrenim" runat="server" class="panel-group">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Öğrenim Bilgisi</b>
                                    </h3>
                                </div>
                                <asp:Literal runat="server" ID="pnlOgrenim"></asp:Literal>
                            </div>
                            <div class="panel-group" id="aile" runat="server">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Aile Bilgisi</b>
                                    </h3>
                                </div>
                                <asp:Literal runat="server" ID="pnlAile"></asp:Literal>
                            </div>
                            <div id="kurs" runat="server" class="panel-group">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Kurs Bilgisi</b>
                                    </h3>
                                </div>
                                <asp:Literal ID="pnlKurs" runat="server"></asp:Literal>
                            </div>
                            <div id="dil" runat="server" class="panel-group">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Dil Bilgisi</b>
                                    </h3>
                                </div>
                                <asp:Literal ID="pnlDil" runat="server"></asp:Literal>
                            </div>
                            <div id="hizmet" runat="server" class="panel-group">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Hizmet Bilgisi</b>
                                    </h3>
                                </div>
                                <asp:Literal ID="pnlHizmet" runat="server"></asp:Literal>
                            </div>
                            <div id="takdir" runat="server" class="panel-group">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Takdir Bilgisi</b>
                                    </h3>
                                </div>
                                <asp:Literal ID="pnlTakdir" runat="server"></asp:Literal>
                            </div>
                            <div id="ceza" runat="server" class="panel-group">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Ceza Bilgisi</b>
                                    </h3>
                                </div>
                                <asp:Literal ID="pnlCeza" runat="server"></asp:Literal>
                            </div>
                            <div id="memuriyet" class="panel panel-primary tab-pane fade  in active" runat="server">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <b>Memuriyet Bilgisi</b>
                                    </h3>
                                </div>
                                <div class="panel-body" id="Div11">
                                    <table class="table table-condensed" id="Table10">
                                        <tbody>
                                            <tr>
                                                <td class="hucre">
                                                    TC No
                                                </td>
                                                <td runat="server" id="mTC">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Sicili
                                                </td>
                                                <td runat="server" id="mSicil">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    İlk İşe Başladığı Tarih
                                                </td>
                                                <td runat="server" id="mIlkT">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Kuruma Başlama Tarihi
                                                </td>
                                                <td runat="server" id="mKurumT">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Kadro Başlama Tarihi
                                                </td>
                                                <td runat="server" id="mKadroT">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Memuriyet Toplamı
                                                </td>
                                                <td runat="server" id="mMemuriyetSure">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Kadro Derecesi
                                                </td>
                                                <td runat="server" id="mKadroDerece">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    EkGostergesi
                                                </td>
                                                <td runat="server" id="mEkGosterge">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Kazanılmış Derece/Kademe
                                                </td>
                                                <td runat="server" id="mKHA">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Emekli Derece/Kademe
                                                </td>
                                                <td runat="server" id="mEKEA">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="hucre">
                                                    Geldiği Kurum
                                                </td>
                                                <td runat="server" id="mGeldigiKurum">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
</body>
</html>
