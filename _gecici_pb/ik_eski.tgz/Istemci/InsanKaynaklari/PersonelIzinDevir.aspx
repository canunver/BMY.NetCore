﻿<%@ Page Language="C#" CodeBehind="PersonelIzinDevir.aspx.cs" Inherits="InsanKaynaklari.PersonelIzinDevir" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="InsanKaynaklari" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript" src="../Personel/ModulScripts/Ortak.js?mc=03022015"></script>
    <script type="text/javascript" language="javascript">
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnBirimKod" runat="server" />
    <ext:Hidden ID="hdnYil" runat="server" />
    <ext:Hidden ID="Hidden1" runat="server" />
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;"
        Layout="BorderLayout">
        <Items>
            <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px"
                Region="Center" Margins="104 20 10 20" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click">
                                        <ExtraParams>
                                            <ext:Parameter Name="ListeBilgileri" Value="Ext1.util.JSON.encode(#{grdListe}.getRowsValues({dirtyRowsOnly: true}))"
                                                Mode="Raw" />
                                            <ext:Parameter Name="yil" Mode="Raw" Value="ctlIzinDonem.yil" />
                                        </ExtraParams>
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnListele" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMIZD002%>"
                                Icon="ApplicationGo">
                                <DirectEvents>
                                    <Click OnEvent="btnListele_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                        <ExtraParams>
                                            <ext:Parameter Name="yil" Mode="Raw" Value="ctlIzinDonem.yil" />
                                        </ExtraParams>
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnAktar" runat="server" Text="Devreden İzinleri Aktar" Icon="ApplicationGo">
                                <DirectEvents>
                                    <Click OnEvent="btnAktar_Click">
                                        <EventMask ShowMask="true" Msg="Bir önceki yıldan devreden günler aktarılıyor." />
                                        <ExtraParams>
                                            <ext:Parameter Name="yil" Mode="Raw" Value="ctlIzinDonem.yil" />
                                        </ExtraParams>
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="FormPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        AutoHeight="true" Region="North">
                        <Items>
                            <ext:ExtIzinDonem runat="server" ID="ctlIzinDonem" YilMin="1980" Width="140" FieldLabel="Yıl">
                            </ext:ExtIzinDonem>
                            <ext:ExtOrgSecim runat="server" ID="ddlBirim" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>"
                                AnchorHorizontal="97%" MaxWidth="400" />
                            <ext:ExtCokluSecim runat="server" ID="ctlPersonelTip" FieldLabel="Personel Tipi"
                                AnchorHorizontal="97%" MaxWidth="400" />
                            <ext:TextField ID="txtGenelSorgu" runat="server" FieldLabel="Arama" AnchorHorizontal="97%"
                                MaxWidth="400" />
                        </Items>
                    </ext:FormPanel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                        Border="true" ClicksToEdit="1" Width="400"
                        Region="Center">
                        <Store>
                            <ext:Store ID="ListeStore" runat="server">
                                <Reader>
                                    <ext:JsonReader>
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="personelKod" Type="Int" />
                                            <ext:RecordField Name="yil" Type="Int" />
                                            <ext:RecordField Name="yilAd" Type="String" />
                                            <ext:RecordField Name="sicilNo" Type="string" />
                                            <ext:RecordField Name="tcKimlikNo" Type="string" />
                                            <ext:RecordField Name="adSoyad" Type="string" />
                                            <ext:RecordField Name="devreden" Type="Int" />
                                            <ext:RecordField Name="yilici" Type="Int"/>
                                            <ext:RecordField Name="kullanilan" Type="Int"/>
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:RowNumbererColumn Width="40" Header="Sıra" />
                                <ext:Column DataIndex="sicilNo" Header="Sicil"
                                    Width="100" />
                                <ext:Column DataIndex="adSoyad" Header="<%$ Resources:InsanKaynaklari, FRMIZD007%>"
                                    Width="200" />
                                <ext:Column DataIndex="yilAd" Header="Yıl"
                                    Width="110" />
                                <ext:Column DataIndex="devreden" Header="<%$ Resources:InsanKaynaklari, FRMIZD008%>"
                                    Width="100" Align="Right">
                                    <Editor>
                                        <ext:NumberField runat="server" AllowBlank="true" AllowNegative="false" AllowDecimals="false"
                                            SelectOnFocus="true" />
                                    </Editor>
                                </ext:Column>
                                <ext:Column DataIndex="yilici" Header="<%$ Resources:InsanKaynaklari, FRMIZD009%>"
                                    Width="100" Align="Right">
                                    <Editor>
                                        <ext:NumberField runat="server" AllowBlank="true" AllowNegative="false" AllowDecimals="false"
                                            SelectOnFocus="true" />
                                    </Editor>
                                </ext:Column>
                                <ext:Column DataIndex="kullanilan" Header="Kullanılan"
                                    Width="100" Align="Right">
                                </ext:Column>
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true" />
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="1000" HideRefresh="true" />
                        </BottomBar>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
