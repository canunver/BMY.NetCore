﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelBilgisi.aspx.cs"
    Inherits="InsanKaynaklari.PersonelBilgisi" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_themes/Theme1/Theme1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form id="form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Panel ID="Panel1" runat="server" Border="false">
        <Items>
            <ext:RowLayout ID="RowLayout1" runat="server">
                <Rows>
                    <ext:LayoutRow RowHeight="0.20">
                        <ext:Panel ID="Panel2" runat="server" Height="70" MinHeight="70" MaxHeight="70">
                            <Items>
                                <ext:ColumnLayout ID="ColumnLayout1" runat="server">
                                    <Columns>
                                        <ext:LayoutColumn>
                                            <ext:Panel ID="pnlUstResim" runat="server" Border="false" Padding="5">
                                                <Items>
                                                    <ext:Image ID="imgPersonelResim" runat="server" Width="48" Height="59" ImageUrl="../app_themes/images/bos.jpg" />
                                                </Items>
                                            </ext:Panel>
                                        </ext:LayoutColumn>
                                        <ext:LayoutColumn ColumnWidth="1">
                                            <ext:Panel ID="pnlUstBilgi" runat="server" Border="false" Padding="5">
                                            </ext:Panel>
                                        </ext:LayoutColumn>
                                    </Columns>
                                </ext:ColumnLayout>
                            </Items>
                        </ext:Panel>
                    </ext:LayoutRow>
                </Rows>
            </ext:RowLayout>
        </Items>
    </ext:Panel>
    </form>
</body>
</html>
