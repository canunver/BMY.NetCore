﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;
using TNS.KYM;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Bilgi Sınıfı
    /// </summary>
    public partial class PersonelBilgi : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public string personelTCKimlikNo = "";

        public string TemizleIkon { get { return ResourceManager1.GetIconUrl(Icon.PageWhite); } }

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["menuYok"] + "" != "")
                    tabPanelAna.Margins = "0 0 0 0";

                //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
                SayfaUstAltBolumYaz(this);
                this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

                hdnIlk.Text = "0";
                if (personelTCKimlikNo == "")
                    personelTCKimlikNo = Request.QueryString["i"] + "";

                ddlBirim.KullanicininBirimleri = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");

                Genel.UnvanDoldur(servisIKY, this, storeUnvan);
                Genel.PersonelTipGrupDoldur(ddlPersonelTipGrup, stoPersonelTipGrup);
                ctlPersonelTip.ListeDoldur(Genel.PersonelTurDondur(TipGruplariBul()));

                string yetkiliBirimKopruKod = kullanan.yetkiTipiDegerleri["KopruKod", 0];
                if (!string.IsNullOrWhiteSpace(yetkiliBirimKopruKod))
                {
                    string birimKod = yetkiliBirimKopruKod.Substring(yetkiliBirimKopruKod.Length - 3, 3);
                    TNS.ORG.OrganizasyonBirim birim = TNS.ORG.Arac.OrgBirimBul(birimKod);
                    if (birim != null)
                        ddlBirim.SetValue(birim.kod.ToString(), birim.adi);
                }
            }
        }

        [DirectMethod]
        public void PersonelTipleriYenile()
        {
            ddlPersonelTipGrup_Changed(null, null);
        }

        protected void ddlPersonelTipGrup_Changed(object sender, DirectEventArgs e)
        {
            ctlPersonelTip.ListeDoldur(Genel.PersonelTurDondur(TipGruplariBul()));
        }

        private string[] TipGruplariBul()
        {
            string[] tipGruplar = new string[ddlPersonelTipGrup.SelectedItems.Count];
            for (int i = 0; i < ddlPersonelTipGrup.SelectedItems.Count; i++)
            {
                tipGruplar[i] = ddlPersonelTipGrup.SelectedItems[i].Text;
            }
            return tipGruplar;
        }

        protected void ListeStore_ReadData(object sender, StoreRefreshDataEventArgs e)
        {
            if (hdnIlk.Text == "0")
            {
                e.Total = 0;
                //ListeStore.Buffered = true;
                //ListeStore.PageSize = 200;
            }
            else
            {
                e.Total = PersonelListele(e.Start, e.Limit);
                //if (e.Total < e.Limit) e.Total = e.Limit;
                //if (e.Total > e.Limit)
                //{
                //    ListeStore.Buffered = true;
                //}
                //else
                //{
                //    ListeStore.Buffered = false;
                //}
            }
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected int PersonelListele(int basla, int sayfa)
        {
            int kayitSay = 0;
            try
            {
                TNS.IKY.Personel p = new TNS.IKY.Personel();
                p.kadro.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value.ToString(), 0);
                p.kadro.unvan = OrtakFonksiyonlar.ConvertToInt(cmbUnvan.Value, 0);
                p.kadro.vekilUnvanKod = OrtakFonksiyonlar.ConvertToInt(cmbUnvan.Value, 0);
                p.genelSorgu = txtGenelSorgu.Text;

                string personelTurler = ctlPersonelTip.Value.ToString();
                if (string.IsNullOrWhiteSpace(personelTurler))
                    p.tipGruplar = TipGruplariBul();
                else
                    p.personelTipleri = ctlPersonelTip.UnderlyingValue;

                //p.personelTip = OrtakFonksiyonlar.ConvertToInt(ddlPersonelTip.SelectedItem.Value, 0);
                p.aktifDurum = OrtakFonksiyonlar.ConvertToInt(rgAktiflik.CheckedItems[0].InputValue, 1);
                p.kayitBasla = basla;
                p.kayitToplam = sayfa;
                p.tarihce = false;


                p.listeSiralama = (ENUMPersonelSira)OrtakFonksiyonlar.ConvertToInt(cmbSiralama.SelectedItem.Value, 1);
                ObjectArray liste = servisIKY.PersonelListele(kullanan, p, false, true);
                grdListe.ColumnModel.SetHidden(0, !rgResimVar.Checked);
                if (!liste.sonuc.islemSonuc)
                    throw new Exception(liste.sonuc.hataStr);
                else
                    kayitSay = liste.sonuc.kayitSay;
                ListeStore.DataSource = liste.objeler;
                ListeStore.DataBind();
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
            }
            return kayitSay;
        }

        /// <summary>
        /// Rows the select.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.DirectEventArgs"/> instance containing the event data.</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["KOD"], 0);
            EkranHazirla(kod);
        }

        /// <summary>
        /// Yeni kayıt yapılmak istendiğinde ekranı boşaltma işlemini yapar
        /// </summary>
        [DirectMethod(Namespace = "PersonelX")]
        public void YeniKayitHazirla()
        {
            pnlUst.Title = "Personel Bilgi";
            imgPersonelResim.ImageUrl = "../App_themes/images/bos.jpg";

            lblTipUnvan.Text = "";
            lblKadroYeri.Text = "";
            lblIletisim.Text = "";

            lblKurumaBasTar.Text = "";
            lblGorevYeri.Text = "";
            lblVekilUnv.Text = "";

            lblKadroDerece.Text = "";
            lblKazanilmisD.Text = "";
            lblEmekliD.Text = "";

            TabPersonelBilgi.Items.Clear();
            TabPanelleriOlustur(new TNS.IKY.Personel());
        }

        /// <summary>
        /// Yeni kayıt yapıldıktan sonra bütün tabları göstermek için
        /// </summary>
        /// <param name="tcKimlikNo">The tc kimlik no.</param>
        [DirectMethod(Namespace = "PersonelX")]
        public void KayittanSonraGoster(int kod)
        {
            EkranHazirla(kod);
        }

        void EkranHazirla(int kod)
        {
            if (kod > 0)
            {
                TNS.IKY.Personel p = new TNS.IKY.Personel();
                p.kod = kod;
                ObjectArray liste = servisIKY.PersonelListele(kullanan, p, false, true);
                if (liste.sonuc.islemSonuc && liste.objeler.Count == 1)
                {
                    p = (TNS.IKY.Personel)liste[0];
                    TabPersonelBilgi.Items.Clear();

                    //Personel resim göster
                    imgPersonelResim.ImageUrl = p.resimBoy2;

                    pnlUst.Title = string.Format("<b>{0}-{1} {2}/{3}</b>", p.TCKIMLIKNO, p.ad, p.soyad, p.sicilNo);

                    lblTipUnvan.Text = string.Format("{0}/{1}", p.personelTipAd, p.unvanAd);
                    lblKadroYeri.Text = p.kadro.birimGorevAd;
                    lblIletisim.Text = string.Format("{0}-{1}-{2}", p.cepTelefon, p.isTelefon, p.EPOSTA);

                    lblKurumaBasTar.Text = p.kurumaBaslamaTarihi.ToString();
                    lblGorevYeri.Text = p.kadro.gorevBirimAd;
                    lblVekilUnv.Text = p.kadro.vekilUnvanAd;

                    lblKadroDerece.Text = p.KADRODERECE + "/" + p.emekliEsasEkGosterge;
                    lblKazanilmisD.Text = p.kazanilmisHakDerece + "-" + p.kazanilmisHakKademe + "/" + p.kazanilmisEkGosterge;
                    lblEmekliD.Text = p.emekliEsasDerece + "-" + p.emekliEsasKademe + "/" + p.emekliEsasEkGosterge;

                    //bool yetkisiVar = true;
                    //if (!TNS.IKY.Yetki.YetkisiVarMiBirime(kullanan, p.muhasebeKodu.ToString(), p.birimKodu, p.organizasyonKodu))
                    //    yetkisiVar = false;

                    //Tab Panelleri Oluştur
                    TabPanelleriOlustur(p);
                }
            }
        }

        private string islemlerListe = "";
        void TabPanelleriOlustur(TNS.IKY.Personel p)
        {
            List<Panel> pnlList = new List<Panel>();
            string IFrameHTTP = TNS.KYM.Arac.ServerWebConfigOku("IFrameHTTP", "0");
            string urlPath;
            urlPath = HttpContext.Current.Request.Url.AbsoluteUri;
            urlPath = urlPath.Substring(0, urlPath.LastIndexOf("/"));
            if ((IFrameHTTP == "1") || (IFrameHTTP == "2"))
            {
                if ((IFrameHTTP == "1")) //HTTP Yap
                {
                    if ((urlPath[4] == 'S' || urlPath[4] == 's'))
                        urlPath = urlPath.Remove(4, 1);
                }
                else if (urlPath[4] == ':')//HTTPS Yap
                {
                    urlPath = urlPath.Insert(4, "s");
                }
            }

            islemlerListe = servisIKY.KullanicininIslemleri(kullanan, p.kopruKodTam, TNS.MUH.ENUMOGY.Gorme);
            //pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.HizliBilgi));
            pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Kisisel));
            if (p.kod > 0)
            {
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Kadro));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.IzinHareket));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Gorevler));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Aile));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.MaasParam));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Adres));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.PersonelKullaniciIslemleri));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Gider));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.MalBildirimi));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Ogrenim));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.YabanciDil));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Egitim));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.CezaOdul));
                if (p.nufus.cinsiyeti == ENUMCINSIYET.ERKEK)
                    pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Askerlik));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.IzinDevir));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Tarihce));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Kart));
                pnlListEkle(pnlList, TabPanelOlustur(urlPath, p, TabPanelAd.Lojman));
            }
            TabPersonelBilgi.Items.AddRange(pnlList);
            TabPersonelBilgi.Render();
        }

        private void pnlListEkle(List<Panel> pnlList, Panel panel)
        {
            if (panel != null)
                pnlList.Add(panel);
        }

        Panel TabPanelOlustur(string urlPath, TNS.IKY.Personel p, TabPanelAd tabPanelAd)
        {
            if (!TabPanelYetki(p, tabPanelAd))
                return null;
            Panel tab = new Panel();
            tab.ID = TabPanelIDGetir(tabPanelAd);
            tab.Title = TabPanelAdGetir(tabPanelAd);
            tab.Closable = false;
            tab.Padding = 0;
            string parTc = "";
            if (!string.IsNullOrWhiteSpace(p.tcKimlikNo)) parTc = "&tcKimlikNo=" + p.tcKimlikNo;
            tab.AutoLoad.Url = string.Format("{0}/{1}?menuYok=1&personelKod={2}&personelTur={3}" + parTc, urlPath, TabPanelSayfaGetir(tabPanelAd), p.kod, p.personelTipleri);

            tab.AutoLoad.ShowMask = true;
            tab.AutoLoad.MaskMsg = Resources.InsanKaynaklari.FRMORT073;
            tab.Flex = 1;
            return tab;
        }

        private string TabPanelIDGetir(TabPanelAd tabPanelAd)
        {
            switch (tabPanelAd)
            {
                case TabPanelAd.Kisisel: return "tabKisisel";
                case TabPanelAd.Adres: return "tabAdres";
                case TabPanelAd.Aile: return "tabAile";
                case TabPanelAd.Ogrenim: return "tabOgrenim";
                case TabPanelAd.YabanciDil: return "tabYabanci";
                case TabPanelAd.IzinHareket: return "tabIzin";
                case TabPanelAd.Memuriyet: return "tabMemuriyet";
                case TabPanelAd.Kadro: return "tabKadro";
                case TabPanelAd.Egitim: return "tabHizmetIciEğitim";
                case TabPanelAd.CezaOdul: return "tabCeza";
                case TabPanelAd.MalBildirimi: return "tabMalBildirimi";
                case TabPanelAd.Nitelik: return "tabBilgiBirikimi";
                case TabPanelAd.Tarihce: return "tabTarihce";
                case TabPanelAd.PersonelKullaniciIslemleri: return "tabKullanici";
                case TabPanelAd.Askerlik: return "tabAskerlik";
                case TabPanelAd.Kart: return "tabKart";
                case TabPanelAd.MaasParam: return "tabMaasParam";
                case TabPanelAd.Lojman: return "tabLojman";
                case TabPanelAd.IzinDevir: return "tabIzinDevir";
                case TabPanelAd.HizliBilgi: return "tabHizliBilgi";
                case TabPanelAd.Gider: return "tabGider";
                case TabPanelAd.Gorevler: return "tabGorevler";
            }
            return "";
        }

        string TabPanelAdGetir(TabPanelAd tabPanelAd)
        {
            switch (tabPanelAd)
            {
                case TabPanelAd.Kisisel: return "Kişisel";
                case TabPanelAd.Adres: return "İletişim/Adres";
                case TabPanelAd.Aile: return "Aile";
                case TabPanelAd.Ogrenim: return "Öğrenim Durumu";
                case TabPanelAd.YabanciDil: return "Yabancı Dil";
                case TabPanelAd.IzinHareket: return "İzin/Görev";
                case TabPanelAd.Memuriyet: return "Memuriyet";
                case TabPanelAd.Kadro: return "Hizmet Belgesi";
                case TabPanelAd.Egitim: return "Hizmet İçi Eğitim";
                case TabPanelAd.CezaOdul: return "Ceza/Ödül";
                case TabPanelAd.MalBildirimi: return "Mal Bildirimi";
                case TabPanelAd.Nitelik: return "Bilgi Birikimi/Nitelik";
                case TabPanelAd.Tarihce: return "Tarihçe";
                case TabPanelAd.PersonelKullaniciIslemleri: return "Kullanici İşlemleri";
                case TabPanelAd.Askerlik: return "Askerlik";
                case TabPanelAd.Kart: return "Kart";
                case TabPanelAd.MaasParam: return "Maaş Parametreleri";
                case TabPanelAd.Lojman: return "Lojman";
                case TabPanelAd.IzinDevir: return "İzin Devir";
                case TabPanelAd.HizliBilgi: return "Hızlı Bilgi";
                case TabPanelAd.Gider: return "Giderler";
                case TabPanelAd.Gorevler: return "Görevlendirmeler";
            }
            return "";
        }

        string TabPanelSayfaGetir(TabPanelAd tabPanelAd)
        {
            switch (tabPanelAd)
            {
                case TabPanelAd.Kisisel: return "PersonelKisisel.aspx";
                case TabPanelAd.Adres: return "PersonelAdres.aspx";
                case TabPanelAd.Aile: return "PersonelAile.aspx";
                case TabPanelAd.Ogrenim: return "PersonelOgrenim.aspx";
                case TabPanelAd.YabanciDil: return "PersonelDil.aspx";
                case TabPanelAd.IzinHareket: return "PersonelIzin.aspx";
                case TabPanelAd.Memuriyet: return "PersonelMemuriyet.aspx";
                case TabPanelAd.Kadro: return "PersonelKadro.aspx";
                case TabPanelAd.Egitim: return "PersonelKurs.aspx";
                case TabPanelAd.CezaOdul: return "PersonelCezaOdul.aspx";
                case TabPanelAd.MalBildirimi: return "PersonelMalBildirimi.aspx";
                case TabPanelAd.Nitelik: return "PersonelNitelik.aspx";
                case TabPanelAd.Tarihce: return "PersonelTarihce.aspx";
                case TabPanelAd.PersonelKullaniciIslemleri: return "PersonelKullaniciIslemleri.aspx";
                case TabPanelAd.Askerlik: return "PersonelAskerlik.aspx";
                case TabPanelAd.Kart: return "PersonelKart.aspx";
                case TabPanelAd.MaasParam: return "PersonelMaasParam.aspx";
                case TabPanelAd.Lojman: return "PersonelLojman.aspx";
                case TabPanelAd.IzinDevir: return "PersonelIzinDevirTab.aspx";
                case TabPanelAd.HizliBilgi: return "PersonelHizliBilgi.aspx";
                case TabPanelAd.Gider: return "PersonelGider.aspx";
                case TabPanelAd.Gorevler: return "PersonelGorev.aspx";
            }
            return "";
        }

        bool TabPanelYetki(TNS.IKY.Personel p, TabPanelAd tabPanelAd)
        {
            if (p.aktifMi == 0)
            {
                if (tabPanelAd == TabPanelAd.Kadro || tabPanelAd == TabPanelAd.Kisisel)
                    return true;
            }
            ENUMYetkiIslem yIslem = YetkiKoduBul(tabPanelAd);

            return Genel.StringdeVarMi((int)yIslem, islemlerListe);
        }

        private ENUMYetkiIslem YetkiKoduBul(TabPanelAd tabPanelAd)
        {
            switch (tabPanelAd)
            {
                case TabPanelAd.Kisisel: return ENUMYetkiIslem.OzlukDetay;
                case TabPanelAd.Adres: return ENUMYetkiIslem.Iletisim;
                case TabPanelAd.Aile: return ENUMYetkiIslem.Aile;
                case TabPanelAd.Ogrenim: return ENUMYetkiIslem.Ogrenim;
                case TabPanelAd.YabanciDil: return ENUMYetkiIslem.YabanciDil;
                case TabPanelAd.IzinHareket: return ENUMYetkiIslem.Izin;
                case TabPanelAd.Memuriyet: return ENUMYetkiIslem.Hizmetler;
                case TabPanelAd.Gorevler: return ENUMYetkiIslem.Hizmetler;
                case TabPanelAd.Kadro: return ENUMYetkiIslem.Hizmetler;
                case TabPanelAd.Egitim: return ENUMYetkiIslem.HizmetIciEgitim;
                case TabPanelAd.CezaOdul: return ENUMYetkiIslem.CezaOdul;
                case TabPanelAd.MalBildirimi: return ENUMYetkiIslem.MalBildirimi;
                case TabPanelAd.Nitelik: return ENUMYetkiIslem.Nitelik;
                case TabPanelAd.Tarihce: return ENUMYetkiIslem.Tarihce;
                case TabPanelAd.PersonelKullaniciIslemleri: return ENUMYetkiIslem.KullaniciIslemleri;
                case TabPanelAd.Askerlik: return ENUMYetkiIslem.Askerlik;
                case TabPanelAd.Kart: return ENUMYetkiIslem.Kartlar;
                case TabPanelAd.MaasParam: return ENUMYetkiIslem.MaasParametreleri;
                case TabPanelAd.Lojman: return ENUMYetkiIslem.Lojman;
                case TabPanelAd.IzinDevir: return ENUMYetkiIslem.IzinDevir;
                case TabPanelAd.HizliBilgi: return ENUMYetkiIslem.HizliBilgi;
                case TabPanelAd.Gider: return ENUMYetkiIslem.Gider;
                default: return ENUMYetkiIslem.Tanimsiz;
            }
        }

        enum TabPanelAd
        {
            Kisisel, Adres, Aile, Ogrenim, YabanciDil, IzinHareket, Memuriyet, Kadro, Egitim, CezaOdul, MalBildirimi, Nitelik, Tarihce,
            PersonelKullaniciIslemleri, Askerlik, Kart, MaasParam, Lojman, IzinDevir, HizliBilgi, Gider, Gorevler
        }
    }
}