﻿using System;
using System.Collections;
using System.Data;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;

namespace InsanKaynaklari
{
    public partial class KadroKontenjan : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public static int kadroDereceSayi;
        DataTable dtKadroKontenjan;
        ENUMPersonelTur personelTur;

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, "KadroKontenjanAna.aspx");

            if (!IsPostBack)
            {
                ddlBirim.KullanicininBirimleri = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");
                Genel.KadroIslemTurDoldur(storeIslemTur, false);
                Genel.UnvanDoldur(servisIKY, this, storeUnvan);
            }
        }

        //Kalkacak
        protected void NodeLoad(object sender, NodeLoadEventArgs e)
        {
            Genel.BirimDoldur(e);

        }

        /// <summary>
        /// Handles the Init event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Init(object sender, EventArgs e)
        {
            personelTur = (ENUMPersonelTur)GenelIslemlerIstemci.RequestBul(this, "personelTur", 1);
            if (personelTur == ENUMPersonelTur.Isci)
                kadroDereceSayi = 1;
            else
                kadroDereceSayi = 15;
            KadroKontenjanKolonEkle();
        }

        /// <summary>
        /// Handles the Click event of the btnListele control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="Ext1.Net.DirectEventArgs"/> instance containing the event data.</param>
        protected void btnListele_Click(object sender, DirectEventArgs e)
        {
            Listele(0);
        }

        /// <summary>
        /// Handles the Click event of the btnKaydet control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="Ext1.Net.DirectEventArgs"/> instance containing the event data.</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            TNS.IKY.KadroKontenjan kk = new TNS.IKY.KadroKontenjan();

            kk.kod = OrtakFonksiyonlar.ConvertToInt(txtSira.Value, 0);
            kk.organizasyonKod = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
            kk.islemTur = (EnumKadroKontenjanIslemTur)OrtakFonksiyonlar.ConvertToInt(cmbIslemTur.Value, 0);
            kk.aciklama = txtAciklama.Value != null ? txtAciklama.Value.ToString() : null;
            kk.dayanakBelgeTarih = Genel.TarihAlaniDegerVer(txtDayanakBelgeTarih);
            kk.dayanakBelgeNo = txtDayanakBelgeNo.Value != null ? txtDayanakBelgeNo.Value.ToString() : null;
            kk.detaylar = (KadroKontenjanDetay[])ArrayListeDoldur((Newtonsoft.Json.Linq.JArray)JSON.Deserialize(e.ExtraParams["paramKadroKontenjan"])).ToArray(typeof(KadroKontenjanDetay));
            kk.personelTur = personelTur;
            Sonuc sonuc = servisIKY.KadroKontenjanKaydet(kullanan, kk);
            if (sonuc.islemSonuc)
            {
                txtSira.Value = sonuc.anahtar.PadLeft(6, '0');
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);
            }
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            ddlBirim.Clear();
            txtSira.Clear();
            txtIslemTarih.Clear();
            txtDayanakBelgeTarih.Clear();
            txtDayanakBelgeNo.Clear();
            txtAciklama.Clear();
            cmbIslemTur.Clear();
            grdKadroKontenjan.SelectionModel.Clear();
            storeKadroKontenjan.RemoveAll();
            storeKadroKontenjan.DataBind();
        }

        /// <summary>
        /// Handles the Click event of the btnYazdir control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void btnYazdir_Click(object sender, EventArgs e)
        {
            System.Collections.Hashtable raporParam = new System.Collections.Hashtable();
            raporParam["BirimAd"] = ddlBirim.Text.ToUpper();
            raporParam["ORGKOD"] = ddlBirim.Value;
            raporParam["IslemSiraNo"] = txtSira.Value;

            string dosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            string uretilenDosya = new PersonelRaporlari().RaporAl(kullanan, servisIKY, this.raporSablonYol + @"IKY\" + "PersonelKadroKontenjanIslem.xlt", dosyaAd, GenelIslemler.ExcelTur(), raporParam, "IK010");
            System.IO.File.Delete(dosyaAd);
            if (!string.IsNullOrEmpty(uretilenDosya))
                DosyaIslem.DosyaGonder(uretilenDosya, Resources.InsanKaynaklari.FRMPRPA005, true, GenelIslemler.ExcelTur());
            else
                GenelIslemler.MesajKutusu(this, "Rapor bulunamadı.");
        }

        ArrayList ArrayListeDoldur(Newtonsoft.Json.Linq.JArray jArray)
        {
            ArrayList liste = new ArrayList();
            if (jArray == null)
                return liste;

            foreach (Newtonsoft.Json.Linq.JObject item in jArray)
            {
                for (int i = 1; i <= kadroDereceSayi; i++)
                {
                    int unvanKod = OrtakFonksiyonlar.ConvertToInt(item.Value<string>("Unvan"), 0);
                    if (unvanKod <= 0)
                        continue;

                    KadroKontenjanDetay detay = new KadroKontenjanDetay();
                    detay.unvanKod = unvanKod;
                    detay.kadroDerece = i;
                    detay.kontenjan = OrtakFonksiyonlar.ConvertToInt(item.Value<string>(i.ToString()), 0);

                    liste.Add(detay);
                }
            }
            return liste;
        }

        [DirectMethod]
        public void Listele(int kod)
        {
            TNS.IKY.KadroKontenjan kk = new TNS.IKY.KadroKontenjan();
            if (kod > 0)
                kk.kod = kod;
            else
            {
                if (OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0) > 0)
                    kk.organizasyonKod = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
            }
            kk.personelTur = ENUMPersonelTur.Memur;

            try
            {
                TNS.IKY.KadroKontenjan[] kklar = servisIKY.KadroKontenjanListele(kullanan, kk, true);
                if (kklar == null || kklar.Length <= 0)
                {
                    GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.FRMKAD016);
                    return;
                }
                kk = kklar[0];
            }
            catch (Exception e)
            {
                GenelIslemler.HataYaz(this, e.Message);
                return;
            }

            ddlBirim.SetValue(kk.organizasyonKod.ToString(), kk.organizasyonAd);
            txtSira.Value = kk.kod.ToString().PadLeft(6, '0');
            cmbIslemTur.Value = (int)kk.islemTur;
            txtIslemTarih.Value = kk.islemTarih.ToString();
            txtAciklama.Value = kk.aciklama;
            txtDayanakBelgeTarih.Value = kk.dayanakBelgeTarih.ToString();
            txtDayanakBelgeNo.Value = kk.dayanakBelgeNo.ToString();

            DetayYaz(kk.detaylar);
        }
        void DetayYaz(KadroKontenjanDetay[] detaylar)
        {
            if (detaylar == null)
                return;

            TNSCollection liste = new TNSCollection(detaylar);
            for (int i = 0; i < liste.Count; i++)
            {
                KadroKontenjanDetay detay = (KadroKontenjanDetay)liste[i];

                int[] kadroDereceDegerler = new int[kadroDereceSayi];
                kadroDereceDegerler[detay.kadroDerece - 1] = detay.kontenjan;
                liste.RemoveAt(i);
                i--;

                for (int j = i + 1; j < liste.Count; j++)
                {
                    KadroKontenjanDetay detayDevam = (KadroKontenjanDetay)liste[j];

                    if (detay.unvanKod == detayDevam.unvanKod)
                    {
                        kadroDereceDegerler[detayDevam.kadroDerece - 1] = detayDevam.kontenjan;
                        liste.RemoveAt(j);
                        j--;
                    }
                }

                DataRow dr = dtKadroKontenjan.NewRow();
                dr.SetField<string>(0, detay.unvanKod.ToString());
                for (int k = 0; k < kadroDereceDegerler.Length; k++)
                    dr.SetField<string>(k + 1, kadroDereceDegerler[k] == 0 ? "" : kadroDereceDegerler[k].ToString("#,###"));
                dtKadroKontenjan.Rows.Add(dr);
            }

            storeKadroKontenjan.DataSource = dtKadroKontenjan;
            storeKadroKontenjan.DataBind();
        }
        void KadroKontenjanKolonEkle()
        {
            storeKadroKontenjan.Reader[0].Fields.Add("Unvan");

            Column col = new Column();
            col.Header = Resources.InsanKaynaklari.FRMKAD019;
            col.DataIndex = "Unvan";
            col.Width = System.Web.UI.WebControls.Unit.Pixel(300);
            col.MenuDisabled = true;
            col.Sortable = false;
            col.Align = Alignment.Left;
            col.Renderer.Fn = "unvanRenderer";

            ComboBox cmb = new ComboBox();
            cmb.ID = "cmbUnvan";
            cmb.StoreID = "storeUnvan";
            cmb.Shadow = ShadowMode.Drop;
            cmb.DisplayField = "UnvanAd";
            cmb.ValueField = "UnvanKod";
            cmb.Mode = DataLoadMode.Local;
            cmb.TriggerAction = TriggerAction.All;
            cmb.Editable = true;
            cmb.SelectOnFocus = true;
            col.Editor.Add(cmb);

            grdKadroKontenjan.ColumnModel.Columns.Add(col);
            grdKadroKontenjan.AutoExpandColumn = "Unvan";

            dtKadroKontenjan = new DataTable();
            dtKadroKontenjan.Columns.Add("Unvan");

            for (int i = 1; i <= kadroDereceSayi; i++)
            {
                storeKadroKontenjan.Reader[0].Fields.Add(i.ToString());

                col = new Column();
                col.Header = i.ToString();
                col.DataIndex = i.ToString();
                col.MenuDisabled = true;
                col.Sortable = false;
                col.Align = Alignment.Center;
                col.Width = System.Web.UI.WebControls.Unit.Pixel(80);

                TextField tf = new TextField();
                tf.ID = "tfKadroDerece" + i.ToString();
                tf.SelectOnFocus = true;
                col.Editor.Add(tf);

                grdKadroKontenjan.ColumnModel.Columns.Add(col);

                dtKadroKontenjan.Columns.Add(i.ToString());
            }
        }
    }
}