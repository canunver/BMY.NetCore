﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimDil : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Dil Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Listele(new Dil());
            }
        }

        public void Listele(Dil kriter)
        {
            //ObjectArray dler = servisIKY.DilListele(kriter);

            //if (!dler.sonuc.islemSonuc)
            //{
            //    GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
            //    return;
            //}

            //if (dler.objeler.Count <= 0)
            //    GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            //List<object> tipler = new List<object>();
            //foreach (TNS.IKY.Dil d in dler.objeler)
            //    tipler.Add(new
            //    {
            //        DILKODU = d.kod,
            //        DILADI = d.ad,
            //    });

            //ListeStore.DataSource = tipler;
            //ListeStore.DataBind();
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            //Dil d = new Dil();
            //d.ad = txtDilAdi.Text.Trim();
            //Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            //if (txtDilAdi.Text.Trim() == "")
            //{
            //    GenelIslemler.HataYaz(this, "Dil alanı boş bırakılamaz.");
            //    return;
            //}

            //Dil d = new Dil();
            //d.kod = OrtakFonksiyonlar.ConvertToInt(hdnDilKodu.Value, 0);
            //d.ad = txtDilAdi.Text;

            //Sonuc sonuc = servisIKY.DilKaydet(kullanan, d);
            
            //if (!sonuc.islemSonuc)
            //    GenelIslemler.HataYaz(this, sonuc.hataStr);
            //else
            //{
            //    Temizle();
            //    Listele(new Dil());
            //    GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            //}
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            //Dil d = new Dil();
            //int kod = OrtakFonksiyonlar.ConvertToInt(hdnDilKodu.Value, 0);

            //if (kod > 0)
            //{
            //    d.kod = kod;
            //    Sonuc sonuc = servisIKY.DilSil(kullanan, d);

            //    if (!sonuc.islemSonuc)
            //        GenelIslemler.HataYaz(this, sonuc.hataStr);
            //    else
            //    {
            //        Temizle();
            //        Listele(new Dil());
            //        GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
            //    }
            //}
            //else
            //    GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz dili seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            //Listele(new Dil());
            //Temizle();
        }

        //void Temizle()
        //{
        //    hdnDilKodu.Value = "";
        //    txtDilAdi.Text = "";
        //    grdListeSelectionModel.ClearSelections();
        //}

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            //hdnDilKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["dilKodu"]);
            //txtDilAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["dilAdi"]);
        }
    }
}
