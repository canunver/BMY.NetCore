﻿using System;
using System.Web.UI.WebControls;
using TNS.ORG;
using TNS.BKD;
using OrtakClass;
using TNS;
using System.Data;
using WebServisler.EvrakServis;
using TNS.IKY;
using System.Collections.Generic;
using Ext1.Net;
using System.Collections;

namespace InsanKaynaklari
{
    /// <summary>
    /// Görevlendirme sınıfı
    /// </summary>
    public partial class PersonelSiteKesintisi : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Sayfaya giriş izni varmı?
            formAdi = "Personel Site Kesintisi";
            SayfaUstAltBolumYaz(this);
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                int kolSira = 6;

                TNSCollection col = servisIKY.SozlukGiderListele(kullanan, new SozlukGider()).objeler;
                int cnt = 0;
                SozlukGider gider = new SozlukGider();
                gider.kesintiler = new TNSCollection();
                ArrayList al = new ArrayList();
                ArrayList al2 = new ArrayList();
                foreach (SozlukGider s in col)
                {
                    smDegiskenler.SelectedRows.Add(new SelectedRow(cnt));

                    if (s.endexGor == 1)
                        OrtakClass.ChartTool.GridNumberAlanEkle(grdListe, stoListe, s.kod.ToString() + "Endex", RecordFieldType.Float, s.ad + " Endex", true, false, kolSira++, "0.000,0000/i", null, 90, null, true);
                    else
                        OrtakClass.ChartTool.GridCheckEkle(grdListe, stoListe, s.kod.ToString() + "Dahil", s.ad + " Dahil", true, false, kolSira++, false, 90, null, true);

                    if (s.eldenGor == 1)
                        OrtakClass.ChartTool.GridNumberAlanEkle(grdListe, stoListe, s.kod.ToString() + "Elden", RecordFieldType.Float, s.ad + " Elden", true, false, kolSira++, "0.000,0000/i", null, 90, null, true);

                    if (s.aciklamaGor == 1)
                        OrtakClass.ChartTool.GridStringAlanEkle(grdListe, stoListe, s.kod.ToString() + "Aciklama", s.ad + " Aciklama", true, false, 90, null, null, true, null, null, null);
                    al.Add(s);
                    if (s.eldenGor == 1)
                        al2.Add(s);
                    cnt++;
                }

                stoDegiskenler.DataSource = al;
                stoDegiskenler.DataBind();

                stoDegiskenElden.DataSource = al2;
                stoDegiskenElden.DataBind();

                spnYilAra.Number = DateTime.Now.Year;
                Genel.AyDoldur(ddlAyAra, ayStore, true);
                ddlAyAra.SelectedItem.Value = DateTime.Now.Month.ToString();
                Genel.LojmanSiteDoldur(kullanan, ddlSiteAra, siteStore);
                siteStore.InsertRecord(0, new { kod = -1, siteAdi = "Tümü" });
            }
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected void PersonelListele(object sender, DirectEventArgs e)
        {
            smDegiskenler.SelectedRows.Clear();
            SozlukGider[] degiskenlerAll = (SozlukGider[])Ext.Net.JSON.Deserialize(e.ExtraParams["degiskenlerAll"], typeof(SozlukGider[]));
            for (int i = 0; i < degiskenlerAll.Length; i++)
                smDegiskenler.SelectedRows.Add(new SelectedRow(i));

            Listele();
        }

        protected void Listele()
        {
            string hata = Kontrol();
            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.BilgiYaz(this, hata);
                return;
            }
            PersonelLojmani sg = new PersonelLojmani();
            sg.siteKod = OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0);
            sg.blokKod = OrtakFonksiyonlar.ConvertToInt(ddlBlokAra.SelectedItem.Value, 0);
            sg.yil = OrtakFonksiyonlar.ConvertToInt(spnYilAra.Number, 0);
            sg.ay = OrtakFonksiyonlar.ConvertToInt(ddlAyAra.SelectedItem.Value, 0);
            sg.giderleriOku = true;
            ObjectArray oa = servisIKY.PersonelDoluDaireListesi(kullanan, sg);

            hdnYil.Value = spnYilAra.Number;
            hdnAy.Value = OrtakFonksiyonlar.ConvertToInt(ddlAyAra.SelectedItem.Value, 0);

            GizleAc(!TNS.IKY.Arac.DonemAcikMi(OrtakFonksiyonlar.ConvertToInt(hdnYil.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnAy.Value, 0)));

            TNSCollection col = servisIKY.SozlukGiderListele(kullanan, new SozlukGider()).objeler;

            SiteGider sgForm = new SiteGider();
            sgForm.siteKod = sg.siteKod;
            sgForm.yil = sg.yil;
            sgForm.ay = sg.ay;
            ObjectArray oaSg = servisIKY.SiteGiderListele(kullanan, sgForm);

            int colNo = 5;
            for (int i = 0; i < col.Count; i++)
            {
                SozlukGider sgIc = (SozlukGider)col[i];
                sgForm = SiteGiderAl(oaSg, i);
                if (sgIc.endexGor == 1)
                    colNo++;
                else
                {
                    grdListe.ColumnModel.SetHidden(colNo, sgForm.miktar == 0);
                    colNo++;
                }
                if (sgIc.eldenGor == 1)
                    colNo++;

                if (sgIc.aciklamaGor == 1)
                    colNo++;
            }


            ArrayList al = new ArrayList();
            foreach (PersonelLojmani per in oa.objeler)
            {
                SozlukGider kg = per.kesintiler;
                ArrayList alIc = new ArrayList();
                alIc.Add(per.kod);
                alIc.Add(per.siteAdi);
                alIc.Add(per.blokNo);
                alIc.Add(per.daireNo);
                alIc.Add(per.personelAd);
                alIc.Add(per.unvanAd);
                alIc.Add(per.siteKod);
                alIc.Add(per.personelKod);

                for (int i = 0; i < col.Count; i++)
                {
                    SozlukGider sgIc = (SozlukGider)col[i];
                    PersonelSiteKesinti perKes = KesintiAl(per.kesintiler, i);
                    if (sgIc.endexGor == 1)
                        alIc.Add(perKes.endex);
                    else
                        alIc.Add(perKes.aktif);

                    if (sgIc.eldenGor == 1)
                        alIc.Add(perKes.elden);

                    if (sgIc.aciklamaGor == 1)
                        alIc.Add(perKes.aciklama);
                }
                al.Add(alIc.ToArray());
            }
            stoListe.DataSource = al;
            stoListe.DataBind();
        }

        private SiteGider SiteGiderAl(ObjectArray oaSg, int sira)
        {
            SiteGider siteGider = null;
            if (oaSg != null && sira < oaSg.ObjeSayisi)
                siteGider = (SiteGider)oaSg.objeler[sira];

            if (siteGider == null) siteGider = new SiteGider();
            return siteGider;
        }

        private PersonelSiteKesinti KesintiAl(SozlukGider kg, int sira)
        {
            PersonelSiteKesinti perKes = null;
            if (kg != null && kg.kesintiler != null && sira < kg.kesintiler.Count)
            {
                perKes = (PersonelSiteKesinti)kg.kesintiler[sira];
            }
            if (perKes == null) perKes = new PersonelSiteKesinti();
            return perKes;
        }

        protected void GizleAc(bool gizli)
        {
            btnKaydet.Disabled = gizli;
            //grdListe.Disabled = gizli;
            //btnDegerAra.Disabled = gizli;
        }

        string Kontrol()
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0) == 0)
                hata += "Site seçiniz.";
            if (OrtakFonksiyonlar.ConvertToInt(ddlBlokAra.SelectedItem.Value, 0) == 0)
                hata += "Blok seçiniz.";
            if (OrtakFonksiyonlar.ConvertToInt(spnYilAra.Number, 0) == 0)
                hata += "Kesinti yılı seçiniz.";
            if (OrtakFonksiyonlar.ConvertToInt(ddlAyAra.SelectedItem.Value, 0) == 0)
                hata += "Kesinti ayı seçiniz.";

            return hata;
        }

        protected void SiteDegisti(object sender, DirectEventArgs e)
        {
            BlokDoldur();
            ddlBlokAra.SelectedItem.Value = "";
        }

        protected void BlokDoldur()
        {
            if (OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0) == 0)
            {
                List<object> liste = new List<object>();
                blokStore.DataSource = liste;
                blokStore.DataBind();
            }
            else
                Genel.LojmanSiteBlokDoldur(kullanan, ddlBlokAra, blokStore, OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0));
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            PersonelSiteKesinti[] ksler = new PersonelSiteKesinti[0];
            Newtonsoft.Json.Linq.JObject[] paramlar = (Newtonsoft.Json.Linq.JObject[])Ext.Net.JSON.Deserialize(e.ExtraParams["param"], typeof(Newtonsoft.Json.Linq.JObject[]));
            SozlukGider[] degiskenler = (SozlukGider[])Ext.Net.JSON.Deserialize(e.ExtraParams["degiskenler"], typeof(SozlukGider[]));
            TNSCollection degiskenAdlar = new TNSCollection();
            TNSCollection kisiler = new TNSCollection();
            int siteKod = OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0);
            foreach (Newtonsoft.Json.Linq.JObject row in paramlar)
            {
                PersonelLojmani per = new PersonelLojmani();
                per.kod = row.Value<int>("kod");
                per.personelKod = row.Value<int>("personelKod");
                per.yil = OrtakFonksiyonlar.ConvertToInt(hdnYil.Value, 0);
                per.ay = OrtakFonksiyonlar.ConvertToInt(hdnAy.Value, 0);
                per.siteKod = siteKod;

                per.pkesintiler = new TNSCollection();

                for (int i = 0; i < degiskenler.Length; i++)
                {
                    int aktif = row.Value<int>(degiskenler[i].kod + "Dahil");
                    double elden = row.Value<double>(degiskenler[i].kod + "Elden");
                    double endex = row.Value<double>(degiskenler[i].kod + "Endex");
                    string aciklama = row.Value<string>(degiskenler[i].kod + "Aciklama");
                    per.pkesintiler.Add(new PersonelSiteKesinti
                    {
                        yil = per.yil,
                        ay = per.ay,
                        elden = elden,
                        aktif = aktif,
                        endex = endex,
                        giderKod = degiskenler[i].kod,
                        personelKod = per.personelKod,
                        pLojmanKod = per.kod,
                        aciklama = aciklama
                    });
                }
                kisiler.Add(per);
            }

            TNS.Sonuc s = servisIKY.PersonelKesintileriKaydet(kullanan, kisiler);
            if (s.islemSonuc)
                GenelIslemler.MesajKutusu("Sonuç", "Kayıt başarılı");
            else
                GenelIslemler.MesajKutusu("Hata", s.hataStr);
        }

        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
            int siteKod = OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0);
            int yil = OrtakFonksiyonlar.ConvertToInt(spnYilAra.Number, 0);
            int ay = OrtakFonksiyonlar.ConvertToInt(ddlAyAra.SelectedItem.Value, 0);
            int tur = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["Tur"], 0);
            RaporPersonel.raporUret(servisIKY, kullanan, istemciUzayi.GenelSayfa.RaporSablonYol(), (tur == 2 ? "IK049a" : "IK049"), "", "", "", "", 0, "xlsx", 0, false, "", "", "", "", true, "", 0, siteKod, 0, yil, ay, 0, 0, 0, "", "", 0, "");
        }
    }
}
