﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;
using System.Collections.Generic;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class SitePersonelKesintisi : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = "Personel Site Kesintisi";
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                spnYilAra.Number = DateTime.Now.Year;
                Genel.AyDoldur(ddlAyAra, ayStore, true);
                ddlAyAra.SelectedItem.Value = DateTime.Now.Month.ToString();
                Listele();
                Genel.LojmanSiteDoldur(kullanan, ddlSiteAra, siteStore);
                Genel.SozlukGiderTuruDoldur(kullanan, ddlGiderGrid, sozlukGiderStore);
                siteStore.InsertRecord(0, new { kod = -1, siteAdi = "Tümü" });
                sozlukGiderStore.InsertRecord(0, new { kod = -1, ad = "Tümü" });
            }
        }

        protected void Listele()
        {
            string hata = Kontrol(true);
            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.BilgiYaz(this, hata);
                return;
            }
            PersonelLojmani sg = new PersonelLojmani();
            sg.siteKod = OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0);
            sg.blokKod = OrtakFonksiyonlar.ConvertToInt(ddlBlokAra.SelectedItem.Value, 0);
            sg.yil = OrtakFonksiyonlar.ConvertToInt(spnYilAra.Number, 0);
            sg.ay = OrtakFonksiyonlar.ConvertToInt(ddlAyAra.SelectedItem.Value, 0);
            ObjectArray oa = servis.PersonelDoluDaireListesi(kullanan, sg);
            stoListe.DataSource = oa.objeler;
            stoListe.DataBind();
            hdnYil.Value = spnYilAra.Number;
            hdnAy.Value = OrtakFonksiyonlar.ConvertToInt(ddlAyAra.SelectedItem.Value, 0);
            Temizle();
        }

        string Kontrol(bool ara)
        {
            string hata = "";
            if (!ara)
            {
                if (OrtakFonksiyonlar.ConvertToInt(hdnplKod.Value, 0) == 0)
                    hata = "Kesinti personel dairesi seçiniz.";
            }
            if (OrtakFonksiyonlar.ConvertToInt(spnYilAra.Number, 0) == 0)
                hata += "Kesinti yılı seçiniz.";
            if (OrtakFonksiyonlar.ConvertToInt(ddlAyAra.SelectedItem.Value, 0) == 0)
                hata += "Kesinti ayı seçiniz.";

            return hata;
        }

        protected void KesintiListele()
        {
            PersonelSiteKesinti sk = new PersonelSiteKesinti();
            sk.yil = OrtakFonksiyonlar.ConvertToInt(hdnYil.Value, 0);
            sk.ay = OrtakFonksiyonlar.ConvertToInt(hdnAy.Value, 0);
            sk.pLojmanKod = OrtakFonksiyonlar.ConvertToInt(hdnplKod.Value, 0);
            ObjectArray oa = servis.PersonelSiteKesintisiListele(kullanan, sk);
            kesintiStore.DataSource = oa.objeler;
            kesintiStore.DataBind();
            if (oa.ObjeSayisi > 0)
            {
                PersonelSiteKesinti k = (PersonelSiteKesinti)oa.objeler[0];
                txtToplamTutar.Text = k.toplamTutar.ToString("0.000,00");
                hdnsktKod.Value = k.siteKesTopKod;
            }
        }

        void Kaydet(DirectEventArgs e)
        {
            string kesintiBilgileri = e.ExtraParams["kesintiBilgileri"];
            if (string.IsNullOrEmpty(kesintiBilgileri))
                return;

            Newtonsoft.Json.Linq.JObject[] satirlar = (Newtonsoft.Json.Linq.JObject[])JSON.Deserialize(kesintiBilgileri, typeof(Newtonsoft.Json.Linq.JObject[]));
            PersonelSiteKesinti[] st = new PersonelSiteKesinti[satirlar.Length];

            int i = 0;
            foreach (Newtonsoft.Json.Linq.JObject satir in satirlar)
            {
                st[i] = new PersonelSiteKesinti();
                st[i].pLojmanKod = OrtakFonksiyonlar.ConvertToInt(hdnplKod.Value, 0);
                st[i].yil = OrtakFonksiyonlar.ConvertToInt(hdnYil.Value, 0);
                st[i].ay = OrtakFonksiyonlar.ConvertToInt(hdnAy.Value, 0);
                st[i].aktif = Genel.DegerAlInt(satir, "aktif");
                st[i].endex = Genel.DegerAlDbl(satir, "endex");
                st[i].elden = Genel.DegerAlDbl(satir, "elden");
                st[i].giderKod = Genel.DegerAlInt(satir, "giderKod");
                st[i].aciklama = Genel.DegerAlStr(satir, "aciklama");
                st[i].toplamTutar = OrtakFonksiyonlar.ConvertToDouble(txtToplamTutar.Text);
                st[i].siteKesTopKod = OrtakFonksiyonlar.ConvertToInt(hdnsktKod.Value, 0);
                st[i].siteKod = OrtakFonksiyonlar.ConvertToInt(hdnsiteKod.Value, 0);

                i++;
            }

            Sonuc sonuc = servis.PersonelSiteKesintileriTopluKaydet(kullanan, st);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite003);
                KesintiListele();
            }
        }

        /// <summary>
        /// Lojman Site kodu olarak verilen değeri, txtkod alanına atar ve okuma işlemini çağırır.
        /// </summary>
        /// <param name="kod">Personel tipi kodu </param>
        [DirectMethod]
        public void Goster(int kod, string siteAdi, string blokNo, string daireNo, string personel, string unvan, int siteKod)
        {
            txtKod.Text = kod.ToString();
            hdnplKod.Value = kod;
            txtSite.Text = siteAdi;
            txtBlok.Text = blokNo;
            txtDaire.Text = daireNo;
            txtPersonel.Text = personel;
            txtUnvan.Text = unvan;
            txtYil.Text = hdnYil.Value.ToString();
            txtAy.Text = hdnAy.Value.ToString();
            hdnsiteKod.Value = siteKod;
            GizleAc(!(OrtakFonksiyonlar.ConvertToInt(hdnYil.Value, 0) == System.DateTime.Now.Year && OrtakFonksiyonlar.ConvertToInt(hdnAy.Value, 0) == System.DateTime.Now.Month));
            txtToplamTutar.Clear();
            hdnsktKod.Clear();
            KesintiListele();
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        /// <summary>
        /// Yazdir tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
        }

        ///// <summary>
        ///// Yeni tuşuna basılınca çalışacak olay fonksiyon
        ///// </summary>
        ///// <param name="sender">Olayı uyandıran nesne</param>
        ///// <param name="e">Olayın parametresi</param>
        //protected void btnYeni_Click(object sender, DirectEventArgs e)
        //{
        //    Temizle();
        //}

        /// <summary>
        /// Sil tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            if (OrtakFonksiyonlar.ConvertToInt(hdnsktKod.Value, 0) == 0)
                hata = "Personel kesintisi kayıt edilmediği için silemezsiniz.";
         
            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.BilgiYaz(this, hata);
                return;
            }
            //PersonelSiteKesinti k = new PersonelSiteKesinti();
            //k.pLojmanKod = OrtakFonksiyonlar.ConvertToInt(hdnplKod.Value,0);
            //k.yil = OrtakFonksiyonlar.ConvertToInt(hdnYil.Value, 0);
            //k.ay = OrtakFonksiyonlar.ConvertToInt(hdnAy.Value, 0);

            Sonuc sonuc = servis.PersonelSiteKesintisiToplamSil(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnsktKod.Value, 0));
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite042);
                KesintiListele();
            }
        }

        protected void Temizle()
        {
            txtKod.Clear();
            hdnplKod.Clear();
            txtSite.Clear();
            txtUnvan.Clear();
            txtYil.Clear();
            txtPersonel.Clear();
            txtDaire.Clear();
            txtBlok.Clear();
            txtAy.Clear();
            txtToplamTutar.Clear();
            hdnsktKod.Clear();
            hdnsiteKod.Clear();
            List<object> liste = new List<object>();
            kesintiStore.DataSource = liste;
            kesintiStore.DataBind();    
            GizleAc(false);
        }

        protected void GizleAc(bool gizli)
        {
            btnKaydet.Disabled = gizli;
            btnSil.Disabled = gizli;
            btnYeniSatir.Disabled = gizli;
            gridKesinti.Disabled = gizli;
        }

        protected void stoListe_ReadData(object sender, StoreRefreshDataEventArgs e)
        {
            //if (hdnIlk.Text == "0")
            //{
            //    e.Total = 0;
            //}
            //else
            //{
            //    e.Total = PersonelListele(e.Start, e.Limit);
            //}
            Listele();
        }

        protected void SiteDegisti(object sender, DirectEventArgs e)
        {
            BlokDoldur();
            ddlBlokAra.SelectedItem.Value = "";
        }

        protected void BlokDoldur()
        {
            if (OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0) == 0)
            {
                List<object> liste = new List<object>();
                blokStore.DataSource = liste;
                blokStore.DataBind();
            }
            else
                Genel.LojmanSiteBlokDoldur(kullanan, ddlBlokAra, blokStore, OrtakFonksiyonlar.ConvertToInt(ddlSiteAra.SelectedItem.Value, 0));
        }
    }
}
