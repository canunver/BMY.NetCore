﻿using System;
using System.Web.UI.WebControls;
using TNS.ORG;
using TNS.BKD;
using OrtakClass;
using TNS;
using System.Data;
using WebServisler.EvrakServis;
using TNS.IKY;
using System.Collections.Generic;
using Ext1.Net;
using System.Collections;

namespace InsanKaynaklari
{
    /// <summary>
    /// Görevlendirme sınıfı
    /// </summary>
    public partial class ListePersonelMaasParam : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        ObjectArray bordroTurler;
        static IntKodStrAd[] islecler = { new IntKodStrAd(0, "-"), new IntKodStrAd(1, "Eşit"), new IntKodStrAd(2, "Farklı"), new IntKodStrAd(3, "Büyük ="), new IntKodStrAd(4, "Küçük =") };
        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Sayfaya giriş izni varmı?
            formAdi = "Personel Maaş Bilgileri Toplu Düzenleme";
            SayfaUstAltBolumYaz(this);
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            PersonelTipi pt = new PersonelTipi();
            bordroTurler = servisIKY.ListelePersonelTip(kullanan, pt);
            bordroTurler.objeler.Insert(0, pt);

            if (!IsPostBack)
            {
                cmbMuhasebe.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "MUHASEBE");
                txtBirim.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "MUHASEBEBIRIM");
                stoBordroTurler.DataSource = bordroTurler.objeler;
                stoBordroTurler.DataBind();
                stoIslecler.DataSource = islecler;
                stoIslecler.DataBind();
                int kolSira = 5;
                Genel.UnvanDoldur(ddlUnvan, unvanStore);
                ArrayList al = new ArrayList();
                ArrayList alVeriAlanlar = new ArrayList();
                for (int i = 0; i < TNS.HRC.BordroGenelDegisken.bordroDegiskenler.Length; i++)
                {
                    TNS.HRC.BordroGenelDegisken bgd = TNS.HRC.BordroGenelDegisken.bordroDegiskenler[i];
                    if (bgd.degiskenTur == TNS.HRC.ENUMBordroDegiskenTur.KisiBordroBilgi)
                    {
                        if (bgd.veriTipi == VariableType.Money)
                            OrtakClass.ChartTool.GridNumberAlanEkle(grdListe, stoListe, bgd.degiskenAd, RecordFieldType.Float, bgd.aciklama, true, false, kolSira++, "0.000,000000/i", null, 90, null, true);
                        else
                            OrtakClass.ChartTool.GridStringAlanEkle(grdListe, stoListe, bgd.degiskenAd, bgd.aciklama, true, false, 120, null, null, true);
                        al.Add(bgd);
                        alVeriAlanlar.Add(new StrKodStrAd(bgd.degiskenAd, bgd.aciklama));
                        smDegiskenler.SelectedRows.Add(new SelectedRow(al.Count - 1));
                    }
                }
                al.Add(new TNS.HRC.BordroGenelDegisken("", TNS.HRC.ENUMBordroDegiskenTur.Elle, VariableType.String, "-"));
                stoDegiskenler.DataSource = al;
                stoDegiskenler.DataBind();
                stoVeri.DataSource = alVeriAlanlar;
                stoVeri.DataBind();
            }
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected void PersonelListele(object sender, DirectEventArgs e)
        {
            PersonelListeleIC(sender, e);
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "MUHASEBE", cmbMuhasebe_Text);
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "MUHASEBEBIRIM", txtBirim.Text);
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected void PersonelListeleIC(object sender, DirectEventArgs e)
        {
            try
            {
                TNS.IKY.Personel p = new TNS.IKY.Personel();
                p.kadro.muhasebeKodu = OrtakFonksiyonlar.ConvertToInt(cmbMuhasebe_Text, 0);
                p.kadro.muhasebeBirimi = txtBirim.Text;
                p.genelSorgu = txtSorgu.Text;
                p.kadro.unvan = OrtakFonksiyonlar.ConvertToInt(ddlUnvan.SelectedItem.Value, 0);
                p.aktifTarih = new TNSDateTime(DateTime.Now);
                p.personelTipleri = GenelIslemlerIstemci.MultiComboValue(cmbBordroTurler);
                p.aktifDurum = 1;
                p.maasParamlarOlsun = true;
                ObjectArray liste;
                if (!string.IsNullOrWhiteSpace(p.personelTipleri))
                    liste = servisIKY.PersonelListele(kullanan, p, false, false);
                else
                {
                    liste = new ObjectArray();
                    liste.sonuc.DegerAta("Listelemeden önce lütfen personel tipini seçiniz");
                }
                if (!liste.sonuc.islemSonuc)
                    throw new Exception(liste.sonuc.hataStr);
                PersonelleriGoster(liste.objeler);
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
            }
        }

        private void PersonelleriGoster(TNSCollection liste_objeler)
        {
            string alan1 = cmbAlan1.SelectedItem.Value;
            string alan2 = cmbAlan2.SelectedItem.Value;

            string islec1 = cmbIslec1.SelectedItem.Value;
            string islec2 = cmbIslec2.SelectedItem.Value;

            ArrayList al = new ArrayList();
            foreach (TNS.IKY.Personel per in liste_objeler)
            {
                TNS.IKY.PersonelMaasParam mp = per.personelMaasParam;
                if (GosterilsinMi(mp, alan1, islec1, deger1.Number) && GosterilsinMi(mp, alan2, islec2, deger2.Number))
                {
                    object[] a = new object[7 + per.personelMaasParam.paramlar.Count];
                    a[0] = per.tcKimlikNo;
                    a[1] = per.ad;
                    a[2] = per.soyad;
                    a[3] = per.kadro.unvan;
                    a[4] = per.kadro.unvanAd;
                    a[5] = per.kadro.kadroDerece;
                    a[6] = per.sicilNo;
                    if (mp != null)
                    {
                        for (int i = 0; i < mp.paramlar.Count; i++)
                        {
                            MaasParam mpIc = (MaasParam)mp.paramlar[i];
                            if (mpIc.tip == VariableType.Money)
                                a[7 + i] = mpIc.degerDbl;
                            else
                                a[7 + i] = mpIc.degerStr;
                        }
                    }
                    al.Add(a);
                }
            }
            stoListe.DataSource = al;
            stoListe.DataBind();
        }

        private bool GosterilsinMi(TNS.IKY.PersonelMaasParam mp, string alan, string islec, double deger)
        {
            if (string.IsNullOrWhiteSpace(alan)) return true;
            if (mp == null) return false;

            double veri = mp.ParamDegerBul(alan);

            if (islec == "0") return true; //-
            else if (islec == "1") //Eşit
            {
                return veri == deger;
            }
            else if (islec == "2") //Farklı
            {
                return veri != deger;
            }
            else if (islec == "3") //Büyük =
            {
                return veri >= deger;
            }
            else if (islec == "4") //Küçük =
            {
                return veri <= deger;
            }

            return true;
        }

        protected TNSCollection PersonelListeOl(string e, TNS.HRC.BordroGenelDegisken[] degiskenler)
        {
            Newtonsoft.Json.Linq.JObject[] paramlar = (Newtonsoft.Json.Linq.JObject[])Ext.Net.JSON.Deserialize(e, typeof(Newtonsoft.Json.Linq.JObject[]));
            TNSCollection kisiler = new TNSCollection();

            foreach (Newtonsoft.Json.Linq.JObject row in paramlar)
            {
                TNS.IKY.Personel per = new TNS.IKY.Personel();
                per.tcKimlikNo = row.Value<string>("tcKimlikNo");
                per.sicilNo = row.Value<string>("sicilNo");
                per.ad = row.Value<string>("ad");
                per.soyad = row.Value<string>("soyad");
                per.kadro.unvan = row.Value<int>("unvan");
                per.kadro.unvanAd = row.Value<string>("unvanAd");
                per.kadro.kadroDerece = row.Value<int>("kadroDereces");
                per.personelMaasParam = new TNS.IKY.PersonelMaasParam();
                per.personelMaasParam.paramlar = new TNSCollection();

                for (int i = 0; i < degiskenler.Length; i++)
                {
                    MaasParam mpIc = new MaasParam();
                    mpIc.degiskenAd = degiskenler[i].degiskenAd;
                    mpIc.tip = degiskenler[i].veriTipi;
                    if (degiskenler[i].veriTipi == VariableType.Money)
                        mpIc.degerDbl = row.Value<double>(degiskenler[i].degiskenAd);
                    else
                        mpIc.degerStr = row.Value<string>(degiskenler[i].degiskenAd);
                    per.personelMaasParam.paramlar.Add(mpIc);
                }
                kisiler.Add(per);
            }

            return kisiler;
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            TNS.HRC.BordroGenelDegisken[] degiskenler = (TNS.HRC.BordroGenelDegisken[])Ext.Net.JSON.Deserialize(e.ExtraParams["degiskenler"], typeof(TNS.HRC.BordroGenelDegisken[]));
            TNSCollection kisiler = PersonelListeOl(e.ExtraParams["param"], degiskenler);
            TNSCollection degiskenAdlar = new TNSCollection();
            for (int i = 0; i < degiskenler.Length; i++)
            {
                degiskenAdlar.Add(degiskenler[i].degiskenAd);
            }
            TNS.Sonuc s = servisIKY.MaasParamKaydet(kullanan, kisiler, degiskenAdlar);
            if (s.islemSonuc)
            {
                GenelIslemler.MesajKutusu("Sonuç", "Kayıt başarılı");
                stoListe.CommitChanges();
            }
            else
                GenelIslemler.MesajKutusu("Hata", s.hataStr);
        }

        private string cmbMuhasebe_Text
        {
            get
            {
                if (string.IsNullOrWhiteSpace(cmbMuhasebe.Text)) return "";
                string[] tut = cmbMuhasebe.Text.Split('-');
                return tut[0];
            }
        }

        protected void fuDosya_Selected(object sender, DirectEventArgs e)
        {
            string veriAlan = cmbVeri.SelectedItem.Value;
            if (string.IsNullOrWhiteSpace(veriAlan))
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen Veri Alanını Seçiniz");
                return;
            }
            List<TNS.HRC.BordroGenelDegisken> degiskenler = new List<TNS.HRC.BordroGenelDegisken>();
            TNS.HRC.BordroGenelDegisken df = null;

            int alanYer = -1;
            for (int i = 0; i < TNS.HRC.BordroGenelDegisken.bordroDegiskenler.Length; i++)
            {
                TNS.HRC.BordroGenelDegisken bgd = TNS.HRC.BordroGenelDegisken.bordroDegiskenler[i];
                if (bgd.degiskenTur == TNS.HRC.ENUMBordroDegiskenTur.KisiBordroBilgi)
                {
                    degiskenler.Add(bgd);
                    if (bgd.degiskenAd == veriAlan)
                    {
                        df = bgd;
                        alanYer = degiskenler.Count - 1;
                    }
                }
            }
            if (df == null)
            {
                GenelIslemler.MesajKutusu("Hata", "Veri alanı bulunamadı!");
                return;
            }

            TNSCollection kisiler = PersonelListeOl(e.ExtraParams["param"], degiskenler.ToArray());
            Tablo XLS = GenelIslemler.NewTablo();
            if (!fuDosya.HasFile)
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen Dosya Seçiniz");
                return;
            }
            int anahAlan = OrtakFonksiyonlar.ConvertToInt(cmbAnahtar.SelectedItem.Value, 0);
            if (anahAlan < 1 || anahAlan > 2)
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen Anahtar Alanı Seçiniz");
                return;
            }

            XLS.DosyaOkuAc(fuDosya.FileContent);

            int sat = 0;
            while (true)
            {
                string anah = XLS.HucreDegerAl(sat, 0);
                string veriS = XLS.HucreDegerAl(sat, 1);
                double veriD = XLS.HucreDegerAlDbl(sat, 1);
                if (string.IsNullOrWhiteSpace(anah)) break;
                TNS.IKY.Personel ilkSatir = SatirBul(kisiler, anahAlan, anah);
                if (ilkSatir != null)
                {
                    MaasParam mpIc = (MaasParam)ilkSatir.personelMaasParam.paramlar[alanYer];
                    if (df.veriTipi == VariableType.Money)
                        mpIc.degerDbl = veriD;
                    else
                        mpIc.degerStr = veriS;
                }
                sat++;
            }
            PersonelleriGoster(kisiler);
            fuDosya.Reset();
            fuDosya.Clear();
            X.AddScript("DegistiIsaretiKoy();");
        }

        private TNS.IKY.Personel SatirBul(TNSCollection kisiler, int kol, string anah)
        {
            foreach (TNS.IKY.Personel item in kisiler)
            {
                if (item.TCKIMLIKNO == anah && kol == 1 || item.sicilNo == anah && kol == 2)
                    return item;
            }
            return null;
        }
    }
}
