﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Services;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.HRC;
using TNS.IKY;
using TNS.KYM;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Mal Bildirimi Sınıfı
    /// </summary>
    public partial class PersonelMalBildirimi : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public int personelKod = 0;

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            personelKod = GenelIslemlerIstemci.RequestBul(this, "personelKod", 0);

            if (!IsPostBack)
            {
                Temizle();
                Listele();
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel Mal Bildirimi bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel Mal Bildirimi tipinde sınıf</param>
        public void Listele()
        {
            //ObjectArray pler = servisIKY.PersonelMalBildirimiListele(kullanan, new TNS.IKY.PersonelMalBildirimi() { personelKod = personelKod });

            //if (!pler.sonuc.islemSonuc)
            //{
            //    GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
            //    return;
            //}

            //List<object> liste = new List<object>();
            //foreach (TNS.IKY.PersonelMalBildirimi d in pler.objeler)
            //    liste.Add(new
            //    {
            //        SIRANO = d.sirano,
            //        TARIH = d.tarih.Oku(),
            //        ACIKLAMA = d.aciklama,
            //    });

            //ListeStore.DataSource = liste;
            //ListeStore.DataBind();
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Mal Bildirimi bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            //if (txtTarih.IsEmpty)
            //    hata += Resources.InsanKaynaklari.FRMPMB010 + "<br>";
            //if (txtAciklama.Text.Trim() == "")
            //    hata += Resources.InsanKaynaklari.FRMPMB011 + "<br>";

            //if (hata != "")
            //{
            //    GenelIslemler.MesajKutusu(this, hata);
            //    return;
            //}

            //TNS.IKY.PersonelMalBildirimi d = new TNS.IKY.PersonelMalBildirimi();
            //d.personelKod = personelKod;
            //d.sirano = OrtakFonksiyonlar.ConvertToInt(hdnSiraNo.Value, 0);
            //d.tarih = Genel.TarihAlaniDegerVer(txtTarih);
            //d.aciklama = txtAciklama.Text;

            //Sonuc sonuc = servisIKY.PersonelMalBildirimiKaydet(kullanan, d);

            //if (!sonuc.islemSonuc)
            //    GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            //else
            //{
            //    Temizle();
            //    Listele();
            //    GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPMB012);
            //}
        }

        /// <summary>
        /// Sil düğmesine basınca, koda, T.C. Kimlik numarasına göre Personel Mal Bildirimi bilgisi silen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            //int kod = OrtakFonksiyonlar.ConvertToInt(hdnSiraNo.Value, 0);
            //if (kod <= 0)
            //{
            //    GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPMB014);
            //    return;
            //}

            //TNS.IKY.PersonelMalBildirimi d = new TNS.IKY.PersonelMalBildirimi();
            //d.kod = kod;
            //Sonuc sonuc = servisIKY.PersonelMalBildirimiSil(kullanan, d);

            //if (!sonuc.islemSonuc)
            //    GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            //else
            //{
            //    Temizle();
            //    Listele();
            //    GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPMB013);
            //}
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            //Temizle();
            //grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            //string secilisatir = e.ExtraParams["RowValue"].ToString();
            //XmlNode xml = JSON.DeserializeXmlNode("{records:{record:" + secilisatir + "}}");
            //foreach (XmlNode row in xml.SelectNodes("records/record"))
            //{
            //    hdnSiraNo.Value = row.SelectSingleNode("SIRANO").InnerXml;
            //    txtTarih.Value = row.SelectSingleNode("TARIH").InnerXml;
            //    txtAciklama.Value = row.SelectSingleNode("ACIKLAMA").InnerXml;
            //}
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        void Temizle()
        {
            //hdnSiraNo.Text = "";
            //txtTarih.Text = "";
            //txtAciklama.Text = "";
        }

        [WebMethod(EnableSession = true)]
        public static Sonuc KaydetMealBildirimi(TNS.IKY.PersonelMalBildirimi malBildirimi)
        {
            Kullanici kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            IIKYServis servis = TNS.IKY.Arac.Tanimla();
            return servis.PersonelMalBildirimiKaydet(kullanan, malBildirimi);
        }

        [WebMethod(EnableSession = true)]
        public static ObjectArray ListeleMalBildirimi(int pKod)
        {
            Kullanici kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            IIKYServis servis = TNS.IKY.Arac.Tanimla();
            return servis.PersonelMalBildirimiListele(kullanan, new TNS.IKY.PersonelMalBildirimi() { personelKod = pKod });
        }

        [WebMethod(EnableSession = true)]
        public static ObjectVAN OkuMalBildirimi(int kod)
        {
            Kullanici kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            IIKYServis servis = TNS.IKY.Arac.Tanimla();
            return servis.PersonelMalBildirimiOku(kullanan, kod);
        }
    }
}
