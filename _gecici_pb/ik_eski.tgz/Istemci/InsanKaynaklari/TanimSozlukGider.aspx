﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.TanimSozlukGider" CodeBehind="TanimSozlukGider.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>
        Süzlük Gider Tanim</title>
    <script type="text/javascript" language="javascript">
        function SatirDegisti() {
            if (smListe.hasSelection())
                Ext1.net.DirectMethods.Goster(smListe.getSelected().data.kod);
        }  
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager runat="server">
    </ext:ResourceManager>
  
    <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout" Margins="104 20 10 20">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnYeni" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                TabIndex="18" Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnYeni_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite037%>"
                                TabIndex="17" Icon="DatabaseSave">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click">
                                        <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, LojmanSite038%>"
                                            Message="<%$ Resources:InsanKaynaklari, LojmanSite039%>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, LojmanSite040%>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="Sil" Icon="TableDelete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:GridPanel ID="grdListe" Width="600" Collapsed="false" AutoScroll="true"
                        Region="West" Split="true" Layout="BorderLayout" runat="server">
                        <Store>
                            <ext:Store runat="server" ID="stoListe">
                                <Reader>
                                    <ext:JsonReader>
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="ad" Type="String" />
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <ColumnModel>
                            <Columns>
                                <ext:Column DataIndex="kod" ColumnID="kod" Header="Kod" Width="50px" />
                                <ext:Column DataIndex="ad" ColumnID="ad" Header="Gider Adı" Width="200px" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel runat="server" ID="smListe">
                                <Listeners>
                                    <SelectionChange Fn="SatirDegisti" />
                                </Listeners>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                    </ext:GridPanel>
                    <ext:FormPanel runat="server" Border="false" Region="Center" Layout="RowLayout" Padding="5"
                        ButtonAlign="Center" AutoScroll="true" LabelWidth="160">
                        <Items>
                            <ext:TextField runat="server" Hidden="true" ID="txtKod" TabIndex="1" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite005%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite006%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>                           
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtAd" TabIndex="3"
                                FieldLabel="Gider Adi">
                                <ToolTips>
                                    <ext:ToolTip Html="Gider Adi" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>   
                            <ext:Checkbox runat="server" ID="chkEldenGor" BoxLabel="Elden Görünsün Mü?"></ext:Checkbox>    
                            <ext:Checkbox runat="server" ID="chkEndexGor" BoxLabel="Endex Görünsün Mü?"></ext:Checkbox>
                            <ext:Checkbox runat="server" ID="chkAciklamaGor" BoxLabel="Açıklama Görünsün Mü?"></ext:Checkbox>                    
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
