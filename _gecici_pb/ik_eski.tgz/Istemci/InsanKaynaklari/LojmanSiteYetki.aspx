﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="LojmanSiteYetki.aspx.cs"
    Inherits="InsanKaynaklari.LojmanSiteYetki" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Personel Bilgi</title>
    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
    <script type="text/javascript">
        var OrgBirimDoldur = function (node) {
            var orgBirim = { ozellikAra: false, yetkiliOlduguMuhasebeBirim: hdnYetkiliBirim.value };
            nodeLoadOrgBirimParam(node, orgBirim);
        };
        var birimRenderer = function (value) {
            if (hdnBirimKod.value == value)
                return hdnBirimAd.value;
            else
                return "";
        };
        var unvanRenderer = function (value) {
            var r = storeUnvan.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.UnvanAd;
        };
        var yetkiTipRenderer = function (value) {
            var r = yetkiTipStore.getById(value);
            if (Ext1.isEmpty(r))
                return "";
            return r.data.AD;
        };
        function YetkiListele(siteKod) {
            Ext1.net.DirectMethods.YetkiListele(siteKod);
        } 
    </script>
</head>
<body>
    <form id="Form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnYetkiliBirim" runat="server" />
    <ext:Hidden ID="hdnBirimKod" runat="server" />
    <ext:Hidden ID="hdnBirimAd" runat="server" />
    <ext:Hidden ID="hdnSiteKod" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:ArrayReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="ADSOYAD" />
                    <ext:RecordField Name="TCKIMLIKNO" />
                    <ext:RecordField Name="SICILNO" />
                    <ext:RecordField Name="BIRIM" />
                    <ext:RecordField Name="UNVAN" />
                    <ext:RecordField Name="KADRODERECE" />
                    <ext:RecordField Name="KADROTARIHI" />
                    <ext:RecordField Name="KADRODURUMU" />
                    <ext:RecordField Name="PERSONELTUR" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeUnvan">
        <Reader>
            <ext:JsonReader IDProperty="UnvanKod">
                <Fields>
                    <ext:RecordField Name="UnvanKod" />
                    <ext:RecordField Name="UnvanAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="yetkiTipStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="yetkiListeStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="pkod">
                <Fields>
                    <ext:RecordField Name="pkod" Type="Int" />
                    <ext:RecordField Name="yetkiliOlduguSiteKod" Type="Int" />
                    <ext:RecordField Name="yetkiliOlduguSiteAd" Type="String" />
                    <ext:RecordField Name="aktif" Type="Int" />
                    <ext:RecordField Name="tip" Type="Int" />
                    <ext:RecordField Name="personelAd" Type="String" />
                    <ext:RecordField Name="oturduguSite" Type="String" />
                    <ext:RecordField Name="oturduguBlok" Type="String" />
                    <ext:RecordField Name="oturduguDaire" Type="Int" />
                    <ext:RecordField Name="oturduguPLKod" Type="Int" />
                    <ext:RecordField Name="aktifText" Type="String" />
                    <ext:RecordField Name="tipAd" Type="String" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Listeners>
            <BeforeHide Handler="alert('deneme');" />
        </Listeners>
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center>
                    <ext:Panel ID="pnlSol" runat="server" Title="<%$Resources:InsanKaynaklari,FRMPAB035%>"
                        Width="230" Collapsed="false" AutoScroll="true">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server">
                                <Items>
                                    <ext:ToolbarFill ID="ToolbarFill1" runat="server" />
                                    <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPBI003%>"
                                        Icon="ApplicationGo">
                                        <DirectEvents>
                                            <Click OnEvent="YetkiListesi">
                                                <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="solTaraf" runat="server">
                                <North Split="true">
                                    <ext:FormPanel ID="FormPanel1" runat="server" Height="90" LabelWidth="50" Layout="AnchorLayout"
                                        Frame="false" Header="false" Border="false" Padding="5">
                                        <Items>
                                            <ext:TextField runat="server" ID="txtGenelSorgu" FieldLabel="Arama" AnchorHorizontal="97%"
                                                TabIndex="1" />
                                            <ext:DropDownField ID="ddlBirim" runat="server" Editable="false" TriggerIcon="Ellipsis"
                                                Mode="ValueText" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>" AnchorHorizontal="97%">
                                                <Triggers>
                                                    <ext:FieldTrigger Icon="Clear" />
                                                </Triggers>
                                                <Listeners>
                                                    <TriggerClick Handler="if (index == 0) { this.clearValue(); }" />
                                                </Listeners>
                                                <Component>
                                                    <ext:Panel ID="Panel5" runat="server" Width="400">
                                                        <Items>
                                                            <ext:TreePanel ID="trpBirim" runat="server" Height="250" AutoWidth="true" AutoScroll="true"
                                                                Border="false" RootVisible="false">
                                                                <Root>
                                                                    <ext:AsyncTreeNode NodeID="0" Expanded="true" Icon="Note" />
                                                                </Root>
                                                                <Listeners>
                                                                    <Click Handler="#{ddlBirim}.setValue(node.id, node.text, false);#{hdnBirimKod}.setValue(node.id);#{hdnBirimAd}.setValue(node.text); #{ddlBirim}.collapse();" />
                                                                </Listeners>
                                                            </ext:TreePanel>
                                                        </Items>
                                                    </ext:Panel>
                                                </Component>
                                            </ext:DropDownField>
                                            <ext:ComboBox ID="cmbUnvan" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                ForceSelection="true" StoreID="storeUnvan" DisplayField="UnvanAd" ValueField="UnvanKod"
                                                AnchorHorizontal="97%" FieldLabel="Unvan" />
                                        </Items>
                                    </ext:FormPanel>
                                </North>
                                <Center>
                                    <ext:Panel ID="Panel1" runat="server" Border="false">
                                        <Items>
                                            <ext:GridPanel ID="grdYetkiListe" runat="server" StoreID="yetkiListeStore" Height="620"
                                                Title="Personel Listesi" AutoScroll="true">
                                                <ColumnModel>
                                                    <Columns>
                                                        <ext:Column ColumnID="kod" DataIndex="kod" Header="Kod" Hidden="true">
                                                        </ext:Column>
                                                        <ext:Column ColumnID="personelAd" DataIndex="personelAd" Header="Personel Adı" Width="175">
                                                        </ext:Column>
                                                        <ext:Column ColumnID="oturduguSite" DataIndex="oturduguSite" Header="Oturduğu Site">
                                                        </ext:Column>
                                                        <ext:Column ColumnID="oturduguBlok" DataIndex="oturduguBlok" Header="Oturduğu Blok">
                                                        </ext:Column>
                                                        <ext:Column ColumnID="oturduguDaire" DataIndex="oturduguDaire" Header="Oturduğu Daire">
                                                        </ext:Column>
                                                        <ext:Column ColumnID="tip" DataIndex="tip" Header="Yetki Tipi" Width="200">
                                                            <Renderer Fn="yetkiTipRenderer" />
                                                            <Editor>
                                                                <ext:ComboBox runat="server" ID="ddlYetkiTip" DisplayField="AD" ValueField="KOD"
                                                                    StoreID="yetkiTipStore" Mode="Local" TriggerAction="All" Resizable="true" ListWidth="200">
                                                                </ext:ComboBox>
                                                            </Editor>
                                                        </ext:Column>
                                                    </Columns>
                                                </ColumnModel>
                                                <SelectionModel>
                                                    <ext:CheckboxSelectionModel runat="server" CheckOnly="true" ID="smDegiskenler">
                                                    </ext:CheckboxSelectionModel>
                                                </SelectionModel>
                                                <TopBar>
                                                    <ext:Toolbar ID="Toolbar3" runat="server">
                                                        <Items>
                                                            <ext:Button ID="Button1" runat="server" Text="Ekle" Icon="Add">
                                                                <DirectEvents>
                                                                    <Click OnEvent="btnYetkiKaydet_Click">
                                                                        <ExtraParams>
                                                                            <ext:Parameter Name="YetkiListeBilgileri" Value="Ext1.util.JSON.encode(#{grdYetkiListe}.getRowsValues({selectedOnly: true}))"
                                                                                Mode="Raw" />
                                                                        </ExtraParams>
                                                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                                            Title="Onay" />
                                                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                                                    </Click>
                                                                </DirectEvents>
                                                            </ext:Button>
                                                        </Items>
                                                    </ext:Toolbar>
                                                </TopBar>
                                            </ext:GridPanel>
                                        </Items>
                                    </ext:Panel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
