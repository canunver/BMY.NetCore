﻿using System;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Mal Bildirimi Sınıfı
    /// </summary>
    public partial class PersonelNitelik : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public string personelTCKimlikNo = "";

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    //btnTemizle.Hidden = true;
            //    //btnSil.Hidden = true;
            //}
            if (string.IsNullOrEmpty(personelTCKimlikNo))
                GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                Temizle();
                Listele();
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel Mal Bildirimi bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel Mal Bildirimi tipinde sınıf</param>
        public void Listele()
        {
            if (string.IsNullOrEmpty(personelTCKimlikNo))
                return; 
            
            TNS.IKY.PersonelBilgiBirikimi kriter = new TNS.IKY.PersonelBilgiBirikimi();
            kriter.tcKimlikNo = personelTCKimlikNo;
            ObjectArray pler = servisIKY.PersonelBilgiBirikimiListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }
            kriter = (TNS.IKY.PersonelBilgiBirikimi)pler[0];
            txtGorev.Text = kriter.gorev;
            txtBilgi.Text = kriter.bilgi;
            txtBeceri.Text = kriter.beceri;
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Mal Bildirimi bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            TNS.IKY.PersonelBilgiBirikimi d = new TNS.IKY.PersonelBilgiBirikimi();

            d.tcKimlikNo = personelTCKimlikNo;
            d.gorev = txtGorev.Text;
            d.bilgi = txtBilgi.Text;
            d.beceri = txtBeceri.Text;

            Sonuc sonuc = servisIKY.PersonelBilgiBirikimiKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele();
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPMB012);
            }
        }

        ///// <summary>
        ///// Sil düğmesine basınca, koda, T.C. Kimlik numarasına göre Personel Mal Bildirimi bilgisi silen fonksiyon
        ///// </summary>
        ///// <param name="sender">Çağıran, object tipinde sınıf</param>
        ///// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        //protected void btnSil_Click(object sender, DirectEventArgs e)
        //{
        //    //int siraNo = OrtakFonksiyonlar.ConvertToInt(hdnSiraNo.Value, 0);
        //    //if (string.IsNullOrEmpty(personelTCKimlikNo) || siraNo <= 0)
        //    //{
        //    //    GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPMB014);
        //    //    return;
        //    //}

        //    //TNS.IKY.PersonelMalBildirimi d = new TNS.IKY.PersonelMalBildirimi();
        //    //d.tcKimlikNo = personelTCKimlikNo;
        //    //d.sirano = siraNo;
        //    //Sonuc sonuc = servisIKY.PersonelMalBildirimiSil(kullanan, d);

        //    //if (!sonuc.islemSonuc)
        //    //    GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        //    //else
        //    //{
        //    //    Temizle();
        //    //    Listele(new TNS.IKY.PersonelMalBildirimi());
        //    //    GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPMB013);
        //    //}
        //}

        ///// <summary>
        ///// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        ///// </summary>
        ///// <param name="sender">Çağıran, object tipinde sınıf</param>
        ///// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        //protected void btnTemizle_Click(object sender, DirectEventArgs e)
        //{
        //    Temizle();
        //}


        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        void Temizle()
        {
            txtBeceri.Text = "";
            txtBilgi.Text = "";
            txtGorev.Text = "";
        }
    }
}
