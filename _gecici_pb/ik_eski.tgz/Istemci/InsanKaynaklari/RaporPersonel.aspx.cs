﻿using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.BKD;
using TNS.UZY;
using TNS.ORG;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Xml;
using Aspose.Words;
using System.Data;
using TNS.KYM;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Kişisel Sınıfı
    /// </summary>
    public partial class RaporPersonel : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        IBKDServis servisBKD = TNS.BKD.Arac.Tanimla();

        /// <summary>
        /// Sayfa yüklenirken, Kullanıcı bilgisi session'dan alınır. Yetki kontrolü yapılır. Sayfa çerçevesi oluşturulur. 
        /// Sayfa ilk yüklendiğinde sayfa ile gelen parametreler ile listeleme işlemi yapılır.
        /// </summary>
        /// <param name="sender">Olayı çağıran sınıf</param>
        /// <param name="e">Olay parametresi</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && !X.IsAjaxRequest)
            {
                formAdi = "Raporlar";
                SayfaUstAltBolumYaz(this);
                ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

                //Sayfaya giriş izni varmı?
                GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

                int indir = GenelIslemlerIstemci.RequestBul(this, "indir", 0);
                if (indir == 1)
                {
                    RaporGonder();
                    return;
                }
                cmpCokluSecim.ListeDoldur(Genel.IzinTipDondur(false));
                ddlBirim.KullanicininBirimleri = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");

                Genel.PersonelTipGrupDoldur(ddlPersonelTipGrup, stoPersonelTipGrup);
                if (((TNSCollection)stoPersonelTipGrup.DataSource).Count > 0)
                {
                    //ddlPersonelTipGrup.SelectedItems.Add(new SelectedListItem(0));
                }
                X.AddScript("PersonelTipYenile();");
                Genel.KadroDereceDoldur(storeKadroDerece);
                Genel.LojmanSiteDoldur(kullanan, ddlSite, siteStore);
                siteStore.InsertRecord(0, new { kod = -1, siteAdi = "Tümü" });
                spnYilAra.Number = DateTime.Now.Year;
                Genel.AyDoldur(ddlAyAra, ayStore, true);
                ddlAyAra.SelectedItem.Value = DateTime.Now.Month.ToString();
                if (ddlYerleske.Hidden)
                    Genel.YemekhaneDoldur(ddlYerleske, null, yerleskeStore, kullanan);
                dfTarihSorgu.SelectedDate = DateTime.Now.Date;
            }
        }

        [DirectMethod]
        public void PersonelTipleriYenile()
        {
            ddlPersonelTipGrup_Changed(null, null);
        }

        protected void ddlPersonelTipGrup_Changed(object sender, DirectEventArgs e)
        {
            cmbPersonelTipCoklu.ListeDoldur(Genel.PersonelTurDondur(TipGruplariBul()));
        }

        private string[] TipGruplariBul()
        {
            string[] tipGruplar = new string[ddlPersonelTipGrup.SelectedItems.Count];
            for (int i = 0; i < ddlPersonelTipGrup.SelectedItems.Count; i++)
            {
                tipGruplar[i] = ddlPersonelTipGrup.SelectedItems[i].Text;
            }
            return tipGruplar;
        }

        public enum ENUMRaporTur
        {
            //Crystal,
            Metot,
        }

        public class RaporGrubu
        {
            public RaporGrubu() { }
            public string KOD { get; set; }
            public string AD { get; set; }
            public string ATAKOD { get; set; }
            public int pZorunlu { get; set; }

            public RaporGrubu(string KOD, string AD, string ATAKOD, int pZorunlu)
            {
                this.KOD = KOD;
                this.AD = AD;
                this.ATAKOD = ATAKOD;
                this.pZorunlu = pZorunlu;
            }
        }

        public static RaporGrubu[] raporGrubu = {
             new RaporGrubu("GR002", "Birim Raporları", null,0),
             new RaporGrubu("GR003", "Kişisel Raporlar", null,1),
             new RaporGrubu("GR004", "Kadro Raporları", null,0),
             new RaporGrubu("GR005", "İzin Raporları", null,1),
             new RaporGrubu("GR006", "Hizmet Raporları", null,1),
             //new RaporGrubu("GR007", "Terfi Raporları", null),
             new RaporGrubu("GR008", "Unvan Raporları", null,0),
             //new RaporGrubu("GR009", "Dinamik Rapor Listesi", null),
             new RaporGrubu("GR010", "İstatistiki Raporlar", null,0),
             new RaporGrubu("GR011", "Kart Raporları", null,0),
             new RaporGrubu("GR012", "Lojman Raporları", null,0),
             new RaporGrubu("GR013", "Site Yönetim Raporları", null,0),
             new RaporGrubu("GR014", "Yemek Raporları", null,0),
        };

        public class RaporAlanTanim
        {
            public bool cmpBirim = true;
            public bool cmpKadroDerece = false;
            public bool cmpIslemSira = false;
            public bool cmpCiktiTur = false;
            public bool cmpPersonelTurCoklu = true;
            public bool cmpCiktiTurDoc = false;
            public bool cmpYukumlu = false;
            public bool cmpKisiArama = true;
            public bool cmpSonTarih = false;
            public bool cmpDinamik = false;
            public string siralamaListe = null;
            public bool cmpAktiflik = true;
            public bool cmpSiteKod = false;
            public bool cmpDaireBosluk = false;
            public bool cmpYil = false;
            public bool cmpAy = false;
            public bool cmpYilArasi = false;
            public bool cmpYemekhane = false;
            public bool cmpKisiAramaGrid = false;
            public bool tarihSorgu = false;
            public bool izinTur = false;
        }

        public class RaporTanim
        {
            public RaporTanim() { }
            public string KOD { get; set; }
            public string AD { get; set; }
            public string DOSYAAD { get; set; }
            public ENUMRaporTur raporTur { get; set; }
            public string raporGrubu { get; set; }
            public int raporDosyasiNo { get; set; }

            public bool cmpBirim { get; set; }
            public bool cmpKadroDerece { get; set; }
            public bool cmpIslemSira { get; set; }
            public bool cmpCiktiTur { get; set; }
            public bool cmpCiktiTurDoc { get; set; }
            public bool cmpPersonelTurCoklu { get; set; }
            public bool cmpYukumlu { get; set; }
            public bool cmpSonTarih { get; set; }
            public bool cmpKisiArama { get; set; }
            public bool cmpDinamik { get; set; }
            public bool cmpAktiflik { get; set; }
            public bool cmpSiteKod { get; set; }
            public bool cmpDaireBosluk { get; set; }
            public bool cmpYil { get; set; }
            public bool cmpAy { get; set; }
            public bool cmpYilArasi { get; set; }
            public bool cmpYemekhane { get; set; }
            public string siralamaListe { get; set; }
            public bool cmpKisiAramaGrid { get; set; }
            public bool tarihSorgu { get; set; }
            public bool izinTur { get; set; }

            public RaporTanim(string KOD, string AD, string DOSYAAD, ENUMRaporTur raporTur,
                              bool cmpBirim, bool cmpKadroDerece, bool cmpIslemSira, bool kullanma3,
                              bool cmpCiktiTur, bool cmpPersonelTurCoklu, bool cmpCiktiTurDoc,
                              bool cmpYukumlu, bool kullanma1, bool cmpKisiArama, bool kullanma2, bool cmpSonTarih,
                              int raporDosyasiNo, bool cmpDinamik, string raporGrubu, string siralamaListe, bool cmpAktiflik, bool cmpSiteKod,
                              bool cmpDaireBosluk, bool cmpYil, bool cmpAy, bool cmpYilArasi, bool cmpYemekhane, bool cmpKisiAramaGrid, bool tarihSorgu, bool izinTur)
            {
                this.KOD = KOD;
                this.AD = AD;
                this.DOSYAAD = DOSYAAD;
                this.raporTur = raporTur;
                this.raporGrubu = raporGrubu;
                this.raporDosyasiNo = raporDosyasiNo;

                this.cmpBirim = cmpBirim;
                this.cmpKadroDerece = cmpKadroDerece;
                this.cmpIslemSira = cmpIslemSira;
                this.cmpCiktiTur = cmpCiktiTur;
                this.cmpPersonelTurCoklu = cmpPersonelTurCoklu;
                this.cmpCiktiTurDoc = cmpCiktiTurDoc;
                this.cmpYukumlu = cmpYukumlu;
                this.cmpKisiArama = cmpKisiArama;
                this.cmpSonTarih = cmpSonTarih;
                this.cmpDinamik = cmpDinamik;
                this.siralamaListe = siralamaListe;
                this.cmpAktiflik = cmpAktiflik;
                this.cmpSiteKod = cmpSiteKod;
                this.cmpDaireBosluk = cmpDaireBosluk;
                this.cmpYil = cmpYil;
                this.cmpAy = cmpAy;
                this.cmpYilArasi = cmpYilArasi;
                this.cmpYemekhane = cmpYemekhane;
                this.cmpKisiAramaGrid = cmpKisiAramaGrid;
                this.tarihSorgu = tarihSorgu;
                this.izinTur = izinTur;
            }

            public RaporTanim(string KOD, string AD, string DOSYAAD, ENUMRaporTur raporTur, string raporGrubu, int raporDosyasiNo, RaporAlanTanim rat)
            {
                this.KOD = KOD;
                this.AD = AD;
                this.DOSYAAD = DOSYAAD;
                this.raporTur = raporTur;
                this.raporGrubu = raporGrubu;
                this.raporDosyasiNo = raporDosyasiNo;

                this.cmpBirim = rat.cmpBirim;
                this.cmpKadroDerece = rat.cmpKadroDerece;
                this.cmpIslemSira = rat.cmpIslemSira;
                this.cmpCiktiTur = rat.cmpCiktiTur;
                this.cmpPersonelTurCoklu = rat.cmpPersonelTurCoklu;
                this.cmpCiktiTurDoc = rat.cmpCiktiTurDoc;
                this.cmpYukumlu = rat.cmpYukumlu;
                this.cmpKisiArama = rat.cmpKisiArama;
                this.cmpSonTarih = rat.cmpSonTarih;
                this.cmpDinamik = rat.cmpDinamik;
                this.siralamaListe = rat.siralamaListe;
                this.cmpAktiflik = rat.cmpAktiflik;
                this.cmpSiteKod = rat.cmpSiteKod;
                this.cmpDaireBosluk = rat.cmpDaireBosluk;
                this.cmpYil = rat.cmpYil;
                this.cmpAy = rat.cmpAy;
                this.cmpYilArasi = rat.cmpYilArasi;
                this.cmpYemekhane = rat.cmpYemekhane;
                this.cmpKisiAramaGrid = rat.cmpKisiAramaGrid;
                this.tarihSorgu = rat.tarihSorgu;
                this.izinTur = rat.izinTur;
            }
        }
        public static string sira = "Öncelik Derecesine Göre,Unvana Göre,Birime Göre,İsme Göre";

        public static RaporTanim[] raporTanimlar = {
             new RaporTanim("IK009", "Dolu-Boş Kadro Listesi",            "PersonelKadroKontenjanMemur.xlt",       ENUMRaporTur.Metot,   true, false, false, true, true, false, false, false, false, false, false, false, 0, false, "GR004", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK012", "Organizasyon Şeması",               "OrganizasyonPersonel.xltx",             ENUMRaporTur.Metot,   false, false, false, false, true, true, false, false , false, false, false, false, 0, false, "GR002", null,false,false,false,false,false,false,false, false, false, false),

             new RaporTanim("IK013", "İsimli Kadro Listesi",              "IsimliKadroListesi.xltx",               ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR004", "Unvana Göre,Birime Göre,İsme Göre",false,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK014", "İsimsiz Kadro Listesi",             "IsimsizKadroListesi.xltx",              ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR004", null,false,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK015", "Kadro Derece Durum Listesi",        "KadroDereceDurumListesi.xltx",          ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR004", "Unvana Göre,Birime Göre,İsme Göre",false,false,false,false,false,false,false, true, false, false),

             new RaporTanim("IK016", "Aile Listesi",                      "AileListesi.xltx",                      ENUMRaporTur.Metot,   true, false, false, false, false, true, false, true , false, true, false, false, 0, false, "GR003", null,true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK017", "Öğrenim Durum Listesi",             "OgrenimDurumListesi.xltx",              ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR003", null,true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK021", "İzin/Görevlendirme (Herkes)",       "IzinListesi.xltx",                      ENUMRaporTur.Metot,   "GR005", 0, new RaporAlanTanim{izinTur=true, siralamaListe="Unvana Göre,Birime Göre,İsme Göre"}),
             new RaporTanim("IK021b","İzin/Görevlendirme (Kullanan)",     "IzinListesi2.xltx",                     ENUMRaporTur.Metot,   "GR005", 0, new RaporAlanTanim{izinTur=true, siralamaListe="Unvana Göre,Birime Göre,İsme Göre"}),
             new RaporTanim("IK021a","İdari Görev Bilgileri",             "IdariGorevListesi.xltx",                ENUMRaporTur.Metot,   "GR005", 0, new RaporAlanTanim{cmpSonTarih=true}),
             new RaporTanim("IK022", "Öğrenim Genel Durumu Dağılımı",     "IKYIstatistik.xltx",                    ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK023", "Cinsiyete Göre Dağılım",            "IKYIstatistik.xltx",                    ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK024", "Personel Türlerine Göre Dağılım",   "IKYIstatistik.xltx",                    ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK025", "Yaş Genel Durum Dağılımı",          "IKYIstatistik.xltx",                    ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK026", "Dil Durumuna Göre Dağılım",         "IKYIstatistik.xltx",                    ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK027", "Kıdem Yılına Göre Personel Dağılımı", "IKYIstatistik.xltx",                  ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK028", "Personel Kart Listesi",             "KartListesi.xltx",                      ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR011", null,false,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK029", "Teslim Edilmeyen Kart Listesi",     "KartListesi.xltx",                      ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR011", null,false,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK030", "Kayıp Kart Listesi",                "KartListesi.xltx",                      ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR011", null,false,false,false,false,false,false,false, true, false, false),

             new RaporTanim("IK031", "Kurum Hizmeti Listesi",             "HizmetBelgesiListesi.xltx",             ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, true, true, 0, false, "GR006",  "Unvana Göre,Birime Göre,İsme Göre,Süreye Göre",true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK032", "Kıdem Hizmeti Listesi",             "HizmetBelgesiListesi.xltx",             ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, true, 0, false, "GR006", "Unvana Göre,Birime Göre,İsme Göre,Süreye Göre",true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK033", "Emekli Keseneği Hizmet Belgesi Listesi", "HizmetBelgesiListesi.xltx",        ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, true, 0, false, "GR006", "Unvana Göre,Birime Göre,İsme Göre,Süreye Göre",true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK034", "İzin Hizmet Belgesi Listesi",       "HizmetBelgesiListesi.xltx",             ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, true, 0, false, "GR006", "Unvana Göre,Birime Göre,İsme Göre,Süreye Göre",true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK035", "Toplam Hizmet Belgesi Listesi",     "HizmetBelgesiListesi.xltx",             ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, true, 0, false, "GR006", "Unvana Göre,Birime Göre,İsme Göre,Süreye Göre",true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK036", "En Son Hizmet Belgesi Listesi",     "KadroDereceDurumListesi.xltx",          ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false,"GR006", "Unvana Göre,Birime Göre,İsme Göre,Süreye Göre",false,false,false,false,false,false,false,true, false, false),
             new RaporTanim("IK037", "Evlilik Durumuna Göre Dağılım",     "IKYIstatistik.xltx",                    ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK038", "Çocuk Sayısına Göre Dağılım",       "IKYIstatistik.xltx",                    ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK039", "Kurumda Çalıştığı Yıla Göre Personel Dağılımı", "IKYIstatistik.xltx",        ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK040", "Emekliliğe Sayılan Yıla Göre Personel Dağılımı", "IKYIstatistik.xltx",       ENUMRaporTur.Metot,   true, false, false, true, true, true, false, false, false, false, false, false, 1, false, "GR010", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK041", "Sırtlık Listesi",                   "Sirtlik.xltx",                          ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 1, false, "GR003", null,false,false,false,false,false,false,false, true, true, false),
             new RaporTanim("IK042", "Unvan İsim Listesi",                "UnvanIsimListesi.xltx",                 ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR008", null,false,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK043", "Unvan Kadro Dağılımları",           "PersonelKadroKontenjanMemurT.xlt",      ENUMRaporTur.Metot,   true, false, false, true, true, false,false,false, false, false, false, false, 0, false, "GR008", null,false,false,false,false,false,false,false, false,false, false),
             new RaporTanim("IK044", "Unvan Derece Dağılımı",             "PersonelKadroKontenjanMemur.xlt",       ENUMRaporTur.Metot,   true, false, false, true, true, false,false,false, false, false, false, false, 0, false, "GR008", null,false,false,false,false,false,false,false, false, false, false),
             new RaporTanim("IK045", "Tanıtma Kartı",                     "PersonelTanitmaKarti.docx",             ENUMRaporTur.Metot,   true, false, false, false, false, true, true, false , false, true, false, false, 1, false, "GR003", null,true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK046", "Kurum Kadrolu Hizmeti Listesi",     "HizmetBelgesiListesi.xltx",             ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true, false, true, 0, false, "GR006", "Unvana Göre,Birime Göre,İsme Göre,Süreye Göre",true,false,false,false,false,false,false, true, false, false),
             new RaporTanim("IK047", "Lojmanda Oturan Personel Listesi",  "LojmanListesi.xltx",                    ENUMRaporTur.Metot, false, false, false, false, false, false, false, false, false, false, false, false, 0, false, "GR011", null,false,true,false,false,false,false,false, false, false, false),
             new RaporTanim("IK048", "Lojman Dolu-Boş Daire Listesi",  "LojmanDaireListesi.xltx",                  ENUMRaporTur.Metot, false, false, false, false, false, false, false, false, false, false, false, false, 0, false, "GR011", null,false,true,true ,false,false,false,false, false, false, false),
             new RaporTanim("IK049", "Site Kesinti (Site)",  "PersonelSiteKesintiListesi.xltx",                    ENUMRaporTur.Metot, true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR011", null,true,true,false, true,true,false,false, true, false, false),
             new RaporTanim("IK049a","Site Kesinti (Blok)", "PersonelSiteKesintiListesi.xltx",                     ENUMRaporTur.Metot, true, false, false, false, false, true, false, false, false, true, false, false, 0, false, "GR011", null,true,true,false, true,true,false,false, true, false, false),
             new RaporTanim("IK050", "Lojman Değişiklik Listesi",  "LojmanDegisiklikListesi.xltx",                 ENUMRaporTur.Metot, false, false, false, false, false, false, false, false, false, false, false, false, 0, false, "GR011", null,false,true,false,false,false,false,false, false, false, false),
             new RaporTanim("IK051", "Lojmanda Oturanlar Listesi (Süre Kısıtlı)",  "LojmanListesi.xltx",           ENUMRaporTur.Metot, false, false, false, false, false, false, false, false, false, false, false, false, 0, false, "GR011", null,false,true,false,false,false,true ,false, false, false, false),
             new RaporTanim("IK052", "Lojman Değişiklik Listesi Gruplu",  "LojmanDegisiklikListesiGrup.xltx",      ENUMRaporTur.Metot, false, false, false, false, false, false, false, false, false, false, false, false, 0, false, "GR011", null,false,true,false,false,false,false,false, false, false, false),
             new RaporTanim("IK053", "Lojmanda Rezervasyon Listesi",  "LojmanRezervasyonListesi.xltx",             ENUMRaporTur.Metot, false, false, false, false, false, false, false, false, false, false, false, false, 0, false, "GR011", sira,false,true,false,false,false,false,false, false, false, false),
             new RaporTanim("IK054", "Gider Listesi",                 "PersonelGiderListesi.xltx",                 ENUMRaporTur.Metot, "GR011", 2, new RaporAlanTanim{cmpAktiflik=false, cmpKisiArama=false, cmpPersonelTurCoklu=false, cmpYil=true, cmpAy=true } ),
             //new RaporTanim("IK055", "Personel Hesaplanmış Yemek Listesi", "PersonelHesaplanmisYemekListesi.xltx", ENUMRaporTur.Metot,   true, false, false, false, false, true, false, false, false, true,false,false, 0, false, "GR014", null,true,false,false,true,true,false,true, true, false, false),
             new RaporTanim("IK056", "Soruşturma Bilgisi",            "SorusturmaListesi.xltx",                    ENUMRaporTur.Metot, "GR003", 1, new RaporAlanTanim{cmpAktiflik=false, cmpKisiArama=false, cmpPersonelTurCoklu=true, cmpYil=false, cmpAy=false, tarihSorgu=true } ),

             new RaporTanim("IK101", "Unvan ve Personel Tipine Göre Dağılım", "",                                  ENUMRaporTur.Metot,   "GR010", 1, new RaporAlanTanim{}),
             new RaporTanim("IK102", "Hrc. Birimi ve Personel Tipine Göre Dağılım", "",                            ENUMRaporTur.Metot,   "GR010", 1, new RaporAlanTanim{}),

             new RaporTanim("GR009", "Dinamik Liste Seçimi Listesi",      "DinamikRapor.xltx",                     ENUMRaporTur.Metot, true, false, false, true, true, true,false,false, false, true, false, false, 0, true, "GR009", null,true,false,false,false,false,false,false, false, true, false),
        };

        private static RaporTanim RaporBul(string kod)
        {
            foreach (RaporTanim item in raporTanimlar)
            {
                if (item.KOD == kod) return item;
            }
            return null;
        }

        void EkranHazirla(string kod)
        {
            RaporTanim rapor = RaporBul(kod);
            bool gizle = rapor == null;
            if (rapor == null)
            {
                rapor = new RaporTanim("", "Lütfen Rapor Seçiniz", "", ENUMRaporTur.Metot, false, false, false, false, false, false, false, false, false, false, false, false, 0, false, "", null, false, false, false, false, false, false, false, false, false, false);
            }

            btnYazdir.Hidden = gizle;
            btnYazdir2.Hidden = gizle;
            btnYazdir3.Hidden = gizle;
            frmPanel.SetTitle("Rapor Kriter Alanları - " + rapor.AD);

            cmbKadroDerece.Hidden = !rapor.cmpKadroDerece;
            cfBirim.Hidden = !rapor.cmpBirim;

            ddlPersonelTipGrup.Hidden = !(rapor.cmpPersonelTurCoklu);
            cmbPersonelTipCoklu.Hidden = !(rapor.cmpPersonelTurCoklu);
            cmbPersonelTipCoklu.SingleSelect = !rapor.cmpPersonelTurCoklu;

            txtIslemSira.Hidden = !rapor.cmpIslemSira;
            chkYukumlu.Hidden = !rapor.cmpYukumlu;
            cfArama.Hidden = !rapor.cmpKisiArama;

            cfAramaResimli.Hidden = !rapor.cmpKisiAramaGrid;
            cfAramaResimsiz.Hidden = !rapor.cmpKisiAramaGrid;
            grdPerList.Hidden = !rapor.cmpKisiAramaGrid;

            grdDinamik.Hidden = !rapor.cmpDinamik;
            txtSonTarih.Hidden = !rapor.cmpSonTarih;
            if (rapor.cmpSonTarih)
            {
                if (txtSonTarih.SelectedDate == DateTime.MinValue)
                {
                    txtSonTarih.SelectedDate = DateTime.Now.Date;
                }
                if (rapor.KOD == "IK021a")
                    txtSonTarih.FieldLabel = "Görev Tarihi";
                else
                    txtSonTarih.FieldLabel = "Son Tarih";
            }
            cmbSiralama.Hidden = true;
            ddlAktiflik.Hidden = !rapor.cmpAktiflik;
            ddlSite.Hidden = !rapor.cmpSiteKod;
            ddlDaireBosluk.Hidden = !rapor.cmpDaireBosluk;
            spnYilAra.Hidden = !rapor.cmpYil;
            ddlAyAra.Hidden = !rapor.cmpAy;
            ddlYerleske.Hidden = !rapor.cmpYemekhane;
            cfTarihSorgu.Hidden = !rapor.tarihSorgu;
            if (rapor.izinTur)
            {
                cmpCokluSecim.Hidden = false;
                cmpYilArasi.Hidden = false;
                cmpYilArasi.FieldLabel = "Yıllar";
                int dYil = IzinArac.DonemYiliBul(DateTime.Now.Year, DateTime.Now.Month);
                spnYil1.MaxValue = dYil + 1;
                spnYil1.MinValue = 2000;
                spnYil1.Number = dYil;
                spnYil2.MaxValue = dYil + 1;
                spnYil2.MinValue = 2000;
                spnYil2.Number = dYil;
            }
            else
            {
                cmpCokluSecim.Hidden = true;
                cmpYilArasi.Hidden = !rapor.cmpYilArasi;
                cmpYilArasi.FieldLabel = "Süre";
                spnYil1.MaxValue = 90;
                spnYil1.MinValue = -1;
                spnYil1.Number = -1;
                spnYil2.MaxValue = 90;
                spnYil2.MinValue = -1;
                spnYil2.Number = -1;
            }

            if (!string.IsNullOrWhiteSpace(rapor.siralamaListe))
            {
                string[] siralamalar = rapor.siralamaListe.Split(',');
                ArrayList al = new ArrayList();
                int say = 0;
                foreach (string item in siralamalar)
                {
                    string ic = item.Trim();
                    if (!string.IsNullOrWhiteSpace(ic))
                    {
                        al.Add(new IntKodStrAd(say++, ic));
                    }
                }
                if (al.Count > 0)
                {
                    stoSiralama.DataSource = al;
                    stoSiralama.DataBind();
                    cmbSiralama.Hidden = false;
                }
            }

            frmPanel.DoLayout();
            if (!grdDinamik.Hidden)
                Genel.DinamikListeDoldur(storeDinamik);
            //ImzaBilgileriniDoldur(kod);
        }

        //static void RaporParametreleriDoldur(ReportDocument crRapor, string kod, string orgBirimKod, int kadroDerece, ref string hata)
        //{
        //    string formul = "";

        //    if (!formul.StartsWith("HATA"))
        //    {
        //        if (kod == "IK011")
        //        {
        //            int kadroDurumu = (int)ENUMKadroDurumu.AKTIFKAYIT;
        //            formul += "{IKYPERSONELKADRO.KADRODURUMU}= " + kadroDurumu;
        //            //if (birim != 0)
        //            //    formul += " AND {IKYPERSONELKADRO.ORGANIZASYONKOD}= " + birim;
        //            if (kadroDerece != 0)
        //                formul += " AND {IKYPERSONELKADRO.KADRODERECE}= " + kadroDerece;
        //        }
        //        //if (kod == "IK006")
        //        //{
        //        //    formul += "{IKYPERSONELOGRENIM.GECERLI}=1";
        //        //    formul += " AND {IKYPERSONELAILE.YAKINLIKDERECESI}=23";
        //        //}
        //    }

        //    if (formul.StartsWith("HATA"))
        //        hata = formul;
        //    else if (formul != "")
        //        crRapor.RecordSelectionFormula = formul;
        //}

        public static string adresUret(string raporKod, string personelTurler, string islemSirano, string birimAd, string orgKopruKod, int siralamaKod, string ciktiTur, int kadroDerece, bool goster, string seciliKodlar, string aktifDurumlar, string sonTarih, string siralamaListesi, string sorgu, int aktiflik, int siteKod, int dairebosluk, int yil, int ay, int yil1, int yil2, int yukumluMu, string yerleskeler, string tarihSorgu, int tarihSorguTur, string izinTurler)
        {
            return "RaporPersonel.ashx?indir=1" + ParamEkle("raporKod", raporKod) + ParamEkle("personelTurler", personelTurler) + ParamEkle("islemSira", islemSirano) + ParamEkle("birim", birimAd) + ParamEkle("orgKod", orgKopruKod) + ParamEkle("yukumlu", yukumluMu.ToString()) + ParamEkle("siralamaKod", siralamaKod.ToString()) + ParamEkle("kadroDerece", kadroDerece.ToString()) + ParamEkle("seciliKodlar", seciliKodlar) + ParamEkle("aktifDurumlar", aktifDurumlar) + ParamEkle("sonTarih", sonTarih) + ParamEkle("siralamaListesi", siralamaListesi) + ParamEkle("sorgu", sorgu) + ParamEkle("aktiflik", aktiflik.ToString()) + ParamEkle("site", siteKod.ToString()) + ParamEkle("daireBosluk", dairebosluk.ToString()) + ParamEkle("yil", yil.ToString()) + ParamEkle("ay", ay.ToString()) + ParamEkle("yil1", yil1.ToString()) + ParamEkle("yil2", yil2.ToString()) + ParamEkle("goster", goster ? "1" : "0") + ParamEkle("dosyaAd", "Rapor.pdf") + ParamEkle("yerleskeler", yerleskeler) + ParamEkle("tarihSorgu", tarihSorgu) + ParamEkle("tarihSorguTur", tarihSorguTur.ToString()) + ParamEkle("izinTurler", izinTurler);
        }

        public static string raporUret(IIKYServis servisIKY, Kullanici kullanan, string raporSablonYol, string raporKod,
            string personelTurler, string islemSirano, string birimAd, string orgKopruKod,
            int siralamaKod,
            string ciktiTur, int kadroDerece, bool goster,
            string seciliKodlar, string aktifDurumlar, string sonTarih, string siralamaListesi, bool gonder,
            string sorgu, int aktiflik, int siteKod, int daireBosluk, int yil, int ay, int yil1, int yil2, int yukumluMu, string yerleskeler,
            string tarihSorgu, int tarihSorguTur, string izinTurler)
        {
            RaporTanim raporTanim = RaporBul(raporKod);

            if (raporTanim == null)
            {
                throw new Exception("Listeden görmek istediğiniz raporu seçiniz.");
            }

            string raporDosyaAd = raporTanim.DOSYAAD;
            string raporAd = raporTanim.AD;

            string sablonAd = raporSablonYol + @"IKY\" + raporTanim.DOSYAAD;
            string uretilenDosya = null;
            string sonucDosyaAd = DosyaIslem.DosyaAdUret("IKY", "");
            if (raporTanim.raporTur == ENUMRaporTur.Metot)
            {
                System.Collections.Hashtable raporParam = new System.Collections.Hashtable();
                raporParam["personelTur"] = personelTurler;
                raporParam["IslemSiraNo"] = islemSirano;
                raporParam["BirimAd"] = birimAd;
                raporParam["ORGKOD"] = orgKopruKod;

                raporParam["personelKod"] = seciliKodlar;
                raporParam["aktifDurumlar"] = aktifDurumlar;
                raporParam["sonTarih"] = sonTarih;
                raporParam["siralamaListesi"] = siralamaListesi;
                raporParam["siralamaKod"] = siralamaKod;

                raporParam["sorgu"] = sorgu;
                raporParam["aktiflik"] = aktiflik;
                raporParam["site"] = siteKod;
                raporParam["daireBosluk"] = daireBosluk;
                raporParam["yil"] = yil;
                raporParam["ay"] = ay;
                raporParam["yil1"] = yil1;
                raporParam["yil2"] = yil2;

                raporParam["yukumlu"] = yukumluMu;
                raporParam["yerleskeler"] = yerleskeler;

                raporParam["tarihSorgu"] = tarihSorgu;
                raporParam["tarihSorguTur"] = tarihSorguTur;
                raporParam["izinTurler"] = izinTurler;
                if (raporTanim.raporDosyasiNo == 1)
                    uretilenDosya = new PersonelRaporlari2().RaporAl(kullanan, servisIKY, sablonAd, sonucDosyaAd, ciktiTur, raporParam, raporKod);
                else
                    uretilenDosya = new PersonelRaporlari().RaporAl(kullanan, servisIKY, sablonAd, sonucDosyaAd, ciktiTur, raporParam, raporKod);
            }
            else
            {
                //ReportDocument crRapor = new ReportDocument();
                //crRapor.Load(sablonAd);

                //if (crRapor.IsLoaded)
                //{
                //    //***********************************************************
                //    string kullanici = "";
                //    string parola = "";
                //    string sunucu = "";
                //    string veriTabani = "";
                //    Genel.VeriTabaniBaglantiBilgileriniAl(kullanan, ref kullanici, ref parola, ref sunucu, ref veriTabani);
                //    for (int i = 0; i < crRapor.DataSourceConnections.Count; i++)
                //    {
                //        crRapor.DataSourceConnections[i].SetConnection(sunucu, veriTabani, kullanici, parola);
                //    }

                //    //***********************************************************
                //    string hata = "";
                //    RaporParametreleriDoldur(crRapor, raporKod, orgKopruKod, kadroDerece, ref hata);
                //    if (hata != "")
                //    {
                //        //Genel.CrystalReportKapat(crRapor);
                //        throw new Exception(hata);
                //    }

                //    string raporUzanti = ciktiTur;
                //    ExportFormatType crtip = ciktiTur == "pdf" ? ExportFormatType.PortableDocFormat : ExportFormatType.Excel;
                //    //if (raporKod == "MK004" || raporKod == "MK005")
                //    //    crtip = ExportFormatType.PortableDocFormat;

                //    crRapor.ExportOptions.ExportDestinationType = CrystalDecisions.Shared.ExportDestinationType.DiskFile;
                //    crRapor.ExportOptions.ExportFormatType = crtip;

                //    CrystalDecisions.Shared.DiskFileDestinationOptions dfo = new CrystalDecisions.Shared.DiskFileDestinationOptions();

                //    dfo.DiskFileName = sonucDosyaAd;

                //    crRapor.ExportOptions.DestinationOptions = dfo;
                //    crRapor.Export();

                //    //Genel.CrystalReportKapat(crRapor);
                //    uretilenDosya = sonucDosyaAd;
                //}
            }
            if (!string.IsNullOrWhiteSpace(uretilenDosya) && gonder)
            {
                DosyaIslem.DosyaGonderX(uretilenDosya, raporTanim.AD + "_" + DateTime.Now.Ticks.ToString() + "." + ciktiTur, true, ciktiTur, !goster);
                return null;
            }
            else
                return uretilenDosya;
        }

        private void RaporGonder()
        {
        }

        private string KopruKodBul(int orgKod)
        {
            if (orgKod > 0)
            {
                TNS.ORG.OrganizasyonBirim birim = TNS.ORG.Arac.OrgBirimBul(orgKod);
                return birim.kopruKod;
            }
            return "";
        }

        //class SiralaIntKodStrAd : IComparer
        //{
        //    public int Compare(object x, object y)
        //    {
        //        if (x is IntKodStrAd && y is IntKodStrAd)
        //        {
        //            IntKodStrAd xx = (IntKodStrAd)x;
        //            IntKodStrAd yy = (IntKodStrAd)y;
        //            int sonuc = xx.ad.CompareTo(yy.ad);
        //            if (sonuc != 0) return sonuc;
        //            return xx.kod.CompareTo(yy.kod);
        //        }
        //        return 0;
        //    }
        //}
        /// <summary>
        /// Listele tuşuna basılınca griddeki para birimi listesi yenilenir.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
            string raporKod = hdnRaporKod.Text;
            RaporTanim raporTanim = RaporBul(raporKod);
            if (raporTanim == null)
            {
                GenelIslemler.MesajKutusu("Uyarı", "Listeden görmek istediğiniz raporu seçiniz.");
                return;
            }


            //ImzaBilgileriniKaydet(hdnRaporKod.Text);
            string personelTurler = "";
            if (raporTanim.cmpPersonelTurCoklu)
            {
                personelTurler = cmbPersonelTipCoklu.UnderlyingValue;
                if (string.IsNullOrWhiteSpace(personelTurler) && ddlPersonelTipGrup.SelectedItems.Count > 0)
                {
                    PersonelTipi pt = new PersonelTipi();
                    pt.tipGruplar = TipGruplariBul();
                    pt.aktif = 1;
                    ObjectArray ptipler = servisIKY.ListelePersonelTip(null, pt);
                    personelTurler = "";
                    foreach (PersonelTipi item in ptipler.objeler)
                    {
                        if (personelTurler != "") personelTurler += ";";
                        personelTurler += item.kod.ToString();
                    }
                }
            }
            string ciktiTur = "";

            string tusTur = e.ExtraParams["tur"];
            if (tusTur == "3")
                ciktiTur = "pdf";
            else
            {
                if (raporTanim.cmpCiktiTurDoc)
                    ciktiTur = "docx";
                else
                    ciktiTur = "xlsx";
            }

            string seciliKodlar = "";
            if (raporTanim.cmpKisiAramaGrid)
            {
                foreach (var sr in smPerList.SelectedRows)
                {
                    if (seciliKodlar != "") seciliKodlar += ",";
                    seciliKodlar += sr.RecordID;
                }
            }
            string yerleskeler = "";
            if (raporTanim.cmpYemekhane)
            {
                foreach (var sr in csmYerleske.SelectedRows)
                {
                    if (yerleskeler != "") yerleskeler += ",";
                    yerleskeler += sr.RecordID;
                }
            }
            string hata = "";

            string ddlBirimTxt = "";
            int ddlBirimVal = 0;

            if (raporTanim.cmpBirim)
            {
                ddlBirimTxt = ddlBirim.Text.ToUpper();
                ddlBirimVal = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
            }

            string siralamalar = "";
            if (raporTanim.cmpDinamik)
            {
                Newtonsoft.Json.Linq.JObject[] o = (Newtonsoft.Json.Linq.JObject[])JSON.Deserialize(e.ExtraParams["dinamikler"], typeof(Newtonsoft.Json.Linq.JObject[]));
                if (o.Length > 0)
                {
                    foreach (Newtonsoft.Json.Linq.JObject row in o)
                    {
                        if (siralamalar != "") siralamalar += ",";
                        siralamalar += row.Value<int>("Kod");
                    }
                }
            }
            int siralamaKod = cmbSiralama.SelectedIndex;
            if (raporTanim.raporGrubu == "GR009" && string.IsNullOrWhiteSpace(siralamalar))
                hata += " Lütfen raporda görmek istediğiniz alanları seçiniz.";

            if ((raporTanim.raporGrubu == "GR014") && ddlBirimVal == 0)
                hata += " Rapor almak istediğiniz birimi seçiniz.";

            if (raporKod == "IK045" && string.IsNullOrEmpty(seciliKodlar))
                hata += " Lütfen personel seçiniz.";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu("bilgi", hata);
                return;
            }

            string izinTurler = "";
            if (raporTanim.izinTur)
                izinTurler = cmpCokluSecim.Value.ToString();

            if (tusTur == "1")
                X.AddScript("SayfaAc('{0}')", adresUret(raporKod, personelTurler, TextAl(!raporTanim.cmpIslemSira, txtIslemSira), ddlBirimTxt, KopruKodBul(ddlBirimVal) + AltBirimli(!raporTanim.cmpBirim), siralamaKod, ciktiTur, IntAlCmbVal(!raporTanim.cmpKadroDerece, cmbKadroDerece), true, seciliKodlar, "", TextAl(!raporTanim.cmpSonTarih, txtSonTarih), siralamalar, TextAl(!raporTanim.cmpKisiArama, tfArama), AktifBul(!raporTanim.cmpAktiflik), IntAl(!raporTanim.cmpSiteKod, ddlSite), IntAl(!raporTanim.cmpDaireBosluk, ddlDaireBosluk), SpnIntAl(!raporTanim.cmpYil, spnYilAra), IntAl(!raporTanim.cmpAy, ddlAyAra), SpnIntAl(!(raporTanim.cmpYilArasi || raporTanim.izinTur), spnYil1), SpnIntAl(!(raporTanim.cmpYilArasi || raporTanim.izinTur), spnYil2), InputValtoInt(!raporTanim.cmpYukumlu, chkYukumlu.CheckedItems[0].InputValue), yerleskeler, TextAl(!raporTanim.tarihSorgu, dfTarihSorgu), IntAl(!raporTanim.tarihSorgu, cbTarihSorgu), izinTurler));
            else
                raporUret(servisIKY, kullanan, this.raporSablonYol, raporKod, personelTurler, TextAl(!raporTanim.cmpIslemSira, txtIslemSira), ddlBirimTxt, KopruKodBul(ddlBirimVal) + AltBirimli(!raporTanim.cmpBirim), siralamaKod, ciktiTur, IntAlCmbVal(!raporTanim.cmpKadroDerece, cmbKadroDerece), false, seciliKodlar, "", TextAl(!raporTanim.cmpSonTarih, txtSonTarih), siralamalar, true, TextAl(!raporTanim.cmpKisiArama, tfArama), AktifBul(!raporTanim.cmpAktiflik), IntAl(!raporTanim.cmpSiteKod, ddlSite), IntAl(!raporTanim.cmpDaireBosluk, ddlDaireBosluk), SpnIntAl(!raporTanim.cmpYil, spnYilAra), IntAl(!raporTanim.cmpAy, ddlAyAra), SpnIntAl(!(raporTanim.cmpYilArasi || raporTanim.izinTur), spnYil1), SpnIntAl(!(raporTanim.cmpYilArasi || raporTanim.izinTur), spnYil2), InputValtoInt(!raporTanim.cmpYukumlu, chkYukumlu.CheckedItems[0].InputValue), yerleskeler, TextAl(!raporTanim.tarihSorgu, dfTarihSorgu), IntAl(!raporTanim.tarihSorgu, cbTarihSorgu), izinTurler);
        }

        private int IntAl(bool hidden, ComboBox cbTarihSorgu)
        {
            if (!hidden)
                return OrtakFonksiyonlar.ConvertToInt(cbTarihSorgu.SelectedItem.Value, 0);
            return 0;
        }

        private int IntAlCmbVal(bool hidden, ComboBox cmbKadroDerece)
        {
            if (!hidden)
                return OrtakFonksiyonlar.ConvertToInt(cmbKadroDerece.Value, 0);
            else
                return 0;
        }

        private int InputValtoInt(bool hidden, string inpVal)
        {
            if (!hidden)
                OrtakFonksiyonlar.ConvertToInt(inpVal, 0);
            return 0;
        }

        private int SpnIntAl(bool hidden, SpinnerField spnYilAra)
        {
            if (!hidden)
                return OrtakFonksiyonlar.ConvertToInt(spnYilAra.Number, 0);
            return 0;
        }

        private string TextAl(bool hidden, DateField dfTarihSorgu)
        {
            if (!hidden)
                return dfTarihSorgu.Text;
            return "";
        }

        private string TextAl(bool hidden, TextField tfArama)
        {
            if (!hidden)
                return tfArama.Text;
            else
                return "";
        }

        private string AltBirimli(bool hidden)
        {
            if (!hidden)
                return cbAltBirimli.Checked ? "%" : "";
            else
                return "";
        }

        private int AktifBul(bool hidden)
        {
            if (!hidden)
                return OrtakFonksiyonlar.ConvertToInt(ddlAktiflik.SelectedItem.Value, 0);
            return -1;
        }

        private string StrYap(object p)
        {
            if (p == null) return "";
            else return p.ToString();
        }

        private static string ParamEkle(string param, string deger)
        {
            return "&" + param + "=" + System.Web.HttpUtility.UrlEncode(deger);
        }

        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            string raporKod = e.ExtraParams["secKod"];
            RaporTanim raporTanim = RaporBul(raporKod);
            hdnRaporKod.Value = raporKod;
            EkranHazirla(raporKod);
        }

        //void ImzaBilgileriniDoldur(string kod)
        //{
        //    string imzaKodu = "";
        //    if (kod == "MK001" || kod == "MK002" || kod == "MK003" || kod == "MK004" || kod == "MK005")
        //        imzaKodu = "GRUP1";
        //    else
        //        imzaKodu = "GRUP2";

        //    txtSolImzaAdSoyad.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "RAPORSOLIMZAADSOYAD" + imzaKodu);
        //    txtOrtaImzaAdSoyad.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "RAPORORTAIMZAADSOYAD" + imzaKodu);
        //    txtSagImzaAdSoyad.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "RAPORSAGIMZAADSOYAD" + imzaKodu);
        //    txtSolImzaGorev.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "RAPORSOLIMZAGOREV" + imzaKodu);
        //    txtOrtaImzaGorev.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "RAPORORTAIMZAGOREV" + imzaKodu);
        //    txtSagImzaGorev.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "RAPORSAGIMZAGOREV" + imzaKodu);
        //}

        //void ImzaBilgileriniKaydet(string kod)
        //{
        //    string imzaKodu = "";
        //    if (kod == "MK001" || kod == "MK002" || kod == "MK003" || kod == "MK004" || kod == "MK005")
        //        imzaKodu = "GRUP1";
        //    else
        //        imzaKodu = "GRUP2";

        //    GenelIslemler.KullaniciDegiskenSakla(kullanan, "RAPORSOLIMZAADSOYAD" + imzaKodu, txtSolImzaAdSoyad.Text);
        //    GenelIslemler.KullaniciDegiskenSakla(kullanan, "RAPORORTAIMZAADSOYAD" + imzaKodu, txtOrtaImzaAdSoyad.Text);
        //    GenelIslemler.KullaniciDegiskenSakla(kullanan, "RAPORSAGIMZAADSOYAD" + imzaKodu, txtSagImzaAdSoyad.Text);
        //    GenelIslemler.KullaniciDegiskenSakla(kullanan, "RAPORSOLIMZAGOREV" + imzaKodu, txtSolImzaGorev.Text);
        //    GenelIslemler.KullaniciDegiskenSakla(kullanan, "RAPORORTAIMZAGOREV" + imzaKodu, txtOrtaImzaGorev.Text);
        //    GenelIslemler.KullaniciDegiskenSakla(kullanan, "RAPORSAGIMZAGOREV" + imzaKodu, txtSagImzaGorev.Text);
        //}       

        protected void tfArama_Ara_Clicked(object sender, DirectEventArgs e)
        {
            TNS.IKY.Personel p = new TNS.IKY.Personel();
            p.genelSorgu = tfArama.Text;
            p.kadro.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value.ToString(), 0);

            var personelTurler = cmbPersonelTipCoklu.UnderlyingValue;
            if (string.IsNullOrWhiteSpace(personelTurler))
                p.tipGruplar = TipGruplariBul();
            else
                p.personelTipleri = cmbPersonelTipCoklu.UnderlyingValue;

            string raporKod = hdnRaporKod.Text;
            RaporTanim raporTanim = RaporBul(raporKod);

            p.aktifDurum = OrtakFonksiyonlar.ConvertToInt(ddlAktiflik.SelectedItem.Value, 0);

            p.aktifTarih = new TNSDateTime(dfTarihSorgu.SelectedDate);
            p.aktifTarihTur = OrtakFonksiyonlar.ConvertToInt(cbTarihSorgu.SelectedItem.Value, 0);

            if (raporTanim.raporGrubu == "GR012")
            {
                if (OrtakFonksiyonlar.ConvertToInt(ddlSite.SelectedItem.Value, 0) == 0)
                    ddlSite.SelectedItem.Value = "-1";
                p.personelSiteKod = OrtakFonksiyonlar.ConvertToInt(ddlSite.SelectedItem.Value, 0);
            }

            ObjectArray oa = servisIKY.PersonelListele(kullanan, p, false, false);
            grdPerList.ColumnModel.SetHidden(1, e.ExtraParams["Resim"] == "0");
            if (oa.sonuc.islemSonuc)
            {
                smPerList.ClearSelections();
                smPerList.SelectedRows.Clear();
                stoPerList.DataSource = oa.objeler;
                stoPerList.DataBind();
            }
            else
                GenelIslemler.MesajKutusu("Hata", oa.sonuc.hataStr);
        }
    }
}
