﻿using System;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Collections;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Öğrenim Sınıfı
    /// </summary>
    public partial class PersonelOgrenim : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        //public string personelTCKimlikNo = "";

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPKod.Value = (Request.QueryString["personelKod"] + "").Trim();

            //personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnTemizle.Hidden = true;
            //    btnSil.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                OgrenimDoldur();
                UniversiteDoldur();
                FakulteDoldur();
                BolumDoldur();
                OgrenimYeriDoldur();
                OgrenimBelgeTurDoldur();
                Temizle();
                Listele(new TNS.IKY.PersonelOgrenim());
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel Öğrenim bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel Öğrenim tipinde sınıf</param>
        public void Listele(TNS.IKY.PersonelOgrenim kriter)
        {
            if (string.IsNullOrEmpty(hdnPKod.Value.ToString()))
                return;

            kriter.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            ObjectArray pler = servisIKY.PersonelOgrenimListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            List<object> liste = new List<object>();
            foreach (TNS.IKY.PersonelOgrenim p in pler.objeler)
                liste.Add(new
                {
                    KOD = p.kod,
                    PKOD = p.personelKod,
                    OGRENIMKOD = p.ogrenimKod,
                    UNIVERSITEKOD = p.universiteKod,
                    FAKULTEKOD = p.fakulteKod,
                    BOLUMKOD = p.bolumKod,
                    OKULADI = p.okulAdi,
                    BELGETUR = p.belgeTur,
                    BELGETARIHI = p.belgeTarihi.Oku(),
                    BELGENO = p.belgeNo,
                    BASLANGICTARIHI = p.baslangicTarihi.Oku(),
                    DERECE = p.derece,
                    GECERLI = p.gecerli,
                    OGRENIMYERI = p.ogrenimYeri,
                    DENKLIK = p.denklik,
                    DENKLIKTARIHI = p.denklikTarihi,
                    DENKOKUL = p.denkOkul,
                    DENKBOLUM = p.denkBolum,
                    HAZIRLIK = p.hazirlikVarMi,
                    KURUMAIBRAZTARIHI = p.kurumaIbrazTarihi.Oku(),
                    OgrenimKodKayitKod = p.ogrenimKodKayitKod,
                    GIRISOKULU = p.memuriyeteBasladigiOkul,
                    OGRENIMSURESI = p.ogrenimSuresi,
                });

            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Öğrenim bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnKaydet_Click(object sender, EventArgs e)
        {
            if (!KayitKontrol())
                return;

            TNS.IKY.PersonelOgrenim p = new TNS.IKY.PersonelOgrenim();
            p.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) > 0)
                p.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            if (ddlOgrenim.Value != null)
            {
                string[] arr = ddlOgrenim.Value.ToString().Split(':');
                p.ogrenimKod = OrtakFonksiyonlar.ConvertToInt(arr[0], 0);
            }
            p.universiteKod = OrtakFonksiyonlar.ConvertToInt(ddlUniversite.Value, 0);
            p.fakulteKod = OrtakFonksiyonlar.ConvertToInt(ddlFakulte.Value, 0);
            p.bolumKod = OrtakFonksiyonlar.ConvertToInt(ddlBolum.Value, 0);
            p.ogrenimSuresi = OrtakFonksiyonlar.ConvertToInt(txtOgrenimSuresi.Text, 0);
            if (string.IsNullOrEmpty(txtOkulAdi.Text))
                p.okulAdi = Genel.SozlukBilgiGetir(p.universiteKod).ad;
            else
                p.okulAdi = txtOkulAdi.Text;
            p.baslangicTarihi = Genel.TarihAlaniDegerVer(txtBaslamaTarihi);
            p.belgeTur = OrtakFonksiyonlar.ConvertToInt(ddlBelgeTur.Text, 0);
            p.belgeNo = txtBelgeNo.Text;
            p.derece = OrtakFonksiyonlar.ConvertToInt(txtDerecesi.Text, 0);
            p.belgeTarihi = Genel.TarihAlaniDegerVer(txtBitirmeTarihi);
            p.gecerli = OrtakFonksiyonlar.ConvertToInt(chkGecerli.Checked, 0);
            p.ogrenimYeri = OrtakFonksiyonlar.ConvertToInt(ddlOgrenimYeri.Value, 0);
            p.denklik = OrtakFonksiyonlar.ConvertToInt(chkDenklik.Checked, 0);
            if (p.denklik == 1)
            {
                p.denkBolum = OrtakFonksiyonlar.ConvertToStr(txtDenklikBolum.Value);
                p.denkOkul = txtDenklikOkul.Text;
                p.denklikTarihi = Genel.TarihAlaniDegerVer(txtDenklikTarihi);
            }
            if (p.denklik == 0)
            {
                p.denkBolum = string.Empty;
                p.denkOkul = string.Empty;
                p.denklikTarihi = new TNSDateTime();
            }
            p.hazirlikVarMi = OrtakFonksiyonlar.ConvertToInt(chkHazirlik.Checked, 0);
            p.kurumaIbrazTarihi = Genel.TarihAlaniDegerVer(txtKurumIbrazTarihi);
            p.memuriyeteBasladigiOkul = OrtakFonksiyonlar.ConvertToInt(chkMemuriyeteBaslama.Checked, 0);

            Sonuc sonuc = servisIKY.PersonelOgrenimKaydet(kullanan, p);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                //Temizle();
                hdnKod.Value = sonuc.anahtar;
                Listele(new TNS.IKY.PersonelOgrenim());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL017);
            }
        }

        /// <summary>
        /// Sil butonuna basınca, koda, T.C. Kimlik numarasına göre Personel Öğrenim bilgisi silen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, EventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            int pKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            if (pKod <= 0 || kod <= 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPOG032);
                return;
            }

            TNS.IKY.PersonelOgrenim d = new TNS.IKY.PersonelOgrenim();
            d.personelKod = pKod;
            d.kod = kod;
            Sonuc sonuc = servisIKY.PersonelOgrenimSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                //PersonelBelgeler belge = new PersonelBelgeler();
                //belge.tcKimlikNo = personelTCKimlikNo;
                //belge.tip = (int)ENUMBELGEFORMTIP.PERSONELOGRENIM;
                //belge.kayitSiraNo = hdnSiraNo.Value.ToString();
                //servisIKY.PersonelBelgeSil(kullanan, belge);

                Temizle();
                Listele(new TNS.IKY.PersonelOgrenim());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL018);
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            string secilisatir = e.ExtraParams["RowValue"].ToString();
            XmlNode xml = JSON.DeserializeXmlNode("{records:{record:" + secilisatir + "}}");
            foreach (XmlNode row in xml.SelectNodes("records/record"))
            {
                int ogrenimKod = OrtakFonksiyonlar.ConvertToInt(row.SelectSingleNode("OGRENIMKOD").InnerXml, 0);
                string okk = row.SelectSingleNode("OgrenimKodKayitKod").InnerXml;
                if (ogrenimKod > 0)
                {
                    ddlOgrenim.SetValueAndFireSelect(ogrenimKod + ":" + okk);
                    X.AddScript("OgrenimKodDegisti();");
                }
                hdnKod.Value = row.SelectSingleNode("KOD").InnerXml;
                hdnPKod.Value = row.SelectSingleNode("PKOD").InnerXml;
                //ddlOgrenim.SetValueAndFireSelect(row.SelectSingleNode("OGRENIMKOD").InnerXml);
                ddlUniversite.SetValueAndFireSelect(row.SelectSingleNode("UNIVERSITEKOD").InnerXml);
                ddlFakulte.SetValueAndFireSelect(row.SelectSingleNode("FAKULTEKOD").InnerXml);
                ddlBolum.SetValueAndFireSelect(row.SelectSingleNode("BOLUMKOD").InnerXml);
                txtOkulAdi.Text = row.SelectSingleNode("OKULADI").InnerXml;
                txtBaslamaTarihi.Text = row.SelectSingleNode("BASLANGICTARIHI") != null ? row.SelectSingleNode("BASLANGICTARIHI").InnerXml : "";
                ddlBelgeTur.SetValueAndFireSelect(row.SelectSingleNode("BELGETUR").InnerXml);
                txtBitirmeTarihi.Text = row.SelectSingleNode("BELGETARIHI") != null ? row.SelectSingleNode("BELGETARIHI").InnerXml : "";
                txtBelgeNo.Text = row.SelectSingleNode("BELGENO").InnerXml;
                txtDerecesi.Text = row.SelectSingleNode("DERECE").InnerXml;
                chkGecerli.Checked = OrtakFonksiyonlar.ConvertToInt(row.SelectSingleNode("GECERLI").InnerXml, 0) > 0;
                ddlOgrenimYeri.SetValueAndFireSelect(row.SelectSingleNode("OGRENIMYERI").InnerXml);
                chkDenklik.Checked = OrtakFonksiyonlar.ConvertToInt(row.SelectSingleNode("DENKLIK").InnerXml, 0) > 0;
                if (chkDenklik.Checked)
                {
                    txtDenklikTarihi.Text = row.SelectSingleNode("DENKLIKTARIHI") != null ? row.SelectSingleNode("DENKLIKTARIHI").InnerXml : "";
                    txtDenklikBolum.Text = (row.SelectSingleNode("DENKBOLUM").InnerXml);
                    txtDenklikOkul.Text = row.SelectSingleNode("DENKOKUL").InnerXml;
                }
                else
                {
                    cmpDenklik.Hide();
                    Genel.TarihAlanTemizle(ref txtDenklikTarihi, false);
                    txtDenklikBolum.Text = string.Empty;
                    txtDenklikOkul.Text = string.Empty;
                }
                chkHazirlik.Checked = OrtakFonksiyonlar.ConvertToInt(row.SelectSingleNode("HAZIRLIK").InnerXml, 0) > 0;
                txtKurumIbrazTarihi.Text = row.SelectSingleNode("KURUMAIBRAZTARIHI") != null ? row.SelectSingleNode("KURUMAIBRAZTARIHI").InnerXml : "";
                chkMemuriyeteBaslama.Checked = OrtakFonksiyonlar.ConvertToInt(row.SelectSingleNode("GIRISOKULU").InnerXml, 0) > 0;
                txtOgrenimSuresi.Text = row.SelectSingleNode("OGRENIMSURESI").InnerXml;
            }
            BelgeListesiDoldur();
        }

        void Temizle()
        {
            hdnKod.Clear();
            ddlOgrenim.Clear();
            ddlUniversite.Clear();
            ddlFakulte.Clear();
            ddlBolum.Clear();
            txtOkulAdi.Text = "";
            Genel.TarihAlanTemizle(ref txtBaslamaTarihi, false);
            ddlBelgeTur.Text = "";
            txtBelgeNo.Text = "";
            txtDerecesi.Text = "";
            txtBitirmeTarihi.Text = "";
            chkGecerli.Checked = false;
            chkMemuriyeteBaslama.Checked = false;
            ddlOgrenimYeri.Clear();
            chkDenklik.Checked = false;
            cmpDenklik.Hide();
            txtDenklikOkul.Text = "";
            txtDenklikBolum.Clear();
            Genel.TarihAlanTemizle(ref txtDenklikTarihi, false);
            chkHazirlik.Checked = false;
            Genel.TarihAlanTemizle(ref txtKurumIbrazTarihi, false);
            grdListeSelectionModel.ClearSelections();
            BelgeStore.RemoveAll();
            BelgeStore.DataBind();
            txtOgrenimSuresi.Clear();
        }

        bool KayitKontrol()
        {
            string hata = "";

            if (ddlOgrenim.Value == null)
                hata += Resources.InsanKaynaklari.FRMPOG025 + "<br>";
            if (string.IsNullOrEmpty(txtOkulAdi.Text))
                hata += "Okul Adı boş bırakılamaz.<br>";
            //if (string.IsNullOrEmpty(txtBaslamaTarihi.Text))
            //    hata += Resources.InsanKaynaklari.FRMPOG028 + "<br>";
            //if (string.IsNullOrEmpty(txtBitirmeTarihi.Text))
            //    hata += Resources.InsanKaynaklari.FRMPOG029 + "<br>";
            //if (OrtakFonksiyonlar.ConvertToInt(ddlBelgeTur.Value, 0) <= 0)
            //    hata += "Lütfen Belge türünü seçiniz" + "<br>";
            //if (OrtakFonksiyonlar.ConvertToInt(ddlOgrenimYeri.Value, 0) <= 0)
            //    hata += "Lütfen Öğrenim yerini seçiniz" + "<br>";
            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return false;
            }
            else
                return true;
        }

        void OgrenimDoldur()
        {
            ddlOgrenim.Items.Clear();

            object[] tmp1 = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.OGRENIMKOD, 0).ToString().PadLeft(2, '0'), seviye = 2, ozel = true });
            object[] tmp2 = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.OGRENIMKOD2, 0).ToString().PadLeft(2, '0'), seviye = 2, ozel = true });
            object[] tmp = new object[tmp1.Length + tmp2.Length];

            tmp1.CopyTo(tmp, 0);
            tmp2.CopyTo(tmp, tmp1.Length);

            StoreOgrenim.DataSource = tmp;
            StoreOgrenim.DataBind();
        }
        void UniversiteDoldur()
        {
            ddlUniversite.Items.Clear();
            StoreUniversite.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.UNIVERSITEKODU, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreUniversite.DataBind();
        }
        void FakulteDoldur()
        {
            ddlFakulte.Items.Clear();
            StoreFakulte.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.FAKULTEKODU, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreFakulte.DataBind();
        }
        void BolumDoldur()
        {
            ddlBolum.Items.Clear();
            StoreBolum.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.BOLUMKODU, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreBolum.DataBind();
        }
        void OgrenimYeriDoldur()
        {
            ddlOgrenimYeri.Items.Clear();
            StoreOgrenimYeri.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.OGRENIMYERI, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreOgrenimYeri.DataBind();
        }

        void OgrenimBelgeTurDoldur()
        {
            ddlBelgeTur.Items.Clear();
            StoreOgrenimBelgeTur.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.OGRENIMBELGETUR, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreOgrenimBelgeTur.DataBind();
        }

        public object[] OgrenimKodYukle(Sozluk sozluk)
        {
            ObjectArray sozluktmp = new ObjectArray();

            sozluktmp = servisIKY.SozlukListele(sozluk);

            ArrayList al = new ArrayList();
            al.Add(new object[] { 0, "" });
            string[] k;

            foreach (Sozluk s in sozluktmp.objeler)
            {
                k = s.kayitKod.Split('.');
                al.Add(new object[] { s.kod + ":" + OrtakFonksiyonlar.ConvertToInt(k[1], 0), s.ad });
            }

            return (object[])al.ToArray(typeof(object[]));
        }

        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELOGRENIM;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnKod.Value.ToString().Trim()))
            {
                btnKaydet_Click(null, null);
                //GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMPAB040, Resources.InsanKaynaklari.FRMPAB041);
                //return;
            }

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELOGRENIM, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }
    }
}