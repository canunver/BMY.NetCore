﻿using System;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimUnvan : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Unvan Bilgileri";
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                SınıfDoldur();
                Listele(new Unvan());
            }
        }

        public void Listele(Unvan kriter)
        {
            ObjectArray dler = servisIKY.UnvanListele(kriter);

            if (!dler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
                return;
            }

            if (dler.objeler.Count <= 0)
                GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            ListeStore.DataSource = dler.objeler;
            ListeStore.DataBind();
            PagingToolbar1.PageSize = 100;
            PagingToolbar1.SetPageSize(100);
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            Unvan d = new Unvan();
            d.kod = OrtakFonksiyonlar.ConvertToInt(txtUnvanKodu.Text.Trim(), 0);
            d.ad = txtUnvanAdi.Text.Trim();
            d.sinifAdKisa = txtSinifAdiKisa.Text.Trim();
            d.siraNo = OrtakFonksiyonlar.ConvertToInt(txtSiraNo.Text.Trim(), 0);
            Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(txtSiraNo.Text.Trim(), 0) == 0)
                hata = "Sıra No boş bırakılamaz" + "<br>";
            if (txtUnvanKodu.Text.Trim() == "")
                hata += "Unvan Kod bilgisi boş bırakılamaz" + "<br>";
            if (txtUnvanAdi.Text.Trim() == "")
                hata += "Unvan bilgisi boş bırakılamaz" + "<br>";

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            Unvan d = new Unvan();
            d.kod = OrtakFonksiyonlar.ConvertToInt(txtUnvanKodu.Text.Trim(), 0);
            d.ad = txtUnvanAdi.Text;
            d.sinifAdKisa = txtSinifAdiKisa.Text;
            d.siraNo = OrtakFonksiyonlar.ConvertToInt(txtSiraNo.Text.Trim(), 0);
            d.yonetici = chkYonetici.Checked ? 1 : 0;
            d.sinifKod = OrtakFonksiyonlar.ConvertToInt(cmbSinif.Value, 0);
            d.aktif = chkAktif.Checked;
            d.hitapKod = OrtakFonksiyonlar.ConvertToInt(txthitapKod.Text.Trim(), 0);
            Genel.unvanlar = null;
            Sonuc sonuc = servisIKY.UnvanKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele(new Unvan());
                GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            }
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            Unvan d = new Unvan();
            int kod = OrtakFonksiyonlar.ConvertToInt(txtUnvanKodu.Text.Trim(), 0);

            if (kod > 0)
            {
                Genel.unvanlar = null;
                d.kod = kod;
                Sonuc sonuc = servisIKY.UnvanSil(kullanan, d);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    Temizle();
                    Listele(new Unvan());
                    GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
                }
            }
            else
                GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz unvanı seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Listele(new Unvan());
            Temizle();
        }

        void Temizle()
        {
            txtUnvanKodu.Text = "";
            txtUnvanAdi.Text = "";
            txtSinifAdiKisa.Text = "";
            txtSiraNo.Text = "";
            chkYonetici.Checked = false;
            chkAktif.Checked = false;
            cmbSinif.SelectedItem.Value = "";
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            string secilisatir = e.ExtraParams["RowValue"].ToString();
            XmlNode xml = JSON.DeserializeXmlNode("{records:{record:" + secilisatir + "}}");
            foreach (XmlNode row in xml.SelectNodes("records/record"))
            {
                txtUnvanKodu.Text = row.SelectSingleNode("kod").InnerXml;
                txtUnvanAdi.Text = row.SelectSingleNode("ad").InnerXml;
                txtSinifAdiKisa.Text = row.SelectSingleNode("sinifAdKisa").InnerXml;
                txtSiraNo.Text = row.SelectSingleNode("siraNo").InnerXml;
                cmbSinif.SetValueAndFireSelect(row.SelectSingleNode("sinifKod").InnerXml);
                chkYonetici.Checked = OrtakFonksiyonlar.ConvertToInt(row.SelectSingleNode("yonetici").InnerXml, 0) > 0;
                chkAktif.Checked = row.SelectSingleNode("aktif").InnerXml == "true";
                txthitapKod.Text = row.SelectSingleNode("hitapKod").InnerXml;
            }
        }

        void SınıfDoldur()
        {
            cmbSinif.Items.Clear();
            StoreSinif.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.KADROSINIF, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreSinif.DataBind();
        }
    }
}