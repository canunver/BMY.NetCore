﻿<%@ Page Language="C#" CodeBehind="PersonelIzin.aspx.cs" Inherits="InsanKaynaklari.PersonelIzin" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="InsanKaynaklari" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        var imzaTip;

        function SorguAc(alanNo) {
            Ext1.net.Mask.show(); PersonelSorguAc(alanNo); Ext1.net.Mask.hide();
        }

        function Temizle(alanNo) {
            imzaTip = alanNo;
            if (alanNo <= 3) {
                PersonelBilgiYaz("", "");
            }
            else
                YerYaz("", "");
        }

        function Trigger1(p1, p2, trigNo) {
            if (trigNo == 0) SorguAc(1);
            else Temizle(1);

        }

        function Trigger2(p1, p2, trigNo) {
            if (trigNo == 0) SorguAc(2);
            else Temizle(2);
        }

        function Trigger3(p1, p2, trigNo) {
            if (trigNo == 0) SorguAc(3);
            else Temizle(3);
        }

        function Trigger4(p1, p2, trigNo) {
            if (trigNo == 0) SorguAc(4);
            else Temizle(4);
        }

        function PersonelSorguAc(tip) {
            imzaTip = tip;
            if (tip <= 3)
                showPopWin('ListePersonelSec.aspx?menuYok=1', 500, 440, true, null);
            else
                showPopWin("../ButceHazirlikv2/KodAgac.aspx?kodTur=20&cagiran=metot", 480, 310, true, null);
        }

        function personelEkle(secili) {
            PersonelBilgiYaz(secili.kod, secili.AD + " " + secili.SOYAD);
            hidePopWin();
        }

        function KodSecildi(kod, ad) {
            YerYaz(kod, ad);
        }

        function YerYaz(kod, ad) {
            document.getElementById('txtYerAd').value = ad;
            document.getElementById('hdnYerKod').value = kod;
        }

        function PersonelBilgiYaz(personelKod, personelAd) {
            if (imzaTip == 1) {
                document.getElementById('txtImzaAtan').value = personelAd;
                document.getElementById('hdnImzaAtan').value = personelKod;
            }
            else if (imzaTip == 2) {
                document.getElementById('txtTeklifEden').value = personelAd;
                document.getElementById('hdnTeklifEden').value = personelKod;
            }
            else if (imzaTip == 3) {
                document.getElementById('txtYerineGorevli').value = personelAd;
                document.getElementById('hdnYerineGorevli').value = personelKod;
            }
        }

        function ZorunluAlanKontrol() {
            var valid = pnlGiris1.isValid() && pnlGiris2.isValid();
            if (!valid) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return valid;
        }

        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                    function (btn) {
                        if (btn == "yes") {
                            Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                        }
                    });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };

        function IzinTipDegisti() {
            if (ddlIzinTip.value == "6" || ddlIzinTip.value == "15") {
                txtSaglikKurulusu.setVisible(true);
                dfRaporTarihi.setVisible(true);
                txtRaporNo.setVisible(true);
                nfYatiliGecenSure.setVisible(true);
                nfYatiliGecenSure.setFieldLabel("Yatılı Gün");
            }
            else if (ddlIzinTip.value == "11" || ddlIzinTip.value == "12" || ddlIzinTip.value == "13" || ddlIzinTip.value == "14") {
                txtSaglikKurulusu.setVisible(false);
                dfRaporTarihi.setVisible(false);
                txtRaporNo.setVisible(false);
                nfYatiliGecenSure.setVisible(true);
                nfYatiliGecenSure.setFieldLabel("Yevmiye Gün");
            }
            else {
                txtSaglikKurulusu.setVisible(false);
                dfRaporTarihi.setVisible(false);
                txtRaporNo.setVisible(false);
                nfYatiliGecenSure.setVisible(false);
            }
        }

        function satirSecildi(secilenler, satirNo) {
            if (secilenler.selections.items.length > 0) {
                var rec = secilenler.selections.items[secilenler.selections.items.length - 1];
                pnlGiris1.getForm().loadRecord(rec);
                pnlGiris2.getForm().loadRecord(rec);

                txtIzinNotu2.setValue(rec.data["izinNotu2"]);

                IzinTipDegisti();
            }
        }

    </script>
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <ext:Hidden ID="hdnTCKimlikNo" runat="server" />
        <ext:Hidden ID="hdnPersonelKod" runat="server" />
        <ext:Hidden ID="hdnToplamIzin" runat="server" />
        <ext:Hidden ID="hdnToplamKullanilanIzin" runat="server" />
        <ext:Hidden ID="hdnKalanIzin" runat="server" />
        <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
            <Items>
                <ext:Panel ID="FPanel1" runat="server" Border="false" Region="Center" Layout="BorderLayout">
                    <TopBar>
                        <ext:Toolbar ID="Toolbar1" runat="server">
                            <Items>
                                <ext:ExtIzinDonem runat="server" ID="ctlIzinDonem" YilMin="1980" Width="120">
                                    <DirectEvents>
                                        <Change OnEvent="ctlIzinDonem_Degisti">
                                            <ExtraParams>
                                                <ext:Parameter Name="yil" Mode="Raw" Value="ctlIzinDonem.yil" />
                                            </ExtraParams>
                                        </Change>
                                    </DirectEvents>
                                </ext:ExtIzinDonem>
                                <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                    Icon="Disk">
                                    <DirectEvents>
                                        <Click OnEvent="btnKaydet_Click" ViewStateMode="Enabled" Before="return ZorunluAlanKontrol();">
                                            <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                Title="<%$Resources:InsanKaynaklari,FRMPKS075 %>" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            <ExtraParams>
                                                <ext:Parameter Name="yil" Mode="Raw" Value="ctlIzinDonem.yil" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                    Icon="Delete">
                                    <DirectEvents>
                                        <Click OnEvent="btnSil_Click">
                                            <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                                Title="Onay" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            <ExtraParams>
                                                <ext:Parameter Name="yil" Mode="Raw" Value="ctlIzinDonem.yil" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                    Icon="PageWhite">
                                    <DirectEvents>
                                        <Click OnEvent="btnTemizle_Click">
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnYazdir" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMIZN001%>"
                                    Icon="Printer">
                                    <DirectEvents>
                                        <Click OnEvent="btnYazdir_Click" IsUpload="true">
                                            <ExtraParams>
                                                <ext:Parameter Name="yil" Mode="Raw" Value="ctlIzinDonem.yil" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                            </Items>
                        </ext:Toolbar>
                    </TopBar>
                    <Items>
                        <ext:Panel ID="FormPanel1" runat="server" Frame="true" Region="Center" Layout="RowLayout">
                            <Items>
                                <ext:Panel ID="FormPanel3" runat="server" RowHeight="1" AutoScroll="true" Layout="ColumnLayout">
                                    <Items>
                                        <ext:FormPanel ID="pnlGiris1" runat="server" ColumnWidth="0.50" AutoScroll="true"
                                            Padding="5" LabelWidth="80">
                                            <Items>
                                                <ext:Hidden ID="hdnKod" runat="server" DataIndex="kod" />
                                                <ext:ComboBox ID="ddlIzinTip" runat="server" Editable="false" ForceSelection="true"
                                                    FieldLabel="<%$ Resources:InsanKaynaklari, FRMIZN005%>" AnchorHorizontal="95%"
                                                    TriggerAction="All" ValueField="kod" DisplayField="ad" AllowBlank="false" SelectOnFocus="true"
                                                    LabelStyle="font-weight: bold;" DataIndex="izinTurKod">
                                                    <Store>
                                                        <ext:Store ID="IzinTurStore" runat="server">
                                                            <Reader>
                                                                <ext:JsonReader>
                                                                    <Fields>
                                                                        <ext:RecordField Name="ad" />
                                                                        <ext:RecordField Name="kod" Type="Int" />
                                                                        <ext:RecordField Name="sure" />
                                                                    </Fields>
                                                                </ext:JsonReader>
                                                            </Reader>
                                                        </ext:Store>
                                                    </Store>
                                                    <Listeners>
                                                        <Select Handler="IzinTipDegisti();" />
                                                    </Listeners>
                                                </ext:ComboBox>
                                                <ext:DateField ID="txtBaslama" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMIZN006%>"
                                                    Vtype="daterange" AllowBlank="false" DataIndex="baslangicTarihiDT">
                                                    <CustomConfig>
                                                        <ext:ConfigItem Name="endDateField" Value="#{txtBitis}" Mode="Value" />
                                                    </CustomConfig>
                                                    <DirectEvents>
                                                        <Change OnEvent="GunAl">
                                                        </Change>
                                                    </DirectEvents>
                                                </ext:DateField>
                                                <ext:DateField ID="txtBitis" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMIZN007%>"
                                                    Vtype="daterange" AllowBlank="false" DataIndex="bitisTarihiDT">
                                                    <CustomConfig>
                                                        <ext:ConfigItem Name="startDateField" Value="#{txtBaslama}" Mode="Value" />
                                                    </CustomConfig>
                                                    <DirectEvents>
                                                        <Change OnEvent="GunAl">
                                                        </Change>
                                                    </DirectEvents>
                                                </ext:DateField>
                                                <ext:NumberField FieldLabel="Gün" runat="server" ID="txtIzinGun" ReadOnly="true"
                                                    DataIndex="kullanilanGun">
                                                </ext:NumberField>
                                                <ext:TextArea ID="txtIzinYeri" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMIZN008%>"
                                                    AnchorHorizontal="95%" Height="40" DataIndex="izinYeri" />
                                                <ext:DropDownField ID="ddlTelefon" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMIZN010%>"
                                                    TriggerIcon="Combo" AnchorHorizontal="95%" DataIndex="telefon">
                                                    <Component>
                                                        <ext:GridPanel ID="grdTelefon" runat="server" Height="100" AutoExpandColumn="NUMARA"
                                                            Header="false">
                                                            <Store>
                                                                <ext:Store ID="TelefonStore" runat="server">
                                                                    <Reader>
                                                                        <ext:JsonReader>
                                                                            <Fields>
                                                                                <ext:RecordField Name="TIP" />
                                                                                <ext:RecordField Name="NUMARA" />
                                                                            </Fields>
                                                                        </ext:JsonReader>
                                                                    </Reader>
                                                                </ext:Store>
                                                            </Store>
                                                            <ColumnModel ID="ColumnModel2" runat="server">
                                                                <Columns>
                                                                    <ext:Column DataIndex="TIP" Width="30" Header="<%$ Resources:InsanKaynaklari, FRMIZN012%>" />
                                                                    <ext:Column DataIndex="NUMARA" Header="<%$ Resources:InsanKaynaklari, FRMIZN011%>" />
                                                                </Columns>
                                                            </ColumnModel>
                                                            <LoadMask ShowMask="true" />
                                                            <SelectionModel>
                                                                <ext:RowSelectionModel ID="grdTelefonSelectionModel" runat="server">
                                                                    <Listeners>
                                                                        <RowSelect Handler="#{ddlTelefon}.setValue(record.data.NUMARA);" />
                                                                    </Listeners>
                                                                </ext:RowSelectionModel>
                                                            </SelectionModel>
                                                        </ext:GridPanel>
                                                    </Component>
                                                </ext:DropDownField>
                                                <ext:TextField ID="txtBelgeNo" runat="server" Width="150" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG005 %>"
                                                    DataIndex="belgeNo" />
                                                <ext:DateField ID="txtBelgeTarihi" runat="server" Width="110" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG006 %>"
                                                    DataIndex="belgeTarihiDT" />
                                            </Items>
                                        </ext:FormPanel>
                                        <ext:FormPanel ID="pnlGiris2" runat="server" ColumnWidth="0.50" AutoScroll="true"
                                            Padding="5" LabelWidth="80">
                                            <Items>
                                                <ext:DateField ID="txtKayitTarihi" runat="server" FieldLabel="Kayıt Tarihi" Width="100"
                                                    Hidden="true" DataIndex="kayitTarihiDT" />
                                                <ext:TextField ID="txtMemuriyeti" runat="server" FieldLabel="Memuriyeti" AnchorHorizontal="95%"
                                                    Hidden="true" DataIndex="memuriyeti" />
                                                <ext:Hidden ID="hdnYerineGorevli" runat="server" DataIndex="yerineGorevli" />
                                                <ext:TriggerField ID="txtYerineGorevli" runat="server" FieldLabel="Vekalet Eden"
                                                    AnchorHorizontal="95%" Editable="false" DataIndex="yerineGorevliAd">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Search" HideTrigger="false" />
                                                        <ext:FieldTrigger Icon="Clear" HideTrigger="false" />
                                                    </Triggers>
                                                    <Listeners>
                                                        <TriggerClick Fn="Trigger3" />
                                                    </Listeners>
                                                </ext:TriggerField>
                                                <ext:Hidden ID="hdnTeklifEden" runat="server" DataIndex="teklifEden" />
                                                <ext:TriggerField ID="txtTeklifEden" runat="server" FieldLabel="Teklif Eden" AnchorHorizontal="95%"
                                                    Editable="false" DataIndex="teklifEdenAd">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Search" HideTrigger="false" />
                                                        <ext:FieldTrigger Icon="Clear" HideTrigger="false" />
                                                    </Triggers>
                                                    <Listeners>
                                                        <TriggerClick Fn="Trigger2" />
                                                    </Listeners>
                                                </ext:TriggerField>
                                                <ext:Hidden ID="hdnImzaAtan" runat="server" DataIndex="imzalayan" />
                                                <ext:TriggerField ID="txtImzaAtan" runat="server" FieldLabel="Uygun Gören" AnchorHorizontal="95%"
                                                    Editable="false" DataIndex="imzalayanAd">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Search" HideTrigger="false" />
                                                        <ext:FieldTrigger Icon="Clear" HideTrigger="false" />
                                                    </Triggers>
                                                    <Listeners>
                                                        <TriggerClick Fn="Trigger1" />
                                                    </Listeners>
                                                </ext:TriggerField>
                                                <ext:TextArea ID="txtAciklama" runat="server" FieldLabel="Gerekçe" AnchorHorizontal="95%"
                                                    DataIndex="aciklama" Height="40" />
                                                <ext:TextField ID="txtSaglikKurulusu" runat="server" FieldLabel="Sağlık Kuruluşu"
                                                    Hidden="true" AnchorHorizontal="95%" DataIndex="saglikKurulusu" />
                                                <ext:DateField ID="dfRaporTarihi" runat="server" FieldLabel="Rapor Tarihi" Hidden="true"
                                                    Width="100" DataIndex="raporTarihiDT" />
                                                <ext:TextField ID="txtRaporNo" runat="server" FieldLabel="Rapor No" Hidden="true"
                                                    AnchorHorizontal="95%" DataIndex="raporNo" />
                                                <ext:NumberField ID="nfYatiliGecenSure" runat="server" FieldLabel="Yatılı Gün" Hidden="true"
                                                    AnchorHorizontal="95%" DataIndex="yatiliGecenSure" />
                                                <ext:Hidden ID="hdnYerKod" runat="server" DataIndex="yerKod" />
                                                <ext:TriggerField ID="txtYerAd" runat="server" FieldLabel="Yer" AnchorHorizontal="95%"
                                                    Editable="false" DataIndex="yerAd">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Search" HideTrigger="false" />
                                                        <ext:FieldTrigger Icon="Clear" HideTrigger="false" />
                                                    </Triggers>
                                                    <Listeners>
                                                        <TriggerClick Fn="Trigger4" />
                                                    </Listeners>
                                                </ext:TriggerField>
                                            </Items>
                                        </ext:FormPanel>
                                    </Items>
                                </ext:Panel>
                                <ext:GridPanel ID="grdIzinSureler" runat="server" StripeRows="true" TrackMouseOver="true"
                                    Border="true" Height="150">
                                    <Store>
                                        <ext:Store ID="IzinSureStore" runat="server">
                                            <Reader>
                                                <ext:JsonReader>
                                                    <Fields>
                                                        <ext:RecordField Name="TURKOD" Type="Int" />
                                                        <ext:RecordField Name="TUR" />
                                                        <ext:RecordField Name="TOPLAM" Type="Int" />
                                                        <ext:RecordField Name="KULLANDIGI" Type="Int" />
                                                        <ext:RecordField Name="AKTIFKULLANDIGI" Type="Int" />
                                                        <ext:RecordField Name="KALAN" Type="Int" />
                                                        <ext:RecordField Name="DEVREDEN" Type="Int" />
                                                        <ext:RecordField Name="YILICI" Type="Int" />
                                                    </Fields>
                                                </ext:JsonReader>
                                            </Reader>
                                        </ext:Store>
                                    </Store>
                                    <ColumnModel ID="ColumnModel3" runat="server">
                                        <Columns>
                                            <ext:NumberColumn DataIndex="TURKOD" Hidden="true" />
                                            <ext:Column DataIndex="TUR" Header="İzin Türü" Width="100" Align="Left" />
                                            <ext:NumberColumn Format="9" DataIndex="DEVREDEN" Header="Devreden</br>İzin" Align="Right" Width="80" />
                                            <ext:NumberColumn Format="9" DataIndex="YILICI" Header="Aktif Yıl İçi</br>İzin" Align="Right" Width="80" />
                                            <ext:NumberColumn Format="9" DataIndex="TOPLAM" Header="Toplam</br>İzin" Align="Right" Width="80" />
                                            <ext:NumberColumn Format="9" DataIndex="KULLANDIGI" Header="Önceki Yıldan</br>Kullandığı İzin"
                                                Align="Right" Width="80" />
                                            <ext:NumberColumn Format="9" DataIndex="AKTIFKULLANDIGI" Header="Aktif Yıldan</br>Kullandığı İzin"
                                                Align="Right" Width="80" />
                                            <ext:NumberColumn Format="9" DataIndex="KALAN" Header="<%$ Resources:InsanKaynaklari, FRMIZN015%>"
                                                Align="Right" Width="80" />
                                        </Columns>
                                    </ColumnModel>
                                </ext:GridPanel>
                                <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                    TrackMouseOver="true" HideHeaders="true" Height="70" Hidden="false" Border="true">
                                    <Store>
                                        <ext:Store ID="BelgeStore" runat="server">
                                            <Reader>
                                                <ext:JsonReader>
                                                    <Fields>
                                                        <ext:RecordField Name="KOD" />
                                                        <ext:RecordField Name="PKOD" />
                                                        <ext:RecordField Name="KAYITKOD" />
                                                        <ext:RecordField Name="TIP" />
                                                        <ext:RecordField Name="BELGEADI" />
                                                    </Fields>
                                                </ext:JsonReader>
                                            </Reader>
                                        </ext:Store>
                                    </Store>
                                    <ColumnModel ID="ColumnModel4" runat="server">
                                        <Columns>
                                            <ext:RowNumbererColumn />
                                            <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Header="<%$ Resources:InsanKaynaklari,FRMPOG043 %>"
                                                Width="250" />
                                            <ext:CommandColumn Width="30">
                                                <Commands>
                                                    <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPOG044 %>" />
                                                </Commands>
                                            </ext:CommandColumn>
                                            <ext:CommandColumn Width="30">
                                                <Commands>
                                                    <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPOG045 %>" />
                                                </Commands>
                                            </ext:CommandColumn>
                                        </Columns>
                                    </ColumnModel>
                                    <Listeners>
                                        <Command Fn="KomutCalistir" />
                                    </Listeners>
                                    <SelectionModel>
                                        <ext:RowSelectionModel ID="RowSelectionModel2" runat="server" SingleSelect="true">
                                        </ext:RowSelectionModel>
                                    </SelectionModel>
                                    <TopBar>
                                        <ext:Toolbar ID="Toolbar4" runat="server">
                                            <Items>
                                                <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                    ButtonText="<%$ Resources:InsanKaynaklari,FRMPOG046 %>">
                                                    <DirectEvents>
                                                        <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                    </DirectEvents>
                                                </ext:FileUploadField>
                                            </Items>
                                        </ext:Toolbar>
                                    </TopBar>
                                </ext:GridPanel>
                            </Items>
                        </ext:Panel>
                        <ext:Panel runat="server" Region="East" Layout="BorderLayout" Width="400" Border="false">
                            <Items>
                                <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                    Layout="FitLayout" AutoExpandColumn="izinTurAd" Border="true" Region="Center">
                                    <Store>
                                        <ext:Store ID="ListeStore" runat="server">
                                            <Reader>
                                                <ext:JsonReader>
                                                    <Fields>
                                                        <ext:RecordField Name="personelKod" Type="Int" />
                                                        <ext:RecordField Name="kod" Type="Int" />
                                                        <ext:RecordField Name="izinTurKod" Type="Int" />
                                                        <ext:RecordField Name="izinTurAd" />
                                                        <ext:RecordField Name="baslangicTarihiDT" Type="Date" />
                                                        <ext:RecordField Name="bitisTarihiDT" Type="Date" />
                                                        <ext:RecordField Name="kullanilanGun" Type="Int" />
                                                        <ext:RecordField Name="izinYeri" />
                                                        <ext:RecordField Name="aciklama" />
                                                        <ext:RecordField Name="saglikKurulusu" />
                                                        <ext:RecordField Name="kayitTarihiDT" Type="Date" />
                                                        <ext:RecordField Name="memuriyeti" />
                                                        <ext:RecordField Name="telefon" />
                                                        <ext:RecordField Name="belgeNo" />
                                                        <ext:RecordField Name="belgeTarihiDT" Type="Date" />
                                                        <ext:RecordField Name="yerineGorevli" Type="Int" />
                                                        <ext:RecordField Name="yerineGorevliAd" />
                                                        <ext:RecordField Name="teklifEden" Type="Int" />
                                                        <ext:RecordField Name="teklifEdenAd" />
                                                        <ext:RecordField Name="imzalayan" Type="Int" />
                                                        <ext:RecordField Name="imzalayanAd" />
                                                        <ext:RecordField Name="onay" Type="Int" />
                                                        <ext:RecordField Name="onayAd" />
                                                        <ext:RecordField Name="evrEvrakNo" />
                                                        <ext:RecordField Name="raporTarihiDT" Type="Date" />
                                                        <ext:RecordField Name="raporNo" Type="String" />
                                                        <ext:RecordField Name="yatiliGecenSure" Type="Int" />
                                                        <ext:RecordField Name="yerKod" Type="String" />
                                                        <ext:RecordField Name="yerAd" Type="String" />
                                                        <ext:RecordField Name="izinNotu2" />
                                                    </Fields>
                                                </ext:JsonReader>
                                            </Reader>
                                            <SortInfo Field="baslangicTarihiDT" Direction="DESC" />
                                        </ext:Store>
                                    </Store>
                                    <ColumnModel ID="ColumnModel1" runat="server">
                                        <Columns>
                                            <ext:Column ColumnID="izinTurAd" DataIndex="izinTurAd" Header="<%$ Resources:InsanKaynaklari, FRMIZN016%>"
                                                Width="120" />
                                            <ext:DateColumn DataIndex="baslangicTarihiDT" Header="<%$ Resources:InsanKaynaklari, FRMIZN017%>"
                                                Width="100" Format="dd/m/Y" />
                                            <ext:DateColumn DataIndex="bitisTarihiDT" Header="Dönüş Tarihi" Width="90" Align="Center"
                                                Format="dd/m/Y" />
                                            <ext:Column DataIndex="kullanilanGun" Header="<%$ Resources:InsanKaynaklari, FRMIZN019%>"
                                                Width="70" Align="Center" />
                                            <ext:Column DataIndex="onayAd" Header="<%$ Resources:InsanKaynaklari, FRMIZN041%>"
                                                Width="40" Align="Center" Hidden="true" />
                                            <ext:Column DataIndex="izinTurKod" Hidden="true" />
                                            <ext:Column DataIndex="aciklama" Hidden="true" />
                                            <ext:Column DataIndex="telefon" Hidden="true" />
                                            <ext:Column DataIndex="izinYeri" Hidden="true" />
                                            <ext:Column DataIndex="evrEvrakNo" Header="EvrEvrakNo" Hidden="true" />
                                        </Columns>
                                    </ColumnModel>
                                    <SelectionModel>
                                        <ext:RowSelectionModel runat="server" SingleSelect="true">
                                            <Listeners>
                                                <RowSelect Fn="satirSecildi" />
                                            </Listeners>
                                            <DirectEvents>
                                                <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                                    <EventMask ShowMask="true" MinDelay="200" />
                                                    <ExtraParams>
                                                        <ext:Parameter Name="kod" Value="this.getSelected().data.kod" Mode="Raw" />
                                                    </ExtraParams>
                                                </RowSelect>
                                            </DirectEvents>
                                        </ext:RowSelectionModel>
                                    </SelectionModel>
                                    <BottomBar>
                                        <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                                        </ext:PagingToolbar>
                                    </BottomBar>
                                </ext:GridPanel>
                                <ext:Panel runat="server" Layout="FitLayout" Height="120" Region="South" Padding="10">
                                    <Items>
                                        <ext:TextArea ID="txtIzinNotu2" runat="server" FieldLabel="İzin Notu" LabelAlign="Top"></ext:TextArea>
                                    </Items>
                                </ext:Panel>
                            </Items>
                        </ext:Panel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
    </form>
</body>
</html>
