﻿<%@ Page Language="C#" CodeBehind="PersonelAile.aspx.cs" Inherits="InsanKaynaklari.PersonelAile" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        function ZorunluAlanKontrol() {
            if (!pnlformpanel1.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return pnlformpanel1.isValid();
        }

        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                function (btn) {
                    if (btn == "yes") {
                        Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                    }
                });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };
        function YukumlulukAc() {
            if (chkYukumlu.checked) {
                txtYukumlulukBitisTarihi.show();
            }
            else {
                txtYukumlulukBitisTarihi.hide();
            }
        }
    </script>
    <script src="../Personel/ModulScripts/Ortak.js?mc=03022015" type="text/javascript"></script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnPersonelKod" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <ext:Hidden ID="hdnBelgeKod" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="TCKIMLIKNO" />
                    <ext:RecordField Name="ADSOYAD" />
                    <ext:RecordField Name="YAKINLIK" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="yakinlikDerecesiStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="yakininDurumuStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="yakininOgrenimTipiStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="cinsiyetStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click" Before="return ZorunluAlanKontrol();">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                Icon="Delete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnTemizle_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnNufusYazdir2" runat="server" Text="Nüfus Cüzdanı Örneği" Icon="PageWord">
                                <DirectEvents>
                                    <Click OnEvent="NufusYazdir" Timeout="900000" IsUpload="true">
                                        <ExtraParams>
                                            <ext:Parameter Name="Kod" Value="2" Mode="Value" />
                                        </ExtraParams>
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnNufusYazdir1" runat="server" Text="İkametgah İl Muhaberi" Icon="PageWord">
                                <DirectEvents>
                                    <Click OnEvent="NufusYazdir" Timeout="900000" IsUpload="true">
                                        <ExtraParams>
                                            <ext:Parameter Name="Kod" Value="1" Mode="Value" />
                                        </ExtraParams>
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button Icon="Lightbulb" runat="server">
                                <Listeners>
                                    <MouseOver Handler="wndYardim.show();" />
                                    <MouseOut Handler="wndYardim.hide();" />
                                </Listeners>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:Panel runat="server" Frame="true" AutoScroll="true" Padding="5" Region="Center"
                        Layout="RowLayout">
                        <Items>
                            <ext:FormPanel runat="server" Layout="ColumnLayout" Frame="true" RowHeight="1" ID="pnlformpanel1">
                                <Items>
                                    <ext:FormPanel runat="server" ColumnWidth="0.5">
                                        <Items>
                                            <ext:TriggerField ID="txtTCKimlikNo" runat="server" Width="130" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB019%>"
                                                MaxLength="11" AllowBlank="false">
                                                <Triggers>
                                                    <ext:FieldTrigger Icon="Search" />
                                                </Triggers>
                                                <DirectEvents>
                                                    <TriggerClick OnEvent="KimlikBilgisiGetir">
                                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                                    </TriggerClick>
                                                    <SpecialKey Before="return e.getKey() == Ext1.EventObject.ENTER;" OnEvent="KimlikBilgisiGetir">
                                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                                    </SpecialKey>
                                                </DirectEvents>
                                            </ext:TriggerField>
                                            <ext:TextField runat="server" ID="txtAd" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB021%>"
                                                AnchorHorizontal="95%">
                                            </ext:TextField>
                                            <ext:TextField runat="server" ID="txtSoyad" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB022%>"
                                                AnchorHorizontal="95%">
                                            </ext:TextField>
                                            <ext:DateField runat="server" ID="txtDogumTarihi" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB023%>">
                                            </ext:DateField>
                                            <ext:ComboBox runat="server" ID="ddlCinsiyet" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB024%>"
                                                AnchorHorizontal="95%" DisplayField="AD" ValueField="KOD" StoreID="cinsiyetStore">
                                            </ext:ComboBox>
                                        </Items>
                                    </ext:FormPanel>
                                    <ext:FormPanel ID="FormPanel1" runat="server" ColumnWidth="0.5">
                                        <Items>
                                            <ext:ComboBox runat="server" ID="ddlYakinlik" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB025%>"
                                                AnchorHorizontal="95%" DisplayField="AD" ValueField="KOD" StoreID="yakinlikDerecesiStore">
                                            </ext:ComboBox>
                                            <ext:ComboBox runat="server" ID="ddlDurum" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB026%>"
                                                AnchorHorizontal="95%" DisplayField="AD" ValueField="KOD" StoreID="yakininDurumuStore">
                                            </ext:ComboBox>
                                            <ext:ComboBox runat="server" ID="ddlOgrenimTipi" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB045%>"
                                                AnchorHorizontal="95%" DisplayField="AD" ValueField="KOD" StoreID="yakininOgrenimTipiStore">
                                            </ext:ComboBox>
                                            <ext:TextField runat="server" ID="txtMeslek" FieldLabel="Meslek" AnchorHorizontal="95%">
                                            </ext:TextField>
                                            <ext:SpinnerField runat="server" ID="spnEng" FieldLabel="Sak. Drc." MinValue="0" MaxValue="3">
                                            </ext:SpinnerField>
                                            <ext:Checkbox runat="server" ID="chkAGI" BoxLabel="Evet" FieldLabel="AGİ'ne dahil">
                                            </ext:Checkbox>
                                            <ext:Checkbox runat="server" ID="chkYukumlu" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB042%>"
                                                BoxLabel="Evet">
                                                <Listeners>
                                                    <Check Handler="YukumlulukAc();" />
                                                </Listeners>
                                            </ext:Checkbox>
                                            <ext:DateField runat="server" ID="txtYukumlulukBitisTarihi" Hidden="true" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB043%>" />
                                        </Items>
                                    </ext:FormPanel>
                                </Items>
                            </ext:FormPanel>
                            <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                Frame="true" TrackMouseOver="true" StoreID="BelgeStore" HideHeaders="true" Height="200"
                                AnchorHorizontal="96%" HideLabel="true">
                                <ColumnModel ID="ColumnModel2" runat="server">
                                    <Columns>
                                        <ext:RowNumbererColumn />
                                        <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Width="250" />
                                        <ext:CommandColumn Width="30">
                                            <Commands>
                                                <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB037 %>" />
                                            </Commands>
                                        </ext:CommandColumn>
                                        <ext:CommandColumn Width="30">
                                            <Commands>
                                                <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB038 %>" />
                                            </Commands>
                                        </ext:CommandColumn>
                                    </Columns>
                                </ColumnModel>
                                <Listeners>
                                    <Command Fn="KomutCalistir" />
                                </Listeners>
                                <SelectionModel>
                                    <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                    </ext:RowSelectionModel>
                                </SelectionModel>
                                <TopBar>
                                    <ext:Toolbar runat="server">
                                        <Items>
                                            <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                ButtonText="Belge Ekle">
                                                <DirectEvents>
                                                    <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                </DirectEvents>
                                            </ext:FileUploadField>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                            </ext:GridPanel>
                        </Items>
                    </ext:Panel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" Width="350" AutoExpandColumn="ADSOYAD"
                        Border="true" Region="East">
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column ColumnID="ADSOYAD" DataIndex="ADSOYAD" Header="<%$ Resources:InsanKaynaklari,FRMPAB034 %>" />
                                <ext:Column ColumnID="YAKINLIK" DataIndex="YAKINLIK" Header="<%$ Resources:InsanKaynaklari,FRMPAB025 %>" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                <DirectEvents>
                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                        <ExtraParams>
                                            <ext:Parameter Name="kod" Value="this.getSelected().data.KOD" Mode="Raw" />
                                        </ExtraParams>
                                    </RowSelect>
                                </DirectEvents>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <ext:Window runat="server" Hidden="true" Closable="false" Frame="true" Width="300"
        Height="50" X="470" Y="10" ID="wndYardim">
        <Items>
            <ext:Label ID="Label1" runat="server" Icon="Lightbulb" Text="Aile bireyinin, TC Kimlik Numarasını girdikten sonra merceğe basarak bilgilerini getirin. Yakınlık Derecesi ve Durumunu girdikten sonra Kaydet düğmesi ile kayıt edin. Bu işlemi diğer aile bireyleri için tekrarlayın." />
        </Items>
    </ext:Window>
    </form>
</body>
</html>
