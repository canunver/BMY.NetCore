﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelHizmetSureleri.aspx.cs"
    Inherits="InsanKaynaklari.PersonelHizmetSureleri" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnPersonelKod" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel ID="Panel1" runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <Items>
                    <ext:FormPanel ID="pnlformpanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        LabelWidth="200" Region="Center">
                        <Items>
                            <ext:TextField runat="server" ID="txtToplamHizmet" FieldLabel="Toplam Hizmet" NoteAlign="Top"
                                ReadOnly="true" Width="150">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtKAH" FieldLabel="Kıdem Ayliği Hizmeti"
                                ReadOnly="true" NoteAlign="Top" Width="150">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtKHA" FieldLabel="Kazanılmış Hak Aylığı Süresi" NoteAlign="Top" Width="150"
                                ReadOnly="true">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtEKEA" FieldLabel="Emekli Keseneği Esas Aylığı Süresi" NoteAlign="Top"
                                ReadOnly="true" Width="150">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtKurum" FieldLabel="Kurumda Geçen Süre" NoteAlign="Top"
                                ReadOnly="true" Width="150">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtIzin" FieldLabel="İzin Hesabı Süresi" NoteAlign="Top"
                                ReadOnly="true" Width="150">
                            </ext:TextField>
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
