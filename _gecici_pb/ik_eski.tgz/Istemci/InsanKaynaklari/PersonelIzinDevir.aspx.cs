﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Xml;
using TNS.ORG;

namespace InsanKaynaklari
{
    public partial class PersonelIzinDevir : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                formAdi = Resources.InsanKaynaklari.FRMIZD015;
                SayfaUstAltBolumYaz(this);
                ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

                //Sayfaya giriş izni varmı?
                GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

                ctlIzinDonem.YilMaks = DateTime.Now.Year;
                ctlIzinDonem.Yil = IzinArac.DonemYiliBul(DateTime.Now.Year, DateTime.Now.Month);
                ctlPersonelTip.ListeDoldur(TNS.IKY.Arac.PersonelTipListe);
            }
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel İzin Devir bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            int yil = OrtakFonksiyonlar.ConvertToInt(hdnYil.Value, 0);
            string hata = "";
            if (yil == 0)
                hata += Resources.InsanKaynaklari.FRMIZD010;

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.PersonelIzinDevir[] listeBilgileri = (TNS.IKY.PersonelIzinDevir[])Ext.Net.JSON.Deserialize(e.ExtraParams["ListeBilgileri"], typeof(TNS.IKY.PersonelIzinDevir[]));

            if (listeBilgileri.Length > 0)
            {
                Sonuc sonuc = servisIKY.PersonelIzinDevirKaydet(kullanan, listeBilgileri);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    btnListele_Click(null, e);
                    GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.FRMIZD016);
                }
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel İzin DEvir bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnListele_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            if (OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0) == 0)
                hata += Resources.InsanKaynaklari.FRMIZD004;

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.PersonelIzinDevir pid = new TNS.IKY.PersonelIzinDevir();
            pid.yil = ctlIzinDonemYil(e);
            pid.arama = txtGenelSorgu.Text;
            pid.personelTipleri = ctlPersonelTip.Value.ToString();
            ObjectArray pidArr = servisIKY.PersonelIzinDevirListele(kullanan, pid, OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0));
            if (pidArr.sonuc.islemSonuc)
            {
                hdnYil.Value = ctlIzinDonemYil(e);
                hdnBirimKod.Value = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
                ListeStore.DataSource = pidArr.objeler;
                ListeStore.DataBind();
            }
            else
                GenelIslemler.MesajKutusu("Hata", pidArr.sonuc.hataStr);
        }

        private int ctlIzinDonemYil(DirectEventArgs e)
        {
            return OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["yil"], 0);
        }

        protected void btnAktar_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            if (OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0) == 0)
                hata += Resources.InsanKaynaklari.FRMIZD004 + "<br>";

            //if (yil >= DateTime.Now.Year)
            //if (yil != DateTime.Now.Year - 1) //Eski yılları ve sonrakileri yapmaması için sistem yılı -1 olmalı sadece
            //    hata += string.Format(Resources.InsanKaynaklari.FRMIZD018, DateTime.Now.Year - 1) + "<br>";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu("Uyarı", hata);
                return;
            }

            TNS.IKY.PersonelIzinDevir pid = new TNS.IKY.PersonelIzinDevir();
            pid.yil = ctlIzinDonemYil(e);
            pid.arama = txtGenelSorgu.Text;
            pid.personelTipleri = ctlPersonelTip.Value.ToString();
            Sonuc s = servisIKY.PersonelIzinDevirleriAktar(kullanan, pid, OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0));
            if (s.islemSonuc)
            {
                GenelIslemler.MesajKutusu("Bilgi", "Aktarım işlemi başarılı.");
                btnListele_Click(null, e);
            }
            else
                GenelIslemler.MesajKutusu("Hata", s.hataStr);
        }
    }
}

