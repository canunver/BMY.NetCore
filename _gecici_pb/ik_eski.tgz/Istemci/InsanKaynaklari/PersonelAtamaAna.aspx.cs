﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OrtakClass;
using TNS;

namespace InsanKaynaklari
{
    public partial class PersonelAtamaAna : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.FRMKAD024;
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                //int personelTur = OrtakFonksiyonlar.ConvertToInt(Request.QueryString.Get("personelTur"), 0);
                panelIslem.AutoLoad.Url = "PersonelAtama.aspx?menuYok=1";
                panelSorgu.AutoLoad.Url = "PersonelAtamaSorgu.aspx?menuYok=1";
            }
        }
    }
}