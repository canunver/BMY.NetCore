﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelHITAP.aspx.cs"
    Inherits="InsanKaynaklari.PersonelHITAP" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript">
        var OrgBirimDoldur = function (node) {
            var orgBirim = { personelMi: 1, yetkiliOlduguMuhasebeBirim: hdnYetkiliBirim.value };
            nodeLoadOrgBirimParam(node, orgBirim);
        };

        function KadroYenile(mesaj) {
            alert(mesaj);
            parent.parent.KadroYenile();
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnYetkiliBirim" runat="server" />
    <ext:Hidden ID="hdnPersonelKod" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <ext:Viewport ID="Viewport1" runat="server" Layout="FitLayout">
        <Items>
            <ext:FormPanel ID="pnlformpanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                LabelWidth="150" Region="Center">
                <Items>
                    <ext:TextField runat="server" ID="txtHITAPKul" FieldLabel="HİTAP Kullanıcı Kodu"
                        Width="150" />
                    <ext:TextField runat="server" ID="txtHITAPPar" FieldLabel="HİTAP Parolası" Width="150"
                        InputType="Password" />
                    <ext:ComboBox ID="cmbPersonelTip" runat="server" Editable="false" TypeAhead="true"
                        Mode="Local" ForceSelection="true" SelectOnFocus="true" DisplayField="ad" ValueField="kod"
                        FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS079%>" AnchorHorizontal="96%">
                        <Store>
                            <ext:Store ID="personelTipStore" runat="server">
                                <Reader>
                                    <ext:JsonReader IDProperty="kod">
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="ad" />
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                    </ext:ComboBox>
                    <ext:DropDownField ID="ddlBirim" runat="server" Editable="false" TriggerIcon="Ellipsis"
                        Mode="ValueText" AnchorHorizontal="96%" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>"
                        DataIndex="birimAd">
                        <Triggers>
                            <ext:FieldTrigger Icon="Clear" />
                        </Triggers>
                        <Component>
                            <ext:Panel ID="Panel1" runat="server" Width="400">
                                <Items>
                                    <ext:TreePanel ID="trpBirim" runat="server" Height="250" AutoWidth="true" AutoScroll="true"
                                        Border="false" RootVisible="false">
                                        <Root>
                                            <ext:AsyncTreeNode NodeID="0" Expanded="true" Icon="Note" />
                                        </Root>
                                        <Listeners>
                                            <Click Handler="#{ddlBirim}.setValue(node.id, node.text, false);#{ddlBirim}.collapse();" />
                                        </Listeners>
                                    </ext:TreePanel>
                                </Items>
                            </ext:Panel>
                        </Component>
                        <Listeners>
                            <TriggerClick Handler="ddlBirim.clear()" />
                        </Listeners>
                    </ext:DropDownField>
                </Items>
                <Buttons>
                    <ext:Button Text="Veri Al" Icon="Accept" runat="server" ID="btnVeriAl">
                        <DirectEvents>
                            <Click OnEvent="btnVeriAl_Click" />
                        </DirectEvents>
                    </ext:Button>
                </Buttons>
            </ext:FormPanel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
