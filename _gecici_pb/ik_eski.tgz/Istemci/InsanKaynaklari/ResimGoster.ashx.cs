﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TNS.IKY;
using OrtakClass;
using TNS;

namespace InsanKaynaklari
{
    /// <summary>
    /// Summary description for ResimGoster
    /// </summary>
    public class ResimGoster : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            try
            {
                ResimGosterM(context.Response, TNS.IKY.Arac.Tanimla(), OrtakFonksiyonlar.ConvertToInt(context.Request.QueryString["pKod"], 0), OrtakFonksiyonlar.ConvertToInt(context.Request.QueryString["kucuk"], 0), 0, 0);
            }
            catch {  }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public static void ResimGosterM(System.Web.HttpResponse Response, IIKYServis servisIKY, int kod, int buyukluk, int en, int boy)
        {
            Response.ContentType = "image/jpeg";
            Response.Expires = 0;
            Response.Buffer = true;
            Response.Clear();
            Response.BinaryWrite(servisIKY.PersonelResimGetir(kod, buyukluk, en, boy));
            Response.End();
        }
    }
}