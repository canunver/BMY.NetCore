﻿<%@ Page Language="C#" CodeBehind="PersonelMalBildirimi.aspx.cs" Inherits="InsanKaynaklari.PersonelMalBildirimi" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title></title>

    <link rel="stylesheet" href="../App_themes/BootStrap/css/bootstrap.min.css" />
    <script type="text/javascript" src="../App_themes/BootStrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../App_themes/FontAwesome/css/all.min.css" />

    <link rel="stylesheet" href="../App_themes/AGGrid/ag-grid.min.css" />
    <link rel="stylesheet" href="../App_themes/AGGrid/ag-theme-balham.min.css" />
    <script type="text/javascript" src="../App_themes/AGGrid/ag-grid-community.min.js"></script>

    <script language="javascript" type="text/javascript" src="../Script/strspread.js?v=20260224"></script>
    <script language="JavaScript" type="text/javascript" src="../script/BootstrapMesajKutusu.js?mc=2810201522"></script>

    <style type="text/css">
        html, body {
            height: 100%;
        }

        #content {
            width: 100%;
            padding-right: 2px;
            padding-left: 2px;
        }

        .container-fluid, .container-fluid > .row {
            height: 100%;
            width: 100%;
        }

        .panel-header {
            background-color: #191970;
            color: white;
            padding: 10px;
            font-size: 16px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 5px 5px 0 0;
        }

        .ext-left-panel {
            height: calc(100% - 30px);
            overflow-y: scroll; /* HER ZAMAN scrollbar */
            overflow-x: hidden;
            background-color: #eef4ff; /* resimdeki açık mavi */
            border: 1px solid #b7c9e2;
            padding: 10px;
        }

        .ext-panel {
            border: 1px solid #b7c9e2;
            background: #eef4ff;
            padding: 10px;
            min-height: 260px;
        }

            .ext-panel .panel-titlebar {
                background: #d9e8ff;
                border: 1px solid #b7c9e2;
                padding: 6px 10px;
                margin: -10px -10px 10px -10px;
                font-weight: 600;
            }

        .toolbar-ext {
            background: #d9e8ff;
            border: 1px solid #b7c9e2;
            padding: 3px;
            margin-bottom: 0px;
            width: 100%;
        }

            .toolbar-ext .btn {
                margin-right: 6px;
            }

        /* Ext'teki sıkı form aralığı */
        .form-horizontal .form-group {
            margin-bottom: 8px;
        }

        /* Sağdaki liste başlığı gibi */
        .mini-grid {
            background: #fff;
            border: 1px solid #b7c9e2;
        }

            .mini-grid th {
                background: #f3f6fb;
                font-weight: 600;
            }

        .left-panel, .right-panel {
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: white;
            overflow-y: auto;
        }

        td.saga-hizala {
            text-align: right;
        }

        .table thead th {
            font-weight: bold;
        }

        .no-arrow {
            -moz-appearance: none; /* Firefox */
            -webkit-appearance: none; /* Safari, Chrome */
            appearance: none; /* Standart */
            background: none; /* Arkaplan oku da kaldırır */
            background-color: #fff; /* İstersen rengi ayarla */
        }
    </style>
    <script type="text/javascript">
        function listele() {
            $.ajax({
                url: "PersonelMalBildirimi.aspx/ListeleMalBildirimi",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ pKod: 1 }),
                success: function (response) {
                    var d = response.d;

                    if (!d) {
                        MesajKutusu('Hata', "Sözleşme yüklenirken hata oluştu");
                        return;
                    }

                    if (d.sonuc && d.sonuc.islemSonuc) {
                        listeGridOptionsApi.setRowData(d.objeler);
                    } else {
                        MesajKutusu('Hata', d.sonuc?.hataStr || "Sözleşme yüklenirken hata oluştu");
                    }
                },
                error: function (xhr) {
                    MesajKutusu('Hata', "Listeleme hatası");
                }
            });
        }

        function malBildirimiOku(kayit) {
            $.ajax({
                url: "PersonelMalBildirimi.aspx/OkuMalBildirimi",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ kod: 1 }),
                success: function (response) {
                    const d = response.d;
                    if (!d) {
                        MesajKutusu("Hata", "Sözleşme yüklenirken hata oluştu");
                        return;
                    }

                    if (d.sonuc && d.sonuc.islemSonuc) {
                        var data = d.o;
                        kimlikGridApi?.setRowData(data.kimlikListesi || []);
                        tasinmazGridApi?.setRowData(data.tasinmazListesi || []);
                        kooperatifGridApi?.setRowData(data.kooperatifListesi || []);
                        tasitGridApi?.setRowData(data.tasitListesi || []);
                        digerTasinirGridApi?.setRowData(data.digerTasinirListesi || []);
                        bankaMenkulGridApi?.setRowData(data.bankaMenkulListesi || []);
                        altinMucevherGridApi?.setRowData(data.altinMucevherListesi || []);
                        borcAlacakGridApi?.setRowData(data.borcAlacakListesi || []);
                        digerServetGridApi?.setRowData(data.digerServetListesi || []);
                    }
                    else {
                        MesajKutusu("Hata", d.sonuc?.hataStr || "Sözleşme yüklenirken hata oluştu");
                    }
                },
                error: function (xhr) {
                    MesajKutusu("Hata", "Listeleme hatası");
                    alert();
                }
            });
        }

        let listeGridOptionsApi = null
        let kimlikGridApi = null;
        let tasinmazGridApi = null;
        let kooperatifGridApi = null;
        let tasitGridApi = null;
        let digerTasinirGridApi = null;
        let bankaMenkulGridApi = null;
        let altinMucevherGridApi = null;
        let borcAlacakGridApi = null;
        let digerServetGridApi = null;

        const listeGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { field: "kod", headerName: "Kod", width: 0, editable: false, hide: true },
                {
                    field: "tarihDT", headerName: "Tarih", width: 90, editable: false,
                    valueFormatter: params => {
                        var dt = parseJsonDateDT(params.value);
                        return formatTarih(dt);
                    }
                },
                { field: "aciklama", headerName: "Açıklama", width: 180, editable: false, cellClass: 'ag-cell-wrap-text', autoHeight: true },

            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true,
                filter: false
            },
            onCellClicked: (params) => malBildirimiOku(params),
            onGridReady: function (params) {
                listeGridOptionsApi = params.api;
                listele();
            }
        };

        const kimlikGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { field: "siraNo", headerName: "Sıra No", width: 80, editable: true, type: "LiraKolon" },
                { field: "adiSoyadi", headerName: "Adı Soyadı", width: 220, editable: true, cellClass: 'ag-cell-wrap-text', autoHeight: true },
                {
                    field: "dogumTarihiDT", headerName: "Doğum Tarihi", width: 120, editable: true,
                    valueFormatter: params => {
                        var dt = parseJsonDateDT(params.value);
                        return formatTarih(dt);
                    }
                },
                { field: "dogumYeri", headerName: "Doğum Yeri", width: 150, editable: true },
                { field: "yakinligi", headerName: "Yakınlığı", width: 140, editable: true },
                { field: "tcKimlikNo", headerName: "T.C. Kimlik No", width: 160, editable: true }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true,
                filter: false
            },
            onGridReady: function (params) {
                kimlikGridApi = params.api;
            }
        };

        const tasinmazGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { field: "siraNo", headerName: "Sıra No", width: 80, editable: true, type: "LiraKolon" },
                { field: "degeri", headerName: "Değeri", width: 130, editable: true, cellClass: 'ag-right-aligned-cell', type: "KurusKolon" },
                { field: "tasinmazCinsi", headerName: "Taşınmazın Cinsi", width: 180, editable: true },
                { field: "adres", headerName: "Adresi (Mah., Ada, Parsel)", width: 320, editable: true, cellClass: 'ag-cell-wrap-text', autoHeight: true },
                { field: "hisseMiktari", headerName: "Hisse Miktarı", width: 140, editable: true, type: "LiraKolon" },
                {
                    field: "edinmeTarihiDT", headerName: "Edinme Tarihi", width: 120, editable: true,
                    valueFormatter: params => {
                        var dt = parseJsonDateDT(params.value);
                        return formatTarih(dt);
                    }
                },
                { field: "malikTCKN", headerName: "Malikin T.C. Kimlik No", width: 170, editable: true }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true,
            },
            onGridReady: function (params) {
                tasinmazGridApi = params.api;
            }
        };

        const kooperatifGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { headerName: "Sıra No", field: "siraNo", width: 80, editable: true, type: "LiraKolon" },
                { headerName: "Kooperatifin Adı ve Yeri", field: "kooperatifAdiYeri", width: 320, editable: true, cellClass: 'ag-cell-wrap-text', autoHeight: true },
                { headerName: "Hisse Değeri", field: "hisseDegeri", width: 130, editable: true, type: "KurusKolon", cellClass: "ag-right-aligned-cell", type: "KurusKolon" },
                {
                    headerName: "Üyelik Tarihi", field: "uyelikTarihiDT", width: 130, editable: true, valueFormatter: params => {
                        var dt = parseJsonDateDT(params.value);
                        return formatTarih(dt);
                    }
                },
                { headerName: "Hissedar T.C. Kimlik No", field: "tcKimlikNo", width: 200, editable: true }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true
            },
            onGridReady: function (params) {
                kooperatifGridApi = params.api;
            }
        };

        const tasitGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { headerName: "Sıra No", field: "siraNo", width: 80, editable: true, type: "LiraKolon" },
                { headerName: "Plaka No", field: "plakaNo", width: 120, editable: true },
                { headerName: "Taşıtın Cinsi", field: "tasitinCinsi", width: 160, editable: true },
                { headerName: "Taşıtın Markası", field: "tasitinMarkasi", width: 160, editable: true },
                { headerName: "Edinme Değeri", field: "edinmeDegeri", width: 140, editable: true, type: "KurusKolon", cellClass: "ag-right-aligned-cell" },
                { headerName: "Model Yılı", field: "modelYili", width: 110, editable: true, type: "LiraKolon" },
                {
                    headerName: "Edinme Tarihi", field: "edinmeTarihiDT", width: 130, editable: true, valueFormatter: params => {
                        var dt = parseJsonDateDT(params.value);
                        return formatTarih(dt);
                    }
                },
                { headerName: "Sahibinin T.C. Kimlik No", field: "tcKimlikNo", width: 200, editable: true }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true
            },
            onGridReady: function (params) {
                tasitGridApi = params.api;
            }
        };

        const digerTasinirGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { headerName: "Sıra No", field: "siraNo", width: 80, editable: true, type: "LiraKolon" },
                { headerName: "Taşınır Malın Cinsi", field: "tasinirMalCinsi", width: 300, editable: true, cellClass: 'ag-cell-wrap-text', autoHeight: true },
                { headerName: "Edinme Değeri", field: "edinmeDegeri", width: 150, editable: true, type: "KurusKolon", cellClass: "ag-right-aligned-cell" },
                { headerName: "Model Yılı", field: "modelYili", width: 120, editable: true, type: "LiraKolon" },
                {
                    headerName: "Edinme Tarihi", field: "edinmeTarihiDT", width: 140, editable: true, valueFormatter: params => {
                        var dt = parseJsonDateDT(params.value);
                        return formatTarih(dt);
                    }
                },
                { headerName: "Sahibinin T.C. Kimlik No", field: "tcKimlikNo", width: 220, editable: true }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true
            },
            onGridReady: function (params) {
                digerTasinirGridApi = params.api;
            }
        };

        const bankaMenkulGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { headerName: "Sıra No", field: "siraNo", width: 80, editable: true, type: "LiraKolon" },
                { headerName: "Para veya Menkul Değerin Niteliği", field: "nitelik", width: 320, editable: true },
                { headerName: "Miktarı", field: "miktari", width: 140, editable: true, cellClass: "ag-right-aligned-cell", type: "KurusKolon" },
                { headerName: "Cinsi", field: "cinsi", width: 120, editable: true },
                { headerName: "Sahibinin T.C. Kimlik No", field: "tcKimlikNo", width: 220, editable: true }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true
            },
            onGridReady: function (params) {
                bankaMenkulGridApi = params.api;
            }
        };

        const altinMucevherGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { headerName: "Sıra No", field: "siraNo", width: 80, editable: true, type: "LiraKolon" },
                { headerName: "Cinsi", field: "cinsi", width: 260, editable: true },
                { headerName: "Değeri", field: "degeri", width: 150, editable: true, cellClass: "ag-right-aligned-cell", type: "KurusKolon" },
                { headerName: "Miktarı", field: "miktari", width: 130, editable: true, type: "KurusKolon" },
                { headerName: "Sahibinin T.C. Kimlik No", field: "tcKimlikNo", width: 220, editable: true }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true
            },
            onGridReady: function (params) {
                altinMucevherGridApi = params.api;
            }
        };

        const borcAlacakGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { headerName: "Sıra No", field: "siraNo", width: 80, editable: true, type: "LiraKolon" },
                { headerName: "Borçlunun Adı Soyadı", field: "borcluAdi", width: 260, editable: true },
                { headerName: "Alacaklının Adı Soyadı", field: "alacakliAdi", width: 260, editable: true },
                { headerName: "Borç / Alacak Tutarı", field: "tutar", width: 180, editable: true, cellClass: "ag-right-aligned-cell", type: "KurusKolon" }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true
            },
            onGridReady: function (params) {
                borcAlacakGridApi = params.api;
            }
        };

        const digerServetGridOptions = {
            theme: "legacy",
            columnTypes,
            localeText: AGTurkceAyar,
            columnDefs: [
                { headerName: "Sıra No", field: "siraNo", width: 80, editable: true, type: "LiraKolon" },
                { headerName: "Hak veya Beyanı Gerekli Görülen Diğer Servet Unsurları", field: "servetUnsuru", width: 420, editable: true },
                { headerName: "Edinme Şekli", field: "edinmeSekli", width: 200, editable: true },
                { headerName: "Sahibinin T.C. Kimlik No", field: "tcKimlikNo", width: 220, editable: true }
            ],
            rowData: [],
            defaultColDef: {
                resizable: true,
                sortable: true
            },
            onGridReady: function (params) {
                digerServetGridApi = params.api;
            }
        };

        function kimlikGridSatirEkle() {
            if (kimlikGridApi) {
                kimlikGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        adiSoyadi: "",
                        dogumTarihi: "",
                        dogumYeri: "",
                        yakinligi: "",
                        tcKimlikNo: ""
                    }]
                });
            } else {
                console.log("kimlikGridApi hazır değil");
            }
        }

        function tasinmazGridSatirEkle() {
            if (tasinmazGridApi) {
                tasinmazGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        degeri: "",
                        tasinmazCinsi: "",
                        adres: "",
                        hisseMiktari: "",
                        edinmeTarihi: "",
                        malikTCKN: ""
                    }]
                });
            } else {
                console.log("tasinmazGridApi hazır değil");
            }
        }

        function kooperatifGridSatirEkle() {
            if (kooperatifGridApi) {
                kooperatifGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        kooperatifAdiYeri: "",
                        hisseDegeri: "",
                        uyelikTarihi: "",
                        tcKimlikNo: ""
                    }]
                });
            } else {
                console.log("kooperatifGridApi hazır değil");
            }
        }

        function tasitGridSatirEkle() {
            if (tasitGridApi) {
                tasitGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        plakaNo: "",
                        tasitinCinsi: "",
                        tasitinMarkasi: "",
                        edinmeDegeri: "",
                        modelYili: "",
                        edinmeTarihi: "",
                        tcKimlikNo: ""
                    }]
                });
            } else {
                console.log("tasitGridApi hazır değil");
            }
        }

        function digerTasinirGridSatirEkle() {
            if (digerTasinirGridApi) {
                digerTasinirGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        tasinirMalCinsi: "",
                        edinmeDegeri: "",
                        modelYili: "",
                        edinmeTarihi: "",
                        tcKimlikNo: ""
                    }]
                });
            } else {
                console.log("digerTasinirGridApi hazır değil");
            }
        }

        function bankaMenkulGridSatirEkle() {
            if (bankaMenkulGridApi) {
                bankaMenkulGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        nitelik: "",
                        miktari: "",
                        cinsi: "",
                        tcKimlikNo: ""
                    }]
                });
            } else {
                console.log("bankaMenkulGridApi hazır değil");
            }
        }
        function altinMucevherGridSatirEkle() {
            if (altinMucevherGridApi) {
                altinMucevherGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        cinsi: "",
                        degeri: "",
                        miktari: "",
                        tcKimlikNo: ""
                    }]
                });
            } else {
                console.log("altinMucevherGridApi hazır değil");
            }
        }
        function borcAlacakGridSatirEkle() {
            if (borcAlacakGridApi) {
                borcAlacakGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        borcluAdi: "",
                        alacakliAdi: "",
                        tutar: ""
                    }]
                });
            } else {
                console.log("borcAlacakGridApi hazır değil");
            }
        }
        function digerServetGridSatirEkle() {
            if (digerServetGridApi) {
                digerServetGridApi.applyTransaction({
                    add: [{
                        siraNo: "",
                        servetUnsuru: "",
                        edinmeSekli: "",
                        tcKimlikNo: ""
                    }]
                });
            } else {
                console.log("digerServetGridApi hazır değil");
            }
        }

        function gridDataAl(api) {
            const liste = [];

            if (!api) {
                console.log("Grid API boş");
                return liste;
            }

            api.forEachNode(node => {
                liste.push(node.data);
            });

            return liste;
        }

        function kaydetMenkul() {
            const payload = {
                kimlikListesi: gridDataAl(kimlikGridApi),
                tasinmazListesi: gridDataAl(tasinmazGridApi),
                kooperatifListesi: gridDataAl(kooperatifGridApi),
                tasitListesi: gridDataAl(tasitGridApi),
                digerTasinirListesi: gridDataAl(digerTasinirGridApi),
                bankaMenkulListesi: gridDataAl(bankaMenkulGridApi),
                altinMucevherListesi: gridDataAl(altinMucevherGridApi),
                borcAlacakListesi: gridDataAl(borcAlacakGridApi),
                digerServetListesi: gridDataAl(digerServetGridApi)
            };

            console.log("Gönderilen payload:", payload);

            $.ajax({
                url: "PersonelMalBildirimi.aspx/KaydetMenkul",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ menkul: payload }),
                success: function (response) {
                    if (response.d && response.d.islemSonuc) {
                        alert("Tüm tablolar kayıt edildi");
                    } else {
                        alert("Kayıt başarısız");
                    }
                }
            });
        }

        $(document).ready(function () {
            new agGrid.Grid(document.getElementById("gridListe"), listeGridOptions);
            new agGrid.Grid(document.getElementById("gridKimlikBilgileri"), kimlikGridOptions);
            new agGrid.Grid(document.getElementById("gridTasinmazMal"), tasinmazGridOptions);
            new agGrid.Grid(document.getElementById("gridKooperatif"), kooperatifGridOptions);
            new agGrid.Grid(document.getElementById("gridTasit"), tasitGridOptions);
            new agGrid.Grid(document.getElementById("gridDigerTasinir"), digerTasinirGridOptions);
            new agGrid.Grid(document.getElementById("gridBankaMenkul"), bankaMenkulGridOptions);
            new agGrid.Grid(document.getElementById("gridAltinMucevher"), altinMucevherGridOptions);
            new agGrid.Grid(document.getElementById("gridBorcAlacak"), borcAlacakGridOptions);
            new agGrid.Grid(document.getElementById("gridDigerServet"), digerServetGridOptions);
        });
    </script>
</head>
<body>
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <div class="container-fluid page-container" style="margin-left: 0px; border-top: none; padding-left: 0px; padding-right: 0px; border-top: none;">
        <!-- ÜST TOOLBAR -->
        <div class="toolbar-ext">
            <button type="button" class="btn btn-primary btn-sm">
                <span class="glyphicon glyphicon-floppy-disk"></span>&nbsp;Kaydet
            </button>
            <button type="button" class="btn btn-primary btn-sm">
                <span class="glyphicon glyphicon-trash"></span>&nbsp;Sil
            </button>
            <button type="button" class="btn btn-primary btn-sm">
                <span class="glyphicon glyphicon-plus"></span>&nbsp;Yeni Kayıt
            </button>
            <div class="clearfix"></div>
        </div>
        <div class="row" style="margin-left: 0px; margin-right: 0px;">
            <div class="col-md-9 ext-left-panel" style="margin-top: 0; border-top: none;">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h3 class="m-0 font-weight-bold">KİMLİK BİLGİLERİ
                            <button type="button" class="btn btn-primary btn-sm" onclick="kimlikGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridKimlikBilgileri" class="ag-theme-balham full-width m-0 p-0" style="height: 300px;"></div>

                <div class="d-flex justify-content-between align-items-center bolum-header">
                    <h3 class="m-0 font-weight-bold">TAŞINMAZ MAL BİLGİLERİ
                            <button class="btn btn-primary btn-sm" onclick="tasinmazGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridTasinmazMal" class="ag-theme-balham" style="height: 300px;"></div>

                <div class="d-flex justify-content-between align-items-center bolum-header">
                    <h3 class="m-0 font-weight-bold">KOOPERATİF BİLGİLERİ
                            <button class="btn btn-primary btn-sm" onclick="kooperatifGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridKooperatif" class="ag-theme-balham" style="height: 300px;"></div>

                <div class="d-flex justify-content-between align-items-center bolum-header bolum-alt">
                    <h3 class="m-0 font-weight-bold">TAŞIT BİLGİLERİ
                            <button class="btn btn-primary btn-sm" onclick="tasitGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridTasit" class="ag-theme-balham bolum-alt" style="height: 300px;"></div>

                <div class="d-flex justify-content-between align-items-center bolum-header bolum-alt">
                    <h3 class="m-0 font-weight-bold">DİĞER TAŞINIR MALLAR
                            <button class="btn btn-primary btn-sm" onclick="digerTasinirGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridDigerTasinir" class="ag-theme-balham bolum-alt" style="height: 300px;"></div>

                <div class="d-flex justify-content-between align-items-center bolum-header">
                    <h3 class="m-0 font-weight-bold">BANKA VE MENKUL DEĞERLERE AİT BİLGİLER
                            <button class="btn btn-primary btn-sm" onclick="bankaMenkulGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridBankaMenkul" class="ag-theme-balham" style="height: 300px;"></div>

                <div class="d-flex justify-content-between align-items-center bolum-header">
                    <h3 class="m-0 font-weight-bold">ALTIN VE MÜCEVHERAT BİLGİLERİ
                            <button class="btn btn-primary btn-sm" onclick="altinMucevherGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridAltinMucevher" class="ag-theme-balham" style="height: 300px;"></div>

                <div class="d-flex justify-content-between align-items-center bolum-header">
                    <h3 class="m-0 font-weight-bold">BORÇ - ALACAK BİLGİLERİ
                            <button class="btn btn-primary btn-sm" onclick="borcAlacakGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridBorcAlacak" class="ag-theme-balham" style="height: 300px;"></div>

                <div class="d-flex justify-content-between align-items-center bolum-header">
                    <h3 class="m-0 font-weight-bold">HAKLAR VE BEYANI GEREKLİ GÖRÜLEN DİĞER SERVET UNSURLARI
                        <button class="btn btn-primary btn-sm" onclick="digerServetGridSatirEkle()"><i class="fa fa-plus"></i>&nbsp;Ekle</button></h3>
                </div>
                <div id="gridDigerServet" class="ag-theme-balham" style="height: 300px;"></div>
            </div>
            <div class="col-md-3 ext-left-panel" style="margin-top: 0; border-top: none;">
                <div id="gridListe" class="ag-theme-balham" style="height: 100%; width: 100%"></div>
            </div>
        </div>
    </div>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
</body>
</html>
