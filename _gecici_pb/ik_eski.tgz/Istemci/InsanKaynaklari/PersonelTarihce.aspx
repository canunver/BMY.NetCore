﻿<%@ Page Language="C#" CodeBehind="PersonelTarihce.aspx.cs" Inherits="InsanKaynaklari.PersonelTarihce" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript" language="javascript" src="../Personel/ModulScripts/Ortak.js?mc=03022015"></script>
    <script type="text/javascript" language="javascript">
        var renderDegisenAlan = function (value) {
            return '<b>' + value + '</b>'
        };
        var renderYeniDeger = function (value) {
            return "<span style=\"color:green;\">" + value + "</span>";
        };
        var renderEskiDeger = function (value) {
            return "<span style=\"color:red;\">" + value + "</span>";
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />    
    <ext:Hidden ID="hdnPersonelKod" runat="server" />
    <ext:Store ID="ListeStore" runat="server" GroupDir="DESC" GroupField="KATEGORI">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="TARIH" Type="Date" />
                    <ext:RecordField Name="KATEGORI" />
                    <ext:RecordField Name="DEGISENALAN" />
                    <ext:RecordField Name="YENIDEGER" />
                    <ext:RecordField Name="ESKIDEGER" />
                    <ext:RecordField Name="DEGISIKLIKYAPAN" />
                    <ext:RecordField Name="ACIKLAMA1" />
                    <ext:RecordField Name="ACIKLAMA2" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server">
        <Items>
            <ext:BorderLayout ID="BorderLayout3" runat="server">
                <Center MarginsSummary="4">
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="true" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" Border="true"  AutoExpandColumn="DEGISENALAN"
                        Title="<%$ Resources:InsanKaynaklari,FRMPTR001 %>">
                        <View>
                            <ext:GroupingView ID="GroupingView1" HideGroupedColumn="true" runat="server" StartCollapsed="false"
                                GroupTextTpl='{text} ({[values.rs.length]})'>
                            </ext:GroupingView>
                        </View>
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:DateColumn DataIndex="TARIH" Header="<%$ Resources:InsanKaynaklari,FRMPTR002 %>" Width="130" Format="dd.MM.yyyy hh:mm:ss" />
                                <ext:Column DataIndex="DEGISIKLIKYAPAN" Header="<%$ Resources:InsanKaynaklari,FRMPTR003 %>" Width="140" />
                                <ext:Column DataIndex="KATEGORI" Header="<%$ Resources:InsanKaynaklari,FRMPTR004 %>" Width="100" />                               
                                <ext:Column DataIndex="ACIKLAMA2" Header="<%$ Resources:InsanKaynaklari,FRMPTR009 %>" Width="180" Groupable="false">
                                </ext:Column>
                                <ext:Column DataIndex="ACIKLAMA1" Header="<%$ Resources:InsanKaynaklari,FRMPTR008 %>" Width="180" Groupable="false">
                                </ext:Column>
                                <ext:Column DataIndex="DEGISENALAN" Header="<%$ Resources:InsanKaynaklari,FRMPTR005 %>" Width="200">
                                    <Renderer Fn="renderDegisenAlan" />
                                </ext:Column>
                                <ext:Column DataIndex="YENIDEGER" Header="<%$ Resources:InsanKaynaklari,FRMPTR006 %>" Width="200" Groupable="false">
                                    <Renderer Fn="renderYeniDeger" />
                                </ext:Column>
                                <ext:Column DataIndex="ESKIDEGER" Header="<%$ Resources:InsanKaynaklari,FRMPTR007 %>" Width="200" Groupable="false">
                                    <Renderer Fn="renderEskiDeger" />
                                </ext:Column>
                            </Columns>
                        </ColumnModel>
                        <LoadMask ShowMask="true" />
                        <SelectionModel>
                            <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <Plugins>
                            <ext:GroupingSummary ID="GroupingSummary1" runat="server">
                            </ext:GroupingSummary>
                        </Plugins>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="500" DisplayInfo="true"
                                HideRefresh="true" />
                        </BottomBar>
                    </ext:GridPanel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
