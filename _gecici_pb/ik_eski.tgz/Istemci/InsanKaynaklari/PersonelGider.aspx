﻿<%@ Page Language="C#" CodeBehind="PersonelGider.aspx.cs" Inherits="InsanKaynaklari.PersonelGider" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Personel Gider Formu</title>
    <script type="text/javascript" language="javascript">
        function AktarSor() {
            Ext1.Msg.confirm("Uyarı", spnYil.getValue() + " yılı " + spnAy.getValue() + ". ay, " + cmbHarcamaTur.getText() + " verilerini aktarmak istiyor musunuz? Verilerin hepsi silinip tekrar aktarılacaktır.",
                function (btn) {
                    if (btn == "yes") {
                        PerGider.CBVeriAktar();
                    }
                });

        }

        function ZorunluAlanKontrol() {
            if (!pnlformpanel1.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return pnlformpanel1.isValid();
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <ext:Hidden ID="hdnYeni" runat="server" />
        <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
            <Items>
                <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                    <TopBar>
                        <ext:Toolbar ID="Toolbar1" runat="server">
                            <Items>
                                <ext:Button ID="btnKaydet" runat="server" Text="Ekle" Icon="Disk">
                                    <DirectEvents>
                                        <Click OnEvent="btnKaydet_Click" Before="return ZorunluAlanKontrol();">
                                            <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                Title="Onay" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                    Icon="PageWhite">
                                    <DirectEvents>
                                        <Click OnEvent="btnTemizle_Click">
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:ToolbarSpacer runat="server" Width="10px" />
                                <ext:Label runat="server" Text="Yıl:" Width="40" Cls="font-weight:bolder;" />
                                <ext:ToolbarSpacer runat="server" Width="3px" />
                                <ext:SpinnerField runat="server" ID="spnYil" Width="80" />
                                <ext:ToolbarSpacer runat="server" Width="10px" />
                                <ext:Label runat="server" Text="Ay:" Width="40" />
                                <ext:ToolbarSpacer runat="server" Width="3px" />
                                <ext:SpinnerField runat="server" ID="spnAy" Width="80" MinValue="1" MaxValue="12" />
                                <ext:ToolbarSpacer runat="server" Width="3px" />
                                <ext:Button ID="btnListele" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPBI003%>"
                                    Icon="ApplicationGo">
                                    <DirectEvents>
                                        <Click OnEvent="Listele">
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:ToolbarFill runat="server" />
                                <ext:Button ID="btnKumYukle" runat="server" Text="Küm. Yükle" Icon="PageExcel">
                                    <Listeners>
                                        <Click Handler="wndKumYukle.show();" />
                                    </Listeners>
                                </ext:Button>
                                <ext:Button ID="btnAktar" runat="server" Text="Aktar"
                                    Icon="ApplicationCascade">
                                    <Listeners>
                                        <Click Fn="AktarSor" />
                                    </Listeners>
                                </ext:Button>
                            </Items>
                        </ext:Toolbar>
                    </TopBar>
                    <Items>
                        <ext:FormPanel ID="pnlformpanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                            Region="Center">
                            <Items>
                                <ext:ExtOrgSecim runat="server" ID="ddlYerleskeKod" FieldLabel="Harcama Yeri"
                                    AnchorHorizontal="97%" AgacTur="2" AllowBlank="false" />
                                <ext:ComboBox runat="server" ID="cmbHarcamaTur" FieldLabel="Tür" AnchorHorizontal="96%" AllowBlank="false" DisplayField="ad" ValueField="kod" Editable="false">
                                    <Store>
                                        <ext:Store runat="server" ID="stoHarcamaTur">
                                            <Reader>
                                                <ext:JsonReader>
                                                    <Fields>
                                                        <ext:RecordField Name="kod" Type="Int" />
                                                        <ext:RecordField Name="ad" Type="String" />
                                                    </Fields>
                                                </ext:JsonReader>
                                            </Reader>
                                        </ext:Store>
                                    </Store>
                                </ext:ComboBox>
                                <ext:DateField runat="server" ID="txtTarih" AllowBlank="false" FieldLabel="Tarih"
                                    Format="dd.MM.yyyy HH:mm:ss" Width="160">
                                </ext:DateField>
                                <ext:NumberField runat="server" ID="nfUcret" FieldLabel="Tutar" AllowBlank="false">
                                </ext:NumberField>
                            </Items>
                        </ext:FormPanel>
                        <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                            AutoExpandColumn="yerleskeAdi" Region="East" Split="true" Width="700">
                            <Store>
                                <ext:Store ID="ListeStore" runat="server">
                                    <Reader>
                                        <ext:JsonReader>
                                            <Fields>
                                                <ext:RecordField Name="yerleskeKod" Type="Int" />
                                                <ext:RecordField Name="harcamaTur" Type="Int" />
                                                <ext:RecordField Name="tarihDT" Type="Date" />
                                                <ext:RecordField Name="tutar" Type="Float" />
                                                <ext:RecordField Name="yerleskeAdi" />
                                                <ext:RecordField Name="harcamaTurAdi" Type="String" />
                                            </Fields>
                                        </ext:JsonReader>
                                    </Reader>
                                </ext:Store>
                            </Store>
                            <ColumnModel ID="ColumnModel1" runat="server">
                                <Columns>
                                    <ext:DateColumn ColumnID="tarihDT" DataIndex="tarihDT" Header="Zaman" Width="120" Format="dd.MM.yyyy HH:mm:ss" />
                                    <ext:Column ColumnID="harcamaTurAdi" DataIndex="harcamaTurAdi" Header="Türü" Width="80" />
                                    <ext:Column ColumnID="yerleskeAdi" DataIndex="yerleskeAdi" Header="Yer" />
                                    <ext:NumberColumn ColumnID="tutar" DataIndex="tutar" Header="Tutar" Format="9.990,00/i" Align="Right" />
                                </Columns>
                            </ColumnModel>
                            <SelectionModel>
                                <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                    <DirectEvents>
                                        <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                            <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                            <ExtraParams>
                                                <ext:Parameter Name="yerleskeKod" Value="this.getSelected().data.yerleskeKod" Mode="Raw" />
                                                <ext:Parameter Name="harcamaTur" Value="this.getSelected().data.harcamaTur" Mode="Raw" />
                                                <ext:Parameter Name="tarihDT" Value="this.getSelected().data.tarihDT" Mode="Raw" />
                                            </ExtraParams>
                                        </RowSelect>
                                    </DirectEvents>
                                </ext:RowSelectionModel>
                            </SelectionModel>
                        </ext:GridPanel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
        <ext:Window runat="server" ID="wndKumYukle" Modal="true" Hidden="true" Width="400" Height="165" Closable="true" InitCenter="true" Title="Kümülatif Gider Dosyası Yükleme">
            <Items>
                <ext:FormPanel runat="server" ButtonAlign="Center">
                    <Items>
                        <ext:DisplayField runat="server" StyleSpec="color:darkred" Text="<b>A sütununda</b> sicil no veya Kimlik no bulunan, <b>B sütununda</b> tutar bulunan dosya; seçili yıl, ay, harcama yeri ve tür için, seçili ayın son gününe <b>varsa önceki verilerin hepsi silindikten sonra</b> yüklenir. Yüklemek için dosya seçip, yükle tuşuna basınız" HideLabel="true" />
                        <ext:Label runat="server" HideLabel="true" />
                        <ext:FileUploadField runat="server" ID="fuKumDosyaYukle" FieldLabel="Yüklenecek Dosya" />
                    </Items>
                    <Buttons>
                        <ext:Button runat="server" ID="btnKumDosyaYukle" Text="Yükle">
                            <DirectEvents>
                                <Click OnEvent="btnKumDosyaYukle_Click" />
                            </DirectEvents>
                        </ext:Button>
                    </Buttons>
                </ext:FormPanel>
            </Items>
        </ext:Window>
    </form>
</body>
</html>
