﻿using OrtakClass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS;
using TNS.IKY;
using TNS.KYM;

namespace InsanKaynaklari
{
    public partial class IKYIstemciServis : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

            Response.Cache.SetExpires(DateTime.Now);
            string kul = GenelIslemlerIstemci.RequestBul(this, "kul", "");
            string par = GenelIslemlerIstemci.RequestBul(this, "par", "");
            string ekParam = GenelIslemlerIstemci.RequestBul(this, "ekParam", "");
            long t = OrtakFonksiyonlar.ConvertToLong(GenelIslemlerIstemci.RequestBul(this, "t", ""));
            string tc = GenelIslemlerIstemci.RequestBul(this, "p1", "");
            DateTime dt = new DateTime(t);
            Kullanici kullanan = GenelIslemler.SabitKullanici("aktarim", TNS.KYM.ENUMKullaniciTipi.SISTEMYONETICISI);
            if (ekParam == "TarimAktar")
            {
                Sonuc sonuc = servisIKY.TarimVerileriniAktar(tc);
                Response.Write($"Sonuç Hata: {sonuc.hataStr} Sonuç Bilgi: {sonuc.bilgiStr}" );
            }
        }
    }
}