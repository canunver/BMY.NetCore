﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelHizliBilgi.aspx.cs"
    Inherits="InsanKaynaklari.PersonelHizliBilgi" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="FitLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnYenile" runat="server" Text="Yenile" Icon="Reload">
                                <DirectEvents>
                                    <Click OnEvent="Yenile">
                                        <EventMask ShowMask="true" Msg="Personel hızlı bilgi yeniden yükleniyor.." />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="frmBilgi" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        LabelWidth="130" MonitorValid="true">
                        <Items>
                            <ext:FieldSet ID="FieldSet1" runat="server" Title="Özlük Bilgileri">
                                <Items>
                                    <ext:Label ID="lblAd" FieldLabel="Ad" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblSoyad" FieldLabel="Soyad" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblTC" FieldLabel="TC" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblSicil" FieldLabel="Sicil" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                </Items>
                            </ext:FieldSet>
                            <ext:FieldSet ID="FieldSet2" runat="server" Title="İletişim Bilgileri">
                                <Items>
                                    <ext:Label ID="lblDahili" FieldLabel="Dahili Tel" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblCep" FieldLabel="Cep Tel" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblEposta" FieldLabel="E-posta" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                </Items>
                            </ext:FieldSet>
                            <ext:FieldSet ID="FieldSet3" runat="server" Title="Kadro Bilgileri">
                                <Items>
                                    <ext:Label ID="lblHPersonelTur" FieldLabel="Personel Türü" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblBirim" FieldLabel="Birimi" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblGorevYeri" FieldLabel="Görev Yeri" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblHUnvan" FieldLabel="Unvanı" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblVekaletUnvan" FieldLabel="Vekalet Unvanı" runat="server" AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblKurumaBasTar" FieldLabel="Kuruma Başlama Tarihi" runat="server"
                                        AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblKadroDerece" FieldLabel="Kadro Derece/Ek Gösterge" runat="server"
                                        AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblKazanilmisD" FieldLabel="Kazanılmış Kadro Derece/Ek Gösterge" runat="server"
                                        AnchorHorizontal="%96">
                                    </ext:Label>
                                    <ext:Label ID="lblEmekliD" FieldLabel="Emekli Kadro Derece/Ek Gösterge" runat="server"
                                        AnchorHorizontal="%96">
                                    </ext:Label>
                                </Items>
                            </ext:FieldSet>
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
