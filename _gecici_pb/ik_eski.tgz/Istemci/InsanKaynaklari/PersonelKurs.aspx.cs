﻿using System;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.KYM;
using System.Collections;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Eğitim(Kurs) Sınıfı
    /// </summary>
    public partial class PersonelKurs : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public string personelTCKimlikNo = "";

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();

            hdnPKod.Value = (Request.QueryString["personelKod"] + "").Trim();

            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnTemizle.Hidden = true;
            //    btnSil.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                for (int i = 2000; i <= DateTime.Now.Year; i++)
                    ddlYil.Items.Add(new ListItem(i.ToString(), i.ToString()));

                KursDoldur();
                OgrenimYeriDoldur();
                Temizle();

                Listele(new TNS.IKY.PersonelKurs());
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel Eğitim(Kurs) bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel Eğitim(Kurs) tipinde sınıf</param>
        private void Listele(TNS.IKY.PersonelKurs kriter)
        {
            if (string.IsNullOrEmpty(hdnPKod.Value.ToString()))
                return;

            kriter.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);

            ObjectArray pler = servisIKY.PersonelKursListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            List<object> liste = new List<object>();
            foreach (TNS.IKY.PersonelKurs p in pler.objeler)
            {
                liste.Add(new
                {
                    KOD = p.kod,
                    PKOD = p.personelKod,
                    KURSKODU = p.kursKod,
                    TARIH = p.tarih,
                    ALDIGIYER = p.aldigiYer,
                    BASLAMATARIH = p.baslamaTarihi.Oku(),
                    BITIRMETARIH = p.bitirmeTarihi.Oku(),
                    PUAN = p.puan,
                    DERECE = p.derece,
                    KURSADI = p.kursAdi,
                    DERSSAATI = p.dersSaati,
                    EGITIMYERI = p.egitimYeri,
                    YIL = p.yil,
                    DONEM = p.donem,
                    GUN = p.gun,
                    DOSYANO = p.dosyaNo,
                    ACIKLAMA = p.aciklama,
                });
            }
            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Eğitim(Kurs) bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            //if (OrtakFonksiyonlar.ConvertToInt(ddlKurs.Value, 0) == 0)
            //    hata += Resources.InsanKaynaklari.FRMPRK030 + "<br>";
            if (txtKursAdi.Text.Trim() == "" && OrtakFonksiyonlar.ConvertToInt(ddlKurs.Value, 0) != 0)
                txtKursAdi.Text = ddlKurs.SelectedItem.Text;

            if (txtKursAdi.Text.Trim() == "")
                hata += Resources.InsanKaynaklari.FRMPRK031 + "<br>";

            //if (txtBaslamaTarihi.SelectedValue == null)
            //    hata += Resources.InsanKaynaklari.FRMPRK033 + "<br>";
            //if (txtBitirmeTarihi.SelectedValue == null)
            //    hata += Resources.InsanKaynaklari.FRMPRK034 + "<br>";
            //if (txtAlinanYer.Text.Trim() == "")
            //    hata += Resources.InsanKaynaklari.FRMPRK039 + "<br>";
            //if (OrtakFonksiyonlar.ConvertToInt(ddlOgrenimYeri.Value, 0) <= 0)
            //    hata += Resources.InsanKaynaklari.FRMPRK040 + "<br>";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.PersonelKurs k = new TNS.IKY.PersonelKurs();
            k.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) > 0)
                k.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            k.kursKod = OrtakFonksiyonlar.ConvertToInt(ddlKurs.Value, 0);
            k.tarih = new TNSDateTime();
            k.aldigiYer = txtAlinanYer.Text;
            k.baslamaTarihi = Genel.TarihAlaniDegerVer(txtBaslamaTarihi);
            k.bitirmeTarihi = Genel.TarihAlaniDegerVer(txtBitirmeTarihi);
            k.puan = OrtakFonksiyonlar.ConvertToDouble(txtPuan.Text, 0);
            k.derece = txtDerece.Text;
            k.kursAdi = txtKursAdi.Text;
            k.dersSaati = OrtakFonksiyonlar.ConvertToInt(txtDersSaati.Text, 0);
            k.egitimYeri = OrtakFonksiyonlar.ConvertToInt(ddlOgrenimYeri.Value, 0);
            k.yil = OrtakFonksiyonlar.ConvertToInt(ddlYil.Value, 0);
            k.donem = OrtakFonksiyonlar.ConvertToStr(ddlDonem.Value);
            k.gun = OrtakFonksiyonlar.ConvertToInt(txtGun.Text, 0);
            k.dosyaNo = txtDosyaNo.Text;
            k.aciklama = txtAciklama.Text;

            Sonuc sonuc = servisIKY.PersonelKursKaydet(kullanan, k);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                //Temizle();
                hdnKod.Value = sonuc.anahtar;
                Listele(new TNS.IKY.PersonelKurs());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL017);
            }
        }

        /// <summary>
        /// Sil düğmesine basınca ekrandan bilgileri toplayarak silmek için sunucu tarafındaki metodu çağıran metod
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            int pKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            if (pKod <= 0 || kod <= 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPRK043);
                return;
            }

            TNS.IKY.PersonelKurs d = new TNS.IKY.PersonelKurs();
            d.personelKod = pKod;
            d.kod = kod;
            Sonuc sonuc = servisIKY.PersonelKursSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                //PersonelBelgeler belge = new PersonelBelgeler();
                //belge.tcKimlikNo = personelTCKimlikNo;
                //belge.tip = (int)ENUMBELGEFORMTIP.PERSONELKURS;
                //belge.kayitSiraNo = hdnSiraNo.Value.ToString();
                //servisIKY.PersonelBelgeSil(kullanan, belge);

                Temizle();
                Listele(new TNS.IKY.PersonelKurs());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPRK042);
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            string secilisatir = e.ExtraParams["RowValue"].ToString();
            XmlNode xml = JSON.DeserializeXmlNode("{records:{record:" + secilisatir + "}}");
            foreach (XmlNode row in xml.SelectNodes("records/record"))
            {
                hdnKod.Value = RowBul(row, "KOD");
                hdnPKod.Value = RowBul(row, "PKOD");
                ddlKurs.SetValueAndFireSelect(RowBul(row, "KURSKODU"));
                dfTarih.Value = RowBul(row, "TARIH") != null ? RowBul(row, "TARIH") : "";
                txtAlinanYer.Value = RowBul(row, "ALDIGIYER");
                txtBaslamaTarihi.Value = RowBul(row, "BASLAMATARIH") != null ? RowBul(row, "BASLAMATARIH") : "";
                txtBitirmeTarihi.Value = RowBul(row, "BITIRMETARIH") != null ? RowBul(row, "BITIRMETARIH") : "";
                txtPuan.Value = RowBul(row, "PUAN");
                txtDerece.Value = RowBul(row, "DERECE");
                txtKursAdi.Value = RowBul(row, "KURSADI");
                txtDersSaati.Value = RowBul(row, "DERSSAATI");
                ddlOgrenimYeri.SetValueAndFireSelect(RowBul(row, "EGITIMYERI"));
                ddlYil.SetValueAndFireSelect(RowBul(row, "YIL"));
                ddlDonem.SetValueAndFireSelect(RowBul(row, "DONEM"));
                txtGun.Value = OrtakFonksiyonlar.ConvertToInt(RowBul(row, "GUN"), 0);
                txtDosyaNo.Value = RowBul(row, "DOSYANO");
                txtAciklama.Value = RowBul(row, "ACIKLAMA");
            }
            BelgeListesiDoldur();
        }

        private string RowBul(XmlNode row, string alan)
        {
            var tut = row.SelectSingleNode(alan);
            if (tut != null)
                return tut.InnerXml;
            return null;
        }

        void Temizle()
        {
            hdnKod.Clear();
            ddlKurs.Clear();
            ddlYil.Clear();
            ddlDonem.Clear();
            txtAlinanYer.Text = "";
            Genel.TarihAlanTemizle(ref txtBaslamaTarihi, false);
            Genel.TarihAlanTemizle(ref txtBitirmeTarihi, true);
            txtPuan.Clear();
            txtDerece.Clear();
            txtKursAdi.Text = "";
            txtDersSaati.Text = "";
            ddlOgrenimYeri.Clear();
            txtAciklama.Text = "";
            txtDosyaNo.Text = "";
            txtGun.Text = "";
            grdListeSelectionModel.ClearSelections();
            BelgeStore.RemoveAll();
            BelgeStore.DataBind();
        }
        void KursDoldur()
        {
            ddlKurs.Items.Clear();
            StoreKurs.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.KURSKOD, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreKurs.DataBind();
        }
        void OgrenimYeriDoldur()
        {
            ddlOgrenimYeri.Items.Clear();
            StoreEgitimYeri.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.OGRENIMYERI, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreEgitimYeri.DataBind();
        }


        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELKURS;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnKod.Value.ToString().Trim()))
            {
                btnKaydet_Click(null, null);
                //GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMPAB040, Resources.InsanKaynaklari.FRMPAB041);
                //return;
            }

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELKURS, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }
    }
}
