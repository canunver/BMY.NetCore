﻿using System;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Collections;
using TNS.ORG;
using Aspose.Words;
using System.Data;
using System.IO;
using System.Dynamic;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Kadro Sınıfı
    /// </summary>
    public partial class PersonelKadro : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPersonelKod.Value = (Request.QueryString["personelKod"] + "").Trim();

            if (!IsPostBack)
            {
                hdnTANIMSIZ.Text = ResourceManager1.GetIconUrl(Icon.Cross);
                hdnYENI.Text = ResourceManager1.GetIconUrl(Icon.Add);
                hdnAKTIFKAYIT.Text = ResourceManager1.GetIconUrl(Icon.Accept);
                hdnAKTIFKAPANIYOR.Text = ResourceManager1.GetIconUrl(Icon.CheckError);
                hdnAKTIFKAPANDI.Text = ResourceManager1.GetIconUrl(Icon.LockStart);
                hdnAYRILDI.Text = ResourceManager1.GetIconUrl(Icon.Lock);
                hdnREDDEDILDI.Text = ResourceManager1.GetIconUrl(Icon.Cancel);

                hdnYetkiliBirim.Text = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");
                Listele();

                if (TNS.DEG.Arac.ManasKullaniyor())
                    gridBelgeler.Visible = true;

            }
        }

        [DirectMethod]
        public void Listele()
        {
            int personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            if (personelKod == 0)
            {
                return;
            }
            ObjectArray pler = servisIKY.PersonelKadroListele(kullanan, new TNS.IKY.PersonelKadro { personelKod = personelKod }, false);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }
            ListeStore.DataSource = pler.objeler;
            ListeStore.DataBind();

            if (TNS.DEG.Arac.ManasKullaniyor())
                BelgeListesiDoldur();

            //if (pler.objeler.Count > 0)
            //    grdListeSelectionModel.SelectFirstRow();
        }

        protected void HizmetBelgesiYazdir(object sender, DirectEventArgs e)
        {
            TNS.IKY.Personel personel = servisIKY.HizmetBelgesiRaporu(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0));
            string sonucDosyaad = Path.Combine(TNS.OrtakFonksiyonlar.GeciciYolBul(), Path.GetRandomFileName()) + ".docx";
            string dosyaAd = this.raporSablonYol + "\\IKY\\HizmetBelgesi.docx";
            string birim = "", unvan = "";

            Document doc = new Document(dosyaAd);
            DocumentBuilder docb = new DocumentBuilder(doc);
            DataTable data = new DataTable();

            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "TC", personel.tcKimlikNo);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "ESicil", personel.emekliSicilNo);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "KSicil", personel.sicilNo);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "SSicil", personel.sskSicilNo);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "Ad", personel.ad + " " + personel.soyad);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "Dogum", personel.nufus.dogumYeri + " / " + personel.dogumTarihi.ToString());

            string hazirlik = "", lisansustu = "", sonOgrenim = "", ilkOgrenim = "";
            int ogrenimKod = 0;
            foreach (TNS.IKY.PersonelOgrenim o in personel.ogrenim)
            {
                ogrenimKod = OrtakFonksiyonlar.ConvertToInt(o.ogrenimKodKayitKod.Split('.')[1], 0);
                hazirlik = "";
                if (o.memuriyeteBasladigiOkul == 1)
                {
                    ilkOgrenim = o.ogrenimAdi + " / " + o.okulAdi + " / Öğr. Süresi: " + o.ogrenimSuresi + " / " + o.belgeTarihi.ToString();

                    if (o.hazirlikVarMi == 1)
                        hazirlik = "Var";
                    else
                        hazirlik = "Yok";
                }
                if (o.sonOkul == 1)
                    sonOgrenim = o.ogrenimAdi + " / " + o.okulAdi + " / Öğr. Süresi: " + o.ogrenimSuresi + " / " + o.belgeTarihi.ToString();

                if (ogrenimKod == OrtakFonksiyonlar.ConvertToInt(ENUMOgrenimKod.YuksekLisans, 0) || ogrenimKod == OrtakFonksiyonlar.ConvertToInt(ENUMOgrenimKod.Doktora, 0))
                    lisansustu += o.ogrenimAdi + " / " + o.okulAdi + " / Öğr. Süresi: " + o.ogrenimSuresi + " / " + o.belgeTarihi.ToString() + "\n";
            }

            //string kurslar = "";
            //foreach (TNS.IKY.PersonelKurs k in personel.kurs)
            //{
            //    kurslar += k.kursAdi + " / " + k.tarih;
            //}

            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "Ogrenim", ilkOgrenim);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "SonOgrenim", sonOgrenim);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "Hazirlik", hazirlik);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "Lisansustu", lisansustu);

            string askerlik = "";
            if (personel.askerlik != null && personel.askerlik.kod != 0)
            {
                var result = GetYMD(personel.askerlik.askerlikBaslamaTarihi.Oku(), personel.askerlik.terhisTarihi.Oku());
                askerlik = personel.askerlik.askerlikDurumuAd + " " + personel.askerlik.askerlikBaslamaTarihi.ToString() + " - " + personel.askerlik.terhisTarihi.ToString() + " " + result.Years + " yıl " + result.Months + " ay " + result.Days + " gün ";
            }
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "Askerlik", askerlik);

            int hizmetGunu = 0, borclanmaGunu = 0, toplamHizmetGunu = 0, KAHGunu = 0, KHAGunu = 0, EKEAGunu = 0, BHGun = 0;
            int hizmetCnt = 0;
            int birlestirilenCnt = 0;
            int borcCnt = 0;

            DataTable tabHizmetler = new DataTable();
            tabHizmetler.TableName = "Hizmetler";
            tabHizmetler.Columns.Add("Gorev");
            tabHizmetler.Columns.Add("hizmetUnvan");
            tabHizmetler.Columns.Add("Sinif");
            tabHizmetler.Columns.Add("KadroDerece");
            tabHizmetler.Columns.Add("ODED");
            tabHizmetler.Columns.Add("ODEK");
            tabHizmetler.Columns.Add("ODEE");
            tabHizmetler.Columns.Add("KHAD");
            tabHizmetler.Columns.Add("KHAK");
            tabHizmetler.Columns.Add("KHAE");
            tabHizmetler.Columns.Add("EMED");
            tabHizmetler.Columns.Add("EMEK");
            tabHizmetler.Columns.Add("EMEE");
            tabHizmetler.Columns.Add("HBaslamaTarihi");
            tabHizmetler.Columns.Add("HBitisTarihi");
            tabHizmetler.Columns.Add("HizmetSebep");

            DataTable tabBorclanmalar = new DataTable();
            tabBorclanmalar.TableName = "Borclanmalar";
            tabBorclanmalar.Columns.Add("BSebep");
            tabBorclanmalar.Columns.Add("BBaslamaTarihi");
            tabBorclanmalar.Columns.Add("BBitisTarihi");
            tabBorclanmalar.Columns.Add("BorclanmaGun");

            DataTable tabBHizmetler = new DataTable();
            tabBHizmetler.TableName = "Birlestirilenler";
            tabBHizmetler.Columns.Add("BHSebep");
            tabBHizmetler.Columns.Add("BHBaslamaTarihi");
            tabBHizmetler.Columns.Add("BHBitisTarihi");
            tabBHizmetler.Columns.Add("OnSekizAlti");
            tabBHizmetler.Columns.Add("PrimGun");
            tabBHizmetler.Columns.Add("KHADurum");
            tabBHizmetler.Columns.Add("HizmetGun");
            tabBHizmetler.Columns.Add("KidemGun");
            tabBHizmetler.Columns.Add("KHAGun");
            tabBHizmetler.Columns.Add("EKEAGun");

            if (personel.kadrolar.ObjeSayisi > 0)
            {
                foreach (TNS.IKY.PersonelKadro k in personel.kadrolar.objeler)
                {
                    if (k.eskiHizmetTipiFlag == 1) continue;
                    if (string.IsNullOrEmpty(personel.kadro.birimAd))
                        birim = "CUMHURBAŞKANLIĞI GENEL SEKRETERLİĞİ";
                    else
                        birim = k.birimAd;
                    unvan = k.unvanAd;
                    //int hizmetKurumuKayitKod = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.DiziElemanAl(k.hizmetKurumuKayitKod.Split('.'), 1, ""), 0);
                    //if (hizmetKurumuKayitKod == OrtakFonksiyonlar.ConvertToInt(ENUMHizmetKurumu.BORCLANMA, 0))
                    if (k.hizmetHesabi == ENUMHizmetTablolari.Borclanma)
                    {
                        DataRow row = tabBorclanmalar.NewRow();
                        row["BSebep"] = TNS.IKY.Arac.HitapBorcNeviAd(k.hitapBorcNevi);
                        row["BBaslamaTarihi"] = k.atamaTarihi.ToString();
                        row["BBitisTarihi"] = k.ayrilmaTarihi.ToString();
                        row["BorclanmaGun"] = k.hizmetGunSayisi;
                        borclanmaGunu += k.hizmetGunSayisi;
                        tabBorclanmalar.Rows.Add(row);
                        borcCnt++;
                    }
                    //else if (hizmetKurumuKayitKod != OrtakFonksiyonlar.ConvertToInt(ENUMHizmetKurumu.MEMURKURUMU, 0) && hizmetKurumuKayitKod !=
                    //    OrtakFonksiyonlar.ConvertToInt(ENUMHizmetKurumu.MEMURVEKILOGIBI, 0) && hizmetKurumuKayitKod != OrtakFonksiyonlar.ConvertToInt(ENUMHizmetKurumu.MEMURDIGERKURUMLAR, 0))
                    else if (k.hizmetHesabi == ENUMHizmetTablolari.SSK || k.hizmetHesabi == ENUMHizmetTablolari.Bagkur)
                    {
                        birlestirilenCnt++;
                        DataRow row = tabBHizmetler.NewRow();
                        row["BHSebep"] = TNS.IKY.Arac.ENUMSGKNeviAd(k.hitapsgkNevi) + " (" + k.gorevYeri + ")";
                        row["BHBaslamaTarihi"] = k.atamaTarihi.ToString();
                        row["BHBitisTarihi"] = k.ayrilmaTarihi.ToString();
                        row["OnSekizAlti"] = "";
                        row["PrimGun"] = k.hizmetGunSayisi;
                        row["KHADurum"] = TNS.IKY.Arac.HitapKHADurum(k.hitapkhaDurum);
                        row["HizmetGun"] = k.hizmetGunSayisi;
                        row["KidemGun"] = "";
                        row["KHAGun"] = "";
                        row["EKEAGun"] = k.hizmetGunSayisi;
                        BHGun += k.hizmetGunSayisi;
                        tabBHizmetler.Rows.Add(row);
                    }
                    else if (k.hizmetHesabi == ENUMHizmetTablolari.EmekliSandigi)
                    {
                        hizmetCnt++;
                        DataRow row = tabHizmetler.NewRow();
                        row["Gorev"] = k.birimGorevAd;
                        row["hizmetUnvan"] = k.unvanAd;
                        row["Sinif"] = k.sinifKisaAd;
                        row["KadroDerece"] = k.kadroDerece;
                        row["ODED"] = k.odemeyeEsasDerece;
                        row["ODEK"] = k.odemeyeEsasKademe;
                        row["ODEE"] = k.odemeyeEsasEkGosterge;
                        row["KHAD"] = k.kazanilmisHakDerece;
                        row["KHAK"] = k.kazanilmisHakKademe;
                        row["KHAE"] = k.kazanilmisEkGosterge;
                        row["EMED"] = k.emekliyeEsasDerece;
                        row["EMEK"] = k.emekliyeEsasKademe;
                        row["EMEE"] = k.emekliyeEsasEkGosterge;
                        row["HBaslamaTarihi"] = k.atamaTarihi.ToString();
                        row["HBitisTarihi"] = "-";
                        row["HizmetSebep"] = k.hizmetSebebiAd;
                        //if (!(k.kadroDurum == ENUMKadroDurumu.AYRILDIHESAPLAMA || k.kadroDurum == ENUMKadroDurumu.AKTIFUCRETSIZIZIN))
                        hizmetGunu += k.hizmetGunSayisi;
                        tabHizmetler.Rows.Add(row);
                        if (k.ayrilmaGerekcesiTip == ENUMHizmetSebebiNevi.AYRILMA)
                        {
                            row = tabHizmetler.NewRow();
                            row["Gorev"] = k.gorevYeri;
                            row["hizmetUnvan"] = k.unvanAd;
                            row["Sinif"] = k.sinifKisaAd;
                            row["KadroDerece"] = k.kadroDerece;
                            row["ODED"] = k.odemeyeEsasDerece;
                            row["ODEK"] = k.odemeyeEsasKademe;
                            row["ODEE"] = k.odemeyeEsasEkGosterge;
                            row["KHAD"] = k.kazanilmisHakDerece;
                            row["KHAK"] = k.kazanilmisHakKademe;
                            row["KHAE"] = k.kazanilmisEkGosterge;
                            row["EMED"] = k.emekliyeEsasDerece;
                            row["EMEK"] = k.emekliyeEsasKademe;
                            row["EMEE"] = k.emekliyeEsasEkGosterge;
                            row["HizmetSebep"] = k.ayrilmaGerekcesiAd;
                            row["HBaslamaTarihi"] = "-";
                            row["HBitisTarihi"] = k.ayrilmaTarihi.ToString();
                            tabHizmetler.Rows.Add(row);
                        }
                    }
                }

                if (hizmetCnt == 0)
                {
                    DataRow row = tabHizmetler.NewRow();
                    row["Gorev"] = "";
                    row["hizmetUnvan"] = "";
                    row["Sinif"] = "";
                    row["KadroDerece"] = "";
                    row["ODED"] = "";
                    row["ODEK"] = "";
                    row["ODEE"] = "";
                    row["KHAD"] = "";
                    row["KHAK"] = "";
                    row["KHAE"] = "";
                    row["EMED"] = "";
                    row["EMEK"] = "";
                    row["EMEE"] = "";
                    row["HizmetSebep"] = "";
                    row["HBaslamaTarihi"] = "";
                    row["HBitisTarihi"] = "";
                    tabHizmetler.Rows.Add(row);
                }
                if (borcCnt == 0)
                {
                    DataRow row = tabBorclanmalar.NewRow();
                    row["BSebep"] = "";
                    row["BBaslamaTarihi"] = "";
                    row["BBitisTarihi"] = "";
                    row["BorclanmaGun"] = "";
                    tabBorclanmalar.Rows.Add(row);
                }
                if (birlestirilenCnt == 0)
                {
                    DataRow row = tabBHizmetler.NewRow();
                    row["BHSebep"] = "";
                    row["BHBaslamaTarihi"] = "";
                    row["BHBitisTarihi"] = "";
                    row["OnSekizAlti"] = "";
                    row["PrimGun"] = "";
                    row["KHADurum"] = "";
                    row["HizmetGun"] = "";
                    row["KidemGun"] = "";
                    row["KHAGun"] = "";
                    row["EKEAGun"] = "";
                    tabBHizmetler.Rows.Add(row);
                }
            }
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "THizmet", Hizmet.YilAyGunDondur(hizmetGunu));
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "BorclanmaHizmeti", Hizmet.YilAyGunDondur(borclanmaGunu));
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "BHizmetSure", Hizmet.YilAyGunDondur(BHGun));

            foreach (Hizmet h in personel.hizmetSureleri) //Tek personel gidiyor 1 satır dönecek
            {
                toplamHizmetGunu = h.hizmetGunu;
                KAHGunu = h.kidemGunu;
                KHAGunu = h.KHAGunu;
                EKEAGunu = h.EKEAGunu;
            }

            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "ToplamHizmetSuresi", Hizmet.YilAyGunDondur(toplamHizmetGunu));
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "KidemAyligiSuresi", Hizmet.YilAyGunDondur(KAHGunu));
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "KHASuresi", Hizmet.YilAyGunDondur(KHAGunu));
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "EKEASuresi", Hizmet.YilAyGunDondur(EKEAGunu));
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "Kurum", birim);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "Unvan", unvan);

            doc.MailMerge.ExecuteWithRegions(tabHizmetler);
            doc.MailMerge.ExecuteWithRegions(tabBHizmetler);
            doc.MailMerge.ExecuteWithRegions(tabBorclanmalar);

            doc.Save(sonucDosyaad, SaveFormat.Pdf);

            servisIKY.PersonelTarihceKaydet(kullanan, new TNS.IKY.PersonelKadro(), new TNS.IKY.PersonelKadro { personelKod = personel.kod }, ENUMTARIHCE.KADRO, OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), ENUMTARIHCEISLEMTIP.YAZDIR);

            OrtakClass.DosyaIslem.DosyaGonderX(sonucDosyaad, "HizmetBelgesi.pdf", true, "PDF");
        }

        private dynamic GetYMD(DateTime dt1, DateTime dt2)
        {
            int years = 0;
            for (int i = 0; i <= dt2.Year - dt1.Year; i++)
            {
                if (dt1.AddYears(i) <= dt2)
                {
                    years = i;
                }
            }

            var dt1y = dt1.AddYears(years);

            int months = 0;
            for (int i = 0; i < 12; i++)
            {
                if (dt1y.AddMonths(i) <= dt2)
                {
                    months = i;
                }
            }
            var dt1ym = dt1y.AddMonths(months);
            int days = (int)(dt2 - dt1ym).TotalDays;

            var hms = (dt2 - dt1ym.AddDays(days));

            dynamic ymdhms = new ExpandoObject();
            ymdhms.Years = years;
            ymdhms.Months = months;
            ymdhms.Days = days;
            ymdhms.Hours = hms.Hours;
            ymdhms.Minutes = hms.Minutes;
            ymdhms.Hours = hms.Seconds;
            ymdhms.MilliSeconds = hms.Milliseconds;
            ymdhms.HMS = hms;
            return ymdhms;
        }

        protected void btnOnayla_Click(object sender, DirectEventArgs e)
        {
            TNSCollection tc = new TNSCollection();
            for (int i = 0; i < grdListeSelectionModel.SelectedRows.Count; i++)
            {
                TNS.IKY.PersonelKadro kadro = new TNS.IKY.PersonelKadro();
                kadro.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
                kadro.kod = OrtakFonksiyonlar.ConvertToInt(grdListeSelectionModel.SelectedRows[i].RecordID, 0);
                tc.Add(kadro);
            }

            Sonuc sonuc = servisIKY.AtamaOnayBilgileriniGuncelle(kullanan, tc, OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["onayKod"], 5));
            string goster;
            bool listele = true;
            if (!sonuc.islemSonuc)
            {
                goster = sonuc.hataStr;
                listele = false;
            }
            else if (string.IsNullOrWhiteSpace(sonuc.bilgiStr))
                goster = "Seçili işlemlerin durumu başarı ile değiştirildi.";
            else
                goster = sonuc.bilgiStr;
            GenelIslemler.MesajKutusu("sonuç", goster);
            if (listele) Listele();
        }

        protected void btnKisiBorcuYazdir_Click(object sender, DirectEventArgs e)
        {
            string sonucDosyaad = PersonelRaporlari2.MaasIdasiHesaplamaCetveliYazdir(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), this.raporSablonYol, "xlsx");
            OrtakClass.DosyaIslem.DosyaGonderX(sonucDosyaad, "MaasIadesiHesaplamaCetveli.xlsx", true, "xlsx");
        }

        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELKADRO;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);


            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnPersonelKod.Value.ToString().Trim()))
            {
                //btnKaydet_Click(null, null);
                GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMPAB040, Resources.InsanKaynaklari.FRMPAB041);
                return;
            }

            if (OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) == 0)
                return;

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELKADRO, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }

    }
}
