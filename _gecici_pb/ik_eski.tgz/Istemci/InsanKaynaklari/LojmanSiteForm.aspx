﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.LojmanSiteForm" CodeBehind="LojmanSiteForm.aspx.cs" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>
        <%= Resources.InsanKaynaklari.LojmanSite004%></title>
    <script type="text/javascript" language="javascript">
        function SatirDegisti() {
            if (smLojmanSiteListe.hasSelection())
                Ext1.net.DirectMethods.Goster(smLojmanSiteListe.getSelected().data.kod);
        }
        function GRDListeKomutu(komut, rec, sat, sut) {
            BlokaGit(rec.data.kod);
        }
        function BlokaGit(kod) {
            if (kod == 0)
                kod = document.getElementById("txtKod").value;
            if (Number(kod) == 0) {
                Ext1.Msg.alert("Uyarı", "İlk önce site seçiniz", "", "")
                return;
            }
            showPopWinTop('LojmanSiteBlokForm.aspx?menuYok=1&siteKod=' + kod, 1200, 600, true, '', '', true);
        }
        var KomutCalistir = function (command, record, row) {
            var metin = "", aktif = 0;
            if (record.data.aktif == 1)
                metin = "pasif";
            else {
                metin = "aktif";
                aktif = 1;
            }

            Ext1.Msg.confirm("Uyarı", "Kişi yetkisi " + metin + " yapılacak. Onaylıyor musunuz?",
                function (btn) {
                    if (btn == "yes") {
                        Ext1.net.DirectMethods.AktifPasifYap(record.data.kod, aktif);
                    }
                });
        };
        var yetkiTipRenderer = function (value) {
            var r = yetkiTipStore.getById(value);
            if (Ext1.isEmpty(r))
                return "";
            return r.data.AD;
        };
        function PersonelSorguAc() {
            if (txtKod.value == null)
                Ext1.Msg.alert("Uyarı", "İlk önce site seçiniz", "", "");
            else
                showPopWin('LojmanSiteYetki.aspx?menuYok=1&siteKod=' + txtKod.value, 915, 800, true, '');
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager runat="server">
    </ext:ResourceManager>
    <ext:Store ID="yetkiTipStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="yetkiListeStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" Type="Int" />
                    <ext:RecordField Name="pkod" Type="Int" />
                    <ext:RecordField Name="yetkiliOlduguSiteKod" Type="Int" />
                    <ext:RecordField Name="yetkiliOlduguSiteAd" Type="String" />
                    <ext:RecordField Name="aktif" Type="Int" />
                    <ext:RecordField Name="tip" Type="Int" />
                    <ext:RecordField Name="personelAd" Type="String" />
                    <ext:RecordField Name="oturduguSite" Type="String" />
                    <ext:RecordField Name="oturduguBlok" Type="String" />
                    <ext:RecordField Name="oturduguDaire" Type="Int" />
                    <ext:RecordField Name="oturduguPLKod" Type="Int" />
                    <ext:RecordField Name="aktifText" Type="String" />
                    <ext:RecordField Name="tipAd" Type="String" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout" Margins="104 20 10 20">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <%--<ext:Button ID="btnOku" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite035%>"
                                TabIndex="16" Icon="DatabaseConnect">
                                <DirectEvents>
                                    <Click OnEvent="btnOku_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, LojmanSite036%>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>--%>
                            <ext:Button ID="btnYeni" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                TabIndex="18" Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnYeni_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite037%>"
                                TabIndex="17" Icon="DatabaseSave">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click">
                                        <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, LojmanSite038%>"
                                            Message="<%$ Resources:InsanKaynaklari, LojmanSite039%>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, LojmanSite040%>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="Sil" Icon="TableDelete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnBlok" runat="server" Text="Bloklar" Icon="HouseGo">
                                <Listeners>
                                    <Click Handler="BlokaGit(0);"></Click>
                                </Listeners>
                            </ext:Button>
                            <%-- <ext:Button ID="btnYazdir" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite041%>"
                                TabIndex="18" Icon="Printer">
                                <DirectEvents>
                                    <Click OnEvent="btnYazdir_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>--%>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:GridPanel Width="700" Collapsed="false" AutoScroll="true" Region="West" Split="true"
                        Layout="BorderLayout" runat="server" ID="grdLojmanSiteListe">
                        <Store>
                            <ext:Store runat="server" ID="stoLojmanSiteListe">
                                <Reader>
                                    <ext:JsonReader>
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="siteAdi" Type="String" />
                                            <ext:RecordField Name="mahalle" Type="String" />
                                            <ext:RecordField Name="cadde" Type="String" />
                                            <ext:RecordField Name="sokak" Type="String" />
                                            <ext:RecordField Name="semt" Type="String" />
                                            <ext:RecordField Name="ilce" Type="String" />
                                            <ext:RecordField Name="il" Type="String" />
                                            <ext:RecordField Name="yakitKesilecek" Type="Int" />
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <ColumnModel>
                            <Columns>
                                <ext:ImageCommandColumn Width="50" Header="Bloklar">
                                    <Commands>
                                        <ext:ImageCommand Icon="HouseGo" CommandName="1" />
                                    </Commands>
                                </ext:ImageCommandColumn>
                                <ext:Column DataIndex="kod" ColumnID="kod" Header="Kod" Width="50px" />
                                <ext:Column DataIndex="siteAdi" ColumnID="siteAdi" Header="Site Adı" Width="200px" />
                                <ext:Column DataIndex="mahalle" ColumnID="mahalle" Header="Mahalle" Width="150px" />
                                <%--<ext:Column DataIndex="cadde" ColumnID="cadde" Header="Cadde" />
                                <ext:Column DataIndex="sokak" ColumnID="sokak" Header="Sokak" />
                                <ext:Column DataIndex="semt" ColumnID="semt" Header="Semt" />--%>
                                <ext:Column DataIndex="il" ColumnID="il" Header="İl" Width="150px" />
                                <ext:Column DataIndex="ilce" ColumnID="ilce" Header="İlçe" Width="150px" />
                                <ext:CheckColumn DataIndex="yakitKesilecek" ColumnID="yakitKesilecek" Header="Yakıt Kesilsin Mi?"
                                    Width="100px" />
                            </Columns>
                        </ColumnModel>
                        <Plugins>
                            <ext:GridFilters runat="server" ID="GridFilters1" Local="true">
                                <Filters>
                                    <ext:NumericFilter DataIndex="kod" />
                                    <ext:StringFilter DataIndex="siteAdi" />
                                    <ext:StringFilter DataIndex="mahalle" />
                                    <ext:StringFilter DataIndex="il" />
                                    <ext:StringFilter DataIndex="ilce" />
                                    <ext:BooleanFilter DataIndex="yakitKesilecek" />
                                    <%--<ext:DateFilter DataIndex="Date">
                                        <DatePickerOptions runat="server" TodayText="Now" />
                                    </ext:DateFilter>
                                    <ext:ListFilter DataIndex="Size" Options="extra small,small,medium,large,extra large" />--%>
                                </Filters>
                            </ext:GridFilters>
                        </Plugins>
                        <SelectionModel>
                            <ext:RowSelectionModel runat="server" ID="smLojmanSiteListe">
                                <Listeners>
                                    <SelectionChange Fn="SatirDegisti" />
                                </Listeners>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <Listeners>
                            <Command Fn="GRDListeKomutu" />
                        </Listeners>
                    </ext:GridPanel>
                    <ext:FormPanel runat="server" Border="false" Region="Center" Layout="RowLayout" Padding="5"
                        ButtonAlign="Center" AutoScroll="true">
                        <Items>
                            <ext:FormPanel runat="server" Layout="RowLayout" Frame="true" ID="pnlformpanel1">
                                <Items>
                                    <ext:TextField runat="server" Hidden="true" ID="txtKod" TabIndex="1" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite005%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite006%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtsiteAdi" TabIndex="2"
                                        FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite007%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite008%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtmahalle" TabIndex="3"
                                        FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite009%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite010%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtcadde" TabIndex="4" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite011%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite012%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtsokak" TabIndex="5" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite013%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite014%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtsemt" TabIndex="6" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite015%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite016%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtil" TabIndex="8" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite019%>">
                                        <ToolTips>
                                            <ext:ToolTip ID="ToolTip1" Html="<%$ Resources:InsanKaynaklari, LojmanSite020%>"
                                                runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtilce" TabIndex="7" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite017%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite018%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:Checkbox runat="server" ID="chkyakitKesilecek" TabIndex="9" BoxLabel="<%$ Resources:InsanKaynaklari, LojmanSite021%>"
                                        FieldLabel="">
                                        <ToolTips>
                                            <ext:ToolTip ID="ToolTip2" Html="<%$ Resources:InsanKaynaklari, LojmanSite022%>"
                                                runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:Checkbox>
                                    <ext:TextField runat="server" ID="txtkesintiTipi" Hidden="true" TabIndex="10" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite023%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite024%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField runat="server" ID="txtkesintiCevreGideri" Hidden="true" TabIndex="11"
                                        FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite025%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite026%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField runat="server" ID="txtkesintiSuGideri" Hidden="true" TabIndex="12"
                                        FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite027%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite028%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField runat="server" ID="txtkesintiDiger" Hidden="true" TabIndex="13" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite029%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite030%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField runat="server" ID="txtkesintiDigerAciklama" Hidden="true" TabIndex="14"
                                        FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite031%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite032%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField runat="server" ID="txtkesintiOrtakGider" Hidden="true" TabIndex="15"
                                        FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite033%>">
                                        <ToolTips>
                                            <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite034%>" runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                </Items>
                            </ext:FormPanel>
                            <ext:GridPanel ID="grdYetkiListe" runat="server" StoreID="yetkiListeStore" Height="700"
                                Title="Yetkili Olanların ve Sitede Oturanların Listesi">
                                <ColumnModel>
                                    <Columns>
                                        <ext:CommandColumn Header="Aktif/Pasif Yap" Width="90">
                                            <Commands>
                                                <ext:GridCommand Icon="ApplicationGo" CommandName="AktifPasifYap" ToolTip-Text="Aktif/Pasif Yap." />
                                            </Commands>
                                        </ext:CommandColumn>
                                        <%--  <ext:CommandColumn Header="Aktif Yap" Width="70">
                                            <Renderer Fn="AcKapaRenderer" />
                                            <Commands>
                                                <ext:GridCommand Icon="Add" CommandName="AktifYap" ToolTip-Text="Aktif Yap." />
                                            </Commands>
                                        </ext:CommandColumn>--%>
                                        <ext:Column ColumnID="kod" DataIndex="kod" Header="Kod" Hidden="true">
                                        </ext:Column>
                                        <ext:Column ColumnID="personelAd" DataIndex="personelAd" Header="Personel Adı" Width="175">
                                        </ext:Column>
                                        <ext:Column ColumnID="oturduguSite" DataIndex="oturduguSite" Header="Oturduğu Site">
                                        </ext:Column>
                                        <ext:Column ColumnID="oturduguBlok" DataIndex="oturduguBlok" Header="Oturduğu Blok">
                                        </ext:Column>
                                        <ext:Column ColumnID="oturduguDaire" DataIndex="oturduguDaire" Header="Oturduğu Daire">
                                        </ext:Column>
                                        <ext:Column ColumnID="aktifText" DataIndex="aktifText" Header="Aktiflik">
                                        </ext:Column>
                                        <ext:Column ColumnID="tipAd" Width="120" DataIndex="tipAd" Header="Yetki Tipi">
                                        </ext:Column>
                                        <%--  <ext:CheckColumn ColumnID="aktif" DataIndex="aktif" Header="Aktif" Editable="true">
                                            <Editor>
                                                <ext:Checkbox ID="chAktif" runat="server" AllowNegative="false" AllowDecimals="false"
                                                    SelectOnFocus="true" />
                                            </Editor>
                                        </ext:CheckColumn>
                                        <ext:Column ColumnID="tip" DataIndex="tip" Header="Yetki Tipi" Width="200">
                                            <Renderer Fn="yetkiTipRenderer" />
                                            <Editor>
                                                <ext:ComboBox runat="server" ID="ddlYetkiTip" DisplayField="AD" ValueField="KOD"
                                                    StoreID="yetkiTipStore" Mode="Local" TriggerAction="All" Resizable="true" ListWidth="200">
                                                </ext:ComboBox>
                                            </Editor>
                                        </ext:Column>--%>
                                    </Columns>
                                </ColumnModel>
                                <TopBar>
                                    <ext:Toolbar ID="Toolbar3" runat="server">
                                        <Items>
                                            <%-- <ext:Button ID="Button1" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                                Icon="Disk">
                                                <DirectEvents>
                                                    <Click OnEvent="btnYetkiKaydet_Click">
                                                        <ExtraParams>
                                                            <ext:Parameter Name="YetkiListeBilgileri" Value="Ext1.util.JSON.encode(#{grdYetkiListe}.getRowsValues({dirtyRowsOnly: true}))"
                                                                Mode="Raw" />
                                                        </ExtraParams>
                                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                            Title="Onay" />
                                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                                    </Click>
                                                </DirectEvents>
                                            </ext:Button>--%>
                                            <ext:Button Icon="Add" ID="btnEkle" Text="Yetkili Ekle" runat="server">
                                                <Listeners>
                                                    <Click Fn="PersonelSorguAc" />
                                                </Listeners>
                                            </ext:Button>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                                <Listeners>
                                    <Command Fn="KomutCalistir" />
                                </Listeners>
                            </ext:GridPanel>
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
