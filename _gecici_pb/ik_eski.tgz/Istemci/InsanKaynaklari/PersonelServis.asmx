﻿<%@ WebService Language="C#" CodeBehind="PersonelServis.asmx.cs" Class="InsanKaynaklari.PersonelServis" %>
