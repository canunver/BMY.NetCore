﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.HizmetSebebiForm " CodeBehind="HizmetSebebiForm.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>
        <%= Resources.InsanKaynaklari.HizmetSebebi004%></title>
    <script type="text/javascript">
        function satirSecildi(secilenler, satirNo) {
            if (secilenler.selections.items.length > 0)
                frmSebep.getForm().loadRecord(secilenler.selections.items[secilenler.selections.items.length - 1]);
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager runat="server">
    </ext:ResourceManager>
    <ext:Store runat="server" ID="stoTip">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Type="Int" Name="kod" />
                    <ext:RecordField Type="String" Name="ad" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
        <Items>
            <ext:Panel runat="server" Region="Center" Layout="BorderLayout" Margins="104 20 10 20">
                <Items>
                    <ext:Panel runat="server" Region="West" Layout="RowLayout" Width="400">
                        <Items>
                            <ext:FormPanel runat="server" Height="110" Padding="5">
                                <Items>
                                    <ext:TextField runat="server" ID="txtAraAd" FieldLabel="<%$ Resources:InsanKaynaklari, HizmetSebebi007%>"
                                        AnchorHorizontal="90%" />
                                    <ext:ComboBox runat="server" ID="cmbAraTip" FieldLabel="<%$ Resources:InsanKaynaklari, HizmetSebebi011%>"
                                        AnchorHorizontal="90%" StoreID="stoTip" DisplayField="ad" ValueField="kod" Editable="false" />
                                </Items>
                            </ext:FormPanel>
                            <ext:GridPanel runat="server" ID="grdSebepler" RowHeight="1" AutoExpandColumn="sebepAdi">
                                <TopBar>
                                    <ext:Toolbar runat="server">
                                        <Items>
                                            <ext:Button ID="btnListele" runat="server" Text="<%$ Resources:InsanKaynaklari, HizmetSebebi013%>"
                                                TabIndex="5" Icon="DatabaseConnect">
                                                <DirectEvents>
                                                    <Click OnEvent="btnListele_Click">
                                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, HizmetSebebi014%>" />
                                                    </Click>
                                                </DirectEvents>
                                            </ext:Button>
                                            <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, HizmetSebebi019%>"
                                                TabIndex="7" Icon="Delete">
                                                <DirectEvents>
                                                    <Click OnEvent="btnSil_Click">
                                                        <ExtraParams>
                                                            <ext:Parameter Name="satirlar" Mode="Raw" Value="Ext1.util.JSON.encode(grdSebepler.getRowsValues({ selectedOnly: true }))" />
                                                        </ExtraParams>
                                                    </Click>
                                                </DirectEvents>
                                            </ext:Button>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                                <Store>
                                    <ext:Store runat="server" ID="stoSebepler">
                                        <Reader>
                                            <ext:JsonReader>
                                                <Fields>
                                                    <ext:RecordField Type="Int" Name="kod" />
                                                    <ext:RecordField Type="String" Name="sebepAdi" />
                                                    <ext:RecordField Type="Int" Name="tip" />
                                                    <ext:RecordField Type="String" Name="tipAd" />
                                                </Fields>
                                            </ext:JsonReader>
                                        </Reader>
                                    </ext:Store>
                                </Store>
                                <ColumnModel>
                                    <Columns>
                                        <ext:Column DataIndex="kod" ColumnID="kod" Header="#"
                                            Width="40" />
                                        <ext:Column DataIndex="tipAd" ColumnID="tipAd" Header="<%$ Resources:InsanKaynaklari, HizmetSebebi011%>"
                                            Width="100" />
                                        <ext:Column DataIndex="sebepAdi" ColumnID="sebepAdi" Header="<%$ Resources:InsanKaynaklari, HizmetSebebi007%>"
                                            Width="160" />
                                    </Columns>
                                </ColumnModel>
                                <SelectionModel>
                                    <ext:RowSelectionModel SingleSelect="false">
                                        <Listeners>
                                            <RowSelect Fn="satirSecildi" />
                                        </Listeners>
                                    </ext:RowSelectionModel>
                                </SelectionModel>
                            </ext:GridPanel>
                        </Items>
                    </ext:Panel>
                    <ext:FormPanel runat="server" Region="Center" AutoScroll="true" ID="frmSebep">
                        <TopBar>
                            <ext:Toolbar runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, HizmetSebebi015%>"
                                        TabIndex="6" Icon="DatabaseSave">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, HizmetSebebi016%>"
                                                    Message="<%$ Resources:InsanKaynaklari, HizmetSebebi017%>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, HizmetSebebi018%>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:TextField runat="server" ID="txtkod" TabIndex="1" FieldLabel="<%$ Resources:InsanKaynaklari, HizmetSebebi005%>"
                                DataIndex="kod">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, HizmetSebebi006%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtsebepAdi" TabIndex="2" FieldLabel="<%$ Resources:InsanKaynaklari, HizmetSebebi007%>"
                                AnchorHorizontal="90%" DataIndex="sebepAdi">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, HizmetSebebi008%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:ComboBox runat="server" ID="cmbTip" FieldLabel="<%$ Resources:InsanKaynaklari, HizmetSebebi011%>"
                                AnchorHorizontal="90%" StoreID="stoTip" DisplayField="ad" ValueField="kod" Editable="false"
                                DataIndex="tip">
                                <ToolTips>
                                    <ext:ToolTip ID="ToolTip1" Html="<%$ Resources:InsanKaynaklari, HizmetSebebi012%>"
                                        runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:ComboBox>
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
