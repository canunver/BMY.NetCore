﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelHizmetAyari.aspx.cs"
    Inherits="InsanKaynaklari.PersonelHizmetAyari" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        var ayRenderer = function (value) {
            var r = ayStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnPersonelKod" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <ext:Store ID="ayStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel ID="Panel1" runat="server" Border="false" Region="Center" Layout="BorderLayout"
                Flex="1">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:Personel, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <%-- <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnYeniKayit_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>--%>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="FormPanel3" runat="server" Region="North" Padding="15" Margins="5 5 5 5"
                        LabelWidth="200" Height="80">
                        <Items>
                            <ext:ComboBox runat="server" ID="ddlKTAyi" StoreID="ayStore" DisplayField="AD" ValueField="KOD"
                                FieldLabel="KHA Terfi Ayı" AnchorHorizontal="100%" />
                            <ext:DateField runat="server" ID="txtKAcilisTarihi" FieldLabel="KHA Terfi Açılış Tarihi"
                                NoteAlign="Top" AnchorHorizontal="100%" />
                        </Items>
                    </ext:FormPanel>
                    <ext:FormPanel ID="FormPanel2" runat="server" Region="Center" Padding="15" Margins="0 5 5 5"
                        LabelWidth="200">
                        <Items>
                            <ext:ComboBox runat="server" ID="ddlETAyi" StoreID="ayStore" DisplayField="AD" ValueField="KOD"
                                FieldLabel="EKEA Terfi Ayı" AnchorHorizontal="100%" />
                            <ext:DateField runat="server" ID="txtEAcilisTarihi" FieldLabel="EKEA Terfi Açılış Tarihi"
                                NoteAlign="Top" AnchorHorizontal="100%" />
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
