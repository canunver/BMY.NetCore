﻿using System;
using System.Collections;
using System.Data;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;
using System.Collections.Generic;
using Aspose.Words;
using Aspose.Words.Reporting;
using System.IO;
using EkRtfReport;
using System.Dynamic;

namespace InsanKaynaklari
{
    public partial class PersonelAtama : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                formAdi = Resources.InsanKaynaklari.FRMKAD024;
                SayfaUstAltBolumYaz(this);
                ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

                ddlBirim.KullanicininBirimleri = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");
                ddlGorevBirim.KullanicininBirimleri = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");

                int pKod = GenelIslemlerIstemci.RequestBul(this, "personelKod", 0);
                hdnPersonelKod.Text = pKod.ToString();
                int islemNo = OrtakFonksiyonlar.ConvertToInt(Request.QueryString["kod"], 0);
                Listele(islemNo, -1);
                Genel.UnvanDoldur(ddlUnvan, unvanStore);
                ddlVekaletUnvani.Items.Clear();
                //Genel.SozlukDoldur(ddlSinif, sinifStore, OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.KADROSINIF, 0).ToString().PadLeft(2, '0'), false);
                //Genel.HizmetKurumuDoldur(ddlHizmetKurumu, hizmetKurumuStore);
                Genel.HizmetSebebiDoldur(ddlBaslamaGerekcesi, sgkSebepStoreGir, ENUMHizmetSebebiNevi.BASLAMAGRUBU, true);
                Genel.HizmetSebebiDoldur(ddlAyrilmaGerekcesi, sgkSebepStoreCik, ENUMHizmetSebebiNevi.AYRILMAGRUBU, true);
                Genel.PersonelTurDoldur(cmbPersonelTip, personelTipStore, null);
                Genel.AcikKadroDoldur(stoAtanacagiKadro, 0, true, pKod);
            }
        }

        protected void Temizle()
        {
            hdnEskiKadroKod.Clear();
            hdnYeniPKadroKod.Clear();
            hdnYetkiliBirim.Clear();

            txtKisiBilgi.Clear();
            txtOkulBilgi.Clear();
            cmbPersonelTip.Clear();
            ddlBirim.Clear();
            ddlGorevBirim.Clear();
            ddlUnvan.Clear();
            txtKadroDerece.Clear();
            //ddlSinif.Clear();
            txtEvrakNo.Clear();
            txtYasalDayanak.Clear();
            txtOnayTarih.Clear();
            txtMeslekKodu.Clear();
            txtAciklama.Clear();
            txtKadroTarih.Clear();
            txtKazanilmisHakDerece.Clear();
            txtKazanilmisHakKademe.Clear();
            txtKazanilmisHakTarih.Clear();
            txtKazanilmisGosterge.Clear();
            txtKazanilmisEkGosterge.Clear();
            txtOdemeyeEsasDerece.Clear();
            txtOdemeyeEsasKademe.Clear();
            txtOdemeyeEsasTarih.Clear();
            txtOdemeyeEsasGosterge.Clear();
            txtOdemeyeEsasEkGosterge.Clear();
            txtEmekliyeEsasDerece.Clear();
            txtEmekliyeEsasKademe.Clear();
            txtEmekliyeEsasTarih.Clear();
            txtEmekliGosterge.Clear();
            txtEmekliEkGosterge.Clear();
            txtGorevYeri.Clear();
            txtGorevYeriEski.Clear();
            txtAyrilmaTarihi.Clear();
            ddlAyrilmaGerekcesi.Clear();
            txtAyrilmaTarihiEski.Clear();
            txtAyrilmaNedeni.Clear();

            cmbPersonelTipEski.Clear();
            ddlBirimEski.Clear();
            txtAyrilmaNedeniEski.Clear();

            //txtKadroDurumuEski.Clear();
            //txtKadroDurumu.Clear();
            //ddlHizmetKurumu.Clear();
            //ddlHizmetKurumuEski.Clear();
            //ddlSinifEski.Clear();

            ddlVekaletUnvaniEski.Clear();
            ddlVekaletUnvani.Clear();
            ddlUnvanEski.Clear();
            txtKadroDereceEski.Clear();
            txtEvrakNoEski.Clear();
            txtYasalDayanakEski.Clear();
            txtOnayTarihEski.Clear();
            txtMeslekKoduEski.Clear();
            txtAciklamaEski.Clear();
            txtKadroTarihEski.Clear();
            txtKazanilmisHakDereceEski.Clear();
            txtKazanilmisHakKademeEski.Clear();
            txtKazanilmisHakTarihEski.Clear();
            txtKazanilmisGostergeEski.Clear();
            txtKazanilmisEkGostergeEski.Clear();
            txtOdemeyeEsasDereceEski.Clear();
            txtOdemeyeEsasKademeEski.Clear();
            txtOdemeyeEsasTarihEski.Clear();
            txtOdemeyeEsasGostergeEski.Clear();
            txtOdemeyeEsasEkGostergeEski.Clear();
            txtEmekliyeEsasDereceEski.Clear();
            txtEmekliyeEsasKademeEski.Clear();
            txtEmekliyeEsasTarihEski.Clear();
            txtEmekliGostergeEski.Clear();
            txtEmekliEkGostergeEski.Clear();
            txtAtamaTarihi.Clear();
            txtAtamaNedeni.Clear();
            ddlBaslamaGerekcesi.Clear();
            txtHizmetGunu.Clear();
            txtHizmetGunuEski.Clear();

            hdnIliskiliKadroIslemNo.Text = "";
            cmbAtanacagiKadro.Clear();

            GizleAc(0);
        }

        protected void btnKaydet_Click(object sender, EventArgs e)
        {
            TNS.IKY.PersonelKadro d = VeriTopla();
            Sonuc sonuc = servisIKY.PersonelKadroKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);
                Listele(d.kod, d.eskiKod);
                X.AddScript("Degisti();");
            }
        }

        private TNS.IKY.PersonelKadro VeriTopla()
        {
            TNS.IKY.PersonelKadro d = new TNS.IKY.PersonelKadro();
            d.kadroDurum = (ENUMKadroDurumu)OrtakFonksiyonlar.ConvertToInt(hdnYeniKadroDurum.Text, 0);
            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnYeniPKadroKod.Text, 0);
            d.eskiKod = OrtakFonksiyonlar.ConvertToInt(hdnEskiKadroKod.Text, 0);
            d.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, 0);
            d.personelTip = OrtakFonksiyonlar.ConvertToInt(cmbPersonelTip.Value, 0);
            //d.hizmetKurumu = OrtakFonksiyonlar.ConvertToInt(ddlHizmetKurumu.Value, 0);
            HizmetGerekcesiAta(ddlBaslamaGerekcesi.Value, d, 1);
            d.atamaTarihi = Genel.TarihAlaniDegerVer(txtAtamaTarihi);
            d.hizmetSebebi = txtAtamaNedeni.Text;

            d.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
            d.gorevOrganizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlGorevBirim.Value, 0);
            if (d.gorevOrganizasyonKodu == 0)
                d.gorevOrganizasyonKodu = d.organizasyonKodu;
            d.tayinOlacagiBirim = OrtakFonksiyonlar.ConvertToInt(ddlTayinOlacagiBirim.Value, 0);
            d.gorevYeri = txtGorevYeri.Text;

            //Sınıf kaydedilmiyor, unvan kodundan bulunuyor.
            d.unvan = OrtakFonksiyonlar.ConvertToInt(ddlUnvan.Value, 0);
            d.vekilUnvanKod = OrtakFonksiyonlar.ConvertToInt(ddlVekaletUnvani.Value, 0);
            //if (d.vekilUnvanKod == 0)
            //    d.vekilUnvanKod = d.unvan;
            d.evrakNo = txtEvrakNo.Text;
            d.yasalDayanak = txtYasalDayanak.Text;
            d.onayTarih = Genel.TarihAlaniDegerVer(txtOnayTarih);
            d.meslekKodu = txtMeslekKodu.Text;

            d.aciklama = txtAciklama.Text;

            d.kadroDerece = OrtakFonksiyonlar.ConvertToInt(txtKadroDerece.Text, 0);
            d.kadroTarih = Genel.TarihAlaniDegerVer(txtKadroTarih);

            d.kazanilmisHakDerece = OrtakFonksiyonlar.ConvertToInt(txtKazanilmisHakDerece.Text, 0);
            d.kazanilmisHakKademe = OrtakFonksiyonlar.ConvertToInt(txtKazanilmisHakKademe.Text, 0);
            d.kazanilmisHakTarih = Genel.TarihAlaniDegerVer(txtKazanilmisHakTarih);
            d.kazanilmisGosterge = OrtakFonksiyonlar.ConvertToInt(txtKazanilmisGosterge.Text, 0);
            d.kazanilmisEkGosterge = OrtakFonksiyonlar.ConvertToInt(txtKazanilmisEkGosterge.Text, 0);

            d.odemeyeEsasDerece = OrtakFonksiyonlar.ConvertToInt(txtOdemeyeEsasDerece.Text, 0);
            d.odemeyeEsasKademe = OrtakFonksiyonlar.ConvertToInt(txtOdemeyeEsasKademe.Text, 0);
            d.odemeyeEsasTarih = Genel.TarihAlaniDegerVer(txtOdemeyeEsasTarih);
            d.odemeyeEsasGosterge = OrtakFonksiyonlar.ConvertToInt(txtOdemeyeEsasGosterge.Text, 0);
            d.odemeyeEsasEkGosterge = OrtakFonksiyonlar.ConvertToInt(txtOdemeyeEsasEkGosterge.Text, 0);

            d.emekliyeEsasDerece = OrtakFonksiyonlar.ConvertToInt(txtEmekliyeEsasDerece.Text, 0);
            d.emekliyeEsasKademe = OrtakFonksiyonlar.ConvertToInt(txtEmekliyeEsasKademe.Text, 0);
            d.emekliyeEsasTarih = Genel.TarihAlaniDegerVer(txtEmekliyeEsasTarih);
            d.emekliyeEsasGosterge = OrtakFonksiyonlar.ConvertToInt(txtEmekliGosterge.Text, 0);
            d.emekliyeEsasEkGosterge = OrtakFonksiyonlar.ConvertToInt(txtEmekliEkGosterge.Text, 0);

            HizmetGerekcesiAta(ddlAyrilmaGerekcesi.Value, d, 2);
            d.ayrilmaNedeni = txtAyrilmaNedeni.Text;
            d.ayrilmaTarihi = Genel.TarihAlaniDegerVer(txtAyrilmaTarihi);
            d.hizmetGunSayisi = OrtakFonksiyonlar.ConvertToInt(txtHizmetGunu.Text, 0);

            d.iliskiliKadroIslemNo = OrtakFonksiyonlar.ConvertToInt(hdnIliskiliKadroIslemNo.Text, 0);

            string[] secilenKadro = (((string)cmbAtanacagiKadro.Value) + "").Split('-');
            d.atananacagiKadroUnvanKod = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.DiziElemanAl(secilenKadro, 0, ""), 0);
            d.atananacagiKadroDerece = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.DiziElemanAl(secilenKadro, 1, ""), 0);
            return d;
        }

        private void HizmetGerekcesiAta(object o_tipKod, TNS.IKY.PersonelKadro d, int gelGit)
        {
            int tip = 0;
            int kod = 0;

            if (o_tipKod != null)
            {
                string[] tipKod = o_tipKod.ToString().Split('-');
                tip = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.DiziElemanAl(tipKod, 0, ""), 0);
                kod = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.DiziElemanAl(tipKod, 1, ""), 0);
            }

            if (gelGit == 1)
            {
                d.hizmetSebebiTip = (ENUMHizmetSebebiNevi)tip;
                d.hizmetSebebiKod = kod;
            }
            else
            {
                d.ayrilmaGerekcesiTip = (ENUMHizmetSebebiNevi)tip;
                d.ayrilmaGerekcesi = kod;
            }
        }

        protected void btnYeniKayit_Click(object sender, EventArgs e)
        {
            Listele(0, -1);
        }

        [DirectMethod]
        public void Listele(int kadroKod, int eskiKod)
        {
            TNS.IKY.PersonelKadro yeniKadro;
            TNS.IKY.PersonelKadro eskiKadro;
            PersonelHizmetSatiriBul(kadroKod, out yeniKadro, out eskiKadro, eskiKod);
            hdnYeniKadroDurum.Text = ((int)yeniKadro.kadroDurum).ToString();
            hdnYeniPKadroKod.Text = yeniKadro.kod.ToString();
            hdnEskiKadroKod.Text = eskiKadro.kod.ToString();

            cmbPersonelTip.Value = yeniKadro.personelTip;
            cmbPersonelTipEski.Value = eskiKadro.personelTipAd;
            hdnPersonelTipEski.Text = eskiKadro.personelTip.ToString();

            ddlBaslamaGerekcesi.Value = HizmetSebebi.TipKodOl(yeniKadro.hizmetSebebiTip, yeniKadro.hizmetSebebiKod);
            ddlBaslamaGerekcesiEski.Text = eskiKadro.hizmetSebebiAd;

            txtAtamaTarihi.Text = yeniKadro.atamaTarihi.ToString();
            txtAtamaTarihiEski.Text = eskiKadro.atamaTarihi.ToString();

            txtHizmetGrubuYeni.Text = yeniKadro.hizmetHesabi.ToString();
            txtHizmetGrubuEski.Text = eskiKadro.hizmetHesabi.ToString();

            txtAtamaNedeni.Text = yeniKadro.hizmetSebebi;
            txtAtamaNedeniEski.Text = eskiKadro.hizmetSebebi;

            ddlBirim.SetValue(yeniKadro.organizasyonKodu.ToString(), yeniKadro.birimAd);
            ddlGorevBirim.SetValue(yeniKadro.gorevOrganizasyonKodu.ToString(), yeniKadro.gorevBirimAd);

            ddlBirim.Text = yeniKadro.birimAd;
            ddlGorevBirim.Text = yeniKadro.gorevBirimAd;

            ddlBirimEski.Text = eskiKadro.birimAd;
            ddlGorevBirimEski.Text = eskiKadro.gorevBirimAd;

            txtGorevYeri.Text = yeniKadro.gorevYeri;
            txtGorevYeriEski.Text = eskiKadro.gorevYeri;

            if (yeniKadro.unvan > 0)
                ddlUnvan.Value = yeniKadro.unvan;
            ddlUnvanEski.Value = eskiKadro.unvanAd;

            if (yeniKadro.vekilUnvanKod > 0)
                ddlVekaletUnvani.Value = yeniKadro.vekilUnvanKod;
            ddlVekaletUnvaniEski.Value = eskiKadro.vekilUnvanAd;

            txtEvrakNo.Text = yeniKadro.evrakNo;
            txtEvrakNoEski.Text = eskiKadro.evrakNo;

            txtYasalDayanak.Text = yeniKadro.yasalDayanak;
            txtYasalDayanakEski.Text = eskiKadro.yasalDayanak;

            txtOnayTarih.Text = yeniKadro.onayTarih.ToString();
            txtOnayTarihEski.Text = eskiKadro.onayTarih.ToString();

            txtMeslekKodu.Text = yeniKadro.meslekKodu;
            txtMeslekKoduEski.Text = eskiKadro.meslekKodu;

            txtAciklama.Text = yeniKadro.aciklama;
            txtAciklamaEski.Text = eskiKadro.aciklama;

            txtKadroDerece.Text = yeniKadro.kadroDerece.ToString();
            txtKadroTarih.Text = yeniKadro.kadroTarih.ToString();
            txtKadroDereceEski.Text = eskiKadro.kadroDerece.ToString();
            txtKadroTarihEski.Text = eskiKadro.kadroTarih.ToString();

            txtKazanilmisHakDerece.Text = yeniKadro.kazanilmisHakDerece.ToString();
            txtKazanilmisHakKademe.Text = yeniKadro.kazanilmisHakKademe.ToString();
            txtKazanilmisHakTarih.Text = yeniKadro.kazanilmisHakTarih.ToString();
            txtKazanilmisGosterge.Text = yeniKadro.kazanilmisGosterge.ToString();
            txtKazanilmisEkGosterge.Text = yeniKadro.kazanilmisEkGosterge.ToString();
            txtKazanilmisHakDereceEski.Text = eskiKadro.kazanilmisHakDerece.ToString();
            txtKazanilmisHakKademeEski.Text = eskiKadro.kazanilmisHakKademe.ToString();
            txtKazanilmisHakTarihEski.Text = eskiKadro.kazanilmisHakTarih.ToString();
            txtKazanilmisGostergeEski.Text = eskiKadro.kazanilmisGosterge.ToString();
            txtKazanilmisEkGostergeEski.Text = eskiKadro.kazanilmisEkGosterge.ToString();

            txtOdemeyeEsasDerece.Text = yeniKadro.odemeyeEsasDerece.ToString();
            txtOdemeyeEsasKademe.Text = yeniKadro.odemeyeEsasKademe.ToString();
            txtOdemeyeEsasTarih.Text = yeniKadro.odemeyeEsasTarih.ToString();
            txtOdemeyeEsasGosterge.Text = yeniKadro.odemeyeEsasGosterge.ToString();
            txtOdemeyeEsasEkGosterge.Text = yeniKadro.odemeyeEsasEkGosterge.ToString();
            txtOdemeyeEsasDereceEski.Text = eskiKadro.odemeyeEsasDerece.ToString();
            txtOdemeyeEsasKademeEski.Text = eskiKadro.odemeyeEsasKademe.ToString();
            txtOdemeyeEsasTarihEski.Text = eskiKadro.odemeyeEsasTarih.ToString();
            txtOdemeyeEsasGostergeEski.Text = eskiKadro.odemeyeEsasGosterge.ToString();
            txtOdemeyeEsasEkGostergeEski.Text = eskiKadro.odemeyeEsasEkGosterge.ToString();

            txtEmekliyeEsasDerece.Text = yeniKadro.emekliyeEsasDerece.ToString();
            txtEmekliyeEsasKademe.Text = yeniKadro.emekliyeEsasKademe.ToString();
            txtEmekliyeEsasTarih.Text = yeniKadro.emekliyeEsasTarih.ToString();
            txtEmekliGosterge.Text = yeniKadro.emekliyeEsasGosterge.ToString();
            txtEmekliEkGosterge.Text = yeniKadro.emekliyeEsasEkGosterge.ToString();
            txtEmekliyeEsasDereceEski.Text = eskiKadro.emekliyeEsasDerece.ToString();
            txtEmekliyeEsasKademeEski.Text = eskiKadro.emekliyeEsasKademe.ToString();
            txtEmekliyeEsasTarihEski.Text = eskiKadro.emekliyeEsasTarih.ToString();
            txtEmekliGostergeEski.Text = eskiKadro.emekliyeEsasGosterge.ToString();
            txtEmekliEkGostergeEski.Text = eskiKadro.emekliyeEsasEkGosterge.ToString();

            pnlEskiKadro.Title = "Eski Kadro/" + eskiKadro.kadroDurumAd;
            pnlYeniKadro.Title = "Yeni Kadro/" + yeniKadro.kadroDurumAd;
            //txtKadroDurumu.Text = yeniKadro.kadroDurumAd;
            //txtKadroDurumuEski.Value = eskiKadro.kadroDurumAd;

            ddlAyrilmaGerekcesi.Value = HizmetSebebi.TipKodOl(yeniKadro.ayrilmaGerekcesiTip, yeniKadro.ayrilmaGerekcesi);
            ddlAyrilmaGerekcesiEski.Text = eskiKadro.ayrilmaGerekcesiAd;

            txtAyrilmaNedeni.Value = yeniKadro.ayrilmaNedeni;
            txtAyrilmaNedeniEski.Value = eskiKadro.ayrilmaNedeni;

            txtAyrilmaTarihi.Text = yeniKadro.ayrilmaTarihi.ToString();
            txtAyrilmaTarihiEski.Text = eskiKadro.ayrilmaTarihi.ToString();

            txtHizmetGunu.Text = yeniKadro.hizmetGunSayisi.ToString();
            txtHizmetGunuEski.Text = eskiKadro.hizmetGunSayisi.ToString();
            cmbPersonelTipDegisti(yeniKadro.personelTip);

            PersonelTipi personelTipiEski = TNS.IKY.Arac.PersonelTipBul(eskiKadro.personelTip);
            if (personelTipiEski == null || personelTipiEski.kurumDisi == 0)
            {
                ddlBirimEski.Hidden = false;
                ddlGorevBirimEski.Hidden = false;
                txtGorevYeriEski.Hidden = true;
            }
            else
            {
                ddlBirimEski.Hidden = true;
                ddlGorevBirimEski.Hidden = true;
                txtGorevYeriEski.Hidden = false;
            }
            ddlTayinOlacagiBirim.SetValue(yeniKadro.tayinOlacagiBirim.ToString(), yeniKadro.tayinOlacagiBirimAd);
            hdnIliskiliKadroIslemNo.Text = yeniKadro.iliskiliKadroIslemNo.ToString();
            cmbAtanacagiKadro.Value = yeniKadro.atananacagiKadroUnvanKod.ToString() + '-' + yeniKadro.atananacagiKadroDerece.ToString();

            GizleAc(yeniKadro.kadroDurum);
            cmbPersonelTip.FireEvent("change");
            //ddlHizmetKurumu.FireEvent("change");
            ddlBaslamaGerekcesi.FireEvent("change");
            txtAtamaTarihi.FireEvent("change");
            txtAtamaNedeni.FireEvent("change");
            ddlBirim.FireEvent("change");
            ddlGorevBirim.FireEvent("change");
            txtGorevYeri.FireEvent("change");
            //ddlSinif.FireEvent("change");
            ddlUnvan.FireEvent("change");
            ddlVekaletUnvani.FireEvent("change");
            txtEvrakNo.FireEvent("change");
            txtYasalDayanak.FireEvent("change");
            txtMeslekKodu.FireEvent("change");
            txtOnayTarih.FireEvent("change");
            txtAciklama.FireEvent("change");
            txtKadroDerece.FireEvent("change");
            txtKadroTarih.FireEvent("change");
            txtKazanilmisHakDerece.FireEvent("change");
            txtKazanilmisHakKademe.FireEvent("change");
            txtKazanilmisHakTarih.FireEvent("change");
            //txtKazanilmisGosterge.FireEvent("change");
            txtKazanilmisEkGosterge.FireEvent("change");
            txtOdemeyeEsasDerece.FireEvent("change");
            txtOdemeyeEsasKademe.FireEvent("change");
            txtOdemeyeEsasTarih.FireEvent("change");
            //txtOdemeyeEsasGosterge.FireEvent("change");
            txtOdemeyeEsasEkGosterge.FireEvent("change");
            txtEmekliyeEsasDerece.FireEvent("change");
            txtEmekliyeEsasKademe.FireEvent("change");
            txtEmekliyeEsasTarih.FireEvent("change");
            //txtEmekliGosterge.FireEvent("change");
            txtEmekliEkGosterge.FireEvent("change");
            //txtKadroDurumu.FireEvent("change");
            ddlAyrilmaGerekcesi.FireEvent("change");
            txtAyrilmaNedeni.FireEvent("change");
            txtAyrilmaTarihi.FireEvent("change");
            txtHizmetGunu.FireEvent("change");
            pnlYeniKadro.DoLayout();
        }

        [DirectMethod]
        public void cmbPersonelTipDegisti(int personelTur)
        {
            PersonelTipi personelTipiYeni = TNS.IKY.Arac.PersonelTipBul(personelTur);
            if (personelTipiYeni == null) personelTipiYeni = (PersonelTipi)TNS.IKY.Arac.PersonelTipListe[0];
            BirimGoster(personelTipiYeni);
            txtHizmetGrubuYeni.Text = personelTipiYeni.HITAP.ToString();
            if (personelTipiYeni.KadroIslemiYapilacakMi())
            {
                cmbAtanacagiKadro.Hidden = false;
                lblAtanacagiKadro.Hidden = false;
            }
            else
            {
                cmbAtanacagiKadro.Hidden = true;
                lblAtanacagiKadro.Hidden = true;
            }
        }

        private void BirimGoster(PersonelTipi personelTipiYeni)
        {
            if (personelTipiYeni == null || personelTipiYeni.kurumDisi == 0)
            {
                ddlBirim.Hidden = false;
                ddlGorevBirim.Hidden = false;
                ddlGorevBirimEski.Hidden = false;
                txtGorevYeri.Hidden = true;
                txtGorevYeriEski.Hidden = true;
            }
            else
            {
                ddlBirim.Hidden = true;
                ddlGorevBirim.Hidden = true;
                ddlGorevBirimEski.Hidden = true;
                txtGorevYeriEski.Hidden = false;
                txtGorevYeri.Hidden = false;
            }
        }

        private void PersonelHizmetSatiriBul(int kadroKod, out TNS.IKY.PersonelKadro okunan, out TNS.IKY.PersonelKadro eski, int onceki)
        {
            okunan = null;
            eski = null;
            ObjectArray list2 = null;

            if (kadroKod > 0)
            {
                list2 = servisIKY.PersonelKadroListele(kullanan, new TNS.IKY.PersonelKadro { kod = kadroKod, personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, -1) }, false);
                if (list2 != null && list2.ObjeSayisi > 0)
                {
                    okunan = (TNS.IKY.PersonelKadro)list2.objeler[0];
                    if (okunan.eskiKod > 0 && okunan.eskiKod != kadroKod) onceki = okunan.eskiKod;
                }
            }

            if (onceki > 0)
            {
                list2 = servisIKY.PersonelKadroListele(kullanan, new TNS.IKY.PersonelKadro { kod = onceki, personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, -1) }, false);
            }
            else if (kadroKod == 0)
            {
                list2 = servisIKY.PersonelKadroListele(kullanan, new TNS.IKY.PersonelKadro { personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, -1), kadroDurum = ENUMKadroDurumu.AKTIFKAYIT }, false);
            }
            else
                list2 = null;
            if (list2 != null && list2.ObjeSayisi > 0)
            {
                eski = (TNS.IKY.PersonelKadro)list2.objeler[0];
            }
            if (eski == null && okunan != null)
            {
                //eski = OncekiniBul(okunan);
            }
            if (eski == null) eski = new TNS.IKY.PersonelKadro();
            if (okunan == null)
            {
                okunan = (TNS.IKY.PersonelKadro)eski.Clone();
                okunan.kod = 0;
                okunan.kadroDurum = ENUMKadroDurumu.TANIMSIZ;
                okunan.atananacagiKadroDerece = 0;
                okunan.atananacagiKadroUnvanKod = 0;
                okunan.eskiKod = eski.kod;
                okunan.atamaTarihi = new TNSDateTime(DateTime.MinValue);
                okunan.ayrilmaTarihi = new TNSDateTime(DateTime.MinValue);
                okunan.ayrilmaGerekcesi = 0;
                okunan.ayrilmaGerekcesiAd = "";
                okunan.gitOrganizasyonKopruKodu = "";
                okunan.tayinOlacagiBirim = 0;
                okunan.tayinOlacagiBirimAd = "";
                okunan.iliskiliKadroIslemNo = 0;
            }
        }

        //private TNS.IKY.PersonelKadro OncekiniBul(TNS.IKY.PersonelKadro okunan)
        //{
        //    if (okunan != null)
        //    {
        //        TNS.IKY.PersonelKadro kistas = new TNS.IKY.PersonelKadro();
        //        kistas.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, -1);
        //        kistas.buSatirdanOnceki = okunan.kod;
        //        kistas.hizmetHesabi = okunan.hizmetHesabi;
        //        ObjectArray list2 = servisIKY.PersonelKadroListele(kullanan, kistas, false);
        //        if (list2.ObjeSayisi > 0)
        //        {
        //            return (TNS.IKY.PersonelKadro)list2.objeler[0];
        //        }
        //    }
        //    return null;
        //}

        protected void GizleAc(ENUMKadroDurumu kayitDurumu)
        {
            bool onayDurum = kayitDurumu == ENUMKadroDurumu.AKTIFKAPANIYOR || kayitDurumu == ENUMKadroDurumu.AKTIFKAPANDI || kayitDurumu == ENUMKadroDurumu.AKTIFKAYIT || kayitDurumu == ENUMKadroDurumu.AYRILDI || kayitDurumu == ENUMKadroDurumu.REDDEDILDI;
            bool bitmis = kayitDurumu == ENUMKadroDurumu.AYRILDI || kayitDurumu == ENUMKadroDurumu.REDDEDILDI || kayitDurumu == ENUMKadroDurumu.AKTIFKAPANDI;
            btnKaydet.Disabled = bitmis;
            //btnOnayla.Disabled = bitmis;
            //btnRed.Disabled = bitmis;

            cmbPersonelTip.ReadOnly = onayDurum;
            //ddlHizmetKurumu.ReadOnly = onayDurum;
            ddlBaslamaGerekcesi.ReadOnly = onayDurum;
            txtAtamaTarihi.ReadOnly = onayDurum;
            txtAtamaNedeni.ReadOnly = onayDurum;
            ddlBirim.ReadOnly = onayDurum;
            ddlGorevBirim.ReadOnly = onayDurum;
            txtGorevYeri.ReadOnly = onayDurum;
            //ddlSinif.ReadOnly = onayDurum;
            ddlUnvan.ReadOnly = onayDurum;
            ddlVekaletUnvani.ReadOnly = onayDurum;
            txtEvrakNo.ReadOnly = onayDurum;
            txtYasalDayanak.ReadOnly = onayDurum;
            txtMeslekKodu.ReadOnly = onayDurum;
            txtOnayTarih.ReadOnly = onayDurum;
            txtAciklama.ReadOnly = onayDurum;

            txtKadroDerece.ReadOnly = onayDurum;
            txtKadroTarih.ReadOnly = onayDurum;

            txtKazanilmisHakDerece.ReadOnly = onayDurum;
            txtKazanilmisHakKademe.ReadOnly = onayDurum;
            txtKazanilmisHakTarih.ReadOnly = onayDurum;
            //txtKazanilmisGosterge.ReadOnly = onayDurum;
            txtKazanilmisEkGosterge.ReadOnly = onayDurum;

            txtOdemeyeEsasDerece.ReadOnly = onayDurum;
            txtOdemeyeEsasKademe.ReadOnly = onayDurum;
            txtOdemeyeEsasTarih.ReadOnly = onayDurum;
            //txtOdemeyeEsasGosterge.ReadOnly = onayDurum;
            txtOdemeyeEsasEkGosterge.ReadOnly = onayDurum;

            txtEmekliyeEsasDerece.ReadOnly = onayDurum;
            txtEmekliyeEsasKademe.ReadOnly = onayDurum;
            txtEmekliyeEsasTarih.ReadOnly = onayDurum;
            //txtEmekliGosterge.ReadOnly = onayDurum;
            txtEmekliEkGosterge.ReadOnly = onayDurum;
            cmbAtanacagiKadro.ReadOnly = onayDurum;

            bool ayrilabilir = (kayitDurumu == ENUMKadroDurumu.TANIMSIZ || kayitDurumu == ENUMKadroDurumu.YENI || kayitDurumu == ENUMKadroDurumu.AKTIFYENI || kayitDurumu == ENUMKadroDurumu.AKTIFKAYIT || kayitDurumu == ENUMKadroDurumu.AKTIFKAPANIYOR);
            ddlAyrilmaGerekcesi.ReadOnly = !ayrilabilir;
            txtAyrilmaNedeni.ReadOnly = !ayrilabilir;
            txtAyrilmaTarihi.ReadOnly = !ayrilabilir;
            txtHizmetGunu.ReadOnly = !ayrilabilir;
        }

        [DirectMethod]
        public void GostergeHesapla(int yer)
        {
            string[] alanlar = {
            "txtKazanilmisHakDerece", "txtKazanilmisHakKademe", "txtKazanilmisGosterge",
            "txtEmekliyeEsasDerece", "txtEmekliyeEsasKademe", "txtEmekliGosterge",
            "txtOdemeyeEsasDerece", "txtOdemeyeEsasKademe", "txtOdemeyeEsasGosterge"};

            TextField tfD;
            TextField tfK;
            TextField tfG;

            if (yer == 1)
            {
                tfD = txtKazanilmisHakDerece;
                tfK = txtKazanilmisHakKademe;
                tfG = txtKazanilmisGosterge;
            }
            else if (yer == 2)
            {
                tfD = txtEmekliyeEsasDerece;
                tfK = txtEmekliyeEsasKademe;
                tfG = txtEmekliGosterge;
            }
            else
            {
                tfD = txtOdemeyeEsasDerece;
                tfK = txtOdemeyeEsasKademe;
                tfG = txtOdemeyeEsasGosterge;
            }
            tfG.Text = TNS.IKY.Arac.GostergeBul(OrtakFonksiyonlar.ConvertToInt(tfD.Text, 0), OrtakFonksiyonlar.ConvertToInt(tfK.Text, 0)).ToString();
        }
    }
}
