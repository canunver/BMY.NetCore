﻿<%@ Page Language="C#" CodeBehind="PersonelKart.aspx.cs" Inherits="InsanKaynaklari.PersonelKart" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        function ZorunluAlanKontrol() {
            if (!pnlformpanel1.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return pnlformpanel1.isValid();
        }

        function PersonelSorguAc(tip) {
            showPopWin('PersonelSorgu.aspx?menuYok=1&tip=' + tip, 915, 500, true, '');
        }

        function BilgiListeleAc(kadroKod, personelKod, hareketDurumu, eskiKadroKod, personelAd, tip) {
            if (tip == 1) {
                document.getElementById('txtZimmetEden').value = personelAd;
                document.getElementById('hdnZimmetEden').value = personelKod;
            }
            else if (tip == 2) {
                document.getElementById('txtIadeAlan').value = personelAd;
                document.getElementById('hdnIadeAlan').value = personelKod;
            }
        }

        //        var KomutCalistir = function (command, record, row) {
        //            if (command == 'BelgeSil') {
        //                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
        //                function (btn) {
        //                    if (btn == "yes") {
        //                        Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
        //                    }
        //                });
        //            }
        //            else if (command == 'BelgeGoster')
        //                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        //        };
    </script>
    <script src="../Personel/ModulScripts/Ortak.js?mc=03022015" type="text/javascript"></script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnPersonelKod" runat="server" />
    <ext:Hidden ID="hdnZimmetEden" runat="server" />
    <ext:Hidden ID="hdnIadeAlan" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <%--<ext:Hidden ID="hdnBelgeKod" runat="server" />--%>
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="KARTTIPI" />
                    <ext:RecordField Name="KARTNO" />
                    <ext:RecordField Name="ADSOYAD" />
                    <ext:RecordField Name="AKTIF" />
                    <ext:RecordField Name="ZIMMETTAR" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="kartTipiStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="yakinlikDerecesiStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <%--    <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>--%>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click" Before="return ZorunluAlanKontrol();">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                Icon="Delete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnTemizle_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="pnlformpanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        Region="Center">
                        <Items>
                            <ext:ComboBox runat="server" ID="ddlTip" FieldLabel="Kart Tipi" NoteAlign="Top" AnchorHorizontal="96%"
                                DisplayField="AD" ValueField="KOD" StoreID="kartTipiStore" Editable="false">
                            </ext:ComboBox>
                            <ext:TextField runat="server" ID="txtKartNo" FieldLabel="Kart No" NoteAlign="Top"
                                Width="130">
                            </ext:TextField>
                            <ext:ComboBox runat="server" ID="ddlYakinlik" FieldLabel="Yakınlığı" NoteAlign="Top"
                                Editable="false" AnchorHorizontal="96%" DisplayField="AD" ValueField="KOD" StoreID="yakinlikDerecesiStore">
                            </ext:ComboBox>
                            <ext:TextField runat="server" ID="txtAdSoyad" FieldLabel="Kart Sahibi Adı Soyadı"
                                NoteAlign="Top" AnchorHorizontal="96%">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtPlaka" FieldLabel="Plaka" NoteAlign="Top" Width="130">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtCihazNo" FieldLabel="Tag Cihaz No" NoteAlign="Top"
                                Width="130">
                            </ext:TextField>
                            <ext:DateField runat="server" ID="txtZimmetTarihi" FieldLabel="Zimmet Tarihi" NoteAlign="Top"
                                Width="130">
                            </ext:DateField>
                            <ext:DateField runat="server" ID="txtIadeTarihi" FieldLabel="İade Tarihi" NoteAlign="Top"
                                Width="130">
                            </ext:DateField>
                            <ext:TextField runat="server" ID="txtAciklama" FieldLabel="Açıklama" NoteAlign="Top"
                                AnchorHorizontal="96%">
                            </ext:TextField>
                            <ext:DateField runat="server" ID="txtKayipTarihi" FieldLabel="Kayip Bildirim Tarihi"
                                NoteAlign="Top" Width="130">
                            </ext:DateField>
                            <ext:TriggerField ID="txtZimmetEden" runat="server" FieldLabel="Zimmet Eden Personel"
                                Width="150" Editable="false" AnchorHorizontal="96%">
                                <Triggers>
                                    <ext:FieldTrigger Icon="Search" />
                                </Triggers>
                                <Listeners>
                                    <TriggerClick Handler="Ext1.net.Mask.show(); PersonelSorguAc(1); Ext1.net.Mask.hide();" />
                                </Listeners>
                            </ext:TriggerField>
                            <ext:TriggerField ID="txtIadeAlan" runat="server" FieldLabel="İade Alan Personel"
                                Width="150" Editable="false" AnchorHorizontal="96%">
                                <Triggers>
                                    <ext:FieldTrigger Icon="Search" />
                                </Triggers>
                                <Listeners>
                                    <TriggerClick Handler="Ext1.net.Mask.show(); PersonelSorguAc(2); Ext1.net.Mask.hide();" />
                                </Listeners>
                            </ext:TriggerField>
                        </Items>
                    </ext:FormPanel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" AutoExpandColumn="ADSOYAD" Border="true"
                        Region="East" Split="true" Width="700">
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column ColumnID="ZIMMETTAR" DataIndex="ZIMMETTAR" Header="Zimmet Tarihi" />
                                <ext:Column ColumnID="KARTTIPI" DataIndex="KARTTIPI" Header="Kart Tipi" Width="150"/>
                                <ext:Column ColumnID="KARTNO" DataIndex="KARTNO" Header="Kart No" />
                                <ext:Column ColumnID="ADSOYAD" DataIndex="ADSOYAD" Header="Ad Soyad" />
                                <ext:Column ColumnID="AKTIF" DataIndex="AKTIF" Header="Aktif Mi?" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                <DirectEvents>
                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                        <ExtraParams>
                                            <ext:Parameter Name="kod" Value="this.getSelected().data.KOD" Mode="Raw" />
                                        </ExtraParams>
                                    </RowSelect>
                                </DirectEvents>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
