﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimBanka : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.FRMPTB004;
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Listele(new Banka());
            }
        }

        public void Listele(Banka kriter)
        {
            ObjectArray dler = servisIKY.BankaListele(kriter);

            if (!dler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
                return;
            }

            if (dler.objeler.Count <= 0)
                GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            List<object> tipler = new List<object>();
            foreach (TNS.IKY.Banka d in dler.objeler)
                tipler.Add(new
                {
                    BANKAKODU = d.kod,
                    BANKAADI = d.ad,
                });

            ListeStore.DataSource = tipler;
            ListeStore.DataBind();
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            Banka d = new Banka();
            d.kod = txtBankaKodu.Text.Trim();
            d.ad = txtBankaAdi.Text.Trim();
            Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(txtBankaKodu.Text.Trim(), 0) == 0)
                hata = Resources.InsanKaynaklari.FRMPTB008 + "<br>";
            if (txtBankaAdi.Text.Trim() == "")
                hata += Resources.InsanKaynaklari.FRMPTB009 + "<br>";

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            Banka d = new Banka();
            d.kod = txtBankaKodu.Text.Trim();
            d.ad = txtBankaAdi.Text.Trim();

            Sonuc sonuc = servisIKY.BankaKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele(new Banka());
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.FRMPTB005);
            }
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            Banka d = new Banka();
            string kod = txtBankaKodu.Text.Trim();

            if (kod != "")
            {
                d.kod = kod;
                Sonuc sonuc = servisIKY.BankaSil(kullanan, d);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    Temizle();
                    Listele(new Banka());
                    GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.FRMPTB006);
                }
            }
            else
                GenelIslemler.HataYaz(this, Resources.InsanKaynaklari.FRMPTB007);
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Listele(new Banka());
            Temizle();
        }

        void Temizle()
        {
            txtBankaKodu.Text = "";
            txtBankaAdi.Text = "";
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            txtBankaKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["bankaKodu"]);
            txtBankaAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["bankaAdi"]);
        }
    }
}
