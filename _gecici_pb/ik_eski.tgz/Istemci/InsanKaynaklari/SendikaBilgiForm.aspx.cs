﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class SendikaBilgiForm : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.SendikaBilgi001;
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            if (!IsPostBack)
            {
                SayfaUstAltBolumYaz(this);
                this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
                Listele();
            }
        }

        private void Listele()
        {
            SendikaBilgi form = new SendikaBilgi();
            ObjectArray oa = servis.ListeleSendikaBilgi(kullanan, form);
            stoSendikaListesi.DataSource = oa.objeler;
            stoSendikaListesi.DataBind();
        }

        protected void SendikaSecildi(object sender, DirectEventArgs e)
        {
            SendikaSecildiIc(OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["kod"], 0));
        }

        protected void YeniSendika(object sender, DirectEventArgs e)
        {
            txtsendikaNo.Text = "";
            txtsendikaAd.Text = "";
            txtadres.Text = "";
            txtiBAN.Text = "";
            txthesapNo.Text = "";
            txtTopluGorusmePuani.Text = "0";
            stoSendikaPersonel.DataSource = new ArrayList();
            stoSendikaPersonel.DataBind();
        }

        [DirectMethod]
        public void KisileriEkle(string kisiler_JSON)
        {
            TNSCollection pKodList = new TNSCollection();

            TNS.IKY.Personel[] bordro = (TNS.IKY.Personel[])JSON.Deserialize(kisiler_JSON, typeof(TNS.IKY.Personel[]));
            foreach (TNS.IKY.Personel p in bordro)
            {
                pKodList.Add(p.kod);
            }
            int sendikaKod = OrtakFonksiyonlar.ConvertToInt(txtsendikaNo.Text, 0);
            Sonuc sonuc = servis.PersonelSendikayaEkle(kullanan, sendikaKod, pKodList, OrtakFonksiyonlar.ConvertToDbl(nfKesintiOrani.Value), true);
            if (sonuc.islemSonuc)
                SendikaSecildiIc(sendikaKod);
            else
                GenelIslemler.HataYaz(this, sonuc.hataStr);
        }

        protected void SendikaSecildiIc(int sendikaKod)
        {
            SendikaBilgi form = new SendikaBilgi();
            form.sendikaNo = sendikaKod;
            ObjectVAN ov = servis.OkuSendikaBilgi(kullanan, form);
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                form = (SendikaBilgi)ov.o;
                txtsendikaNo.Text = form.sendikaNo.ToString();
                txtsendikaAd.Text = form.sendikaAd;
                txtadres.Text = form.adres;
                txtiBAN.Text = form.iBAN;
                txthesapNo.Text = form.hesapNo;
                txtTopluGorusmePuani.Text = form.topluGorusmePuani.ToString();
                nfKesintiOrani.Value = form.kesintiOrani;
                stoSendikaPersonel.DataSource = form.sendikaPersonel;
                stoSendikaPersonel.DataBind();
            }
            else if (!ov.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.SendikaBilgi002);
        }


        protected void PersonelCikart(object sender, DirectEventArgs e)
        {
            Sonuc sonuc = servis.PersonelSendikadanCikart(kullanan, OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["pkod"], 0));
            if (sonuc.islemSonuc)
                SendikaSecildiIc(OrtakFonksiyonlar.ConvertToInt(txtsendikaNo.Text, 0));
            else
                GenelIslemler.HataYaz(this, sonuc.hataStr);
        }

        protected void btnKisiDegerAtaClick(object sender, DirectEventArgs e)
        {
            Sonuc sonuc = servis.PersonelSendikaOranDegistir(kullanan, OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["pkod"], 0), OrtakFonksiyonlar.ConvertToDbl(nfKesintiOrani.Value));
            if (sonuc.islemSonuc)
                SendikaSecildiIc(OrtakFonksiyonlar.ConvertToInt(txtsendikaNo.Text, 0));
            else
                GenelIslemler.HataYaz(this, sonuc.hataStr);
        }

        void Kaydet(DirectEventArgs e)
        {
            SendikaBilgi form = new SendikaBilgi();
            form.sendikaNo = OrtakFonksiyonlar.ConvertToInt(txtsendikaNo.Text, 0);
            form.sendikaAd = txtsendikaAd.Text;
            form.adres = txtadres.Text;
            form.iBAN = txtiBAN.Text;
            form.hesapNo = txthesapNo.Text;
            form.topluGorusmePuani = OrtakFonksiyonlar.ConvertToInt(txtTopluGorusmePuani.Text, 0);
            form.kesintiOrani = OrtakFonksiyonlar.ConvertToDbl(nfKesintiOrani.Value);
            Sonuc sonuc = servis.KaydetSendikaBilgi(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                TNS.IKY.Arac.SendikaListesi = null;
                if (form.sendikaNo == 0)
                    txtsendikaNo.Text = sonuc.anahtar;
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.SendikaBilgi003);
            }
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        /// <summary>
        /// Yazdir tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
        }
    }
}
