﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;
using System.Collections.Generic;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class PersonelGorev : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            servisIKY = TNS.IKY.Arac.Tanimla();
            if (!IsPostBack)
            {
                hdnPersonelKod.Text = (Request.QueryString["personelKod"] + "").Trim();
                formAdi = Resources.InsanKaynaklari.Gorevlendirmeler001;
                yardimBag = yardimYol + "#YardimDosyasiAd";
                OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
                SayfaUstAltBolumYaz(this);
                this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

                ArrayList al = new ArrayList();
                al.Add(new IntKodStrAd((int)Gorevler.ENUMGorevDurumu.ALTIAY, Gorevler.GorevDurumAd(Gorevler.ENUMGorevDurumu.ALTIAY)));
                al.Add(new IntKodStrAd((int)Gorevler.ENUMGorevDurumu.ASIL, Gorevler.GorevDurumAd(Gorevler.ENUMGorevDurumu.ASIL)));
                al.Add(new IntKodStrAd((int)Gorevler.ENUMGorevDurumu.TEDVIREN, Gorevler.GorevDurumAd(Gorevler.ENUMGorevDurumu.TEDVIREN)));
                al.Add(new IntKodStrAd((int)Gorevler.ENUMGorevDurumu.UCRETLIVEKALET, Gorevler.GorevDurumAd(Gorevler.ENUMGorevDurumu.UCRETLIVEKALET)));
                al.Add(new IntKodStrAd((int)Gorevler.ENUMGorevDurumu.UCRETSIZVEKALET, Gorevler.GorevDurumAd(Gorevler.ENUMGorevDurumu.UCRETSIZVEKALET)));
                stoGorevDurumu.DataSource = al;
                stoGorevDurumu.DataBind();
                Genel.UnvanDoldur(servisIKY, this, storeUnvan);
                Listele();
            }
        }

        void Listele()
        {
            Gorevler form = new Gorevler();
            form.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, 0);
            ObjectArray oa = servisIKY.ListeleGorevlendirmeler(kullanan, form);
            if (oa.sonuc.islemSonuc)
            {
                stoGorevler.DataSource = oa.objeler;
                stoGorevler.DataBind();
            }
            else
                GenelIslemler.BilgiYaz(this, oa.sonuc.hataStr);
        }

        void Kaydet(DirectEventArgs e)
        {
            Gorevler form = new Gorevler();
            form.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, 0);
            form.baslamaTarihiDT = txtBaslamaTarihiDT.SelectedDate;
            form.bitisTarihiDT = txtBitisTarihiDT.SelectedDate;
            form.birimi = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
            form.gorevDurumu = (Gorevler.ENUMGorevDurumu)OrtakFonksiyonlar.ConvertToInt(cmbGorevDurumu.SelectedItem.Value, 0);
            form.gorevNo = OrtakFonksiyonlar.ConvertToInt(txtGorevNo.Number, 0);
            form.unvanKod = OrtakFonksiyonlar.ConvertToInt(cmbUnvan.SelectedItem.Value, 0);
            form.aciklama = txtAciklama.Text;
            form.onayNo = txtOnayNo.Text;
            form.onayTarihiDT = txtOnayTarihi.SelectedDate;
            Sonuc sonuc = servisIKY.KaydetGorevlendirmeler(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.Gorevlendirmeler003);
                txtGorevNo.Number = OrtakFonksiyonlar.ConvertToInt(sonuc.anahtar, 0);
                Listele();
            }
        }

        /// <summary>
        /// Listele tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYeni_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        private void Temizle()
        {
            txtGorevNo.Number = 0;
            cmbUnvan.Clear();
            cmbGorevDurumu.Clear();
            ddlBirim.Clear();
            txtBaslamaTarihiDT.Clear();
            txtBitisTarihiDT.Clear();
            txtOnayNo.Clear();
            txtOnayTarihi.Clear();

            BelgeStore.RemoveAll();
            BelgeStore.DataBind();
        }

        /// <summary>
        /// Listele tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            Gorevler form = new Gorevler();
            form.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, 0);
            form.gorevNo = OrtakFonksiyonlar.ConvertToInt(txtGorevNo.Number, 0);
            Sonuc sonuc = servisIKY.SilGorevlendirmeler(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.Gorevlendirmeler003);
                Temizle();
                Listele();
            }
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELGOREV;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnKod.Value.ToString().Trim()))
            {
                btnKaydet_Click(null, null);
                //GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMPAB040, Resources.InsanKaynaklari.FRMPAB041);
                //return;
            }

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELGOREV, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }

        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            hdnKod.Value = e.ExtraParams["kod"];
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            BelgeListesiDoldur();
        }
    }
}
