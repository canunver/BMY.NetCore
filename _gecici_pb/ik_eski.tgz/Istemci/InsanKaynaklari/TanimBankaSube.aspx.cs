﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimBankaSube : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Banka Şube Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                BankaDoldur();
                Listele(new BankaSube());
            }
        }

        public void Listele(BankaSube kriter)
        {
            ObjectArray dler = servisIKY.BankaSubeListele(kriter);

            if (!dler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
                return;
            }

            if (dler.objeler.Count <= 0)
                GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            List<object> tipler = new List<object>();
            foreach (TNS.IKY.BankaSube d in dler.objeler)
                tipler.Add(new
                {
                    BANKAKODU = d.bankaKodu,
                    BANKAADI = d.bankaAd,
                    SUBEKODU = d.kod,
                    SUBEADI = d.ad
                });

            ListeStore.DataSource = tipler;
            ListeStore.DataBind();
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            BankaSube d = new BankaSube();
            d.kod = txtSubeKodu.Text.Trim();
            d.ad = txtSubeAdi.Text.Trim();
            d.bankaKodu = OrtakFonksiyonlar.ConvertToStr(ddlBanka.Value);
            Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(ddlBanka.Value, 0) == 0)
                hata += "Banka Bilgisi boş bırakılamaz" + "<br>";
            if (OrtakFonksiyonlar.ConvertToInt(txtSubeKodu.Text.Trim(), 0) == 0)
                hata += "Banka Şube Kodu boş bırakılamaz" + "<br>";
            if (txtSubeAdi.Text.Trim() == "")
                hata += "Banka Şube Adı boş bırakılamaz" + "<br>";

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            BankaSube d = new BankaSube();
            d.bankaKodu = OrtakFonksiyonlar.ConvertToStr(ddlBanka.Value);
            d.kod = txtSubeKodu.Text.Trim();
            d.ad = txtSubeAdi.Text;

            Sonuc sonuc = servisIKY.BankaSubeKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                BankaSube dListe = new BankaSube();
                dListe.bankaKodu = OrtakFonksiyonlar.ConvertToStr(ddlBanka.Value);
                Listele(dListe);
                Temizle();

                GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            }
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            BankaSube d = new BankaSube();
            int kod = OrtakFonksiyonlar.ConvertToInt(txtSubeKodu.Text.Trim(), 0);
            string bankaKod = OrtakFonksiyonlar.ConvertToStr(ddlBanka.Value);

            if (kod > 0 && !string.IsNullOrEmpty(bankaKod))
            {
                d.bankaKodu = bankaKod;
                d.kod = txtSubeKodu.Text.Trim();
                d.ad = txtSubeAdi.Text.Trim();
                Sonuc sonuc = servisIKY.BankaSubeSil(kullanan, d);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    BankaSube dListe = new BankaSube();
                    dListe.bankaKodu = OrtakFonksiyonlar.ConvertToStr(ddlBanka.Value);
                    Listele(dListe);
                    GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
                    Temizle();
                }
            }
            else
                GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz Banka Şubesini seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Listele(new BankaSube());
            Temizle();
        }

        void Temizle()
        {
            ddlBanka.Clear();
            txtSubeKodu.Text = "";
            txtSubeAdi.Text = "";
            grdListeSelectionModel.ClearSelections();
        }

        void BankaDoldur()
        {
            ObjectArray dler = new ObjectArray();
            dler = servisIKY.BankaListele(new Banka());
            List<object> tipler = new List<object>();

            if (dler.sonuc.islemSonuc)
            {
                foreach (Banka d in dler.objeler)
                    tipler.Add(new { KOD = d.kod.ToString(), AD = d.ad });
            }

            BankaStore.DataSource = tipler;
            BankaStore.DataBind();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            ddlBanka.SetValueAndFireSelect(e.ExtraParams["bankaKodu"]);
            txtSubeKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["subeKodu"]);
            txtSubeAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["subeAdi"]);
        }
    }
}
