﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.LojmanSiteBlokDaireForm" CodeBehind="LojmanSiteBlokDaireForm.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>
        <%= Resources.InsanKaynaklari.LojmanSite060%></title>
    <script type="text/javascript" language="javascript">
        function SatirDegisti() {
            if (smLojmanBlokDaireListe.hasSelection())
                Ext1.net.DirectMethods.Goster(smLojmanBlokDaireListe.getSelected().data.kod);
        }
        function ZorunluAlanKontrol() {
            if (!pnlIc.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return pnlformpanel1.pnlIc();
        }       
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager runat="server">
    </ext:ResourceManager>
    <ext:Store ID="siteStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="siteAdi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="blokStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="blokNo" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="daireTuruStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnYeni" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                TabIndex="18" Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnYeni_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite037%>"
                                TabIndex="19" Icon="DatabaseSave">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click">
                                        <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, LojmanSite038%>"
                                            Message="<%$ Resources:InsanKaynaklari, LojmanSite039%>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, LojmanSite040%>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="Sil" Icon="TableDelete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <%-- <ext:Button ID="btnYazdir" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite041%>"
                                TabIndex="18" Icon="Printer">
                                <DirectEvents>
                                    <Click OnEvent="btnYazdir_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>--%>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:GridPanel ID="grdLojmanBlokDaireListe" Width="600" Collapsed="false" AutoScroll="true"
                        Region="West" Split="true" Layout="BorderLayout" runat="server">
                        <Store>
                            <ext:Store runat="server" ID="stoLojmanBlokDaireListe">
                                <Reader>
                                    <ext:JsonReader>
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="siteAdi" Type="String" />
                                            <ext:RecordField Name="blokNo" Type="Int" />
                                            <ext:RecordField Name="daireNo" Type="Int" />
                                            <ext:RecordField Name="blokNo" Type="Int" />
                                            <ext:RecordField Name="metrekare" Type="Int" />
                                            <ext:RecordField Name="daireTuruAd" Type="String" />
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <ColumnModel>
                            <Columns>
                                <ext:Column DataIndex="kod" ColumnID="kod" Header="Kod" Width="50px" />
                                <ext:Column DataIndex="siteAdi" ColumnID="siteAdi" Header="Site Adı" Width="200px" />
                                <ext:Column DataIndex="blokNo" ColumnID="blokNo" Header="Blok No" Width="80px" />
                                <ext:Column DataIndex="daireNo" ColumnID="daireNo" Header="Daire No" Width="80px" />
                                <ext:Column DataIndex="metrekare" ColumnID="metrekare" Header="Metrekare" Width="80px" />
                                <ext:Column DataIndex="daireTuruAd" ColumnID="daireTuruAd" Header="Daire Türü" Width="80px" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel runat="server" ID="smLojmanBlokDaireListe">
                                <Listeners>
                                    <SelectionChange Fn="SatirDegisti" />
                                </Listeners>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                    </ext:GridPanel>
                    <ext:FormPanel runat="server" Border="false" Region="Center" Layout="RowLayout" Padding="5"
                        ButtonAlign="Center" AutoScroll="true" ID="pnlIc">
                        <Items>
                            <ext:TextField runat="server" Hidden="true" ID="txtKod" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite005%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite006%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:ComboBox ReadOnly="true" runat="server" ID="ddlSite" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite007%>"
                                AnchorHorizontal="80%" DisplayField="siteAdi" ValueField="kod" StoreID="siteStore">
                            </ext:ComboBox>
                            <ext:ComboBox ReadOnly="true" runat="server" ID="ddlBlok" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite044%>"
                                AnchorHorizontal="80%" DisplayField="blokNo" ValueField="kod" StoreID="blokStore">
                            </ext:ComboBox>
                            <ext:ComboBox runat="server" ID="ddldaireTuru" TabIndex="1" Editable="false" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite048%>"
                                AnchorHorizontal="80%" DisplayField="AD" ValueField="KOD" StoreID="daireTuruStore"
                                AllowBlank="false">
                            </ext:ComboBox>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtDaireNo" TabIndex="2" AllowBlank="false"
                                FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite049%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite049%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtmetrekare" TabIndex="3"
                                AllowBlank="false" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite050%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite050%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtsuNo" TabIndex="4" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite051%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite051%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtelekNo" TabIndex="5"
                                FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite052%>">
                                <ToolTips>
                                    <ext:ToolTip ID="ToolTip1" Html="<%$ Resources:InsanKaynaklari, LojmanSite052%>"
                                        runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtDogNo" TabIndex="6" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite053%>">
                                <ToolTips>
                                    <ext:ToolTip ID="ToolTip2" Html="<%$ Resources:InsanKaynaklari, LojmanSite053%>"
                                        runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtCevNo" TabIndex="7" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite054%>">
                                <ToolTips>
                                    <ext:ToolTip ID="ToolTip3" Html="<%$ Resources:InsanKaynaklari, LojmanSite054%>"
                                        runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtDahiliTel" TabIndex="8"
                                FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite055%>">
                                <ToolTips>
                                    <ext:ToolTip ID="ToolTip4" Html="<%$ Resources:InsanKaynaklari, LojmanSite055%>"
                                        runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
