﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelKisisel.aspx.cs"
    Inherits="InsanKaynaklari.PersonelKisisel" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        function btnKaydet_Click() {
            var pkod = hdnKod.getValue();
            if (pkod == "" || pkod == "0") {
                PersonelK.AlanlariKontrolEt(
                    {
                        success: function (sonuc) {
                            if (sonuc == "")
                                wndBirimUnvanOrgAl.show();
                            else
                                alert(sonuc);
                        }
                    }

                );
            }
            else {
                PersonelK.btnKaydet_Click();
            }
        }

        function ZorunluAlanKontrol() {
            //            if (!FormPanel1.isValid()) {
            //                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            //            }
            //            return FormPanel1.isValid();
        }

        function YeniKayitHazirla() {
            parent.PersonelX.YeniKayitHazirla();
        }

        function KayittanSonraGoster(kod) {
            parent.PersonelX.KayittanSonraGoster(kod);
        }

        function PersonelUstResimYenile(url) {
            parent.imgPersonelResim.setImageUrl(url);
        }

        function GizleAc() {
            var activePanelId = tabPanel.getActiveTab().id;
            if (activePanelId == "pnlHizliBilgi") {
                btnKaydet.setVisible(false);
                btnTemizle.setVisible(false);
            }
            else {
                btnKaydet.setVisible(true);
                btnTemizle.setVisible(true);
            }
        }

        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                    function (btn) {
                        if (btn == "yes") {
                            Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                        }
                    });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <ext:Hidden ID="hdnKod" runat="server" />
        <ext:Hidden ID="hdnBelgeKod" runat="server" />
        <ext:Store ID="sakatlikDurumuStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="StoreSosyalGuvence" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="ilStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="medeniHaliStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="cinsiyetStore" runat="server">
            <Reader>
                <ext:JsonReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:JsonReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="ilceStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="BelgeStore" runat="server">
            <Reader>
                <ext:JsonReader>
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="PKOD" />
                        <ext:RecordField Name="KAYITKOD" />
                        <ext:RecordField Name="TIP" />
                        <ext:RecordField Name="BELGEADI" />
                    </Fields>
                </ext:JsonReader>
            </Reader>
        </ext:Store>
        <ext:Viewport ID="Viewport1" runat="server" Layout="FitLayout">
            <Items>
                <ext:TabPanel runat="server" ID="tabPanel" DeferredRender="false">
                    <TopBar>
                        <ext:Toolbar ID="Toolbar2" runat="server">
                            <Items>
                                <ext:Button ID="btnKaydet" runat="server" Text="<%$Resources:InsanKaynaklari, FRMPRK016%>"
                                    Icon="Disk">
                                    <Listeners>
                                        <Click Fn="btnKaydet_Click" />
                                    </Listeners>
                                </ext:Button>
                                <ext:Button ID="btnTemizle" runat="server" Text="<%$Resources:InsanKaynaklari, FRMPRK018%>"
                                    Icon="PageWhite">
                                    <Listeners>
                                        <Click Fn="YeniKayitHazirla" />
                                    </Listeners>
                                </ext:Button>
                                <ext:Button ID="btnTanitmaKarti" runat="server" Text="Per. Tanıtma Kartı" Icon="PageWord">
                                    <DirectEvents>
                                        <Click OnEvent="TanitmaKartiYazdir" Timeout="900000" IsUpload="true">
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="bnMailImza" runat="server" Text="Mail İmza" Icon="PageWord">
                                    <DirectEvents>
                                        <Click OnEvent="MailImzaYazdir" Timeout="900000" IsUpload="true">
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnNufusYazdir2" runat="server" Text="Nüfus Cüzdanı Örneği" Icon="PageWord">
                                    <DirectEvents>
                                        <Click OnEvent="NufusYazdir" Timeout="900000" IsUpload="true">
                                            <ExtraParams>
                                                <ext:Parameter Name="Kod" Value="2" Mode="Value" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnNufusYazdir1" runat="server" Text="İkametgah İlmühaberi" Icon="PageWord">
                                    <DirectEvents>
                                        <Click OnEvent="NufusYazdir" Timeout="900000" IsUpload="true">
                                            <ExtraParams>
                                                <ext:Parameter Name="Kod" Value="1" Mode="Value" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnNakilBildirimYazdir" runat="server" Text="Nakil Bildirim" Icon="PageWord">
                                    <DirectEvents>
                                        <Click OnEvent="NakilBildirimiYazdir" Timeout="900000" IsUpload="true">
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnKisiBorcuYazdir" runat="server" Text="Kişi Borcu" Icon="PageCancel">
                                    <DirectEvents>
                                        <Click OnEvent="btnKisiBorcuYazdir_Click" Timeout="900000" IsUpload="true">
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <%--<ext:Button ID="btnOzlukYazdir" runat="server" Text="<%$Resources:InsanKaynaklari, FRMGNL006%>"
                                Icon="Printer">
                                <DirectEvents>
                                    <Click OnEvent="btnOzlukYazdir_Click" />
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnYeniOzlukYazdir" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPKS076 %>"
                                Icon="Printer">
                                <DirectEvents>
                                    <Click OnEvent="btnYeniOzlukYazdir_Click" />
                                </DirectEvents>
                            </ext:Button>--%>
                                <ext:FileUploadField ID="fileResim" runat="server" ButtonOnly="true" Icon="Attach"
                                    ButtonText="<%$Resources:InsanKaynaklari,FRMGNL003%>">
                                    <DirectEvents>
                                        <FileSelected IsUpload="true" OnEvent="ResimKayit">
                                        </FileSelected>
                                    </DirectEvents>
                                </ext:FileUploadField>
                            </Items>
                        </ext:Toolbar>
                    </TopBar>
                    <Items>
                        <ext:Panel runat="server" Title="<%$Resources:InsanKaynaklari,FRMPKS082%>" Layout="ColumnLayout">
                            <Items>
                                <ext:FormPanel ID="pnlNufus" runat="server" ColumnWidth="0.5" AutoScroll="true" Frame="true"
                                    LabelWidth="130">
                                    <Items>
                                        <ext:CompositeField runat="server">
                                            <Items>

                                                <ext:TriggerField ID="txtTCKimlikNo" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS001%>"
                                                    MaxLength="11" Width="130" AllowBlank="false">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Search" />
                                                    </Triggers>
                                                    <DirectEvents>
                                                        <TriggerClick OnEvent="KimlikBilgisiGetir">
                                                            <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMORT073 %>" />
                                                        </TriggerClick>
                                                        <SpecialKey Before="return e.getKey() == Ext1.EventObject.ENTER;" OnEvent="KimlikBilgisiGetir">
                                                            <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMORT073 %>" />
                                                        </SpecialKey>
                                                    </DirectEvents>
                                                </ext:TriggerField>
                                                <ext:Button ID="txtTCKimlikNoDegistir" runat="server" Icon="DatabaseEdit" Text="TC Kimlik No Değiştir">
                                                    <Menu>
                                                        <ext:Menu ID="menuTCKimlikNo" runat="server">
                                                            <Items>
                                                                <ext:FormPanel runat="server" Height="85" Width="150" Padding="10" Layout="FitLayout" LabelAlign="Top">
                                                                    <Items>
                                                                        <ext:TextField runat="server" ID="txtTCKimlikNoYeni" FieldLabel="Yeni TC Kimlik No" />
                                                                    </Items>
                                                                    <BottomBar>
                                                                        <ext:Toolbar runat="server">
                                                                            <Items>
                                                                                <ext:Button runat="server" ID="btnTCKimlikNoDegistirKaydet" Icon="DiskUpload" Text="Kaydet">
                                                                                    <DirectEvents>
                                                                                        <Click OnEvent="btnTCKimlikNoDegistir_Click">
                                                                                            <EventMask ShowMask="true" />
                                                                                            <ExtraParams>
                                                                                                <ext:Parameter Name="YeniTCKimlikNo" Mode="Raw" Value="txtTCKimlikNoYeni.getValue()" />
                                                                                            </ExtraParams>
                                                                                        </Click>
                                                                                    </DirectEvents>
                                                                                </ext:Button>
                                                                            </Items>
                                                                        </ext:Toolbar>
                                                                    </BottomBar>
                                                                </ext:FormPanel>
                                                            </Items>
                                                            <Listeners>
                                                                <Show Handler="setTimeout(function(){txtTCKimlikNoYeni.focus();},200);" />
                                                            </Listeners>
                                                        </ext:Menu>
                                                    </Menu>
                                                </ext:Button>
                                            </Items>
                                        </ext:CompositeField>
                                        <ext:TriggerField ID="txtSicilNo" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS003%>"
                                            Width="130">
                                            <Triggers>
                                                <ext:FieldTrigger Icon="SimpleArrowDown" />
                                                <ext:FieldTrigger Icon="SimpleArrowUp" />
                                            </Triggers>
                                            <DirectEvents>
                                                <TriggerClick OnEvent="txtSicilNo_TriggerClick">
                                                    <ExtraParams>
                                                        <ext:Parameter Name="tusNo" Mode="Raw" Value="index">
                                                        </ext:Parameter>
                                                    </ExtraParams>
                                                </TriggerClick>
                                            </DirectEvents>
                                        </ext:TriggerField>
                                        <ext:TextField ID="txtAd" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS004%>"
                                            AnchorHorizontal="97%" AllowBlank="false" />
                                        <ext:TextField ID="txtSoyad" runat="server" FieldLabel="Soyad" AnchorHorizontal="97%"
                                            AllowBlank="false" />
                                        <ext:TextField runat="server" ID="lblUnvan" FieldLabel="Unvanı" ReadOnly="true" AnchorHorizontal="97%" />
                                        <ext:TextField runat="server" ID="lblUnvanVekalet" FieldLabel="Vekalet/Rehber Unvanı"
                                            ReadOnly="true" AnchorHorizontal="97%" />
                                        <ext:TextField runat="server" ID="lblBirimi" FieldLabel="Birimi" ReadOnly="true"
                                            AnchorHorizontal="97%" />
                                        <ext:TextField runat="server" ID="lblGrvYeri" FieldLabel="Görev Yeri" ReadOnly="true"
                                            AnchorHorizontal="97%" />
                                        <ext:TextField ID="lblPersonelTur" runat="server" ReadOnly="true" AnchorHorizontal="97%"
                                            FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS079%>" />
                                        <ext:TextField ID="lblKadroBaslangicTarihi" runat="server" FieldLabel="Kadro Başlangıc Tarihi"
                                            ReadOnly="true" AnchorHorizontal="97%" />
                                        <ext:TextField ID="lblDereceEkGosterge" runat="server" FieldLabel="Derece EkGosterge"
                                            ReadOnly="true" AnchorHorizontal="97%" />
                                        <ext:ComboBox ID="cmbSosyalGuvence" runat="server" FieldLabel="Sosyal Güvence" AnchorHorizontal="97%"
                                            StoreID="StoreSosyalGuvence" DisplayField="AD" ValueField="KOD" Editable="false" />
                                        <ext:TextField ID="txtEmekliSicilNo" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS029%>"
                                            NoteAlign="Top" Width="100" />
                                        <ext:TextField ID="txtSSKSicilNo" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS035%>"
                                            NoteAlign="Top" Width="100" />
                                        <ext:TextField ID="txtBagkurSicilNo" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS037%>"
                                            NoteAlign="Top" Width="100" />
                                    </Items>
                                </ext:FormPanel>
                                <ext:FormPanel ID="pnlResim" runat="server" ColumnWidth="0.5" Frame="true" LabelWidth="140">
                                    <Items>
                                        <ext:Panel Layout="ColumnLayout" runat="server" Height="180">
                                            <Items>
                                                <ext:FormPanel runat="server" ColumnWidth="1" LabelWidth="140">
                                                    <Items>
                                                        <ext:DateField ID="txtIlkIseBaslamaTarihi" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPRM102%>"
                                                            Format="dd.MM.yyyy" />
                                                        <ext:DateField ID="txtKurumaBaslamaTarihi" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKA061%>"
                                                            Format="dd.MM.yyyy" />
                                                        <ext:DateField ID="txtAsaletTarihi" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKA060%>"
                                                            Format="dd.MM.yyyy" />
                                                        <ext:TextField runat="server" ID="txtArsivNo" FieldLabel="Arşiv No" AnchorHorizontal="97%" />
                                                        <ext:Checkbox runat="server" ID="chkAktifMi" FieldLabel="Aktif Mi" BoxLabel="Evet" Disabled="true" DisabledClass="x-form-cb-label" />
                                                        <ext:TextField runat="server" ID="txtGeldigiKurum" FieldLabel="Geldiği Kurum" AnchorHorizontal="97%" />
                                                        <ext:TextField runat="server" ID="txtGeldigiKurumSicili" FieldLabel="Maliye Muhasebe No"
                                                            AnchorHorizontal="97%" />
                                                    </Items>
                                                </ext:FormPanel>
                                                <ext:FormPanel runat="server" Width="130">
                                                    <Items>
                                                        <ext:Image ID="imgResim" runat="server" ImageUrl="../app_themes/images/bos.jpg" Width="125"
                                                            Height="160" HideLabel="true" />
                                                    </Items>
                                                </ext:FormPanel>
                                            </Items>
                                        </ext:Panel>
                                        <ext:TextField runat="server" ID="txtVergiDairesi" FieldLabel="<%$Resources:InsanKaynaklari,FRMORG101%>"
                                            AnchorHorizontal="97%" />
                                        <ext:TextField runat="server" ID="txtEmail" FieldLabel="E Mail" ReadOnly="true" Disabled="true"
                                            AnchorHorizontal="97%" />
                                        <ext:TextField runat="server" ID="txtIbanNo" FieldLabel="<%$Resources:InsanKaynaklari,FRMPBS003%>"
                                            AnchorHorizontal="97%" />
                                        <ext:ComboBox ID="cmbSakatlikDurumu" runat="server" Editable="false" TypeAhead="true"
                                            Mode="Local" ForceSelection="true" SelectOnFocus="true" FieldLabel="Sakatlık Durumu"
                                            NoteAlign="Top" DisplayField="AD" ValueField="KOD" TriggerAction="All" StoreID="sakatlikDurumuStore"
                                            AnchorHorizontal="97%" Hidden="true" />
                                        <ext:ComboBox ID="cmbSakatlikDerece" runat="server" ForceSelection="true" SelectOnFocus="true" FieldLabel="Engellilik Derecesi" Editable="false" AnchorHorizontal="97%">
                                            <Items>
                                                <ext:ListItem Text="Sakat Değil" Value="0" />
                                                <ext:ListItem Text="1. Derece" Value="1" />
                                                <ext:ListItem Text="2. Derece" Value="2" />
                                                <ext:ListItem Text="3. Derece" Value="3" />
                                            </Items>
                                        </ext:ComboBox>
                                        <ext:CheckboxGroup runat="server" ID="chkGrpOzelDurum" FieldLabel="Özel Durum">
                                            <Items>
                                                <ext:Checkbox runat="server" ID="chkTerorMagduru" FieldLabel="" BoxLabel="Terör Mağduru" />
                                                <ext:Checkbox runat="server" ID="chkHukumlu" FieldLabel="" BoxLabel="Hükümlü" />
                                                <ext:Checkbox runat="server" ID="chkKorumayaMuhtac" FieldLabel="" BoxLabel="Korumaya Muhtaç" />
                                            </Items>
                                        </ext:CheckboxGroup>
                                        <ext:TextField runat="server" ID="txtRumuz" FieldLabel="Rumuz" MaxLengthText="10"
                                            MaxLength="10" AnchorHorizontal="97%">
                                        </ext:TextField>
                                        <%--    <ext:TextField runat="server" ID="txtTitr" FieldLabel="Title" AnchorHorizontal="97%">
                                    </ext:TextField>--%>
                                        <ext:ComboBox ID="txtTitr" runat="server" FieldLabel="Ak. Unvan" AnchorHorizontal="97%"
                                            Editable="true">
                                            <Items>
                                                <ext:ListItem Text="" Value="" />
                                                <ext:ListItem Text="Prof.Dr." Value="Prof.Dr." />
                                                <ext:ListItem Text="Prof." Value="Prof." />
                                                <ext:ListItem Text="Doç.Dr." Value="Doç.Dr." />
                                                <ext:ListItem Text="Doç." Value="Doç." />
                                                <ext:ListItem Text="Yrd.Doç.Dr." Value="Yrd.Doç.Dr." />
                                                <ext:ListItem Text="Yrd.Doç." Value="Yrd.Doç." />
                                                <ext:ListItem Text="Dr." Value="Dr." />
                                            </Items>
                                        </ext:ComboBox>
                                    </Items>
                                </ext:FormPanel>
                            </Items>
                        </ext:Panel>
                        <ext:Panel runat="server" ID="pnlEkBilgi" AutoScroll="true" Title="<%$Resources:InsanKaynaklari,FRMPKS083%>"
                            Frame="true" LabelWidth="0" Layout="ColumnLayout" AnchorHorizontal="100%">
                            <Items>
                                <ext:FormPanel runat="server" ColumnWidth="0.5" AutoScroll="true">
                                    <Items>
                                        <ext:ComboBox ID="ddlCinsiyet" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS006%>"
                                            AnchorHorizontal="95%" StoreID="cinsiyetStore" DisplayField="AD" Editable="false"
                                            ValueField="KOD">
                                        </ext:ComboBox>
                                        <ext:TextField ID="txtIlkSoyad" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS009%>"
                                            AnchorHorizontal="95%" Hidden="false">
                                        </ext:TextField>
                                        <ext:TextField ID="txtBabaAd" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS011%>"
                                            NoteAlign="Top" AnchorHorizontal="95%" AllowBlank="false">
                                        </ext:TextField>
                                        <ext:TextField ID="txtAnaAd" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS010%>"
                                            NoteAlign="Top" AnchorHorizontal="95%" AllowBlank="false">
                                        </ext:TextField>
                                        <ext:DateField ID="txtDogumTarihi" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS013%>"
                                            Format="dd.MM.yyyy" />
                                        <ext:TextField ID="txtDogumYeri" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS012%>"
                                            NoteAlign="Top" AnchorHorizontal="95%">
                                        </ext:TextField>
                                        <ext:ComboBox ID="ddlMedeniHali" runat="server" Editable="true" TypeAhead="true"
                                            Mode="Local" ForceSelection="true" SelectOnFocus="true" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS014%>"
                                            NoteAlign="Top" DisplayField="AD" ValueField="KOD" TriggerAction="All" StoreID="medeniHaliStore"
                                            Width="150px">
                                        </ext:ComboBox>
                                        <ext:TextField ID="txtDin" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS084%>"
                                            NoteAlign="Top" AnchorHorizontal="95%">
                                        </ext:TextField>
                                        <ext:ComboBox ID="ddlKanGrubu" runat="server" FieldLabel="<%$Resources:Personel,FRMPKS017%>"
                                            NoteAlign="Top" AnchorHorizontal="95%" HideMode="Display" Editable="false">
                                            <Items>
                                                <ext:ListItem Text="" Value=""></ext:ListItem>
                                                <ext:ListItem Text="<%$Resources:Personel,FRMORTK001%>" Value="<%$Resources:Personel,FRMORTK001%>"></ext:ListItem>
                                                <ext:ListItem Text="<%$Resources:Personel,FRMORTK002%>" Value="<%$Resources:Personel,FRMORTK002%>"></ext:ListItem>
                                                <ext:ListItem Text="<%$Resources:Personel,FRMORTK003%>" Value="<%$Resources:Personel,FRMORTK003%>"></ext:ListItem>
                                                <ext:ListItem Text="<%$Resources:Personel,FRMORTK004%>" Value="<%$Resources:Personel,FRMORTK004%>"></ext:ListItem>
                                                <ext:ListItem Text="<%$Resources:Personel,FRMORTK005%>" Value="<%$Resources:Personel,FRMORTK005%>"></ext:ListItem>
                                                <ext:ListItem Text="<%$Resources:Personel,FRMORTK006%>" Value="<%$Resources:Personel,FRMORTK006%>"></ext:ListItem>
                                                <ext:ListItem Text="<%$Resources:Personel,FRMORTK007%>" Value="<%$Resources:Personel,FRMORTK007%>"></ext:ListItem>
                                                <ext:ListItem Text="<%$Resources:Personel,FRMORTK008%>" Value="<%$Resources:Personel,FRMORTK008%>"></ext:ListItem>
                                            </Items>
                                        </ext:ComboBox>

                                        <ext:FieldSet runat="server" Title="Pasaport Bilgileri" AnchorHorizontal="95%">
                                            <Items>
                                                <ext:DisplayField runat="server" Height="10" />
                                                <ext:TextField ID="txtPasaportNo" runat="server" FieldLabel="Pasaport No" NoteAlign="Top" AnchorHorizontal="95%" AllowBlank="false">
                                                </ext:TextField>
                                                <ext:DateField ID="txtPasaportVerilisTarihi" runat="server" FieldLabel="Veriliş Tarihi"
                                                    Format="dd.MM.yyyy" />
                                                <ext:TextField ID="txtPasaportVerildigiYer" runat="server" FieldLabel="Verildiği Yer"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:TextField>
                                                <ext:TextField ID="txtPasaportVerenMakam" runat="server" FieldLabel="Veren Makam"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:TextField>
                                                <ext:NumberField ID="txtPasaportSuresi" runat="server" FieldLabel="Pasaport Süresi"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:NumberField>
                                            </Items>
                                        </ext:FieldSet>

                                    </Items>
                                </ext:FormPanel>

                                <ext:FormPanel runat="server" ColumnWidth="0.5" AutoScroll="true">
                                    <Items>
                                        <ext:FormPanel runat="server" AnchorHorizontal="98%">
                                            <Items>
                                                <ext:TextField ID="txtCuzdanSeriNo" runat="server" NoteAlign="Top" AnchorHorizontal="95%"
                                                    FieldLabel="Cüzdan Seri No">
                                                </ext:TextField>
                                                <ext:TextField ID="txtCuzdanKayitNo" runat="server" NoteAlign="Top" AnchorHorizontal="95%"
                                                    FieldLabel="Cüzdan Kayıt No">
                                                </ext:TextField>
                                                <ext:ComboBox ID="ddlNufusIl" runat="server" TypeAhead="true" Mode="Local" ForceSelection="true"
                                                    NoteAlign="Top" AnchorHorizontal="95%" StoreID="ilStore" DisplayField="AD" ValueField="KOD"
                                                    SelectOnFocus="true" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS026%>" ReadOnly="true">
                                                    <GetListParent Handler="return this.el.up('.x-menu');" />
                                                    <DirectEvents>
                                                        <Change OnEvent="IlBilgisiDegisti">
                                                            <ExtraParams>
                                                                <ext:Parameter Name="ilKod" Mode="Raw" Value="#{ddlNufusIl}.getValue()" />
                                                            </ExtraParams>
                                                        </Change>
                                                    </DirectEvents>
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Clear" HideTrigger="true" />
                                                    </Triggers>
                                                </ext:ComboBox>
                                                <ext:ComboBox ID="ddlNufusIlce" runat="server" TypeAhead="true" Mode="Local" ForceSelection="true"
                                                    FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS027%>" NoteAlign="Top" AnchorHorizontal="95%"
                                                    StoreID="ilceStore" DisplayField="AD" ValueField="KOD" TriggerAction="All" SelectOnFocus="true"
                                                    ReadOnly="true">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Clear" HideTrigger="true" />
                                                    </Triggers>
                                                </ext:ComboBox>
                                                <ext:TextField ID="txtMahalle" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS030%>"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:TextField>
                                                <ext:TextField ID="txtCiltNo" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS032%>"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:TextField>
                                                <ext:TextField ID="txtAileSiraNo" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS036%>"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:TextField>
                                                <ext:TextField ID="txtSiraNo" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS034%>"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:TextField>
                                                <ext:TextField ID="txtVerilisNedeni" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS038%>"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:TextField>
                                                <ext:TextField ID="txtVerildigiYer" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS040%>"
                                                    NoteAlign="Top" AnchorHorizontal="95%">
                                                </ext:TextField>
                                                <ext:DateField ID="txtVerilisTarihi" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS042%>"
                                                    Format="dd.MM.yyyy" />
                                            </Items>
                                        </ext:FormPanel>
                                        <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                            Frame="true" TrackMouseOver="true" StoreID="BelgeStore" HideHeaders="true" Height="150"
                                            HideLabel="true" AnchorHorizontal="95%">
                                            <TopBar>
                                                <ext:Toolbar runat="server">
                                                    <Items>
                                                        <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                            ButtonText="Belge Ekle">
                                                            <DirectEvents>
                                                                <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                            </DirectEvents>
                                                        </ext:FileUploadField>
                                                    </Items>
                                                </ext:Toolbar>
                                            </TopBar>
                                            <ColumnModel ID="ColumnModel2" runat="server">
                                                <Columns>
                                                    <ext:RowNumbererColumn />
                                                    <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Width="250" />
                                                    <ext:CommandColumn Width="30">
                                                        <Commands>
                                                            <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB037 %>" />
                                                        </Commands>
                                                    </ext:CommandColumn>
                                                    <ext:CommandColumn Width="30">
                                                        <Commands>
                                                            <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB038 %>" />
                                                        </Commands>
                                                    </ext:CommandColumn>
                                                </Columns>
                                            </ColumnModel>
                                            <Listeners>
                                                <Command Fn="KomutCalistir" />
                                            </Listeners>
                                            <SelectionModel>
                                                <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                                </ext:RowSelectionModel>
                                            </SelectionModel>
                                        </ext:GridPanel>
                                    </Items>
                                </ext:FormPanel>

                            </Items>
                        </ext:Panel>
                    </Items>
                    <Listeners>
                        <TabChange Fn="GizleAc" />
                    </Listeners>
                </ext:TabPanel>
            </Items>
        </ext:Viewport>
        <ext:Store runat="server" ID="storeUnvan">
            <Reader>
                <ext:JsonReader IDProperty="UnvanKod">
                    <Fields>
                        <ext:RecordField Name="UnvanKod" />
                        <ext:RecordField Name="UnvanAd" />
                    </Fields>
                </ext:JsonReader>
            </Reader>
        </ext:Store>
        <ext:Window runat="server" ID="wndBirimUnvanOrgAl" Layout="FormLayout" Modal="true"
            Hidden="true" Width="500" Height="240" Title="Yeni Personel Birim/Unvan/Tür Girişi"
            Padding="10">
            <TopBar>
                <ext:Toolbar runat="server">
                    <Items>
                        <ext:Button Icon="Accept" Text="Kaydet" runat="server">
                            <Listeners>
                                <Click Handler="PersonelK.btnKaydet_Click();" />
                            </Listeners>
                        </ext:Button>
                        <ext:Button Icon="Decline" Text="Kapat" runat="server">
                            <Listeners>
                                <Click Handler="wndBirimUnvanOrgAl.hide()" />
                            </Listeners>
                        </ext:Button>
                    </Items>
                </ext:Toolbar>
            </TopBar>
            <Items>
                <ext:ExtOrgSecim ID="ddlBirim" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>"
                    AnchorHorizontal="97%" />
                <ext:ComboBox ID="cmbPersonelTip" runat="server" Editable="false" TypeAhead="true"
                    Mode="Local" ForceSelection="true" SelectOnFocus="true" DisplayField="ad" ValueField="kod"
                    FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS079%>" AnchorHorizontal="96%">
                    <Store>
                        <ext:Store ID="personelTipStore" runat="server">
                            <Reader>
                                <ext:JsonReader IDProperty="kod">
                                    <Fields>
                                        <ext:RecordField Name="kod" Type="Int" />
                                        <ext:RecordField Name="ad" />
                                    </Fields>
                                </ext:JsonReader>
                            </Reader>
                        </ext:Store>
                    </Store>
                    <DirectEvents>
                        <Change OnEvent="cmbPersonelTipDegisti" />
                    </DirectEvents>
                </ext:ComboBox>
                <ext:ComboBox ID="cmbUnvan" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                    ForceSelection="true" StoreID="storeUnvan" DisplayField="UnvanAd" ValueField="UnvanKod"
                    AnchorHorizontal="97%" FieldLabel="Unvan" />
                <ext:TextField ID="txtKadroDerece" runat="server" Width="50" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK056 %>" />
                <ext:TextField ID="txtEkGosterge" runat="server" Width="50" FieldLabel="Ek Gösterge" />
                <ext:ComboBox ID="cmbAtanacagiKadro" runat="server" TypeAhead="true" Mode="Local"
                    ForceSelection="true" SelectOnFocus="true" DisplayField="Aciklama" ValueField="ID"
                    FieldLabel="Atanacağı Kadro" AnchorHorizontal="96%" Hidden="true">
                    <Triggers>
                        <ext:FieldTrigger Icon="Clear" />
                    </Triggers>
                    <Listeners>
                        <TriggerClick Handler="cmbAtanacagiKadro.clear()" />
                    </Listeners>
                    <Store>
                        <ext:Store runat="server" ID="stoAtanacagiKadro">
                            <Reader>
                                <ext:JsonReader IDProperty="ID">
                                    <Fields>
                                        <ext:RecordField Name="ID" Type="String" />
                                        <ext:RecordField Name="Aciklama" Type="String" />
                                    </Fields>
                                </ext:JsonReader>
                            </Reader>
                        </ext:Store>
                    </Store>
                </ext:ComboBox>
            </Items>
        </ext:Window>
        <ext:Hidden runat="server" ID="sil" />
    </form>
</body>
</html>
