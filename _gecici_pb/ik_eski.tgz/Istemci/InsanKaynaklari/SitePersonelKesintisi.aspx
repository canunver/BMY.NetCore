﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.SitePersonelKesintisi" CodeBehind="SitePersonelKesintisi.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>Personel Site Kesintisi</title>
    <script type="text/javascript" language="javascript">
        function SatirDegisti() {
            if (smListe.hasSelection())
                Ext1.net.DirectMethods.Goster(smListe.getSelected().data.kod, smListe.getSelected().data.siteAdi, smListe.getSelected().data.blokNo, smListe.getSelected().data.daireNo, smListe.getSelected().data.personelAd, smListe.getSelected().data.unvanAd, smListe.getSelected().data.siteKod);
        }
        var ayRenderer = function (value) {
            var r = ayStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
        function Temizle() {
        }
        function Yukle() {
            //            hdnIlk.setValue("1");
            stoListe.reload();
        }
        function GridSatirEkle(grid, satirSayi) {
            try {
                var rowIndex = 0;
                for (var i = 0; i < satirSayi; i++) {
                    if (i == 0)
                        rowIndex = grid.addRecord();
                    else
                        grid.addRecord();
                }
                grid.getView().focusRow(rowIndex);
            } catch (e) {
            }
        }
        var giderTurRenderer = function (value) {
            var r = sozlukGiderStore.getById(value);
            if (Ext1.isEmpty(r))
                return "";
            return r.data.ad;
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager runat="server">
    </ext:ResourceManager>
    <ext:Hidden ID="hdnIlk" runat="server" />
    <ext:Hidden ID="hdnYil" runat="server" />
    <ext:Hidden ID="hdnAy" runat="server" />
    <ext:Hidden ID="hdnplKod" runat="server" />
    <ext:Hidden ID="hdnsktKod" runat="server" />
    <ext:Hidden ID="hdnsiteKod" runat="server" />
    <ext:Store ID="ayStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="blokStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="blokNo" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="siteStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="siteAdi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="sozlukGiderStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="ad" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="kesintiStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="giderKod" />
                    <ext:RecordField Name="aktif" />
                    <ext:RecordField Name="endex" />
                    <ext:RecordField Name="elden" />
                    <ext:RecordField Name="aciklama" />
                    <ext:RecordField Name="tutar" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout" Margins="104 20 10 20">
                <Items>
                    <ext:Panel ID="pnlSol" runat="server" Title="Personel Site Blok Arama" Width="600"
                        Collapsed="false" AutoScroll="true" Region="West" Split="true" Layout="BorderLayout">
                        <%--<Tools>
                            <ext:Tool CustomType="icon-clear" Fn="Temizle" Qtip="Alanları Boşalt">
                            </ext:Tool>
                        </Tools>--%>
                        <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server">
                                <Items>
                                    <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPBI003%>"
                                        Icon="ApplicationGo">
                                        <Listeners>
                                            <Click Handler="Yukle()" />
                                        </Listeners>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:FormPanel ID="FormPanel2" runat="server" Height="150" LabelWidth="100" Layout="AnchorLayout"
                                Frame="false" Header="false" Border="false" Padding="5" Region="North" LabelAlign="Left">
                                <Items>
                                    <ext:ComboBox runat="server" ID="ddlSiteAra" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite007%>"
                                        DisplayField="siteAdi" ValueField="kod" StoreID="siteStore" Width="300px">
                                        <DirectEvents>
                                            <Change OnEvent="SiteDegisti">
                                            </Change>
                                        </DirectEvents>
                                    </ext:ComboBox>
                                    <ext:ComboBox runat="server" ID="ddlBlokAra" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite044%>"
                                        Width="300px" DisplayField="blokNo" ValueField="kod" StoreID="blokStore">
                                    </ext:ComboBox>
                                    <ext:CompositeField ID="CompositeField1" runat="server">
                                        <Items>
                                            <ext:Label ID="Label2" runat="server" Text="Yıl: " Width="100px">
                                            </ext:Label>
                                            <ext:SpinnerField runat="server" ID="spnYilAra" Width="195px" />
                                        </Items>
                                    </ext:CompositeField>
                                    <ext:ComboBox runat="server" ID="ddlAyAra" StoreID="ayStore" DisplayField="AD" ValueField="KOD"
                                        FieldLabel="Ay" Width="300px">
                                    </ext:ComboBox>
                                </Items>
                            </ext:FormPanel>
                            <ext:Panel ID="Panel2" runat="server" Border="false" Region="Center">
                                <Items>
                                    <ext:FitLayout ID="fitLayout3" runat="server">
                                        <Items>
                                            <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                                Layout="FitLayout" Width="350" Border="false">
                                                <Store>
                                                    <ext:Store runat="server" ID="stoListe" OnRefreshData="stoListe_ReadData" AutoLoad="true"
                                                        RemotePaging="true">
                                                        <Reader>
                                                            <ext:JsonReader>
                                                                <Fields>
                                                                    <ext:RecordField Name="kod" Type="Int" />
                                                                    <ext:RecordField Name="siteAdi" Type="String" />
                                                                    <ext:RecordField Name="blokNo" Type="String" />
                                                                    <ext:RecordField Name="daireNo" Type="Int" />
                                                                    <ext:RecordField Name="personelAd" Type="String" />
                                                                    <ext:RecordField Name="unvanAd" Type="String" />
                                                                    <ext:RecordField Name="siteKod" Type="String" />
                                                                </Fields>
                                                            </ext:JsonReader>
                                                        </Reader>
                                                    </ext:Store>
                                                </Store>
                                                <ColumnModel>
                                                    <Columns>
                                                        <ext:Column DataIndex="siteAdi" ColumnID="siteAdi" Header="Site Adı" Width="100px" />
                                                        <ext:Column DataIndex="blokNo" ColumnID="blokNo" Header="Blok No" Width="80px" />
                                                        <ext:Column DataIndex="daireNo" ColumnID="daireNo" Header="Daire No" Width="80px" />
                                                        <ext:Column DataIndex="personelAd" ColumnID="personelAd" Header="Personel Ad" Width="150px" />
                                                        <ext:Column DataIndex="unvanAd" ColumnID="unvanAd" Header="Unvan Ad" Width="150px" />
                                                    </Columns>
                                                </ColumnModel>
                                                <SelectionModel>
                                                    <ext:RowSelectionModel runat="server" ID="smListe">
                                                        <Listeners>
                                                            <SelectionChange Fn="SatirDegisti" />
                                                        </Listeners>
                                                    </ext:RowSelectionModel>
                                                </SelectionModel>
                                            </ext:GridPanel>
                                        </Items>
                                    </ext:FitLayout>
                                </Items>
                            </ext:Panel>
                        </Items>
                    </ext:Panel>
                    <ext:Panel ID="Panel3" runat="server" Border="false" Region="Center" Layout="RowLayout">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <%--   <ext:Button ID="btnYeni" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                        TabIndex="18" Icon="PageWhite">
                                        <DirectEvents>
                                            <Click OnEvent="btnYeni_Click">
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>--%>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite037%>"
                                        TabIndex="17" Icon="DatabaseSave">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, LojmanSite038%>"
                                                    Message="<%$ Resources:InsanKaynaklari, LojmanSite039%>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, LojmanSite040%>" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="kesintiBilgileri" Value="Ext1.util.JSON.encode(#{gridKesinti}.getRowsValues())"
                                                        Mode="Raw" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnSil" runat="server" Text="Sil" Icon="TableDelete">
                                        <DirectEvents>
                                            <Click OnEvent="btnSil_Click">
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:FormPanel ID="FormPanel1" runat="server" Border="false" Region="Center" Layout="RowLayout"
                                Padding="5" ButtonAlign="Center" AutoScroll="true">
                                <Items>
                                    <ext:TextField runat="server" Hidden="true" ID="txtKod" TabIndex="1" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite005%>">
                                        <ToolTips>
                                            <ext:ToolTip ID="ToolTip1" Html="<%$ Resources:InsanKaynaklari, LojmanSite006%>"
                                                runat="server">
                                            </ext:ToolTip>
                                        </ToolTips>
                                    </ext:TextField>
                                    <ext:TextField runat="server" ReadOnly="true" ID="txtSite" TabIndex="1" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite007%>">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ReadOnly="true" ID="txtBlok" TabIndex="2" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite044%>">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ReadOnly="true" ID="txtDaire" TabIndex="3" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite049%>">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ReadOnly="true" ID="txtPersonel" TabIndex="4" FieldLabel="<%$Resources:InsanKaynaklari,FRMIZD007%>">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ReadOnly="true" ID="txtUnvan" TabIndex="5" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAB036%>">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ReadOnly="true" ID="txtYil" TabIndex="6" FieldLabel="Yıl">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ReadOnly="true" ID="txtAy" TabIndex="7" FieldLabel="Ay">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ReadOnly="true" ID="txtToplamTutar" TabIndex="8" FieldLabel="ToplamTutar">
                                    </ext:TextField>
                                </Items>
                            </ext:FormPanel>
                            <ext:GridPanel ID="gridKesinti" runat="server" AutoScroll="true" Frame="true" StripeRows="true"
                                TrackMouseOver="true" AutoWidth="true" ColumnLines="true" StoreID="kesintiStore"
                                ClicksToEdit="1" Height="600" Header="true">
                                <ColumnModel>
                                    <Columns>
                                        <ext:RowNumbererColumn />
                                        <ext:Column Header="Gider Türü" DataIndex="giderKod" Width="90" Sortable="false">
                                            <Renderer Fn="giderTurRenderer" />
                                            <Editor>
                                                <ext:ComboBox runat="server" ID="ddlGiderGrid" DisplayField="ad" ValueField="kod"
                                                    StoreID="sozlukGiderStore" Mode="Local" TriggerAction="All" Resizable="true"
                                                    ListWidth="200">
                                                </ext:ComboBox>
                                            </Editor>
                                        </ext:Column>
                                        <ext:Column Header="Dahil Mi?" DataIndex="aktif" Width="50" Sortable="false">
                                            <Editor>
                                                <ext:Checkbox runat="server" ID="chkAktif">
                                                </ext:Checkbox>
                                            </Editor>
                                        </ext:Column>
                                        <ext:Column Header="Endex" DataIndex="endex" Width="50" Sortable="false">
                                            <Renderer Handler="return Ext1.util.Format.number(value, '0.000,00/i');" />
                                            <Editor>
                                                <ext:TextField runat="server" ID="txtEndexGrid">
                                                </ext:TextField>
                                            </Editor>
                                        </ext:Column>
                                        <ext:Column Header="Elden" DataIndex="elden" Width="50" Sortable="false">
                                            <Renderer Handler="return Ext1.util.Format.number(value, '0.000,00/i');" />
                                            <Editor>
                                                <ext:TextField runat="server" ID="txtEldenGrid">
                                                </ext:TextField>
                                            </Editor>
                                        </ext:Column>
                                            <ext:Column Header="Tutar" DataIndex="tutar" Width="50" Sortable="false">
                                            <Renderer Handler="return Ext1.util.Format.number(value, '0.000,00/i');" />                                            
                                        </ext:Column>
                                        <ext:Column Header="Açıklama" DataIndex="aciklama" Width="250" Sortable="false">
                                            <Editor>
                                                <ext:TextField runat="server" ID="txtAciklamaGrid">
                                                </ext:TextField>
                                            </Editor>
                                        </ext:Column>
                                    </Columns>
                                </ColumnModel>
                                <View>
                                    <ext:GridView ID="GridView1" ForceFit="true" runat="server">
                                    </ext:GridView>
                                </View>
                                <TopBar>
                                    <ext:Toolbar ID="Toolbar3" runat="server">
                                        <Items>
                                            <ext:SplitButton ID="btnYeniSatir" runat="server" Text="Yeni Satır" Icon="Add">
                                                <Listeners>
                                                    <Click Handler="GridSatirEkle(#{gridKesinti}, 1);" />
                                                </Listeners>
                                            </ext:SplitButton>
                                            <ext:Button ID="btnSatirSil" runat="server" Text="Satır Sil" Icon="Delete" Disabled="true">
                                                <Listeners>
                                                    <Click Handler="#{gridKesinti}.deleteSelected(); if (!#{gridKesinti}.hasSelection()) {#{btnSatirSil}.disable();}" />
                                                </Listeners>
                                            </ext:Button>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                                <SelectionModel>
                                    <ext:RowSelectionModel ID="RowSelectionModel1" SingleSelect="false" runat="server">
                                        <Listeners>
                                            <RowSelect Handler="#{btnSatirSil}.enable();" />
                                            <RowDeselect Handler="if (!#{gridKesinti}.hasSelection()) {#{btnSatirSil}.disable();}" />
                                        </Listeners>
                                    </ext:RowSelectionModel>
                                </SelectionModel>
                            </ext:GridPanel>
                        </Items>
                    </ext:Panel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
