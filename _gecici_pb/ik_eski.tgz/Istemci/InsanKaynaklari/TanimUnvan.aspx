﻿<%@ Page Language="C#" CodeBehind="TanimUnvan.aspx.cs" Inherits="InsanKaynaklari.TanimUnvan" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="kod" Type="Int" />
                    <ext:RecordField Name="ad" Type="String" />
                    <ext:RecordField Name="sinifAdKisa" Type="String" />
                    <ext:RecordField Name="siraNo" Type="Int" />
                    <ext:RecordField Name="sinifKod" Type="Int" />
                    <ext:RecordField Name="sinifAd" Type="String" />
                    <ext:RecordField Name="yonetici" Type="Int" />
                    <ext:RecordField Name="yoneticiAd" Type="String" />
                    <ext:RecordField Name="aktif" Type="Boolean" />
                    <ext:RecordField Name="aktifAd" Type="String" />
                    <ext:RecordField Name="hitapKod" Type="String" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreSinif" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center MarginsSummary="104 20 10 20">
                    <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:Personel, FRMPRK016%>"
                                        Icon="Disk">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:Personel,FRMORT074 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:Personel,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:Personel, FRMPRK017%>"
                                        Icon="Delete">
                                        <DirectEvents>
                                            <Click OnEvent="btnSil_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:Personel,FRMORT075 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:Personel,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnAra" runat="server" Text="Bul" Icon="Find">
                                        <DirectEvents>
                                            <Click OnEvent="btnAra_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:Personel,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:Personel, FRMPRK018%>"
                                        Icon="PageWhite">
                                        <DirectEvents>
                                            <Click OnEvent="btnTemizle_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:Personel,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="BorderLayout2" runat="server">
                                <North>
                                    <ext:FormPanel ID="FormPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                                        AutoHeight="true">
                                        <Items>
                                            <ext:TextField runat="server" ID="txtUnvanKodu" Width="200" FieldLabel="Unvan Kodu"
                                                NoteAlign="Top" />
                                            <ext:TextField runat="server" ID="txtUnvanAdi" Width="200" FieldLabel="Unvan Adı"
                                                NoteAlign="Top" />
                                            <ext:TextField runat="server" ID="txtSinifAdiKisa" Width="200" FieldLabel="Sınıf Kısa Adı"
                                                NoteAlign="Top" />
                                            <ext:ComboBox runat="server" ID="cmbSinif" Width="200" FieldLabel="Sınıf" StoreID="StoreSinif"
                                                DisplayField="AD" ValueField="KOD">
                                            </ext:ComboBox>
                                            <ext:TextField runat="server" ID="txtSiraNo" Width="200" FieldLabel="Sıra No" NoteAlign="Top" />
                                            <ext:Checkbox runat="server" ID="chkYonetici" Width="200" FieldLabel="Yönetici" NoteAlign="Top" />
                                            <ext:Checkbox runat="server" ID="chkAktif" Width="200" FieldLabel="Aktif" NoteAlign="Top" />
                                            <ext:TextField runat="server" ID="txthitapKod" Width="200" FieldLabel="Hitap Kod" NoteAlign="Top" />
                                        </Items>
                                    </ext:FormPanel>
                                </North>
                                <Center Split="true">
                                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                        StoreID="ListeStore" Border="true" AutoExpandColumn="ad" Layout="FitLayout" Width="400">
                                        <ColumnModel ID="ColumnModel1" runat="server">
                                            <Columns>
                                                <ext:Column DataIndex="kod" Header="Unvan Kodu" />
                                                <ext:Column DataIndex="ad" Header="Unvan Adı" />
                                                <ext:Column DataIndex="sinifAdKisa" Header="Sınıf Kısa Ad" />
                                                <ext:Column DataIndex="siraNo" Header="Sıra No" />
                                                <ext:Column DataIndex="sinifAd" Header="Sınıf" Width="200" />
                                                <ext:Column DataIndex="yonetici" Header="Yönetici" Hidden="true" />
                                                <ext:Column DataIndex="yoneticiAd" Header="Yönetici" />
                                                <ext:Column DataIndex="aktifAd" Header="Aktif" />
                                                <ext:Column DataIndex="hitapKod" Header="Hitap" />
                                            </Columns>
                                        </ColumnModel>
                                        <SelectionModel>
                                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                                <DirectEvents>
                                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:Personel,FRMPAB020%>" />
                                                        <ExtraParams>
                                                            <ext:Parameter Name="RowValue" Value="Ext1.encode(#{grdListe}.getRowsValues({selectedOnly:true}))"
                                                                Mode="Raw" />
                                                        </ExtraParams>
                                                    </RowSelect>
                                                </DirectEvents>
                                            </ext:RowSelectionModel>
                                        </SelectionModel>
                                        <BottomBar>
                                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" HideRefresh="true" PageSize="100">
                                                <Items>
                                                </Items>
                                            </ext:PagingToolbar>
                                        </BottomBar>
                                    </ext:GridPanel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
