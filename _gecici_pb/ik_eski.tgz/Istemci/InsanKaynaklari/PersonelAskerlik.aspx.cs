﻿using System;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Collections;
using System.Collections.Generic;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel adres ve iletişim Sınıfı
    /// </summary>
    public partial class PersonelAskerlik : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();      

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnKod.Value = (Request.QueryString["personelKod"] + "").Trim();

            //personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnAdres.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                Temizle();
                AskerlikDurumDoldur();
                RutbeDoldur();
                SinifDoldur();

                if(TNS.DEG.Arac.ManasKullaniyor())
                {
                    cmpAsker.Visible = false;
                    cmpTerhis.Visible = false;
                    txtTecilTarihi.Visible = false;
                    txtMuafNedeni.Visible = false;
                    chkBorclanma.Visible = false;
                    cmpRS.Visible = false;
                    cmpNasp.Visible = false;
                    yedekSubay.Visible = false;
                    yedekSubay2.Visible = false;
                    txtIbrazIntıkalTarihi.Visible = false;
                    txtAciklama.Visible = false;
                }

                Listele(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel İletişim Adres bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel İletişim Adres tipinde sınıf</param>
        public void Listele(int kod)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            try
            {
                PAskerlik askerlik = servisIKY.PersonelAskerlikListele(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
                if (!askerlik.sonuc.islemSonuc)
                {
                    GenelIslemler.MesajKutusu("Hata", askerlik.sonuc.hataStr);
                    return;
                }
                if (askerlik.askerlikDurumu > 0)
                {
                    ddlAskerlikDurumu.Value = askerlik.askerlikDurumu + ":" + askerlik.askerlikDurumuKayitKod; //OrtakFonksiyonlar.ConvertToInt(askerlik.askerlikDurumuKayitKod.Split('.')[1], 0);
                    X.AddScript("AskerlikDurumuDegisti();");
                }
                txtDuhulTarihi.Text = askerlik.askerlikBaslamaTarihi.ToString();
                txtTerhisTarihi.Text = askerlik.terhisTarihi.ToString();
                txtTecilTarihi.Text = askerlik.tecilTarihi.ToString();
                txtTerhisBelgeTarihi.Text = askerlik.belgeTarihi.ToString();
                txtAstegmenNaspTarihi.Text = askerlik.astegmenNaspTarihi.ToString();
                txtTegmenNaspTarihi.Text = askerlik.tegmenNaspTarihi.ToString();
                txtYedekSubayOkuluGirisTarihi.Text = askerlik.yedekSubayOkuluGirisTarihi.ToString();
                txtErYedekSubayGecisTarihi.Text = askerlik.erYedekSubayGecisTarihi.ToString();
                txtErYedekSubayKitaBaslamaTarihi.Text = askerlik.erYedekSubayKitaHizmetiBaslamaTarihi.ToString();
                txtErYedekSubayKitaBitisTarihi.Text = askerlik.erYedekSubayKitaHizmetiBitisTarihi.ToString();
                txtIbrazIntıkalTarihi.Text = askerlik.ibrazIntikalTarihi.ToString();
                txtMuafNedeni.Text = askerlik.askerlikMuafNeden;
                txtSayilmayanGunSayisi.Text = askerlik.sayilmayanGunSayisi.ToString();
                txtCuzdanNo.Text = askerlik.askerlikCuzdanNo;
                ddlRutbe.Value = askerlik.rutbesi;
                ddlSinif.Value = askerlik.sinifi;
                if (askerlik.borclanmaVarMi > 0)
                    chkBorclanma.Checked = true;
                else
                    chkBorclanma.Checked = false;
                txtAskerlikSubesi.Text = askerlik.askerlikSubesi;
                txtSinifDonemSicilNo.Text = askerlik.sinifDonemSicilNo;
                txtErYedekSubayGorevYeri.Text = askerlik.erYedekSubayGorevYeri;
                txtAciklama.Text = askerlik.aciklama;
                txtTerhisBelgeNo.Text = askerlik.belgeNo;
                BelgeListesiDoldur();
            }
            catch(Exception ex)
            {
                GenelIslemler.MesajKutusu(this, ex.Message);
                return;
            }
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel İletişim(Adres) bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet();
        }

        protected string Kaydet()
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                hata += Resources.InsanKaynaklari.FRMPAB002 + "<br>";

            if (ddlAskerlikDurumu.Value == null)
                hata += "Askerlik durum bilgisini boş geçmeyiniz.<br>";       

            //if (Genel.TarihAlaniDegerVer(txtErYedekSubayKitaBaslamaTarihi).Oku() > Genel.TarihAlaniDegerVer(txtErYedekSubayKitaBitisTarihi).Oku())
            //    hata += " Er yedek subay kıta başlama tarihi bitiş tarihinden büyük olamaz.";

            //if (Genel.TarihAlaniDegerVer(txtDuhulTarihi).Oku() > Genel.TarihAlaniDegerVer(txtTerhisTarihi).Oku() || Genel.TarihAlaniDegerVer(txtDuhulTarihi).Oku() > Genel.TarihAlaniDegerVer(txtTerhisBelgeTarihi).Oku())
            //    hata += " Duhul tarihi terhis/terhis belge tarihinden büyük olamaz.";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return hata;
            }

            PAskerlik askerlik = new TNS.IKY.PAskerlik();
            askerlik.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            if (ddlAskerlikDurumu.Value != null)
            {
                string[] arr = ddlAskerlikDurumu.Value.ToString().Split(':');
                askerlik.askerlikDurumu = OrtakFonksiyonlar.ConvertToInt(arr[0], 0);
            }
            askerlik.askerlikBaslamaTarihi = Genel.TarihAlaniDegerVer(txtDuhulTarihi);
            askerlik.terhisTarihi = Genel.TarihAlaniDegerVer(txtTerhisTarihi);
            askerlik.tecilTarihi = Genel.TarihAlaniDegerVer(txtTecilTarihi);
            askerlik.belgeTarihi = Genel.TarihAlaniDegerVer(txtTerhisBelgeTarihi);
            askerlik.astegmenNaspTarihi = Genel.TarihAlaniDegerVer(txtAstegmenNaspTarihi);
            askerlik.tegmenNaspTarihi = Genel.TarihAlaniDegerVer(txtTegmenNaspTarihi);
            askerlik.yedekSubayOkuluGirisTarihi = Genel.TarihAlaniDegerVer(txtYedekSubayOkuluGirisTarihi);
            askerlik.erYedekSubayGecisTarihi = Genel.TarihAlaniDegerVer(txtErYedekSubayGecisTarihi);
            askerlik.erYedekSubayKitaHizmetiBaslamaTarihi = Genel.TarihAlaniDegerVer(txtErYedekSubayKitaBaslamaTarihi);
            askerlik.erYedekSubayKitaHizmetiBitisTarihi = Genel.TarihAlaniDegerVer(txtErYedekSubayKitaBitisTarihi);
            askerlik.ibrazIntikalTarihi = Genel.TarihAlaniDegerVer(txtIbrazIntıkalTarihi);
            askerlik.askerlikMuafNeden = txtMuafNedeni.Text;
            askerlik.sayilmayanGunSayisi = OrtakFonksiyonlar.ConvertToInt(txtSayilmayanGunSayisi.Text, 0);
            askerlik.askerlikCuzdanNo = txtSayilmayanGunSayisi.Text;
            askerlik.rutbesi = OrtakFonksiyonlar.ConvertToInt(ddlRutbe.Value, 0);
            askerlik.sinifi = OrtakFonksiyonlar.ConvertToInt(ddlSinif.Value, 0);
            if (chkBorclanma.Checked)
                askerlik.borclanmaVarMi = 1;
            askerlik.askerlikSubesi = txtAskerlikSubesi.Text;
            askerlik.sinifDonemSicilNo = txtSinifDonemSicilNo.Text;
            askerlik.erYedekSubayGorevYeri = txtErYedekSubayGorevYeri.Text;
            askerlik.aciklama = txtAciklama.Text;
            askerlik.belgeNo = txtTerhisBelgeNo.Text;

            Sonuc sonuc = servisIKY.PersonelAskerlikKaydet(kullanan, askerlik);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPIA025);
                //Listele(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
            }

            return hata;
        }

        void Temizle()
        {
            
        }
        protected void AskerlikDurumDoldur()
        {
            ddlAskerlikDurumu.Items.Clear();
            askerlikDurumuStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.ASKERLIKDURUMU, 0).ToString().PadLeft(2, '0'), seviye = 2, ozel=true }); ;
            askerlikDurumuStore.DataBind();
        }
        protected void RutbeDoldur()
        {
            ddlRutbe.Items.Clear();
            rutbesiStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.ASKERLIKRUTBESI, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            rutbesiStore.DataBind();
        }
        protected void SinifDoldur()
        {
            ddlSinif.Items.Clear();
            sinifiStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.ASKERLIKSINIFI, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            sinifiStore.DataBind();
        }

        ///// <summary>
        ///// Sozluk bilgisini listeyen fonksiyon.
        ///// </summary>
        ///// <returns></returns>
        //public object[] AskerlikDurumYukle(Sozluk sozluk)
        //{
        //    ObjectArray sozluktmp = new ObjectArray();

        //    sozluktmp = servisIKY.SozlukListele(sozluk);

        //    ArrayList al = new ArrayList();
        //    al.Add(new object[] { 0, "" });
        //    string[] k;

        //    foreach (Sozluk s in sozluktmp.objeler)
        //    {
        //        k = s.kayitKod.Split('.');
        //        al.Add(new object[] { s.kod + ":" + OrtakFonksiyonlar.ConvertToInt(k[1],0), s.ad });
        //    }

        //    return (object[])al.ToArray(typeof(object[]));
        //}

        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELASKERLIK;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB041);
                return;
            }

            string hata = Kaydet();
            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELASKERLIK, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }
    }
}
