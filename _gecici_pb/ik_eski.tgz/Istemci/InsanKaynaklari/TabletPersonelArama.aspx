﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="TabletPersonelArama.aspx.cs"
    Inherits="InsanKaynaklari.TabletPersonelArama" %>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Personel Arama</title>
    <link href="../App_themes/BootStrap/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../App_themes/BootStrap/css/bootstrap.css" type="text/css" />
    <link href="../App_themes/BootStrap/css/sidebar.css" rel="stylesheet" />
    <%--    <link href="../App_themes/BootStrap/css/sidebar2.css" rel="stylesheet" />--%>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <%--   <link rel="stylesheet" href="../App_themes/BootStrap/css/bootstrap-multiselect.css"
        type="text/css" />--%>
    <%--<link rel="stylesheet" href="../App_themes/BootStrap/css/bootstrap-switch.css"
        type="text/css" />--%>
    <%--    <link rel="stylesheet" href="../App_themes/BootStrap/css/jquery.tree-multiselect.css"
        type="text/css" />--%>
    <%-- <script type="text/javascript" src="../App_themes/BootStrap/js/bootstrap-multiselect.js"></script>--%>
    <script type="text/javascript" src="../App_themes/BootStrap/js/bootstrap.min.js"></script>
    <%--  <script type="text/javascript" src="../App_themes/BootStrap/js/jquery.tree-multiselect.js"></script>--%>
    <%--<script type="text/javascript" src="../App_themes/BootStrap/js/bootstrap-switch.js"></script>--%>
    <style type="text/css">
        body
        {
            min-height: 100vh;
        }
        .kisiSinifi
        {
            width: 120px;
            height: 50px;
            text-align: center;
            font-weight: bold;
            font-size: large;
        }
        .chkPersonel
        {
            width: 50px;
            height: 40px;
        }
        .state-icon
        {
            left: -5px;
        }
        .list-group-item-primary
        {
            color: rgb(255, 255, 255);
            background-color: rgb(66, 139, 202);
        }
        .inset
        {
            overflow: auto;
            height: 100%;
            width: 100%;
            padding-top: 70px;
        }
        .content-header
        {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
            background-color: Black;
        }
        .scroll-top-wrapper
        {
            position: fixed;
            opacity: 0;
            visibility: hidden;
            overflow: hidden;
            text-align: center;
            z-index: 99999999;
            background-color: #777777;
            color: #eeeeee;
            width: 50px;
            height: 48px;
            line-height: 48px;
            right: 30px;
            bottom: 30px;
            padding-top: 2px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
            border-bottom-left-radius: 10px;
            -webkit-transition: all 0.5s ease-in-out;
            -moz-transition: all 0.5s ease-in-out;
            -ms-transition: all 0.5s ease-in-out;
            -o-transition: all 0.5s ease-in-out;
            transition: all 0.5s ease-in-out;
        }
        .scroll-top-wrapper:hover
        {
            background-color: #888888;
        }
        .scroll-top-wrapper.show
        {
            visibility: visible;
            cursor: pointer;
            opacity: 1.0;
        }
        .scroll-top-wrapper i.fa
        {
            line-height: inherit;
        }
        
        .yukle
        {
            height: 100%;
            width: 100%;
            margin: auto;
            margin-top: 10px;
            text-align: Center;
        }
        .searchclear
        {
            position: absolute;
            right: 5px;
            bottom: 0;
            height: 14px;
            font-size: 14px;
            color: #ccc;
            margin-top: 75px;
            left: 300px;
            cursor: pointer;
        }
        
        #xx
        {
            position: absolute;
            right: 5px;
            top: 0;
            bottom: 0;
            height: 14px;
            margin: auto;
            font-size: 14px;
            cursor: pointer;
            color: #ccc;
        }
        
        .panelsinifi
        {
            padding-bottom: 5px;
            width: 220px;
        }
        
        .pad
        {
            margin-left: 20px;
        }
        
        .renk
        {
            color: black;
            font-weight: bold;
            font-size: large;
            background-color: White;
            width: 225px;
            height: 50px;
            padding-left: 10px;
            padding-top: 15px;
            text-align: justify;
        }
        
        .divAra
        {
            margin-left: -20px;
        }
        
        div.tree-multiselect
        {
            background-color: #F8F8F8;
        }
        
        div.tree-multiselect div.title
        {
            background: white;
            color: Black;
            font-weight: bold;
        }
        
        div.tree-multiselect
        {
            margin-left: 20px;
            width: 220px;
        }
        
        div.tree-multiselect div.title > span.collapse-section
        {
            margin: 0 22px 0 -20px;
        }
        
        div.tree-multiselect > div.selections div.item
        {
            margin-left: 10px;
        }
        
        .sidebar-nav li a:hover, .sidebar-nav li.active
        {
            color: #333333;
        }
        
        #filtre div.row
        {
            padding: 10px 0 0 20px;
            width: 250px;
        }
        
        #filtre div.row .text-center
        {
            color: White;
            height: 10px;
        }
        
        #rapor div.row
        {
            padding: 10px 0 0 20px;
            width: 250px;
        }
        
        #rapor div.row .text-center
        {
            color: White;
            height: 10px;
        }
        
        .aratext
        {
            margin-top: 15px;
            margin-left: 10px;
        }
        
        .aratext2
        {
            margin-top: 15px;
            margin-left: 20px;
        }
        
        .clearable-input
        {
            position: relative;
            display: inline-block;
        }
        .clearable-input > input
        {
            padding-right: 1.4em;
        }
        .clearable-input > [data-clear-input]
        {
            display: none;
            position: absolute;
            top: 0;
            right: 0;
            font-weight: bold;
            font-size: 1.4em;
            padding: 0 2.5em;
            line-height: 1em;
            cursor: pointer;
        }
        .clearable-input > input::-ms-clear
        {
            display: none;
        }
        
        @media (max-width:767px)
        {
            .baslik
            {
                margin-left: 0;
            }
            .baslik2
            {
                margin-left: 0px;
            }
        
            .aratext
            {
                margin-top: 15px;
                margin-left: 10px;
            }
        
            .aratext2
            {
                margin-top: 15px;
                margin-left: 10px;
            }
        
            .divtop
            {
                padding-left: 240px;
            }
            .divtop2
            {
                padding-left: 0;
            }
        
            .divAra
            {
                margin-left: 0;
            }
        }
    </style>
    <script type="text/javascript">
        window.onscroll = function () { VerileriGetir() };
        function VerileriGetir() {
            var scroll = $(this).scrollTop();
            var uzunluk = $(document).height() - $(this).height();
            if (scroll == uzunluk && $("#hdnSatir")[0].value > 0) {
                //                $(".yukle").html("<img src='../App_themes/Images/loadingC.gif' id='load' />");
                $('#scrollModal').find('p').html("<img src='../App_themes/Images/loadingC.gif' id='load' />");
                $('#scrollModal').modal('show');
                //                $(".yukle").html("<button class=\"btn btn-lg btn-warning\"> <span class=\"glyphicon glyphicon-refresh glyphicon-refresh-animate\"></span>Loading...</button>");
                //                $(".yukle").html("<h3>Yükleniyor.....</h3><div class=\"progress progress-striped active page-progress-bar\"><div class=\"progress-bar\" style=\"width: 100%;\"></div></div>");

                var s = $(this).scrollTop();
                setTimeout(function () { KisiListele(true, -1); }, 1000);
            }
        }

        var navUa = navigator.userAgent;
        var androidMi = navUa.indexOf('Android') > -1;
        var chromeMu = navUa.indexOf('Chrome') > -1

        function SeciliKodlariGetir(tip, raporId, raporAd) {
            try {
                if (androidMi && !chromeMu)
                    document.forms[0].target = "_blank";
            }
            catch (e) {
            }

            var kodlar = "";
            $("input:checkbox[name=type]:checked").each(function () {
                kodlar += $(this).val() + ";";
            });
            $("#hdnKodlar")[0].value = kodlar;
            $("#hdnRapor")[0].value = raporId + "," + raporAd;
            var mesaj = "";
            if (tip == 1) {
                document.getElementById('btnRDevam').style.display = "inline-block";
                document.getElementById('btnMDevam').style.display = "none";
                document.getElementById('txtMailKisi').style.display = "none";
                mesaj = " Raporunu İndirmek İstediğinizden Eminmisiniz?";
            }
            else {
                document.getElementById('btnRDevam').style.display = "none";
                document.getElementById('btnMDevam').style.display = "inline-block";
                document.getElementById('txtMailKisi').style.display = "block";
                mesaj = " Raporunu Mail Göndermek İstediğinizden Eminmisiniz? Eminseniz Mail Göndereceğiniz Kişiyi Aşağıdaki Alana Girip 'Devam' Tuşuna Basınız.";
            }

            $('#mesajmodal').find('p').html(raporAd + mesaj);
            $('#mesajmodal').modal('show');
        }

        function getParameterByName(name) {
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
            return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        }

        $(document).ready(function () {

            Array.prototype.forEach.call(document.querySelectorAll('.clearable-input'), function (el) {
                var input = el.querySelector('input');

                conditionallyHideClearIcon();
                input.addEventListener('input', conditionallyHideClearIcon);
                el.querySelector('[data-clear-input]').addEventListener('click', function (e) {
                    input.value = '';
                    conditionallyHideClearIcon();
                });

                function conditionallyHideClearIcon(e) {
                    var target = (e && e.target) || input;
                    target.nextElementSibling.style.display = target.value ? 'block' : 'none';
                }
            });

            var ispostback = "<%= Page.IsPostBack%>";
            var dondu = "";
            if (ispostback == "False") {
                dondu = getParameterByName("dondu");
                if (dondu == "true") {
                    $("#cAktiflik li").each(function (idx, li) {
                        $(li).attr("data-checked", false);
                    });
                    $("#ptip li").each(function (idx, li) {
                        $(li).attr("data-checked", false);
                    });
                    var ak = [];
                    ak = getParameterByName("aktiflik").split(',');
                    if (ak[0] != "") {
                        for (var i = 0; i < ak.length; i++) {
                            $("#cAktiflik li").each(function (idx, li) {
                                if ($(li).val() == ak[i]) {
                                    $(li).attr("data-checked", true);
                                    $(li).addClass('active');
                                }
                            });
                        }
                    }

                    var pti = [];
                    pti = getParameterByName("tipler").split(',');
                    if (pti[0] != "") {
                        for (var a = 0; a < pti.length; a++) {
                            $("#ptip li").each(function (idx, li) {
                                if ($(li).text() == pti[a]) {
                                    $(li).attr("data-checked", true);
                                    $(li).addClass('active');
                                }
                            });
                        }
                    }
                    KisiListele(false, 4);
                }
            }


            $(".yukle").html('');

            $(".searchinput").keyup(function () {
                $(this).next().toggle(Boolean($(this).val()));
            });
            $(".searchclear").toggle(Boolean($(".searchinput").val()));
            $(".searchclear").click(function () {
                $("#txtAra2")[0].value = '';
                $(this).prev().val('').focus();
                $(this).hide();
            });

            $("#xx").click(function () {
                $("#txtAra2").val('');
            });

            $("#selectall").change(function () {
                $(".chkPersonel").prop('checked', $(this).prop("checked"));
            });

            $("#btnBas").click(function () {
                KisiListele(false, 1);
                return false;
            });

            $("#btnAra").click(function () {
                KisiListele(false, 2);
                return false;
            });

            $("#menu-toggle").click(function (e) {
                e.preventDefault();
                if (screen.width < 768) {
                    $("#baslik").toggleClass("baslik baslik2");
                }
                $("#wrapper").toggleClass("active");
                if ($('div.alan').is('.col-sm-6')) {
                    $('div.alan').removeClass('col-sm-6');
                    $('div.alan').addClass('col-sm-4');
                }
                else if ($('div.alan').is('.col-sm-4')) {
                    $('div.alan').removeClass('col-sm-4');
                    $('div.alan').addClass('col-sm-6');
                }
                if ($('div.alan').is('.col-md-4')) {
                    $('div.alan').removeClass('col-md-4');
                    $('div.alan').addClass('col-md-3');
                }
                else if ($('div.alan').is('.col-md-3')) {
                    $('div.alan').removeClass('col-md-3');
                    $('div.alan').addClass('col-md-4');
                }
            });

        });

        function KisiListele(ekle, btn) {

            var kelime = $("#txtAra2")[0].value;
            var counter = 0, aktiflik = "", pTipler = [], ptur = "";

            if (btn == -1) {
                kelime = $("#hdnSorgu")[0].value;
                aktiflik = $("#hdnAktiflik")[0].value;
                pTipler = $("#hdnPTipler")[0].value.split(',');
            }
            else {
                $("#cAktiflik li.active").each(function (idx, li) {
                    if (counter != 0)
                        aktiflik += ",";
                    aktiflik += $(li).val();
                    counter++;
                });
                $("#ptip li.active").each(function (idx, li) {
                    pTipler.push($(li).text());
                    ptur += $(li).text() + ",";
                });
                $("#hdnAktiflik")[0].value = aktiflik;
                $("#hdnPTipler")[0].value = pTipler;
            }

            var alansinifi = null;
            if (!ekle && btn != 4) {
                $("#thmListe").html('');
                $("#hdnSatir")[0].value = 0;
            }
            else {
                var alanlar = document.getElementById("thmListe").querySelectorAll(".alan");
                if (alanlar != null && alanlar[0] != null)
                    alansinifi = alanlar[0].getAttribute("class");
            }
            $("#hdnSorgu")[0].value = kelime;
            $("#txtAra2")[0].value = kelime;

            var resim = document.querySelector('input[name="optradio"]:checked').value;
            PageMethods.Listele(kelime, $("#hdnSatir")[0].value, aktiflik, pTipler, resim, OnSucceed, OnFailed);
            return false;

            function OnSucceed(tablo) {
                $(".yukle").html('');
                $('#scrollModal').modal('hide');
                if (!$('#wrapper').is('.active') && screen.width >= 768)
                    $("#menu-toggle").click();
                if ($('#wrapper').is('.active') && screen.width < 768)
                    $("#menu-toggle").click();
                if (tablo.tablo != "") {
                    $("#thmListe").append(tablo.tablo);
                    $("#hdnSatir")[0].value = tablo.satir;
                    $("#txtAra2").blur();
                    $("#thmListe").focus();
                    document.getElementById('alert').style.display = "none";
                    $('#sayilar').find('p').html('Toplam personel sayısı: ' + tablo.toplamKayit + ' Görüntülenen personel sayısı: ' + tablo.satir);
                    document.getElementById('sayilar').style.display = "block";

                    var gir = false;
                    if (alansinifi != null)
                        gir = true;

                    var x = document.getElementById("thmListe").querySelectorAll(".alan");
                    for (var i = 0; i < x.length; i++) {
                        var timeout;
                        var lastTap = 0;
                        x[i].addEventListener("touchend", function (event) {
                            var currentTime = new Date().getTime();
                            var tapLength = currentTime - lastTap;
                            clearTimeout(timeout);
                            if (tapLength < 500 && tapLength > 0) {
                                DetayaGit(this.id.substring(4), kelime, aktiflik, ptur, resim);
                                event.preventDefault();
                            } else {
                                timeout = setTimeout(function () {
                                    clearTimeout(timeout);
                                }, 500);
                            }
                            lastTap = currentTime;
                        });
                        if (gir)
                            x[i].setAttribute("class", alansinifi);
                    }
                }
                else {
                    if (!tablo.yukleme) {
                        $('#alert').find('p').html('Seçtiğiniz kriterlere ait personel bulunmamaktadır.');
                        document.getElementById('alert').style.display = "block";
                        document.getElementById('sayilar').style.display = "none";
                    }
                    else
                        $(".yukle").html('<b>Yüklenecek Personel Kalmadı.<b>');
                }

                $(".chkPersonel").prop('checked', $(".chkPersonel").prop("checked"));
            }

            function OnFailed(xhr, status) {
                $('#alert').find('p').html(xhr.responseText + " " + status);
                document.getElementById('alert').style.display = "block";
                document.getElementById('sayilar').style.display = "none";
            }
        }

        function DetayaGit(pkod, sorgu, aktiflik, tipler, resimBilgi) {
            document.location.href = "TabletPersonelDetay.aspx?pKod=" + pkod + "&sorgu=" + sorgu + "&dondu=true" + "&aktiflik=" + aktiflik + "&tipler=" + tipler + "&resim=" + resimBilgi;
        }
        function RaporaGit(dosyaMail) {
            var ptip = [];
            ptip = $("#hdnPTipler")[0].value.split(',');
            $(".searchclear").hide();
            document.getElementById('btnRDevam').style.display = "none";
            document.getElementById('btnMDevam').style.display = "none";
            document.getElementById('txtMailKisi').style.display = "none";
            $('#mesajmodal').find('p').html("<img src='../App_themes/Images/loadingC.gif' id='load' />");
            PageMethods.RaporUret(dosyaMail, $("#hdnRapor")[0].value, $("#hdnAktiflik")[0].value, ptip, $('#selectall').is(':checked'), $("#txtMailKisi")[0].value, $("#hdnKodlar")[0].value, $("#hdnSorgu")[0].value, OnSucceed, OnFailed);
            return false;

            function OnSucceed(mesaj) {
                try {
                    var mesParca = mesaj.split(':');
                    if (mesParca[0] == "1") {
                        //                    window.open(mesParca[1]);
                        $('#mesajmodal').modal('hide');
                        window.location.href = mesParca[1];
                    }
                    else {
                        $('#mesajmodal').find('p').html(mesParca[1]);
                        //                        $('#mesajmodal').modal('show');
                    }
                }
                catch (e) {
                    alert(e.Message);
                }
            }

            function OnFailed(xhr, status) {
                $('#mesajmodal').find('p').html(xhr.responseText + " " + status);
                $('#mesajmodal').modal('show');
            }
        }

        $(function () {

            $(document).on('scroll', function () {

                if ($(window).scrollTop() > 100) {
                    $('.scroll-top-wrapper').addClass('show');
                } else {
                    $('.scroll-top-wrapper').removeClass('show');
                }
            });

            $('.scroll-top-wrapper').on('click', scrollToTop);
        });

        function scrollToTop() {
            verticalOffset = typeof (verticalOffset) != 'undefined' ? verticalOffset : 0;
            element = $('body');
            offset = element.offset();
            offsetTop = offset.top;
            $('html, body').animate({ scrollTop: offsetTop }, 500, 'linear');
        }   
    </script>
</head>
<body style="background-color: #b8e2ff; height: 100%;">
    <form id="form1" runat="server" class="form-inline">
    <asp:ScriptManager ID="ScriptManager1" runat="server" EnablePageMethods="true">
    </asp:ScriptManager>
    <asp:HiddenField ID="hdnSatir" runat="server" Value="0" />
    <asp:HiddenField ID="hdnKodlar" runat="server" />
    <asp:HiddenField ID="hdnSorgu" runat="server" />
    <asp:HiddenField ID="hdnRapor" runat="server" />
    <asp:HiddenField ID="hdnAktiflik" runat="server" />
    <asp:HiddenField ID="hdnPTipler" runat="server" />
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <nav id="spy">
                <ul class="nav nav-tabs" role="tablist" style="margin-top: 60px;">
                    <li class="active"><a href="#filtre" role="tab" data-toggle="tab">Filtreler</a></li>
                    <li><a href="#rapor" role="tab" data-toggle="tab">Raporlar</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="filtre">
                        <div class="row">
                            <h4 class="text-center">
                                Aktiflik</h4>
                            <ul id="cAktiflik" class="list-group checked-list-box" runat="server">
                                <li class="list-group-item" data-style="button" data-color="info" data-checked="true"
                                    value="1">Aktif</li>
                                <li class="list-group-item" data-style="button" data-color="info" value="0">Pasif</li>
                            </ul>
                        </div>
                        <div class="row">
                            <h4 class="text-center">
                                Personel Türleri</h4>
                            <asp:Literal ID="pTurler" runat="server"></asp:Literal>
                        </div>
                        <div class="row">
                            <label class="renk">
                                <input type="radio" name="optradio" id="resimli" runat="server" checked="true" value="1">Resimli
                            </label>
                            <label class="renk">
                                <input type="radio" name="optradio" id="resimsiz" runat="server" value="2">Resimsiz
                            </label>
                        </div>
                        <div class="row">
                            <button class="btn btn-primary btn-md" type="submit" id="btnBas" runat="server" style="width: 220px;">
                                <i class="glyphicon glyphicon-search">Ara</i>
                            </button>
                        </div>
                        <%--  <p>
                            <input id="switch-state" type="checkbox" checked>
                        </p>--%>
                    </div>
                    <div class="tab-pane" id="rapor">
                        <div class="row">
                            <label class="renk">
                                <input type="checkbox" id="selectall" name="selectall" runat="server"> Tüm Personeli
                                    Seç </input>
                            </label>
                        </div>
                        <div class="panel-group" id="accordion" style="margin: 10px 5px 5px 5px">
                            <asp:Literal runat="server" ID="ltlRaporlar"></asp:Literal>
                        </div>
                        <%--   <div class="row">
                            <select id="soRaporlar" runat="server">
                            </select>
                            <asp:Button class="btn btn-primary panelsinifi pad" ID="btnRaporListele" OnClientClick="SeciliKodlariGetir();"
                                OnClick="RaporListele" Text="Raporu İndir" runat="server"></asp:Button>
                        </div>
                        <asp:Button ID="btnMailGonder" runat="server" Text="Raporu Mail Gönder" class="row btn btn-primary pad"
                            OnClientClick="SeciliKodlariGetir();" OnClick="MailGonder"></asp:Button>--%>
                    </div>
                </div>
            </nav>
        </div>
        <div id="page-content-wrapper">
            <div id="baslik" class="content-header baslik">
                <div class="col-xs-2 col-sm-1 col-md-1">
                    <h1>
                        <a id="menu-toggle" href="#" style="color: White;" class="glyphicon glyphicon-align-justify btn-menu toggle">
                            <%--style="background-color:White">--%>
                        </a>
                    </h1>
                </div>
                <div class="col-xs-8 col-sm-7 col-md-9">
                    <div class="input-group col-xs-12 col-sm-12 col-md-12 aratext" id="divgrup">
                       <%-- <div class="input-group-btn has-feedback col-md-10">--%>
                            <input id="txtAra2" runat="server" type="text" class="searchinput form-control input-md" />
                            <span class="searchclear glyphicon glyphicon-remove-circle" ></span>
                  <%--      </div>--%>
                        <div class="input-group-btn">
                            <span>
                                <button class="btn btn-primary btn-md" type="button" id="btnAra" style="margin-top: -30px">
                                    <i class="glyphicon glyphicon-search"></i>
                                </button>
                            </span>
                        </div>
                    </div>
                </div>
                <%--      <div class="col-xs-8 col-sm-7 col-md-9">
                    <div class="input-group clearable-input">
                        <input type="text" class="form-control input-md" id="txtAra2" runat="server"/>
                        <span  data-clear-input>&times;</span> 
                        <span class="input-group-btn">
                            <button class="btn btn-primary btn-md" type="button" id="btnAra" style="margin-left: -5px">
                                <i class="glyphicon glyphicon-search"></i>
                            </button>
                        </span>
                    </div>
                </div>--%>
            </div>
            <div class="page-content inset">
                <div class="row" style="padding: 0 5px 0 5px;">
                    <div class="alert alert-danger" id="alert" runat="server" style="display: none;">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> <strong>
                            Hata!</strong>
                        <p>
                        </p>
                    </div>
                    <div class="alert alert-success" id="sayilar" style="display: none;">
                        <%--  <strong>Başarılı!</strong>--%>
                        <p>
                        </p>
                    </div>
                    <div class="row" id="thmListe" runat="server">
                    </div>
                    <div class="yukle">
                    </div>
                    <div class="scroll-top-wrapper ">
                        <%--fa fa-2x fa-arrow-circle-up--%>
                        <span class="scroll-top-inner"><i class="glyphicon glyphicon-arrow-up"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="mesajmodal" runat="server">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        ×</button>
                    <h4 class="modal-title">
                        Bilgi</h4>
                </div>
                <div class="modal-body" id="pmesaj">
                    <p style="font-weight: bold">
                    </p>
                    <input id="txtMailKisi" type="text" runat="server" class="form-control input-md searchinput"
                        placeholder="Mail Gönderilecek Kişiyi Giriniz..." style="width: 300px;" />
                    <span class="searchclear glyphicon glyphicon-remove-circle"></span>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" id="btnRDevam" onclick="RaporaGit(true);">
                        Devam</button>
                    <%--OnClick="RaporaDevam"--%>
                    <button type="button" class="btn btn-default" id="btnMDevam" onclick="RaporaGit(false);">
                        Devam</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="scrollModal" runat="server">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body" id="Div2">
                    <p style="font-weight: bold; text-align: center">
                    </p>
                </div>
            </div>
        </div>
    </div>
    </form>
    <script type="text/javascript">
        $(function () {
            $('.list-group.checked-list-box .list-group-item').each(function () {

                // Settings
                var $widget = $(this),
            $checkbox = $('<input type="checkbox" class="hidden" />'),
            color = ($widget.data('color') ? $widget.data('color') : "primary"),
            style = ($widget.data('style') == "button" ? "btn-" : "list-group-item-"),
            settings = {
                on: {
                    icon: 'glyphicon glyphicon-check'
                },
                off: {
                    icon: 'glyphicon glyphicon-unchecked'
                }
            };

                $widget.css('cursor', 'pointer')
                $widget.append($checkbox);

                // Event Handlers
                $widget.on('click', function () {
                    $checkbox.prop('checked', !$checkbox.is(':checked'));
                    $checkbox.triggerHandler('change');
                    updateDisplay();
                });
                $checkbox.on('change', function () {
                    updateDisplay();
                });

                // Actions
                function updateDisplay() {
                    var isChecked = $checkbox.is(':checked');

                    // Set the button's state
                    $widget.data('state', (isChecked) ? "on" : "off");

                    // Set the button's icon
                    $widget.find('.state-icon')
                .removeClass()
                .addClass('state-icon ' + settings[$widget.data('state')].icon);

                    // Update the button's color
                    if (isChecked) {
                        $widget.addClass(style + color + ' active');
                    } else {
                        $widget.removeClass(style + color + ' active');
                    }
                }

                // Initialization
                function init() {

                    if ($widget.data('checked') == true) {
                        $checkbox.prop('checked', !$checkbox.is(':checked'));
                    }

                    updateDisplay();

                    // Inject the icon if applicable
                    if ($widget.find('.state-icon').length == 0) {
                        $widget.prepend('<span class="state-icon ' + settings[$widget.data('state')].icon + '"></span>');
                    }
                }
                init();
            });
        });
    </script>
</body>
</html>
