﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;
using System.Web.UI.WebControls;
using System.Web.Services;
using TNS.KYM;

namespace InsanKaynaklari
{
    public partial class TabletOzlukBilgileri : System.Web.UI.Page
    {
        TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int pkod = TNS.OrtakFonksiyonlar.ConvertToInt((Request.QueryString["pKod"] + "").Trim(), 0);
                Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
                TNS.ObjectArray dler = new ObjectArray();
                dler = servisIKY.PersonelListele(kul, new TNS.IKY.Personel { kod = pkod }, false, false);

                if (!dler.sonuc.islemSonuc)
                {
                    GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
                    return;
                }

                if (dler.objeler.Count > 0)
                {
                    TNS.IKY.Personel d = (TNS.IKY.Personel)dler.objeler[0];
                    lblOzluk.Text = "Adı: " + d.adSoyad + "<br> TC Kimlik No: " + d.tcKimlikNo + "<br> Sicil Numarası: " + d.sicilNo;
                    lblNufus.Text = "Anne Adı: " + d.nufus.anaAd + "<br> Baba Adı: " + d.nufus.babaAd + "<br> Doğum Yeri: " + d.nufus.dogumYeri + "<br> Doğum Tarihi: " + d.nufus.dogumTarihi + "<br> Nüfus İli: " + d.nufus.ilAd + "<br> Nüfus İlçesi: " + d.nufus.ilceAd;
                }
            }
        }
    }
}