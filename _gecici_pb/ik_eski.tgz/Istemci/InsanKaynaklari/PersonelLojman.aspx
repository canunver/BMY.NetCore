﻿<%@ Page Language="C#" CodeBehind="PersonelLojman.aspx.cs" Inherits="InsanKaynaklari.PersonelLojman" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        function ZorunluAlanKontrol() {
            if (!FPanel1.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return FPanel1.isValid();
        }
        //        daireStore.each(function (r) {
        //            if (r.data.doluMu == 1)
        //                r.selectable = false;
        //                });
        //        daireStore.on('load', function () {
        //            daireStore.data.each(function (item, index, totalItems) {            
        //                if (item.data['doluMu'] == 1)
        //                    item.disabled = true;
        //            });
        //        });     
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden runat="server" ID="hdnPKod" />
    <ext:Hidden runat="server" ID="hdnKod" />
    <ext:Hidden runat="server" ID="hdnTahsisTipi" />
    <ext:Store ID="tahsisTipStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="ad" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="lojmanTipiStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="etiket" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="siteStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="siteAdi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="blokStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="blokNoBosDaireli" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="daireStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="daireGenel" />
                    <ext:RecordField Name="doluMu" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="personelKod" />
                    <ext:RecordField Name="daireKod" />
                    <ext:RecordField Name="lojmanTipi" />
                    <ext:RecordField Name="basTarihiDT" Type="Date" />
                    <ext:RecordField Name="bitTarihiDT" Type="Date" />
                    <ext:RecordField Name="adres" />
                    <ext:RecordField Name="lojmanTipiEtiketi" />
                    <ext:RecordField Name="blokNo" />
                    <ext:RecordField Name="siteAdi" />
                    <ext:RecordField Name="daireNo" />
                    <ext:RecordField Name="blokKod" />
                    <ext:RecordField Name="siteKod" />
                    <ext:RecordField Name="tahsisTipAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click" ViewStateMode="Enabled" Before="return ZorunluAlanKontrol();">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="<%$Resources:InsanKaynaklari,FRMPKS075 %>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                Icon="Delete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnTemizle_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:DateField ID="txtTahsisTarihi" Hidden="true" Width="80" runat="server" Format="dd.MM.yyyy" />
                            <ext:Button ID="btnTahsisEt" Hidden="true" runat="server" Text="Tahsis Et" Icon="Accept">
                                <DirectEvents>
                                    <Click OnEvent="btnTahsisEt_Click">
                                        <EventMask ShowMask="true" Msg="Tahsis Ediliyor." />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="Button1" Icon="Lightbulb" runat="server">
                                <Listeners>
                                    <MouseOver Handler="wndYardim.show();" />
                                    <MouseOut Handler="wndYardim.hide();" />
                                </Listeners>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="FPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        Region="Center">
                        <Items>
                            <ext:TextArea runat="server" ID="txtAdres" FieldLabel="Kurum Dışı Lojman Adres" NoteAlign="Top"
                                AnchorHorizontal="60%">
                            </ext:TextArea>
                            <ext:ComboBox runat="server" ID="ddlTahsisTip" FieldLabel="Tahsis Tipi" AnchorHorizontal="60%"
                                DisplayField="ad" ValueField="kod" StoreID="tahsisTipStore">
                                <DirectEvents>
                                    <Change OnEvent="TahsisTipiChange" />
                                </DirectEvents>
                            </ext:ComboBox>
                            <ext:ComboBox runat="server" ID="ddlSite" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite007%>"
                                DisplayField="siteAdi" ValueField="kod" StoreID="siteStore" AnchorHorizontal="60%">
                                <DirectEvents>
                                    <Change OnEvent="SiteDegisti">
                                    </Change>
                                </DirectEvents>
                            </ext:ComboBox>
                            <ext:ComboBox runat="server" ID="ddlBlok" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite044%>"
                                DisplayField="blokNoBosDaireli" ValueField="kod" StoreID="blokStore" AnchorHorizontal="60%">
                                <DirectEvents>
                                    <Change OnEvent="BlokDegisti">
                                    </Change>
                                </DirectEvents>
                            </ext:ComboBox>
                            <ext:ComboBox runat="server" ID="ddlDaire" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite049%>"
                                DisplayField="daireGenel" ValueField="kod" StoreID="daireStore" AnchorHorizontal="60%">
                            </ext:ComboBox>
                            <ext:CompositeField runat="server" ID="cmpTahTarih" Hidden="true" FieldLabel="Tahsis Tarihleri">
                                <Items>
                                    <ext:DateField ID="txtBaslamaTarihi" runat="server" NoteAlign="Top" Note="<%$Resources:InsanKaynaklari,LojmanSite056%>"
                                        Format="dd.MM.yyyy" AnchorHorizontal="60%" />
                                    <ext:DateField ID="txtBitisTarihi" runat="server" NoteAlign="Top" Note="<%$Resources:InsanKaynaklari,LojmanSite057%>"
                                        Format="dd.MM.yyyy" AnchorHorizontal="60%" />
                                </Items>
                            </ext:CompositeField>
                            <ext:DateField ID="txtRezervTarihi" runat="server" FieldLabel="Rezervasyon Tarihi"
                                Format="dd.MM.yyyy" AnchorHorizontal="60%" Hidden="true" />
                            <ext:TextArea runat="server" ID="txtAciklama" FieldLabel="Açıklama" AnchorHorizontal="60%" Hidden="true">
                            </ext:TextArea>
                            <ext:ComboBox runat="server" ID="ddlDerece" FieldLabel="Öncelik Derecesi" Hidden="true" AnchorHorizontal="60%">
                                <Items>
                                    <ext:ListItem Text="" Value="0" />
                                    <ext:ListItem Text="1-Çok Önemli" Value="1" />
                                    <ext:ListItem Text="2-Önemli" Value="2" />
                                    <ext:ListItem Text="3-Normal" Value="3" />
                                </Items>
                            </ext:ComboBox>
                            <ext:ComboBox runat="server" ID="ddlLojmanTipi" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite058%>"
                                DisplayField="etiket" ValueField="kod" StoreID="lojmanTipiStore" AnchorHorizontal="60%"
                                Hidden="true">
                            </ext:ComboBox>
                        </Items>
                    </ext:FormPanel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" Width="700" AutoExpandColumn="siteAdi"
                        Border="true" Region="East">
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column DataIndex="tahsisTipAd" Header="Tahsis Tipi" />
                                <ext:Column DataIndex="siteAdi" Header="<%$Resources:InsanKaynaklari,LojmanSite007%>" />
                                <ext:Column DataIndex="blokNo" Header="<%$Resources:InsanKaynaklari,LojmanSite044%>" />
                                <ext:Column DataIndex="daireNo" Header="<%$Resources:InsanKaynaklari,LojmanSite049%>" />
                                <ext:DateColumn DataIndex="basTarihiDT" Header="<%$Resources:InsanKaynaklari,LojmanSite056%>"
                                    Format="dd/m/Y" />
                                <ext:DateColumn DataIndex="bitTarihiDT" Header="<%$Resources:InsanKaynaklari,LojmanSite057%>"
                                    Format="dd/m/Y" />
                                <ext:Column DataIndex="lojmanTipiEtiketi" Header="<%$Resources:InsanKaynaklari,LojmanSite058%>" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                <DirectEvents>
                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                        <ExtraParams>
                                            <%--   <ext:Parameter Name="RowValue" Value="Ext1.encode(#{grdListe}.getRowsValues({selectedOnly:true}))"
                                                Mode="Raw" />--%>
                                            <ext:Parameter Name="kod" Value="this.getSelected().data.kod" Mode="Raw" />
                                        </ExtraParams>
                                    </RowSelect>
                                </DirectEvents>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <ext:Window ID="wndYardim" runat="server" Hidden="true" Closable="false" Frame="true"
        Width="380" Height="140" X="220" Y="10">
        <Items>
            <ext:Label ID="Label1" runat="server" Icon="Lightbulb" Text="Oturduğunuz lojman bilgilerinin kaydını giriniz." />
        </Items>
    </ext:Window>
    </form>
</body>
</html>
