﻿using System;
using System.Collections;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.IO;
using System.Collections.Generic;
using TNS.KYM;
using System.Xml;

namespace InsanKaynaklari
{
    public partial class PersonelIzinDevirTab : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                hdnPersonelKod.Value = (Request.QueryString["personelKod"] + "").Trim();
                Listele();
            }
        }

        protected void Listele()
        {
            TNS.IKY.PersonelIzinDevir pid = new TNS.IKY.PersonelIzinDevir();
            pid.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            ObjectArray pler = servisIKY.PersonelIzinDevirListele(kullanan, pid, 0);
            if (pler.sonuc.islemSonuc)
            {
                ListeStore.DataSource = pler.objeler;
                ListeStore.DataBind();
            }
            else
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
        }

        [DirectMethod]
        public void DevirSil(int kod, int yil)
        {
            string hata = "";
            if (kod == 0)
                hata = "Devir seçiniz.<br>";
            //if (yil != System.DateTime.Now.Year)
            //    hata += "Sadece bulunduğunuz yılın devrini silebilirsiniz.";

            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }
            Sonuc sonuc = servisIKY.PersonelIzinDevirSil(kullanan, new TNS.IKY.PersonelIzinDevir { kod = kod, personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) });
            if (sonuc.islemSonuc)
            {
                Listele();
                GenelIslemler.MesajKutusu(this, "Silme işlemi başarılı.");
            }
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            if (OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) == 0)
                hata += "Personel bilgisi olmadığından kayıt yapamazsınız.";

            //if (yil == 0)
            //    hata += Resources.InsanKaynaklari.FRMIZD010;
            //if (yil != System.DateTime.Now.Year)
            //    hata += "Sadece bulunduğunuz yılın kayıt işlemini yapabilirsiniz.";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.PersonelIzinDevir[] listeBilgileri = (TNS.IKY.PersonelIzinDevir[])Ext.Net.JSON.Deserialize(e.ExtraParams["ListeBilgileri"], typeof(TNS.IKY.PersonelIzinDevir[]));

            Sonuc sonuc = null;
            if (listeBilgileri.Length > 0)
                sonuc = servisIKY.PersonelIzinDevirKaydet(kullanan, listeBilgileri);
            else
                sonuc = new Sonuc(false, "Kayıt edilecek veri bulunamadı.", "");
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Listele();
                GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarılı");
            }
        }
    }
}