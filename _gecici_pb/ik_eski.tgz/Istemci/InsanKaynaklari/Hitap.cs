﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebServisler.SGKHitapWS;
using TNS;
using TNS.KYM;
using System.Text;
using System.Collections;


namespace InsanKaynaklari
{
    public class Hitap
    {
        public static string kullaniciAdi = "";
        public static string parola = "";
        void Hitaplar()
        {
            //HizmetAcikSureServisBean has = new HizmetAcikSureServisBean();
            //HizmetBirlestirmeServisBean hb = new HizmetBirlestirmeServisBean();
            //HizmetBorclanmaServisBean hborc = new HizmetBorclanmaServisBean();
            //HizmetCetveliServisBean hc = new HizmetCetveliServisBean();
            //HizmetIHSServisBean hIHS = new HizmetIHSServisBean();
            //HizmetMahkemeServisBean hm = new HizmetMahkemeServisBean();
            //HizmetTazminatServisBean ht = new HizmetTazminatServisBean();
            //HizmetUnvanServisBean hu = new HizmetUnvanServisBean();            
        }

        void HizmetNufusYaz(long tckn, TNS.IKY.Personel nufus, long kayitNo)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetNufusServisBean hnufus = new HizmetNufusServisBean();
            hnufus.tckn = tckn;//nufus.tcKimlikNo.;
            hnufus.ad = nufus.ad;
            hnufus.soyad = nufus.soyad;
            hnufus.ilkSoyad = nufus.ilkSoyad;
            hnufus.dogumTarihi = nufus.dogumTarihi.Oku().ToString("yyyy-aa-gg");
            hnufus.cinsiyet = nufus.cinsiyetHitapID;
            hnufus.emekliSicilNo = OrtakFonksiyonlar.ConvertToInt(nufus.emekliSicilNo, 0);
            hnufus.memuriyetBaslamaTarihi = nufus.ilkIseBaslamaTarihi.Oku().ToString("yyyy-aa-gg");
            hnufus.kurumSicili = nufus.sicilNo;
            hnufus.maluliyetKod = nufus.sakatlikDurumu.ToString();
            hnufus.sebep = 0;
            hnufus.yetkiSeviyesi = "";
            hnufus.aciklama = "";
            hnufus.kurumaBaslamaTarihi = nufus.kurumaBaslamaTarihi.Oku().ToString("yyyy-aa-gg");

            ServisSonuc sonuc = new ServisSonuc();
            if (kayitNo == 0)
                sonuc = sc.HizmetNufusInsert(hnufus, kullaniciAdi, parola);
            else
                sonuc = sc.HizmetNufusUpdate(hnufus, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,sonuc.kayitNo);
        }

        void HizmetNufusOku(long tckn)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetNufusServisBean hnufus = sc.HizmetNufusSorgula(kullaniciAdi, parola, tckn);
        }

        void HizmetEgitimKursYaz(long tckn, TNS.IKY.PersonelKurs kurs, long kayitNo)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetEgitimKursServisBean hek = new HizmetEgitimKursServisBean();
            hek.tckn = tckn;
            hek.kayitNo = kayitNo; //ogrenim.hitapKayitNo;
            hek.kursOgrenimSuresi = 0;
            hek.mezuniyetTarihi = kurs.bitirmeTarihi.Oku().ToString("yyyy-aa-gg");
            hek.kursNevi = OrtakFonksiyonlar.ConvertToInt(kurs.kursKodHitapID, 0);
            hek.okulAd = kurs.kursAdi + " " + kurs.egitimYeri;
            hek.bolumAd = "";
            hek.ogrenimYeri = kurs.ogrenimYeriHitapID;
            hek.denklikTarihi = "";
            hek.denklikOkul = "";
            hek.denklikBolum = "";
            hek.kurumOnayTarihi = kurs.kurumaIbrazTarihi.Oku().ToString("yyyy-aa-gg");

            ServisSonuc sonuc = new ServisSonuc();
            if (kayitNo == 0)
                sonuc = sc.HizmetKursInsert(hek, kullaniciAdi, parola);
            else
                sonuc = sc.HizmetKursUpdate(hek, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,sonuc.kayitNo);

        }

        void HizmetEgitimKursOku(long tckn)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetEgitimKursServisBean[] hekler = sc.HizmetKursSorgula(kullaniciAdi, parola, tckn);
        }

        void HizmetEgitimKursSil(long tckn, long kayitNo, bool butunBilgiler)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();
            ServisSonuc sonuc = new ServisSonuc();

            if (butunBilgiler && kayitNo == 0)
                sonuc = sc.HizmetKursDeleteTCAll(tckn, kullaniciAdi, parola);
            else if (!butunBilgiler && kayitNo > 0)
                sonuc = sc.HizmetKursDelete(kayitNo, tckn, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,0);
        }

        void HizmetEgitimKursOkulYaz(long tckn, TNS.IKY.PersonelOgrenim ogrenim, long kayitNo)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetEgitimKursServisBean hek = new HizmetEgitimKursServisBean();
            hek.tckn = tckn;
            hek.kayitNo = kayitNo; //ogrenim.hitapKayitNo;
            hek.kursOgrenimSuresi = 0;
            hek.mezuniyetTarihi = ogrenim.belgeTarihi.Oku().ToString("yyyy-aa-gg");
            hek.kursNevi = OrtakFonksiyonlar.ConvertToInt(ogrenim.ogrenimKodHitapID, 0);
            hek.okulAd = ogrenim.okulAdi;
            hek.bolumAd = ogrenim.bolumAdi;
            hek.ogrenimYeri = ogrenim.ogrenimYeri.ToString();
            hek.denklikTarihi = ogrenim.denklikTarihi.Oku().ToString("yyyy-aa-gg");
            hek.denklikOkul = ogrenim.denkOkul;
            hek.denklikBolum = ogrenim.denkBolum;
            hek.kurumOnayTarihi = ogrenim.kurumaIbrazTarihi.Oku().ToString("yyyy-aa-gg");

            ServisSonuc sonuc = new ServisSonuc();
            if (kayitNo == 0)
                sonuc = sc.HizmetKursInsert(hek, kullaniciAdi, parola);
            else
                sonuc = sc.HizmetKursUpdate(hek, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,sonuc.kayitNo);

        }

        void HizmetEgitimKursOkulOku(long tckn)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetEgitimKursServisBean[] hekler = sc.HizmetKursSorgula(kullaniciAdi, parola, tckn);
        }

        void HizmetEgitimKursOkulSil(long tckn, long kayitNo, bool butunBilgiler)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();
            ServisSonuc sonuc = new ServisSonuc();

            if (butunBilgiler && kayitNo == 0)
                sonuc = sc.HizmetKursDeleteTCAll(tckn, kullaniciAdi, parola);
            else if (!butunBilgiler && kayitNo > 0)
                sonuc = sc.HizmetKursDelete(kayitNo, tckn, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,0);
        }

        void HizmetEgitimOkulYaz(long tckn, TNS.IKY.PersonelOgrenim ogrenim, long kayitNo)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetEgitimOkulServisBean heo = new HizmetEgitimOkulServisBean();
            heo.kayitNo = kayitNo; //ogrenim.hitapKayitNo;
            heo.tckn = tckn;
            heo.ogrenimDurumu = OrtakFonksiyonlar.ConvertToInt(ogrenim.ogrenimKodHitapID, 0); //ogrenimHitapID
            heo.mezuniyetTarihi = ogrenim.belgeTarihi.Oku().ToString("yyyy-aa-gg");
            heo.okulAd = ogrenim.okulAdi;
            heo.bolum = ogrenim.bolumAdi;
            heo.ogrenimYer = ogrenim.ogrenimYeriHitapID;//ogrenimYeriHitapID

            heo.denklikTarihi = ogrenim.denklikTarihi.Oku().ToString("yyyy-aa-gg");
            heo.denklikOkul = ogrenim.denkOkul;
            heo.denklikBolum = ogrenim.denkBolum;

            heo.ogrenimSuresi = 0; //ogrenim.belgeTarihi - ogrenim.baslangicTarihi;
            heo.hazirlik = ogrenim.hazirlikVarMi;
            heo.kurumOnayTarihi = ogrenim.kurumaIbrazTarihi.Oku().ToString("yyyy-aa-gg");


            ServisSonuc sonuc = new ServisSonuc();
            if (kayitNo == 0)
                sonuc = sc.HizmetOkulInsert(heo, kullaniciAdi, parola);
            else
                sonuc = sc.HizmetOkulUpdate(heo, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,sonuc.kayitNo);

        }

        void HizmetEgitimOkulOku(long tckn)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetEgitimOkulServisBean[] heoler = sc.HizmetOkulSorgula(kullaniciAdi, parola, tckn);
        }

        void HizmetEgitimOkulSil(long tckn, long kayitNo, bool butunBilgiler)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();
            ServisSonuc sonuc = new ServisSonuc();

            if (butunBilgiler && kayitNo == 0)
                sonuc = sc.HizmetOkulDeleteTCAll(tckn, kullaniciAdi, parola);
            else if (!butunBilgiler && kayitNo > 0)
                sonuc = sc.HizmetOkulDelete(kayitNo, tckn, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,0);
        }

        void HizmetAskerlikYaz(long tckn, TNS.IKY.PAskerlik askerlik, long kayitNo)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetAskerlikServisBean ha = new HizmetAskerlikServisBean();
            ha.kayitNo = kayitNo;
            ha.tckn = tckn;
            ha.askerlikNevi = OrtakFonksiyonlar.ConvertToInt(askerlik.askerlikDurumHitapID, 0); //askerlikHitapID
            ha.baslamaTarihi = askerlik.askerlikBaslamaTarihi.Oku().ToString("yyyy-aa-gg");
            ha.bitisTarihi = askerlik.terhisTarihi.Oku().ToString("yyyy-aa-gg");
            ha.sayilmayanGunSayisi = askerlik.sayilmayanGunSayisi;
            ha.subayOkuluGirisTarihi = askerlik.yedekSubayOkuluGirisTarihi.Oku().ToString("yyyy-aa-gg");
            ha.astegmenNaspTarihi = askerlik.astegmenNaspTarihi.Oku().ToString("yyyy-aa-gg");
            ha.tegmenNaspTarihi = askerlik.tegmenNaspTarihi.Oku().ToString("yyyy-aa-gg");
            ha.sinifOkuluSicil = askerlik.sinifDonemSicilNo;
            ha.muafiyetNeden = askerlik.askerlikMuafNeden;
            ha.gorevYeri = askerlik.erYedekSubayGorevYeri;
            ha.subayliktanErligeGecisTarihi = askerlik.erYedekSubayGecisTarihi.Oku().ToString("yyyy-aa-gg");
            ha.kitaBaslamaTarihi = askerlik.erYedekSubayKitaHizmetiBaslamaTarihi.Oku().ToString("yyyy-aa-gg");
            ha.kitaBitisTarihi = askerlik.erYedekSubayKitaHizmetiBitisTarihi.Oku().ToString("yyyy-aa-gg");
            ha.kurumOnayTarihi = askerlik.ibrazIntikalTarihi.Oku().ToString("yyyy-aa-gg");

            ServisSonuc sonuc = new ServisSonuc();
            if (kayitNo == 0)
                sonuc = sc.HizmetAskerlikInsert(ha, kullaniciAdi, parola);
            else
                sonuc = sc.HizmetAskerlikUpdate(ha, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,sonuc.kayitNo);

        }

        void HizmetAskerlikOku(long tckn)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            HizmetAskerlikServisBean[] haler = sc.HizmetAskerlikSorgula(kullaniciAdi, parola, tckn);
        }

        void HizmetAskerlikSil(long tckn, long kayitNo, bool butunBilgiler)
        {
            Hitap4cWEBBeanService sc = HitapServisiOlustur();
            ServisSonuc sonuc = new ServisSonuc();

            if (butunBilgiler && kayitNo == 0)
                sonuc = sc.HizmetAskerlikDeleteTCAll(tckn, kullaniciAdi, parola);
            else if (!butunBilgiler && kayitNo > 0)
                sonuc = sc.HizmetAskerlikDelete(kayitNo, tckn, kullaniciAdi, parola);

            //if (sonuc.hataKod>0) Loga yaz sonuc.hataMesaj

            //sonuc.kayitNo bilgisini satira kaydet servis.OgrenimHitapNoGuncelle(ogrenim.personelKod,ogrenim.kod,0);
        }

        private static Hitap4cWEBBeanService HitapServisiOlustur()
        {
            Hitap4cWEBBeanService sc = new Hitap4cWEBBeanService();
            //string certPath = @"C:\Users\Can\Downloads\Sertifika\Sertifika\sgk.gov.tr.v2";
            //System.Security.Cryptography.X509Certificates.X509Certificate cert = System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromCertFile(certPath);
            //sc.ClientCertificates.Add(cert);
            sc.Proxy = OrtakFonksiyonlar.ProxyAyarla();
            sc.Timeout = 20 * 60 * 1000;

            //HitapKullaniciBilgileriAl(ref kullaniciAdi, ref parola);

            return sc;
        }

        private static void HitapKullaniciBilgileriAl(ref string kullaniciAdi, ref string parola)
        {
            kullaniciAdi = "";
            parola = "";
        }

        public class HizmetCetveliSirala : IComparer
        {
            public int Compare(object x, object y)
            {
                if (x is TNS.IKY.PersonelKadro && y is TNS.IKY.PersonelKadro)
                {
                    return Kiyasla((TNS.IKY.PersonelKadro)x, (TNS.IKY.PersonelKadro)y);
                }
                return 0;
            }

            private int Kiyasla(TNS.IKY.PersonelKadro pk1, TNS.IKY.PersonelKadro pk2)
            {
                DateTime dt1;
                if (!pk1.atamaTarihi.isNull)
                    dt1 = pk1.atamaTarihiDT;
                else if (!pk1.ayrilmaTarihi.isNull)
                    dt1 = pk1.ayrilmaTarihiDT;
                else
                    return -1;

                DateTime dt2;
                if (!pk2.atamaTarihi.isNull)
                    dt2 = pk2.atamaTarihiDT;
                else if (!pk2.ayrilmaTarihi.isNull)
                    dt2 = pk2.ayrilmaTarihiDT;
                else
                    return 1;
                int sonuc = dt1.CompareTo(dt2);

                if (sonuc != 0) return sonuc;
                if (pk1.atamaTarihi.isNull) return -1;
                return 1;
            }
        }

        public static void HitapHizmetleriAl(Kullanici kullanan, TNS.IKY.IIKYServis ikyServis, int personelKod, int organizasyonKodu, int personelTip, string kullaniciAdi, string parola)
        {
            TNS.ORG.IORGServis orgServis = TNS.ORG.Arac.Tanimla();
            if (personelKod <= 0) throw new Exception("Lütfen personel seçiniz!");
            TNS.IKY.Personel p = new TNS.IKY.Personel { kod = personelKod };
            ObjectArray oa = ikyServis.PersonelListele(kullanan, p, false, true);

            if (!oa.sonuc.islemSonuc)
                throw new Exception(oa.sonuc.hataStr);
            if (oa.ObjeSayisi != 1)
                throw new Exception("Beklenmeyen sayıda personel kaydı bulundu: " + oa.ObjeSayisi.ToString());
            p = (TNS.IKY.Personel)oa.objeler[0];

            Hitap4cWEBBeanService sc = HitapServisiOlustur();

            //HizmetCetveliServisBean[] hCetveli = {
            //    HizmetCetveliServisBeanOl(OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo), 1, "01.01.2002", "01.01.2003", "görev", 1, 1, 1,1,1000, 1,1,1000, 1,1,1000, 1),
            //    HizmetCetveliServisBeanOl(OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo), 1, "01.01.2003", "01.01.2004", "xörev", 1, 1, 1,1,1000, 1,1,1000, 1,1,1000, 1),
            //    HizmetCetveliServisBeanOl(OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo), 1, "01.01.2004", "01.01.2005", "zörev", 1, 1, 1,1,1000, 1,1,1000, 1,1,1000, 1),
            //    HizmetCetveliServisBeanOl(OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo), 1, "01.01.2005", "01.01.2006", "nörev", 1, 1, 1,1,1000, 1,1,1000, 1,1,1000, 1),
            //    HizmetCetveliServisBeanOl(OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo), 1, "01.01.2006", "01.01.2007", "nörev", 1, 1, 1,1,1000, 1,1,1000, 1,1,1000, 1),
            //    HizmetCetveliServisBeanOl(OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo), 1, "01.01.2006", "01.01.0001", "aörev", 1, 1, 1,1,1000, 1,1,1000, 1,1,1000, 1),
            //                                     };
            ArrayList al = new ArrayList();
            HizmetCetveliServisBean[] hCetveli = sc.HizmetCetvelSorgula(kullaniciAdi, parola, OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo));
            if (hCetveli != null)
            {
                string oncekiBirim = "";
                int oncekiBirimKod = 0;
                int eskiHitapUnvan = -1;
                int eskiSGBUnvan = -1;
                foreach (HizmetCetveliServisBean item in hCetveli)
                {
                    if (item != null)
                        al.Add(PersonelKadroOl(p.kod, item, ikyServis, ref eskiHitapUnvan, ref eskiSGBUnvan));
                }
                al.Sort(new HizmetCetveliSirala());
                for (int i = 0; i < al.Count - 1; i++)
                {
                    TNS.IKY.PersonelKadro pk = (TNS.IKY.PersonelKadro)al[i];
                    TNS.IKY.PersonelKadro pkSonraki = (TNS.IKY.PersonelKadro)al[i + 1];
                    if (!string.IsNullOrWhiteSpace(pk.gorevYeri))
                    {
                        if (pk.gorevYeri != oncekiBirim)
                        {
                            oncekiBirim = pk.gorevYeri;
                            ObjectArray oaBirimler = orgServis.OrganizasyonBirimListele(new TNS.ORG.OrganizasyonBirim { adi = pk.gorevYeri }, false, false);
                            if (oaBirimler.sonuc.islemSonuc && oaBirimler.ObjeSayisi > 0)
                            {
                                oncekiBirimKod = ((TNS.ORG.OrganizasyonBirim)oaBirimler[0]).kod;
                            }
                            else
                                oncekiBirimKod = 0;
                        }
                    }
                    pk.gorevOrganizasyonKodu = oncekiBirimKod;
                    pk.organizasyonKodu = oncekiBirimKod;
                    pk.ayrilmaGerekcesi = pkSonraki.hizmetSebebiKod;
                    if (!pkSonraki.ayrilmaTarihi.isNull)
                    {
                        pk.ayrilmaTarihi = new TNSDateTime(pkSonraki.ayrilmaTarihiDT);
                        al.RemoveAt(i + 1);
                    }
                    else
                        pk.ayrilmaTarihi = new TNSDateTime(pkSonraki.atamaTarihiDT);
                    pk.hizmetGunSayisi = TNS.IKY.Arac.GunHesapla360(pk.atamaTarihiDT, pk.ayrilmaTarihiDT);
                    if (pk.organizasyonKodu > 0)
                        if (personelTip > 0)
                            pk.personelTip = personelTip;
                        else
                            pk.personelTip = KurumdaEmekliSandigi;
                    else
                        pk.personelTip = KurumdisiEmekliSandigi;
                }
                if (al.Count > 0)
                {
                    TNS.IKY.PersonelKadro pkSon = (TNS.IKY.PersonelKadro)al[al.Count - 1];
                    if (organizasyonKodu > 0)
                        pkSon.organizasyonKodu = organizasyonKodu;
                    else
                        pkSon.organizasyonKodu = oncekiBirimKod;

                    pkSon.gorevOrganizasyonKodu = pkSon.organizasyonKodu;

                    if (pkSon.organizasyonKodu > 0)
                    {
                        if (personelTip > 0)
                            pkSon.personelTip = personelTip;
                        else
                            pkSon.personelTip = KurumdaEmekliSandigi;
                    }
                    else
                        pkSon.personelTip = KurumdisiEmekliSandigi;
                }

                //Eğer okunan personelin birimi ve personel tipi varsa, kullan....
            }
            else
                throw new Exception("HİTAPdan veri dönmedi");

            HizmetBirlestirmeServisBean[] hBirlestirme = sc.HizmetBirlestirmeSorgula(kullaniciAdi, parola, OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo));
            if (hBirlestirme != null)
            {
                foreach (HizmetBirlestirmeServisBean item in hBirlestirme)
                {
                    if (item != null)
                        al.Add(PersonelKadroOl(p.kod, item));
                }
            }
            else
                throw new Exception("HİTAPdan veri dönmedi");

            HizmetBorclanmaServisBean[] hBorclanma = sc.HizmetBorclanmaSorgula(kullaniciAdi, parola, OrtakFonksiyonlar.ConvertToLong(p.tcKimlikNo));
            if (hBorclanma != null)
            {
                foreach (HizmetBorclanmaServisBean item in hBorclanma)
                {
                    if (item != null)
                        al.Add(PersonelKadroOl(p.kod, item));
                }
            }
            else
                throw new Exception("HİTAPdan veri dönmedi");
            //throw new Exception("Hazır değil!");
            TNS.IKY.PersonelKadro pkOnceki = null;
            for (int i = 0; i < al.Count; i++)
            {
                TNS.IKY.PersonelKadro pk = (TNS.IKY.PersonelKadro)al[i];
                if (pkOnceki != null)
                {
                    if (pkOnceki.ayrilmaTarihiDT == pk.atamaTarihiDT && pk.personelTip <= KurumdisiEmekliSandigi)
                        pk.eskiKod = pkOnceki.kod;
                }
                Sonuc s = ikyServis.PersonelKadroKaydet(kullanan, pk);
                if (!s.islemSonuc)
                    throw new Exception(s.hataStr);
                pk.kod = OrtakFonksiyonlar.ConvertToInt(s.anahtar, 0);
                s = ikyServis.AtamaOnayBilgileriniGuncelle(kullanan, new TNSCollection(pk), 5);
                if (!s.islemSonuc)
                    throw new Exception(s.hataStr);
                pkOnceki = pk;
            }
        }

        private static string StringYap(HizmetBorclanmaServisBean item)
        {
            return String.Format("baslamaTarihi:{0} bitisTarihi:{1} emekliSicil:{2} derece:{3} kademe:{4} ekgosterge:{5} gunSayisi:{6} kanunKod:{7} borcNevi:{8} toplamTutar:{9} odenenMiktar:{10} calistigiKurum:{11} isyeriIl:{12} isyeriIlce:{13} borclanmaTarihi:{14} odemeTarihi:{15} ",
                item.baslamaTarihi, item.bitisTarihi, item.emekliSicil, item.derece, item.kademe, item.ekgosterge, item.gunSayisi, item.kanunKod, item.borcNevi, item.toplamTutar, item.odenenMiktar, item.calistigiKurum, item.isyeriIl, item.isyeriIlce, item.borclanmaTarihi, item.odemeTarihi);

            /*
             * kanunKod (bkz:Açıklamalar-28.madde)
             * 
             *      5434: 5434 S.K. tabi borçlanma 
             *      5510: 5510 S.K. tabi borçlanma
             * 
             * 
             * borcNevi (bkz:Açıklamalar-29.madde)
             *      22:Personel Mevzuatına Göre Aylıksız İzin Süreleri(4c)
             *      28:5434 SK geçici 209 borçlanması
             *      30:5510 S.K. Geç. 4. MD. 17. Fıkra Borç.(5525 S.K.)
             *      31:5510 S.K. Geç. 36. MD. Borç.(1402)
             *      32:5510 S.K. Geç. 43. MD. Borç.(1416)
             *      33:5510 S.K. Geç. 44. MD. Borç.(5525 S.K.)
             *      34:5510 S.K. Geç. 51. MD. Borç.(5525 S.K.)
             *      35:5510 S.K. 41 MD. (4/C STATÜLÜ DOĞUM BORÇLANMASI) (22.04.2015 eklendi)
             *      36:5510 S.K. Geç. 56. MD. Borç.(5525 S.K.) (01.07.2015 tarihinde eklendi)
             * */
        }

        private static string StringYap(HizmetBirlestirmeServisBean item)
        {
            return String.Format("baslamaTarihi:{0} bitisTarihi:{1} sgkNevi:{2} sgkSicilNo:{3} sure:{4} kamuIsyeriAd:{5} ozelIsyeriAd:{6} bagKurMeslek:{7} ulkeKod:{8} bankaSandıkKod:{9} kidemTazminatOdemeDurumu:{10} ayrilmaNedeni:{11} khaDurum:{12}",
                item.baslamaTarihi, item.bitisTarihi, item.sgkNevi, item.sgkSicilNo, item.sure, item.kamuIsyeriAd, item.ozelIsyeriAd, item.bagKurMeslek, item.ulkeKod, item.bankaSandikKod, item.kidemTazminatOdemeDurumu, item.ayrilmaNedeni, item.khaDurum);

            /*
             * 
             * Nevi SGK Nevi Integer (bkz:Açıklamalar-10.madde)
             *      1: SSK Kamu 
             *      2: SSK Özel 
             *      3: Bağ-Kur 
             *      4: Yurt Dışı Hizmetleri 
             *      5: Banka Emekli Sandıkları
             *      6: SSK Askerlik Borçlanması (8 Haziran 2012 tarihinde eklendi) 
             *      7: SSK Diğer Borçlanma (8 Haziran 2012 tarihinde eklendi) 
             *      8: Bağ-Kur Askerlik Borçlanması (8 Haziran 2012 tarihinde eklendi) 
             *      9: Bağ-Kur Diğer Borçlanma (8 Haziran 2012 tarihinde eklendi)
             *      10: Banka Emekli Sandık Askerlik Borçlanması (8 Haziran 2012 tarihinde eklendi) 
             *      11: Banka Emekli Sandık Diğer Borçlanma (8 Haziran 2012 tarihinde eklendi)
             *      12: SSK FHZ (01/10/2008 Sonrası İçin) (22.04.2015 tarihinde eklendi)
             * 
             * 
             * sure Süre Integer Prim Gün Sayısı
             *      0: HAYIR 
             *      1: EVET
             *      “”(BOŞ KARAKTER): BELİRLENEMEDİ
             * 
             * kıdemTazminatOdemeDurumu Kıdem Tazminat Ödeme Durumu String (bkz:Açıklamalar-19.madde)
             * 
             * 
             * khaDurum KHA Durumu String (bkz:Açıklamalar-20.madde)
             *      0: Değerlendirilmedi
             *      1: Prim gün sayısının 2/3 oranında değerlendirildi
             *      2: Prim gün sayısının 3/4 oranında değerlendirildi
             *      3: Prim gün sayısının 4/4 oranında değerlendirildi
             *      4: Belirlenemedi
             *      5: İki tarih arasının tamamı değerlendirildi
             * 
             * */
        }

        private static string StringYap(HizmetCetveliServisBean item)
        {
            return String.Format("baslamaTarihi:{0} bitisTarihi:{1} emekliDerece:{2} emekliEkGosterge:{3} emekliKademe:{4} gorev:{5} hizmetSinifi:{6} kadroDerece:{7} kazanilmisHakAyligiDerece:{8} kazanilmisHakAyligiEkGosterge:{9} kazanilmisHakAyligiKademe:{10} kurumOnayTarihi:{11} odemeDerece:{12} odemeEkGosterge:{13} odemeKademe:{14} sebepKod:{15} ucret:{16} unvanKod:{17} yevmiye:{18}",
                item.baslamaTarihi, item.bitisTarihi, item.emekliDerece, item.emekliEkGosterge, item.emekliKademe, item.gorev, item.hizmetSinifi, item.kadroDerece, item.kazanilmisHakAyligiDerece, item.kazanilmisHakAyligiEkGosterge, item.kazanilmisHakAyligiKademe, item.kurumOnayTarihi, item.odemeDerece, item.odemeEkGosterge, item.odemeKademe, item.sebepKod, item.ucret, item.unvanKod, item.yevmiye);

            /*
             * 
             * 
             * hizmetSinifi Hizmet Sınıfı String (bkz:Açıklamalar-15.madde)
             *      1 veya GİH: GENEL İDARE HİZMETLERİ
             *      2 veya MİAH: MÜLKİ İDARE AMİRLİĞİ HİZMETLERİ
             *      3 veya SH: SAĞLIK HİZMETLERİ
             *      4 veya TH: TEKNİK HİZMETLER
             *      5 veya EÖH: EĞİTİM ÖĞRETİM HİZMETLERİ
             *      6 veya AH: AVUKATLIK HİZMETLERİ
             *      7 veya EH: EMNİYET HİZMETLERİ
             *      8 veya DH: DİN HİZMETLERİ
             *      9 veya YH: YARDIMCI HİZMETLER
             *      10 veya MİT: MİLLİ İSTİHBARAT TEŞKİLATI
             *      11 veya AHS: ASKERİ HAKİM VE SAVCILAR
             *      12 veya BB: BELEDİYE BAŞKANI
             *      13 veya CU: CUMHURBAŞKANI
             *      14 veya CUM: CUMHURBAŞKANLIĞI PERSONELİ
             *      15 veya DE: DENETİM ELEMANLARI
             *      16 veya DVS: DEVLET SANATÇILARI
             *      17 veya HS: HAKİM VE SAVCILAR
             *      18 veya MB: MERKEZ BANKASI
             *      19 veya MV: MİLLETVEKİLİ
             *      20 veya ÖÜ: ÖĞRETİM ÜYELERİ
             *      21 veya SAY: SAYIŞTAY ÜYELERİ VE MESLEK MENSUPLARI
             *      22 veya TBM: TÜRKİYE BÜYÜK MİLLET MECLİSİ PERSONELİ
             *      23 veya TRT: TÜRKİYE RADYO TELEVİZYON KURUMU
             *      24 veya TSK: TÜRK SİLAHLI KUVVETLERİ
             *      25 veya YÖK: ÖĞRETİM ÜYELERİ
             *      26 veya YSH: YARDIMCI SAĞLIK HİZMETLERİ.
             *      27 veya ÖGO: ÖĞRETİM GÖREVLİLERİ VE OKUTMANLAR (8 Haziran 2012 eklendi) 
             *      28 veya ÖY: ÖĞRETİM YARDIMCILARI (8 Haziran 2012 tarihinde eklendi)
             *      29 veya SÖZ: SÖZLEŞMELİ PERSONEL (29 Haziran 2012 tarihinde eklendi)
             * 
             * unvanKod Unvan kodu Integer (bkz: Unvan Kod Listesi)
             * 
             * 
             * sebepKod Sebep Integer (bkz: Hizmet Sebep Kod Listesi)
             * 
             * 
             * 
             * */
        }

        private static object PersonelKadroOl(int personelKod, HizmetBorclanmaServisBean item)
        {
            TNS.IKY.PersonelKadro pk = new TNS.IKY.PersonelKadro();
            pk.personelKod = personelKod;
            pk.eskiKod = 0;
            pk.personelTip = 0;
            pk.hizmetSebebiKod = 0;
            pk.atamaTarihi = TarihOl(item.baslamaTarihi);
            pk.hizmetSebebi = item.borcNevi;
            pk.hitapSicilNo = item.emekliSicil;
            //item.ad;

            pk.organizasyonKodu = 0;
            pk.gorevOrganizasyonKodu = 0;
            pk.gorevYeri = (item.calistigiKurum + "").Trim();
            if (string.IsNullOrWhiteSpace(pk.gorevYeri)) pk.gorevYeri = "Hizmet Borçlanma";

            //Sınıf kaydedilmiyor, unvan kodundan bulunuyor.
            pk.unvan = 0;
            pk.vekilUnvanKod = 0;
            pk.evrakNo = "";
            pk.yasalDayanak = "";
            //pk.onayTarih = pk.atamaTarihi;

            pk.hizmetGunSayisi = item.gunSayisi;
            pk.hitapKod = item.kayitNo;
            pk.hitapBorcNevi = item.borcNevi;
            pk.belgeTarihi = TarihOl(item.borclanmaTarihi);

            //Borçlanma alanları eklenmeli
            pk.hitaptoplamTutar = item.toplamTutar;
            pk.hitapodenenMiktar = item.odenenMiktar;
            pk.hitapodemeTarihi = TarihOl(item.odemeTarihi);
            pk.kadroDerece = 0;
            pk.kadroTarih = new TNSDateTime();
            pk.personelTip = Borclanma;
            //TNS.IKY.ENUMHizmetTablolari.Borclanma;
            pk.kazanilmisHakDerece = 0;
            pk.kazanilmisHakKademe = 0;
            pk.kazanilmisHakTarih = pk.kadroTarih;
            pk.kazanilmisEkGosterge = 0;

            pk.odemeyeEsasDerece = 0;
            pk.odemeyeEsasKademe = 0;
            pk.odemeyeEsasTarih = pk.kadroTarih;
            pk.odemeyeEsasEkGosterge = 0;

            pk.emekliyeEsasDerece = 0;
            pk.emekliyeEsasKademe = 0;
            pk.emekliyeEsasTarih = pk.kadroTarih;
            pk.emekliyeEsasEkGosterge = 0;

            pk.ayrilmaTarihi = TarihOl(item.bitisTarihi);

            pk.iliskiliKadroIslemNo = 0;

            return pk;
        }

        private static object PersonelKadroOl(int personelKod, HizmetBirlestirmeServisBean item)
        {
            TNS.IKY.PersonelKadro pk = new TNS.IKY.PersonelKadro();
            pk.personelKod = personelKod;
            pk.eskiKod = 0;
            pk.personelTip = 0;
            pk.hizmetSebebiKod = 0;
            pk.atamaTarihi = TarihOl(item.baslamaTarihi);
            pk.hizmetSebebi = "";

            pk.organizasyonKodu = 0;
            pk.gorevOrganizasyonKodu = 0;
            pk.gorevYeri = item.ozelIsyeriAd + item.kamuIsyeriAd;
            if (string.IsNullOrWhiteSpace(pk.gorevYeri)) pk.gorevYeri = "Hizmet Birleştirme";
            pk.ayrilmaNedeni = item.ayrilmaNedeni;
            pk.hitapKod = item.kayitNo;
            pk.hitapkhaDurum = item.khaDurum;
            pk.hitapsgkNevi = (TNS.IKY.ENUMSGKNevi)item.sgkNevi;
            pk.hizmetGunSayisi = item.sure;
            pk.hitapSicilNo = item.sgkSicilNo;
            if (string.IsNullOrWhiteSpace(item.bagKurMeslek))
                pk.personelTip = KurumdisiSSK;
            else
                pk.personelTip = KurumdisiBagkur;

            pk.unvan = 0;
            pk.vekilUnvanKod = 0;
            pk.evrakNo = "";
            pk.yasalDayanak = "";
            //pk.onayTarih = pk.atamaTarihi;

            pk.aciklama = "";

            pk.kadroDerece = 0;
            pk.kadroTarih = new TNSDateTime();

            pk.kazanilmisHakDerece = 0;
            pk.kazanilmisHakKademe = 0;
            pk.kazanilmisHakTarih = pk.kadroTarih;
            pk.kazanilmisEkGosterge = 0;

            pk.odemeyeEsasDerece = 0;
            pk.odemeyeEsasKademe = 0;
            pk.odemeyeEsasTarih = pk.kadroTarih;
            pk.odemeyeEsasEkGosterge = 0;

            pk.emekliyeEsasDerece = 0;
            pk.emekliyeEsasKademe = 0;
            pk.emekliyeEsasTarih = pk.kadroTarih;
            pk.emekliyeEsasEkGosterge = 0;

            pk.ayrilmaTarihi = TarihOl(item.bitisTarihi);

            pk.iliskiliKadroIslemNo = 0;

            return pk;
        }

        private static TNS.IKY.PersonelKadro PersonelKadroOl(int personelKod, HizmetCetveliServisBean item, TNS.IKY.IIKYServis ikyServis, ref int eskiHitapUnvan, ref int eskiSGBUnvan)
        {
            TNS.IKY.PersonelKadro pk = new TNS.IKY.PersonelKadro();
            pk.personelKod = personelKod;
            pk.eskiKod = 0;
            pk.personelTip = 0;
            pk.hizmetSebebiKod = item.sebepKod;
            pk.atamaTarihi = TarihOl(item.baslamaTarihi);
            pk.hizmetSebebi = "";

            pk.organizasyonKodu = 0;
            pk.gorevOrganizasyonKodu = 0;
            pk.gorevYeri = (item.gorev + "").Trim();

            pk.hitapKod = item.kayitNo;

            //Sınıf kaydedilmiyor, unvan kodundan bulunuyor.
            pk.unvan = UnvanKodBul(item.unvanKod, ikyServis, ref eskiHitapUnvan, ref eskiSGBUnvan);
            pk.vekilUnvanKod = pk.unvan;
            pk.evrakNo = "";
            pk.yasalDayanak = "";
            //pk.onayTarih = pk.atamaTarihi;

            pk.aciklama = "";

            pk.kadroDerece = OrtakFonksiyonlar.ConvertToInt(item.kadroDerece, 0);
            pk.kadroTarih = pk.atamaTarihi;

            pk.kazanilmisHakDerece = item.kazanilmisHakAyligiDerece;
            pk.kazanilmisHakKademe = item.kazanilmisHakAyligiKademe;
            pk.kazanilmisHakTarih = pk.atamaTarihi;
            pk.kazanilmisEkGosterge = OrtakFonksiyonlar.ConvertToInt(item.kazanilmisHakAyligiEkGosterge, 0);

            pk.odemeyeEsasDerece = item.odemeDerece;
            pk.odemeyeEsasKademe = item.odemeKademe;
            pk.odemeyeEsasTarih = pk.atamaTarihi;
            pk.odemeyeEsasEkGosterge = OrtakFonksiyonlar.ConvertToInt(item.odemeEkGosterge, 0);

            pk.emekliyeEsasDerece = item.emekliDerece;
            pk.emekliyeEsasKademe = item.emekliKademe;
            pk.emekliyeEsasTarih = pk.atamaTarihi;
            pk.emekliyeEsasEkGosterge = OrtakFonksiyonlar.ConvertToInt(item.emekliEkGosterge, 0);

            pk.ayrilmaTarihi = TarihOl(item.bitisTarihi);
            pk.iliskiliKadroIslemNo = 0;

            return pk;
        }

        private static int UnvanKodBul(int hitapUnvan, TNS.IKY.IIKYServis ikyServis, ref int eskiHitapUnvan, ref int eskiSGBUnvan)
        {
            if (hitapUnvan == eskiHitapUnvan)
                return eskiSGBUnvan;
            if (hitapUnvan > 0)
            {
                eskiHitapUnvan = hitapUnvan;
                eskiSGBUnvan = 0;
                ObjectArray oa = ikyServis.UnvanListele(new TNS.IKY.Unvan { hitapKod = hitapUnvan });
                if (oa.sonuc.islemSonuc && oa.ObjeSayisi == 1)
                {
                    TNS.IKY.Unvan u = (TNS.IKY.Unvan)oa.objeler[0];
                    eskiSGBUnvan = u.UnvanKod;
                    return eskiSGBUnvan;
                }
                else
                    throw new Exception(hitapUnvan + " kodu hitap unvanının karşılığı bulunamadı!" + oa.sonuc.hataStr);
            }
            return 0;
        }

        private static TNSDateTime TarihOl(string tarihStr)
        {
            TNSDateTime dt = new TNSDateTime();
            if (!string.IsNullOrWhiteSpace(tarihStr) && tarihStr != "01.01.0001")
                dt.Yaz(tarihStr);
            return dt;
        }

        private static HizmetCetveliServisBean HizmetCetveliServisBeanOl(long tckn, int siraNo, string baslamaTarihi, string bitisTarihi, string gorev, int unvanKod, int kadroDerece, int odemeDerece, int odemeKademe, int odemeEkGosterge, int kazanilmisHakAyligiDerece, int kazanilmisHakAyligiKademe, int kazanilmisHakAyligiEkGosterge, int emekliDerece, int emekliKademe, int emekliEkGosterge, int sebepKod)
        {
            HizmetCetveliServisBean sb = new HizmetCetveliServisBean();
            sb.tckn = tckn;
            sb.kayitNo = siraNo;
            sb.baslamaTarihi = baslamaTarihi;
            sb.bitisTarihi = bitisTarihi;
            sb.gorev = gorev;
            sb.unvanKod = unvanKod;
            sb.yevmiye = "";
            sb.ucret = "";
            sb.hizmetSinifi = "GİH";
            sb.kadroDerece = kadroDerece.ToString();

            sb.odemeDerece = odemeDerece;
            sb.odemeKademe = odemeKademe;
            sb.odemeEkGosterge = odemeEkGosterge;

            sb.kazanilmisHakAyligiDerece = kazanilmisHakAyligiDerece;
            sb.kazanilmisHakAyligiKademe = kazanilmisHakAyligiKademe;
            sb.kazanilmisHakAyligiEkGosterge = kazanilmisHakAyligiEkGosterge;

            sb.emekliDerece = emekliDerece;
            sb.emekliKademe = emekliKademe;
            sb.emekliEkGosterge = emekliEkGosterge;

            sb.sebepKod = sebepKod;
            return sb;
        }

        static TNSCollection _personelTipListe = null;
        private static int PersonelTipBul(bool kadrolu, TNS.IKY.ENUMHizmetTablolari hizmetTuru)
        {
            if (_personelTipListe == null)
                _personelTipListe = TNS.IKY.Arac.PersonelTipListe;
            if (_personelTipListe == null) return 0;

            foreach (TNS.IKY.PersonelTipi item in _personelTipListe)
            {
                if (item.HITAP == hizmetTuru)
                {
                    if (kadrolu && item.KadroIslemiYapilacakMi())
                        return item.kod;
                    if (!kadrolu && !item.KadroIslemiYapilacakMi() && item.kod >= 1000)
                        return item.kod;
                }
            }
            return 0;
        }

        public static int _KurumdaEmekliSandigi = -1;
        public static int KurumdaEmekliSandigi
        {
            get
            {
                if (_KurumdaEmekliSandigi == -1)
                    _KurumdaEmekliSandigi = PersonelTipBul(true, TNS.IKY.ENUMHizmetTablolari.EmekliSandigi);
                return _KurumdaEmekliSandigi;
            }
        }

        public static int _KurumdisiEmekliSandigi = -1;
        public static int KurumdisiEmekliSandigi
        {
            get
            {
                if (_KurumdisiEmekliSandigi == -1)
                    _KurumdisiEmekliSandigi = PersonelTipBul(false, TNS.IKY.ENUMHizmetTablolari.EmekliSandigi);
                return _KurumdisiEmekliSandigi;
            }
        }

        public static int _KurumdisiSSK = -1;
        public static int KurumdisiSSK
        {
            get
            {
                if (_KurumdisiSSK == -1)
                    _KurumdisiSSK = PersonelTipBul(false, TNS.IKY.ENUMHizmetTablolari.SSK);
                return _KurumdisiSSK;
            }
        }

        public static int _KurumdisiBagkur = -1;
        public static int KurumdisiBagkur
        {
            get
            {
                if (_KurumdisiBagkur == -1)
                    _KurumdisiBagkur = PersonelTipBul(false, TNS.IKY.ENUMHizmetTablolari.Bagkur);
                return _KurumdisiBagkur;
            }
        }

        public static int _Borclanma = -1;
        public static int Borclanma
        {
            get
            {
                if (_Borclanma == -1)
                    _Borclanma = PersonelTipBul(false, TNS.IKY.ENUMHizmetTablolari.Borclanma);
                return _Borclanma;
            }
        }
    }
}