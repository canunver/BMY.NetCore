﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.PersonelSozlesmeToplu" CodeBehind="PersonelSozlesmeToplu.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>Toplu Personel Sözleşme Sayfası</title>
    <script type="text/javascript" language="javascript">
        var personelEkle = function () {
            showPopWin('ListePersonelSec.aspx?menuYok=1&cokluSec=1', 500, 540, true, null);
        }

        var PersonelleriEkle = function (personelListesi) {

            var store = grdListe.getStore();
            var rowIndex = store.data.length;

            Ext1.each(personelListesi, function (personel) {
                var kayitVar = false;
                Ext1.each(store.data.items, function (item) {
                    if (item.data.tcKimlikNo == personel.TCKIMLIKNO)
                        kayitVar = true;
                });

                if (!kayitVar) {
                    if (rowIndex >= store.data.length) {
                        strListe.addRecord({
                            kod: 0,
                            yil: 0,
                            tcKimlikNo: personel.TCKIMLIKNO,
                            adSoyad: personel.AD + ' ' + personel.SOYAD,
                            tutar: 0,
                            sozlesmeKod: 0
                        });
                    }

                    rowIndex++;
                }

            });
        }

        var TopluTarihDegistir = function (alan, deger) {
            var store = grdListe.getStore();
            Ext1.each(store.data.items, function (item) {
                item.set(alan, deger);
                item.commit();
            });
            //store.commitChanges();
        }

        var KomutCalistir = function (command, record, rowIndex) {
            var mesaj = "'" + record.data.adSoyad + "' isimli personel ";
            if (record.data.sozlesmeKod > 0) {
                mesaj += " ve sözleşme bilgisi ";
            }
            mesaj += " silinecektir. Onaylıyor musunuz?"

            Ext1.Msg.confirm("Uyarı", mesaj,
                function (btn) {
                    if (btn == "yes") {
                        if (record.data.kod != 0) {
                            Ext1.net.DirectMethods.PersonelSil(record.data.kod, record.data.sozlesmeKod, {
                                success: function (result) {
                                    if (result == "1") {
                                        grdListe.getSelectionModel().selectRow(rowIndex);
                                        grdListe.deleteSelected();
                                    }
                                }
                            });

                        }
                        else {
                            grdListe.getSelectionModel().selectRow(rowIndex);
                            grdListe.deleteSelected();
                        }
                    }
                });
        };

    </script>
</head>
<body>
    <form id="form" runat="server">
        <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
        <ext:ResourceManager runat="server">
        </ext:ResourceManager>
        <ext:Store ID="strListe" runat="server">
            <Reader>
                <ext:JsonReader>
                    <Fields>
                        <ext:RecordField Name="kod" Type="Int" />
                        <ext:RecordField Name="yil" Type="Int" />
                        <ext:RecordField Name="tcKimlikNo" Type="String" />
                        <ext:RecordField Name="adSoyad" Type="String" />
                        <ext:RecordField Name="basTarihDT" Type="Date" />
                        <ext:RecordField Name="bitTarihDT" Type="Date" />
                        <ext:RecordField Name="tutar" Type="Float" />
                        <ext:RecordField Name="sozlesmeKod" Type="Int" />
                    </Fields>
                </ext:JsonReader>
            </Reader>
        </ext:Store>
        <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
            <Items>
                <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout" Margins="104 20 10 20" StyleSpec="background-color:white;padding:10px">
                    <Items>
                        <ext:GridPanel ID="grdListe" runat="server" StyleSpec="background-color:white;" Border="true" Layout="FitLayout" Region="Center"
                            StripeRows="true" TrackMouseOver="true" ClicksToEdit="1" Cls="gridExt" StoreID="strListe">
                            <TopBar>
                                <ext:Toolbar ID="Toolbar1" runat="server">
                                    <Items>
                                        <ext:DisplayField runat="server" Text="Yıl: " />
                                        <ext:SpinnerField ID="ddlYil" runat="server" Width="60" />
                                        <ext:Button runat="server" ID="btnListele" Icon="TableGo" Text="Listele">
                                            <DirectEvents>
                                                <Click OnEvent="btnListele_Click">
                                                    <EventMask ShowMask="true" />
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:Button runat="server" ID="btnKaydet" Text="Kaydet" Icon="Disk">
                                            <DirectEvents>
                                                <Click OnEvent="btnKaydet_Click" Timeout="600000">
                                                    <Confirmation ConfirmRequest="true" Title="Onay" Message="Bilgiler kaydedilecek. Onaylıyor musunuz?" />
                                                    <EventMask ShowMask="true" />
                                                    <ExtraParams>
                                                        <ext:Parameter Name="LISTE" Value="Ext1.util.JSON.encode(#{grdListe}.getRowsValues())" Mode="Raw" />
                                                    </ExtraParams>
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:ToolbarSeparator />
                                        <ext:Button ID="btnPersonelEkle" runat="server" Icon="Add" Text="Personel Ekle">
                                            <Listeners>
                                                <Click Handler="personelEkle();" />
                                            </Listeners>
                                        </ext:Button>
                                    </Items>
                                </ext:Toolbar>
                            </TopBar>
                            <ColumnModel>
                                <Columns>
                                    <ext:CommandColumn Width="20">
                                        <Commands>
                                            <ext:GridCommand Icon="Delete" CommandName="Delete" />
                                        </Commands>
                                    </ext:CommandColumn>
                                    <ext:Column ColumnID="adSoyad" DataIndex="adSoyad" Header="Personel" Width="275" />
                                    <ext:DateColumn ColumnID="basTarih" DataIndex="basTarihDT" Header="Başlangıç Tarihi" Width="125" Format="dd.MM.yyyy">
                                        <Editor>
                                            <ext:DateField runat="server" Format="dd.MM.yyyy" />
                                        </Editor>
                                    </ext:DateColumn>
                                    <ext:DateColumn ColumnID="bitTarih" DataIndex="bitTarihDT" Header="Bitiş Tarihi" Width="125" Format="dd.MM.yyyy">
                                        <Editor>
                                            <ext:DateField runat="server" Format="dd.MM.yyyy" />
                                        </Editor>
                                    </ext:DateColumn>
                                    <ext:Column ColumnID="tutar" DataIndex="tutar" Header="Sözleşme Tutarı" Width="125" Align="Right">
                                        <Renderer Handler="return Ext1.util.Format.number(value, '0.000,00/i');" />
                                        <Editor>
                                            <ext:NumberField runat="server" DecimalPrecision="2" SelectOnFocus="true" />
                                        </Editor>
                                    </ext:Column>
                                    <ext:Column ColumnID="sozlesmeKod" DataIndex="sozlesmeKod" Header="Sözleşme No" Width="125" />
                                </Columns>
                            </ColumnModel>
                            <View>
                                <ext:GridView runat="server" AutoFill="false" ForceFit="false">
                                    <HeaderRows>
                                        <ext:HeaderRow Cls="x-small-editor">
                                            <Columns>
                                                <ext:HeaderColumn />
                                                <ext:HeaderColumn />
                                                <ext:HeaderColumn>
                                                    <Component>
                                                        <ext:DateField ID="basTarih" runat="server" Width="125" Height="30" Format="dd.MM.yyyy">
                                                            <Listeners>
                                                                <Select Handler="TopluTarihDegistir('basTarihDT',this.getValue());" />
                                                                <Blur Handler="TopluTarihDegistir('basTarihDT',this.getValue());" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                    </Component>
                                                </ext:HeaderColumn>
                                                <ext:HeaderColumn>
                                                    <Component>
                                                        <ext:DateField ID="bitTarih" runat="server" Width="125" Height="30" Format="dd.MM.yyyy">
                                                            <Listeners>
                                                                <Select Handler="TopluTarihDegistir('bitTarihDT',this.getValue());" />
                                                                <Blur Handler="TopluTarihDegistir('bitTarihDT',this.getValue());" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                    </Component>
                                                </ext:HeaderColumn>
                                                <ext:HeaderColumn />
                                            </Columns>
                                        </ext:HeaderRow>
                                    </HeaderRows>

                                </ext:GridView>
                            </View>
                            <Listeners>
                                <Command Fn="KomutCalistir" />
                            </Listeners>
                            <SelectionModel>
                                <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                </ext:RowSelectionModel>
                            </SelectionModel>
                            <BottomBar>
                                <ext:PagingToolbar runat="server" HideRefresh="true" />
                            </BottomBar>
                        </ext:GridPanel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
        <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
