﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.PersonelTipForm" CodeBehind="PersonelTipForm.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>
        <%= Resources.InsanKaynaklari.PersonelTipForm004%></title>
    <script type="text/javascript" language="javascript">
        function SatirDegisti() {
            if (smPersonelTipListe.hasSelection())
                Ext1.net.DirectMethods.Goster(smPersonelTipListe.getSelected().data.kod);
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
        <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
        <ext:ResourceManager runat="server">
        </ext:ResourceManager>
        <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
            <Items>
                <ext:Panel runat="server" Region="Center" Layout="RowLayout" Margins="104 20 10 20">
                    <Items>
                        <ext:FormPanel runat="server" Height="230" AutoScroll="true" Layout="ColumnLayout">
                            <TopBar>
                                <ext:Toolbar runat="server">
                                    <Items>
                                        <ext:Button ID="btnOku" runat="server" Text="<%$ Resources:InsanKaynaklari, PersonelTipForm029%>"
                                            TabIndex="13" Icon="DatabaseConnect">
                                            <DirectEvents>
                                                <Click OnEvent="btnOku_Click">
                                                    <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, PersonelTipForm030%>" />
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, PersonelTipForm031%>"
                                            TabIndex="14" Icon="DatabaseSave">
                                            <DirectEvents>
                                                <Click OnEvent="btnKaydet_Click">
                                                    <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, PersonelTipForm032%>"
                                                        Message="<%$ Resources:InsanKaynaklari, PersonelTipForm033%>" />
                                                    <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, PersonelTipForm034%>" />
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                    </Items>
                                </ext:Toolbar>
                            </TopBar>
                            <Items>
                                <ext:FormPanel runat="server" ColumnWidth="1" Padding="5">
                                    <Items>
                                        <ext:NumberField runat="server" ID="txtkod" TabIndex="1" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm005%>">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip1" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm006%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:NumberField>
                                        <ext:SpinnerField runat="server" ID="txtsira" TabIndex="2" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm011%>">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip4" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm012%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:SpinnerField>
                                        <ext:TextField runat="server" ID="txtgrupAd" TabIndex="3" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm017%>"
                                            AnchorHorizontal="97%">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip7" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm018%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:TextField>
                                        <ext:TextField runat="server" ID="txtad" TabIndex="4" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm007%>"
                                            AnchorHorizontal="97%">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip2" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm008%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:TextField>
                                        <ext:ComboBox runat="server" ID="cmbHitap" TabIndex="5" FieldLabel="Hizmet Grubu"
                                            AnchorHorizontal="97%" Editable="false" DisplayField="ad" ValueField="kod">
                                            <Store>
                                                <ext:Store runat="server" ID="stoHitap">
                                                    <Reader>
                                                        <ext:JsonReader>
                                                            <Fields>
                                                                <ext:RecordField Name="kod" Type="Int" />
                                                                <ext:RecordField Name="ad" Type="String" />
                                                            </Fields>
                                                        </ext:JsonReader>
                                                    </Reader>
                                                </ext:Store>
                                            </Store>
                                        </ext:ComboBox>
                                        <ext:TextField runat="server" ID="txtmaasGrupAd" TabIndex="6" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm019%>"
                                            AnchorHorizontal="97%">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip8" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm020%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:TextField>
                                        <ext:CompositeField runat="server" FieldLabel="Maaş günleri">
                                            <Items>
                                                <ext:Label runat="server" Text="Dönem İlk Günü:" />
                                                <ext:NumberField runat="server" ID="nfMaasDonemGun" Width="40" />
                                                <ext:ToolbarSpacer Width="40" />
                                                <ext:Label runat="server" Text="Ödeme Günü:" />
                                                <ext:NumberField runat="server" ID="nfMaasOdemeGun" Width="40" />
                                            </Items>
                                        </ext:CompositeField>
                                    </Items>
                                </ext:FormPanel>
                                <ext:FormPanel runat="server" Width="200" Padding="5">
                                    <Items>
                                        <ext:Checkbox runat="server" ID="txtkadrolu" TabIndex="7" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm013%>"
                                            BoxLabel="Evet">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip5" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm014%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:Checkbox>
                                        <ext:Checkbox runat="server" ID="txtkurumDisi" TabIndex="8" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm009%>"
                                            BoxLabel="Evet">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip3" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm010%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:Checkbox>
                                        <ext:Checkbox runat="server" ID="txtgoster" TabIndex="9" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm015%>"
                                            BoxLabel="Evet">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip6" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm016%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:Checkbox>
                                        <ext:Checkbox runat="server" ID="txtaktif" TabIndex="9" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm021%>"
                                            BoxLabel="Evet">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip9" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm022%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:Checkbox>
                                        <ext:Checkbox runat="server" ID="txtterfiyeDahil" TabIndex="10" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm023%>"
                                            BoxLabel="Evet">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip10" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm024%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:Checkbox>
                                        <ext:Checkbox runat="server" ID="txtmaasDahil" TabIndex="11" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm025%>"
                                            BoxLabel="Evet">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip11" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm026%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:Checkbox>
                                        <ext:Checkbox runat="server" ID="txthitapMi" TabIndex="12" FieldLabel="<%$ Resources:InsanKaynaklari, PersonelTipForm027%>"
                                            BoxLabel="Evet">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip12" Html="<%$ Resources:InsanKaynaklari, PersonelTipForm028%>"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:Checkbox>
                                        <ext:Checkbox runat="server" ID="txtPesinMi" TabIndex="12" FieldLabel="Peşin Maaş"
                                            BoxLabel="Evet">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip19" Html="Maaş alıp çalışılıyorsa işaret koyunuz!"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:Checkbox>
                                    </Items>
                                </ext:FormPanel>
                                <ext:FormPanel ID="FormPanel1" runat="server" Width="300" Padding="5">
                                    <Items>
                                        <ext:SpinnerField runat="server" ID="txtH1" TabIndex="13" FieldLabel="Hizmet Günü">
                                            <ToolTips>
                                                <ext:ToolTip Html="Hizmet Günü hesabı için çarpım katsayısını giriniz!" runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:SpinnerField>
                                        <ext:SpinnerField runat="server" ID="txtH6" TabIndex="14" FieldLabel="Kıdem">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip13" Html="Kıdem hesabı için çarpım katsayısını giriniz!"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:SpinnerField>
                                        <ext:SpinnerField runat="server" ID="txtH4" TabIndex="15" FieldLabel="Kazanılmış Hak">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip14" Html="Kazanılmış hak hesabı için çarpım katsayısını giriniz!"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:SpinnerField>
                                        <ext:SpinnerField runat="server" ID="txtH5" TabIndex="16" FieldLabel="EKEA">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip15" Html="EKEA hesabı için çarpım katsayısını giriniz!" runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:SpinnerField>
                                        <ext:SpinnerField runat="server" ID="txtH2" TabIndex="16" FieldLabel="İzin">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip16" Html="İzin hesabı için çarpım katsayısını giriniz!" runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:SpinnerField>
                                        <ext:SpinnerField runat="server" ID="txtH3" TabIndex="16" FieldLabel="Kurum">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip17" Html="Kurum hizmeti hesabı için çarpım katsayısını giriniz!"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:SpinnerField>
                                        <ext:SpinnerField runat="server" ID="txtH7" TabIndex="16" FieldLabel="Kadro">
                                            <ToolTips>
                                                <ext:ToolTip ID="ToolTip18" Html="Kadro hizmeti hesabı için çarpım katsayısını giriniz!"
                                                    runat="server">
                                                </ext:ToolTip>
                                            </ToolTips>
                                        </ext:SpinnerField>
                                    </Items>
                                </ext:FormPanel>
                            </Items>
                        </ext:FormPanel>
                        <ext:GridPanel runat="server" ID="grdPersonelTipListe" RowHeight="1" AutoExpandColumn="ad" ColumnLines="true" StripeRows="true">
                            <Store>
                                <ext:Store runat="server" ID="stoPersonelTipListe">
                                    <Reader>
                                        <ext:JsonReader>
                                            <Fields>
                                                <ext:RecordField Name="kod" Type="Int" />
                                                <ext:RecordField Name="ad" Type="String" />
                                                <ext:RecordField Name="kurumDisi" Type="Int" />
                                                <ext:RecordField Name="sira" Type="Int" />
                                                <ext:RecordField Name="kadrolu" Type="Int" />
                                                <ext:RecordField Name="goster" Type="Int" />
                                                <ext:RecordField Name="grupAd" Type="String" />
                                                <ext:RecordField Name="aktif" Type="Int" />
                                            </Fields>
                                        </ext:JsonReader>
                                    </Reader>
                                </ext:Store>
                            </Store>
                            <ColumnModel>
                                <Columns>
                                    <ext:Column DataIndex="grupAd" ColumnID="grupAd" Header="Grup" Width="120" />
                                    <ext:Column DataIndex="kod" ColumnID="kod" Header="Kod" Width="80" />
                                    <ext:Column DataIndex="sira" ColumnID="sira" Header="Sıra" Width="80" />
                                    <ext:Column DataIndex="ad" ColumnID="ad" Header="Ad" Width="300" />
                                    <ext:Column DataIndex="kurumDisi" ColumnID="kurumDisi" Header="Kurum Dışı" Width="80" />
                                    <ext:Column DataIndex="kadrolu" ColumnID="kadrolu" Header="Kadrolu" Width="80" />
                                    <ext:Column DataIndex="goster" ColumnID="goster" Header="Göster" Width="80" />
                                    <ext:Column DataIndex="aktif" ColumnID="aktif" Header="Aktif" Width="80" />
                                </Columns>
                            </ColumnModel>
                            <SelectionModel>
                                <ext:RowSelectionModel runat="server" ID="smPersonelTipListe">
                                    <Listeners>
                                        <SelectionChange Fn="SatirDegisti" />
                                    </Listeners>
                                </ext:RowSelectionModel>
                            </SelectionModel>
                        </ext:GridPanel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
        <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
