﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.LojmanSiteBlokForm" CodeBehind="LojmanSiteBlokForm.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>
        <%= Resources.InsanKaynaklari.LojmanSite047%></title>
    <script type="text/javascript" language="javascript">
        function SatirDegisti() {
            if (smLojmanBlokListe.hasSelection())
                Ext1.net.DirectMethods.Goster(smLojmanBlokListe.getSelected().data.kod);
        }
        function GRDListeKomutu(komut, rec, sat, sut) {
            DaireyeGit(rec.data.kod);
        }
        function DaireyeGit(kod) {
            var sitekod = $('#ddlSite').val();
            if (kod == 0)
                kod = document.getElementById("txtKod").value;
            if (Number(kod) == 0) {
                Ext1.Msg.alert("Uyarı", "İlk önce blok seçiniz", "", "")
                return;
            }
            showPopWin('LojmanSiteBlokDaireForm.aspx?menuYok=1&siteKod=' + sitekod + '&blokKod=' + kod, 1000, 500, true, '', '', true);
        }  
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager runat="server">
    </ext:ResourceManager>
    <ext:Store ID="siteStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="siteAdi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnYeni" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                TabIndex="18" Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnYeni_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite037%>"
                                TabIndex="17" Icon="DatabaseSave">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click">
                                        <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, LojmanSite038%>"
                                            Message="<%$ Resources:InsanKaynaklari, LojmanSite039%>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, LojmanSite040%>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="Sil" Icon="TableDelete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnDaire" runat="server" Text="Daireler" Icon="HouseGo">
                                <Listeners>
                                    <Click Handler="DaireyeGit(0);"></Click>
                                </Listeners>
                            </ext:Button>
                            <%-- <ext:Button ID="btnYazdir" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite041%>"
                                TabIndex="18" Icon="Printer">
                                <DirectEvents>
                                    <Click OnEvent="btnYazdir_Click">
                                    </Click>
                                </DirectEvents>
                            </ext:Button>--%>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:GridPanel ID="grdLojmanBlokListe" Width="700" Collapsed="false" AutoScroll="true"
                        Region="West" Split="true" Layout="BorderLayout" runat="server">
                        <Store>
                            <ext:Store runat="server" ID="stoLojmanBlokListe">
                                <Reader>
                                    <ext:JsonReader>
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="siteKod" Type="Int" />
                                            <ext:RecordField Name="siteAdi" Type="String" />
                                            <ext:RecordField Name="blokAdi" Type="String" />
                                            <ext:RecordField Name="blokNo" Type="String" />
                                            <ext:RecordField Name="daireSayisi" Type="Int" />
                                            <ext:RecordField Name="siteGideri" Type="Int" />
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <ColumnModel>
                            <Columns>
                               <ext:ImageCommandColumn Width="50" Header="Daireler">
                                    <Commands>
                                        <ext:ImageCommand Icon="HouseGo" CommandName="1" />
                                    </Commands>
                                </ext:ImageCommandColumn>
                                <ext:Column DataIndex="kod" ColumnID="kod" Header="Kod" Width="50px"/>
                                <ext:Column DataIndex="siteAdi" ColumnID="siteAdi" Header="Site Adı" Width="200px" />
                                <ext:Column DataIndex="blokAdi" ColumnID="blokAdi" Header="Blok Adı" Width="100px" />
                                <ext:Column DataIndex="blokNo" ColumnID="blokNo" Header="Blok No" Width="80px" />
                                <ext:Column DataIndex="daireSayisi" ColumnID="daireSayisi" Header="Daire Sayısı"
                                    Width="80px" />
                                <ext:CheckColumn DataIndex="siteGideri" ColumnID="siteGideri" Header="Site Gideri Kesilsin Mi?"
                                    Width="120px" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel runat="server" ID="smLojmanBlokListe">
                                <Listeners>
                                    <SelectionChange Fn="SatirDegisti" />
                                </Listeners>
                            </ext:RowSelectionModel>
                        </SelectionModel>                        
                        <Listeners>
                            <Command Fn="GRDListeKomutu" />
                        </Listeners>
                    </ext:GridPanel>
                    <ext:FormPanel runat="server" Border="false" Region="Center" Layout="RowLayout" Padding="5"
                        ButtonAlign="Center" AutoScroll="true">
                        <Items>
                            <ext:TextField runat="server" Hidden="true" ID="txtKod" TabIndex="1" FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite005%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite006%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:ComboBox ReadOnly="true" runat="server" ID="ddlSite" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite007%>"
                                AnchorHorizontal="80%" DisplayField="siteAdi" ValueField="kod" StoreID="siteStore">
                            </ext:ComboBox>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtblokAdi" TabIndex="3"
                                FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite043%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite043%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtblokNo" TabIndex="4"
                                FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite044%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite044%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:TextField AnchorHorizontal="80%" runat="server" ID="txtdaireSayisi" TabIndex="5"
                                FieldLabel="<%$ Resources:InsanKaynaklari, LojmanSite045%>">
                                <ToolTips>
                                    <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, LojmanSite045%>" runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:TextField>
                            <ext:Checkbox runat="server" ID="chksiteGideri" TabIndex="9" BoxLabel="<%$ Resources:InsanKaynaklari, LojmanSite046%>"
                                FieldLabel="">
                                <ToolTips>
                                    <ext:ToolTip ID="ToolTip2" Html="<%$ Resources:InsanKaynaklari, LojmanSite046%>"
                                        runat="server">
                                    </ext:ToolTip>
                                </ToolTips>
                            </ext:Checkbox>
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
