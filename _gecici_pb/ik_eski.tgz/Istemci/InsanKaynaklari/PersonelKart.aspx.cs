﻿using System;
using System.Collections;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections.Generic;
using TNS.KYM;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel aile sınıfı
    /// </summary>
    public partial class PersonelKart : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPersonelKod.Value = (Request.QueryString["personelKod"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnTemizle.Hidden = true;
            //    btnSil.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {

                KartTipiDoldur();
                Genel.YakinlikDerecesiDoldur(ddlYakinlik, yakinlikDerecesiStore);
                yakinlikDerecesiStore.InsertRecord(0, new Sozluk { kod = 0, ad = "" });
                Temizle();
                Listele(new TNS.IKY.PersonelKart());
            }
        }

        /// <summary>
        /// Girilen kritere göre Kişinin bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel tipinde sınıf</param>
        public void Listele(TNS.IKY.PersonelKart kriter)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) == 0)
                return;

            kriter.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            ObjectArray pler = servisIKY.PersonelKartListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            ArrayList liste = new ArrayList();
            string aktif = "";
            foreach (TNS.IKY.PersonelKart p in pler.objeler)
            {
                aktif = "Aktif";
                if (p.kayipTarihi.Yil != 0 || p.iadeTarihi.Yil != 0)
                    aktif = "Pasif";
                liste.Add(new { ZIMMETTAR = p.zimmetTarihi.ToString(), KOD = p.kod, KARTTIPI = p.kartTipiAd, KARTNO = p.kartNo, ADSOYAD = p.adiSoyadi, AKTIF = aktif });
            }

            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }

        /// <summary>
        /// Kaydet düğmesine basınca ekrandan bilgileri toplayarak kayıt etmek için sunucu tarafındaki metodu çağıran metod
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) == 0)
                hata += Resources.InsanKaynaklari.FRMPAB002 + "<br>";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.PersonelKart bilgi = new TNS.IKY.PersonelKart();
            bilgi.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            bilgi.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            bilgi.kartNo = txtKartNo.Text;
            bilgi.adiSoyadi = txtAdSoyad.Text;
            bilgi.plaka = txtPlaka.Text;
            bilgi.zimmetTarihi = Genel.TarihAlaniDegerVer(txtZimmetTarihi);
            bilgi.kartTipi = OrtakFonksiyonlar.ConvertToInt(ddlTip.SelectedItem.Value,0);
            bilgi.yakinligi = (ENUMYakinlikDerecesi)OrtakFonksiyonlar.ConvertToInt(ddlYakinlik.Value, 0);
            bilgi.tagCihazNo = txtCihazNo.Text;
            bilgi.aciklama = txtAciklama.Text;
            bilgi.iadeTarihi = Genel.TarihAlaniDegerVer(txtIadeTarihi);
            bilgi.kayipTarihi = Genel.TarihAlaniDegerVer(txtKayipTarihi);
            bilgi.zimmetEdenPersonel = OrtakFonksiyonlar.ConvertToInt(hdnZimmetEden.Value, 0);
            bilgi.iadeAlanPersonel = OrtakFonksiyonlar.ConvertToInt(hdnIadeAlan.Value, 0);

            Sonuc sonuc = servisIKY.PersonelKartKaydet(kullanan, bilgi);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele(new TNS.IKY.PersonelKart());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB015);
            }
        }

        /// <summary>
        /// Sil düğmesine basınca ekrandan bilgileri toplayarak silmek için sunucu tarafındaki metodu çağıran metod
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB017);
                return;
            }

            TNS.IKY.PersonelKart d = new TNS.IKY.PersonelKart();
            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            d.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            Sonuc sonuc = servisIKY.PersonelKartSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele(new TNS.IKY.PersonelKart());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB016);
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            Temizle();
            hdnKod.Value = e.ExtraParams["kod"];
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            TNS.IKY.PersonelKart kriter = new TNS.IKY.PersonelKart();
            kriter.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            kriter.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            ObjectArray pler = new ObjectArray();
            pler = servisIKY.PersonelKartListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            foreach (TNS.IKY.PersonelKart p in pler.objeler)
            {
                txtKartNo.Text = p.kartNo;
                txtAdSoyad.Text = p.adiSoyadi;
                txtPlaka.Text = p.plaka;
                txtCihazNo.Text = p.tagCihazNo.ToString();
                txtZimmetTarihi.Text = p.zimmetTarihi.ToString();
                txtIadeTarihi.Text = p.iadeTarihi.ToString();
                txtAciklama.Text = p.aciklama;
                txtKayipTarihi.Text = p.kayipTarihi.ToString();
                ddlTip.SetValueAndFireSelect(p.kartTipi);
                ddlYakinlik.SelectedItem.Value = ((int)p.yakinligi).ToString();
                hdnZimmetEden.Value = p.zimmetEdenPersonel;
                txtZimmetEden.Text = p.zimmetEdenPersonelAd;
                hdnIadeAlan.Value = p.iadeAlanPersonel;
                txtIadeAlan.Text = p.iadeAlanPersonelAd;
            }
        }

        protected void KartTipiDoldur()
        {
            ddlTip.Items.Clear();
            kartTipiStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.KARTTIPI, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            kartTipiStore.DataBind();
        }

        void Temizle()
        {
            hdnKod.Clear();
            ddlTip.Clear();
            txtKartNo.Clear();
            ddlYakinlik.Clear();
            txtAdSoyad.Clear();
            txtPlaka.Clear();
            txtCihazNo.Clear();
            txtZimmetTarihi.Clear();
            txtIadeTarihi.Clear();
            txtAciklama.Clear();
            txtKayipTarihi.Clear();
            grdListeSelectionModel.ClearSelections();
            hdnZimmetEden.Clear();
            txtZimmetEden.Clear();
            hdnIadeAlan.Clear();
            txtIadeAlan.Clear();
        }
    }
}
