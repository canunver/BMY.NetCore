﻿using System;
using System.Collections;
using System.Data;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;
using TNS.KYM;

namespace InsanKaynaklari
{
    public partial class PersonelHizmetAyari : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPersonelKod.Value = (Request.QueryString["personelKod"] + "").Trim();
            if (!IsPostBack)
            {
                Genel.AyDoldur(ddlKTAyi, ayStore, true);
                Genel.AyDoldur(ddlETAyi, ayStore, true);
                Listele();
            }
        }

        protected void Listele()
        {
            ObjectArray arr = servisIKY.PersonelKadroAyarListele(kullanan, new KadroAyar { pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) });
            if (!arr.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, arr.sonuc.hataStr);
                return;
            }

            if (arr.objeler.Count > 0)
            {
                KadroAyar ayar = (KadroAyar)arr.objeler[0];
                ddlKTAyi.Value = ayar.kTerfiAyi;
                ddlETAyi.Value = ayar.eTerfiAyi;
                txtKAcilisTarihi.Text = ayar.kAcilisTarihi.ToString();
                txtEAcilisTarihi.Text = ayar.eAcilisTarihi.ToString();
            }
        }

        protected void btnKaydet_Click(object sender, EventArgs e)
        {
            KadroAyar ayar = new KadroAyar();
            ayar.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            ayar.kTerfiAyi = OrtakFonksiyonlar.ConvertToInt(ddlKTAyi.Value, 0);
            ayar.eTerfiAyi = OrtakFonksiyonlar.ConvertToInt(ddlETAyi.Value, 0);
            ayar.kAcilisTarihi = Genel.TarihAlaniDegerVer(txtKAcilisTarihi);
            ayar.eAcilisTarihi = Genel.TarihAlaniDegerVer(txtEAcilisTarihi);

            Sonuc sonuc = servisIKY.PersonelKadroAyarKaydet(kullanan, ayar);
            if (sonuc.islemSonuc)
                GenelIslemler.MesajKutusu("Bilgi", "Kayıt işlemi başarılı.");
            else
                GenelIslemler.MesajKutusu("Hata", sonuc.hataStr);
        }
    }
}