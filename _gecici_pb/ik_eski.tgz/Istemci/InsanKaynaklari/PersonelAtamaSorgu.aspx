﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelAtamaSorgu.aspx.cs"
    Inherits="InsanKaynaklari.PersonelAtamaSorgu" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Personel Atama Sorgu</title>
    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
    <script type="text/javascript">
        var OrgBirimDoldur = function (node) {
            var orgBirim = { harcamaMi: 1, yetkiliOlduguMuhasebeBirim: hdnYetkiliBirim.value };
            nodeLoadOrgBirimParam(node, orgBirim);
        };
        var birimRenderer = function (value) {
            if (hdnBirimKod.value == value)
                return hdnBirimAd.value;
            else
                return "";
        };
        var unvanRenderer = function (value) {
            var r = storeUnvan.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.UnvanAd;
        };
        var kadroDereceRenderer = function (value) {
            var r = storeKadroDerece.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.DereceAd;
        };
        var personelTipRenderer = function (value) {
            var r = personelTipStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
        var sinifRenderer = function (value) {
            var r = sinifStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
        var atamaTuruRenderer = function (value) {
            var r = atamaTuruStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
        var atamaSekliRenderer = function (value) {
            var r = atamaSekliStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
        var hareketDurumuRenderer = function (value) {
            var r = hareketDurumuStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
    </script>
</head>
<body>
    <form id="Form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnYetkiliBirim" runat="server" />
    <ext:Hidden ID="hdnBirimKod" runat="server" />
    <ext:Hidden ID="hdnBirimAd" runat="server" />
    <ext:Store runat="server" ID="storeUnvan">
        <Reader>
            <ext:JsonReader IDProperty="UnvanKod">
                <Fields>
                    <ext:RecordField Name="UnvanKod" />
                    <ext:RecordField Name="UnvanAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeKadroDerece">
        <Reader>
            <ext:JsonReader IDProperty="DereceKod">
                <Fields>
                    <ext:RecordField Name="DereceKod" />
                    <ext:RecordField Name="DereceAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="sinifStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="atamaTuruStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="atamaSekliStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="hareketDurumuStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center>
                    <ext:Panel ID="pnlSol" runat="server" Width="230" Collapsed="false" AutoScroll="true">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server">
                                <Items>
                                    <ext:ToolbarFill ID="ToolbarFill1" runat="server" />
                                    <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPBI003%>"
                                        Icon="ApplicationGo">
                                        <DirectEvents>
                                            <Click OnEvent="PersonelAtamaListele">
                                                <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="solTaraf" runat="server">
                                <West Split="true" UseSplitTips="true" MarginsSummary="5">
                                    <ext:FormPanel ID="FormPanel1" runat="server" LabelWidth="50" Layout="AnchorLayout"
                                        Frame="false" Header="false" Border="false" Padding="5" Collapsible="true" Width="250">
                                        <Items>
                                            <ext:FitLayout ID="FitLayout" runat="server">
                                                <Items>
                                                    <ext:PropertyGrid ID="pgFiltre" runat="server" Border="false" HideHeaders="true">
                                                        <Source>
                                                            <ext:PropertyGridParameter Name="birim" DisplayName="<%$ Resources:InsanKaynaklari,FRMPRM026%>">
                                                                <Renderer Fn="birimRenderer" />
                                                                <Editor>
                                                                    <ext:DropDownField ID="ddlBirim" runat="server" Editable="false" TriggerIcon="Ellipsis"
                                                                        Mode="ValueText">
                                                                        <Triggers>
                                                                            <ext:FieldTrigger Icon="Clear" />
                                                                        </Triggers>
                                                                        <Listeners>
                                                                            <TriggerClick Handler="if (index == 0) { this.clearValue(); }" />
                                                                        </Listeners>
                                                                        <Component>
                                                                            <ext:Panel ID="Panel5" runat="server" Width="400">
                                                                                <Items>
                                                                                    <ext:TreePanel ID="trpBirim" runat="server" Height="250" AutoWidth="true" AutoScroll="true"
                                                                                        Border="false" RootVisible="false">
                                                                                        <Root>
                                                                                            <ext:AsyncTreeNode NodeID="0" Expanded="true" Icon="Note" />
                                                                                        </Root>
                                                                                        <Loader>
                                                                                            <ext:PageTreeLoader OnNodeLoad="NodeLoad" />
                                                                                        </Loader>
                                                                                        <Listeners>
                                                                                            <Click Handler="#{ddlBirim}.setValue(node.id, node.text, false);#{hdnBirimKod}.setValue(node.id);#{hdnBirimAd}.setValue(node.text); #{ddlBirim}.collapse();" />
                                                                                        </Listeners>
                                                                                    </ext:TreePanel>
                                                                                </Items>
                                                                            </ext:Panel>
                                                                        </Component>
                                                                    </ext:DropDownField>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="tcKimlikNo" DisplayName="<%$ Resources:InsanKaynaklari,FRMPKS001%>">
                                                                <Editor>
                                                                    <ext:TextField runat="server" ID="txtTCKimlikNo">
                                                                    </ext:TextField>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="sinif" DisplayName="<%$ Resources:InsanKaynaklari,FRMPRK051 %>">
                                                                <Renderer Fn="sinifRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="ddlSinif" runat="server" Editable="true" TypeAhead="true" Mode="Local"
                                                                        ForceSelection="true" Width="310" StoreID="SinifStore" DisplayField="AD" ValueField="KOD"
                                                                        SelectOnFocus="true">
                                                                    </ext:ComboBox>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="unvan" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD019 %>">
                                                                <Renderer Fn="unvanRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="cmbUnvan" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                                        ForceSelection="true" StoreID="storeUnvan" DisplayField="UnvanAd" ValueField="UnvanKod"
                                                                        ListWidth="250" />
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="kadroDerece" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD020 %>">
                                                                <Renderer Fn="kadroDereceRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="cmbKadroDerece" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                                        ForceSelection="true" StoreID="storeKadroDerece" DisplayField="DereceAd" ValueField="DereceKod" />
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="personelTip" DisplayName="Personel Tip">
                                                                <Renderer Fn="personelTipRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="cmbPersonelTip" runat="server" StoreID="personelTipStore" Editable="true"
                                                                        TypeAhead="true" Mode="Local" ForceSelection="true" SelectOnFocus="true" DisplayField="ad"
                                                                        ValueField="kod" Width="200px">
                                                                        <Store>
                                                                            <ext:Store ID="personelTipStore" runat="server">
                                                                                <Reader>
                                                                                    <ext:JsonReader IDProperty="kod">
                                                                                        <Fields>
                                                                                            <ext:RecordField Name="kod" Type="Int" />
                                                                                            <ext:RecordField Name="ad" />
                                                                                        </Fields>
                                                                                    </ext:JsonReader>
                                                                                </Reader>
                                                                            </ext:Store>
                                                                        </Store>
                                                                    </ext:ComboBox>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="atamaSekli" DisplayName="SGK Hizmet Sebebi">
                                                                <Renderer Fn="atamaSekliRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="ddlAtamaSekli" runat="server" StoreID="atamaSekliStore" TypeAhead="true"
                                                                        Mode="Local" ForceSelection="true" SelectOnFocus="true" DisplayField="AD" ValueField="KOD"
                                                                        Width="200px">
                                                                    </ext:ComboBox>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <%--       <ext:PropertyGridParameter Name="atamaTuru" DisplayName="Atama Türü">
                                                                <Renderer Fn="atamaTuruRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="ddlAtamaTuru" runat="server" StoreID="atamaTuruStore" TypeAhead="true"
                                                                        Mode="Local" ForceSelection="true" SelectOnFocus="true" DisplayField="AD" ValueField="KOD"
                                                                        Width="200px">
                                                                    </ext:ComboBox>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>--%>
                                                            <ext:PropertyGridParameter Name="hareketDurumu" DisplayName="Kadro Durumu">
                                                                <Renderer Fn="hareketDurumuRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="ddlHareketDurumu" runat="server" StoreID="hareketDurumuStore" TypeAhead="true"
                                                                        Mode="Local" ForceSelection="true" SelectOnFocus="true" DisplayField="AD" ValueField="KOD"
                                                                        Width="200px">
                                                                    </ext:ComboBox>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                        </Source>
                                                        <Listeners>
                                                            <Render Handler="function() { this.getStore().sortInfo = undefined; this.getColumnModel().config[0].sortable = false;this.getColumnModel().config[1].sortable = false;}" />
                                                            <SortChange Handler="this.getStore().sortInfo = undefined;" />
                                                        </Listeners>
                                                        <View>
                                                            <ext:GridView ID="GridView1" ForceFit="true" runat="server" />
                                                        </View>
                                                    </ext:PropertyGrid>
                                                </Items>
                                            </ext:FitLayout>
                                        </Items>
                                    </ext:FormPanel>
                                </West>
                                <Center>
                                    <ext:Panel ID="Panel1" runat="server" Border="false">
                                        <Items>
                                            <ext:FitLayout ID="fitLayout3" runat="server">
                                                <Items>
                                                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                                        Layout="FitLayout" Width="350" Border="false">
                                                        <ColumnModel ID="ColumnModel1" runat="server">
                                                            <Columns>
                                                                <ext:ImageCommandColumn Width="20">
                                                                    <Commands>
                                                                        <ext:ImageCommand Icon="TableEdit" CommandName="giris">
                                                                        </ext:ImageCommand>
                                                                    </Commands>
                                                                </ext:ImageCommandColumn>
                                                                <ext:Column ColumnID="PERSONELTUR" DataIndex="PERSONELTUR" Header="Personel Tür" />
                                                                <ext:Column ColumnID="TCKIMLIKNO" DataIndex="TCKIMLIKNO" Header="TC Kimlik No" />
                                                                <ext:Column ColumnID="ADSOYAD" DataIndex="ADSOYAD" Header="<%$Resources:InsanKaynaklari,FRMPAB034%>" />
                                                                <ext:Column ColumnID="BIRIM" DataIndex="BIRIM" Header="Birim" />
                                                                <ext:Column ColumnID="SINIF" DataIndex="SINIF" Header="Sinif" />
                                                                <ext:Column ColumnID="UNVAN" DataIndex="UNVAN" Header="Unvan" />
                                                                <ext:Column ColumnID="KADRODERECE" DataIndex="KADRODERECE" Header="Kadro Derecesi" />
                                                                <ext:Column ColumnID="ATAMATARIHI" DataIndex="ATAMATARIHI" Header="Atama Tarihi" />
                                                                <ext:Column ColumnID="ATAMANEDENI" DataIndex="ATAMANEDENI" Header="Atama Nedeni" />
                                                                <%--<ext:Column ColumnID="ATAMATURU" DataIndex="ATAMATURU" Header="Atama Türü" />--%>
                                                                <ext:Column ColumnID="ATAMASEKLI" DataIndex="ATAMASEKLI" Header="SGK Hizmet Sebebi" />
                                                                <ext:Column ColumnID="HAREKETDURUMUAD" DataIndex="HAREKETDURUMUAD" Header="Kadro Durumu" />
                                                            </Columns>
                                                        </ColumnModel>
                                                        <Listeners>
                                                            <Command Handler="window.parent.GirisAc(record.data.KADROKOD, record.data.PERSONELKOD, record.data.HAREKETDURUMU, record.data.ESKIKADROKOD);" />
                                                        </Listeners>
                                                        <Store>
                                                            <ext:Store ID="storeListe" runat="server">
                                                                <Reader>
                                                                    <ext:JsonReader>
                                                                        <Fields>
                                                                            <ext:RecordField Name="KADROKOD" />
                                                                            <ext:RecordField Name="PERSONELKOD" />
                                                                            <ext:RecordField Name="ADSOYAD" />
                                                                            <ext:RecordField Name="TCKIMLIKNO" />
                                                                            <ext:RecordField Name="BIRIM" />
                                                                            <ext:RecordField Name="SINIF" />
                                                                            <ext:RecordField Name="UNVAN" />
                                                                            <ext:RecordField Name="KADRODERECE" />
                                                                            <ext:RecordField Name="ATAMATARIHI" />
                                                                            <ext:RecordField Name="ATAMASEKLI" />
                                                                            <ext:RecordField Name="ATAMANEDENI" />
                                                                            <ext:RecordField Name="PERSONELTUR" />
                                                                            <ext:RecordField Name="HAREKETDURUMU" />
                                                                            <ext:RecordField Name="HAREKETDURUMUAD" />
                                                                            <ext:RecordField Name="ESKIKADROKOD" />
                                                                        </Fields>
                                                                    </ext:JsonReader>
                                                                </Reader>
                                                            </ext:Store>
                                                        </Store>
                                                        <BottomBar>
                                                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="250" HideRefresh="true">
                                                            </ext:PagingToolbar>
                                                        </BottomBar>
                                                    </ext:GridPanel>
                                                </Items>
                                            </ext:FitLayout>
                                        </Items>
                                    </ext:Panel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
