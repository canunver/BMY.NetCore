﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelAskerlik.aspx.cs"
    Inherits="InsanKaynaklari.PersonelAskerlik" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        function AskerlikDurumuDegisti() {
            if (ddlAskerlikDurumu.value.split(':')[1] == "07.00001") {
                txtTecilTarihi.setVisible(true);
                txtMuafNedeni.setVisible(false);
                cmpAsker.setVisible(false);
                cmpTerhis.setVisible(false);
                chkBorclanma.setVisible(false);
                cmpRS.setVisible(false);
                cmpNasp.setVisible(false);
                yedekSubay.setVisible(false);
                yedekSubay2.setVisible(false);
                txtIbrazIntıkalTarihi.setVisible(false);
            }
            else if (ddlAskerlikDurumu.value.split(':')[1] == "07.00005") {
                txtMuafNedeni.setVisible(true); ;
                txtTecilTarihi.setVisible(false);
                cmpAsker.setVisible(false);
                cmpTerhis.setVisible(false);
                chkBorclanma.setVisible(false);
                cmpRS.setVisible(false);
                cmpNasp.setVisible(false);
                yedekSubay.setVisible(false);
                yedekSubay2.setVisible(false);
                txtIbrazIntıkalTarihi.setVisible(false);
            }
            else {
                txtMuafNedeni.setVisible(false);
                txtTecilTarihi.setVisible(false);
                cmpAsker.setVisible(true);
                cmpTerhis.setVisible(true);
                chkBorclanma.setVisible(true);
                cmpRS.setVisible(true);
                cmpNasp.setVisible(true);
                yedekSubay.setVisible(true);
                yedekSubay2.setVisible(true);
                txtIbrazIntıkalTarihi.setVisible(true);
            }
        }
        function ZorunluAlanKontrol() {
            if (!frmBilgi.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return frmBilgi.isValid();
        }
        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                function (btn) {
                    if (btn == "yes") {
                        Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                    }
                });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="askerlikDurumuStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="rutbesiStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="sinifiStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server">
        <Items>
            <ext:BorderLayout runat="server">
                <Center>
                    <ext:Panel runat="server" Border="false">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                        Icon="Disk">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click" Before="return ZorunluAlanKontrol();">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout runat="server">
                                <Center>
                                    <ext:FormPanel ID="frmBilgi" runat="server" Frame="true" AutoScroll="true" Padding="5"
                                        LabelWidth="130" MonitorValid="true">
                                        <Items>
                                            <ext:ComboBox runat="server" ID="ddlAskerlikDurumu" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAS003%>"
                                                NoteAlign="Top" Width="130" DisplayField="AD" ValueField="KOD" StoreID="askerlikDurumuStore"
                                                TriggerAction="All" Mode="Local" ForceSelection="true">
                                                <Listeners>
                                                    <Select Handler="AskerlikDurumuDegisti();" />
                                                </Listeners>
                                            </ext:ComboBox>
                                            <ext:CompositeField ID="cmpAsker" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAS010%>">
                                                <Items>
                                                    <ext:DateField ID="txtDuhulTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS006%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:DateField>
                                                    <ext:TextField ID="txtCuzdanNo" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS008%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:TextField>
                                                    <ext:TextField ID="txtAskerlikSubesi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS014%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:TextField>
                                                    <ext:TextField ID="txtSayilmayanGunSayisi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS015%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:TextField>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField ID="cmpTerhis" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAS016%>">
                                                <Items>
                                                    <ext:DateField ID="txtTerhisTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS007%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:DateField>
                                                    <ext:TextField ID="txtTerhisBelgeNo" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS017%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:TextField>
                                                    <ext:DateField ID="txtTerhisBelgeTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS018%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:DateField>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:DateField ID="txtTecilTarihi" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAS005%>"
                                                NoteAlign="Top" Width="130" Hidden="true">
                                            </ext:DateField>
                                            <ext:TextField ID="txtMuafNedeni" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAS004%>"
                                                NoteAlign="Top" Width="130" Hidden="true">
                                            </ext:TextField>
                                            <ext:Checkbox runat="server" ID="chkBorclanma" BoxLabel="<%$Resources:InsanKaynaklari,FRMPAS019%>"
                                                NoteAlign="Top" Width="200">
                                            </ext:Checkbox>
                                            <ext:CompositeField ID="cmpRS" runat="server">
                                                <Items>
                                                    <ext:ComboBox runat="server" ID="ddlRutbe" Note="<%$Resources:InsanKaynaklari,FRMPAS020%>"
                                                        NoteAlign="Top" Width="130" DisplayField="AD" ValueField="KOD" StoreID="rutbesiStore">
                                                    </ext:ComboBox>
                                                    <ext:ComboBox runat="server" ID="ddlSinif" Note="<%$Resources:InsanKaynaklari,FRMPAS021%>"
                                                        NoteAlign="Top" Width="130" DisplayField="AD" ValueField="KOD" StoreID="sinifiStore">
                                                    </ext:ComboBox>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField ID="cmpNasp" runat="server">
                                                <Items>
                                                    <ext:DateField ID="txtAstegmenNaspTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS022%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:DateField>
                                                    <ext:DateField ID="txtTegmenNaspTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS023%>"
                                                        NoteAlign="Top" Width="130">
                                                    </ext:DateField>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField ID="yedekSubay" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAS024%>"
                                                LabelWidth="200">
                                                <Items>
                                                    <ext:DateField ID="txtYedekSubayOkuluGirisTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS025%>"
                                                        NoteAlign="Top" Width="200">
                                                    </ext:DateField>
                                                    <ext:TextField ID="txtSinifDonemSicilNo" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS026%>"
                                                        NoteAlign="Top" Width="200">
                                                    </ext:TextField>
                                                    <ext:TextField ID="txtErYedekSubayGorevYeri" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS027%>"
                                                        NoteAlign="Top" Width="200">
                                                    </ext:TextField>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField ID="yedekSubay2" runat="server">
                                                <Items>
                                                    <ext:DateField ID="txtErYedekSubayGecisTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS028%>"
                                                        NoteAlign="Top" Width="200">
                                                    </ext:DateField>
                                                    <ext:DateField ID="txtErYedekSubayKitaBaslamaTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS029%>"
                                                        NoteAlign="Top" Width="200">
                                                    </ext:DateField>
                                                    <ext:DateField ID="txtErYedekSubayKitaBitisTarihi" runat="server" Note="<%$Resources:InsanKaynaklari,FRMPAS030%>"
                                                        NoteAlign="Top" Width="200">
                                                    </ext:DateField>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:DateField ID="txtIbrazIntıkalTarihi" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAS031%>"
                                                NoteAlign="Top" Width="200">
                                            </ext:DateField>
                                            <ext:TextArea ID="txtAciklama" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPAS032%>"
                                                NoteAlign="Top" Height="50" Width="400" AutoScroll="true">
                                            </ext:TextArea>
                                            <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                                Frame="true" FieldLabel="<%$Resources:InsanKaynaklari,FRMORT082%>" TrackMouseOver="true"
                                                StoreID="BelgeStore" HideHeaders="true" AutoHeight="true" Width="350">
                                                <ColumnModel ID="ColumnModel2" runat="server">
                                                    <Columns>
                                                        <ext:RowNumbererColumn />
                                                        <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Width="250" />
                                                        <ext:CommandColumn Width="30">
                                                            <Commands>
                                                                <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB037 %>" />
                                                            </Commands>
                                                        </ext:CommandColumn>
                                                        <ext:CommandColumn Width="30">
                                                            <Commands>
                                                                <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB038 %>" />
                                                            </Commands>
                                                        </ext:CommandColumn>
                                                    </Columns>
                                                </ColumnModel>
                                                <Listeners>
                                                    <Command Fn="KomutCalistir" />
                                                </Listeners>
                                                <SelectionModel>
                                                    <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                                    </ext:RowSelectionModel>
                                                </SelectionModel>
                                                <TopBar>
                                                    <ext:Toolbar ID="Toolbar2" runat="server">
                                                        <Items>
                                                            <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                                ButtonText="Belge Ekle">
                                                                <DirectEvents>
                                                                    <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                                </DirectEvents>
                                                            </ext:FileUploadField>
                                                        </Items>
                                                    </ext:Toolbar>
                                                </TopBar>
                                            </ext:GridPanel>
                                        </Items>
                                    </ext:FormPanel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
