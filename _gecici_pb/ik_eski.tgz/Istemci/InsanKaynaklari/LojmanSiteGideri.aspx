﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.LojmanSiteGideri" CodeBehind="LojmanSiteGideri.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>Site Gider Tanım</title>
    <script type="text/javascript" language="javascript">

    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server" />
    <ext:ResourceManager runat="server" />
    <ext:Viewport runat="server" Layout="FitLayout" StyleSpec="background-color: transparent;">
        <Items>
            <ext:GridPanel runat="server" ID="grdKesintiler" AutoExpandColumn="aciklama">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite037%>"
                                TabIndex="1" Icon="DatabaseSave">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click">
                                        <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, LojmanSite038%>"
                                            Message="<%$ Resources:InsanKaynaklari, LojmanSite039%>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, LojmanSite040%>" />
                                        <ExtraParams>
                                            <ext:Parameter Name="grdKesintiler" Value="Ext1.encode(#{grdKesintiler}.getRowsValues())"
                                                Mode="Raw" />
                                        </ExtraParams>
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Store>
                    <ext:Store runat="server" ID="stoKesintiler">
                        <Reader>
                            <ext:JsonReader>
                                <Fields>
                                    <ext:RecordField Name="kod" Type="Int" />
                                    <ext:RecordField Name="giderKod" Type="Int" />
                                    <ext:RecordField Name="giderTurAd" Type="String" />
                                    <ext:RecordField Name="miktar" Type="Float" />
                                    <ext:RecordField Name="aciklama" Type="String" />
                                    <ext:RecordField Name="otomatik" Type="Boolean" />
                                </Fields>
                            </ext:JsonReader>
                        </Reader>
                    </ext:Store>
                </Store>
                <ColumnModel>
                    <Columns>
                        <ext:Column ColumnID="giderTurAd" DataIndex="giderTurAd" Header="Gider" Tooltip="Açıklama Giriniz." />
                        <ext:NumberColumn ColumnID="miktar" DataIndex="miktar" Header="Tutar" Tooltip="Gider tutarını giriniz."
                            Format="0,00/i" Align="Right">
                            <Editor>
                                <ext:NumberField runat="server" SelectOnFocus="true" />
                            </Editor>
                        </ext:NumberColumn>
                        <ext:Column ColumnID="aciklama" DataIndex="aciklama" Header="Açıklama" Tooltip="Açıklama Giriniz.">
                            <Editor>
                                <ext:TextField runat="server" SelectOnFocus="true" />
                            </Editor>
                        </ext:Column>
                        <ext:CheckColumn ColumnID="otomatik" DataIndex="otomatik" Header="Otomatik" Tooltip="Otomatik kesilsin mi?"
                            Align="Center" Editable="true" />
                    </Columns>
                </ColumnModel>
            </ext:GridPanel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server" />
    </form>
</body>
</html>
