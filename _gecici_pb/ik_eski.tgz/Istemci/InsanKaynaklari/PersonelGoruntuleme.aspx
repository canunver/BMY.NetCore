﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelGoruntuleme.aspx.cs"
    Inherits="InsanKaynaklari.PersonelGoruntuleme" %>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Personel</title>
    <!-- Global stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900"
        rel="stylesheet" type="text/css">
    <link href="../App_themes/LTR/assets/css/icons/icomoon/styles.css" rel="stylesheet"
        type="text/css">
    <link href="../App_themes/LTR/assets/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="../App_themes/LTR/assets/css/core.css" rel="stylesheet" type="text/css">
    <link href="../App_themes/LTR/assets/css/components.css" rel="stylesheet" type="text/css">
    <link href="../App_themes/LTR/assets/css/colors.css" rel="stylesheet" type="text/css">
    <!-- /global stylesheets -->
    <!-- Core JS files -->
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/loaders/pace.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/core/libraries/jquery.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/core/libraries/bootstrap.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/loaders/blockui.min.js"></script>
    <!-- /core JS files -->
    <!-- Theme JS files -->
    <script type="text/javascript" src="../App_themes/LTR/assets/js/core/libraries/jquery_ui/core.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/core/libraries/jquery_ui/effects.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/extensions/cookie.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/forms/styling/switchery.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/forms/styling/uniform.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/trees/fancytree_all.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/trees/fancytree_childcounter.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/forms/selects/bootstrap_select.min.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/plugins/forms/selects/bootstrap_multiselect.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/core/app.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/pages/form_bootstrap_select.js"></script>
    <script type="text/javascript" src="../App_themes/LTR/assets/js/pages/extra_trees.js"></script>
    <!-- /theme JS files -->
    <script type="text/javascript">
        $(document).ready(function () {
            $("#btnAra").click(function () {
                KisiListele(false);
                return false;
            });
        });
        function KisiListele(ekle) {

            //            if (btn == -1)
            //                kelime = $("#hdnSorgu")[0].value;
            //            else if (btn == 1 || btn == 4) {
            //                if (!$('#wrapper').is('.active-left'))
            //                    kelime = $("#txtAra")[0].value;
            //                else
            //                    kelime = $("#txtAra2")[0].value;
            //            }
            //            else if (btn == 2)
            //                kelime = $("#txtAra2")[0].value;
            //            }
            //            var opSel = $("#pTipler")[0].options;
            //            var pTipler = "";
            //            var alansinifi = null;
            //            for (var i = 0; i < opSel.length; i++) {
            //                if (opSel[i].selected)
            //                    pTipler += opSel[i].value + ";";
            //            }
            if (!ekle) {
                $("#thmListe").html('');
                $("#hdnSatir")[0].value = 0;
            }
            //            else {
            //                var alanlar = document.getElementById("thmListe").querySelectorAll(".alan");
            //                if (alanlar != null && alanlar[0] != null)
            //                    alansinifi = alanlar[0].getAttribute("class");
            //            }
            //            $("#hdnSorgu")[0].value = kelime;
            //            $("#txtAra")[0].value = kelime;
            //            $("#txtAra2")[0].value = kelime;
            //            var resim = document.querySelector('input[name="optradio"]:checked').value;
            //            PageMethods.Listele(kelime, $("#hdnSatir")[0].value, $("#aktiflik")[0].value, pTipler, resim, OnSucceed, OnFailed);
            var resim = document.querySelector('input[name="radio-inline-left"]:checked').value;
            PageMethods.Listele($("#txtAra")[0].value, "0", $("#aktiflik")[0].value, "", resim, OnSucceed, OnFailed);
            return false;

            function OnSucceed(tablo) {
                //                $(".yukle").html('');
                if (tablo.tablo != "") {
                    $("#thmListe").append(tablo.tablo);
                    //                    $("#hdnSatir")[0].value = tablo.satir;
                    //                    $("#txtAra").blur();
                    //                    $("#txtAra2").blur();
                    $("#thmListe").focus();
                    //                    document.getElementById('alert').style.display = "none";
                    //                    $('#sayilar').find('p').html('Toplam personel sayısı: ' + tablo.toplamKayit + ' <br>Görüntülenen personel sayısı: ' + tablo.satir);
                    //                    document.getElementById('sayilar').style.display = "block";

                    //                    var gir = false;
                    //                    if (alansinifi != null)
                    //                        gir = true;

                    //                    var x = document.getElementById("thmListe").querySelectorAll(".alan");
                    //                    for (var i = 0; i < x.length; i++) {
                    //                        var timeout;
                    //                        var lastTap = 0;
                    //                        x[i].addEventListener("touchend", function (event) {
                    //                            var currentTime = new Date().getTime();
                    //                            var tapLength = currentTime - lastTap;
                    //                            clearTimeout(timeout);
                    //                            if (tapLength < 500 && tapLength > 0) {
                    //                                DetayaGit(this.id.substring(4), kelime, $("#aktiflik")[0].value, pTipler, resim);
                    //                                event.preventDefault();
                    //                            } else {
                    //                                timeout = setTimeout(function () {
                    //                                    clearTimeout(timeout);
                    //                                }, 500);
                    //                            }
                    //                            lastTap = currentTime;
                    //                        });
                    //                        if (gir)
                    //                            x[i].setAttribute("class", alansinifi);
                    //                    }

                    //                    document.getElementById('menu-toggle-right').style.display = "inline-block";
                }
                else {
                    //                    if (!tablo.yukleme) {
                    //                        $('#alert').find('p').html('Seçtiğiniz kriterlere ait personel bulunmamaktadır.');
                    //                        document.getElementById('alert').style.display = "block";
                    //                        document.getElementById('sayilar').style.display = "none";
                    //                        document.getElementById('menu-toggle-right').style.display = "none";
                    //                    }
                    //                    else
                    //                        $(".yukle").html('<b>Yüklenecek Personel Kalmadı.<b>');
                }

                //                $(".chkPersonel").prop('checked', $(".chkPersonel").prop("checked"));
            }

            function OnFailed(xhr, status) {
                //                $('#alert').find('p').html(xhr.responseText + " " + status);
                //                document.getElementById('alert').style.display = "block";
                //                document.getElementById('sayilar').style.display = "none";
            }
        }
    </script>
</head>
<body class="navbar-top">
    <form id="form1" runat="server">
    <asp:ScriptManager ID="ScriptManager1" runat="server" EnablePageMethods="true" />
    <asp:HiddenField ID="hdnSatir" runat="server" Value="0" />
    <asp:HiddenField ID="hdnKodlar" runat="server" />
    <asp:HiddenField ID="hdnSorgu" runat="server" />
    <!-- Main navbar -->
    <div class="navbar navbar-inverse header-highlight navbar-fixed-top">
        <div class="navbar-header">
            <a class="navbar-brand" href="#"></a>
            <ul class="nav navbar-nav pull-right visible-xs-block">
                <li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i>
                </a></li>
                <li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a>
                </li>
            </ul>
        </div>
        <div class="navbar-collapse collapse" id="navbar-mobile">
            <ul class="nav navbar-nav">
                <li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3">
                </i></a></li>
            </ul>
            <!--        <ul class="nav navbar-nav navbar-left">
                <li>
                    <div class="input-group col-xs-4 col-sm-4 col-md-4" style="padding-left:350px;">
                        <input id="txtAra2" runat="server" type="text" class="form-control input-md " />
                        <span class="input-group-btn">
                            <button class="btn btn-primary btn-md" type="button" id="btnAra" style="margin-top: -30px">
                                <i class="glyphicon glyphicon-search"></i>
                            </button>
                        </span>
                    </div>
                </li>
            </ul>-->
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown dropdown-user"><a class="dropdown-toggle" data-toggle="dropdown">
                    <img src="../App_themes/LTR/assets/images/demo/users/face11.jpg" alt="">
                    <span>Victoria</span> <i class="caret"></i></a>
                    <ul class="dropdown-menu dropdown-menu-right">
                        <li><a href="#"><i class="icon-user-plus"></i>My profile</a></li>
                        <li><a href="#"><i class="icon-coins"></i>My balance</a></li>
                        <li><a href="#"><span class="badge badge-warning pull-right">58</span> <i class="icon-comment-discussion">
                        </i>Messages</a></li>
                        <li class="divider"></li>
                        <li><a href="#"><i class="icon-cog5"></i>Account settings</a></li>
                        <li><a href="#"><i class="icon-switch2"></i>Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <!-- /main navbar -->
    <!-- Page container -->
    <div class="page-container">
        <!-- Page content -->
        <div class="page-content">
            <!-- Main sidebar -->
            <div class="sidebar sidebar-main sidebar-fixed">
                <div class="sidebar-content">
                    <!-- User menu -->
                    <div class="sidebar-user">
                        <div class="category-content">
                            <div class="media">
                                <a href="#" class="media-left">
                                    <img src="../App_themes/LTR/assets/images/demo/users/face11.jpg" class="img-circle img-sm"
                                        alt=""></a>
                                <div class="media-body">
                                    <span class="media-heading text-semibold">Victoria Baker</span>
                                    <div class="text-size-mini text-muted">
                                        <i class="icon-pin text-size-small"></i>&nbsp;Santa Ana, CA
                                    </div>
                                </div>
                                <div class="media-right media-middle">
                                    <ul class="icons-list">
                                        <li><a href="#"><i class="icon-cog3"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /user menu -->
                    <!-- Main navigation -->
                    <div class="sidebar-category sidebar-category-visible">
                        <div class="category-content no-padding">
                            <ul class="navigation navigation-main navigation-accordion">
                                <!-- Main -->
                                <li class="navigation-header"><span>Ana Sayfa</span> <i class="icon-menu" title="Ana Sayfa">
                                </i></li>
                                <li><a href="#"><i class="icon-home4"></i><span>Dashboard</span></a></li>
                                <li><a href="#"><i class="icon-stack2"></i><span>Page layouts</span></a>
                                    <ul>
                                        <li><a href="#">Fixed navbar</a></li>
                                        <li><a href="#">Fixed navbar &amp; sidebar</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- /main navigation -->
                </div>
            </div>
            <!-- /main sidebar -->
            <!-- Main content -->
            <div class="content-wrapper">
                <!-- Page header -->
                <div class="page-header">
                    <div class="page-header-content">
                        <div class="page-title">
                            <h4>
                                <i class="icon-arrow-left52 position-left"></i>Personel Arama<%--<span class="text-semibold"></span>--%>
                            </h4>
                        </div>
                        <div class="heading-elements">
                            <div class="heading-btn-group">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /page header -->
                <!-- Content area -->
                <div class="content">
                    <!-- Search field -->
                    <div class="panel panel-flat">
                        <div class="panel-heading">
                            <h5 class="panel-title">
                            </h5>
                            <div class="heading-elements">
                                <ul class="icons-list">
                                    <li><a data-action="collapse"></a></li>
                                    <!-- <li><a data-action="close"></a></li>-->
                                </ul>
                            </div>
                        </div>
                        <div class="panel-body">
                            <form action="#" class="main-search">
                            <div class="input-group content-group">
                                <div class="has-feedback has-feedback-left">
                                    <input type="text" class="form-control input-xlg" placeholder="Aranacak Kelimeyi Giriniz.."
                                        id="txtAra" runat="server">
                                    <div class="form-control-feedback">
                                        <i class="icon-search4 text-muted text-size-base"></i>
                                    </div>
                                </div>
                                <div class="input-group-btn">
                                    <button type="button" class="btn btn-primary btn-xlg" id="btnAra">
                                        <i class="glyphicon glyphicon-search"></i>
                                    </button>
                                </div>
                            </div>
                            </form>
                            <div class="tabbable">
                                <ul class="nav nav-pills nav-justified">
                                    <li class="active"><a href="#large-default-pill1" data-toggle="tab"><i class="icon-search4 position-left">
                                    </i>Gelişmiş Arama</a></li>
                                    <li><a href="#large-default-pill2" data-toggle="tab"><i class="icon-menu7 position-left">
                                    </i>Raporlar</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="large-default-pill1">
                                        <div class="form-group">
                                            <label class="display-block text-semibold">
                                                Aktiflik</label>
                                            <select id="aktiflik" class="bootstrap-select" data-style="btn-primary">
                                                <option value="-1">Tümü</option>
                                                <option value="1" selected="selected">Aktif</option>
                                                <option value="0">Pasif</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="display-block text-semibold">
                                                Resimlilik</label>
                                            <label class="radio-inline">
                                                <input type="radio" name="radio-inline-left" class="styled" checked="checked" value="1">
                                                Resimli
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="radio-inline-left" class="styled" value="2">
                                                Resimsiz
                                            </label>
                                        </div>
                                        <div class="form-group col-xs-12 col-sm-6 col-md-4">
                                            <label class="display-block text-semibold">
                                                Personel Tipleri</label>
                                            <div class="tree-checkbox-hierarchical well ">
                                                <%--border-left-danger border-left-sm--%>
                                                <ul>
                                                    <%--  <li class="folder expanded">Expanded folder with children
                                                        <ul>
                                                            <li class="expanded">Expanded sub-item
                                                                <ul>
                                                                    <li>Menu sub-item</li>
                                                                    <li class="selected">This is a selected item</li>
                                                                </ul>
                                                            </li>
                                                            <li>Collapsed sub-item
                                                                <ul>
                                                                    <li>Sub-item 2.2.1</li>
                                                                    <li>Sub-item 2.2.2</li>
                                                                </ul>
                                                            </li>
                                                        </ul>
                                                    </li>--%>
                                                    <%--<li class="popup" title="Look, a tool tip!">Menu item with key and tooltip</li>
                                                    <li class="folder">Collapsed folder
                                                        <ul>
                                                            <li>Sub-item 1.1</li>
                                                            <li>Sub-item 1.2</li>
                                                        </ul>
                                                    </li>--%>
                                                    <li class="expanded">Kadrolu
                                                        <ul>
                                                            <li class="selected">Sözleşmeli</li>
                                                            <li class="selected">657 Kadrolu-Sigortalı</li>
                                                        </ul>
                                                    </li>
                                                    <li>Geçici</li>
                                                    <li>Şirket</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="large-default-pill2">
                                        <div class="form-group">
                                            <label class="display-block text-semibold">
                                                Raporlar</label>
                                            <ul class="dropdown-menu" style="display: block; position: static; width: 100%; margin-top: 0;
                                                float: none;">                                                
                                                <li class="dropdown-submenu dropdown-submenu-left"><a href="#">Raporlar</a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="#">Rapor1</a></li>                                                      
                                                        <li><a href="#">Rapor2</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /search field -->
                    <!-- Tabs -->
                    <ul class="nav nav-lg nav-tabs nav-tabs-bottom search-results-tabs">
                        <li class="active"><a href="#"><i class="icon-people position-left"></i>Personel</a></li>
                    </ul>
                    <!-- /tabs -->
                    <!-- Search results -->
                    <div class="content-group">
                        <p class="text-muted text-size-small content-group">
                            Bilgi sayılar</p>
                        <div class="search-results-list content-group">
                            <div class="row" id="thmListe">
                                <%-- <div class="col-lg-3 col-sm-6">
                                    <div class="thumbnail">
                                        <div class="panel-heading">
                                            <h6 class="panel-title">
                                            </h6>
                                            <div class="heading-elements">
                                                <form class="heading-form" action="#">
                                                <div class="form-group">
                                                    <label class="checkbox-inline checkbox-right">
                                                        <input type="checkbox" class="styled" checked="checked">
                                                        Seç
                                                    </label>
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                        <div class="thumb">
                                            <img src="../App_themes/LTR/assets/images/demo/flat/12.png" alt="">
                                            <!--  <div class="caption-overflow">
                                                <span><a href="../App_themes/LTR/assets/images/demo/flat/12.png" class="btn bg-teal-300 btn-rounded btn-icon"
                                                    data-popup="lightbox"><i class="icon-zoomin3"></i></a><a href="#" class="btn bg-teal-300 btn-rounded btn-icon">
                                                        <i class="icon-link"></i></a></span>
                                            </div>-->
                                        </div>
                                        <div class="caption">
                                            <h6 class="text-semibold no-margin">
                                                İsim <small class="display-block">Unvan</small> <small class="display-block">Personel
                                                    Tipi</small> <small class="display-block">Birim</small>
                                            </h6>
                                        </div>
                                    </div>
                                </div>--%>
                            </div>
                        </div>
                    </div>
                    <!-- /search results -->
                </div>
                <!-- /content area -->
            </div>
            <!-- /main content -->
        </div>
        <!-- /page content -->
    </div>
    <!-- /page container -->
    </form>
</body>
</html>
