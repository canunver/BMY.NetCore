﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelSorgu.aspx.cs"
    Inherits="InsanKaynaklari.PersonelSorgu" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Personel Bilgi</title>
    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
    <script type="text/javascript">
        var OrgBirimDoldur = function (node) {
            var orgBirim = { ozellikAra: false, yetkiliOlduguMuhasebeBirim: hdnYetkiliBirim.value };
            nodeLoadOrgBirimParam(node, orgBirim);
        };
        var birimRenderer = function (value) {
            if (hdnBirimKod.value == value)
                return hdnBirimAd.value;
            else
                return "";
        };
        var unvanRenderer = function (value) {
            var r = storeUnvan.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.UnvanAd;
        };

        var kadroDereceRenderer = function (value) {
            var r = storeKadroDerece.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.DereceAd;
        };

        var personelTipRenderer = function (value) {
            var r = personelTipStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.ad;
        };
    </script>
</head>
<body>
    <form id="Form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnYetkiliBirim" runat="server" />
    <ext:Hidden ID="hdnBirimKod" runat="server" />
    <ext:Hidden ID="hdnBirimAd" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:ArrayReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="ADSOYAD" />
                    <ext:RecordField Name="TCKIMLIKNO" />
                    <ext:RecordField Name="SICILNO" />
                    <ext:RecordField Name="BIRIM" />
                    <ext:RecordField Name="UNVAN" />
                    <ext:RecordField Name="KADRODERECE" />
                    <ext:RecordField Name="KADROTARIHI" />
                    <ext:RecordField Name="KADRODURUMU" />
                    <ext:RecordField Name="PERSONELTUR" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeUnvan">
        <Reader>
            <ext:JsonReader IDProperty="UnvanKod">
                <Fields>
                    <ext:RecordField Name="UnvanKod" />
                    <ext:RecordField Name="UnvanAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeKadroDerece">
        <Reader>
            <ext:JsonReader IDProperty="DereceKod">
                <Fields>
                    <ext:RecordField Name="DereceKod" />
                    <ext:RecordField Name="DereceAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center>
                    <ext:Panel ID="pnlSol" runat="server" Title="<%$Resources:InsanKaynaklari,FRMPAB035%>"
                        Width="230" Collapsed="false" AutoScroll="true">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server">
                                <Items>
                                    <ext:ToolbarFill ID="ToolbarFill1" runat="server" />
                                    <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPBI003%>"
                                        Icon="ApplicationGo">
                                        <DirectEvents>
                                            <Click OnEvent="PersonelListele">
                                                <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="solTaraf" runat="server">
                                <North Split="true">
                                    <ext:FormPanel ID="FormPanel1" runat="server" Height="90" LabelWidth="50" Layout="AnchorLayout"
                                        Frame="false" Header="false" Border="false" Padding="5">
                                        <Items>
                                   <%--         <ext:FitLayout ID="FitLayout" runat="server">
                                                <Items>--%>
                                                    <ext:TextField runat="server" ID="txtGenelSorgu" FieldLabel="Arama" AnchorHorizontal="97%"
                                                        TabIndex="1" />
                                                    <ext:DropDownField ID="ddlBirim" runat="server" Editable="false" TriggerIcon="Ellipsis"
                                                        Mode="ValueText" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>" AnchorHorizontal="97%">
                                                        <Triggers>
                                                            <ext:FieldTrigger Icon="Clear" />
                                                        </Triggers>
                                                        <Listeners>
                                                            <TriggerClick Handler="if (index == 0) { this.clearValue(); }" />
                                                        </Listeners>
                                                        <Component>
                                                            <ext:Panel ID="Panel5" runat="server" Width="400">
                                                                <Items>
                                                                    <ext:TreePanel ID="trpBirim" runat="server" Height="250" AutoWidth="true" AutoScroll="true"
                                                                        Border="false" RootVisible="false">
                                                                        <Root>
                                                                            <ext:AsyncTreeNode NodeID="0" Expanded="true" Icon="Note" />
                                                                        </Root>
                                                                        <Listeners>
                                                                            <Click Handler="#{ddlBirim}.setValue(node.id, node.text, false);#{hdnBirimKod}.setValue(node.id);#{hdnBirimAd}.setValue(node.text); #{ddlBirim}.collapse();" />
                                                                        </Listeners>
                                                                    </ext:TreePanel>
                                                                </Items>
                                                            </ext:Panel>
                                                        </Component>
                                                    </ext:DropDownField>
                                                    <ext:ComboBox ID="cmbUnvan" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                        ForceSelection="true" StoreID="storeUnvan" DisplayField="UnvanAd" ValueField="UnvanKod"
                                                        AnchorHorizontal="97%" FieldLabel="Unvan" />
                                                    <%--      <ext:PropertyGrid ID="pgFiltre" runat="server" Border="false" HideHeaders="true">
                                                        <Source>
                                                            <ext:PropertyGridParameter Name="birim" DisplayName="<%$ Resources:InsanKaynaklari,FRMPRM026%>">
                                                                <Renderer Fn="birimRenderer" />
                                                                <Editor>
                                                                    <ext:DropDownField ID="ddlBirim" runat="server" Editable="false" TriggerIcon="Ellipsis"
                                                                        Mode="ValueText">
                                                                        <Triggers>
                                                                            <ext:FieldTrigger Icon="Clear" />
                                                                        </Triggers>
                                                                        <Listeners>
                                                                            <TriggerClick Handler="if (index == 0) { this.clearValue(); }" />
                                                                        </Listeners>
                                                                        <Component>
                                                                            <ext:Panel ID="Panel5" runat="server" Width="400">
                                                                                <Items>
                                                                                    <ext:TreePanel ID="trpBirim" runat="server" Height="250" AutoWidth="true" AutoScroll="true"
                                                                                        Border="false" RootVisible="false">
                                                                                        <Root>
                                                                                            <ext:AsyncTreeNode NodeID="0" Expanded="true" Icon="Note" />
                                                                                        </Root>
                                                                                        <Listeners>
                                                                                            <Click Handler="#{ddlBirim}.setValue(node.id, node.text, false);#{hdnBirimKod}.setValue(node.id);#{hdnBirimAd}.setValue(node.text); #{ddlBirim}.collapse();" />
                                                                                        </Listeners>
                                                                                    </ext:TreePanel>
                                                                                </Items>
                                                                            </ext:Panel>
                                                                        </Component>
                                                                    </ext:DropDownField>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                                                      <ext:PropertyGridParameter Name="tcKimlikNo" DisplayName="<%$ Resources:InsanKaynaklari,FRMPKS001%>">
                                                                <Editor>
                                                                    <ext:TextField runat="server" ID="txtTCKimlikNo">
                                                                    </ext:TextField>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="sicilNo" DisplayName="Sicil No">
                                                                <Editor>
                                                                    <ext:TextField runat="server" ID="txtsicilNo">
                                                                    </ext:TextField>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="ad" DisplayName="<%$ Resources:InsanKaynaklari,FRMPAB021%>">
                                                                <Editor>
                                                                    <ext:TextField runat="server" ID="txtAd">
                                                                    </ext:TextField>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                            <ext:PropertyGridParameter Name="soyad" DisplayName="<%$ Resources:InsanKaynaklari,FRMPAB022%>">
                                                                <Editor>
                                                                    <ext:TextField runat="server" ID="txtSoyad">
                                                                    </ext:TextField>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>                                                            
                                                            <ext:PropertyGridParameter Name="kadroDerece" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD020 %>">
                                                                <Renderer Fn="kadroDereceRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="cmbKadroDerece" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                                        ForceSelection="true" StoreID="storeKadroDerece" DisplayField="DereceAd" ValueField="DereceKod" />
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                    <ext:PropertyGridParameter Name="unvan" DisplayName="<%$ Resources:InsanKaynaklari, FRMKAD019 %>">
                                                        <renderer fn="unvanRenderer" />
                                                        <editor>
                                                                    <ext:ComboBox ID="cmbUnvan" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                                                        ForceSelection="true" StoreID="storeUnvan" DisplayField="UnvanAd" ValueField="UnvanKod"
                                                                        ListWidth="250" />
                                                                </editor>
                                                    </ext:PropertyGridParameter>
                                                     <ext:PropertyGridParameter Name="personelTip" DisplayName="Personel Tip">
                                                                <Renderer Fn="personelTipRenderer" />
                                                                <Editor>
                                                                    <ext:ComboBox ID="cmbPersonelTip" runat="server" Editable="true" TypeAhead="true"
                                                                        Mode="Local" ForceSelection="true" SelectOnFocus="true" DisplayField="ad" ValueField="kod"
                                                                        Width="200px">
                                                                        <Store>
                                                                            <ext:Store ID="personelTipStore" runat="server">
                                                                                <Reader>
                                                                                    <ext:JsonReader IDProperty="kod">
                                                                                        <Fields>
                                                                                            <ext:RecordField Name="kod" Type="Int" />
                                                                                            <ext:RecordField Name="ad" />
                                                                                        </Fields>
                                                                                    </ext:JsonReader>
                                                                                </Reader>
                                                                            </ext:Store>
                                                                        </Store>
                                                                    </ext:ComboBox>
                                                                </Editor>
                                                            </ext:PropertyGridParameter>
                                                    <ext:PropertyGridParameter Name="genelSorgu" DisplayName="Genel Sorgu">
                                                        <editor>
                                                                    <ext:TextField runat="server" ID="txtGenelSorgu">
                                                                    </ext:TextField>
                                                                </editor>
                                                    </ext:PropertyGridParameter>
                                                    </Source>
                                                    <listeners>
                                                            <Render Handler="function() { this.getStore().sortInfo = undefined; this.getColumnModel().config[0].sortable = false;this.getColumnModel().config[1].sortable = false;}" />
                                                            <SortChange Handler="this.getStore().sortInfo = undefined;" />
                                                        </listeners>
                                                    <view>
                                                            <ext:GridView ID="GridView1" ForceFit="true" runat="server" />
                                                        </view>
                                                    </ext:PropertyGrid>
                                                </Items>
                                            </ext:FitLayout>--%>
                                        </Items>
                                    </ext:FormPanel>
                                </North>
                                <Center>
                                    <ext:Panel ID="Panel1" runat="server" Border="false">
                                        <Items>
                                            <ext:FitLayout ID="fitLayout3" runat="server">
                                                <Items>
                                                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                                        StoreID="ListeStore" Layout="FitLayout" Width="350" AutoExpandColumn="ADSOYAD"
                                                        Border="false">
                                                        <ColumnModel ID="ColumnModel1" runat="server">
                                                            <Columns>
                                                                <ext:Column ColumnID="TCKIMLIKNO" DataIndex="TCKIMLIKNO" Header="TC Kimlik No" />
                                                                <ext:Column ColumnID="SICILNO" DataIndex="SICILNO" Header="Sicil No" />
                                                                <ext:Column ColumnID="ADSOYAD" DataIndex="ADSOYAD" Header="<%$Resources:InsanKaynaklari,FRMPAB034%>" />
                                                                <ext:Column ColumnID="BIRIM" DataIndex="BIRIM" Header="Birim" />
                                                                <ext:Column ColumnID="PERSONELTUR" DataIndex="PERSONELTUR" Header="Personel Tür" />
                                                                <ext:Column ColumnID="UNVAN" DataIndex="UNVAN" Header="Unvan" />
                                                                <ext:Column ColumnID="KADRODERECE" DataIndex="KADRODERECE" Header="Kadro Derecesi" />
                                                                <ext:Column ColumnID="KADROTARIHI" DataIndex="KADROTARIHI" Header="Kadro Tarihi"
                                                                    Hidden="true" />
                                                                <ext:Column ColumnID="KADRODURUMU" DataIndex="KADRODURUMU" Header="Kadro Durumu"
                                                                    Hidden="true" />
                                                            </Columns>
                                                        </ColumnModel>
                                                        <SelectionModel>
                                                            <ext:CheckboxSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                                                <DirectEvents>
                                                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                                                        <ExtraParams>
                                                                            <ext:Parameter Name="KOD" Value="this.getSelected().data.KOD" Mode="Raw" />
                                                                            <ext:Parameter Name="ADSOYAD" Value="this.getSelected().data.ADSOYAD" Mode="Raw" />
                                                                        </ExtraParams>
                                                                    </RowSelect>
                                                                </DirectEvents>
                                                            </ext:CheckboxSelectionModel>
                                                        </SelectionModel>
                                                        <BottomBar>
                                                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="250" HideRefresh="true">
                                                            </ext:PagingToolbar>
                                                        </BottomBar>
                                                    </ext:GridPanel>
                                                </Items>
                                            </ext:FitLayout>
                                        </Items>
                                    </ext:Panel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
