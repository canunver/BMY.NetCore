﻿using System;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    /// <summary>
    /// PersonelHizliBilgi Sınıfı
    /// </summary>
    public partial class PersonelHizliBilgi : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnKod.Value = (Request.QueryString["personelKod"] + "").Trim();

            //personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnAdres.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                Listele(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel Hızlı bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel kod</param>
        public void Listele(int kod)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            try
            {
                ObjectArray list = servisIKY.PersonelListele(kullanan, new TNS.IKY.Personel { kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), hizliBilgi = true, tarihce = true }, true, false);
                if (list.ObjeSayisi > 0)
                {
                    TNS.IKY.Personel d = (TNS.IKY.Personel)list.objeler[0];
                    lblAd.Text = d.AD;
                    lblSoyad.Text = d.SOYAD;
                    lblSicil.Text = d.sicilNo;
                    lblTC.Text = d.TCKIMLIKNO;
                    lblCep.Text = d.iletisim.cepTelefon;
                    lblDahili.Text = d.iletisim.isTelefon;
                    lblEposta.Text = d.iletisim.eposta;
                    lblKurumaBasTar.Text = d.kurumaBaslamaTarihi.ToString();
                    if (d.kadro != null)
                    {
                        lblKadroDerece.Text = d.kadro.kadroDerece + "/" + d.kadro.emekliyeEsasEkGosterge;
                        lblKazanilmisD.Text = d.kadro.kazanilmisHakDerece + "/" + d.kadro.kazanilmisEkGosterge;
                        lblEmekliD.Text = d.kadro.emekliyeEsasDerece + "/" + d.kadro.emekliyeEsasEkGosterge;
                        lblHPersonelTur.Text = d.kadro.personelTipAd;
                        lblHUnvan.Text = d.kadro.unvanAd;
                        lblBirim.Text = d.kadro.birimAd;
                        lblGorevYeri.Text = d.kadro.gorevBirimAd;
                        lblVekaletUnvan.Text = d.kadro.vekilUnvanAd;
                    }
                }
                else
                {
                    GenelIslemler.MesajKutusu(this, list.sonuc.hataStr);
                    return;
                }
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu(this, ex.Message);
                return;
            }
        }

        protected void Yenile(object sender, EventArgs e)
        {
            Listele(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
        }
    }
}
