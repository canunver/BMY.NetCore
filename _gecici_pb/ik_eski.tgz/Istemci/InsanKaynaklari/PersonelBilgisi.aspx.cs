﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS.KYM;
using TNS.IKY;
using TNS;
using System.Web.UI.HtmlControls;

namespace InsanKaynaklari
{
    public partial class PersonelBilgisi : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Kullanici kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false);
            string tcKimlikNo = kullanan.mernis;
            if (!string.IsNullOrEmpty(tcKimlikNo))
            {
                IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
                TNS.IKY.Personel p = new TNS.IKY.Personel();
                p.tcKimlikNo = tcKimlikNo;

                ObjectArray liste = servisIKY.PersonelListele(kullanan, p, true, false);
                if (liste.sonuc.islemSonuc && liste.objeler.Count == 1)
                {
                    //Personel resim göster
                    imgPersonelResim.ImageUrl = p.resimYol;

                    p = (TNS.IKY.Personel)liste[0];
                    //string unvanBirim = "Unvanı : " + p.unvanAd;
                    //string isTel = "İş Telefonu : " + p.isTelefon;

                    //Personel bilgi göster
                    string content = string.Format("<b><a href='PersonelBilgi.aspx?i=" + p.kod + "' target='_parent'>{0} {1}</a></b>", p.ad, p.soyad);
                    //if (!string.IsNullOrEmpty(unvanBirim)) content += string.Format("<p>{0}</p>", unvanBirim);
                    //if (!string.IsNullOrEmpty(isTel)) content += string.Format("<p>{0}</p>", isTel);
                    pnlUstBilgi.Update(content);
                }
            }
        }        
    }

    public class BE_PersonelBilgi : TNS.KYM.IBilgiEkran
    {

        public string BilgiUret(Kullanici kullanan)
        {
            return "";
        }
    }
}