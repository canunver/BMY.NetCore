﻿<%@ Page Language="C#" CodeBehind="PersonelIzinDevirTab.aspx.cs" Inherits="InsanKaynaklari.PersonelIzinDevirTab" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        var KomutCalistir = function (command, record, row) {
            Ext1.Msg.confirm("Uyarı", "Devir bilgisi silinecek. Onaylıyor musunuz?",
                function (btn) {
                    if (btn == "yes") {
                        Ext1.net.DirectMethods.DevirSil(record.data.kod, record.data.yil);
                    }
                });
        };

        function GridSatirEkle(grid, satirSayi) {
            try {
                var rowIndex = 0;
                for (var i = 0; i < satirSayi; i++) {
                    if (i == 0)
                        rowIndex = grid.addRecord();
                    else
                        grid.addRecord();
                }
                grid.getView().focusRow(rowIndex);
            } catch (e) {
            }
        }
    </script>
</head>
<body>
    <form id="form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnPersonelKod" runat="server" />
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel ID="Panel1" runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <Items>
                    <ext:GridPanel ID="grdListe" runat="server" Height="700">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar3" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                        Icon="Disk">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <ExtraParams>
                                                    <ext:Parameter Name="ListeBilgileri" Value="Ext1.util.JSON.encode(#{grdListe}.getRowsValues({dirtyRowsOnly: true}))"
                                                        Mode="Raw" />
                                                </ExtraParams>
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Store>
                            <ext:Store ID="ListeStore" runat="server">
                                <Reader>
                                    <ext:JsonReader IDProperty="kod">
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="personelKod" Type="Int" />
                                            <ext:RecordField Name="yil" Type="Int" />
                                            <ext:RecordField Name="yilAd" Type="String" />
                                            <ext:RecordField Name="devreden" Type="Int" />
                                            <ext:RecordField Name="yilici" Type="Int"/>
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <ColumnModel>
                            <Columns>
                                <ext:CommandColumn Width="30">
                                    <Commands>
                                        <ext:GridCommand Icon="Delete" CommandName="Sil" ToolTip-Text="Devir Sil." />
                                    </Commands>
                                </ext:CommandColumn>
                                <ext:Column ColumnID="yilAd" DataIndex="yilAd" Header="Yıl" />
                                <ext:Column ColumnID="devreden" DataIndex="devreden" Header="Devreden" Align="Right">
                                    <Editor>
                                        <ext:NumberField runat="server" AllowBlank="true" AllowNegative="false" AllowDecimals="false"
                                            SelectOnFocus="true" />
                                    </Editor>
                                </ext:Column>
                                <ext:Column ColumnID="yilici" DataIndex="yilici" Header="Yıl içi" Align="Right">
                                    <Editor>
                                        <ext:NumberField ID="NumberField1" runat="server" AllowBlank="true" AllowNegative="false" AllowDecimals="false"
                                            SelectOnFocus="true" />
                                    </Editor>
                                </ext:Column>
                            </Columns>
                        </ColumnModel>
                        <Listeners>
                            <Command Fn="KomutCalistir" />
                        </Listeners>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
