﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OrtakClass;
using TNS;
using TNS.KYM;
using Ext1.Net;
using TNS.ORG;

namespace InsanKaynaklari
{
    public partial class PersonelKullaniciIslemleri : istemciUzayi.GenelSayfa
    {
        TNS.KYM.IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();
        TNS.IKY.IIKYServis servisPER = TNS.IKY.Arac.Tanimla();
        TNS.ORG.IORGServis servisORG = TNS.ORG.Arac.Tanimla();

        //string denemeTCNO = "14410018098";
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "SGB Kullanıcı İşlemleri";
            //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!Page.IsPostBack)
            {
                hdnTcKimlikNo.Text = Request.QueryString["tcKimlikNo"] + " ";
                GorevleriDoldur();
                KullaniciKontrol();
            }
        }

        private void GorevleriDoldur()
        {
            BirimGenelGorev[] gorevler = servisORG.GenelGorevListele(kullanan, null, true);
            System.Collections.ArrayList al = new System.Collections.ArrayList();
            for (int i = 0; i < gorevler.Length; i++)
            {
                BirimGenelGorev bgg = gorevler[i];
                if (kullanan.YetkiTipiDegeriIceriyorMu("Personel Kullanıcı Görev Listesi", bgg.siraNo.ToString(), false))
                    al.Add(bgg);
            }
            stoGorevler.DataSource = al;
            stoGorevler.DataBind();
        }

        public void btnYeniParolaAta_Click(object sender, DirectEventArgs e)
        {
            Sonuc sonuc = servisKYM.KullaniciyaYeniParolaAta(hdnTcKimlikNo.Value.ToString());
            if (sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr.Trim() == string.Empty ? Resources.InsanKaynaklari.FRMPKL019 : sonuc.bilgiStr);
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }

        public void btnDegistir_Click(object sender, DirectEventArgs e)
        {
            string eskiparola = txtSQBEskiParola.Value != null ? txtSQBEskiParola.Value.ToString() : "";
            string parola = txtSQBYeniParola.Value != null ? txtSQBYeniParola.Value.ToString() : "";
            string parolatekrar = txtSQBYeniParolaTekrar.Value != null ? txtSQBYeniParolaTekrar.Value.ToString() : "";

            if (parola == parolatekrar)
            {
                if (txtSQBKullaniciKodu.Text.Trim() != string.Empty)
                {
                    Kullanici kul = new Kullanici();
                    kul.kullaniciKodu = txtSQBKullaniciKodu.Text.Trim();
                    Sonuc sonuc = servisKYM.ParolaDegistir(kul, eskiparola, parola, parolatekrar);
                    if (sonuc.islemSonuc)
                    {
                        GenelIslemler.MesajKutusu(this, sonuc.bilgiStr.Trim() == string.Empty ? Resources.InsanKaynaklari.FRMPKL019 : sonuc.bilgiStr);
                    }
                    else
                    {
                        GenelIslemler.MesajKutusu(this, sonuc.hataStr);
                    }
                }
                else
                {
                    GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPKL020);
                }
            }
            else
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPKL021);
            }
        }

        public void btnRolSil_Click(object sender, DirectEventArgs e)
        {
            string gridSatirlari = e.ExtraParams["GridSatirlari"];
            List<KisiGorev> kisigorevleri = new List<KisiGorev>();
            if (!string.IsNullOrEmpty(gridSatirlari) && hdnTcKimlikNo.Text != string.Empty)
            {
                Newtonsoft.Json.Linq.JArray ja = JSON.Deserialize<Newtonsoft.Json.Linq.JArray>(gridSatirlari);
                foreach (Newtonsoft.Json.Linq.JObject item in ja)
                {
                    KisiGorev kg = new KisiGorev();
                    kg.orgKod = item.Value<int>("BIRIMKOD");
                    kg.gorevOrgKod = item.Value<int>("ROLKOD");
                    kg.gorevSiraNo = item.Value<int>("ROLSIRANO");
                    kg.tcKimlikNo = hdnTcKimlikNo.Text;//denemeTCNO;
                    kisigorevleri.Add(kg);
                }
                Sonuc sonuc = servisORG.KisiGenelGorevleriSil(kullanan, kisigorevleri.ToArray());
                if (sonuc.islemSonuc)
                {
                    GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);
                    KullaniciYetkiListele();
                }
                else
                {
                    GenelIslemler.MesajKutusu(this, sonuc.hataStr);
                }
            }
        }

        public void btnYeniKullaniciOlustur_Click(object sender, DirectEventArgs e)
        {

            if (cbOneriKullaniciKodu.Text.Trim() != string.Empty)
            {
                Kullanici yeniKullanici = KullaniciOl();
                Sonuc sonuc = servisKYM.KullaniciKaydet(kullanan, yeniKullanici, true);
                if (sonuc.islemSonuc)
                {
                    KullaniciKontrol();
                }
                else
                    GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            }
        }

        private Kullanici KullaniciOl()
        {
            Kullanici yeniKullanici = new Kullanici();
            yeniKullanici.kullaniciKodu = cbOneriKullaniciKodu.Text;
            yeniKullanici.mernis = hdnTcKimlikNo.Text.Trim();

            TNS.IKY.Personel per = new TNS.IKY.Personel();
            per.tcKimlikNo = hdnTcKimlikNo.Text.Trim();
            //***Kullanıcı Bilgileri
            ObjectArray perList = servisPER.PersonelListele(kullanan, per, false, true);
            if (perList.sonuc.islemSonuc)
            {
                if (perList.objeler.Count == 1)
                {
                    per = (TNS.IKY.Personel)perList.objeler[0];
                    yeniKullanici.ad = per.ad;
                    yeniKullanici.soyad = per.soyad;
                    yeniKullanici.unvan = per.unvanAd;
                    yeniKullanici.aktifMi = ENUMAktiflik.AKTIF;
                    yeniKullanici.anaAdi = per.nufus.anaAd;
                    yeniKullanici.babaAdi = per.nufus.babaAd;
                    yeniKullanici.calistigiBirim = per.kadro.gorevBirimAd;
                    yeniKullanici.calistigiKurum = per.kadro.muhasebeKodu.ToString();
                    yeniKullanici.dogumTarihi = per.dogumTarihi;
                    yeniKullanici.kullaniciTipi = new ENUMKullaniciTipi[1];
                    yeniKullanici.kullaniciTipi[0] = ENUMKullaniciTipi.MISAFIR;

                    if (per.cinsiyet == TNS.IKY.ENUMCINSIYET.ERKEK)
                        yeniKullanici.cinsiyet = "E";
                    else if (per.cinsiyet == TNS.IKY.ENUMCINSIYET.KADIN)
                        yeniKullanici.cinsiyet = "K";
                    else
                        yeniKullanici.cinsiyet = "";
                    yeniKullanici.emailAdresi = per.EPOSTA;
                    yeniKullanici.telefon = per.isTelefon;
                    if (string.IsNullOrEmpty(yeniKullanici.telefon)) yeniKullanici.telefon = "Girilmemiş";
                }
            }
            else
            {
                GenelIslemler.MesajKutusu(this, perList.sonuc.hataStr);
            }
            return yeniKullanici;
        }

        private void OneriListele()
        {
            Kullanici kul = new Kullanici();
            TNS.IKY.Personel per = new TNS.IKY.Personel();
            per.tcKimlikNo = hdnTcKimlikNo.Text.Trim();
            //***Kullanıcı Bilgileri
            ObjectArray perList = servisPER.PersonelListele(kullanan, per, false, true);
            if (perList.sonuc.islemSonuc)
            {
                if (perList.objeler.Count == 1)
                {
                    per = (TNS.IKY.Personel)perList.objeler[0];
                    kul.ad = per.ad;
                    kul.soyad = per.soyad;

                    ObjectArray oneriler = servisKYM.KullaniciAdOner(kul);
                    List<object> listOneri = new List<object>();
                    foreach (Kullanici item in oneriler.objeler)
                    {
                        listOneri.Add(new
                        {
                            Text = item.kullaniciKodu,
                            Value = item.kullaniciKodu
                        });
                    }
                    storeOneri.DataSource = listOneri.ToArray();
                    storeOneri.DataBind();
                }
            }

        }

        private void KullaniciKontrol()
        {
            KullaniciVAN kul = servisKYM.KullaniciOku(kullanan, hdnTcKimlikNo.Text);
            PanelGosterGizle(string.IsNullOrWhiteSpace(kul.kullanici.kullaniciKodu));
            //**kullanıcı var****
            if (kul.sonuc.islemSonuc)
            {
                KullaniciBilgiGoster(kul.kullanici);
                KullaniciYetkiListele();
            }
            else
            {
                //GenelIslemler.MesajKutusu(this, kul.sonuc.hataStr);
                OneriListele();
            }
        }

        private void PanelGosterGizle(bool kullaniciyok)
        {
            pnlAna.ActiveIndex = kullaniciyok ? 0 : 1;
            //panelKullaniciVar.Hidden = !kullaniciyok;
            //panelKullaniciYok.Hidden = kullaniciyok;
        }

        private void KullaniciBilgiGoster(Kullanici k)
        {
            hdnMailAdres.Value = k.emailAdresi;
            txtSQBKullaniciKodu.Value = k.kullaniciKodu;
            // txtSQBEskiParola.Value = k.parola;
        }

        private void KullaniciYetkiListele()
        {
            if (hdnTcKimlikNo.Text != string.Empty)
            {
                List<object> yetkiler = new List<object>();
                KisiGorev kg = new KisiGorev();
                kg.tcKimlikNo = hdnTcKimlikNo.Text;//denemeTCNO;
                KisiGorev[] kgList = servisORG.KisiGenelGorevleriListele(kullanan, kg);
                foreach (KisiGorev item in kgList)
                {
                    yetkiler.Add(new
                    {
                        BIRIMKOD = item.orgKod,
                        BIRIMAD = item.orgAd,
                        ROLKOD = item.gorevOrgKod,
                        ROLSIRANO = item.gorevSiraNo,
                        ROLAD = item.gorevAd
                    });
                }
                storeRoller.DataSource = yetkiler.ToArray();
                storeRoller.DataBind();
            }
        }

        public void btnGorevEkle_Click(object sender, DirectEventArgs e)
        {
            string gorevKod = cmbGorevler.SelectedItem.Value;
            if (string.IsNullOrWhiteSpace(gorevKod))
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen görev seçiniz!");
                return;
            }
            string secBirimler = ddlBirim.Value.ToString();
            if (string.IsNullOrWhiteSpace(secBirimler))
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen birim seçiniz!");
                return;
            }

            string[] birimler = secBirimler.Split(',');
            TNS.ORG.Personel[] personeller = new TNS.ORG.Personel[1];
            string hata = "";
            int eklenen = 0;
            foreach (var birimStr in birimler)
            {
                OrganizasyonBirim organizasyonBirim = new OrganizasyonBirim();
                organizasyonBirim.kod = OrtakFonksiyonlar.ConvertToInt(birimStr, 0);
                personeller[0] = new TNS.ORG.Personel();
                personeller[0].tcKimlikNo = hdnTcKimlikNo.Text;
                Sonuc s = servisORG.GenelGorevKisileriEkle(kullanan, organizasyonBirim, BirimGenelGorev.GorevKodBicimindenGenelGoreve(gorevKod), personeller);
                if (!s.islemSonuc)
                {
                    if (hata != "") hata += ", ";
                    hata += s.hataStr;
                }
                else
                    eklenen++;
            }
            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.MesajKutusu("Hata", hata);
            }
            if (eklenen > 0)
                KullaniciKontrol();
        }
    }
}