﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OrtakClass;
using TNS;

namespace InsanKaynaklari
{
    public partial class KadroKontenjanAna : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.FRMKAD004;
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                int personelTur = OrtakFonksiyonlar.ConvertToInt(Request.QueryString.Get("personelTur"), 0);
                panelIslem.AutoLoad.Url = "KadroKontenjan.aspx?menuYok=1&personelTur=" + personelTur;
                panelSorgu.AutoLoad.Url = "KadroKontenjanSorgu.aspx?menuYok=1&personelTur=" + personelTur;
            }
        }
    }
}