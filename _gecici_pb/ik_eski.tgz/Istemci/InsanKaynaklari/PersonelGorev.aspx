﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.PersonelGorev" CodeBehind="PersonelGorev.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>
        <%= Resources.InsanKaynaklari.Gorevlendirmeler004%></title>
    <script type="text/javascript">
        function satirSecildi(secilenler, satirNo) {
            if (secilenler.selections.items.length > 0) {
                var rec = secilenler.selections.items[secilenler.selections.items.length - 1];
                frmGiris.getForm().loadRecord(rec);
                ddlBirim.setValue(rec.data.birimi, rec.data.birimiAd, false);
            }
        }

        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                    function (btn) {
                        if (btn == "yes") {
                            Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                        }
                    });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };

    </script>
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <ext:Hidden ID="hdnPersonelKod" runat="server" />
        <ext:Hidden ID="hdnKod" runat="server" />
        <ext:Hidden ID="hdnBelgeKod" runat="server" />
        <ext:Store ID="BelgeStore" runat="server">
            <Reader>
                <ext:JsonReader>
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="PKOD" />
                        <ext:RecordField Name="KAYITKOD" />
                        <ext:RecordField Name="TIP" />
                        <ext:RecordField Name="BELGEADI" />
                    </Fields>
                </ext:JsonReader>
            </Reader>
        </ext:Store>
        <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
            <Items>
                <ext:Panel runat="server" Region="Center" Layout="BorderLayout">
                    <TopBar>
                        <ext:Toolbar runat="server">
                            <Items>
                                <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, Gorevlendirmeler009%>"
                                    TabIndex="3" Icon="DatabaseSave">
                                    <DirectEvents>
                                        <Click OnEvent="btnKaydet_Click">
                                            <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, Gorevlendirmeler010%>"
                                                Message="<%$ Resources:InsanKaynaklari, Gorevlendirmeler011%>" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, Gorevlendirmeler012%>" />
                                            <ExtraParams>
                                                <ext:Parameter Name="grdGorevler" Value="Ext1.util.JSON.encode(#{grdGorevler}.getRowsValues())"
                                                    Mode="Raw" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="Button1" runat="server" Icon="Add" Text="Yeni">
                                    <DirectEvents>
                                        <Click OnEvent="btnYeni_Click" />
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="Button2" runat="server" Icon="Delete" Text="Sil">
                                    <DirectEvents>
                                        <Click OnEvent="btnSil_Click" />
                                    </DirectEvents>
                                </ext:Button>
                            </Items>
                        </ext:Toolbar>
                    </TopBar>
                    <Items>
                        <ext:Panel runat="server" Region="West" AutoScroll="true" Width="500" Border="false" Layout="BorderLayout">
                            <Items>
                                <ext:FormPanel runat="server" AutoScroll="true" ID="frmGiris" Padding="5" Region="Center">
                                    <Items>
                                        <ext:NumberField runat="server" ID="txtGorevNo" DataIndex="gorevNo" FieldLabel="Kayıt No" ReadOnly="true" Width="110" />
                                        <ext:ComboBox ID="cmbUnvan" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                            ForceSelection="true" DisplayField="UnvanAd" ValueField="UnvanKod" AnchorHorizontal="97%"
                                            FieldLabel="Unvan" DataIndex="unvanKod">
                                            <Store>
                                                <ext:Store runat="server" ID="storeUnvan">
                                                    <Reader>
                                                        <ext:JsonReader IDProperty="UnvanKod">
                                                            <Fields>
                                                                <ext:RecordField Name="UnvanKod" />
                                                                <ext:RecordField Name="UnvanAd" />
                                                            </Fields>
                                                        </ext:JsonReader>
                                                    </Reader>
                                                </ext:Store>
                                            </Store>
                                        </ext:ComboBox>
                                        <ext:ComboBox runat="server" ID="cmbGorevDurumu" FieldLabel="<%$ Resources:InsanKaynaklari, Gorevlendirmeler017%>"
                                            DisplayField="ad" ValueField="kod" DataIndex="gorevDurumu" AnchorHorizontal="97%">
                                            <Store>
                                                <ext:Store runat="server" ID="stoGorevDurumu">
                                                    <Reader>
                                                        <ext:JsonReader>
                                                            <Fields>
                                                                <ext:RecordField Name="kod" Type="Int" />
                                                                <ext:RecordField Name="ad" Type="String" />
                                                            </Fields>
                                                        </ext:JsonReader>
                                                    </Reader>
                                                </ext:Store>
                                            </Store>
                                        </ext:ComboBox>
                                        <ext:ExtOrgSecim ID="ddlBirim" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>"
                                            AnchorHorizontal="97%" />
                                        <ext:DateField runat="server" ID="txtBaslamaTarihiDT" DataIndex="baslamaTarihiDT"
                                            FieldLabel="<%$ Resources:InsanKaynaklari, Gorevlendirmeler019%>" />
                                        <ext:DateField runat="server" ID="txtBitisTarihiDT" DataIndex="bitisTarihiDT" FieldLabel="<%$ Resources:InsanKaynaklari, Gorevlendirmeler020%>" />
                                        <ext:TextField ID="txtAciklama" runat="server" FieldLabel="Açıklama" AnchorHorizontal="97%" DataIndex="aciklama" />
                                        <ext:TextField ID="txtOnayNo" runat="server" FieldLabel="Onay No" AnchorHorizontal="97%" DataIndex="onayNo" />
                                        <ext:DateField ID="txtOnayTarihi" runat="server" DataIndex="onayTarihiDT" FieldLabel="Onay Tarihi" />
                                    </Items>
                                </ext:FormPanel>
                                <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false" Region="South"
                                    Frame="true" TrackMouseOver="true" StoreID="BelgeStore" HideHeaders="true" Height="130"
                                    AnchorHorizontal="96%" HideLabel="true">
                                    <ColumnModel ID="ColumnModel2" runat="server">
                                        <Columns>
                                            <ext:RowNumbererColumn />
                                            <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Width="250" />
                                            <ext:CommandColumn Width="30">
                                                <Commands>
                                                    <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB037 %>" />
                                                </Commands>
                                            </ext:CommandColumn>
                                            <ext:CommandColumn Width="30">
                                                <Commands>
                                                    <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB038 %>" />
                                                </Commands>
                                            </ext:CommandColumn>
                                        </Columns>
                                    </ColumnModel>
                                    <Listeners>
                                        <Command Fn="KomutCalistir" />
                                    </Listeners>
                                    <SelectionModel>
                                        <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                        </ext:RowSelectionModel>
                                    </SelectionModel>
                                    <TopBar>
                                        <ext:Toolbar runat="server">
                                            <Items>
                                                <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                    ButtonText="Belge Ekle">
                                                    <DirectEvents>
                                                        <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                    </DirectEvents>
                                                </ext:FileUploadField>
                                            </Items>
                                        </ext:Toolbar>
                                    </TopBar>
                                </ext:GridPanel>
                            </Items>
                        </ext:Panel>

                        <ext:GridPanel runat="server" Header="false" Border="true" ID="grdGorevler" ClicksToEdit="1"
                            StripeRows="true" ColumnLines="true" Region="Center">
                            <SelectionModel>
                                <ext:RowSelectionModel runat="server" SingleSelect="true">
                                    <Listeners>
                                        <RowSelect Fn="satirSecildi" />
                                    </Listeners>
                                    <DirectEvents>
                                        <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                            <EventMask ShowMask="true" MinDelay="200" />
                                            <ExtraParams>
                                                <ext:Parameter Name="kod" Value="this.getSelected().data.gorevNo" Mode="Raw" />
                                            </ExtraParams>
                                        </RowSelect>
                                    </DirectEvents>
                                </ext:RowSelectionModel>
                            </SelectionModel>
                            <Store>
                                <ext:Store runat="server" ID="stoGorevler">
                                    <Reader>
                                        <ext:JsonReader>
                                            <Fields>
                                                <ext:RecordField Name="gorevNo" Type="Int" />
                                                <ext:RecordField Name="unvanKod" Type="Int" />
                                                <ext:RecordField Name="unvanAd" Type="String" />
                                                <ext:RecordField Name="gorevDurumu" Type="Int" />
                                                <ext:RecordField Name="gorevDurumuAd" Type="String" />
                                                <ext:RecordField Name="birimi" Type="Int" />
                                                <ext:RecordField Name="birimiAd" Type="String" />
                                                <ext:RecordField Name="baslamaTarihiDT" Type="Date" />
                                                <ext:RecordField Name="bitisTarihiDT" Type="Date" />
                                                <ext:RecordField Name="aciklama" Type="String" />
                                                <ext:RecordField Name="onayNo" Type="String" />
                                                <ext:RecordField Name="onayTarihiDT" Type="Date" />
                                            </Fields>
                                        </ext:JsonReader>
                                    </Reader>
                                </ext:Store>
                            </Store>
                            <ColumnModel>
                                <Columns>
                                    <ext:Column DataIndex="unvanAd" ColumnID="unvanAd" Header="<%$ Resources:InsanKaynaklari, Gorevlendirmeler016%>" />
                                    <ext:Column DataIndex="gorevDurumuAd" ColumnID="gorevDurumuAd" Header="<%$ Resources:InsanKaynaklari, Gorevlendirmeler017%>" />
                                    <ext:Column DataIndex="birimiAd" ColumnID="birimiAd" Header="<%$ Resources:InsanKaynaklari, Gorevlendirmeler018%>" />
                                    <ext:DateColumn DataIndex="baslamaTarihiDT" ColumnID="baslamaTarihiDT" Header="<%$ Resources:InsanKaynaklari, Gorevlendirmeler019%>"
                                        Format="d.m.Y" Width="70" />
                                    <ext:DateColumn DataIndex="bitisTarihiDT" ColumnID="bitisTarihiDT" Header="<%$ Resources:InsanKaynaklari, Gorevlendirmeler020%>"
                                        Format="d.m.Y" Width="70" />
                                </Columns>
                            </ColumnModel>
                        </ext:GridPanel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
    </form>
</body>
</html>
