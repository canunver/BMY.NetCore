﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelKadroOnaysiz.aspx.cs"
    Inherits="InsanKaynaklari.PersonelKadroOnaysiz" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:TabPanel ID="Panel1" runat="server" Border="false" Region="Center">
                <Items>
                    <ext:GridPanel runat="server" ID="gpOnaysizlar" Title="Onaysızlar" StripeRows="true"
                        TrackMouseOver="true" ColumnLines="true" EnableTheming="true">
                        <Store>
                            <ext:Store runat="server" ID="stoOnaysizlar">
                                <Reader>
                                    <ext:JsonReader IDProperty="kod">
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="personelKod" Type="Int" />
                                            <ext:RecordField Name="kadroDurumAd" Type="String" />
                                            <ext:RecordField Name="unvanAd" Type="String" />
                                            <ext:RecordField Name="personelTCKimlikNo" Type="String" />
                                            <ext:RecordField Name="personelAdSoyad" Type="String" />
                                            <ext:RecordField Name="birimAd" Type="String" />
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <ColumnModel>
                            <Columns>
                                <ext:RowNumbererColumn Header="#" />
                                <ext:Column DataIndex="kadroDurumAd" Header="Kayıt Durum" />
                                <ext:Column DataIndex="unvanAd" Header="Unvanı" Width="200" />
                                <ext:Column DataIndex="personelTCKimlikNo" Header="Kimlik No" />
                                <ext:Column DataIndex="personelAdSoyad" Header="Ad Soyad" Width="200" />
                                <ext:Column DataIndex="birimAd" Header="Birimi" Width="300" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel SingleSelect="true">
                            </ext:RowSelectionModel>
                        </SelectionModel>
                    </ext:GridPanel>
                    <ext:GridPanel runat="server" ID="gpTayinBekleyenler" Title="Tayin Bekleyenler" StripeRows="true"
                        TrackMouseOver="true" ColumnLines="true">
                        <TopBar>
                            <ext:Toolbar runat="server">
                                <Items>
                                    <ext:Label runat="server" Text="Tarih:" />
                                    <ext:DateField ID="dfAlisTarih" runat="server" />
                                    <ext:Button ID="btnBirimeAl" runat="server" Text="Birime Al" Icon="Accept">
                                        <DirectEvents>
                                            <Click OnEvent="btnBirimeAl_Click">
                                                <ExtraParams>
                                                    <ext:Parameter Name="satirlar" Mode="Raw" Value="Ext1.util.JSON.encode(gpTayinBekleyenler.getRowsValues({ selectedOnly: true }))" />
                                                </ExtraParams>
                                                <Confirmation ConfirmRequest="true" Message="Seçili kişiyi kendi biriminize almak istiyor musunuz?"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="Lütfen Bekleyiniz.." />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Store>
                            <ext:Store runat="server" ID="stoTayinBekleyenler">
                                <Reader>
                                    <ext:JsonReader IDProperty="kod">
                                        <Fields>
                                            <ext:RecordField Name="kod" Type="Int" />
                                            <ext:RecordField Name="personelKod" Type="Int" />
                                            <ext:RecordField Name="kadroDurumAd" Type="String" />
                                            <ext:RecordField Name="unvanAd" Type="String" />
                                            <ext:RecordField Name="personelTCKimlikNo" Type="String" />
                                            <ext:RecordField Name="personelAdSoyad" Type="String" />
                                            <ext:RecordField Name="birimAd" Type="String" />
                                            <ext:RecordField Name="tayinOlacagiBirimAd" Type="String" />
                                        </Fields>
                                    </ext:JsonReader>
                                </Reader>
                            </ext:Store>
                        </Store>
                        <ColumnModel>
                            <Columns>
                                <ext:RowNumbererColumn Header="#" />
                                <ext:Column DataIndex="kadroDurumAd" Header="Kayıt Durum" />
                                <ext:Column DataIndex="unvanAd" Header="Unvanı" Width="200" />
                                <ext:Column DataIndex="personelTCKimlikNo" Header="Kimlik No" />
                                <ext:Column DataIndex="personelAdSoyad" Header="Ad Soyad" Width="200" />
                                <ext:Column DataIndex="birimAd" Header="Gönderen Birim" Width="300" />
                                <ext:Column DataIndex="tayinOlacagiBirimAd" Header="Alacak Birim" Width="300" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel SingleSelect="true" runat="server" ID="rsTayinBekleyenler">
                            </ext:RowSelectionModel>
                        </SelectionModel>
                    </ext:GridPanel>
                </Items>
            </ext:TabPanel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
