﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="RaporPersonel.aspx.cs"
    Inherits="InsanKaynaklari.RaporPersonel" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">

        function onContainerOver(dz, grid, dd, e, data) {
            if (dd.grid == grid) {
                if (getTargetRow(dd.grid, e) >= 0)
                    return dz.dropAllowed;
            }
            return dz.dropNotAllowed;
        }

        function getTargetRow(grid, e) {
            var t = e.getTarget(grid.view.cellSelector);
            if (t) {
                var rowIndex = grid.view.findRowIndex(t);
                return rowIndex;
            }
            return -1;
        }

        function onContainerDrop(grid, dd, e, data) {
            var satir = getTargetRow(dd.grid, e);
            if (satir < 0) return true;
            Ext1.each(data.selections, function (r) {
                dd.grid.store.remove(r);
            });

            grid.store.insert(satir, data.selections);
            return true;
        }

        function PersonelTipYenile() {
            setTimeout("PersonelTipYenileIc()", 50)
        }

        function PersonelTipYenileIc() {
            Ext1.net.DirectMethods.PersonelTipleriYenile();
        }

        function SayfaAc(adres) {
            window.open(adres, '_blank', 'status=1');
        }

        function PersonelTipDegerOku() {
            var retVal = "";
            for (var i = 0; i < csmPersonelTipCoklu.selections.length; i++) {
                if (retVal != "") retVal += ",";
                retVal += csmPersonelTipCoklu.selections.items[i].data.ad;
            }
            if (csmPersonelTipCoklu.selections.length > 1)
                retVal = "[" + retVal + "]";
            return retVal;
        }

        function PersonelTipKodOku() {
            var retVal = "";
            for (var i = 0; i < csmPersonelTipCoklu.selections.length; i++) {
                if (retVal != "") retVal += ";";
                retVal += csmPersonelTipCoklu.selections.items[i].data.kod;
            }
            return retVal;
        }

        function YerleskeDegerOku() {
            var retVal = "";
            for (var i = 0; i < csmYerleske.selections.length; i++) {
                if (retVal != "") retVal += ",";
                retVal += csmYerleske.selections.items[i].data.ad;
            }
            if (csmYerleske.selections.length > 1)
                retVal = "[" + retVal + "]";
            return retVal;
        }

        function YerleskeKodOku() {
            var retVal = "";
            for (var i = 0; i < csmYerleske.selections.length; i++) {
                if (retVal != "") retVal += ";";
                retVal += csmYerleske.selections.items[i].data.kod;
            }
            return retVal;
        }

        function GridKaydir(tasi) {
            var secililer = grdDinamik.getSelectionModel().getSelections(); //grdDinamik.getRowsValues({ selectedOnly: true });
            for (var i = 0; i < secililer.length; i++) {
                var selectedRecord = secililer[i];
                var index = grdDinamik.store.indexOf(secililer[i]);
                grdDinamik.insert(index, selectedRecord);
            }
        }

        var ayRenderer = function (value) {
            var r = ayStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden runat="server" ID="hdnRaporKod" />
    <ext:Store ID="ayStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="yerleskeStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="ad" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="durumStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="ID">
                <Fields>
                    <ext:RecordField Name="ID" />
                    <ext:RecordField Name="Name" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="siteStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="siteAdi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeKadroDerece">
        <Reader>
            <ext:JsonReader IDProperty="DereceKod">
                <Fields>
                    <ext:RecordField Name="DereceKod" />
                    <ext:RecordField Name="DereceAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center MarginsSummary="104 20 10 20">
                    <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px">
                        <Items>
                            <ext:BorderLayout ID="BorderLayout2" runat="server">
                                <Center>
                                    <ext:FormPanel ID="frmPanel" runat="server" Frame="true" AutoScroll="true" Padding="5"
                                        Title="Rapor Kriter Alanları">
                                        <TopBar>
                                            <ext:Toolbar ID="Toolbar1" runat="server">
                                                <Items>
                                                    <ext:Button ID="btnYazdir" runat="server" Text="Göster" Icon="Printer">
                                                        <DirectEvents>
                                                            <Click OnEvent="btnYazdir_Click">
                                                                <ExtraParams>
                                                                    <ext:Parameter Name="tur" Value="1" Mode="Value" />
                                                                    <ext:Parameter Name="dinamikler" Value="Ext1.util.JSON.encode(#{grdDinamik}.getRowsValues({ selectedOnly: true }))"
                                                                        Mode="Raw" />
                                                                </ExtraParams>
                                                            </Click>
                                                        </DirectEvents>
                                                    </ext:Button>
                                                    <ext:Button ID="btnYazdir2" runat="server" Text="İndir" Icon="PageAdd">
                                                        <DirectEvents>
                                                            <Click OnEvent="btnYazdir_Click" IsUpload="true">
                                                                <ExtraParams>
                                                                    <ext:Parameter Name="tur" Value="2" Mode="Value" />
                                                                    <ext:Parameter Name="dinamikler" Value="Ext1.util.JSON.encode(#{grdDinamik}.getRowsValues({ selectedOnly: true }))"
                                                                        Mode="Raw" />
                                                                </ExtraParams>
                                                            </Click>
                                                        </DirectEvents>
                                                    </ext:Button>
                                                    <ext:Button ID="btnYazdir3" runat="server" Text="İndir (PDF)" Icon="PageKey">
                                                        <DirectEvents>
                                                            <Click OnEvent="btnYazdir_Click" IsUpload="true">
                                                                <ExtraParams>
                                                                    <ext:Parameter Name="tur" Value="3" Mode="Value" />
                                                                    <ext:Parameter Name="dinamikler" Value="Ext1.util.JSON.encode(#{grdDinamik}.getRowsValues({ selectedOnly: true }))"
                                                                        Mode="Raw" />
                                                                </ExtraParams>
                                                            </Click>
                                                        </DirectEvents>
                                                    </ext:Button>
                                                </Items>
                                            </ext:Toolbar>
                                        </TopBar>
                                        <Items>
                                            <ext:CompositeField runat="server" ID="cfBirim" FieldLabel="<%$ Resources:Personel,FRMPRM026%>"
                                                Hidden="true">
                                                <Items>
                                                    <ext:ExtOrgSecim ID="ddlBirim" runat="server" Editable="false" TriggerIcon="Ellipsis"
                                                        Mode="ValueText" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>" Width="400" />
                                                    <ext:Checkbox Checked="true" BoxLabel="Alt Birimli" runat="server" ID="cbAltBirimli" />
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:ComboBox ID="cmbKadroDerece" runat="server" Mode="Local" TriggerAction="All"
                                                FieldLabel="Kadro Derece" Hidden="true" ForceSelection="true" StoreID="storeKadroDerece"
                                                DisplayField="DereceAd" ValueField="DereceKod" />
                                            <ext:TextField ID="txtIslemSira" runat="server" FieldLabel="<%$ Resources:Personel, FRMKAD009 %>"
                                                Hidden="true" Width="227" />
                                            <ext:MultiCombo runat="server" ID="ddlPersonelTipGrup" DisplayField="ad" ValueField="ad"
                                                FieldLabel="Grup" Width="400" SelectionMode="Checkbox" Hidden="true">
                                                <Store>
                                                    <ext:Store ID="stoPersonelTipGrup" runat="server">
                                                        <Reader>
                                                            <ext:JsonReader IDProperty="ad">
                                                                <Fields>
                                                                    <ext:RecordField Name="ad" Type="String" />
                                                                </Fields>
                                                            </ext:JsonReader>
                                                        </Reader>
                                                    </ext:Store>
                                                </Store>
                                                <DirectEvents>
                                                    <Change OnEvent="ddlPersonelTipGrup_Changed">
                                                    </Change>
                                                </DirectEvents>
                                            </ext:MultiCombo>
                                            <ext:ExtCokluSecim runat="server" ID="cmbPersonelTipCoklu" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS079%>"
                                                AnchorHorizontal="97%" MaxWidth="400" SingleSelect="true" Hidden="true" />
                                            <ext:RadioGroup ID="chkYukumlu" runat="server" Anchor="none" Hidden="true" FieldLabel="Yükümlülük"
                                                ColumnsWidths="0.12,0.88">
                                                <Items>
                                                    <ext:Radio runat="server" InputValue="0" BoxLabel="Hepsi" Checked="true" />
                                                    <ext:Radio runat="server" InputValue="1" BoxLabel="Sadece Bakmakla Yükümlü Oldukları" />
                                                </Items>
                                            </ext:RadioGroup>
                                            <ext:DateField ID="txtSonTarih" runat="server" FieldLabel="Son Tarih" Hidden="true">
                                            </ext:DateField>
                                            <ext:GridPanel runat="server" ID="grdDinamik" RowHeight="1" Height="200" Width="400"
                                                FieldLabel="Dinamik Seçim Listesi" Hidden="true" AutoExpandColumn="Baslik" EnableDragDrop="true"
                                                DDGroup="dinamikDDGroup">
                                                <Store>
                                                    <ext:Store runat="server" ID="storeDinamik">
                                                        <Reader>
                                                            <ext:JsonReader IDProperty="Kod">
                                                                <Fields>
                                                                    <ext:RecordField Name="Kod" Type="Int" />
                                                                    <ext:RecordField Name="Baslik" Type="String" />
                                                                    <ext:RecordField Name="Siralama" Type="Int" />
                                                                </Fields>
                                                            </ext:JsonReader>
                                                        </Reader>
                                                    </ext:Store>
                                                </Store>
                                                <ColumnModel>
                                                    <Columns>
                                                        <ext:Column DataIndex="Baslik" ColumnID="Baslik" Header="Başlık" />
                                                    </Columns>
                                                </ColumnModel>
                                                <SelectionModel>
                                                    <ext:CheckboxSelectionModel runat="server">
                                                    </ext:CheckboxSelectionModel>
                                                </SelectionModel>
                                            </ext:GridPanel>
                                            <ext:ComboBox runat="server" Hidden="true" ID="ddlAktiflik" FieldLabel="Personel Aktiflik"
                                                Width="400" SelectedIndex="1" Editable="false">
                                                <Items>
                                                    <ext:ListItem Value="-1" Text="Tümü" />
                                                    <ext:ListItem Value="1" Text="Aktif" />
                                                    <ext:ListItem Value="0" Text="Pasif" />
                                                </Items>
                                            </ext:ComboBox>
                                            <ext:ComboBox runat="server" Hidden="true" ID="ddlSite" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite007%>"
                                                DisplayField="siteAdi" ValueField="kod" StoreID="siteStore" Width="400" Editable="false">
                                            </ext:ComboBox>
                                            <ext:ComboBox runat="server" Hidden="true" ID="ddlDaireBosluk" FieldLabel="Daire"
                                                Width="400" SelectedIndex="0" Editable="false">
                                                <Items>
                                                    <ext:ListItem Value="0" Text="Tümü" />
                                                    <ext:ListItem Value="1" Text="Boş" />
                                                    <ext:ListItem Value="2" Text="Dolu" />
                                                </Items>
                                            </ext:ComboBox>
                                            <ext:SpinnerField Hidden="true" runat="server" ID="spnYilAra" Width="382" FieldLabel="Yıl" />
                                            <ext:ComboBox runat="server" Hidden="true" ID="ddlAyAra" StoreID="ayStore" DisplayField="AD"
                                                ValueField="KOD" FieldLabel="Ay" Width="400" Editable="false">
                                            </ext:ComboBox>
                                            <ext:ExtCokluSecim runat="server" ID="cmpCokluSecim" FieldLabel="İzin Tür" Hidden="true"
                                                Width="400" />
                                            <ext:CompositeField Hidden="true" ID="cmpYilArasi" runat="server" FieldLabel="Süre">
                                                <Items>
                                                    <ext:SpinnerField runat="server" ID="spnYil1" Width="80" MaxValue="9999" MinValue="-1"
                                                        Number="-1" />
                                                    <ext:SpinnerField runat="server" ID="spnYil2" Width="80" MaxValue="9999" MinValue="-1"
                                                        Number="-1" />
                                                </Items>
                                            </ext:CompositeField>
                                            <%--    <ext:MultiCombo runat="server" ID="cmbYemekhane" StoreID="yerleskeStore" DisplayField="ad"
                                                ValueField="kod" Width="400" Hidden="true" FieldLabel="Yerleşke">
                                            </ext:MultiCombo>--%>
                                            <ext:DropDownField ID="ddlYerleske" runat="server" Width="400" Editable="false" FieldLabel="Yerleşke"
                                                TriggerIcon="SimpleArrowDown" Mode="ValueText" Hidden="true">
                                                <Component>
                                                    <ext:GridPanel runat="server" ID="grdYerleske" AutoExpandColumn="ad" Height="350"
                                                        StoreID="yerleskeStore" Width="400">
                                                        <ColumnModel>
                                                            <Columns>
                                                                <ext:Column Header="Tümü" ColumnID="ad" DataIndex="ad" />
                                                            </Columns>
                                                        </ColumnModel>
                                                        <SelectionModel>
                                                            <ext:CheckboxSelectionModel SingleSelect="false" runat="server" ID="csmYerleske">
                                                                <Listeners>
                                                                    <SelectionChange Handler="ddlYerleske.setValue(YerleskeKodOku(), YerleskeDegerOku(), false);" />
                                                                </Listeners>
                                                            </ext:CheckboxSelectionModel>
                                                        </SelectionModel>
                                                    </ext:GridPanel>
                                                </Component>
                                            </ext:DropDownField>
                                            <ext:CompositeField runat="server" ID="cfTarihSorgu" Width="700" Hidden="true" FieldLabel="Tarih">
                                                <Items>
                                                    <ext:DateField runat="server" ID="dfTarihSorgu" />
                                                    <ext:ComboBox runat="server" Editable="false" ID="cbTarihSorgu" Width="150" SelectedIndex="0">
                                                        <Items>
                                                            <ext:ListItem Text="-" Value="0" />
                                                            <ext:ListItem Text="Aktif" Value="10" />
                                                            <ext:ListItem Text="Sonra Başlayanlar" Value="20" />
                                                            <ext:ListItem Text="Önce Başlayanlar" Value="21" />
                                                            <ext:ListItem Text="Sonra Ayrılanlar" Value="30" />
                                                            <ext:ListItem Text="Önce Ayrılanlar" Value="31" />
                                                        </Items>
                                                    </ext:ComboBox>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField runat="server" FieldLabel="Arama" Width="700" Hidden="true" ID="cfArama">
                                                <Items>
                                                    <ext:TextField ID="tfArama" runat="server" Width="400" />
                                                    <ext:Button runat="server" Text="Listele (Resimsiz)" ID="cfAramaResimsiz">
                                                        <DirectEvents>
                                                            <Click OnEvent="tfArama_Ara_Clicked">
                                                                <ExtraParams>
                                                                    <ext:Parameter Name="Resim" Value="0" Mode="Value" />
                                                                </ExtraParams>
                                                            </Click>
                                                        </DirectEvents>
                                                    </ext:Button>
                                                    <ext:Button runat="server" Text="Listele (Resimli)" ID="cfAramaResimli">
                                                        <DirectEvents>
                                                            <Click OnEvent="tfArama_Ara_Clicked">
                                                                <ExtraParams>
                                                                    <ext:Parameter Name="Resim" Value="1" Mode="Value" />
                                                                </ExtraParams>
                                                            </Click>
                                                        </DirectEvents>
                                                    </ext:Button>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:GridPanel runat="server" ID="grdPerList" AnchorHorizontal="95%" MaxHeight="300"
                                                Height="300" Hidden="true">
                                                <Store>
                                                    <ext:Store runat="server" ID="stoPerList">
                                                        <Reader>
                                                            <ext:JsonReader IDProperty="kod">
                                                                <Fields>
                                                                    <ext:RecordField Name="kod" Type="Int" />
                                                                    <ext:RecordField Name="tcKimlikNo" Type="String" />
                                                                    <ext:RecordField Name="ad" Type="String" />
                                                                    <ext:RecordField Name="soyad" Type="String" />
                                                                    <ext:RecordField Name="unvanAd" Type="String" />
                                                                    <ext:RecordField Name="personelTipAd" Type="String" />
                                                                    <ext:RecordField Name="cinsiyetAd" Type="String" />
                                                                    <ext:RecordField Name="resimYol" Type="String" />
                                                                </Fields>
                                                            </ext:JsonReader>
                                                        </Reader>
                                                    </ext:Store>
                                                </Store>
                                                <ColumnModel>
                                                    <Columns>
                                                        <ext:TemplateColumn ColumnID="resimYol" DataIndex="resimYol" Width="80" Hidden="true">
                                                            <Template runat="server">
                                                                <Html>
                                                                    <img style="width: 70px; height: 90px;" src="{resimYol}" />
                                                                </Html>
                                                            </Template>
                                                        </ext:TemplateColumn>
                                                        <ext:Column DataIndex="tcKimlikNo" ColumnID="tcKimlikNo" Header="TC Kimlik" />
                                                        <ext:Column DataIndex="ad" ColumnID="ad" Header="Ad" />
                                                        <ext:Column DataIndex="soyad" ColumnID="soyad" Header="Soyad" />
                                                        <ext:Column DataIndex="unvanAd" ColumnID="unvanAd" Header="Unvan" />
                                                        <ext:Column DataIndex="personelTipAd" ColumnID="personelTipAd" Header="Per. Tür" />
                                                        <ext:Column DataIndex="cinsiyetAd" ColumnID="cinsiyetAd" Header="Cins." />
                                                    </Columns>
                                                </ColumnModel>
                                                <SelectionModel>
                                                    <ext:CheckboxSelectionModel ID="smPerList" runat="server">
                                                    </ext:CheckboxSelectionModel>
                                                </SelectionModel>
                                            </ext:GridPanel>
                                            <ext:ComboBox ID="cmbSiralama" runat="server" FieldLabel="Sıralama" Width="400" ValueField="kod"
                                                DisplayField="ad" Hidden="true" Editable="false">
                                                <Store>
                                                    <ext:Store runat="server" ID="stoSiralama">
                                                        <Reader>
                                                            <ext:JsonReader>
                                                                <Fields>
                                                                    <ext:RecordField Name="kod" Type="Int" />
                                                                    <ext:RecordField Name="ad" Type="String" />
                                                                </Fields>
                                                            </ext:JsonReader>
                                                        </Reader>
                                                    </ext:Store>
                                                </Store>
                                            </ext:ComboBox>
                                        </Items>
                                    </ext:FormPanel>
                                </Center>
                                <West Split="true">
                                    <ext:TreePanel ID="treListe" runat="server" Width="400" Title="Raporlar" RootVisible="false"
                                        AutoScroll="true">
                                        <Root>
                                            <ext:TreeNode Text="Elma" NodeID="GR000">
                                                <Nodes>
                                                    <ext:TreeNode Text="Rapor Programı" NodeID="GR001" Hidden="true">
                                                        <Nodes>
                                                            <ext:TreeNode Text="Personel Özlük Listesi" NodeID="IK006" />
                                                            <ext:TreeNode Text="Personel Detaylı Bilgi Listesi" NodeID="IK007" />
                                                            <ext:TreeNode Text="Personel Askerlik Listesi" NodeID="IK003" />
                                                            <ext:TreeNode Text="Personel Dil Listesi" NodeID="IK001" />
                                                            <ext:TreeNode Text="Personel Kurs Listesi" NodeID="IK002" />
                                                            <ext:TreeNode Text="Personel İzin Listesi" NodeID="IK004" />
                                                            <ext:TreeNode Text="Personel Kan Grubu Listesi" NodeID="IK008" />
                                                            <ext:TreeNode Text="Personel Kadro Bilgisi" NodeID="IK011" />
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="Birim Raporları" NodeID="GR002">
                                                        <Nodes>
                                                            <ext:TreeNode Text="Organizasyon Şeması" NodeID="IK012" />
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="Kişisel Raporlar" NodeID="GR003">
                                                        <Nodes>
                                                            <ext:TreeNode Text="Tanıtma Kartı" NodeID="IK045" />
                                                            <ext:TreeNode Text="Aile Listesi" NodeID="IK016" />
                                                            <ext:TreeNode Text="Öğrenim Durum Listesi" NodeID="IK017" />
                                                            <ext:TreeNode Text="Sırtlık Listesi" NodeID="IK041" />
                                                            <ext:TreeNode Text="Soruşturma Bilgisi" NodeID="IK056" />
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="Kadro Raporları" NodeID="GR004">
                                                        <Nodes>
                                                            <ext:TreeNode Text="Dolu-Boş Kadro Listesi" NodeID="IK009" />
                                                            <ext:TreeNode Text="İsimli Kadro Listesi" NodeID="IK013" />
                                                            <ext:TreeNode Text="İsimsiz Kadro Listesi" NodeID="IK014" />
                                                            <ext:TreeNode Text="Kadro Derece Durum Listesi" NodeID="IK015" />
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="İzin/Görev Raporları" NodeID="GR005">
                                                        <Nodes>
                                                            <ext:TreeNode Text="İzin/Görevlendirme (Herkes)" NodeID="IK021" />
                                                            <ext:TreeNode Text="İzin/Görevlendirme (Kullanan)" NodeID="IK021b" />
                                                            <ext:TreeNode Text="İdari Görev" NodeID="IK021a" />
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="Hizmet Raporları" NodeID="GR006">
                                                        <Nodes>
                                                            <ext:TreeNode Text="Kurum Hizmeti Listesi" NodeID="IK031" />
                                                            <ext:TreeNode Text="Kadro Hizmeti Listesi" NodeID="IK046" />
                                                            <ext:TreeNode Text="Kıdem Hizmeti Listesi" NodeID="IK032" />
                                                            <ext:TreeNode Text="Emekli Keseneği Hizmet Belgesi Listesi" NodeID="IK033" />
                                                            <ext:TreeNode Text="İzin Hizmet Belgesi Listesi" NodeID="IK034" />
                                                            <ext:TreeNode Text="Toplam Hizmet Belgesi Listesi" NodeID="IK035" />
                                                            <ext:TreeNode Text="En Son Hizmet Belgesi Listesi" NodeID="IK036" />
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="Terfi Raporları" NodeID="GR007" Hidden="true">
                                                        <Nodes>
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="Unvan Raporları" NodeID="GR008">
                                                        <Nodes>
                                                            <ext:TreeNode Text="Unvan İsim Listesi" NodeID="IK042" />
                                                            <ext:TreeNode Text="Unvan Kadro Dağılımları" NodeID="IK043" />
                                                            <ext:TreeNode Text="Unvan Derece Dağılımı" NodeID="IK044" />
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="Dinamik Rapor Listesi" NodeID="GR009">
                                                        <Nodes>
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="İstatistiki Raporlar" NodeID="GR010">
                                                        <Nodes>
                                                            <ext:TreeNode Text="Unvan ve Personel Grubuna Göre Dağılım" NodeID="IK101" />
                                                            <ext:TreeNode Text="Hrc. Birimi ve Personel Tipine Göre Dağılım" NodeID="IK102" />
                                                            <ext:TreeNode Text="Öğrenim Genel Durumu Dağılımı" NodeID="IK022" />
                                                            <ext:TreeNode Text="Personel Genel Durumu Dağılımı" NodeID="GR0101">
                                                                <Nodes>
                                                                    <ext:TreeNode Text="Cinsiyete Göre Dağılım" NodeID="IK023" />
                                                                    <ext:TreeNode Text="Evlilik Durumuna Göre Dağılım" NodeID="IK037" />
                                                                    <ext:TreeNode Text="Çocuk Sayısına Göre Dağılım" NodeID="IK038" />
                                                                </Nodes>
                                                            </ext:TreeNode>
                                                            <ext:TreeNode Text="Personel Türlerine Göre Dağılım" NodeID="IK024" />
                                                            <ext:TreeNode Text="Yaş Genel Durum Dağılımı" NodeID="IK025" />
                                                            <ext:TreeNode Text="Dil Durumuna Göre Dağılım" NodeID="IK026" />
                                                            <ext:TreeNode Text="Hizmet Genel Durumu Dağılımı" NodeID="GR0102">
                                                                <Nodes>
                                                                    <ext:TreeNode Text="Kıdeme Göre" NodeID="IK027" />
                                                                    <ext:TreeNode Text="Kurum Hizmetine Göre" NodeID="IK039" />
                                                                    <ext:TreeNode Text="Emeklilik Hizmetine Göre" NodeID="IK040" />
                                                                </Nodes>
                                                            </ext:TreeNode>
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                    <ext:TreeNode Text="Diğer Raporlar" NodeID="GR011">
                                                        <Nodes>
                                                            <ext:TreeNode Text="Gider Listesi" NodeID="IK054" />
                                                            <ext:TreeNode Text="Personel Kart Listesi" NodeID="IK028" />
                                                            <ext:TreeNode Text="Teslim Edilmeyen Kart Listesi" NodeID="IK029" />
                                                            <ext:TreeNode Text="Kayıp Kart Listesi" NodeID="IK030" />
                                                            <ext:TreeNode Text="Lojmanda Oturanlar Listesi" NodeID="IK047" />
                                                            <ext:TreeNode Text="Lojmanda Oturanlar Listesi (Süreli)" NodeID="IK051" />
                                                            <ext:TreeNode Text="Lojman Dolu Boş Daire Listesi" NodeID="IK048" />
                                                            <ext:TreeNode Text="Lojman Değişiklik Listesi" NodeID="IK050" />
                                                            <ext:TreeNode Text="Lojman Değişiklik Listesi Gruplu" NodeID="IK052" />
                                                            <ext:TreeNode Text="Lojman Rezervasyon Listesi" NodeID="IK053" />
                                                        </Nodes>
                                                    </ext:TreeNode>
                                                </Nodes>
                                            </ext:TreeNode>
                                        </Root>
                                        <DirectEvents>
                                            <Click OnEvent="SatirSecildi">
                                                <EventMask ShowMask="false" Msg="Lütfen bekleyin..." />
                                                <ExtraParams>
                                                    <ext:Parameter Name="secKod" Value="treListe.getSelectionModel().getSelectedNode().id"
                                                        Mode="Raw" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:TreePanel>
                                </West>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <ext:DropZone ID="DropZone1" runat="server" Target="={grdDinamik.view.scroller.dom}"
        Group="dinamikDDGroup" ContainerScroll="true">
        <OnContainerDrop Handler="return onContainerDrop(grdDinamik, source, e, data);" />
        <OnContainerOver Handler="return onContainerOver(this, grdDinamik, source, e, data);" />
    </ext:DropZone>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
