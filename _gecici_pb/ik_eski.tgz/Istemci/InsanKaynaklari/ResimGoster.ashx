﻿<%@ WebHandler Language="C#" CodeBehind="ResimGoster.ashx.cs"  Class="InsanKaynaklari.ResimGoster" %>
