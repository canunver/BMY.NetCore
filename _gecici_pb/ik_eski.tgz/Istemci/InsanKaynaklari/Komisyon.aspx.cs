﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;
using System.Collections.Generic;
using System.IO;
using Aspose.Words;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class Komisyon : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = "Lojman Komisyon";
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                Listele();
                Genel.ImzaTurDoldur(ddlImzaTur, imzaTurStore);
                Genel.KomisyonTipDoldur(ddlTip, tipStore);
            }
        }

        string Kontrol(bool ara)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(hdnKomisyonKod, 0) == 0)
                hata += "Komisyonu seçiniz.";

            return hata;
        }

        protected void Listele()
        {
            ObjectArray oa = servis.KomisyonListele(kullanan, new TNS.IKY.Komisyon());
            stoListe.DataSource = oa.objeler;
            stoListe.DataBind();
        }

        void Kaydet(DirectEventArgs e)
        {
            string imzaBilgileri = e.ExtraParams["imzaBilgileri"];
            if (string.IsNullOrEmpty(imzaBilgileri))
                return;

            Newtonsoft.Json.Linq.JObject[] satirlar = (Newtonsoft.Json.Linq.JObject[])JSON.Deserialize(imzaBilgileri, typeof(Newtonsoft.Json.Linq.JObject[]));
            IKYImza[] im = new IKYImza[satirlar.Length];
            TNS.IKY.Komisyon komisyon = new TNS.IKY.Komisyon();
            komisyon.kararTarihi = Genel.TarihAlaniDegerVer(txtKararTarihi);
            komisyon.toplantiTarihi = Genel.TarihAlaniDegerVer(txtToplantiTarihi);
            komisyon.yonerge = txtYonerge.Text;
            komisyon.kararSayisi = txtKararSayisi.Text;
            komisyon.kod = OrtakFonksiyonlar.ConvertToInt(hdnKomisyonKod.Value, 0);

            int i = 0;
            foreach (Newtonsoft.Json.Linq.JObject satir in satirlar)
            {
                im[i] = new IKYImza();
                im[i].komisyonKod = OrtakFonksiyonlar.ConvertToInt(hdnKomisyonKod.Value, 0);
                im[i].isim = Genel.DegerAlStr(satir, "isim");
                im[i].unvan = Genel.DegerAlStr(satir, "unvan");
                im[i].imzaTur = (ENUMImzaTur)Genel.DegerAlInt(satir, "imzaTurInt");
                im[i].tip = (ENUMKomisyonTip)Genel.DegerAlInt(satir, "tipInt");
                im[i].siraNo = Genel.DegerAlInt(satir, "siraNo");
                i++;
            }

            komisyon.imzalar = im;

            Sonuc sonuc = servis.KomisyonKaydet(kullanan, komisyon);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite003);
                Listele();
                Temizle();
            }
        }

        /// <summary>
        /// Lojman Site kodu olarak verilen değeri, txtkod alanına atar ve okuma işlemini çağırır.
        /// </summary>
        /// <param name="kod">Personel tipi kodu </param>
        [DirectMethod]
        public void Goster(int kod)
        {
            hdnKomisyonKod.Value = kod.ToString();
            Oku();
        }

        protected void Oku()
        {
            TNS.IKY.Komisyon komisyon = new TNS.IKY.Komisyon();
            ObjectVAN ov = servis.KomisyonOku(kullanan, new TNS.IKY.Komisyon { kod = OrtakFonksiyonlar.ConvertToInt(hdnKomisyonKod.Value, 0) });
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                komisyon = (TNS.IKY.Komisyon)ov.o;
                txtKararSayisi.Text = komisyon.kararSayisi;
                txtKararTarihi.Text = komisyon.kararTarihi.ToString();
                txtToplantiTarihi.Text = komisyon.toplantiTarihi.ToString();
                txtYonerge.Text = komisyon.yonerge;
                imzaStore.DataSource = komisyon.imzalar;
                imzaStore.DataBind();
            }
            else if (!ov.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite002);

        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        protected void btnYeni_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        /// <summary>
        /// Yazdir tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
        }

        ///// <summary>
        ///// Yeni tuşuna basılınca çalışacak olay fonksiyon
        ///// </summary>
        ///// <param name="sender">Olayı uyandıran nesne</param>
        ///// <param name="e">Olayın parametresi</param>
        //protected void btnYeni_Click(object sender, DirectEventArgs e)
        //{
        //    Temizle();
        //}

        /// <summary>
        /// Sil tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            if (OrtakFonksiyonlar.ConvertToInt(hdnKomisyonKod.Value, 0) == 0)
                hata = "Komisyon seçilmediği için silemezsiniz.";

            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.BilgiYaz(this, hata);
                return;
            }

            Sonuc sonuc = servis.KomisyonSil(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnKomisyonKod.Value, 0));
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite042);
                Listele();
                Temizle();
            }
        }

        protected void Temizle()
        {
            hdnKomisyonKod.Clear();
            txtKararTarihi.Clear();
            txtKararSayisi.Clear();
            txtToplantiTarihi.Clear();
            txtYonerge.Clear();

            List<object> liste = new List<object>();
            imzaStore.DataSource = liste;
            imzaStore.DataBind();

        }

        protected void stoListe_ReadData(object sender, StoreRefreshDataEventArgs e)
        {
            //if (hdnIlk.Text == "0")
            //{
            //    e.Total = 0;
            //}
            //else
            //{
            //    e.Total = PersonelListele(e.Start, e.Limit);
            //}
            Listele();
        }

        protected void KomisyonKarariYazdir(object sender, DirectEventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKomisyonKod.Value, 0);
            string hata;
            string sonucDosyaad = KomisyonKarariYazdir(kullanan, kod, this.raporSablonYol, "docx", out hata);
            if (!string.IsNullOrWhiteSpace(hata))
                GenelIslemler.BilgiYaz(this, hata);
            else
                OrtakClass.DosyaIslem.DosyaGonderX(sonucDosyaad, "KonutDagitimKomisyonuKarari" + DateTime.Now.Ticks.ToString() + ".docx", true, "docx");
        }

        public string KomisyonKarariYazdir(Kullanici kullanan, int kod, string sablonYol, string ciktiTur, out string hata)
        {
            hata = "";
            if (kod == 0)
            {
                hata = "Lütfen komisyon seçiniz";
                return "";
            }

            TNS.IKY.Komisyon komisyon = new TNS.IKY.Komisyon();

            string sonucDosyaad = Path.Combine(TNS.OrtakFonksiyonlar.GeciciYolBul(), Path.GetRandomFileName()) + "." + ciktiTur;
            string dosyaAd = sablonYol + "\\IKY\\KonutDagitimKomisyonuKarari.docx";

            Document doc = new Document(dosyaAd);
            DocumentBuilder docb = new DocumentBuilder(doc);

            ObjectVAN ov = servis.KomisyonOku(kullanan, new TNS.IKY.Komisyon { kod = OrtakFonksiyonlar.ConvertToInt(hdnKomisyonKod.Value, 0) });
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                komisyon = (TNS.IKY.Komisyon)ov.o;
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "kararTarihi", komisyon.kararTarihi.ToString());
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "kararSayisi", komisyon.kararSayisi);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "yonerge", komisyon.yonerge);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "tarih", "..../" + komisyon.kararTarihi.Ay.ToString() + "/" + komisyon.kararTarihi.Yil.ToString());
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "toplantiTarihi", komisyon.toplantiTarihi.ToString());

                string paraf1 = "";
                string paraf2 = "";
                string olurKisi = "";
                string olurKisiUnvan = "";
                string uye1 = "";
                string uye2 = "";
                string uye3 = "";
                string baskan = "";

                foreach (IKYImza imza in komisyon.imzalar)
                {
                    if (imza.tip == ENUMKomisyonTip.Paraf && imza.siraNo == 1)
                        paraf1 = imza.unvan + "\t: " + imza.isim;
                    if (imza.tip == ENUMKomisyonTip.Paraf && imza.siraNo == 2)
                        paraf2 = imza.unvan + "\t: " + imza.isim;
                    if (imza.tip == ENUMKomisyonTip.Olur)
                    {
                        olurKisi = imza.isim;
                        olurKisiUnvan = imza.unvan;
                    }
                    if (imza.tip == ENUMKomisyonTip.Imza && imza.siraNo == 1)
                        uye1 = imza.isim + "\n" + imza.unvan + "\n" + imza.imzaTurStr;
                    if (imza.tip == ENUMKomisyonTip.Imza && imza.siraNo == 2)
                        uye2 = imza.isim + "\n" + imza.unvan + "\n" + imza.imzaTurStr;
                    if (imza.tip == ENUMKomisyonTip.Imza && imza.siraNo == 3)
                        uye3 = imza.isim + "\n" + imza.unvan + "\n" + imza.imzaTurStr;
                    if (imza.tip == ENUMKomisyonTip.Imza && imza.imzaTur == ENUMImzaTur.Baskan)
                        baskan = imza.isim + "\n" + imza.unvan + "\n" + imza.imzaTurStr;
                }

                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "paraf1", paraf1);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "paraf2", paraf2);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "olurKisi", olurKisi);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "olurKisiUnvan", olurKisiUnvan);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "uye1", uye1);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "uye2", uye2);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "uye3", uye3);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "baskan", baskan);

                ObjectArray ller = servis.PersonelDoluDaireListesi(kullanan, new PersonelLojmani { yil = komisyon.kararTarihi.Yil, ay = komisyon.kararTarihi.Ay, tashisTip = ENUMTahsisTipi.Rezervasyon, yilAyDolu = 2 });
                int siteKod = 0;
                string daireler = "";
                foreach (PersonelLojmani pl in ller.objeler)
                {
                    if (pl.siteKod != siteKod)
                        daireler += pl.siteAdi + " Sitesi;\n";
                    daireler += pl.blokNo + " Blok apartmanının " + pl.daireNo + " kapı numaralı dairesinin " + pl.unvanAd + " " + pl.personelAd + "' e(a) " + pl.lojmanTipiEtiketi + " olarak tahsisi,\n";
                    siteKod = pl.siteKod;
                }

                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "daireler", daireler);
            }
            else if (!ov.sonuc.islemSonuc)
            {
                hata = ov.sonuc.hataStr;
                return "";
            }
            else
            {
                hata = Resources.InsanKaynaklari.LojmanSite002;
                return "";
            }
            if (ciktiTur == "pdf")
                doc.Save(sonucDosyaad, SaveFormat.Pdf);
            else
                doc.Save(sonucDosyaad);
            return sonucDosyaad;
        }
    }
}
