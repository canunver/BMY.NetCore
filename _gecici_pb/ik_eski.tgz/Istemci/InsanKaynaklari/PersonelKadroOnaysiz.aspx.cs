﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS.IKY;
using TNS;
using OrtakClass;
using Ext1.Net;

namespace InsanKaynaklari
{
    public partial class PersonelKadroOnaysiz : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            servisIKY = TNS.IKY.Arac.Tanimla();
            if (!IsPostBack)
            {
                Listele();
            }
        }

        private void Listele()
        {
            int orgKod = GenelIslemlerIstemci.RequestBul(this, "orgKod", 0);
            ObjectVAN ov = servisIKY.OnaysizKayitlar(kullanan, orgKod, false);
            if (ov.sonuc.islemSonuc)
            {
                OnaysizKadroBilgi kb = (OnaysizKadroBilgi)ov.o;
                stoOnaysizlar.DataSource = kb.onaysizlar;
                stoOnaysizlar.DataBind();
                stoTayinBekleyenler.DataSource = kb.tayinBekleyenler;
                stoTayinBekleyenler.DataBind();
            }
            else
                GenelIslemler.MesajKutusu("Hata", ov.sonuc.hataStr);
        }

        protected void btnBirimeAl_Click(object sender, DirectEventArgs e)
        {
            TNSCollection tc = new TNSCollection();
            TNS.IKY.PersonelKadro[] secilenler = (TNS.IKY.PersonelKadro[])Ext.Net.JSON.Deserialize(e.ExtraParams["satirlar"], typeof(TNS.IKY.PersonelKadro[]));
            if (secilenler.Length == 0)
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen Satır Seçiniz!");
                return;
            }
            TNS.IKY.PersonelKadro kadro = secilenler[0];
            ObjectArray oa = servisIKY.PersonelKadroListele(kullanan, kadro, false);
            if (!oa.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu("Hata", oa.sonuc.hataStr);
                return;
            }
            if (oa.ObjeSayisi == 0)
            {
                GenelIslemler.MesajKutusu("Hata", "Kapatılacak kayıt bulunamadı!");
                return;
            }
            kadro = (TNS.IKY.PersonelKadro)oa.objeler[0];
            kadro.eskiKod = kadro.kod;
            kadro.kod = 0;
            kadro.organizasyonKodu = kadro.tayinOlacagiBirim;
            kadro.tayinOlacagiBirim = 0;
            kadro.hizmetSebebiKod = servisIKY.SebepKodBul(ENUMHizmetSebebiNevi.NAKILBASLAMA);
            kadro.ayrilmaGerekcesi = 0;
            kadro.atamaTarihi = new TNSDateTime(dfAlisTarih.SelectedDate);
            kadro.kadroDurum = ENUMKadroDurumu.YENI;
            kadro.ayrilmaNedeni = "";
            Sonuc s = servisIKY.PersonelKadroKaydet(kullanan, kadro);
            if (s.islemSonuc)
            {
                TNS.IKY.PersonelKadro pk = new TNS.IKY.PersonelKadro();
                pk.kod = OrtakFonksiyonlar.ConvertToInt(s.anahtar, 0);
                pk.personelKod = kadro.personelKod;
                s = servisIKY.AtamaOnayBilgileriniGuncelle(kullanan, new TNSCollection(pk), 5);
                if (!s.islemSonuc)
                    GenelIslemler.MesajKutusu("Hata", "Personel için hizmet kaydı oluşturuldu fakat onaylama işlemi yapılamadığından birime alma işlemi tamamlanamadı. Kişiyi bulup ilgili hizmet kaydını yetkili bir kullanıcıya onaylatmanız gerekmektedir." + s.hataStr);
                Listele();
            }
            else
                GenelIslemler.MesajKutusu("Hata", s.hataStr);
        }
    }
}