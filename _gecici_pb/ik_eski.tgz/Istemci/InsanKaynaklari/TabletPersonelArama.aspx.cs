﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;
using System.Web.UI.WebControls;
using System.Web.Services;
using TNS.KYM;
using Borland.Delphi.Units;
using System.Web.UI.HtmlControls;

namespace InsanKaynaklari
{
    public partial class TabletPersonelArama : System.Web.UI.Page
    {
        TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public class ListeSonuc
        {
            public string tablo;
            public int satir;
            public int toplamKayit;
            public bool yukleme = false;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PersonelTurDoldur();
                //txtAra.Focus();
                Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
                RaporDoldur();

                string resimq = (Request.QueryString["resim"] + "").Trim();
                if (resimq == "1")
                    resimli.Checked = true;
                else if (resimq == "2")
                    resimsiz.Checked = true;
                string dondu = (Request.QueryString["dondu"] + "").Trim();
                //txtAra.Value = (Request.QueryString["sorgu"] + "").Trim();
                txtAra2.Value = (Request.QueryString["sorgu"] + "").Trim();
                //hdnSorgu.Value = (Request.QueryString["sorgu"] + "").Trim();
                //string aktiflik = (Request.QueryString["aktiflik"] + "").Trim();
                //string[] s = (Request.QueryString["tipler"] + "").Trim().Split(';');

                //if (s.Length > 1)
                //{
                //pTipler.SelectedIndex = -1;
                //for (int i = 0; i < s.Length - 1; i++)
                //{
                //    foreach (ListItem item in pTipler.Items)
                //    {
                //        if (item.Value == s[i])
                //        {
                //            item.Selected = true;
                //            break;
                //        }
                //    }
                //}
                //}
                //if (dondu == "true")
                //    ClientScript.RegisterStartupScript(GetType(), "Javascript", "javascript:KisiListele(false, 4);", true);

                //Page.ClientScript.RegisterStartupScript(this.GetType(), "key", "KisiListele(false, 4);", true);                     
                //  Ext1.Net.X.AddScript("KisiListele(false, 4);");
                //ScriptManager1.RegisterStartupScript(this.Page, Page.GetType(), "key", "KisiListele(false, -1)", true);
                //PersonelListele();
            }
        }

        //protected void PersonelListele()
        //{
        //    thmListe.Focus();
        //    string[] pTipleri = "";
        //    //foreach (ListItem item in pTipler.Items)
        //    //{
        //    //    if (item.Selected)
        //    //        pTipleri += item.Value + ";";
        //    //}
        //    string resimBilgi = "1";
        //    if (resimsiz != null && resimsiz.Checked)
        //        resimBilgi = resimsiz.Value;

        //    ListeSonuc sonuc = Listele(txtAra2.Value, "0", "", pTipleri, resimBilgi);
        //    thmListe.InnerHtml = sonuc.tablo;
        //    hdnSatir.Value = (sonuc.satir).ToString();
        //}

        [WebMethod]
        public static ListeSonuc Listele(string genelSorgu, string satir, string aktiflik, string[] personelTurleri, string resimBilgi)
        {
            TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            ListeSonuc sonuc = new ListeSonuc();
            TNS.IKY.Personel personel = new TNS.IKY.Personel();
            personel.genelSorgu = genelSorgu;
            personel.kayitBasla = TNS.OrtakFonksiyonlar.ConvertToInt(satir, 0);
            personel.kayitToplam = 30;
            personel.aktifDurumlar = aktiflik;
            //if (string.IsNullOrWhiteSpace(personelTurleri))
            //    personel.personelTipleri = "1";
            //else
            string personelTurler = "";
            if (personelTurleri != null && personelTurleri.Length > 0)
            {
                PersonelTipi pt = new PersonelTipi();
                pt.tipGruplar = personelTurleri;
                pt.aktif = 1;
                ObjectArray ptipler = servisIKY.ListelePersonelTip(null, pt);
                foreach (PersonelTipi item in ptipler.objeler)
                {
                    if (personelTurler != "") personelTurler += ";";
                    personelTurler += item.kod.ToString();
                }
            }
            personel.personelTipleri = personelTurler;
            string tip = "";
            for (int i = 0; i < personelTurleri.Length; i++)
            {
                if (i != 0)
                    tip += ",";
                tip += personelTurleri[i];
            }

            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.ObjectArray liste = servisIKY.PersonelListele(kul, personel, false, true);

            if (!liste.sonuc.islemSonuc)
                throw new Exception(liste.sonuc.hataStr);
            string tablo = "";
            int sonuncuSatir = 0, cnt = 0;
            if (liste.ObjeSayisi > 0)
            {
                int icYukseklik = 210;
                //int disYukseklik = 350;
                //if (resimBilgi == "2")
                //{
                //    icYukseklik = 390;
                //    //disYukseklik = 455;
                //}
                //tablo += "<div class=\"col-xs-12 col-md-12 col-sm-12\">";
                //string dondu = (Request.QueryString["dondu"] + "").Trim();
                //string sutunSinifi = "";
                //if(dondu=="true")
                //    sutunSinifi = "col-xs-12 col-md-4 col-sm-6";
                foreach (TNS.IKY.Personel p in liste.objeler)
                {
                    tablo += " <div class=\"col-xs-12 col-md-3 col-sm-4 alan\" id=\"alan" + p.kod + "\">";
                    tablo += " <div class=\"thumbnail style=\" background-color:#F8F8F8\" ondblclick=\"DetayaGit('" + p.kod + "','" + genelSorgu + "','" + aktiflik + "'" + ",'" + tip + "', '" + resimBilgi + "');\">";
                    if (resimBilgi == "1")
                        tablo += string.Format("<img src='" + p.resimYol + "'  class=\"img-rounded\" style=\"height: 120px;width:90px;\" />");
                    tablo += " <div class=\"caption\">";
                    tablo += "<div class=\"row\" style=\"height:" + icYukseklik + "px; padding: 5px 5px 0 10px; \">";
                    tablo += " <h3>" + p.adSoyad + "</h3>";
                    tablo += " <p > " + p.kadro.unvanAd + "<br>" + p.personelTipAd + "<br>" + p.kadro.birimAd + "</p></div>";
                    tablo += "<div class=\"row\"> ";
                    tablo += " <div class=\"col-xs-6 col-md-6 col-sm-6\"> <label class=\"kisiSinifi\"> <input name=\"type\" type=\"checkbox\" value=\"" + p.kod + "\" class=\"chkPersonel\"/>SEÇ </label></div>";
                    tablo += " <div class=\"col-xs-6 col-md-6 col-sm-6 text-right\"<p> <a href=\"TabletPersonelDetay.aspx?pKod=" + p.kod + "&dondu=true" + "&sorgu=" + genelSorgu + "&aktiflik=" + aktiflik + "&tipler=" + tip + "&resim=" + resimBilgi + "\" class=\"btn btn-primary\" style=\"height:50px;font-weight:bold;font-size:large;text-align=center;\" role=\"button\">Detay</a> </p> ";
                    tablo += " </div></div> </div> </div> </div>";

                    if (cnt == liste.ObjeSayisi - 1)
                        sonuncuSatir = p.satir;
                    cnt++;
                }
                //tablo += "</div>";
            }

            if (satir != "0")
                sonuc.yukleme = true;
            sonuc.tablo = tablo;
            sonuc.satir = sonuncuSatir;
            sonuc.toplamKayit = liste.sonuc.kayitSay;

            return sonuc;
        }

        [WebMethod]
        //[Ext1.Net.DirectMethod]
        public static string RaporUret(bool dosyaMail, string rapor, string aktiflik, string[] personelTipler, bool tumu,
                                     string mailKisi, string kodlar, string sorgu)
        {
            string raporKod = rapor.Split(',')[0];
            string raporAd = rapor.Split(',')[1];
            string mesaj = "";
            TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);

            if (tumu)
            {
                kodlar = "";
                TNS.IKY.Personel personel = new TNS.IKY.Personel();
                personel.genelSorgu = sorgu;
                personel.aktifDurumlar = aktiflik;
                string personelTurler = "";
                if (personelTipler != null && personelTipler.Length > 0)
                {
                    PersonelTipi pt = new PersonelTipi();
                    pt.tipGruplar = personelTipler;//hdn.Value.Split(','); 
                    pt.aktif = 1;
                    ObjectArray ptipler = servisIKY.ListelePersonelTip(null, pt);
                    int cnt = 0;
                    foreach (PersonelTipi item in ptipler.objeler)
                    {
                        if (cnt != 0) personelTurler += ";";
                        personelTurler += item.kod.ToString();
                        cnt++;
                    }
                }
                personel.personelTipleri = personelTurler;
                TNS.ObjectArray pler = servisIKY.PersonelListele(kul, personel, false, false);
                if (pler.ObjeSayisi > 0)
                {
                    foreach (TNS.IKY.Personel p in pler.objeler)
                        kodlar += p.kod + ";";
                }
            }
            if (dosyaMail)
            {
                //showPopWin('HibeMakineReddet.aspx?menuYok=1&kodlar=' + kodlar, 600, 200, true, null);
                string url = RaporPersonel.adresUret(raporKod, "", "", "", "", 0, "pdf", 0, false, kodlar, aktiflik, "", "", sorgu, -1, 0, 0, 0, 0, 0, 0, 0, "", "", 0, "");
                return "1:" + url;
                //Ext1.Net.X.AddScript("RaporSayfası(" + url + ");");
                //HttpContext.Current.Response.Redirect(RaporPersonel.adresUret(raporKod, "", "", "", 0, false, "", "", "pdf", 0, false, kodlar, 0, "", ""), false);
            }
            else
            {
                if (string.IsNullOrWhiteSpace(mailKisi))
                {
                    //MesajKutusu("Mail Gönderilecek Kişiyi Giriniz.", false, false);
                    mesaj = "Mail Gönderilecek Kişiyi Giriniz.";
                    //return "2:" + mesaj;
                }
                else
                {
                    string dosyaAd = RaporPersonel.raporUret(servisIKY, kul, istemciUzayi.GenelSayfa.RaporSablonYol(), raporKod, "", "", "", "", 0, "pdf", 0, false, kodlar, aktiflik, "", "", false, sorgu, -1, 0, 0, 0, 0, 0, 0, 0, "", "", 0, "");
                    TNSCollection ekDosyaIsimleri = new TNSCollection();
                    EPostaEki ek = new EPostaEki();
                    ek.dosyaAd = dosyaAd;
                    ek.ek = null;
                    ek.ad = raporAd + ".pdf";
                    ekDosyaIsimleri.Add(ek);
                    string sonuc = OrtakFonksiyonlar.MailAt(kul.emailAdresi, mailKisi, "Raporlar", raporAd + " Raporu", true, false, ekDosyaIsimleri);
                    try
                    {
                        System.IO.File.Delete(dosyaAd);
                    }
                    catch
                    {
                    }
                    if (!string.IsNullOrWhiteSpace(sonuc) && sonuc != "1")
                        mesaj = sonuc;
                    //MesajKutusu(sonuc, false, false);
                    else
                        mesaj = "Mail Gönderildi.";
                }
                //MesajKutusu("Mail gönderildi", false, false);
                return "2:" + mesaj;
            }
        }

        //protected void RaporListele(object sender, EventArgs e)
        //{
        //    MesajKutusu(soRaporlar.Items[soRaporlar.SelectedIndex].Text + " Raporunu İndirmek İstediğinizden Emin Misiniz?", true, false);
        //}

        //protected void RaporaDevam(object sender, EventArgs e)
        //{
        //    Button btn = (Button)sender;
        //    if (btn.ID == "btnRDevam")
        //        RaporUret(true);
        //    else
        //        RaporUret(false);
        //}

        protected void RaporDoldur()
        {
            //soRaporlar.Items.Add(new ListItem("Raporlar...", "0"));
            //soRaporlar.Value = "0";
            string raporlar = "";
            foreach (RaporPersonel.RaporGrubu grup in RaporPersonel.raporGrubu)
            {
                raporlar += "<div class=\"panel panel-default\">" +
                              " <div class=\"panel-heading\"> " +
                              "     <h4 class=\"panel-title\"> " +
                               "        <a data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#" + grup.KOD + "\">" + grup.AD + " " +
                               "            </a>" +
                               "    </h4>" +
                             "  </div>" +
                             " <div id=\"" + grup.KOD + "\" class=\"panel-collapse collapse\"><div class=\"panel-body\">";
                foreach (RaporPersonel.RaporTanim item in RaporPersonel.raporTanimlar)
                {
                    if (item.KOD == "GR009" || item.KOD == "IK021")
                        continue;

                    if (item.raporGrubu == grup.KOD)
                    {
                        raporlar += "     <div class=\"row\">" +
                          "  <div class=\"btn-group\">" +
                          " <button type=\"button\" class=\"btn btn-default\" style=\"height:135px; font-size: 18px;width: 130px; white-space: normal;\">" + item.AD + "</button>" +
 " <button type=\"button\" class=\"btn btn-primary\" style=\"height:135px;\" onclick=\"SeciliKodlariGetir(1,'" + item.KOD + "','" + item.AD + "')\"" +
                              " ><i class=\"glyphicon glyphicon-download-alt\"></i></button>" +
 " <button type=\"button\" class=\"btn btn-primary\" style=\"height:135px;\" onclick=\"SeciliKodlariGetir(2,'" + item.KOD + "','" + item.AD + "')\"><i class=\"glyphicon glyphicon-send\"></i></button>" +
"</div>" +
                            "     </div>";
                    }

                    //soRaporlar.Items.Add(new ListItem(item.AD, item.KOD));
                }
                raporlar += "  </div></div></div>";
            }
            //soRaporlar.DataBind();

            ltlRaporlar.Text = raporlar;
        }

        protected void PersonelTurDoldur()
        {
            //pTipler.Items.Clear();
            //ArrayList listeler = TNS.IKY.Arac.PersonelTipListe;
            //int i = 0;
            //foreach (PersonelTipi pt in listeler)
            //{
            //    if (pt.kod == 0)
            //        continue;

            //    ListItem test = new ListItem(pt.ad, pt.kod.ToString());
            //    test.Attributes.Add("data-section", "Personel Tipleri/" + pt.grupAd);
            //    pTipler.Items.Add(test);
            //    if (pt.grupAd == "Kadrolu")//pt.kadrolu == 1)
            //    {
            //        pTipler.Items[i].Selected = true;
            //    }
            //    i++;
            //}
            //pTipler.DataBind();

            string turler = "<ul id=\"ptip\" class=\"list-group checked-list-box\" runat=\"server\">";
            ArrayList col = TNS.IKY.Arac.PersonelTipGrupListe;
            string isaretli = "false";
            foreach (PersonelTipi tip in col)
            {
                isaretli = "false";
                if (tip.ad == "Kadrolu")
                    isaretli = "true";
                turler += "  <li class=\"list-group-item\" data-style=\"button\" data-checked=\"" + isaretli + "\">" + tip.ad + "</li>";
            }
            turler += "     </ul>";
            pTurler.Text = turler;
        }

        //protected void MailGonder(object sender, EventArgs e)
        //{
        //    MesajKutusu(soRaporlar.Items[soRaporlar.SelectedIndex].Text + " Raporunu Mail Göndermek İstediğinizden Emin Misiniz?", false, true);
        //}
    }
}