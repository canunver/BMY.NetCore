﻿using System;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Globalization;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Dil Sınıfı
    /// </summary>
    public partial class PersonelLojman : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        //public string personelTCKimlikNo = "";

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPKod.Value = (Request.QueryString["personelKod"] + "").Trim();

            //personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnTemizle.Hidden = true;
            //    btnSil.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                Temizle();
                grdListeSelectionModel.ClearSelections();
                Genel.LojmanSiteDoldur(kullanan, ddlSite, siteStore);
                Listele(new PersonelLojmani());
                LojmanTurleriniDoldur();
                Genel.TahsisTipDoldur(ddlTahsisTip, tahsisTipStore);
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel Dil bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel Mal Bildirimi tipinde sınıf</param>
        public void Listele(PersonelLojmani kriter)
        {
            int personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            if (personelKod == 0)
            {
                return;
            }
            ObjectArray pler = servisIKY.PersonelLojmanListele(kullanan, new PersonelLojmani { personelKod = personelKod });

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }
            ListeStore.DataSource = pler.objeler;
            ListeStore.DataBind();

            //SiteDegisti(null, null);
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Dil bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            if (!KayitKontrol())
                return;

            PersonelLojmani d = new PersonelLojmani();
            d.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) > 0)
                d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            d.daireKod = OrtakFonksiyonlar.ConvertToInt(ddlDaire.Value, 0);
            d.lojmanTipi = OrtakFonksiyonlar.ConvertToInt(ddlLojmanTipi.Value, 0);         
            d.adres = txtAdres.Text;
            d.tashisTip = (ENUMTahsisTipi)OrtakFonksiyonlar.ConvertToInt(ddlTahsisTip.Value, 0);
            d.aciklama = txtAciklama.Text;
            d.oncelikDerecesi = OrtakFonksiyonlar.ConvertToInt(ddlDerece.Value, 0);
            if (d.tashisTip == ENUMTahsisTipi.Tahsis)
            {
                d.basTarihi = Genel.TarihAlaniDegerVer(txtBaslamaTarihi);
                d.bitTarihi = Genel.TarihAlaniDegerVer(txtBitisTarihi);
            }
            else
                d.rezervTarih = Genel.TarihAlaniDegerVer(txtRezervTarihi);

            Sonuc sonuc = servisIKY.PersonelLojmanKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                //Temizle();
                //grdListeSelectionModel.ClearSelections();
                DaireDoldur();
                ddlDaire.Value = d.daireKod;
                Listele(new PersonelLojmani());              
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL017);
            }
        }

        protected void btnTahsisEt_Click(object sender, DirectEventArgs e)
        {
            Sonuc sonuc = new Sonuc();
            TNSDateTime basTarihi = Genel.TarihAlaniDegerVer(txtTahsisTarihi);
            if (basTarihi.Yil == 0)
            {
                sonuc.DegerAta("Lojmana başlama tarihi boş geçilemez.");
            }
            else
            {
                sonuc = servisIKY.PersonelLojmanRezervdenTahsisEt(kullanan,
                    new PersonelLojmani
                    {
                        kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0),
                        basTarihi = basTarihi,
                        personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0)
                    });
            }

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Temizle();
                grdListeSelectionModel.ClearSelections();
                Listele(new PersonelLojmani());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL017);
            }
        }

        /// <summary>
        /// Sil düğmesine basınca, koda, T.C. Kimlik numarasına göre dil bilgisi silen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            int pKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);

            if (pKod <= 0 || kod <= 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL019);
                return;
            }

            PersonelLojmani d = new PersonelLojmani();
            d.personelKod = pKod;
            d.kod = kod;
            Sonuc sonuc = servisIKY.PersonelLojmanSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Temizle();
                grdListeSelectionModel.ClearSelections();
                Listele(new PersonelLojmani());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL018);
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            Temizle();
            hdnKod.Value = e.ExtraParams["kod"];
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            ObjectArray pler = servisIKY.PersonelLojmanListele(kullanan, new PersonelLojmani { kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0) });

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            PersonelLojmani pl = (PersonelLojmani)pler.objeler[0];

            ddlSite.SelectedItem.Value = pl.siteKod.ToString();
            BlokDoldur();
            ddlBlok.SelectedItem.Value = pl.blokKod.ToString();
            DaireDoldur();
            ddlDaire.SelectedItem.Value = pl.daireKod.ToString();
            ddlLojmanTipi.SelectedItem.Value = pl.lojmanTipi.ToString();
            txtAdres.Text = pl.adres;
            txtBaslamaTarihi.Text = pl.basTarihiDT.ToShortDateString();
            txtBitisTarihi.Text = pl.bitTarihiDT.ToShortDateString();
            ddlTahsisTip.SelectedItem.Value = ((int)pl.tashisTip).ToString();
            hdnTahsisTipi.Value = (int)pl.tashisTip;
            txtTahsisTarihi.Hidden = !(pl.tashisTip == ENUMTahsisTipi.Rezervasyon);
            btnTahsisEt.Hidden = !(pl.tashisTip == ENUMTahsisTipi.Rezervasyon);
            txtAciklama.Text = pl.aciklama;
            ddlDerece.SelectedItem.Value = pl.oncelikDerecesi.ToString();
            txtRezervTarihi.Text = pl.rezervTarih.ToString();
            TahsisTipDegisti();
        }

        protected void SiteDegisti(object sender, DirectEventArgs e)
        {
            BlokDoldur();
            ddlBlok.SelectedItem.Value = "";
        }

        protected void BlokDoldur()
        {
            if (OrtakFonksiyonlar.ConvertToInt(ddlSite.SelectedItem.Value, 0) == 0)
                return;
            Genel.LojmanSiteBlokDoldur(kullanan, ddlBlok, blokStore, OrtakFonksiyonlar.ConvertToInt(ddlSite.SelectedItem.Value, 0));
        }

        protected void DaireDoldur()
        {
            if (OrtakFonksiyonlar.ConvertToInt(ddlBlok.SelectedItem.Value, 0) == 0)
                return;
            //Genel.BosDaireListesi(kullanan, ddlDaire, daireStore, OrtakFonksiyonlar.ConvertToInt(ddlBlok.SelectedItem.Value, 0));
            Genel.LojmanSiteBlokDaireDoldur(kullanan, ddlDaire, daireStore, OrtakFonksiyonlar.ConvertToInt(ddlBlok.SelectedItem.Value, 0));
        }

        protected void BlokDegisti(object sender, DirectEventArgs e)
        {
            DaireDoldur();
            ddlDaire.SelectedItem.Value = "";
        }

        protected void LojmanTurleriniDoldur()
        {
            Genel.LojmanTurleriniDoldur(kullanan, ddlLojmanTipi, lojmanTipiStore);
        }

        void Temizle()
        {
            hdnKod.Clear();
            hdnTahsisTipi.Clear();
            txtAdres.Clear();
            ddlSite.Clear();
            ddlLojmanTipi.Clear();
            ddlBlok.Clear();
            ddlDaire.Clear();
            txtBaslamaTarihi.Clear();
            txtBitisTarihi.Clear();
            ddlBlok.Items.Clear();
            ddlDaire.Items.Clear();
            ddlTahsisTip.Clear();
            txtRezervTarihi.Clear();
            txtTahsisTarihi.Clear();
            txtAciklama.Clear();
            ddlDerece.Clear();
            TahsisTipDegisti();
        }

        bool KayitKontrol()
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(ddlDaire.Value, 0) == 0)
                hata += Resources.InsanKaynaklari.LojmanSite059 + "<br>";
            if (OrtakFonksiyonlar.ConvertToInt(ddlTahsisTip.Value, 0) == 0)
                hata += "Tahsis tipini seçmek zorundasınız. <br>";
            else
            {
                if (OrtakFonksiyonlar.ConvertToInt(ddlTahsisTip.Value, 0) != OrtakFonksiyonlar.ConvertToInt(hdnTahsisTipi.Value, 0) && OrtakFonksiyonlar.ConvertToInt(hdnTahsisTipi.Value, 0) != 0)
                    hata += " Tahsis tipini değiştiremezsiniz.";
            }

            if (OrtakFonksiyonlar.ConvertToInt(ddlTahsisTip.Value, 0) == (int)ENUMTahsisTipi.Rezervasyon)
            {
                if (string.IsNullOrWhiteSpace(Genel.TarihAlaniDegerVer(txtRezervTarihi).ToString()))
                    hata += "Rezervasyon tarihini girmek zorundasınız. <br>";
            }
            else
            {
                if (string.IsNullOrWhiteSpace(Genel.TarihAlaniDegerVer(txtBaslamaTarihi).ToString()))
                    hata += "Tahsis başlama tarihini girmek zorundasınız. <br>";
                if(OrtakFonksiyonlar.ConvertToInt(ddlLojmanTipi.Value, 0) == 0)
                    hata += "Hizmet türünü seçmek zorundasınız. <br>";
            }

                if (hata != "")
                {
                    GenelIslemler.MesajKutusu(this, hata);
                    return false;
                }
                else
                    return true;
        }

        protected void TahsisTipiChange(object sender, DirectEventArgs e)
        {
            TahsisTipDegisti();
        }

        protected void TahsisTipDegisti()
        {
            if (OrtakFonksiyonlar.ConvertToInt(ddlTahsisTip.SelectedItem.Value, 0) == (int)ENUMTahsisTipi.Rezervasyon)
            {
                txtRezervTarihi.Hidden = false;
                txtAciklama.Hidden = false;
                ddlDerece.Hidden = false;
                cmpTahTarih.Hidden = true;
                ddlLojmanTipi.Hidden = true;
            }
            else if (OrtakFonksiyonlar.ConvertToInt(ddlTahsisTip.SelectedItem.Value, 0) == (int)ENUMTahsisTipi.Tahsis)
            {
                txtRezervTarihi.Hidden = true;
                cmpTahTarih.Hidden = false;
                ddlLojmanTipi.Hidden = false;
                txtAciklama.Hidden = true;
                ddlDerece.Hidden = true;
            }
            else
            {
                txtRezervTarihi.Hidden = true;
                cmpTahTarih.Hidden = true;
                ddlLojmanTipi.Hidden = true;
                txtAciklama.Hidden = true;
                ddlDerece.Hidden = true;
            }
        }
    }
}
