﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class LojmanSiteGideri : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;
        int parYil = 0;
        int parAy = 0;
        int parSiteKod = 0;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = "Lojman Site Gider Tanımı";
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            parYil = GenelIslemlerIstemci.RequestBul(this, "yil", 0);
            parAy = GenelIslemlerIstemci.RequestBul(this, "ay", 0);
            parSiteKod = GenelIslemlerIstemci.RequestBul(this, "siteKod", 0);

            if (!IsPostBack)
            {
                Listele();
            }
        }

        protected void Listele()
        {
            SiteGider sg = new SiteGider();
            sg.siteKod = parSiteKod;
            sg.yil = parYil;
            sg.ay = parAy;
            ObjectArray oa = servis.SiteGiderListele(kullanan, sg);
            stoKesintiler.DataSource = oa.objeler;
            stoKesintiler.DataBind();
        }

        void Kaydet(DirectEventArgs e)
        {
            TNSCollection tc = new TNSCollection((SiteGider[])Ext.Net.JSON.Deserialize(e.ExtraParams["grdKesintiler"], typeof(SiteGider[])));
            Sonuc sonuc = servis.SiteGiderKaydet(kullanan, parSiteKod, parYil, parAy, tc);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite003);
                Listele();
            }
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }
    }
}
