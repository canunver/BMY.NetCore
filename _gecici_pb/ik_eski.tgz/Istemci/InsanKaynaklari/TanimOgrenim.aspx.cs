﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimOgrenim : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Ögrenim Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Listele(new Ogrenim());
            }
        }

        public void Listele(Ogrenim kriter)
        {
            //ObjectArray dler = servisIKY.OgrenimListele(kriter);

            //if (!dler.sonuc.islemSonuc)
            //{
            //    GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
            //    return;
            //}

            //if (dler.objeler.Count <= 0)
            //    GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            //List<object> tipler = new List<object>();
            //foreach (TNS.IKY.Ogrenim d in dler.objeler)
            //    tipler.Add(new
            //    {
            //        OGRENIMKODU = d.kod,
            //        OGRENIMADI = d.ad,
            //        SIRANO = d.siraNo,
            //        TIP = d.tip
            //    });

            //ListeStore.DataSource = tipler;
            //ListeStore.DataBind();
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            Ogrenim d = new Ogrenim();
            d.ad = txtOgrenimAdi.Text.Trim();
            d.tip = OrtakFonksiyonlar.ConvertToInt(txtTip.Text.Trim(), 0);
            d.siraNo = OrtakFonksiyonlar.ConvertToInt(txtSiraNo.Text, 0);
            Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            //if (txtOgrenimAdi.Text.Trim() == "")
            //{
            //    GenelIslemler.HataYaz(this, "Açıklama alanı boş bırakılamaz.");
            //    return;
            //}

            //Ogrenim d = new Ogrenim();
            //d.kod = OrtakFonksiyonlar.ConvertToInt(hdnOgrenimKodu.Value, 0);
            //d.ad = txtOgrenimAdi.Text;
            //d.tip = OrtakFonksiyonlar.ConvertToInt(txtTip.Value, 0);
            //d.siraNo = OrtakFonksiyonlar.ConvertToInt(txtSiraNo.Value, 0);

            //Sonuc sonuc = servisIKY.OgrenimKaydet(kullanan, d);

            //if (!sonuc.islemSonuc)
            //    GenelIslemler.HataYaz(this, sonuc.hataStr);
            //else
            //{
            //    Temizle();
            //    Listele(new Ogrenim());
            //    GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            //}
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            //Ogrenim d = new Ogrenim();
            //int kod = OrtakFonksiyonlar.ConvertToInt(hdnOgrenimKodu.Value, 0);

            //if (kod > 0)
            //{
            //    d.kod = kod;
            //    Sonuc sonuc = servisIKY.OgrenimSil(kullanan, d);

            //    if (!sonuc.islemSonuc)
            //        GenelIslemler.HataYaz(this, sonuc.hataStr);
            //    else
            //    {
            //        Temizle();
            //        Listele(new Ogrenim());
            //        GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
            //    }
            //}
            //else
            //    GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz öğrenim Bilgisini seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Listele(new Ogrenim());
            Temizle();
        }

        void Temizle()
        {
            txtOgrenimAdi.Text = "";
            txtSiraNo.Text = "";
            txtTip.Text = "";
            hdnOgrenimKodu.Text = "";
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            txtOgrenimAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["ogrenimAdi"]);
            txtSiraNo.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["siraNo"]);
            hdnOgrenimKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["ogrenimKodu"]);
            txtTip.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["tip"]);
        }
    }
}
