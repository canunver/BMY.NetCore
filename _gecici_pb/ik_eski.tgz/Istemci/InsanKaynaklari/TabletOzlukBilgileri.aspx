﻿<%@ Page Title="" Language="C#" MasterPageFile="~/InsanKaynaklari/MasterPage.Master"
    AutoEventWireup="true" CodeBehind="TabletOzlukBilgileri.aspx.cs" Inherits="InsanKaynaklari.TabletOzlukBilgileri" %>

<asp:Content ID="Content1" ContentPlaceHolderID="bilgiPaneli" runat="server">   
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    Özlük Bilgileri</h3>
            </div>
            <div class="panel-body">
                <asp:Label ID="lblOzluk" runat="server"></asp:Label>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    Nüfus Bilgileri</h3>
            </div>
            <div class="panel-body">
                <asp:Label ID="lblNufus" runat="server"></asp:Label>
            </div>
        </div>
    </div>
</asp:Content>
