﻿using System;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Globalization;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Dil Sınıfı
    /// </summary>
    public partial class PersonelDil : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        //public string personelTCKimlikNo = "";

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPKod.Value = (Request.QueryString["personelKod"] + "").Trim();

            //personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnTemizle.Hidden = true;
            //    btnSil.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                Genel.YilDoldur(ddlDonemYil, new Store(), false);
                Genel.AyDoldur(ddlDonemAy, new Store(), false);
                DilDoldur();
                DilBelgeTurDoldur();
                Temizle();

                Listele(new TNS.IKY.PersonelDil());
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel Dil bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel Mal Bildirimi tipinde sınıf</param>
        public void Listele(TNS.IKY.PersonelDil kriter)
        {
            if (string.IsNullOrEmpty(hdnPKod.Value.ToString()))
                return;

            kriter.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            ObjectArray pler = servisIKY.PersonelDilListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            List<object> liste = new List<object>();
            foreach (TNS.IKY.PersonelDil p in pler.objeler)
                liste.Add(new
                {
                    KOD = p.kod,
                    PKOD = p.personelKod,
                    DILKOD = p.dilKod,
                    DILAD = Genel.SozlukBilgiGetir(p.dilKod).ad,
                    PUAN = p.puan,
                    TARIH = p.tarih.Oku(),
                    DUZEY = p.duzey,
                    DONEMAY = p.donemAy,
                    DONEMYIL = p.donemYil,
                    BELGETUR = p.belgeTur,
                    BELGETURAD = Genel.SozlukBilgiGetir(p.belgeTur).ad,
                    BELGETARIHI = p.belgeTarihi.Oku(),
                    BELGENO = p.belgeNo,
                    BORDROYAESAS = p.bordroyaEsas,
                    DILSEVIYESI = p.dilSeviyesi,
                    KURUMFAYDALANIYOR = p.kurumFaydalaniyor,
                });

            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Dil bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            if (!KayitKontrol())
                return;

            TNS.IKY.PersonelDil d = new TNS.IKY.PersonelDil();
            d.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) > 0)
                d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            d.dilKod = OrtakFonksiyonlar.ConvertToInt(ddlDil.Value, 0);
            d.puan = OrtakFonksiyonlar.ConvertToDouble(txtPuan.Text, 0);
            d.tarih = Genel.TarihAlaniDegerVer(txtTarih);
            d.duzey = OrtakFonksiyonlar.ConvertToStr(ddlDuzey.Value);
            d.donemAy = OrtakFonksiyonlar.ConvertToInt(ddlDonemAy.Value, 0);
            d.donemYil = OrtakFonksiyonlar.ConvertToInt(ddlDonemYil.Value, 0);
            d.belgeTur = OrtakFonksiyonlar.ConvertToInt(ddlBelgeTuru.Value, 0);
            d.belgeTarihi = Genel.TarihAlaniDegerVer(txtBelgeTarihi);
            d.belgeNo = txtBelgeNo.Text.Trim();
            d.dilSeviyesi = txtDilSeviyesi.Text.Trim();
            d.bordroyaEsas = OrtakFonksiyonlar.ConvertToInt(chkBordroyaEsas.Checked, 0);
            d.kurumFaydalaniyor = OrtakFonksiyonlar.ConvertToInt(chkKurumFaydalaniyor1.Checked, 0);

            Sonuc sonuc = servisIKY.PersonelDilKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                hdnKod.Value = sonuc.anahtar;
                //Temizle();
                Listele(new TNS.IKY.PersonelDil());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL017);
            }
        }

        /// <summary>
        /// Sil düğmesine basınca, koda, T.C. Kimlik numarasına göre dil bilgisi silen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            int pKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);

            if (pKod <= 0 || kod <= 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL019);
                return;
            }

            TNS.IKY.PersonelDil d = new TNS.IKY.PersonelDil();
            d.personelKod = pKod;
            d.kod = kod;
            Sonuc sonuc = servisIKY.PersonelDilSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                //PersonelBelgeler belge = new PersonelBelgeler();
                //belge.tcKimlikNo = personelTCKimlikNo;
                //belge.tip = (int)ENUMBELGEFORMTIP.PERSONELDIL;
                //belge.kayitSiraNo = hdnSiraNo.Value.ToString();
                //servisIKY.PersonelBelgeSil(kullanan, belge);

                Temizle();
                Listele(new TNS.IKY.PersonelDil());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL018);
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            string secilisatir = e.ExtraParams["RowValue"].ToString();
            XmlNode xml = JSON.DeserializeXmlNode("{records:{record:" + secilisatir + "}}");
            foreach (XmlNode row in xml.SelectNodes("records/record"))
            {
                hdnKod.Value = row.SelectSingleNode("KOD").InnerXml;
                hdnPKod.Value = row.SelectSingleNode("PKOD").InnerXml;
                ddlDil.SetValueAndFireSelect(row.SelectSingleNode("DILKOD").InnerXml);
                txtPuan.Text = row.SelectSingleNode("PUAN").InnerXml;
                txtTarih.Value = row.SelectSingleNode("TARIH") != null ? row.SelectSingleNode("TARIH").InnerXml : "";
                ddlDuzey.SetValueAndFireSelect(row.SelectSingleNode("DUZEY").InnerXml);
                ddlDonemAy.SetValueAndFireSelect(row.SelectSingleNode("DONEMAY").InnerXml);
                ddlDonemYil.SetValueAndFireSelect(row.SelectSingleNode("DONEMYIL").InnerXml);
                ddlBelgeTuru.SetValueAndFireSelect(row.SelectSingleNode("BELGETUR").InnerXml);
                txtBelgeTarihi.Value = row.SelectSingleNode("BELGETARIHI") != null ? row.SelectSingleNode("BELGETARIHI").InnerXml : "";
                txtBelgeNo.Text = row.SelectSingleNode("BELGENO").InnerXml;
                txtDilSeviyesi.Text = row.SelectSingleNode("DILSEVIYESI").InnerXml;
                chkBordroyaEsas.Checked = OrtakFonksiyonlar.ConvertToInt(row.SelectSingleNode("BORDROYAESAS").InnerXml, 0) > 0;
                chkKurumFaydalaniyor1.Checked = OrtakFonksiyonlar.ConvertToInt(row.SelectSingleNode("KURUMFAYDALANIYOR").InnerXml, 0) > 0;
            }
            BelgeListesiDoldur();
        }

        void Temizle()
        {
            hdnKod.Clear();
            ddlDil.Clear();
            txtBelgeNo.Text = "";
            txtBelgeTarihi.Text = "";
            txtPuan.Text = "";
            txtTarih.Text = "";
            ddlBelgeTuru.Clear();
            ddlDonemAy.Clear();
            ddlDonemYil.Clear();
            ddlDuzey.Clear();
            txtDilSeviyesi.Clear();
            chkBordroyaEsas.Checked = false;
            chkKurumFaydalaniyor1.Checked = false;
            grdListeSelectionModel.ClearSelections();
            BelgeStore.RemoveAll();
            BelgeStore.DataBind();
        }

        bool KayitKontrol()
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(ddlDil.Value, 0) == 0)
                hata += Resources.InsanKaynaklari.FRMPDL016 + "<br>";
            if (OrtakFonksiyonlar.ConvertToInt(ddlBelgeTuru.Value, 0) == 0)
                hata += "Dil Bilgisi belge türünü seçiniz." + "<br>";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return false;
            }
            else
                return true;
        }

        void DilDoldur()
        {
            ddlDil.Items.Clear();
            StoreDil.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.DILKODU, 0).ToString().PadLeft(2, '0'), seviye = 2 });
            StoreDil.DataBind();
        }

        void DilBelgeTurDoldur()
        {
            ddlBelgeTuru.Items.Clear();
            StoreDilBelgeTur.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.DILBELGETUR, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreDilBelgeTur.DataBind();
        }

        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELDIL;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }        

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnKod.Value.ToString().Trim()))
            {
                btnKaydet_Click(null, null);
                //GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMPAB040, Resources.InsanKaynaklari.FRMPAB041);
                //return;
            }

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnPKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELDIL, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }
    }
}
