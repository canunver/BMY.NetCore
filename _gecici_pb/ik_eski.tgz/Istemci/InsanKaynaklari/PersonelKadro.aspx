﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelKadro.aspx.cs"
    Inherits="InsanKaynaklari.PersonelKadro" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        function DurumIconRenderer(deger) {
            var resim = "";
            if (deger == 1) resim = hdnYENI.getValue();
            else if (deger == 146) resim = hdnYENI.getValue();
            else if (deger == 106) resim = hdnAKTIFKAYIT.getValue();
            else if (deger == 136) resim = hdnAKTIFKAYIT.getValue();
            else if (deger == 116) resim = hdnAKTIFKAPANIYOR.getValue();
            else if (deger == 126) resim = hdnAKTIFKAPANDI.getValue();
            else if (deger == 201) resim = hdnAYRILDI.getValue();
            else if (deger == 209) resim = hdnREDDEDILDI.getValue();
            else resim = hdnTANIMSIZ.getValue();
            return "<img src='" + resim + "' />";;
        }

        function GRDListeKomutu(komut, rec, sat, sut) {
            PersonelAtamaAc(rec.data.kod);
        }

        function HizmetSureleri() {
            var kod = hdnPersonelKod.getValue();
            if (Number(kod) == 0) {
                Ext1.Msg.alert("Uyarı", "İlk önce Personel seçiniz", "", "")
                return;
            }
            showPopWinTop('PersonelHizmetSureleri.aspx?menuYok=1&personelKod=' + kod, 400, 250, true, '', '', true);
        }

        function HizmetAyari() {
            var kod = hdnPersonelKod.getValue();
            if (Number(kod) == 0) {
                Ext1.Msg.alert("Uyarı", "İlk önce Personel seçiniz", "", "")
                return;
            }
            showPopWinTop('PersonelHizmetAyari.aspx?menuYok=1&personelKod=' + kod, 450, 240, true, '', '', true);
        }

        function HitaptanAl() {
            var kod = hdnPersonelKod.getValue();
            if (Number(kod) == 0) {
                Ext1.Msg.alert("Uyarı", "İlk önce Personel seçiniz", "", "")
                return;
            }
            showPopWinTop('PersonelHITAP.aspx?menuYok=1&personelKod=' + kod + "&tur=1", 600, 450, true, '', '', true);
        }

        function PersonelAtamaAc(islemNo) {
            parent.PersonelAtamaAc(hdnPersonelKod.getValue(), islemNo)
        }

        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                    function (btn) {
                        if (btn == "yes") {
                            Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                        }
                    });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <ext:Hidden ID="hdnYetkiliBirim" runat="server" />
        <ext:Hidden ID="hdnPersonelKod" runat="server" />
        <ext:Hidden ID="hdnTANIMSIZ" runat="server" />
        <ext:Hidden ID="hdnYENI" runat="server" />
        <ext:Hidden ID="hdnAKTIFKAYIT" runat="server" />
        <ext:Hidden ID="hdnAKTIFKAPANIYOR" runat="server" />
        <ext:Hidden ID="hdnAKTIFKAPANDI" runat="server" />
        <ext:Hidden ID="hdnAYRILDI" runat="server" />
        <ext:Hidden ID="hdnREDDEDILDI" runat="server" />
        <ext:Hidden ID="hdnBelgeKod" runat="server" />
        <ext:Store ID="ListeStore" runat="server">
            <Reader>
                <ext:JsonReader IDProperty="kod">
                    <Fields>
                        <ext:RecordField Name="kod" Type="Int" />
                        <ext:RecordField Name="organizasyonKodu" Type="Int" />
                        <ext:RecordField Name="birimGorevAd" Type="String" />
                        <ext:RecordField Name="unvan" Type="Int" />
                        <ext:RecordField Name="unvanAd" Type="String" />
                        <ext:RecordField Name="sinifi" Type="Int" />
                        <ext:RecordField Name="evrakNo" Type="String" />
                        <ext:RecordField Name="yasalDayanak" Type="String" />
                        <ext:RecordField Name="onayTarihDT" Type="Date" />
                        <ext:RecordField Name="aciklama" Type="String" />
                        <ext:RecordField Name="kadroDerece" Type="Int" />
                        <ext:RecordField Name="kadroTarihDT" Type="Date" />
                        <ext:RecordField Name="kazanilmisHakDerece" Type="Int" />
                        <ext:RecordField Name="kazanilmisHakKademe" Type="Int" />
                        <ext:RecordField Name="kazanilmisHakTarihDT" Type="Date" />
                        <ext:RecordField Name="kazanilmisGosterge" Type="Int" />
                        <ext:RecordField Name="kazanilmisEkGosterge" Type="Int" />
                        <ext:RecordField Name="odemeyeEsasDerece" Type="Int" />
                        <ext:RecordField Name="odemeyeEsasKademe" Type="Int" />
                        <ext:RecordField Name="odemeyeEsasTarihDT" Type="Date" />
                        <ext:RecordField Name="odemeyeEsasGosterge" Type="Int" />
                        <ext:RecordField Name="odemeyeEsasEkGosterge" Type="Int" />
                        <ext:RecordField Name="emekliyeEsasDerece" Type="Int" />
                        <ext:RecordField Name="emekliyeEsasKademe" Type="Int" />
                        <ext:RecordField Name="emekliyeEsasTarihDT" Type="Date" />
                        <ext:RecordField Name="emekliyeEsasGosterge" Type="Int" />
                        <ext:RecordField Name="emekliyeEsasEkGosterge" Type="Int" />
                        <ext:RecordField Name="kadroDurum" Type="Int" />
                        <ext:RecordField Name="ayrilmaTarihiDT" Type="Date" />
                        <ext:RecordField Name="ayrilmaNedeni" Type="String" />
                        <ext:RecordField Name="gorevYeri" Type="String" />
                        <ext:RecordField Name="hizmetSebebi" Type="String" />
                        <ext:RecordField Name="hizmetSebebiKod" Type="Int" />
                        <ext:RecordField Name="hizmetKurumu" Type="Int" />
                        <ext:RecordField Name="belgeCinsi" Type="String" />
                        <ext:RecordField Name="belgeNo" Type="String" />
                        <ext:RecordField Name="belgeTarihiDT" Type="Date" />
                        <ext:RecordField Name="gorunenUnvanKodu" Type="Int" />
                        <ext:RecordField Name="eskiHizmetTipi" Type="Int" />
                        <ext:RecordField Name="hizmetKurumuAd" Type="String" />
                        <ext:RecordField Name="atamaTarihiDT" Type="Date" />
                        <ext:RecordField Name="ayrilmaTarihiDT" Type="Date" />
                        <ext:RecordField Name="personelTipAd" Type="String" />
                        <ext:RecordField Name="hizmetSebebiAd" Type="String" />
                        <ext:RecordField Name="ayrilmaGerekcesiAd" Type="String" />
                    </Fields>
                </ext:JsonReader>
            </Reader>
        </ext:Store>
         <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
        <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
            <Items>
                <ext:Panel ID="Panel1" runat="server" Border="false" Region="Center" Layout="FitLayout">
                    <TopBar>
                        <ext:Toolbar runat="server">
                            <Items>
                                <ext:Button runat="server" ID="btnYeniKayit" Icon="PageAdd" Text="Yeni Hizmet Ekle">
                                    <Listeners>
                                        <Click Handler="PersonelAtamaAc(0);" />
                                    </Listeners>
                                </ext:Button>
                                <ext:Button ID="btnHizmetSureleri" runat="server" Text="Hizmet Süreleri" Icon="UserSuit">
                                    <Listeners>
                                        <Click Handler="HizmetSureleri();"></Click>
                                    </Listeners>
                                </ext:Button>
                                <ext:Button ID="btnHizmetBelgesi" runat="server" Text="Hizmet Belgesi Yazdır" Icon="PageWord">
                                    <DirectEvents>
                                        <Click OnEvent="HizmetBelgesiYazdir" Timeout="900000" IsUpload="true">
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnOnayla" runat="server" Text="Onayla" Icon="Accept">
                                    <DirectEvents>
                                        <Click OnEvent="btnOnayla_Click">
                                            <Confirmation ConfirmRequest="true" Message="Seçili işlemleri onaylamaktan istiyor musunuz?"
                                                Title="Onay" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            <ExtraParams>
                                                <ext:Parameter Name="onayKod" Value="5" Mode="Value" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnRed" runat="server" Text="İptal Et" Icon="Cancel">
                                    <DirectEvents>
                                        <Click OnEvent="btnOnayla_Click">
                                            <Confirmation ConfirmRequest="true" Message="Seçili işlemleri iptal etmek istiyor musunuz?"
                                                Title="Red" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            <ExtraParams>
                                                <ext:Parameter Name="onayKod" Value="9" Mode="Value" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnYeniYap" runat="server" Text="Yeni Yap" Icon="TableEdit">
                                    <DirectEvents>
                                        <Click OnEvent="btnOnayla_Click">
                                            <Confirmation ConfirmRequest="true" Message="Seçili işlemleri değiştirilebilir hale getirmek istiyor musunuz?"
                                                Title="Red" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            <ExtraParams>
                                                <ext:Parameter Name="onayKod" Value="1" Mode="Value" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnSil" runat="server" Text="Sil" Icon="TableDelete">
                                    <DirectEvents>
                                        <Click OnEvent="btnOnayla_Click">
                                            <Confirmation ConfirmRequest="true" Message="Seçili işlemleri iptal etmek istiyor musunuz?"
                                                Title="Red" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            <ExtraParams>
                                                <ext:Parameter Name="onayKod" Value="10" Mode="Value" />
                                            </ExtraParams>
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnHitaptanAl" runat="server" Icon="HouseConnect" Text="HİTAP'tan Al">
                                    <Listeners>
                                        <Click Fn="HitaptanAl" />
                                    </Listeners>
                                </ext:Button>
                                <ext:Button ID="btnHizmetAyari" runat="server" Text="Hizmet Ayarları" Icon="WrenchOrange">
                                    <Listeners>
                                        <Click Handler="HizmetAyari();"></Click>
                                    </Listeners>
                                </ext:Button>
                                <ext:Button ID="btnKisiBorcuYazdir" runat="server" Text="Kişi Borcu" Icon="PageCancel">
                                    <DirectEvents>
                                        <Click OnEvent="btnKisiBorcuYazdir_Click" Timeout="900000" IsUpload="true">
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                            </Items>
                        </ext:Toolbar>
                    </TopBar>
                    <Items>
                        <ext:Panel runat="server" Layout="BorderLayout" Border="false">
                            <Items>
                                <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                    StoreID="ListeStore" Border="true" Region="Center">
                                    <ColumnModel ID="ColumnModel1" runat="server">
                                        <Columns>
                                            <ext:ImageCommandColumn Width="40">
                                                <Commands>
                                                    <ext:ImageCommand Icon="Pencil" Text="Aç" CommandName="1" />
                                                </Commands>
                                            </ext:ImageCommandColumn>
                                            <ext:Column DataIndex="kadroDurum" Width="30">
                                                <Renderer Fn="DurumIconRenderer" />
                                            </ext:Column>
                                            <ext:DateColumn DataIndex="atamaTarihiDT" Header="Başlama Tarihi" Width="80" Format="dd.MM.yyyy" />
                                            <ext:DateColumn DataIndex="ayrilmaTarihiDT" Header="Bitiş Tarihi" Width="80" Format="dd.MM.yyyy" />
                                            <ext:Column DataIndex="hizmetSebebiAd" Header="Başlangıç Sebebi" Width="150" />
                                            <ext:Column DataIndex="ayrilmaGerekcesiAd" Header="Ayrılma Gerekçesi" Width="150" />
                                            <ext:Column DataIndex="personelTipAd" Header="Personel Türü" Width="150" />
                                            <ext:Column DataIndex="birimGorevAd" Header="<%$ Resources:InsanKaynaklari,FRMPRK068 %>"
                                                Width="150" />
                                            <ext:Column DataIndex="unvanAd" Header="<%$ Resources:InsanKaynaklari,FRMPRK050 %>"
                                                Width="110" />
                                            <ext:Column DataIndex="kadroDerece" Header="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                                Width="43" Align="Center" />
                                            <ext:Column DataIndex="kazanilmisHakDerece" Header="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                                Width="43" Align="Center" />
                                            <ext:Column DataIndex="kazanilmisHakKademe" Header="<%$ Resources:InsanKaynaklari,FRMPRK067 %>"
                                                Width="46" Align="Center" />
                                            <ext:Column DataIndex="kazanilmisGosterge" Header="<%$ Resources:InsanKaynaklari,FRMPRK058 %>"
                                                Width="55" Align="Center" />
                                            <ext:Column DataIndex="kazanilmisEkGosterge" Header="<%$ Resources:InsanKaynaklari,FRMPRK059 %>"
                                                Width="66" Align="Center" />
                                            <ext:Column DataIndex="odemeyeEsasDerece" Header="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                                Width="43" Align="Center" />
                                            <ext:Column DataIndex="odemeyeEsasKademe" Header="<%$ Resources:InsanKaynaklari,FRMPRK067 %>"
                                                Width="46" Align="Center" />
                                            <ext:Column DataIndex="odemeyeEsasGosterge" Header="<%$ Resources:InsanKaynaklari,FRMPRK058 %>"
                                                Width="55" Align="Center" />
                                            <ext:Column DataIndex="odemeyeEsasEkGosterge" Header="<%$ Resources:InsanKaynaklari,FRMPRK059 %>"
                                                Width="66" Align="Center" />
                                            <ext:Column DataIndex="emekliyeEsasDerece" Header="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                                Width="43" Align="Center" />
                                            <ext:Column DataIndex="emekliyeEsasKademe" Header="<%$ Resources:InsanKaynaklari,FRMPRK067 %>"
                                                Width="46" Align="Center" />
                                            <ext:Column DataIndex="emekliyeEsasGosterge" Header="<%$ Resources:InsanKaynaklari,FRMPRK058 %>"
                                                Width="55" Align="Center" />
                                            <ext:Column DataIndex="emekliyeEsasEkGosterge" Header="<%$ Resources:InsanKaynaklari,FRMPRK059 %>"
                                                Width="66" Align="Center" />
                                        </Columns>
                                    </ColumnModel>
                                    <View>
                                        <ext:GridView runat="server">
                                            <HeaderGroupRows>
                                                <ext:HeaderGroupRow>
                                                    <Columns>
                                                        <ext:HeaderGroupColumn ColSpan="8" />
                                                        <ext:HeaderGroupColumn Header="<%$ Resources:InsanKaynaklari,FRMPRK055 %>" ColSpan="3"
                                                            Align="Center" />
                                                        <ext:HeaderGroupColumn Header="<%$ Resources:InsanKaynaklari,FRMPRK060 %>" ColSpan="4"
                                                            Align="Center" />
                                                        <ext:HeaderGroupColumn Header="<%$ Resources:InsanKaynaklari,FRMPRK061 %>" ColSpan="4"
                                                            Align="Center" />
                                                        <ext:HeaderGroupColumn Header="<%$ Resources:InsanKaynaklari,FRMPRK062 %>" ColSpan="4"
                                                            Align="Center" />
                                                    </Columns>
                                                </ext:HeaderGroupRow>
                                            </HeaderGroupRows>
                                        </ext:GridView>
                                    </View>
                                    <SelectionModel>
                                        <ext:CheckboxSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="false" />
                                    </SelectionModel>
                                    <Listeners>
                                        <Command Fn="GRDListeKomutu" />
                                    </Listeners>
                                </ext:GridPanel>
                                <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                    Frame="true" TrackMouseOver="true" StoreID="BelgeStore" HideHeaders="true" Height="150"
                                    AnchorHorizontal="96%" HideLabel="true" Region="South" Visible="false">
                                    <ColumnModel ID="ColumnModel2" runat="server">
                                        <Columns>
                                            <ext:RowNumbererColumn />
                                            <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Width="250" />
                                            <ext:CommandColumn Width="30">
                                                <Commands>
                                                    <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB037 %>" />
                                                </Commands>
                                            </ext:CommandColumn>
                                            <ext:CommandColumn Width="30">
                                                <Commands>
                                                    <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPAB038 %>" />
                                                </Commands>
                                            </ext:CommandColumn>
                                        </Columns>
                                    </ColumnModel>
                                    <Listeners>
                                        <Command Fn="KomutCalistir" />
                                    </Listeners>
                                    <SelectionModel>
                                        <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                        </ext:RowSelectionModel>
                                    </SelectionModel>
                                    <TopBar>
                                        <ext:Toolbar runat="server">
                                            <Items>
                                                <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                    ButtonText="Belge Ekle">
                                                    <DirectEvents>
                                                        <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                    </DirectEvents>
                                                </ext:FileUploadField>
                                            </Items>
                                        </ext:Toolbar>
                                    </TopBar>
                                </ext:GridPanel>
                            </Items>
                        </ext:Panel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
    </form>
</body>
</html>
