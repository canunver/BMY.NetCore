﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;

namespace InsanKaynaklari
{
    public partial class KadroKontenjanSorgu : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        int personelTur;

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            personelTur = OrtakFonksiyonlar.ConvertToInt(Request.QueryString.Get("personelTur"), 0);

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, "KadroKontenjanAna.aspx");

            if (!IsPostBack)
            {
                hdnYetkiliBirim.Text = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");

                //if (GenelIslemlerIstemci.OrgSemaPersonelKullaniyorMu())
                trpBirim.Listeners.BeforeLoad.Fn = "OrgBirimDoldur";
                //else
                //    trpBirim.Listeners.BeforeLoad.Fn = "nodeLoadMuhasebeBirim";

                Genel.KadroIslemTurDoldur(storeIslemTur, true);
                Genel.UnvanDoldur(servisIKY, this, storeUnvan);
                Genel.KadroDereceDoldur(storeKadroDerece);
            }
        }

        //Kalkacak
        protected void NodeLoad(object sender, NodeLoadEventArgs e)
        {
            Genel.BirimDoldur(e);
        }

        /// <summary>
        /// Handles the Click event of the btnListe control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="Ext1.Net.DirectEventArgs"/> instance containing the event data.</param>
        protected void btnListe_Click(object sender, DirectEventArgs e)
        {
            try
            {
                TNS.IKY.KadroKontenjan[] kklar = servisIKY.KadroKontenjanListele(kullanan, KriterTopla(), false);
                if (kklar == null || kklar.Length <= 0)
                {
                    GenelIslemler.HataYaz(this, Resources.InsanKaynaklari.FRMKAD016);

                    storeListe.DataSource = new List<object>();
                    storeListe.DataBind();
                    return;
                }

                List<object> list = new List<object>();
                foreach (TNS.IKY.KadroKontenjan k in kklar)
                {
                    object degerler = new
                    {
                        kod = k.kod,
                        birimKod = k.organizasyonKod.ToString(), //GenelIslemlerIstemci.OrgSemaPersonelKullaniyorMu() ?  : "",
                        birim = k.organizasyonAd, //GenelIslemlerIstemci.OrgSemaPersonelKullaniyorMu() ?  : "",
                        siraNo = k.kod.ToString().PadLeft(6, '0'),
                        islemTur = Resources.InsanKaynaklari.ResourceManager.GetString("FRMKAD010_" + (int)k.islemTur),
                        islemTarih = k.islemTarih.ToString(),
                        dayanakTarih = k.dayanakBelgeTarih.ToString(),
                        dayanakNo = k.dayanakBelgeNo,
                        aciklama = k.aciklama
                    };
                    list.Add(degerler);
                }

                storeListe.DataSource = list;
                storeListe.DataBind();

                PagingToolbar1.PageSize = OrtakFonksiyonlar.ConvertToInt(cmbPageSize.Text, 0);
            }
            catch (Exception ex)
            {
                GenelIslemler.HataYaz(this, ex.Message);
                return;
            }
        }

        TNS.IKY.KadroKontenjan KriterTopla()
        {
            TNS.IKY.KadroKontenjan p = new TNS.IKY.KadroKontenjan();
            p.personelTur = ENUMPersonelTur.Memur;

            string birim = pgFiltre.Source["birim"].Value;
            if (!string.IsNullOrEmpty(birim))
            {
                //if (GenelIslemlerIstemci.OrgSemaPersonelKullaniyorMu())
                //{
                p.organizasyonKod = OrtakFonksiyonlar.ConvertToInt(birim, 0);
                if (p.organizasyonKod > 0)
                {
                    OrganizasyonBirim orgBirim = TNS.ORG.Arac.OrgBirimBul(p.organizasyonKod);
                    if (orgBirim != null)
                    {
                        //p.mb = new MuhasebeBirim();
                        //p.mb.muhasebe = OrtakFonksiyonlar.ConvertToInt(orgBirim.muhasebekodu, 0);
                        //p.mb.birimKod = orgBirim.muhasebebirim;
                        //p.mb.kurum = orgBirim.kurumsalkod;
                    }
                }
                //}
                //else
                //{
                //    string[] parcaliKod = birim.Split('-');
                //    //p.mb = new MuhasebeBirim();
                //    //p.mb.kurum = parcaliKod[0];
                //    //p.mb.muhasebe = OrtakFonksiyonlar.ConvertToInt(parcaliKod[1], 0);
                //    //p.mb.birimKod = parcaliKod[2];
                //}
            }

            p.islemTur = (EnumKadroKontenjanIslemTur)OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["islemTur"].Value, 0);
            p.islemTarih = !string.IsNullOrEmpty(pgFiltre.Source["islemTarih"].Value) ? new TNSDateTime(pgFiltre.Source["islemTarih"].Value) : null;
            p.aciklama = pgFiltre.Source["aciklama"].Value;
            p.dayanakBelgeTarih = !string.IsNullOrEmpty(pgFiltre.Source["dayanakTarih"].Value) ? new TNSDateTime(pgFiltre.Source["dayanakTarih"].Value) : null;
            p.dayanakBelgeNo = pgFiltre.Source["dayanakNo"].Value;

            if (!string.IsNullOrEmpty(pgFiltre.Source["unvan"].Value) ||
                !string.IsNullOrEmpty(pgFiltre.Source["kadroDerece"].Value))
            {
                TNS.IKY.KadroKontenjanDetay detay = new TNS.IKY.KadroKontenjanDetay();
                detay.unvanKod = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["unvan"].Value, 0);
                detay.kadroDerece = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["kadroDerece"].Value, 0);

                p.detaylar = new TNS.IKY.KadroKontenjanDetay[1];
                p.detaylar[0] = detay;
            }

            return p;
        }
    }
}