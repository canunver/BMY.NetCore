﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS.KYM;
using OrtakClass;
using TNS;

namespace InsanKaynaklari
{
    public partial class TabletPersonelDetay : istemciUzayi.GenelSayfa
    {
        TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnKod.Value = (Request.QueryString["pKod"] + "").Trim();
            //hdnSorgu.Value = (Request.QueryString["sorgu"] + "").Trim();

            if (!IsPostBack)
            {
                KisiselListele();
            }
            else
            {
                img2.Visible = true;
                lblAd.Visible = true;
            }
        }

        public void IletisimListele(object sender, EventArgs e)
        {
            ShowHide(false);
            adres.Visible = true;
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            try
            {
                TNS.IKY.PersonelIletisim iletisim = servisIKY.PersonelAdresListele(kul, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
                iAdres.InnerText = ": " + iletisim.adres;
                iIsTel.InnerText = ": " + iletisim.isTelefon;
                iCepTel.InnerText = ": " + iletisim.cepTelefon;
                iCepTel2.InnerText = ": " + iletisim.cepTelefon2;
                iFax.InnerText = ": " + iletisim.faks;
                iLojman.InnerText = ": " + iletisim.lojmanTel;
                iGoruntulu.InnerText = ": " + iletisim.goruntulu;
                iTelsiz.InnerText = ": " + iletisim.telsiz;
                iMail.InnerHtml = ": " + "<a href=\"#\" onclick=\"GoMail('" + iletisim.eposta + "'); return false; \" target=\"_blank\" id=\"mailbutton\">" + iletisim.eposta + "</a>";
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu(this, ex.Message);
                return;
            }
        }

        public void btnKisiselListele(object sender, EventArgs e)
        {
            KisiselListele();
        }
        protected void KisiselListele()
        {
            img2.Visible = false;
            lblAd.Visible = false;
            ObjectArray dler = servisIKY.PersonelListele(kullanan, new TNS.IKY.Personel { kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) }, true, false);

            if (dler.objeler.Count > 0)
            {
                TNS.IKY.Personel d = (TNS.IKY.Personel)dler.objeler[0];

                ShowHide(false);
                ozluk.Visible = true;
                ptc.InnerText = ": " + d.tcKimlikNo;
                //pisim.InnerText = d.adSoyad;
                pKadroTarihi.InnerText = ": " + d.kadro.kadroTarih.ToString();
                pBirim.InnerText = ": " + d.kadro.birimAd;
                pCep.InnerText = ": " + d.iletisim.cepTelefon;
                pIsTel.InnerText = ": " + d.iletisim.isTelefon;
                pMail.InnerHtml = ": " + "<a href=\"#\" onclick=\"GoMail('" + d.iletisim.eposta + "'); return false; \" target=\"_blank\" >" + d.iletisim.eposta + "</a>";
                punvan.InnerText = ": " + d.kadro.unvanAd;
                if (d.cinsiyet == TNS.IKY.ENUMCINSIYET.KADIN)
                    lnkAskerlik.Visible = false;
                img1.Src = d.resimYol;
                img2.Src = d.resimYol;
                lblAd.Text = "<h3>" + d.adSoyad + "<h3>";
                lblGenelBilgi.Text = "<h3>" + d.adSoyad + "<h3>";
            }
        }

        public void AskerlikListele(object sender, EventArgs e)
        {
            ShowHide(false);
            askerlik.Visible = true;
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.IKY.PAskerlik bilgi = servisIKY.PersonelAskerlikListele(kul, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
            aDurum.InnerText = ": " + bilgi.askerlikDurumuAd;
            aBaslangic.InnerText = ": " + bilgi.askerlikBaslamaTarihi.ToString();
            aBitis.InnerText = ": " + bilgi.terhisTarihi.ToString();
            aSube.InnerText = ": " + bilgi.askerlikSubesi;
            aIntikal.InnerText = ": " + bilgi.ibrazIntikalTarihi.ToString();
            aSinif.InnerText = ": " + bilgi.sinifAd;
            aBelgeNo.InnerText = ": " + bilgi.belgeNo;
            aBelgeTarihi.InnerText = ": " + bilgi.belgeTarihi.ToString();
            aSayilmayanGun.InnerText = ": " + bilgi.sayilmayanGunSayisi.ToString();
            aAciklama.InnerText = ": " + bilgi.aciklama;
            aNasp.InnerText = ": " + bilgi.astegmenNaspTarihi;
        }

        public void NufusListele(object sender, EventArgs e)
        {
            ShowHide(false);
            nufus.Visible = true;
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.IKY.PersonelNufus bilgi = servisIKY.PersonelNufusListele(kul, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
            nCinsiyet.InnerText = ": " + TNS.IKY.Arac.CinsiyetAdBul(bilgi.cinsiyeti);
            nCSeriNo.InnerText = ": " + bilgi.cuzdanSeriNo;
            nBabaAd.InnerText = ": " + bilgi.babaAd;
            nAnaAd.InnerText = ": " + bilgi.anaAd;
            nDogumTarihi.InnerText = ": " + bilgi.dogumTarihi.ToString();
            nDogumYeri.InnerText = ": " + bilgi.dogumYeri;
            nMedeniHal.InnerText = ": " + bilgi.medeniHaliAd;
            nDin.InnerText = ": " + bilgi.dini;
            nIl.InnerText = ": " + bilgi.ilAd;
            nIlce.InnerText = ": " + bilgi.ilceAd;
            nMahalle.InnerText = ": " + bilgi.nufusMahalleKoy;
            nCilt.InnerText = ": " + bilgi.nufusCiltNo + " / " + bilgi.nufusAileSiraNo;
            //nAileNo.InnerText = ": " + bilgi.nufusAileSiraNo;
            //nBireyNo.InnerText = bilgi.n;
            nCuzdanVerYer.InnerText = ": " + bilgi.cuzdanVerildigiYer;
            nCuzdanVerNeden.InnerText = ": " + bilgi.cuzdanVerilisNedeni;
            nCuzdanVerTarih.InnerText = ": " + bilgi.cuzdanVerilisTarihi.ToString();
            nKayitNo.InnerText = ": " + bilgi.cuzdanKayitNo;
        }

        public void OgrenimListele(object sender, EventArgs e)
        {
            ShowHide(false);
            ogrenim.Visible = true;
            pnlOgrenim.Text = "";
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.IKY.PersonelOgrenim ogr = new TNS.IKY.PersonelOgrenim();
            ogr.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            ObjectArray listeler = servisIKY.PersonelOgrenimListele(kul, ogr);
            if (listeler.objeler.Count > 0)
            {
                string liste = "", sinif = "";
                int cnt = 1;
                foreach (TNS.IKY.PersonelOgrenim o in listeler.objeler)
                {
                    if (cnt % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    liste = "<div class=\"panel " + sinif + " tab-pane fade in active\"> "
                    + "   <div class=\"panel-heading\"> "
                    + "       <h3 class=\"panel-title\"> "
                    + "            <b>" + o.ogrenimAdi + "</b> "
                    + "    </h3>"
                    + " </div>"
                    + "   <div class=\"panel-body\"> "
                    + "       <table class=\"table table-condensed\">    "
                    + "         <tbody> "
                    + "            <tr><td class=\"hucre\">Okul Adı</td><td>: " + o.okulAdi + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Bitirme Tarihi</td><td>: " + o.belgeTarihi.ToString() + "</td></tr> "
                    + "         </tbody> "
                    + "    </table> "
                    + " </div> "
                    + " </div>";

                    pnlOgrenim.Text += liste;
                    cnt++;
                }
            }
        }

        public void AileListele(object sender, EventArgs e)
        {
            ShowHide(false);
            aile.Visible = true;
            pnlAile.Text = "";
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            ObjectArray listeler = servisIKY.PersonelAileListele(kul, 0, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), null, null, null, 0);
            if (listeler.objeler.Count > 0)
            {
                string liste = "", yukumlu = "", sinif = "";
                int cnt = 1;
                foreach (TNS.IKY.PersonelAile a in listeler.objeler)
                {
                    yukumlu = "";
                    if (a.bakmaklaYukumlu == 1)
                        yukumlu = "✓";

                    if (cnt % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    liste = "<div class=\"panel " + sinif + " tab-pane fade in active\"> "
                    + "   <div class=\"panel-heading\"> "
                    + "       <h3 class=\"panel-title\"> "
                    + "            <b>" + TNS.IKY.Arac.YakinlikAd(a.yakinlik) + "</b> "
                    + "    </h3>"
                    + " </div>"
                    + "   <div class=\"panel-body\"> "
                    + "       <table class=\"table table-condensed\">    "
                    + "         <tbody> "
                    + "            <tr><td class=\"hucre\">Ad Soyad</td><td>: " + a.ad + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Öğrenim Bilgisi</td><td>: " + a.ogrenimAd + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Durumu</td><td>: " + a.durumAd + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Bakmakla Yükümlü</td><td>: " + yukumlu + "</td></tr> "
                    + "         </tbody> "
                    + "    </table> "
                    + " </div> "
                    + " </div>";

                    pnlAile.Text += liste;

                    cnt++;
                }

            }
        }

        public void KursListele(object sender, EventArgs e)
        {
            ShowHide(false);
            kurs.Visible = true;
            pnlKurs.Text = "";
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.IKY.PersonelKurs pkurs = new TNS.IKY.PersonelKurs();
            pkurs.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            ObjectArray listeler = servisIKY.PersonelKursListele(kul, pkurs);
            if (listeler.objeler.Count > 0)
            {
                string liste = "", sinif = "";
                int cnt = 1;
                foreach (TNS.IKY.PersonelKurs k in listeler.objeler)
                {
                    if (cnt % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    liste = "<div class=\"panel " + sinif + " tab-pane fade in active\"> "
                    + "   <div class=\"panel-heading\"> "
                    + "       <h3 class=\"panel-title\"> "
                    + "            <b>" + k.bitirmeTarihi.Yil + "</b> "
                    + "    </h3>"
                    + " </div>"
                    + "   <div class=\"panel-body\"> "
                    + "       <table class=\"table table-condensed\">    "
                    + "         <tbody> "
                    + "            <tr><td class=\"hucre\">Kurs Adı</td><td>: " + k.kursAdi + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Aldığı Yer</td><td>: " + k.aldigiYer + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Başlama Tarihi</td><td>: " + k.baslamaTarihi.ToString() + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Bitirme Tarihi</td><td>: " + k.bitirmeTarihi.ToString() + "</td></tr> "
                    + "         </tbody> "
                    + "    </table> "
                    + " </div> "
                    + " </div>";

                    pnlKurs.Text += liste;
                    cnt++;
                }
            }
        }

        public void DilListele(object sender, EventArgs e)
        {
            ShowHide(false);
            dil.Visible = true;
            pnlDil.Text = "";
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.IKY.PersonelDil pdil = new TNS.IKY.PersonelDil();
            pdil.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            ObjectArray listeler = servisIKY.PersonelDilListele(kul, pdil);
            if (listeler.objeler.Count > 0)
            {
                string liste = "", sinif = "";
                int cnt = 1;
                foreach (TNS.IKY.PersonelDil d in listeler.objeler)
                {
                    if (cnt % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    liste = "<div class=\"panel " + sinif + " tab-pane fade in active\"> "
                    + "   <div class=\"panel-heading\"> "
                    + "       <h3 class=\"panel-title\"> "
                    + "            <b>" + d.dilAdi + "</b> "
                    + "    </h3>"
                    + " </div>"
                    + "   <div class=\"panel-body\"> "
                    + "       <table class=\"table table-condensed\">    "
                    + "         <tbody> "
                    + "            <tr><td class=\"hucre\">Dil Seviyesi</td><td>: " + d.dilSeviyesi + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Sınav Türü</td><td>: " + d.belgeAdi + "</td></tr> "
                     + "            <tr><td class=\"hucre\">Sınav Düzeyi</td><td>: " + d.duzey + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Başlangıç Tarihi</td><td>: " + d.tarih.ToString() + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Sınav Puanı</td><td>: " + d.puan + "</td></tr> "
                    + "         </tbody> "
                    + "    </table> "
                    + " </div> "
                    + " </div>";

                    pnlDil.Text += liste;
                    cnt++;
                }
            }
        }

        public void TakdirCezaListele(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;
            bool takdirMi = false, cezaMi = false;
            if (link == null)
            {
                takdirMi = true;
                cezaMi = true;
            }
            else
                if (link.ID == "lnkTakdir")
                    takdirMi = true;
                else
                    cezaMi = true;

            ShowHide(false);
            takdir.Visible = takdirMi;
            ceza.Visible = cezaMi;
            pnlTakdir.Text = "";
            pnlCeza.Text = "";
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.IKY.PersonelCezaOdul takcez = new TNS.IKY.PersonelCezaOdul();
            takcez.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            if (takdirMi && !cezaMi)
                takcez.cezaOdulTipiKayitKodu = "30.00001";
            if (cezaMi && !takdirMi)
                takcez.cezaOdulTipiKayitKodu = "30.00002";

            ObjectArray listeler = servisIKY.PersonelCezaOdulListele(kul, takcez);
            if (listeler.objeler.Count > 0)
            {
                string liste = "", listeT = "", listeC = "", sinif = "";
                int cntT = 1, cntC = 1;
                foreach (TNS.IKY.PersonelCezaOdul co in listeler.objeler)
                {
                    liste = "";
                    string kayitKod = "";
                    if (!string.IsNullOrWhiteSpace(co.cezaOdulTipiKayitKodu))
                    {
                        string[] c = co.cezaOdulTipiKayitKodu.Split('.');
                        if (c.Length > 1)
                            kayitKod = c[0] + "." + c[1];
                    }

                    if (kayitKod == "30.00001")
                    {
                        if (cntT % 2 == 0)
                            sinif = "panel-success";
                        else
                            sinif = "panel-info";
                    }
                    else if (kayitKod == "30.00002")
                    {
                        if (cntC % 2 == 0)
                            sinif = "panel-success";
                        else
                            sinif = "panel-info";
                    }

                    liste = "<div class=\"panel " + sinif + " tab-pane fade in active\"> "
                    + "   <div class=\"panel-heading\"> "
                    + "       <h3 class=\"panel-title\"> "
                    + "            <b>" + co.cezaOdulTipiAdi + "</b> "
                    + "    </h3>"
                    + " </div>"
                    + "   <div class=\"panel-body\"> "
                    + "       <table class=\"table table-condensed\">    "
                    + "         <tbody> "
                    + "            <tr><td class=\"hucre\">Verilen Tarih</td><td>: " + co.tarih.ToString() + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Veren Kurum</td><td>: " + co.verenKurum + "</td></tr> "
                    + "            <tr><td class=\"hucre\">Veren Unvanı</td><td>: " + co.verenUnvani + "</td></tr> "
                    + "         </tbody> "
                    + "    </table> "
                    + " </div> "
                    + " </div>";

                    if (kayitKod == "30.00001")
                    {
                        listeT += liste;
                        cntT++;
                    }

                    else if (kayitKod == "30.00002")
                    {
                        listeC += liste;
                        cntC++;
                    }
                }

                pnlTakdir.Text = listeT;
                pnlCeza.Text = listeC;
            }
        }

        public void HizmetListele(object sender, EventArgs e)
        {
            ShowHide(false);
            pnlHizmet.Text = "";
            hizmet.Visible = true;
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.IKY.PersonelKadro kadro = new TNS.IKY.PersonelKadro();
            kadro.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            ObjectArray listeler = servisIKY.PersonelKadroListele(kul, kadro, false);
            if (listeler.objeler.Count > 0)
            {
                string liste = "";
                int cnt = 1;
                foreach (TNS.IKY.PersonelKadro k in listeler.objeler)
                {
                    string sinif = "";

                    if (cnt % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    liste = "<div class=\"panel " + sinif + " tab-pane fade in active\"> "
                    + "   <div class=\"panel-heading\"> "
                    + "       <h3 class=\"panel-title\"> "
                    + "            <b>" + k.unvanAd + "</b> "
                    + "    </h3>"
                    + " </div>"
                    + "   <div class=\"panel-body\"> "
                    + "       <table class=\"table table-condensed\">    "
                    + "         <tbody> "
                    //+ " <tr><td class=\"hucre\">Unvanı</td><td>: " + k.unvanAd + "</td></tr> "
                    + " <tr><td class=\"hucre\">Memuriyeti</td><td>: " + k.gorevYeri + "</td></tr> "
                    + " <tr><td class=\"hucre\">Başlangıç Sebebi</td><td>: " + k.hizmetSebebiAd + "</td></tr> "
                    + " <tr><td class=\"hucre\">Başlama Tarihi</td><td>: " + k.atamaTarihi + "</td></tr> "
                    + " <tr><td class=\"hucre\">Bitiş Sebebi</td><td>: " + k.ayrilmaGerekcesiAd + "</td></tr> "
                    + " <tr><td class=\"hucre\">Bitiş Tarihi</td><td>: " + k.ayrilmaTarihi + "</td></tr> "
                    + " <tr><td class=\"hucre\">Kadro Derece/Kademe/Ek Göst.</td><td>: " + k.kadroDerece + "/" + k.kazanilmisHakKademe + "/" + k.kazanilmisEkGosterge + "</td></tr> "
                    + " <tr><td class=\"hucre\">Kaz. Derece/Kademe/Ek Göst.</td><td>: " + k.kazanilmisHakDerece + "/" + k.kazanilmisHakKademe + "/" + k.kazanilmisEkGosterge + "</td></tr> "
                    + " <tr><td class=\"hucre\">Em. Derece/Kademe/Ek Göst.</td><td>: " + k.emekliyeEsasDerece + "/" + k.emekliyeEsasKademe + "/" + k.emekliyeEsasEkGosterge + "</td></tr> "
                    + " </tbody> "
                    + " </table> "
                    + " </div> "
                    + " </div>";

                    pnlHizmet.Text += liste;
                    cnt++;
                }
            }
        }

        public void MemuriyetListele(object sender, EventArgs e)
        {
            ShowHide(false);
            memuriyet.Visible = true;
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            ObjectArray dler = servisIKY.HizmetleriGetir(kul, "", hdnKod.Value.ToString(), "", null, 0, "",-1);

            if (dler.objeler.Count > 0)
            {
                TNS.IKY.Hizmet d = (TNS.IKY.Hizmet)dler.objeler[0];

                mTC.InnerText = ": " + d.guncelHizmet.personelTC;
                mSicil.InnerText = ": " + d.guncelHizmet.personelSicil;
                if (d.guncelHizmet.memuriyeteBasladigiTarih.Year == 1)
                    mIlkT.InnerText = ": ";
                else
                    mIlkT.InnerText = ": " + d.guncelHizmet.memuriyeteBasladigiTarih.ToShortDateString();
                if (d.guncelHizmet.kurumaBasladigiTarih.Year == 1)
                    mKurumT.InnerText = ": ";
                else
                    mKurumT.InnerText = ": " + d.guncelHizmet.kurumaBasladigiTarih.ToShortDateString();
                if (d.guncelHizmet.kadroyaGectigiTarih.Year == 1)
                    mKadroT.InnerText = ": ";
                else
                    mKadroT.InnerText = ": " + d.guncelHizmet.kadroyaGectigiTarih.ToShortDateString();
                mMemuriyetSure.InnerText = ": " + TNS.IKY.Hizmet.YilDondur(d.hizmetGunu).ToString();
                mKadroDerece.InnerText = ": " + d.guncelHizmet.kadroDerece.ToString();
                mEkGosterge.InnerText = ": " + d.guncelHizmet.ekGosterge.ToString();
                mKHA.InnerText = ": " + d.guncelHizmet.kDerece.ToString() + "/" + d.guncelHizmet.kKademe.ToString();
                mEKEA.InnerText = ": " + d.guncelHizmet.eDerece.ToString() + "/" + d.guncelHizmet.eKademe.ToString();
                mGeldigiKurum.InnerText = ": " + d.guncelHizmet.geldigiKurum;
            }
        }

        public void TümBilgileriListele(object sender, EventArgs e)
        {
            NufusListele(null, null);
            IletisimListele(null, null);
            if (lnkAskerlik.Visible)
                AskerlikListele(null, null);
            AileListele(null, null);
            OgrenimListele(null, null);
            DilListele(null, null);
            KursListele(null, null);
            MemuriyetListele(null, null);
            TakdirCezaListele(null, null);
            HizmetListele(null, null);

            ShowHide(true);
        }

        protected void ShowHide(bool ac)
        {
            ozluk.Visible = ac;
            nufus.Visible = ac;
            adres.Visible = ac;
            askerlik.Visible = ac;
            ogrenim.Visible = ac;
            aile.Visible = ac;
            kurs.Visible = ac;
            dil.Visible = ac;
            hizmet.Visible = ac;
            takdir.Visible = ac;
            ceza.Visible = ac;
            memuriyet.Visible = ac;
        }
    }
}