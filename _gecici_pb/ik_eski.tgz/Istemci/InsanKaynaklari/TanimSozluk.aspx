﻿<%@ Page Language="C#" CodeBehind="TanimSozluk.aspx.cs" Inherits="InsanKaynaklari.TanimSozluk" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="ANAKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="KAYITAD" />
                    <ext:RecordField Name="KISAAD" />
                    <ext:RecordField Name="SEVIYE" />
                    <ext:RecordField Name="HITAPID" />
                    <ext:RecordField Name="ANAKAYITAD" />
                    <ext:RecordField Name="AKOD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
        <AutoLoadParams>
            <ext:Parameter Name="start" Value="0" Mode="Raw" />
            <ext:Parameter Name="limit" Value="25" Mode="Raw" />
        </AutoLoadParams>
    </ext:Store>
    <ext:Store ID="anaKayitStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center MarginsSummary="104 20 10 20">
                    <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                        Icon="Disk">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                        Icon="Delete" Hidden="true">
                                        <DirectEvents>
                                            <Click OnEvent="btnSil_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnAra" runat="server" Text="Bul" Icon="Find">
                                        <DirectEvents>
                                            <Click OnEvent="btnAra_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                        Icon="PageWhite">
                                        <DirectEvents>
                                            <Click OnEvent="btnTemizle_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="BorderLayout2" runat="server">
                                <Center>
                                    <ext:FormPanel ID="FormPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                                        AutoHeight="true">
                                        <Items>
                                            <ext:ComboBox runat="server" ID="ddlAna" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPTS001 %>"
                                                NoteAlign="Top" Width="200" DisplayField="AD" ValueField="KOD" StoreID="anaKayitStore"
                                                TriggerAction="All" Mode="Local" ForceSelection="true">
                                            </ext:ComboBox>
                                            <ext:TextField runat="server" ID="txtKayitKodu" Width="140" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPTS002 %>"
                                                NoteAlign="Top" ReadOnly="true" />
                                            <ext:TextField runat="server" ID="txtKayitAdi" Width="140" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPTS003 %>"
                                                NoteAlign="Top" />
                                            <ext:TextField runat="server" ID="txtKisaAdi" Width="140" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPTS004 %>" NoteAlign="Top" />
                                            <ext:TextField runat="server" ID="txtSeviye" Width="140" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPTS006 %>" NoteAlign="Top"
                                                ReadOnly="true" />
                                            <ext:TextField runat="server" ID="txtHitapId" Width="140" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPTS007 %>" NoteAlign="Top" />
                                        </Items>
                                    </ext:FormPanel>
                                </Center>
                                <West Split="true">
                                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                        StoreID="ListeStore" Border="true" Layout="FitLayout" Width="400">
                                        <ColumnModel ID="ColumnModel1" runat="server">
                                            <Columns>
                                                <ext:Column DataIndex="KOD" Header="Kod" Hidden="true" />
                                                <ext:Column DataIndex="ANAKAYITAD" Header="Ana Kayıt"/>
                                                <ext:Column DataIndex="KAYITKOD" Header="Kayıt Kod" />
                                                <ext:Column DataIndex="KAYITAD" Header="Kayıt Adı" />
                                                <ext:Column DataIndex="KISAAD" Header="Kısa Adı" />
                                                <ext:Column DataIndex="SEVIYE" Header="Seviye" Hidden="true" />
                                                <ext:Column DataIndex="HITAPID" Header="Hitap Id" Hidden="true" />
                                            </Columns>
                                        </ColumnModel>
                                        <SelectionModel>
                                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                                <DirectEvents>
                                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                                        <ExtraParams>
                                                            <ext:Parameter Name="kod" Value="this.getSelected().data.KOD" Mode="Raw" />
                                                            <ext:Parameter Name="anaKod" Value="this.getSelected().data.ANAKOD" Mode="Raw" />
                                                            <ext:Parameter Name="kayitKod" Value="this.getSelected().data.KAYITKOD" Mode="Raw" />
                                                            <ext:Parameter Name="kayitAd" Value="this.getSelected().data.KAYITAD" Mode="Raw" />
                                                            <ext:Parameter Name="kisaAd" Value="this.getSelected().data.KISAAD" Mode="Raw" />
                                                            <ext:Parameter Name="seviye" Value="this.getSelected().data.SEVIYE" Mode="Raw" />
                                                            <ext:Parameter Name="hitapId" Value="this.getSelected().data.HITAPID" Mode="Raw" />
                                                            <ext:Parameter Name="aKod" Value="this.getSelected().data.AKOD" Mode="Raw" />
                                                        </ExtraParams>
                                                    </RowSelect>
                                                </DirectEvents>
                                            </ext:RowSelectionModel>
                                        </SelectionModel>
                                        <BottomBar>
                                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                                            </ext:PagingToolbar>
                                        </BottomBar>
                                    </ext:GridPanel>
                                </West>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
