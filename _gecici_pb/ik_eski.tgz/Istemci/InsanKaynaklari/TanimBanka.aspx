﻿<%@ Page Language="C#" CodeBehind="TanimBanka.aspx.cs" Inherits="InsanKaynaklari.TanimBanka" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="BANKAKODU" />
                    <ext:RecordField Name="BANKAADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center MarginsSummary="104 20 10 20">
                    <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                        Icon="Disk">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="<%$ Resources:InsanKaynaklari,FRMORT079 %>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                        Icon="Delete">
                                        <DirectEvents>
                                            <Click OnEvent="btnSil_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                                    Title="<%$ Resources:InsanKaynaklari,FRMORT079 %>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnAra" runat="server" Text="<%$ Resources:InsanKaynaklari,FRMPTB001 %>" Icon="Find">
                                        <DirectEvents>
                                            <Click OnEvent="btnAra_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                        Icon="PageWhite">
                                        <DirectEvents>
                                            <Click OnEvent="btnTemizle_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="BorderLayout2" runat="server">
                                <North>
                                    <ext:FormPanel ID="FormPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                                        AutoHeight="true">
                                        <Items>
                                            <ext:TextField runat="server" ID="txtBankaKodu" Width="140" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPTB002 %>"
                                                NoteAlign="Top" />
                                            <ext:TextField runat="server" ID="txtBankaAdi" Width="140" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPTB003 %>"
                                                NoteAlign="Top" />
                                        </Items>
                                    </ext:FormPanel>
                                </North>
                                <Center Split="true">
                                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                        StoreID="ListeStore" Border="true" AutoExpandColumn="BANKAADI" Layout="FitLayout"
                                        Width="400">
                                        <ColumnModel ID="ColumnModel1" runat="server">
                                            <Columns>
                                                <ext:Column DataIndex="BANKAKODU" Header="<%$ Resources:InsanKaynaklari,FRMPTB002 %>" />
                                                <ext:Column DataIndex="BANKAADI" Header="<%$ Resources:InsanKaynaklari,FRMPTB003 %>" />
                                            </Columns>
                                        </ColumnModel>
                                        <SelectionModel>
                                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                                <DirectEvents>
                                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                                        <ExtraParams>
                                                            <ext:Parameter Name="bankaKodu" Value="this.getSelected().data.BANKAKODU" Mode="Raw" />
                                                            <ext:Parameter Name="bankaAdi" Value="this.getSelected().data.BANKAADI" Mode="Raw" />
                                                        </ExtraParams>
                                                    </RowSelect>
                                                </DirectEvents>
                                            </ext:RowSelectionModel>
                                        </SelectionModel>
                                        <BottomBar>
                                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                                            </ext:PagingToolbar>
                                        </BottomBar>
                                    </ext:GridPanel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
