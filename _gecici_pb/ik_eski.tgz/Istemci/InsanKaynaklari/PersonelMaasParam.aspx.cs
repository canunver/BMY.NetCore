﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Memuriyet Sınıfı
    /// </summary>
    public partial class PersonelMaasParam : istemciUzayi.GenelSayfa
    {
        public string personelTCKimlikNo = "";
        public IIKYServis servis = null;
        List<IntKodStrAd> l = new List<IntKodStrAd>();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            personelTCKimlikNo = GenelIslemlerIstemci.RequestBul(this, "tcKimlikNo", "").Trim();
            servis = TNS.IKY.Arac.Tanimla();
            //if (!TNS.PER.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.Personel.FRMGNL008);
            //    personelTCKimlikNo = "";
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.Personel.FRMGNL007);

            if (!IsPostBack)
            {
                formAdi = "Maaş parametreleri";
                SayfaUstAltBolumYaz(this);
                txtYil.Number = DateTime.Now.Year;

                ArrayList al = new ArrayList();
                for (int i = 1; i <= TNS.IKY.PersonelMaasMatrah.matrahTurAdlar.Length; i++)
                {
                    al.Add(new IntKodStrAd(i, PersonelMaasMatrah.MatrahTurAd(i)));
                }
                stoMatrahTur.DataSource = al;
                stoMatrahTur.DataBind();

                TNS.IKY.Arac.SendikaListesi = null;

                Hashtable ht = TNS.IKY.Arac.SendikaListesi;
                foreach (SendikaBilgi item in ht.Values)
                {
                    l.Add(new IntKodStrAd(item.sendikaNo, item.sendikaAd));
                }
                if (l.Count > 0)
                {
                    l.Add(new IntKodStrAd(0, "-"));
                    l.Sort();
                    stoSendikalar.DataSource = l;
                    stoSendikalar.DataBind();
                    SendikaBilgiOku();
                }
                else
                    frmSendika.Hidden = true;
                Listele();
            }
        }

        private void SendikaBilgiOku()
        {
            ObjectVAN ov = servis.OkuKisiSendikaBilgi(kullanan, personelTCKimlikNo);
            if (ov.o == null) ov.o = new SendikaBilgi();
            SendikaBilgi sb = (SendikaBilgi)ov.o;
            cmbSendikalar.Value = sb.sendikaNo;
            tfSenKesOran.Value = sb.kesintiOrani.ToString("0.000");
        }

        private void Listele()
        {
            TNS.IKY.PersonelMaasParam maasParam = servis.MaasParamListele(kullanan, personelTCKimlikNo, Convert.ToInt32(txtYil.Number));
            stoGelirler.DataSource = maasParam.paramlar;
            stoGelirler.DataBind();

            stoMatrahlar.DataSource = maasParam.matrahlar;
            stoMatrahlar.DataBind();
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Memuriyet bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSendikaKaydet_Click(object sender, DirectEventArgs e)
        {
            TNSCollection kisiler = new TNSCollection();

            ObjectArray oa = servis.PersonelListele(kullanan, new TNS.IKY.Personel() { tcKimlikNo = personelTCKimlikNo }, false, true);
            Sonuc s;
            if (oa.sonuc.islemSonuc && oa.ObjeSayisi > 0)
            {
                kisiler.Add(((TNS.IKY.Personel)oa.objeler[0]).kod);
                s = servis.PersonelSendikayaEkle(kullanan, OrtakFonksiyonlar.ConvertToInt(cmbSendikalar.Value, 0), kisiler, OrtakFonksiyonlar.ConvertToDouble(tfSenKesOran.Value), false);
            }
            else
            {
                if (oa.sonuc.islemSonuc)
                    oa.sonuc.DegerAta("Aranan personel bulunamadı!");
                s = oa.sonuc;
            }
            if (s.islemSonuc)
            {
                stoGelirler.CommitChanges();
                GenelIslemler.MesajKutusu("Sonuç", "Sendika bilgisi kaydedildi");
            }
            else
                GenelIslemler.MesajKutusu("Hata", "Sendika bilgisi kaydedilenedi: " + s.hataStr);
        }


        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Memuriyet bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnKaydetGelirler_Click(object sender, DirectEventArgs e)
        {
            TNSCollection kisiler = new TNSCollection();
            TNS.IKY.Personel per = new TNS.IKY.Personel();
            per.tcKimlikNo = personelTCKimlikNo;
            per.personelMaasParam = new TNS.IKY.PersonelMaasParam();

            per.personelMaasParam.paramlar = new TNSCollection((MaasParam[])Ext.Net.JSON.Deserialize(e.ExtraParams["satirlar"], typeof(MaasParam[])));
            kisiler.Add(per);

            Sonuc s = servis.MaasParamKaydet(kullanan, kisiler, null);
            if (s.islemSonuc)
            {
                stoGelirler.CommitChanges();
                GenelIslemler.MesajKutusu("Sonuç", "Kayıt başarılı");
            }
            else
                GenelIslemler.MesajKutusu("Hata", s.hataStr);
        }

        protected void btnKaydetMatrah_Click(object sender, DirectEventArgs e)
        {
            TNSCollection matrahlarTum = new TNSCollection((PersonelMaasMatrah[])Ext.Net.JSON.Deserialize(e.ExtraParams["satirlar"], typeof(PersonelMaasMatrah[])));
            TNSCollection matrahlar = new TNSCollection();
            foreach (PersonelMaasMatrah item in matrahlarTum)
            {
                if (item.surecNo == "" || item.surecNo == "000000000")
                {
                    item.yil = Convert.ToInt32(txtYil.Number);
                    item.surecNo = "000000000";
                    item.tcKimlikNo = personelTCKimlikNo;
                    matrahlar.Add(item);
                }
            }

            Sonuc s = servis.MaasMatrahKaydet(kullanan, Convert.ToInt32(txtYil.Number), "000000000", "", matrahlar);
            if (s.islemSonuc)
                GenelIslemler.MesajKutusu("Sonuç", "Kayıt başarılı");
            else
                GenelIslemler.MesajKutusu("Hata", s.hataStr);
        }

        protected void btnListele_Click(object sender, DirectEventArgs e)
        {
            Listele();
        }

        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
            Hashtable raporParam = new Hashtable();
            raporParam["tcKimlikNo"] = personelTCKimlikNo;
            TNS.Raporlama.RaporlamaServis.TekRaporAl(20000, 1, kullanan, null, raporParam, true, false, null);
        }
    }
}
