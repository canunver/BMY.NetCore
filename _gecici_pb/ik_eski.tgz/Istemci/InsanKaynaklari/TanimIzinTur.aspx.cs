﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimIzinTur : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                formAdi = "İzin Tür Bilgileri";
                SayfaUstAltBolumYaz(this);
                ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

                //Sayfaya giriş izni varmı?
                GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

                List<object> liste = Listele(new IzinTur(), this);
                if (liste.Count == 0)
                {
                    GenelIslemler.HataYaz(this, Resources.InsanKaynaklari.FRMTIT005);
                    btnKaydet.Disabled = true;
                }
                ListeStore.DataSource = liste;
                ListeStore.DataBind();
                gorulebilirlikDoldur();
            }
        }

        public static List<object> Listele(IzinTur kriter, System.Web.UI.Page p)
        {
            IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            ObjectArray dler = servisIKY.IzinTurListele(kriter);
            if (dler == null)
            {
                return null;
            }
            List<object> tipler = new List<object>();

            if (!dler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(p, dler.sonuc.hataStr);
                return tipler;
            }

            foreach (TNS.IKY.IzinTur d in dler.objeler)
                tipler.Add(new
                {
                    KODU = d.kod,
                    ADI = d.ad,
                    SURE = d.sure,
                    GORULEBILIRLIK = d.gorulebilirlik,
                    GORULEBILIRLIKTEXT = Resources.InsanKaynaklari.ResourceManager.GetString("FRMTITG" + d.gorulebilirlik.ToString("d3")),
                    SIRA = d.sira,
                    KODVESURE = d.kod + ";" + d.sure
                });

            return tipler;
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            IzinTur d = new IzinTur();
            d.ad = txtIzinTurAdi.Text.Trim();
            d.sure = OrtakFonksiyonlar.ConvertToInt(txtSure.Text, 0);
            d.gorulebilirlik = OrtakFonksiyonlar.ConvertToInt(cmbGorulebilirlik.Value, 0);
            d.sira = OrtakFonksiyonlar.ConvertToInt(txtSira.Text.Trim(), 0);
            ListeStore.DataSource = Listele(d, this);
            ListeStore.DataBind();
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Arac.izinTipListesi = null;

            IzinTur d = new IzinTur();
            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnIzinTurKodu.Value, 0);
            d.ad = txtIzinTurAdi.Text;
            d.sure = OrtakFonksiyonlar.ConvertToInt(txtSure.Text, 0);
            d.gorulebilirlik = OrtakFonksiyonlar.ConvertToInt(cmbGorulebilirlik.Value, 1);
            d.sira = OrtakFonksiyonlar.ConvertToInt(txtSira.Text.Trim(), 0);

            Sonuc sonuc = servisIKY.IzinTurKaydet(kullanan, d);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                ListeStore.DataSource = Listele(new IzinTur(), this);
                ListeStore.DataBind();
                GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            }
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            IzinTur d = new IzinTur();
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnIzinTurKodu.Value, 0);

            if (kod > 0)
            {
                d.kod = kod;
                Sonuc sonuc = servisIKY.IzinTurSil(kullanan, d);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    Temizle();
                    ListeStore.DataSource = Listele(new IzinTur(), this);
                    ListeStore.DataBind();
                    GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
                }
            }
            else
                GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz öğrenim Bilgisini seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            ListeStore.DataSource = Listele(new IzinTur(), this);
            ListeStore.DataBind();
            Temizle();
        }

        void Temizle()
        {
            txtIzinTurAdi.Clear();
            txtSure.Clear();
            cmbGorulebilirlik.Clear();
            txtSira.Clear();
            hdnIzinTurKodu.Clear();
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            hdnIzinTurKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["KODU"]);
            txtIzinTurAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["ADI"]);
            txtSure.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["SURE"]);
            cmbGorulebilirlik.SetValueAndFireSelect(OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["GORULEBILIRLIK"]));
            txtSira.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["SIRA"]);
        }

        public void gorulebilirlikDoldur()
        {
            for (int i = 1; true; i++)
            {
                string ad = Resources.InsanKaynaklari.ResourceManager.GetString("FRMTITG" + i.ToString("d3"));
                if (string.IsNullOrEmpty(ad)) break;
                cmbGorulebilirlik.Items.Add(new ListItem(ad, i.ToString()));
            }
        }

        [Ext1.Net.DirectMethod]
        public static string IzinDonemBul(int yil)
        {
            return TNS.IKY.IzinArac.DonemAdBul(yil);
        }
    }
}
