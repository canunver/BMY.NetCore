﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class LojmanSiteBlokDaireForm : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.LojmanSite060;
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
           
            if (!IsPostBack)
            {
                ddlSite.SelectedItem.Value = (Request.QueryString["siteKod"] + "").Trim();
                ddlBlok.SelectedItem.Value = (Request.QueryString["blokKod"] + "").Trim();
                Listele();
                Genel.LojmanSiteDoldur(kullanan, ddlSite, siteStore);
                Genel.LojmanSiteBlokDoldur(kullanan, ddlBlok, blokStore, OrtakFonksiyonlar.ConvertToInt(ddlSite.SelectedItem.Value, 0));
                Genel.SozlukDoldur(ddldaireTuru, daireTuruStore, OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.DAIRETURU, 0).ToString().PadLeft(2, '0'), false);
            }
        }

        protected void Listele()
        {
            ObjectArray oa = servis.LojmanSiteBlokDaireListele(kullanan, new LojmanSiteBlokDaire { blokKod = OrtakFonksiyonlar.ConvertToInt(ddlBlok.SelectedItem.Value, 0) });
            if (!oa.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, oa.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite002);
            stoLojmanBlokDaireListe.DataSource = oa.objeler;
            stoLojmanBlokDaireListe.DataBind();
        }

        void Oku()
        {
            LojmanSiteBlokDaire form = new LojmanSiteBlokDaire();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
            ObjectVAN ov = servis.LojmanSiteBlokDaireOku(kullanan, form);
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                form = (LojmanSiteBlokDaire)ov.o;
                txtKod.Text = form.kod.ToString();
                //ddlSite.Value = form.siteKod;
                //ddlBlok.Value = form.blokKod;
                ddldaireTuru.Text = form.daireTuru.ToString();
                txtDaireNo.Text = form.daireNo.ToString();
                txtmetrekare.Text = form.metrekare.ToString();
                txtsuNo.Text = form.suNo.ToString();
                txtelekNo.Text = form.elektrikNo.ToString();
                txtDogNo.Text = form.dogalgazNo.ToString();
                txtCevNo.Text = form.cevtemNo.ToString();
                txtDahiliTel.Text = form.dahiliTel;
            }
            else if (!ov.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite002);
        }

        void Kaydet(DirectEventArgs e)
        {
            LojmanSiteBlokDaire form = new LojmanSiteBlokDaire();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
            form.siteKod = OrtakFonksiyonlar.ConvertToInt(ddlSite.SelectedItem.Value, 0);
            form.blokKod = OrtakFonksiyonlar.ConvertToInt(ddlBlok.SelectedItem.Value, 0);
            form.daireTuru = OrtakFonksiyonlar.ConvertToInt(ddldaireTuru.SelectedItem.Value, 0);
            form.metrekare = OrtakFonksiyonlar.ConvertToInt(txtmetrekare.Text, 0);
            form.suNo = OrtakFonksiyonlar.ConvertToInt(txtsuNo.Text, 0);
            form.elektrikNo = OrtakFonksiyonlar.ConvertToInt(txtelekNo.Text, 0);
            form.dogalgazNo = OrtakFonksiyonlar.ConvertToInt(txtDogNo.Text, 0);
            form.cevtemNo = OrtakFonksiyonlar.ConvertToInt(txtCevNo.Text, 0);
            form.dahiliTel = txtDahiliTel.Text;
            form.daireNo = OrtakFonksiyonlar.ConvertToInt(txtDaireNo.Text, 0);
            Sonuc sonuc = servis.LojmanSiteBlokDaireKaydet(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite003);
                Listele();
            }
        }

        /// <summary>
        /// Lojman Site kodu olarak verilen değeri, txtkod alanına atar ve okuma işlemini çağırır.
        /// </summary>
        /// <param name="kod">Personel tipi kodu </param>
        [DirectMethod]
        public void Goster(int kod)
        {
            txtKod.Text = kod.ToString();
            Oku();
        }

        /// <summary>
        /// Listele tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnOku_Click(object sender, DirectEventArgs e)
        {
            Oku();
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        /// <summary>
        /// Yazdir tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
        }

        /// <summary>
        /// Yeni tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYeni_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        /// <summary>
        /// Sil tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtKod.Text))
            {
                GenelIslemler.BilgiYaz(this, "Silmek istediğiniz daireyi seçiniz.");
                return;
            }
            Sonuc sonuc = servis.LojmanSiteBlokDaireSil(kullanan, OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0));
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite042);
                Listele();
            }
        }

        protected void Temizle()
        {
            txtKod.Clear();
            txtDaireNo.Clear();
            ddldaireTuru.Clear();
            txtmetrekare.Clear();
            txtsuNo.Clear();
            txtDogNo.Clear();
            txtelekNo.Clear();
            txtDahiliTel.Clear();
            txtCevNo.Clear();
        }

    }
}
