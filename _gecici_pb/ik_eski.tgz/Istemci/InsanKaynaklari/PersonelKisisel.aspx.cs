﻿using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;
using TNS.KYM;
using Aspose.Words;
using System.Data;
using System.Collections.Generic;
using System.Text;
using Arac = TNS.DEG.Arac;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Kişisel Sınıfı
    /// </summary>
    public partial class PersonelKisisel : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        IUZYServis servisUZY = TNS.UZY.Arac.Tanimla();
        public int resimGoster;

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnKod.Value = (Request.QueryString["personelKod"] + "").Trim();
            resimGoster = OrtakFonksiyonlar.ConvertToInt(Request.QueryString["resimGoster"], 0);

            if (resimGoster > 0)
            {
                ResimGoster.ResimGosterM(Response, servisIKY, resimGoster, 1, 0, 0);
                return;
            }

            if (!IsPostBack)
            {
                Genel.UnvanDoldur(servisIKY, this, storeUnvan);
                IlYukle();
                Genel.CinsiyetDoldur(ddlCinsiyet, cinsiyetStore);
                MedeniHaliDoldur();
                Temizle();
                if (TNS.IKY.Arac.KVKK())
                    pnlEkBilgi.Hidden = true;

                bool kontrol = false;
                if (!Arac.ManasKullaniyor())
                {
                    //Eğer mernis bağlantısı var ise kontroller kitlensin
                    kontrol = !TNS.KYM.Arac.Tanimla().MernisKontroluYapma();
                }

                txtAd.ReadOnly = kontrol;
                txtSoyad.ReadOnly = kontrol;
                txtBabaAd.ReadOnly = kontrol;
                txtAnaAd.ReadOnly = kontrol;
                txtDogumTarihi.ReadOnly = kontrol;
                txtCuzdanKayitNo.ReadOnly = kontrol;
                txtCuzdanSeriNo.ReadOnly = kontrol;
                txtMahalle.ReadOnly = kontrol;
                txtCiltNo.ReadOnly = kontrol;
                txtSiraNo.ReadOnly = kontrol;
                txtAileSiraNo.ReadOnly = kontrol;
                txtVerilisNedeni.ReadOnly = kontrol;
                txtVerildigiYer.ReadOnly = kontrol;
                txtVerilisTarihi.ReadOnly = kontrol;
                ddlNufusIl.ReadOnly = kontrol;
                ddlNufusIlce.ReadOnly = kontrol;
                txtDogumYeri.ReadOnly = kontrol;
                ddlMedeniHali.ReadOnly = kontrol;

                txtPasaportNo.ReadOnly = false;


                SakatlikDurumuDoldur();
                SosyalGuvenceDoldur();

                if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) > 0)
                    Listele();
                Genel.PersonelTurDoldur(cmbPersonelTip, personelTipStore, null);
                cmbPersonelTip.SelectedItem.Value = "100";

                if (Arac.ManasKullaniyor())
                {
                    txtTCKimlikNo.HideTrigger = true;
                    txtTCKimlikNo.DirectEvents.TriggerClick.Event -= KimlikBilgisiGetir;
                    txtTCKimlikNo.DirectEvents.SpecialKey.Event -= KimlikBilgisiGetir;

                    txtTCKimlikNoDegistir.Visible = true;
                }
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel  bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel tipinde sınıf</param>
        public void Listele()
        {
            txtTCKimlikNo.Editable = true;
            TNS.IKY.Personel kriter = new TNS.IKY.Personel();
            kriter.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            kriter.tarihce = true;
            ObjectArray dler = servisIKY.PersonelListele(kullanan, kriter, true, false);

            if (!dler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
                return;
            }

            if (dler.objeler.Count > 0)
            {
                TNS.IKY.Personel d = (TNS.IKY.Personel)dler.objeler[0];

                txtTCKimlikNo.Text = d.tcKimlikNo;
                //if (!Arac.ManasKullaniyor())
                txtTCKimlikNo.Editable = false;
                txtSicilNo.Text = d.sicilNo;
                txtAd.Text = d.ad;
                txtSoyad.Text = d.soyad;
                lblUnvan.Text = d.unvanAd;
                lblUnvanVekalet.Text = d.unvanVekaletAd;
                lblBirimi.Text = d.birimAd;
                lblGrvYeri.Text = d.kadro.gorevBirimAd;
                lblPersonelTur.Text = d.personelTipAd;
                if (d.kadroBaslangicTarihi.Year != 1)
                    lblKadroBaslangicTarihi.Text = d.kadroBaslangicTarihi.ToShortDateString();

                lblDereceEkGosterge.Text = d.kadro.kadroDerece + "/" + d.kadro.emekliyeEsasEkGosterge;

                if (Arac.ManasKullaniyor())
                {
                    cmbSosyalGuvence.Hide();
                    txtEmekliSicilNo.Hide();
                    txtBagkurSicilNo.Hide();
                    txtAsaletTarihi.Hide();
                    txtArsivNo.Hide();
                    txtGeldigiKurumSicili.Hide();
                    txtVergiDairesi.Hide();
                    txtRumuz.Hide();
                    chkGrpOzelDurum.Hide();
                }
                else
                {
                    cmbSosyalGuvence.SetValueAndFireSelect(d.sosyalGuvence.ToString());
                    txtEmekliSicilNo.Text = d.emekliSicilNo;
                    txtBagkurSicilNo.Text = d.bagkurSicilNo;

                    txtAsaletTarihi.Text = d.asaletTarihi.ToString();
                    txtArsivNo.Text = d.arsivNo;
                    txtGeldigiKurumSicili.Text = d.geldigiKurumSicili;
                    txtVergiDairesi.Text = d.vergiDairesi;
                    txtRumuz.Text = d.rumuz;

                    chkTerorMagduru.Checked = d.terorMagduru > 0;
                    chkHukumlu.Checked = d.hukumlu > 0;
                    chkKorumayaMuhtac.Checked = d.korunmayaMuhtac > 0;
                }

                txtSSKSicilNo.Text = d.sskSicilNo;

                txtIlkIseBaslamaTarihi.Text = d.ilkIseBaslamaTarihi.ToString();
                txtKurumaBaslamaTarihi.Text = d.kurumaBaslamaTarihi.ToString();
                chkAktifMi.Checked = d.aktifMi == 1;
                txtEmail.Text = d.iletisim.eposta;
                txtIbanNo.Text = d.bankaIbanNo;
                txtGeldigiKurum.Text = d.geldigiKurum;

                txtTitr.Text = d.titr;

                cmbSakatlikDurumu.SelectedItem.Value = d.sakatlikDurumu.ToString();
                cmbSakatlikDerece.SetValueAndFireSelect(d.sakatlikDerecesi.ToString());

                imgResim.ImageUrl = d.resimYol;

                ddlCinsiyet.SetValueAndFireSelect((int)d.cinsiyet);

                txtIlkSoyad.Hidden = d.cinsiyet == ENUMCINSIYET.ERKEK;

                txtIlkSoyad.Text = d.ilkSoyad;
                txtBabaAd.Text = d.nufus.babaAd;
                txtAnaAd.Text = d.nufus.anaAd;
                txtDogumTarihi.Text = d.dogumTarihi.ToString();
                txtDogumYeri.Text = d.nufus.dogumYeri;
                ddlMedeniHali.SelectedItem.Value = d.nufus.medeniHali.ToString();
                txtDin.Text = d.nufus.dini;
                ddlKanGrubu.SelectedItem.Value = d.nufus.kanGrubu.ToString();
                txtCuzdanSeriNo.Text = d.nufus.cuzdanSeriNo;
                txtCuzdanKayitNo.Text = d.nufus.cuzdanKayitNo;
                ddlNufusIl.SelectedItem.Value = d.nufus.nufusIlKod;
                ddlNufusIl.SetValueAndFireSelect(d.nufus.nufusIlKod.ToString());
                IlceYukle(d.nufus.nufusIlKod);
                ddlNufusIlce.SelectedItem.Value = d.nufus.nufusIlceKod;
                ddlNufusIlce.SetValueAndFireSelect(d.nufus.nufusIlceKod.ToString());
                txtMahalle.Text = d.nufus.nufusMahalleKoy;
                txtCiltNo.Text = d.nufus.nufusCiltNo;
                txtSiraNo.Text = d.nufus.nufusSiraNo;
                txtAileSiraNo.Text = d.nufus.nufusAileSiraNo;
                txtVerilisNedeni.Text = d.nufus.cuzdanVerilisNedeni;
                txtVerildigiYer.Text = d.nufus.cuzdanVerildigiYer;
                txtVerilisTarihi.Text = d.nufus.cuzdanVerilisTarihi.ToString();
                txtPasaportNo.Text = d.nufus.pasaportNo;

                BelgeListesiDoldur();
            }
        }

        private TNS.IKY.Personel EkrandanAl()
        {
            TNS.IKY.Personel d = new TNS.IKY.Personel();

            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            d.tcKimlikNo = txtTCKimlikNo.Text.Trim();
            d.sicilNo = txtSicilNo.Text.Trim();
            d.ad = txtAd.Text.Trim();
            d.soyad = txtSoyad.Text.Trim();
            d.sosyalGuvence = OrtakFonksiyonlar.ConvertToInt(cmbSosyalGuvence.SelectedItem.Value, 0);
            d.emekliSicilNo = txtEmekliSicilNo.Text.Trim();
            d.sskSicilNo = txtSSKSicilNo.Text.Trim();
            d.bagkurSicilNo = txtBagkurSicilNo.Text.Trim();
            d.ilkIseBaslamaTarihi = Genel.TarihAlaniDegerVer(txtIlkIseBaslamaTarihi);
            d.kurumaBaslamaTarihi = Genel.TarihAlaniDegerVer(txtKurumaBaslamaTarihi);
            d.asaletTarihi = Genel.TarihAlaniDegerVer(txtAsaletTarihi);
            d.arsivNo = txtArsivNo.Text;
            d.aktifMi = chkAktifMi.Checked ? 1 : 0;
            d.geldigiKurum = txtGeldigiKurum.Text;
            d.geldigiKurumSicili = txtGeldigiKurumSicili.Text;
            d.vergiDairesi = txtVergiDairesi.Text;
            d.bankaIbanNo = txtIbanNo.Text;

            d.rumuz = txtRumuz.Text;
            d.titr = txtTitr.Text;

            d.sakatlikDurumu = OrtakFonksiyonlar.ConvertToInt(cmbSakatlikDurumu.SelectedItem.Value, 0);
            d.sakatlikDerecesi = OrtakFonksiyonlar.ConvertToInt(cmbSakatlikDerece.SelectedItem.Value, 0);
            d.terorMagduru = OrtakFonksiyonlar.ConvertToInt(chkTerorMagduru.Checked, 0);
            d.hukumlu = OrtakFonksiyonlar.ConvertToInt(chkHukumlu.Checked, 0);
            d.korunmayaMuhtac = OrtakFonksiyonlar.ConvertToInt(chkKorumayaMuhtac.Checked, 0);

            d.nufus.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            d.nufus.cinsiyeti = (ENUMCINSIYET)OrtakFonksiyonlar.ConvertToInt(ddlCinsiyet.SelectedItem.Value, 0);
            d.nufus.ilkSoyad = txtIlkSoyad.Text.Trim();
            d.nufus.babaAd = txtBabaAd.Text.Trim();
            d.nufus.anaAd = txtAnaAd.Text.Trim();
            d.nufus.dogumTarihi = new TNSDateTime(txtDogumTarihi.SelectedDate);
            d.nufus.dogumYeri = txtDogumYeri.Text;
            d.nufus.medeniHali = OrtakFonksiyonlar.ConvertToInt(ddlMedeniHali.SelectedItem.Value, 0);
            d.nufus.dini = txtDin.Text;
            d.nufus.kanGrubu = Genel.ComboDegerDondur(ddlKanGrubu);
            d.nufus.cuzdanSeriNo = txtCuzdanSeriNo.Text.Trim();
            d.nufus.cuzdanKayitNo = txtCuzdanKayitNo.Text.Trim();
            d.nufus.nufusIlKod = OrtakFonksiyonlar.ConvertToStr(ddlNufusIl.SelectedItem.Value);
            d.nufus.nufusIlceKod = OrtakFonksiyonlar.ConvertToStr(ddlNufusIlce.SelectedItem.Value);
            d.nufus.nufusMahalleKoy = txtMahalle.Text.Trim();
            d.nufus.nufusCiltNo = txtCiltNo.Text.Trim();
            d.nufus.nufusSiraNo = txtSiraNo.Text.Trim();
            d.nufus.nufusAileSiraNo = txtAileSiraNo.Text.Trim();
            d.nufus.cuzdanVerilisNedeni = txtVerilisNedeni.Text.Trim();
            d.nufus.cuzdanVerildigiYer = txtVerildigiYer.Text.Trim();
            d.nufus.cuzdanVerilisTarihi = Genel.TarihAlaniDegerVer(txtVerilisTarihi);
            d.nufus.pasaportNo = txtPasaportNo.Text.Trim();

            if (d.kod == 0)
            {
                d.UNVANKOD = OrtakFonksiyonlar.ConvertToInt(cmbUnvan.Value, 0);
                d.kadro.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
                d.kadro.personelTip = OrtakFonksiyonlar.ConvertToInt(cmbPersonelTip.SelectedItem.Value, 0);
                d.kadro.kadroDerece = OrtakFonksiyonlar.ConvertToInt(txtKadroDerece.Text, 0);
                d.kadro.kadroTarih = new TNSDateTime(DateTime.Now);

                d.kadro.kazanilmisHakDerece = d.kadro.kadroDerece;
                d.kadro.kazanilmisEkGosterge = OrtakFonksiyonlar.ConvertToInt(txtEkGosterge.Text, 0);
                d.kadro.kazanilmisHakKademe = 1;
                d.kadro.kazanilmisHakTarih = d.kadro.kadroTarih;

                d.kadro.emekliyeEsasDerece = d.kadro.kadroDerece;
                d.kadro.emekliyeEsasEkGosterge = d.kadro.kazanilmisEkGosterge;
                d.kadro.emekliyeEsasKademe = 1;
                d.kadro.emekliyeEsasTarih = d.kadro.kadroTarih;

                d.kadro.odemeyeEsasDerece = d.kadro.kadroDerece;
                d.kadro.odemeyeEsasEkGosterge = d.kadro.kazanilmisEkGosterge;
                d.kadro.odemeyeEsasKademe = 1;
                d.kadro.odemeyeEsasTarih = d.kadro.kadroTarih;

                string[] secilenKadro = (((string)cmbAtanacagiKadro.Value) + "").Split('-');
                d.kadro.atananacagiKadroUnvanKod = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.DiziElemanAl(secilenKadro, 0, ""), 0);
                d.kadro.atananacagiKadroDerece = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.DiziElemanAl(secilenKadro, 1, ""), 0);
            }
            return d;
        }

        [DirectMethod(Namespace = "PersonelK")]
        public string AlanlariKontrolEt()
        {
            TNS.IKY.Personel d = EkrandanAl();
            return d.Kontrol(kullanan);
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Kişisel bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        [DirectMethod(Namespace = "PersonelK", ShowMask = true, Msg = "Lütfen Bekleyiniz...")]
        public void btnKaydet_Click()
        {
            TNS.IKY.Personel d = EkrandanAl();
            Sonuc sonuc = servisIKY.PersonelKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPKS071);
                if (!string.IsNullOrEmpty(sonuc.anahtar) && d.kod == 0)
                    X.AddScript("KayittanSonraGoster(" + sonuc.anahtar + ");");
            }
        }

        //protected void btnOzlukYazdir_Click(object sender, DirectEventArgs e)
        //{
        //    PersonelRaporlari2.OzlukRaporYazdir(kullanan, 1, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
        //}

        //protected void btnYeniOzlukYazdir_Click(object sender, DirectEventArgs e)
        //{
        //    PersonelRaporlari2.OzlukRaporYazdir(kullanan, 2, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
        //}

        /// <summary>
        /// Personel bilgilerini MERNİS sisteminden getiren fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Image Click Event Args tipinde sınıf</param>
        protected void KimlikBilgisiGetir(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (txtTCKimlikNo.Text.Trim() == "")
                hata += Resources.InsanKaynaklari.FRMPKS072;

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.Personel p = new TNS.IKY.Personel();
            try
            {
                p = Genel.KimlikBilgisiGetir(kullanan, txtTCKimlikNo.Text.Trim());
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
                return;
            }

            if (!string.IsNullOrEmpty(p.ad))
            {
                txtTCKimlikNo.Text = p.tcKimlikNo;

                txtAd.Text = p.ad;
                txtSoyad.Text = p.soyad;

                txtTCKimlikNo.Text = p.tcKimlikNo;
                txtCuzdanSeriNo.Text = p.nufus.cuzdanSeriNo;
                txtCuzdanKayitNo.Text = p.nufus.cuzdanKayitNo;
                txtVerilisTarihi.Text = p.nufus.cuzdanVerilisTarihi.ToString();
                txtVerilisNedeni.Text = p.nufus.cuzdanVerilisNedeni;
                txtVerildigiYer.Text = p.nufus.cuzdanVerildigiYer;
                txtMahalle.Text = p.nufus.nufusMahalleKoy;
                txtCiltNo.Text = p.nufus.nufusCiltNo;
                txtAileSiraNo.Text = p.nufus.nufusAileSiraNo;
                txtSiraNo.Text = p.nufus.nufusSiraNo;
                txtDogumYeri.Text = p.nufus.dogumYeri;
                ddlKanGrubu.SetValueAndFireSelect(p.nufus.kanGrubu);
                ddlMedeniHali.SetValueAndFireSelect(Genel.SozlukKoduGetir(OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.MEDENIDURUMU, 0).ToString().PadLeft(2, '0') + "." + p.nufus.medeniHali.ToString().PadLeft(5, '0')));

                txtPasaportNo.Text = p.nufus.pasaportNo;
                txtPasaportVerilisTarihi.Text = p.nufus.pasaportVerilisTarihi.ToString();
                txtPasaportVerildigiYer.Text = p.nufus.pasaportVerildigiYer;
                txtPasaportVerenMakam.Text = p.nufus.pasaportVerenMakam;
                txtPasaportSuresi.Text = p.nufus.pasaportSuresi.ToString();

                txtAd.Text = p.ad;
                txtSoyad.Text = p.soyad;
                txtAnaAd.Text = p.nufus.anaAd;
                txtBabaAd.Text = p.nufus.babaAd;
                txtDin.Text = p.nufus.dini;
                ddlKanGrubu.SetValueAndFireSelect(p.nufus.kanGrubu);
                txtIlkSoyad.Text = p.ilkSoyad;
                txtDogumTarihi.Text = p.dogumTarihi.ToString();
                ddlCinsiyet.SetValueAndFireSelect((int)p.cinsiyet);

                txtIlkSoyad.Text = p.ilkSoyad;

                string ilKod = Genel.CografyaKodunaCevir(p.nufus.nufusIlKod);
                ddlNufusIl.SetValueAndFireSelect(ilKod);
                IlceYukle(ilKod);
                ddlNufusIlce.SetValueAndFireSelect(Genel.CografyaKodunaCevir(p.nufus.nufusIlceKod));
            }
            else
            {
                //Kurumda nufus cüzdanı kontrolü için yetki yoksa
                KullaniciVAN kVAN = GenelIslemler.MernisOku(kullanan, txtTCKimlikNo.Text.Trim(), p.dogumTarihi);
                if (kVAN.sonuc.islemSonuc)
                {
                    txtAd.Text = kVAN.kullanici.ad;
                    txtSoyad.Text = kVAN.kullanici.soyad;
                    txtAd.Text = kVAN.kullanici.ad;
                    txtSoyad.Text = kVAN.kullanici.soyad;
                    txtDogumTarihi.Text = kVAN.kullanici.dogumTarihi.ToString();
                    txtAnaAd.Text = kVAN.kullanici.anaAdi;
                    txtBabaAd.Text = kVAN.kullanici.babaAdi;
                    if (kVAN.kullanici.cinsiyet == "Erkek")
                        ddlCinsiyet.SelectedIndex = 1;
                    else
                        ddlCinsiyet.SelectedIndex = 2;
                }
                else
                {
                    txtAd.Text = "";
                    txtSoyad.Text = "";
                }
            }
        }

        /// <summary>
        /// Personele ait resmin veritabanında binary dizisi olarak kayıt edilmesini sağlar
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void ResimKayit(object sender, DirectEventArgs e)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
            {
                GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMGNL005, Resources.InsanKaynaklari.FRMGNL004);
                return;
            }

            PersonelResim resim = new PersonelResim();
            string fileName = fileResim.PostedFile.FileName;

            //Upload edilen resim byte[] olarak alınıyor
            int intLength = Convert.ToInt32(fileResim.PostedFile.InputStream.Length);
            resim.resim = new byte[intLength];
            fileResim.PostedFile.InputStream.Read(resim.resim, 0, intLength);

            //byte[] olan bilgi Image bilgisine dönüştürüldü
            System.IO.MemoryStream msResim = new System.IO.MemoryStream(resim.resim);
            System.Drawing.Image orjinalResim = System.Drawing.Image.FromStream(msResim);



            //Küçültülecek boyutlar
            int dosyaGenislik = 114;
            int dosyaYukseklik = 146;

            //Ratio'yu koru
            double rW = dosyaGenislik * 1.0 / orjinalResim.Width;
            double rH = dosyaYukseklik * 1.0 / orjinalResim.Height;
            double ra = Math.Min(rW, rH);
            if (ra > 0)
            {
                dosyaGenislik = (int)(orjinalResim.Width * ra);
                dosyaYukseklik = (int)(orjinalResim.Height * ra);
            }

            Bitmap kucukResim = new Bitmap(dosyaGenislik, dosyaYukseklik);
            using (Graphics graphics = Graphics.FromImage(kucukResim))
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.CompositingQuality = CompositingQuality.HighSpeed;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.DrawImage(orjinalResim, 0, 0, dosyaGenislik, dosyaYukseklik);
            }
            try
            {
                //Küçültülen resim byte[] dönüştürülüyor
                MemoryStream ms = new MemoryStream();
                kucukResim.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                resim.resim = ms.ToArray();
            }
            catch { }

            resim.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            servisIKY.PersonelResimKaydet(resim);

            imgResim.ImageUrl = "ResimGoster.ashx?pKod=" + resim.kod;
            X.AddScript("PersonelUstResimYenile('" + imgResim.ImageUrl + "')");
        }

        void Temizle()
        {
            txtTCKimlikNo.Text = "";
            txtSicilNo.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            txtEmekliSicilNo.Text = "";

            txtSSKSicilNo.Text = "";
            txtBagkurSicilNo.Text = "";
            imgResim.ImageUrl = "../App_themes/images/bos.jpg";

            txtTCKimlikNo.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            txtIlkSoyad.Text = "";
            txtAnaAd.Text = "";
            txtBabaAd.Text = "";
            txtDogumTarihi.Text = "";
            txtCuzdanSeriNo.Text = "";
            txtCuzdanKayitNo.Text = "";
            txtMahalle.Text = "";
            txtCiltNo.Text = "";
            txtSiraNo.Text = "";
            txtAileSiraNo.Text = "";
            txtVerilisNedeni.Text = "";
            txtVerildigiYer.Text = "";
            txtVerilisTarihi.Text = "";
            txtPasaportNo.Text = "";


            ddlCinsiyet.Clear();
            ddlNufusIl.Clear();
            ddlNufusIlce.Clear();
        }

        protected void TanitmaKartiYazdir(object sender, DirectEventArgs e)
        {
            string sonucDosyaad = PersonelRaporlari2.TanitmaKartiYazdir(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), this.raporSablonYol, "pdf");
            OrtakClass.DosyaIslem.DosyaGonderX(sonucDosyaad, "PersonelTanitmaKarti.pdf", true, "PDF");
        }

        protected void MailImzaYazdir(object sender, DirectEventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen kişi seçiniz");
                return;
            }

            MailImzaRapor mail = servisIKY.MailImzaRaporu(kod);
            string sonucDosyaad = Path.Combine(TNS.OrtakFonksiyonlar.GeciciYolBul(), Path.GetRandomFileName()) + ".docx";
            string dosyaAd = this.raporSablonYol + "\\IKY\\MailImza.docx";

            Document doc = new Document(dosyaAd);
            DocumentBuilder docb = new DocumentBuilder(doc);

            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "isim", mail.isim);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "unvan", mail.unvan);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "birim", mail.birim);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "istel", mail.isTel);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "ceptel", mail.cepTel);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "fax", mail.fax);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "adres", ""); //T.C. Cumhurbaşkanlığı Genel Sekreterliği 06689 Çankaya-Ankara


            byte[] resim = null;

            try
            {
                using (System.Net.WebClient client = new System.Net.WebClient())
                {
                    string kokAdres = Page.Request.Url.ToString().Substring(0, Page.Request.Url.ToString().IndexOf("InsanKaynaklari"));
                    resim = client.DownloadData(new Uri(kokAdres + "/KYM/LogoGetir.aspx?tur=2"));
                }
            }
            catch (Exception ex)
            {
            }

            if (resim != null)
                GenelIslemlerIstemci.AsposeAlanaResimEkle(docb, "resim", resim, Aspose.Words.Drawing.RelativeHorizontalPosition.Default, 0, Aspose.Words.Drawing.RelativeVerticalPosition.Paragraph, 0, Aspose.Words.Drawing.WrapType.None, 80, 80);
            else
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "resim", "");

            doc.Save(sonucDosyaad, SaveFormat.Pdf);

            OrtakClass.DosyaIslem.DosyaGonderX(sonucDosyaad, "MailImza.pdf", true, "PDF");
        }

        protected void NufusYazdir(object sender, DirectEventArgs e)
        {
            int istekTur = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["Kod"], 1);

            System.Collections.Hashtable raporParam = new Hashtable();
            if (Arac.ManasKullaniyor())
                raporParam["TCKimlikNo"] = hdnKod.Text;
            else
                raporParam["TCKimlikNo"] = txtTCKimlikNo.Text.Trim();
            raporParam["DUZENLEYENAD"] = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKDUZENLEYENAD");
            raporParam["DUZENLEYENUNVAN"] = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKDUZENLEYENUNVAN");
            raporParam["ONAYLAYANAD"] = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKONAYLAYANAD");
            raporParam["ONAYLAYANUNVAN"] = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKONAYLAYANUNVAN");

            TNS.Raporlama.RaporlamaServis.TekRaporAl(500, istekTur, kullanan, null, raporParam);
        }


        protected void NakilBildirimiYazdir(object sender, DirectEventArgs e)
        {
            Tablo XLS = GenelIslemler.NewTablo();

            string sablonAd = this.raporSablonYol + @"IKY\" + "PersonelNakilBildirimi2.xltx";
            //string sonucDosyaAd = DosyaIslem.DosyaAdUret("IKY", "");     
            //XLS.DosyaSaklamaFormatAta("xls");       
            string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            XLS.DosyaAc(sablonAd, sonucDosyaAd);
            TNS.IKY.Personel nakil = new TNS.IKY.Personel();
            PersonelIzinGunleri izin = new PersonelIzinGunleri();
            try
            {
                nakil = servisIKY.NakilBildirimRaporu(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
                izin = servisIKY.PersonelYilBazliYillikIzinBilgileri(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), DateTime.Now);
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu(this, ex.Message);
            }

            string esDurum = "";
            XLS.HucreAdBulYaz("baslik", GenelIslemlerIstemci.VarsayilanKurumBulAd());
            XLS.HucreAdBulYaz("isim", nakil.ad);
            XLS.HucreAdBulYaz("kurumSicili", nakil.sicilNo);
            XLS.HucreAdBulYaz("emekliSicili", nakil.emekliSicilNo);
            XLS.HucreAdBulYaz("TC", nakil.tcKimlikNo);
            XLS.HucreAdBulYaz("eskiUnvan", nakil.kadro.unvanAd);
            XLS.HucreAdBulYaz("eskiGorevYeri", nakil.kadro.birimAd);
            XLS.HucreAdBulYaz("EskiDerece", nakil.kadro.kazanilmisHakDerece + "/" + nakil.kadro.kazanilmisHakKademe + " " + nakil.kadro.emekliyeEsasDerece + "/" + nakil.kadro.emekliyeEsasKademe);
            XLS.HucreAdBulYaz("atamaTarihi", nakil.kadro.atamaTarihi.ToString());
            XLS.HucreAdBulYaz("ogrenim", nakil.ogrenim[0].okulAdi);
            XLS.HucreAdBulYaz("izin", izin.kalan + " Gün izni bulunmaktadır.");
            XLS.HucreAdBulYaz("kidemGun", Hizmet.YilAyGunDondur(nakil.kadro.kidemGunu));
            XLS.HucreAdBulYaz("ayrilisTarihi", nakil.kadro.ayrilmaTarihi.ToString() + " (Mesai Bitimi)");
            XLS.HucreAdBulYaz("saglikIzinSayisi", nakil.kullanilanIzinGun + " Gün");
            if (!string.IsNullOrWhiteSpace(nakil.aile[0].durumAd))
                esDurum = "Eşi: " + nakil.aile[0].durumAd;
            XLS.HucreAdBulYaz("aile", esDurum + nakil.aile[0].cocukSayisi + " cocuk");

            XLS.SatirSil(8, 8);

            XLS.DosyaSaklaTamYol();
            DosyaIslem.DosyaGonderX(sonucDosyaAd, "PersonelNakilBildirimi_" + DateTime.Now.Ticks.ToString() + ".xls", true, "xls", true);
        }

        /// <summary>
        /// Nüfus İl Drop Down List bileşeni değiştiği zaman çalışan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, Object tipinde sınıf</param>
        /// <param name="e">Olay Argümanı, Event Args tipinde sınıf</param>
        protected void IlBilgisiDegisti(object sender, DirectEventArgs e)
        {
            IlceYukle(e.ExtraParams["ilKod"]);
        }

        void IlYukle()
        {
            ddlNufusIl.Items.Clear();
            ilStore.DataSource = GenelIslemlerIstemci.IlYukle();
            ilStore.DataBind();
        }

        void IlceYukle(string ilKod)
        {
            if (!string.IsNullOrWhiteSpace(ilKod))
            {
                ddlNufusIlce.Items.Clear();
                ilceStore.DataSource = GenelIslemlerIstemci.IlceYukle(ilKod);
                ilceStore.DataBind();
            }
        }

        protected void MedeniHaliDoldur()
        {
            ddlMedeniHali.Items.Clear();
            medeniHaliStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.MEDENIDURUMU, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            medeniHaliStore.DataBind();
        }

        protected void SakatlikDurumuDoldur()
        {
            cmbSakatlikDurumu.Items.Clear();
            sakatlikDurumuStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.SAKATLIKDURUMU, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            sakatlikDurumuStore.DataBind();
        }

        protected void SosyalGuvenceDoldur()
        {
            cmbSosyalGuvence.Items.Clear();
            StoreSosyalGuvence.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.SOSYALGUVENCEKOD, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            StoreSosyalGuvence.DataBind();
        }

        protected void txtSicilNo_TriggerClick(object sender, DirectEventArgs e)
        {
            string s = txtSicilNo.Text;

            ObjectArray oa = servisIKY.PersonelBulOncekiSonraki(kullanan, s, e.ExtraParams["tusNo"] == "1" ? false : true);
            if (oa.sonuc.islemSonuc)
            {
                if (oa.ObjeSayisi > 0)
                {
                    TNS.IKY.Personel p = (TNS.IKY.Personel)oa.objeler[0];
                    X.AddScript("KayittanSonraGoster(" + p.kod.ToString() + ");");
                }
                else
                    GenelIslemler.MesajKutusu("Hata", s + " sicil nolu personelden önceki/sonraki sicil numaralı personel bulunamadı!");
            }
            else
                GenelIslemler.MesajKutusu("Hata", oa.sonuc.hataStr);
        }

        private string Ekle(string gelen, int rakam)
        {
            StringBuilder s = new StringBuilder(gelen);
            for (int i = s.Length - 1; i >= 0; i--)
            {
                bool devam = false;
                char c = s[i];
                if (Char.IsDigit(c))
                {
                    if (rakam == 1 && c == '9') { c = '0'; devam = true; }
                    else if (rakam == -1 && c == '0') { c = '9'; devam = true; }
                    else c = Convert.ToChar(((int)c) + rakam);
                }
                else
                    c = Convert.ToChar(((int)c) + rakam);
                s[i] = c;
                if (!devam) break;
            }
            return s.ToString();
        }

        protected void cmbPersonelTipDegisti(object sender, DirectEventArgs e)
        {
            int personelTur = OrtakFonksiyonlar.ConvertToInt(cmbPersonelTip.SelectedItem.Value, -1);
            PersonelTipi personelTipiYeni = TNS.IKY.Arac.PersonelTipBul(personelTur);
            if (personelTipiYeni == null) personelTipiYeni = (PersonelTipi)TNS.IKY.Arac.PersonelTipListe[0];
            if (personelTipiYeni.KadroIslemiYapilacakMi())
            {
                Genel.AcikKadroDoldur(stoAtanacagiKadro, OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0), true, 0);
                cmbAtanacagiKadro.Hidden = false;
            }
            else
            {
                cmbAtanacagiKadro.Hidden = true;
            }
        }

        protected void btnKisiBorcuYazdir_Click(object sender, DirectEventArgs e)
        {
            string sonucDosyaad = PersonelRaporlari2.MaasIdasiHesaplamaCetveliYazdir(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), this.raporSablonYol, "xlsx");
            OrtakClass.DosyaIslem.DosyaGonderX(sonucDosyaad, "MaasIadesiHesaplamaCetveli.xlsx", true, "xlsx");
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnKod.Value.ToString().Trim()))
            {
                //btnKaydet_Click(null, null);
                //GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMPAB040, Resources.InsanKaynaklari.FRMPAB041);
                //return;
            }

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELKISISEL, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }

        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELKISISEL;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void btnTCKimlikNoDegistir_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            string yeniTcKimlikNo = (e.ExtraParams["YeniTCKimlikNo"] + "").Trim();

            TNS.IKY.Personel d = new TNS.IKY.Personel();
            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            if (d.kod > 0)
            {
                d.tcKimlikNo = yeniTcKimlikNo.Trim();
                Sonuc sonuc = servisIKY.PersonelTCKimlikNoDegistir(kullanan, d);

                if (!sonuc.islemSonuc)
                    hata = sonuc.hataStr;
            }
            else
                hata = "Personel bilgisi bulunamadı! Lütfen öncelikle personel seçiniz.<br>";

            if (!string.IsNullOrWhiteSpace(hata))
                GenelIslemler.MesajKutusu(this, hata);
            else
            {
                menuTCKimlikNo.Hide();
                txtTCKimlikNo.Text = yeniTcKimlikNo;
                GenelIslemler.ExtNotification("TC Kimlik No bilgisi değiştirildi.", "Bilgi", Ext1.Net.Icon.Accept);
            }

        }
    }
}