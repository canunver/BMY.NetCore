﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelMemuriyet.aspx.cs"
    Inherits="InsanKaynaklari.PersonelMemuriyet" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                function (btn) {
                    if (btn == "yes") {
                        Ext1.net.DirectMethods.BelgeSil(record.data.TCKIMLIKNO, record.data.TIP, record.data.KAYITSIRANO, record.data.BELGESIRANO);
                    }
                });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.TCKIMLIKNO, record.data.TIP, record.data.KAYITSIRANO, record.data.BELGESIRANO);
        }; 
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnSiraNo" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="SIRANO" />
                    <ext:RecordField Name="ORGKOD" />
                    <ext:RecordField Name="MUHASEBEKOD" />
                    <ext:RecordField Name="BIRIMKOD" />
                    <ext:RecordField Name="KURUM" />
                    <ext:RecordField Name="BIRIMAD" />
                    <ext:RecordField Name="GOREV" />
                    <ext:RecordField Name="ISTIHDAMSEKLI" />
                    <ext:RecordField Name="EVRAKNO" />
                    <ext:RecordField Name="YASALDAYANAK" />
                    <ext:RecordField Name="ONAYTARIH" />
                    <ext:RecordField Name="ACIKLAMA" />
                    <ext:RecordField Name="BASLAMATARIHI" Type="Date" />
                    <ext:RecordField Name="AYRILMATARIHI" Type="Date" />
                    <ext:RecordField Name="BASLAMANEDENI" />
                    <ext:RecordField Name="AYRILMANEDENI" />
                    <ext:RecordField Name="BASLAMANEDENIAD" />
                    <ext:RecordField Name="AYRILMANEDENIAD" />
                    <ext:RecordField Name="KADRODERECE" />
                    <ext:RecordField Name="KADROTARIH" />
                    <ext:RecordField Name="KAZANILMISHAKDERECE" />
                    <ext:RecordField Name="KAZANILMISHAKKADEME" />
                    <ext:RecordField Name="KAZANILMISHAKTARIH" />
                    <ext:RecordField Name="KAZANILMISGOSTERGE" />
                    <ext:RecordField Name="KAZANILMISEKGOSTERGE" />
                    <ext:RecordField Name="ODEMEYEESASDERECE" />
                    <ext:RecordField Name="ODEMEYEESASKADEME" />
                    <ext:RecordField Name="ODEMEYEESASTARIH" />
                    <ext:RecordField Name="ODEMEYEESASGOSTERGE" />
                    <ext:RecordField Name="ODEMEYEESASEKGOSTERGE" />
                    <ext:RecordField Name="EMEKLIYEESASDERECE" />
                    <ext:RecordField Name="EMEKLIYEESASKADEME" />
                    <ext:RecordField Name="EMEKLIYEESASTARIH" />
                    <ext:RecordField Name="EMEKLIGOSTERGE" />
                    <ext:RecordField Name="EMEKLIEKGOSTERGE" />
                </Fields>
            </ext:JsonReader>
        </Reader>
        <SortInfo Field="BASLAMATARIHI" Direction="ASC" />
    </ext:Store>
    <ext:Store ID="nedenBaslamaStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="nedenAyrilmaStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="TCKIMLIKNO" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="KAYITSIRANO" />
                    <ext:RecordField Name="BELGESIRANO" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server">
        <Items>
            <ext:BorderLayout runat="server">
                <Center>
                    <ext:Panel runat="server" Border="false">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                        Icon="Disk">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="<%$ Resources:InsanKaynaklari,FRMORT079 %>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                        Icon="Delete">
                                        <DirectEvents>
                                            <Click OnEvent="btnSil_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                                    Title="<%$ Resources:InsanKaynaklari,FRMORT079 %>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                        Icon="PageWhite">
                                        <DirectEvents>
                                            <Click OnEvent="btnTemizle_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout runat="server">
                                <Center>
                                    <ext:FormPanel runat="server" Frame="true" Padding="5">
                                        <Items>
                                            <ext:ExtOrgSecim ID="ddlBirim" runat="server" Width="310" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>" />
                                            <ext:TextField ID="txtGorev" runat="server" Width="310" FieldLabel="Görevi" NoteAlign="Top" />
                                            <ext:ComboBox runat="server" ID="ddlIstihdamSekli" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM094 %>"
                                                Mode="Local" TriggerAction="All" NoteAlign="Top" Width="310" Editable="true">
                                            </ext:ComboBox>
                                            <ext:CompositeField ID="CompositeField6" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM095 %>">
                                                <Items>
                                                    <ext:DateField ID="txtBaslamaTarihi" runat="server" Width="90" Note="Tarihi" NoteAlign="Top"
                                                        Vtype="daterange">
                                                        <CustomConfig>
                                                            <ext:ConfigItem Name="endDateField" Value="#{txtAyrilmaTarihi}" Mode="Value" />
                                                        </CustomConfig>
                                                    </ext:DateField>
                                                    <ext:ComboBox ID="ddlBaslamaNeden" runat="server" Editable="true" TypeAhead="true"
                                                        Mode="Local" ForceSelection="true" Note="<%$ Resources:InsanKaynaklari,FRMPRM098 %>" Width="215" StoreID="nedenBaslamaStore"
                                                        DisplayField="AD" ValueField="KOD" SelectOnFocus="true" NoteAlign="Top">
                                                    </ext:ComboBox>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField ID="CompositeField8" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM096 %>">
                                                <Items>
                                                    <ext:DateField ID="txtAyrilmaTarihi" runat="server" Width="90" Note="<%$ Resources:InsanKaynaklari,FRMPRM097 %>" NoteAlign="Top"
                                                        Vtype="daterange">
                                                        <CustomConfig>
                                                            <ext:ConfigItem Name="startDateField" Value="#{txtBaslamaTarihi}" Mode="Value" />
                                                        </CustomConfig>
                                                    </ext:DateField>
                                                    <ext:ComboBox ID="ddlAyrilmaNeden" runat="server" Editable="true" TypeAhead="true"
                                                        Mode="Local" ForceSelection="true" Note="<%$ Resources:InsanKaynaklari,FRMPRM098 %>" Width="215" StoreID="nedenAyrilmaStore"
                                                        DisplayField="AD" ValueField="KOD" SelectOnFocus="true" NoteAlign="Top">
                                                    </ext:ComboBox>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField ID="CompositeField7" runat="server" FieldLabel="Evrak">
                                                <Items>
                                                    <ext:TextField ID="txtEvrakNo" runat="server" Width="90" Note="<%$ Resources:InsanKaynaklari,FRMPRK052 %>" NoteAlign="Top" />
                                                    <ext:TextField ID="txtYasalDayanak" runat="server" Width="120" Note="<%$ Resources:InsanKaynaklari,FRMPRK053 %>" NoteAlign="Top" />
                                                    <ext:DateField ID="txtOnayTarih" runat="server" Width="90" Note="<%$ Resources:InsanKaynaklari,FRMPRM097 %>" NoteAlign="Top" />
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:TextArea ID="txtAciklama" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK014%>"
                                                Width="310" Height="40" />
                                            <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                                Frame="true" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK063 %>" TrackMouseOver="true" StoreID="BelgeStore"
                                                HideHeaders="true" AutoHeight="true" Width="350">
                                                <ColumnModel ID="ColumnModel2" runat="server">
                                                    <Columns>
                                                        <ext:RowNumbererColumn />
                                                        <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Header="<%$ Resources:InsanKaynaklari,FRMPRK063 %>" Width="250" />
                                                        <ext:CommandColumn Width="30">
                                                            <Commands>
                                                                <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPRK064 %>" />
                                                            </Commands>
                                                        </ext:CommandColumn>
                                                        <ext:CommandColumn Width="30">
                                                            <Commands>
                                                                <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPRK065 %>" />
                                                            </Commands>
                                                        </ext:CommandColumn>
                                                    </Columns>
                                                </ColumnModel>
                                                <Listeners>
                                                    <Command Fn="KomutCalistir" />
                                                </Listeners>
                                                <SelectionModel>
                                                    <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                                    </ext:RowSelectionModel>
                                                </SelectionModel>
                                                <TopBar>
                                                    <ext:Toolbar ID="Toolbar2" runat="server">
                                                        <Items>
                                                            <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                                ButtonText="<%$ Resources:InsanKaynaklari,FRMPRK066 %>">
                                                                <DirectEvents>
                                                                    <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                                </DirectEvents>
                                                            </ext:FileUploadField>
                                                        </Items>
                                                    </ext:Toolbar>
                                                </TopBar>
                                            </ext:GridPanel>
                                            <ext:Panel ID="pnlKadro" runat="server" Title="<%$ Resources:InsanKaynaklari,FRMPRm099 %>" Width="480" Frame="true">
                                                <Items>
                                                    <ext:CompositeField ID="CompositeField5" runat="server" FieldLabel="&nbsp;" LabelSeparator="&nbsp;">
                                                        <Items>
                                                            <ext:Label ID="Label4" runat="server" Width="50" Text="<%$ Resources:InsanKaynaklari,FRMPRK056 %>" />
                                                            <ext:Label ID="Label5" runat="server" Width="50" Text="<%$ Resources:InsanKaynaklari,FRMPRK067 %>" />
                                                            <ext:Label ID="Label6" runat="server" Width="90" Text="<%$ Resources:InsanKaynaklari,FRMPRK057 %>" />
                                                            <ext:Label ID="Label2" runat="server" Width="50" Text="<%$ Resources:InsanKaynaklari,FRMPRK058 %>" />
                                                            <ext:Label ID="Label3" runat="server" Width="70" Text="<%$ Resources:InsanKaynaklari,FRMPRK059 %>" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                    <ext:CompositeField ID="CompositeField4" runat="server" FieldLabel="Kadro">
                                                        <Items>
                                                            <ext:TextField ID="txtKadroDerece" runat="server" Width="50" ReadOnly="true" Selectable="false" />
                                                            <ext:DisplayField ID="DisplayField1" runat="server" Width="50" />
                                                            <ext:TextField ID="txtKadroTarih" runat="server" Width="90" ReadOnly="true" Selectable="false" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                    <ext:CompositeField ID="CompositeField2" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK060 %>">
                                                        <Items>
                                                            <ext:TextField ID="txtKazanilmisHakDerece" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtKazanilmisHakKademe" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtKazanilmisHakTarih" runat="server" Width="90" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtKazanilmisGosterge" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtKazanilmisEkGosterge" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                    <ext:CompositeField ID="CompositeField1" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK061 %>">
                                                        <Items>
                                                            <ext:TextField ID="txtOdemeyeEsasDerece" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtOdemeyeEsasKademe" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtOdemeyeEsasTarih" runat="server" Width="90" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtOdemeyeEsasGosterge" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtOdemeyeEsasEkGosterge" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                    <ext:CompositeField ID="CompositeField3" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK062 %>">
                                                        <Items>
                                                            <ext:TextField ID="txtEmekliyeEsasDerece" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtEmekliyeEsasKademe" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtEmekliyeEsasTarih" runat="server" Width="90" ReadOnly="true"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtEmekliGosterge" runat="server" Width="50" ReadOnly="true" Selectable="false" />
                                                            <ext:TextField ID="txtEmekliEkGosterge" runat="server" Width="50" ReadOnly="true"
                                                                Selectable="false" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                </Items>
                                            </ext:Panel>
                                            <ext:FormPanel ID="frmSureBilgi" runat="server" Width="270" Frame="true" Height="230"
                                                StyleSpec="position:absolute;top:5px;left:450px" LabelWidth="150" Title="Süre Bilgileri">
                                                <Items>
                                                    <ext:TextField ID="txtGorevBaslamaTarihi" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM100 %>"
                                                        Width="80" ReadOnly="true" StyleSpec="background-color:orange;color:black;text-align:center"
                                                        Selectable="false" />
                                                    <ext:TextField ID="txtBirimBaslamaTarihi" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM101 %>"
                                                        Width="80" ReadOnly="true" StyleSpec="background-color:yellow;color:black;text-align:center"
                                                        Selectable="false" />
                                                    <ext:TextField ID="txtMemuriyetBaslamaTarihi" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM102 %>"
                                                        Width="80" ReadOnly="true" StyleSpec="background-color:red;color:black;text-align:center"
                                                        Selectable="false" />
                                                    <ext:CompositeField ID="CompositeField9" runat="server">
                                                        <Items>
                                                            <ext:Label runat="server" Width="25" Text="<%$ Resources:InsanKaynaklari,FRMPRM103 %>" />
                                                            <ext:Label runat="server" Width="25" Text="<%$ Resources:InsanKaynaklari,FRMPRM104 %>" />
                                                            <ext:Label runat="server" Width="25" Text="<%$ Resources:InsanKaynaklari,FRMPRM105 %>" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                    <ext:CompositeField runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM106 %>">
                                                        <Items>
                                                            <ext:TextField ID="txtGorevYil" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:orange;color:black;text-align:center"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtGorevAy" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:orange;color:black;text-align:center"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtGorevGun" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:orange;color:black;text-align:center"
                                                                Selectable="false" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                    <ext:CompositeField runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM107 %>">
                                                        <Items>
                                                            <ext:TextField ID="txtBirimYil" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:yellow;color:black;text-align:center"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtBirimAy" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:yellow;color:black;text-align:center"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtBirimGun" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:yellow;color:black;text-align:center"
                                                                Selectable="false" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                    <ext:CompositeField runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM108 %>">
                                                        <Items>
                                                            <ext:TextField ID="txtKamuYil" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:red;color:black;text-align:center"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtKamuAy" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:red;color:black;text-align:center"
                                                                Selectable="false" />
                                                            <ext:TextField ID="txtKamuGun" runat="server" Width="25" ReadOnly="true" StyleSpec="background-color:red;color:black;text-align:center"
                                                                Selectable="false" />
                                                        </Items>
                                                    </ext:CompositeField>
                                                </Items>
                                            </ext:FormPanel>
                                        </Items>
                                    </ext:FormPanel>
                                </Center>
                                <East Split="true">
                                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                        StoreID="ListeStore" Layout="FitLayout" Width="290" Border="true">
                                        <ColumnModel ID="ColumnModel1" runat="server">
                                            <Columns>
                                                <ext:Column DataIndex="BIRIMAD" Header="Birim" Width="150" />
                                                <ext:DateColumn DataIndex="BASLAMATARIHI" Header="<%$ Resources:InsanKaynaklari,FRMPRM109 %>" Width="90" Format="dd/m/Y" />
                                                <ext:DateColumn DataIndex="AYRILMATARIHI" Header="<%$ Resources:InsanKaynaklari,FRMPRM110 %>" Width="90" Format="dd/m/Y" />
                                                <ext:Column DataIndex="BASLAMANEDENIAD" Header="<%$ Resources:InsanKaynaklari,FRMPRM111 %>" Width="90" />
                                                <ext:Column DataIndex="GOREV" Header="<%$ Resources:InsanKaynaklari,FRMPRM007 %>" Width="150" />
                                                <ext:Column DataIndex="AYRILMANEDENIAD" Header="<%$ Resources:InsanKaynaklari,FRMPRM112 %>" Width="90" />
                                            </Columns>
                                        </ColumnModel>
                                        <SelectionModel>
                                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                                <DirectEvents>
                                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                                        <ExtraParams>
                                                            <ext:Parameter Name="RowValue" Value="Ext1.encode(#{grdListe}.getRowsValues({selectedOnly:true}))"
                                                                Mode="Raw" />
                                                        </ExtraParams>
                                                    </RowSelect>
                                                </DirectEvents>
                                            </ext:RowSelectionModel>
                                        </SelectionModel>
                                        <BottomBar>
                                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                                            </ext:PagingToolbar>
                                        </BottomBar>
                                    </ext:GridPanel>
                                </East>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
