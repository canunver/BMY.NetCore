﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class TanimSozlukGider : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = "Sözlük Gider Tanımı";
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                Listele();
            }
        }

        protected void Listele()
        {
            ObjectArray oa = servis.SozlukGiderListele(kullanan, new SozlukGider());
            stoListe.DataSource = oa.objeler;
            stoListe.DataBind();
        }

        void Oku()
        {
            SozlukGider form = new SozlukGider();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
            ObjectVAN ov = servis.SozlukGiderOku(kullanan, form);
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                form = (SozlukGider)ov.o;
                txtKod.Text = form.kod.ToString();
                txtAd.Text = form.ad.ToString();
                chkEldenGor.Checked = (form.eldenGor == 1);
                chkEndexGor.Checked = (form.endexGor == 1);
                chkAciklamaGor.Checked = (form.aciklamaGor == 1);
            }
            else if (!ov.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite002);
        }

        void Kaydet(DirectEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAd.Text))
            {
                GenelIslemler.HataYaz(this, "Gider Adını giriniz.");
                return;
            }
            SozlukGider form = new SozlukGider();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
            form.ad = txtAd.Text;
            form.eldenGor = chkEldenGor.Checked ? 1 : 0;
            form.endexGor = chkEndexGor.Checked ? 1 : 0;
            form.aciklamaGor = chkAciklamaGor.Checked ? 1 : 0;
            Sonuc sonuc = servis.SozlukGiderKaydet(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite003);
                Listele();
            }
        }

        /// <summary>
        /// Lojman Site kodu olarak verilen değeri, txtkod alanına atar ve okuma işlemini çağırır.
        /// </summary>
        /// <param name="kod">Personel tipi kodu </param>
        [DirectMethod]
        public void Goster(int kod)
        {
            txtKod.Text = kod.ToString();
            Oku();
        }

        /// <summary>
        /// Listele tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnOku_Click(object sender, DirectEventArgs e)
        {
            Oku();
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        /// <summary>
        /// Yazdir tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
        }

        /// <summary>
        /// Yeni tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYeni_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        /// <summary>
        /// Sil tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtKod.Text))
            {
                GenelIslemler.BilgiYaz(this, "Silmek istediğiniz daireyi seçiniz.");
                return;
            }
            Sonuc sonuc = servis.SozlukGiderSil(kullanan, OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0));
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite042);
                Listele();
            }
        }

        protected void Temizle()
        {
            txtKod.Clear();
            txtAd.Clear();
        }

    }
}
