﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimSinif : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Sınıf Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Listele(new Sinif());
            }
        }

        public void Listele(Sinif kriter)
        {
            ObjectArray dler = servisIKY.SinifListele(kriter);

            if (!dler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
                return;
            }

            if (dler.objeler.Count <= 0)
                GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            List<object> tipler = new List<object>();
            foreach (TNS.IKY.Sinif d in dler.objeler)
                tipler.Add(new
                {
                    SINIFKODU = d.kod,
                    SINIFADI = d.ad,
                });

            ListeStore.DataSource = tipler;
            ListeStore.DataBind();
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            Sinif d = new Sinif();
            d.kod = OrtakFonksiyonlar.ConvertToInt(txtSinifKodu.Text.Trim(), 0);
            d.ad = txtSinifAdi.Text.Trim();
            Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(txtSinifKodu.Text.Trim(), 0) == 0)
                hata = "Sınıf Kodu boş bırakılamaz" + "<br>";
            if (txtSinifAdi.Text.Trim() == "")
                hata += "Sınıf adı boş bırakılamaz" + "<br>";

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            Sinif d = new Sinif();
            d.kod = OrtakFonksiyonlar.ConvertToInt(txtSinifKodu.Text.Trim(), 0);
            d.ad = txtSinifAdi.Text;

            Sonuc sonuc = servisIKY.SinifKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele(new Sinif());
                GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            }
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            Sinif d = new Sinif();
            int kod = OrtakFonksiyonlar.ConvertToInt(txtSinifKodu.Text.Trim(), 0);

            if (kod > 0)
            {
                d.kod = kod;
                Sonuc sonuc = servisIKY.SinifSil(kullanan, d);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    Temizle();
                    Listele(new Sinif());
                    GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
                }
            }
            else
                GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz ünvanı seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Listele(new Sinif());
            Temizle();
        }

        void Temizle()
        {
            txtSinifKodu.Text = "";
            txtSinifAdi.Text = "";
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            txtSinifKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["sinifKodu"]);
            txtSinifAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["sinifAdi"]);
        }
    }
}
