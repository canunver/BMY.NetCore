﻿using System;
using System.Collections;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections.Generic;
using TNS.KYM;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel aile sınıfı
    /// </summary>
    public partial class PersonelCezaOdul : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPersonelKod.Value = (Request.QueryString["personelKod"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnTemizle.Hidden = true;
            //    btnSil.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                CezaOdulTipiDoldur();
                Temizle();
                Listele();
            }
        }

        /// <summary>
        /// Girilen kritere göre Kişinin bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel tipinde sınıf</param>
        public void Listele()
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) == 0)
                return;
            TNS.IKY.PersonelCezaOdul kriter = new TNS.IKY.PersonelCezaOdul();
            kriter.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            ObjectArray pler = servisIKY.PersonelCezaOdulListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            ArrayList liste = new ArrayList();
            foreach (TNS.IKY.PersonelCezaOdul p in pler.objeler)
                liste.Add(new { KOD = p.kod, CEZAODULTIPI = p.cezaOdulTipiAdi, TARIH = p.tarih.ToString() });

            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }

        /// <summary>
        /// Kaydet düğmesine basınca ekrandan bilgileri toplayarak kayıt etmek için sunucu tarafındaki metodu çağıran metod
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) == 0)
                hata += Resources.InsanKaynaklari.FRMPAB002 + "<br>";          

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }
  
            TNS.IKY.PersonelCezaOdul bilgi = new TNS.IKY.PersonelCezaOdul();
            bilgi.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            bilgi.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            bilgi.alanUnvani = txtAlanUnvan.Text;
            bilgi.belgeCinsi = txtBelgeCinsi.Text;
            bilgi.belgeNo = txtBelgeNo.Text;
            bilgi.belgeTarihi = Genel.TarihAlaniDegerVer(txtBelgeTarihi);
            bilgi.cezaOdulTipi = OrtakFonksiyonlar.ConvertToInt(ddlTip.SelectedItem.Value, 0);
            bilgi.cinsi = txtCinsi.Text;
            bilgi.dayanak = txtDayanak.Text;
            bilgi.sebebi = txtSebebi.Text;
            bilgi.tarih = Genel.TarihAlaniDegerVer(txtTarih);
            bilgi.verenAdi = txtVerenAd.Text;
            bilgi.verenKurum = txtVerenKurum.Text;
            bilgi.verenUnvani = txtVerenUnvan.Text;

            Sonuc sonuc = servisIKY.PersonelCezaOdulKaydet(kullanan, bilgi);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele();
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB015);
            }
        }

        /// <summary>
        /// Sil düğmesine basınca ekrandan bilgileri toplayarak silmek için sunucu tarafındaki metodu çağıran metod
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB017);
                return;
            }

            TNS.IKY.PersonelCezaOdul d = new TNS.IKY.PersonelCezaOdul();
            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            d.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            Sonuc sonuc = servisIKY.PersonelCezaOdulSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele();
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB016);
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }       

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            hdnKod.Value = e.ExtraParams["kod"];
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            TNS.IKY.PersonelCezaOdul kriter = new TNS.IKY.PersonelCezaOdul();
            kriter.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            kriter.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);

            ObjectArray pler = new ObjectArray();
            pler = servisIKY.PersonelCezaOdulListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            foreach (TNS.IKY.PersonelCezaOdul p in pler.objeler)
            {
                txtAlanUnvan.Text = p.alanUnvani;
                txtBelgeCinsi.Text = p.belgeCinsi;
                txtBelgeNo.Text = p.belgeNo;
                txtBelgeTarihi.Text = p.belgeTarihi.ToString();
                txtCinsi.Text = p.cinsi;
                txtDayanak.Text = p.dayanak;
                txtSebebi.Text = p.sebebi;
                txtTarih.Text = p.tarih.ToString();
                txtVerenAd.Text = p.verenAdi;
                txtVerenKurum.Text = p.verenKurum;
                txtVerenUnvan.Text = p.verenUnvani;
                ddlTip.SetValueAndFireSelect(p.cezaOdulTipi);
            }
        }

        protected void CezaOdulTipiDoldur()
        {
            ddlTip.Items.Clear();
            cezaOdulTipiStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.CEZAODULTIPI, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            cezaOdulTipiStore.DataBind();
        }

        void Temizle()
        {
            hdnKod.Clear();
            ddlTip.Clear();
            txtTarih.Clear();
            txtVerenAd.Clear();
            txtVerenKurum.Clear();
            txtVerenUnvan.Clear();
            txtAlanUnvan.Clear();
            txtCinsi.Clear();
            txtSebebi.Clear();
            txtDayanak.Clear();
            txtBelgeNo.Clear();
            txtBelgeTarihi.Clear();
            txtBelgeCinsi.Clear();      
            grdListeSelectionModel.ClearSelections();
        }
    }
}
