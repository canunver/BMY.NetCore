﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ListePersonelSec.aspx.cs"
    Inherits="InsanKaynaklari.ListePersonelSec" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript">

        function ddlBirim_SetValue(nodeId, birimAd) {
            ddlBirim.setValue(nodeId, birimAd, false);
        }

        function PersonelBilgiAktar(recordData) {
            parent.personelEkle(recordData);
            if (hdnSecKapat.value == "1")
                parent.hidePopWin();
        }

        function CokluSecKapat() {
            parent.PersonelleriEkle(grdListe.getRowsValues({ selectedOnly: true }));
            parent.hidePopWin();
        }

        function CokluSecKapatma() {
            parent.PersonelleriEkle(grdListe.getRowsValues({ selectedOnly: true }));
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnSecKapat" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="TCKIMLIKNO" />
                    <ext:RecordField Name="AD" />
                    <ext:RecordField Name="SOYAD" />
                    <ext:RecordField Name="UNVANKOD" />
                    <ext:RecordField Name="UNVANAD" />
                    <ext:RecordField Name="KADRODERECE" />
                    <ext:RecordField Name="EKGOSTERGE" />
                    <ext:RecordField Name="EPOSTA" />
                    <ext:RecordField Name="sicilNo" />
                    <ext:RecordField Name="sskSicilNo" />
                    <ext:RecordField Name="bankaKodu" />
                    <ext:RecordField Name="bankaSubeKodu" />
                    <ext:RecordField Name="bankaHesapNo" />
                    <ext:RecordField Name="sinifKodu" />
                    <ext:RecordField Name="personelTip" Type="Int" />
                    <ext:RecordField Name="odemeEsasDerece" Type="Int" />
                    <ext:RecordField Name="odemeEsasKademe" Type="Int" />
                    <ext:RecordField Name="odemeEsasGosterge" Type="Int" />
                    <ext:RecordField Name="odemeEsasEkGosterge" Type="Int" />
                    <ext:RecordField Name="emekliEsasDerece" Type="Int" />
                    <ext:RecordField Name="emekliEsasKademe" Type="Int" />
                    <ext:RecordField Name="emekliEsasGosterge" Type="Int" />
                    <ext:RecordField Name="emekliEsasEkGosterge" Type="Int" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;"
        Layout="FitLayout">
        <Items>
            <ext:Panel ID="Panel3" runat="server" Width="230" Layout="BorderLayout" Collapsed="false"
                AutoScroll="true">
                <TopBar>
                    <ext:Toolbar ID="Toolbar2" runat="server">
                        <Items>
                            <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:Personel,FRMPBI003%>"
                                Icon="ApplicationGo">
                                <DirectEvents>
                                    <Click OnEvent="PersonelListele">
                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:Personel,FRMPAB020%>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSecKapat" runat="server" Text="Seç Kapat" Icon="ArrowRight" Hidden="true">
                                <Listeners>
                                    <Click Fn="CokluSecKapat" />
                                </Listeners>
                            </ext:Button>
                            <ext:Button ID="btnSec" runat="server" Text="Seç" Icon="ArrowRight" Hidden="true">
                                <Listeners>
                                    <Click Fn="CokluSecKapatma" />
                                </Listeners>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="FormPanel1" runat="server" Height="60" LabelWidth="120" Layout="AnchorLayout"
                        Frame="false" Header="false" Border="false" Padding="5" Region="North">
                        <Items>
                            <ext:ExtOrgSecim ID="ddlBirim" runat="server" FieldLabel="<%$ Resources:Personel,FRMPRM026%>"
                                AnchorHorizontal="99%" />
                            <ext:TextField runat="server" ID="txtGenelSorgu" FieldLabel="Arama Kriteri" AnchorHorizontal="99%" />
                        </Items>
                    </ext:FormPanel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" Width="350" Border="false" Title="Personel Listesi"
                        Header="true" AutoExpandColumn="AD" Region="Center" Selectable="true">
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:CommandColumn Width="30">
                                    <Commands>
                                        <ext:GridCommand Icon="ArrowRight" CommandName="sec">
                                        </ext:GridCommand>
                                    </Commands>
                                </ext:CommandColumn>
                                <ext:Column ColumnID="TCKIMLIKNO" DataIndex="TCKIMLIKNO" Width="100" Header="<%$ Resources:Personel,FRMPAB019 %>" />
                                <ext:Column ColumnID="AD" DataIndex="AD" Width="80" Header="<%$ Resources:Personel,FRMPAB021 %>" />
                                <ext:Column ColumnID="SOYAD" DataIndex="SOYAD" Width="80" Header="<%$ Resources:Personel,FRMPAB022 %>" />
                                <ext:Column ColumnID="UNVAN" DataIndex="UNVANAD" Width="80" Header="<%$ Resources:Personel,FRMPAB036 %>" />
                                <ext:Column ColumnID="EPOSTA" DataIndex="EPOSTA" Width="80" Header="ePosta" />
                            </Columns>
                        </ColumnModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="250" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                        <Listeners>
                            <Command Handler="PersonelBilgiAktar(record.data);" />
                        </Listeners>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
