﻿using System;
using System.Collections;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections.Generic;
using TNS.KYM;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel aile sınıfı
    /// </summary>
    public partial class PersonelAile : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPersonelKod.Value = (Request.QueryString["personelKod"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnTemizle.Hidden = true;
            //    btnSil.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                YakininDurumunuDoldur();
                Genel.YakinlikDerecesiDoldur(ddlYakinlik, yakinlikDerecesiStore);
                Genel.CinsiyetDoldur(ddlCinsiyet, cinsiyetStore);
                YakininOgrenimTipiDoldur();

                Temizle();
                Listele();
            }
        }

        /// <summary>
        /// Girilen kritere göre Kişinin bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel tipinde sınıf</param>
        public void Listele()
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) == 0)
                return;

            ObjectArray pler = servisIKY.PersonelAileListele(kullanan, 0, OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), null, null, null, 0);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            List<object> liste = new List<object>();
            foreach (TNS.IKY.PersonelAile p in pler.objeler)
                liste.Add(new { KOD = p.kod, TCKIMLIKNO = p.tcKimlikNo, ADSOYAD = p.ad + ' ' + p.soyad, YAKINLIK = p.yakinlikDerecesiAd });

            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }

        /// <summary>
        /// Kaydet düğmesine basınca ekrandan bilgileri toplayarak kayıt etmek için sunucu tarafındaki metodu çağıran metod
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            //Kaydedilecek yakının bilgileri
            TNS.IKY.PersonelAile kisininYakini = new TNS.IKY.PersonelAile();
            kisininYakini.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            kisininYakini.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            kisininYakini.tcKimlikNo = txtTCKimlikNo.Text.Trim();
            kisininYakini.ad = txtAd.Text.Trim();
            kisininYakini.soyad = txtSoyad.Text.Trim();
            kisininYakini.cinsiyet = (ENUMCINSIYET)OrtakFonksiyonlar.ConvertToInt(ddlCinsiyet.SelectedItem.Value, 0);
            kisininYakini.yakinlik = (ENUMYakinlikDerecesi)OrtakFonksiyonlar.ConvertToInt(ddlYakinlik.SelectedItem.Value, 0);
            kisininYakini.durum = OrtakFonksiyonlar.ConvertToInt(ddlDurum.SelectedItem.Value, 0);
            kisininYakini.dogumTarihi = Genel.TarihAlaniDegerVer(txtDogumTarihi);
            kisininYakini.ogrenimTipi = OrtakFonksiyonlar.ConvertToInt(ddlOgrenimTipi.SelectedItem.Value, 0);
            kisininYakini.meslek = txtMeslek.Text.Trim();

            kisininYakini.sakatlikDerecesi = OrtakFonksiyonlar.ConvertToInt(spnEng.Number, 0);
            kisininYakini.agi = chkAGI.Checked ? 1 : 0;
            kisininYakini.bakmaklaYukumlu = chkYukumlu.Checked ? 1 : 0;
            if (kisininYakini.bakmaklaYukumlu == 1)
            {
                kisininYakini.yukumlulukBitisTarihi = Genel.TarihAlaniDegerVer(txtYukumlulukBitisTarihi);
            }

            Sonuc sonuc = servisIKY.PersonelAileKaydet(kullanan, kisininYakini);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                //Temizle();
                hdnKod.Value = sonuc.anahtar;
                Listele();
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB015);
            }
        }

        /// <summary>
        /// Sil düğmesine basınca ekrandan bilgileri toplayarak silmek için sunucu tarafındaki metodu çağıran metod
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB017);
                return;
            }

            TNS.IKY.PersonelAile d = new TNS.IKY.PersonelAile();
            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            d.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);

            Sonuc sonuc = servisIKY.PersonelAileSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                //BelgeSil(personelTCKimlikNo, (int)ENUMBELGEFORMTIP.PERSONELAILE, hdnAileBireyTcKimlikNo.Value.ToString(), 0);

                Temizle();
                Listele();
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB016);
            }

        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        /// <summary>
        /// Personel bilgilerini MERNİS sisteminden getiren fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Image Click Event Args tipinde sınıf</param>
        protected void KimlikBilgisiGetir(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (txtTCKimlikNo.Text.Trim() == "")
                hata += Resources.InsanKaynaklari.FRMPKS072;

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.Personel p = null;
            try
            {
                p = Genel.KimlikBilgisiGetir(kullanan, txtTCKimlikNo.Text.Trim());
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
                return;
            }

            if (!string.IsNullOrEmpty(p.ad))
            {
                txtTCKimlikNo.Text = p.tcKimlikNo;
                txtAd.Text = p.ad;
                txtSoyad.Text = p.soyad;
                txtDogumTarihi.Text = p.dogumTarihi.ToString();
                ddlCinsiyet.SetValueAndFireSelect((int)p.cinsiyet);
            }
            else
            {
                //Kurumda nufus cüzdanı kontrolü için yetki yoksa
                KullaniciVAN kVAN = GenelIslemler.MernisOku(kullanan, txtTCKimlikNo.Text.Trim(), p.dogumTarihi);
                if (kVAN.sonuc.islemSonuc)
                {
                    txtAd.Text = kVAN.kullanici.ad;
                    txtSoyad.Text = kVAN.kullanici.soyad;
                    txtDogumTarihi.Text = kVAN.kullanici.dogumTarihi.ToString();
                    if (kVAN.kullanici.cinsiyet == "Erkek")
                        ddlCinsiyet.SelectedIndex = 0;
                    else
                        ddlCinsiyet.SelectedIndex = 1;
                }
                else
                {
                    txtAd.Text = "";
                    txtSoyad.Text = "";
                }
            }
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            hdnKod.Value = e.ExtraParams["kod"];
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            ObjectArray pler = servisIKY.PersonelAileListele(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), null, null, null, 0);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            foreach (TNS.IKY.PersonelAile p in pler.objeler)
            {
                txtYukumlulukBitisTarihi.Text = p.yukumlulukBitisTarihi.ToString();
                ddlCinsiyet.Value = (int)p.cinsiyet;
                ddlYakinlik.Value = (int)p.yakinlik;
                ddlDurum.Value = p.durum;
                ddlOgrenimTipi.Value = p.ogrenimTipi;
                txtMeslek.Text = p.meslek;
                txtTCKimlikNo.Text = p.tcKimlikNo;
                txtAd.Text = p.ad;
                txtSoyad.Text = p.soyad;
                txtDogumTarihi.Text = p.dogumTarihi.ToString();
                spnEng.Number = p.sakatlikDerecesi;
                chkAGI.Checked = (p.agi == 1);
                if (p.bakmaklaYukumlu == 1)
                {
                    chkYukumlu.Checked = true;
                    txtYukumlulukBitisTarihi.Hidden = false;
                }
                else
                {
                    chkYukumlu.Checked = false;
                    txtYukumlulukBitisTarihi.Hidden = true;
                }
            }

            BelgeListesiDoldur();
        }

        void Temizle()
        {
            ddlOgrenimTipi.Clear();
            hdnKod.Clear();
            ddlCinsiyet.Clear();
            ddlYakinlik.Clear();
            ddlDurum.Clear();
            txtTCKimlikNo.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            txtDogumTarihi.Text = "";
            chkYukumlu.Checked = false;
            txtYukumlulukBitisTarihi.Clear();
            txtMeslek.Clear();
            grdListeSelectionModel.ClearSelections();
            BelgeStore.RemoveAll();
            BelgeStore.DataBind();
        }

        protected void YakininDurumunuDoldur()
        {
            ddlDurum.Items.Clear();
            yakininDurumuStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.YAKININDURUMU, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            yakininDurumuStore.DataBind();
        }

        protected void YakininOgrenimTipiDoldur()
        {
            ddlOgrenimTipi.Items.Clear();
            yakininOgrenimTipiStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.AILEOGRENIMTIPI, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            yakininOgrenimTipiStore.DataBind();
        }

        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELAILE;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnKod.Value.ToString().Trim()))
            {
                btnKaydet_Click(null, null);
                //GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMPAB040, Resources.InsanKaynaklari.FRMPAB041);
                //return;
            }

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELAILE, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }

        protected void NufusYazdir(object sender, DirectEventArgs e)
        {
            int istekTur = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["Kod"], 1);

            System.Collections.Hashtable raporParam = new Hashtable();
            raporParam["TCKimlikNo"] = txtTCKimlikNo.Text.Trim();
            raporParam["DUZENLEYENAD"] = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKDUZENLEYENAD");
            raporParam["DUZENLEYENUNVAN"] = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKDUZENLEYENUNVAN");
            raporParam["ONAYLAYANAD"] = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKONAYLAYANAD");
            raporParam["ONAYLAYANUNVAN"] = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKONAYLAYANUNVAN");

            TNS.Raporlama.RaporlamaServis.TekRaporAl(500, istekTur, kullanan, null, raporParam);
        }
    }
}
