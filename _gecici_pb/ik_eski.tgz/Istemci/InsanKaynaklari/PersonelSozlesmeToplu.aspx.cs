﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;
using System.Collections.Generic;
using System.IO;
using Aspose.Words;
using TNS.MUH;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class PersonelSozlesmeToplu : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = "Toplu Personel Sözşleşme Sayfası";
            servis = TNS.IKY.Arac.Tanimla();
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                ddlYil.Value = DateTime.Now.Year;
                Listele();
            }
        }


        protected void Listele()
        {
            PersonelSozlesme form = new PersonelSozlesme();

            ObjectArray oa = servis.PersonelSozlesmeListele(kullanan, form);
            if (!oa.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, oa.sonuc.hataStr);
            }

            strListe.DataSource = oa.objeler;
            strListe.DataBind();
        }

        protected void btnListele_Click(object sender, DirectEventArgs e)
        {
            Listele();
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            if (OrtakFonksiyonlar.ConvertToInt(ddlYil.Value, 0) <= DateTime.MinValue.Year)
            {
                GenelIslemler.MesajKutusu("Hata", "Yıl bilgisi boş bırakılamaz.");
                return;
            }

            string p = e.ExtraParams["LISTE"];

            Newtonsoft.Json.Linq.JArray detaySatirlari = (Newtonsoft.Json.Linq.JArray)JSON.Deserialize(p);
            List<PersonelSozlesme> liste = new List<PersonelSozlesme>();

            foreach (Newtonsoft.Json.Linq.JObject item in detaySatirlari)
            {
                PersonelSozlesme form = new PersonelSozlesme();
                form.kod = item.Value<int>("kod");
                form.yil = OrtakFonksiyonlar.ConvertToInt(ddlYil.Value, 0);
                form.tcKimlikNo = item.Value<string>("tcKimlikNo");
                form.adSoyad = item.Value<string>("adSoyad");
                form.basTarih = new TNSDateTime(item.Value<DateTime>("basTarihDT"));
                form.bitTarih = new TNSDateTime(item.Value<DateTime>("bitTarihDT"));
                form.tutar = item.Value<double>("tutar");
                form.sozlesmeKod = item.Value<int>("sozlesmeKod");

                liste.Add(form);
            }

            Sonuc sonuc = servis.PersonelSozlesmeKaydet(kullanan, liste.ToArray());

            if (sonuc.islemSonuc)
            {
                //strListe.CommitChanges();
                Listele();
            }
            else
                GenelIslemler.MesajKutusu("Hata", sonuc.hataStr);
        }

        [DirectMethod(ShowMask = true)]
        public string PersonelSil(int kod, int sozlesmeKod)
        {
            Sonuc sonuc = servis.PersonelSozlesmeSil(kullanan, new PersonelSozlesme() { kod = kod, sozlesmeKod = sozlesmeKod });

            if (!sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu("Hata", sonuc.hataStr);
                return "0";
            }
            return "1";
        }
    }
}
