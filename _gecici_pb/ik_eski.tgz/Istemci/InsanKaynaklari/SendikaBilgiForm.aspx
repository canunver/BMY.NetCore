﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.SendikaBilgiForm " CodeBehind="SendikaBilgiForm.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title><%= Resources.InsanKaynaklari.SendikaBilgi004%></title>
    <style type="text/css">
        .SadeceOkuma {
            background-color: antiquewhite
        }
    </style>

    <script type="text/javascript">
        function SeciliKodAd() {
            if (rsSendikaPersonel.selections.items.length > 0)
                return rsSendikaPersonel.selections.items[0].data.kod;
            else
                return -1;
        }

        function PersonelleriEkle(secilenler) {
            var secili_json = JSON.stringify(secilenler);
            Ext1.net.DirectMethods.KisileriEkle(secili_json);
        }

        function btnKisiEkleClick() {
            var adres = "../InsanKaynaklari/ListePersonelSec.aspx?menuYok=1&cokluSec=1&maas=1";
            showPopWin(adres, 500, 440, true, null);
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
        <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
        <ext:ResourceManager runat="server"></ext:ResourceManager>
        <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
            <Items>
                <ext:Panel runat="server" Region="Center" Layout="ColumnLayout" Margins="104 20 10 20">
                    <Items>
                        <ext:GridPanel runat="server" Width="300" AutoExpandColumn="sendikaAd">
                            <TopBar>
                                <ext:Toolbar runat="server">
                                    <Items>
                                        <ext:Button runat="server" Icon="Add" Text="Yeni Sendika">
                                            <DirectEvents>
                                                <Click OnEvent="YeniSendika" />
                                            </DirectEvents>
                                        </ext:Button>
                                    </Items>
                                </ext:Toolbar>
                            </TopBar>
                            <SelectionModel>
                                <ext:RowSelectionModel runat="server">
                                    <DirectEvents>
                                        <RowSelect OnEvent="SendikaSecildi">
                                            <ExtraParams>
                                                <ext:Parameter Name="kod" Value="this.getSelected().data.sendikaNo" Mode="Raw" />
                                            </ExtraParams>
                                        </RowSelect>
                                    </DirectEvents>
                                </ext:RowSelectionModel>
                            </SelectionModel>
                            <Store>
                                <ext:Store runat="server" ID="stoSendikaListesi">
                                    <Reader>
                                        <ext:JsonReader>
                                            <Fields>
                                                <ext:RecordField Name="sendikaNo" Type="Int"></ext:RecordField>
                                                <ext:RecordField Name="sendikaAd" Type="String"></ext:RecordField>
                                            </Fields>
                                        </ext:JsonReader>
                                    </Reader>
                                </ext:Store>
                            </Store>
                            <ColumnModel>
                                <Columns>
                                    <ext:Column DataIndex="sendikaNo" ColumnID="sendikaNo" Header="No" Width="60" />
                                    <ext:Column DataIndex="sendikaAd" ColumnID="sendikaAd" Header="Sendika Ad" />
                                </Columns>
                            </ColumnModel>
                        </ext:GridPanel>

                        <ext:Panel runat="server" ColumnWidth="1" Layout="RowLayout">
                            <TopBar>
                                <ext:Toolbar runat="server">
                                    <Items>
                                        <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, SendikaBilgi017%>" TabIndex="7" Icon="DatabaseSave">
                                            <DirectEvents>
                                                <Click OnEvent="btnKaydet_Click">
                                                    <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, SendikaBilgi018%>" Message="<%$ Resources:InsanKaynaklari, SendikaBilgi019%>" />
                                                    <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, SendikaBilgi020%>" />
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:Button ID="btnYazdir" runat="server" Text="<%$ Resources:InsanKaynaklari, SendikaBilgi021%>" TabIndex="8" Icon="Printer" Hidden="true">
                                            <DirectEvents>
                                                <Click OnEvent="btnYazdir_Click">
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:ToolbarSpacer Width="20" />
                                        <ext:Label runat="server" Text="Kes. Oranı:" />
                                        <ext:ToolbarSpacer Width="5" />
                                        <ext:NumberField runat="server" ID="nfKesintiOrani" Width="120" DecimalPrecision="4" DecimalSeparator="," />
                                        <ext:Button runat="server" Icon="Add" Text="Personel Ekle">
                                            <Listeners>
                                                <Click Fn="btnKisiEkleClick" />
                                            </Listeners>
                                        </ext:Button>
                                        <ext:Button runat="server" Icon="ArrowLeft" Text="Değer Ata">
                                            <DirectEvents>
                                                <Click OnEvent="btnKisiDegerAtaClick">
                                                    <ExtraParams>
                                                        <ext:Parameter Name="pkod" Mode="Raw" Value="SeciliKodAd()" />
                                                    </ExtraParams>
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:ToolbarSpacer Width="20" />
                                        <ext:Button runat="server" Icon="Delete" Text="Seç. Per. Sil">
                                            <DirectEvents>
                                                <Click OnEvent="PersonelCikart">
                                                    <Confirmation ConfirmRequest="true" Title="Onay" Message="Seçili kişi personel listesinden çıkartılacaktır, onaylıyor musunuz?" />
                                                    <ExtraParams>
                                                        <ext:Parameter Name="pkod" Mode="Raw" Value="SeciliKodAd()" />
                                                    </ExtraParams>
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                    </Items>
                                </ext:Toolbar>
                            </TopBar>
                            <Items>
                                <ext:FormPanel runat="server" Height="300" ButtonAlign="Center" AutoScroll="true" LabelWidth="120" Padding="5">
                                    <Items>
                                        <ext:TextField runat="server" ID="txtsendikaNo" TabIndex="1" FieldLabel="<%$ Resources:InsanKaynaklari, SendikaBilgi005%>" ReadOnly="true" Cls="SadeceOkuma" />
                                        <ext:TextField runat="server" ID="txtsendikaAd" TabIndex="2" FieldLabel="<%$ Resources:InsanKaynaklari, SendikaBilgi007%>">
                                            <ToolTips>
                                                <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, SendikaBilgi008%>" runat="server"></ext:ToolTip>
                                            </ToolTips>
                                        </ext:TextField>
                                        <ext:TextField runat="server" ID="txtadres" TabIndex="3" FieldLabel="<%$ Resources:InsanKaynaklari, SendikaBilgi009%>">
                                            <ToolTips>
                                                <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, SendikaBilgi010%>" runat="server"></ext:ToolTip>
                                            </ToolTips>
                                        </ext:TextField>
                                        <ext:TextField runat="server" ID="txtiBAN" TabIndex="4" FieldLabel="<%$ Resources:InsanKaynaklari, SendikaBilgi011%>">
                                            <ToolTips>
                                                <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, SendikaBilgi012%>" runat="server"></ext:ToolTip>
                                            </ToolTips>
                                        </ext:TextField>
                                        <ext:TextField runat="server" ID="txthesapNo" TabIndex="5" FieldLabel="<%$ Resources:InsanKaynaklari, SendikaBilgi013%>">
                                            <ToolTips>
                                                <ext:ToolTip Html="<%$ Resources:InsanKaynaklari, SendikaBilgi014%>" runat="server"></ext:ToolTip>
                                            </ToolTips>
                                        </ext:TextField>
                                        <ext:TextField runat="server" ID="txtTopluGorusmePuani" TabIndex="7" FieldLabel="Toplu Görüşme Puanı">
                                            <ToolTips>
                                                <ext:ToolTip Html="Toplu Görüşme Puanını giriniz" runat="server"></ext:ToolTip>
                                            </ToolTips>
                                        </ext:TextField>
                                    </Items>
                                </ext:FormPanel>
                                <ext:GridPanel runat="server" Title="<%$ Resources:InsanKaynaklari, SendikaBilgi022%>" ID="grdSendikaPersonel" ClicksToEdit="1" StripeRows="true" ColumnLines="true" RowHeight="1">
                                    <SelectionModel>
                                        <ext:RowSelectionModel ID="rsSendikaPersonel" runat="server" SingleSelect="true"></ext:RowSelectionModel>
                                    </SelectionModel>
                                    <Store>
                                        <ext:Store runat="server" ID="stoSendikaPersonel">
                                            <Reader>
                                                <ext:JsonReader>
                                                    <Fields>
                                                        <ext:RecordField Name="kod" Type="Int"></ext:RecordField>
                                                        <ext:RecordField Name="ad" Type="String"></ext:RecordField>
                                                        <ext:RecordField Name="soyad" Type="String"></ext:RecordField>
                                                        <ext:RecordField Name="tcKimlikNo" Type="String"></ext:RecordField>
                                                        <ext:RecordField Name="sicilNo" Type="String"></ext:RecordField>
                                                        <ext:RecordField Name="kesintiOrani" Type="Float"></ext:RecordField>
                                                    </Fields>
                                                </ext:JsonReader>
                                            </Reader>
                                        </ext:Store>
                                    </Store>
                                    <ColumnModel>
                                        <Columns>
                                            <ext:Column DataIndex="kod" ColumnID="kod" Header="<%$ Resources:InsanKaynaklari, SendikaBilgi023%>" />
                                            <ext:Column DataIndex="tcKimlikNo" ColumnID="tcKimlikNo" Header="<%$ Resources:InsanKaynaklari, SendikaBilgi026%>" />
                                            <ext:Column DataIndex="sicilNo" ColumnID="sicilNo" Header="<%$ Resources:InsanKaynaklari, SendikaBilgi027%>" />
                                            <ext:Column DataIndex="ad" ColumnID="ad" Header="<%$ Resources:InsanKaynaklari, SendikaBilgi024%>" />
                                            <ext:Column DataIndex="soyad" ColumnID="soyad" Header="<%$ Resources:InsanKaynaklari, SendikaBilgi025%>" />
                                            <ext:Column DataIndex="kesintiOrani" ColumnID="kesintiOrani" Header="Kes. Oranı" />
                                        </Columns>
                                    </ColumnModel>
                                </ext:GridPanel>
                            </Items>
                        </ext:Panel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
        <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
