﻿using System;
using System.Collections.Generic;
using System.Xml;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Tarihçe Sınıfı
    /// </summary>
    public partial class PersonelTarihce : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Personel Tarihçe";
            hdnPersonelKod.Value = (Request.QueryString["personelKod"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //}

            if (!IsPostBack)
            {
                this.Listele();
            }
        }

        private void Listele()
        {
            List<object> liste = new List<object>();
            int pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            //TNS.IKY.PersonelTarihce pt = new TNS.IKY.PersonelTarihce();
            //pt.personelKod = pKod;

            if (pKod > 0)
            {
                string[] list = servisIKY.PersonelTarihceListele(kullanan, pKod);
                foreach (string item in list)
                {
                    string[] satir = item.Split('!');
                    if (satir.Length == 2)
                    {
                        GenelIslemler.MesajKutusu("Hata",item);
                        return;
                    }
                    liste.Add(new
                        {
                            TARIH = new TNSDateTime(satir[0]).Oku(),
                            KATEGORI = satir[1],
                            DEGISENALAN = satir[2],
                            YENIDEGER = satir[3],
                            ESKIDEGER = satir[4],
                            DEGISIKLIKYAPAN = satir[5],
                            ACIKLAMA1 = satir[6],
                            ACIKLAMA2 = satir[7],
                        });
                }
            }
            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }
    }
}

