﻿<%@ Page Language="C#" CodeBehind="TanimNeden.aspx.cs" Inherits="InsanKaynaklari.TanimNeden" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KODU" />
                    <ext:RecordField Name="ADI" />
                    <ext:RecordField Name="BASLAMA" />
                    <ext:RecordField Name="AYRILMA" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center MarginsSummary="104 20 10 20">
                    <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                        Icon="Disk">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                        Icon="Delete">
                                        <DirectEvents>
                                            <Click OnEvent="btnSil_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnAra" runat="server" Text="Bul" Icon="Find">
                                        <DirectEvents>
                                            <Click OnEvent="btnAra_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                        Icon="PageWhite">
                                        <DirectEvents>
                                            <Click OnEvent="btnTemizle_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="BorderLayout2" runat="server">
                                <North>
                                    <ext:FormPanel ID="FormPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                                        AutoHeight="true">
                                        <Items>
                                            <ext:TextField runat="server" ID="txtNedenKodu" Width="40" FieldLabel="Kodu" NoteAlign="Top" />
                                            <ext:TextField runat="server" ID="txtNedenAdi" Width="240" FieldLabel="Açıklama"
                                                NoteAlign="Top" />
                                            <ext:Checkbox runat="server" ID="chkBaslama" Width="140" FieldLabel="Başlama için mi?"
                                                NoteAlign="Top" />
                                            <ext:Checkbox runat="server" ID="chkAyrilma" Width="140" FieldLabel="Ayrılma için mi?"
                                                NoteAlign="Top" />
                                        </Items>
                                    </ext:FormPanel>
                                </North>
                                <Center Split="true">
                                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                        StoreID="ListeStore" Border="true" Layout="FitLayout" Width="400">
                                        <ColumnModel ID="ColumnModel1" runat="server">
                                            <Columns>
                                                <ext:Column DataIndex="KODU" Header="Kodu" />
                                                <ext:Column DataIndex="ADI" Header="Adı" Width="200" />
                                                <ext:Column DataIndex="BASLAMA" Header="Başlama" />
                                                <ext:Column DataIndex="AYRILMA" Header="Ayrılma" />
                                            </Columns>
                                        </ColumnModel>
                                        <SelectionModel>
                                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                                <DirectEvents>
                                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                                        <ExtraParams>
                                                            <ext:Parameter Name="NedenKodu" Value="this.getSelected().data.KODU" Mode="Raw" />
                                                            <ext:Parameter Name="NedenAdi" Value="this.getSelected().data.ADI" Mode="Raw" />
                                                            <ext:Parameter Name="NedenBaslama" Value="this.getSelected().data.BASLAMA" Mode="Raw" />
                                                            <ext:Parameter Name="NedenAyrilma" Value="this.getSelected().data.AYRILMA" Mode="Raw" />
                                                        </ExtraParams>
                                                    </RowSelect>
                                                </DirectEvents>
                                            </ext:RowSelectionModel>
                                        </SelectionModel>
                                        <BottomBar>
                                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                                            </ext:PagingToolbar>
                                        </BottomBar>
                                    </ext:GridPanel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
