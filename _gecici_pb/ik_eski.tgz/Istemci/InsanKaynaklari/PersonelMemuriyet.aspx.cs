﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Memuriyet Sınıfı
    /// </summary>
    public partial class PersonelMemuriyet : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public string personelTCKimlikNo = "";

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);

            personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnTemizle.Hidden = true;
            //    btnSil.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                ddlBirim.KullanicininBirimleri = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");

                Temizle(true);
                IstihdamDoldur();
                NedenDoldur();
                Listele(new TNS.IKY.PersonelMemuriyet());
            }
        }

        TimeSpan toplamMemuriyet = new TimeSpan();

        /// <summary>
        /// Girilen kritere göre Personel Memuriyet bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel Memuriyet tipinde sınıf</param>
        public void Listele(TNS.IKY.PersonelMemuriyet kriter)
        {
            if (string.IsNullOrEmpty(personelTCKimlikNo))
                return;

            kriter.tcKimlikNo = personelTCKimlikNo;
            ObjectArray pler = servisIKY.PersonelMemuriyetListele(kullanan, kriter);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            List<object> liste = new List<object>();
            foreach (TNS.IKY.PersonelMemuriyet p in pler.objeler)
            {
                if (!p.ayrilmaTarihi.isNull)
                    toplamMemuriyet += p.ayrilmaTarihi.Oku() - p.baslamaTarihi.Oku();
                else
                    toplamMemuriyet += DateTime.Now - p.baslamaTarihi.Oku();
                liste.Add(new
                {
                    SIRANO = p.siraNo,
                    ORGKOD = p.organizasyonKodu,
                    MUHASEBEKOD = p.muhasebeKodu,
                    BIRIMKOD = p.birimKodu,
                    KURUM = p.kurum,
                    BIRIMAD = p.birimAd,
                    GOREV = p.gorev,
                    ISTIHDAMSEKLI = p.istihdamSekli,
                    BASLAMATARIHI = p.baslamaTarihi.Oku(),
                    AYRILMATARIHI = p.ayrilmaTarihi.Oku(),
                    BASLAMANEDENI = p.baslamaNedeni,
                    AYRILMANEDENI = p.ayrilmaNedeni,
                    BASLAMANEDENIAD = p.baslamaNedeniAd,
                    AYRILMANEDENIAD = p.ayrilmaNedeniAd,
                    EVRAKNO = p.evrakNo,
                    YASALDAYANAK = p.yasalDayanak,
                    ONAYTARIH = p.onayTarih.ToString(),
                    ACIKLAMA = p.aciklama,

                    KADRODERECE = p.kadroDerece,
                    KADROTARIH = p.kadroTarih.ToString(),

                    KAZANILMISHAKDERECE = p.kazanilmisHakDerece,
                    KAZANILMISHAKKADEME = p.kazanilmisHakKademe,
                    KAZANILMISHAKTARIH = p.kazanilmisHakTarih.ToString(),
                    KAZANILMISGOSTERGE = p.kazanilmisGosterge,
                    KAZANILMISEKGOSTERGE = p.kazanilmisEkGosterge,

                    ODEMEYEESASDERECE = p.odemeyeEsasDerece,
                    ODEMEYEESASKADEME = p.odemeyeEsasKademe,
                    ODEMEYEESASTARIH = p.odemeyeEsasTarih.ToString(),
                    ODEMEYEESASGOSTERGE = p.odemeyeEsasGosterge,
                    ODEMEYEESASEKGOSTERGE = p.odemeyeEsasEkGosterge,

                    EMEKLIYEESASDERECE = p.emekliyeEsasDerece,
                    EMEKLIYEESASKADEME = p.emekliyeEsasKademe,
                    EMEKLIYEESASTARIH = p.emekliyeEsasTarih.ToString(),
                    EMEKLIGOSTERGE = p.emekliyeEsasGosterge,
                    EMEKLIEKGOSTERGE = p.emekliyeEsasEkGosterge,
                });
            }
            ListeStore.DataSource = liste;
            ListeStore.DataBind();
            MemuriyetTarihleriniYaz();

            if (liste.Count > 0)
                grdListeSelectionModel.SelectLastRow();
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel Memuriyet bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            if (OrtakFonksiyonlar.ConvertToStr(ddlBirim.Value) == "")
                hata += Resources.InsanKaynaklari.FRMPKS051 + "<br>";
            if (txtGorev.Text.Trim() == "")
                hata += Resources.InsanKaynaklari.FRMPRM042 + "<br>";
            if (OrtakFonksiyonlar.ConvertToStr(ddlIstihdamSekli.Value) == ""
                || OrtakFonksiyonlar.ConvertToStr(ddlIstihdamSekli.Value) == "0")
                hata += Resources.InsanKaynaklari.FRMPRM043 + "<br>";
            if (txtBaslamaTarihi.Text.Trim() == "")
                hata += Resources.InsanKaynaklari.FRMPRM044 + "<br>";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.PersonelMemuriyet d = new TNS.IKY.PersonelMemuriyet();
            d.tcKimlikNo = personelTCKimlikNo;
            d.siraNo = OrtakFonksiyonlar.ConvertToInt(hdnSiraNo.Value, 0);

            TNS.IKY.Personel p = new TNS.IKY.Personel();
            Genel.BirimDegerleriniAyarla(ref p, OrtakFonksiyonlar.ConvertToStr(ddlBirim.Value));
            //d.organizasyonKodu = p.organizasyonKodu;
            //d.muhasebeKodu = p.muhasebeKodu;
            //d.birimKodu = p.birimKodu;
            //d.kurum = p.kurum;
            d.birimAd = ddlBirim.Text;

            d.gorev = txtGorev.Text;
            d.istihdamSekli = OrtakFonksiyonlar.ConvertToInt(ddlIstihdamSekli.Value, 0);
            d.aciklama = txtAciklama.Text;
            d.baslamaTarihi = Genel.TarihAlaniDegerVer(txtBaslamaTarihi);
            d.ayrilmaTarihi = Genel.TarihAlaniDegerVer(txtAyrilmaTarihi);
            d.baslamaNedeni = OrtakFonksiyonlar.ConvertToInt(ddlBaslamaNeden.Value, 0);
            d.ayrilmaNedeni = OrtakFonksiyonlar.ConvertToInt(ddlAyrilmaNeden.Value, 0);
            d.evrakNo = txtEvrakNo.Text;
            d.yasalDayanak = txtYasalDayanak.Text;
            d.onayTarih = Genel.TarihAlaniDegerVer(txtOnayTarih);

            Sonuc sonuc = servisIKY.PersonelMemuriyetKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Temizle(true);
                Listele(new TNS.IKY.PersonelMemuriyet());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPRM068);
            }
        }

        /// <summary>
        /// Sil butonuna basınca, koda, T.C. Kimlik numarasına göre Personel Öğrenim bilgisi silen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            int siraNo = OrtakFonksiyonlar.ConvertToInt(hdnSiraNo.Value, 0);
            if (string.IsNullOrEmpty(personelTCKimlikNo) || siraNo <= 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPRM070);
                return;
            }

            TNS.IKY.PersonelMemuriyet d = new TNS.IKY.PersonelMemuriyet();
            d.tcKimlikNo = personelTCKimlikNo;
            d.siraNo = siraNo;
            Sonuc sonuc = servisIKY.PersonelMemuriyetSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                PersonelBelgeler belge = new PersonelBelgeler();
                belge.tcKimlikNo = personelTCKimlikNo;
                belge.tip = (int)ENUMBELGEFORMTIP.PERSONELMEMURIYET;
                belge.kayitSiraNo = hdnSiraNo.Value.ToString();
                servisIKY.PersonelBelgeSil(kullanan, belge);

                Temizle(true);
                Listele(new TNS.IKY.PersonelMemuriyet());
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPRM069);
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle(true);
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            Temizle(false);

            string secilisatir = e.ExtraParams["RowValue"].ToString();
            XmlNode xml = JSON.DeserializeXmlNode("{records:{record:" + secilisatir + "}}");
            foreach (XmlNode row in xml.SelectNodes("records/record"))
            {
                hdnSiraNo.Value = row.SelectSingleNode("SIRANO").InnerXml;
                string orgKod = row.SelectSingleNode("ORGKOD").InnerXml;
                string muhasebe = row.SelectSingleNode("MUHASEBEKOD").InnerXml;
                string birim = row.SelectSingleNode("BIRIMKOD").InnerXml;
                string kurum = row.SelectSingleNode("KURUM").InnerXml;
                string birimAd = row.SelectSingleNode("BIRIMAD").InnerXml;
                //if (GenelIslemlerIstemci.OrgSemaPersonelKullaniyorMu())
                //{
                if (OrtakFonksiyonlar.ConvertToInt(orgKod, 0) == 0)
                {
                    OrganizasyonBirim orgBirim = TNS.ORG.Arac.OrgBirimBul(muhasebe, birim, kurum);
                    if (orgBirim != null)
                        orgKod = orgBirim.kod.ToString();
                }
                //}
                //else
                //    orgKod = kurum + "-" + muhasebe + "-" + birim;

                ddlBirim.SetValue(orgKod, birimAd);

                txtGorev.Text = row.SelectSingleNode("GOREV").InnerXml;
                ddlIstihdamSekli.SetValueAndFireSelect(row.SelectSingleNode("ISTIHDAMSEKLI").InnerXml);

                txtBaslamaTarihi.Text =
                row.SelectSingleNode("BASLAMATARIHI") != null ?
                     row.SelectSingleNode("BASLAMATARIHI").InnerXml : "";

                txtAyrilmaTarihi.Text =
                row.SelectSingleNode("AYRILMATARIHI") != null ?
                row.SelectSingleNode("AYRILMATARIHI").InnerXml : "";

                ddlBaslamaNeden.SetValueAndFireSelect(row.SelectSingleNode("BASLAMANEDENI").InnerXml);
                ddlAyrilmaNeden.SetValueAndFireSelect(row.SelectSingleNode("AYRILMANEDENI").InnerXml);
                txtEvrakNo.Text = row.SelectSingleNode("EVRAKNO").InnerXml;
                txtYasalDayanak.Text = row.SelectSingleNode("YASALDAYANAK").InnerXml;
                txtOnayTarih.Text = row.SelectSingleNode("ONAYTARIH").InnerXml;
                txtAciklama.Text = row.SelectSingleNode("ACIKLAMA").InnerXml;


                txtKadroDerece.Text = row.SelectSingleNode("KADRODERECE").InnerXml;
                txtKadroTarih.Text = row.SelectSingleNode("KADROTARIH").InnerXml;
                txtKazanilmisHakDerece.Text = row.SelectSingleNode("KAZANILMISHAKDERECE").InnerXml;
                txtKazanilmisHakKademe.Text = row.SelectSingleNode("KAZANILMISHAKKADEME").InnerXml;
                txtKazanilmisHakTarih.Text = row.SelectSingleNode("KAZANILMISHAKTARIH").InnerXml;
                txtKazanilmisGosterge.Text = row.SelectSingleNode("KAZANILMISGOSTERGE").InnerXml;
                txtKazanilmisEkGosterge.Text = row.SelectSingleNode("KAZANILMISEKGOSTERGE").InnerXml;
                txtOdemeyeEsasDerece.Text = row.SelectSingleNode("ODEMEYEESASDERECE").InnerXml;
                txtOdemeyeEsasKademe.Text = row.SelectSingleNode("ODEMEYEESASKADEME").InnerXml;
                txtOdemeyeEsasTarih.Text = row.SelectSingleNode("ODEMEYEESASTARIH").InnerXml;
                txtOdemeyeEsasGosterge.Text = row.SelectSingleNode("ODEMEYEESASGOSTERGE").InnerXml;
                txtOdemeyeEsasEkGosterge.Text = row.SelectSingleNode("ODEMEYEESASEKGOSTERGE").InnerXml;
                txtEmekliyeEsasDerece.Text = row.SelectSingleNode("EMEKLIYEESASDERECE").InnerXml;
                txtEmekliyeEsasKademe.Text = row.SelectSingleNode("EMEKLIYEESASKADEME").InnerXml;
                txtEmekliyeEsasTarih.Text = row.SelectSingleNode("EMEKLIYEESASTARIH").InnerXml;
                txtEmekliGosterge.Text = row.SelectSingleNode("EMEKLIGOSTERGE").InnerXml;
                txtEmekliEkGosterge.Text = row.SelectSingleNode("EMEKLIEKGOSTERGE").InnerXml;

                pnlKadro.Hidden = false;
            }
            BelgeListesiDoldur(hdnSiraNo.Value.ToString());
        }

        void MemuriyetTarihleriniYaz()
        {
            TNS.IKY.Personel p = servisIKY.PersonelMemuriyetTarihleriListele(personelTCKimlikNo);
            txtMemuriyetBaslamaTarihi.Text = p.ilkIseBaslamaTarihi.ToString();

            if (!p.ilkIseBaslamaTarihi.isNull)
            {
                txtKamuYil.Text = ((int)(toplamMemuriyet.TotalDays / 365)).ToString();
                txtKamuAy.Text = ((int)((toplamMemuriyet.TotalDays % 365) / 30)).ToString();
                txtKamuGun.Text = ((int)((toplamMemuriyet.TotalDays % 365) % 30)).ToString();
            }
        }

        void Temizle(bool gridSecimTemizle)
        {
            hdnSiraNo.Clear();
            ddlBirim.Clear();
            txtGorev.Clear();
            ddlIstihdamSekli.Clear();
            txtAciklama.Clear();
            Genel.TarihAlanTemizle(ref txtBaslamaTarihi, false);
            Genel.TarihAlanTemizle(ref txtAyrilmaTarihi, true);
            ddlBaslamaNeden.Clear();
            ddlAyrilmaNeden.Clear();
            txtEvrakNo.Clear();
            txtYasalDayanak.Clear();
            txtOnayTarih.Clear();
            BelgeStore.RemoveAll();
            BelgeStore.DataBind();

            pnlKadro.Hide();

            if (gridSecimTemizle)
                grdListeSelectionModel.ClearSelections();
        }
        void IstihdamDoldur()
        {
            ddlIstihdamSekli.Items.Add(new ListItem("", ""));
            ddlIstihdamSekli.Items.Add(new ListItem(Resources.InsanKaynaklari.FRMKAD023_1, "1"));
            ddlIstihdamSekli.Items.Add(new ListItem(Resources.InsanKaynaklari.FRMKAD023_2, "2"));//5-->2
            ddlIstihdamSekli.Items.Add(new ListItem(Resources.InsanKaynaklari.FRMKAD023_3, "3"));
            ddlIstihdamSekli.Items.Add(new ListItem(Resources.InsanKaynaklari.FRMKAD023_4, "4"));//10-->4
            ddlIstihdamSekli.Items.Add(new ListItem(Resources.InsanKaynaklari.FRMKAD023_5, "5"));
            ddlIstihdamSekli.Items.Add(new ListItem(Resources.InsanKaynaklari.FRMKAD023_20, "20"));
            ddlIstihdamSekli.Items.Add(new ListItem(Resources.InsanKaynaklari.FRMKAD023_21, "21"));
        }
        void NedenDoldur()
        {
            ObjectArray dler = servisIKY.NedenListele(new Neden());

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    ArrayList alBaslama = new ArrayList();
                    ArrayList alAyrilma = new ArrayList();
                    ddlBaslamaNeden.Items.Clear();
                    ddlAyrilmaNeden.Items.Clear();

                    alBaslama.Add(new object[] { 0, "" });
                    alAyrilma.Add(new object[] { 0, "" });
                    foreach (Neden d in dler.objeler)
                    {
                        if (d.kod > 0)
                        {
                            if (d.baslama > 0)
                                alBaslama.Add(new object[] { d.kod, d.ad });
                            if (d.ayrilma > 0)
                                alAyrilma.Add(new object[] { d.kod, d.ad });
                        }
                    }

                    nedenBaslamaStore.DataSource = (object[])alBaslama.ToArray(typeof(object[]));
                    nedenBaslamaStore.DataBind();
                    nedenAyrilmaStore.DataSource = (object[])alAyrilma.ToArray(typeof(object[]));
                    nedenAyrilmaStore.DataBind();
                }
            }
        }

        void BelgeListesiDoldur(string kayitSiraNo)
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.tcKimlikNo = personelTCKimlikNo;
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELMEMURIYET;
            belge.kayitSiraNo = kayitSiraNo;

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    TCKIMLIKNO = detay.tcKimlikNo,
                    TIP = detay.tip,
                    KAYITSIRANO = detay.kayitSiraNo,
                    BELGESIRANO = detay.belgeSiraNo,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnSiraNo.Value.ToString().Trim()))
            {
                GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMORT080, Resources.InsanKaynaklari.FRMPRM113);
                return;
            }

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(personelTCKimlikNo, (int)ENUMBELGEFORMTIP.PERSONELMEMURIYET, hdnSiraNo.Value.ToString(), btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur(yeniBelge.kayitSiraNo);
        }

        [DirectMethod]
        public void BelgeGoster(string tcKimlikNo, int tip, string kayitSiraNo, int belgeSiraNo)
        {
            PersonelBelgeler belgeParam = new PersonelBelgeler(tcKimlikNo, tip, kayitSiraNo, belgeSiraNo);
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, belgeParam);

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(string tcKimlikNo, int tip, string kayitSiraNo, int belgeSiraNo)
        {
            PersonelBelgeler belgeParam = new PersonelBelgeler(tcKimlikNo, tip, kayitSiraNo, belgeSiraNo);
            if (string.IsNullOrEmpty(belgeParam.tcKimlikNo) || belgeParam.tip <= 0 || string.IsNullOrEmpty(belgeParam.kayitSiraNo))
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            servisIKY.PersonelBelgeSil(kullanan, belgeParam);
            BelgeListesiDoldur(belgeParam.kayitSiraNo);
        }
    }
}
