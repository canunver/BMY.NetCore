﻿using System;
using System.Collections;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Collections.Generic;
using TNS.KYM;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel aile sınıfı
    /// </summary>
    public partial class PersonelGider : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        int personelKod;
        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            personelKod = GenelIslemlerIstemci.RequestBul(this, "personelKod", -1);

            if (!IsPostBack)
            {
                Temizle();
                spnYil.Number = DateTime.Now.Year;
                spnAy.Number = DateTime.Now.Month;
                stoHarcamaTur.DataSource = IKYPersonelGider.HarcamaTurListe(false);
                stoHarcamaTur.DataBind();
                Listele();

            }
        }

        /// <summary>
        /// Girilen kritere göre Kişinin bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel tipinde sınıf</param>
        public void Listele()
        {
            if (personelKod <= 0)
                return;

            IKYPersonelGider gider = new IKYPersonelGider();
            gider.pKod = personelKod;
            gider.kriterYil = OrtakFonksiyonlar.ConvertToInt(spnYil.Number, -1);
            gider.kriterAy = OrtakFonksiyonlar.ConvertToInt(spnAy.Number, -1);

            ObjectArray pler = servisIKY.PersonelGiderListele(kullanan, gider);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            ListeStore.DataSource = pler.objeler;
            ListeStore.DataBind();
        }

        /// <summary>
        /// Kaydet düğmesine basınca ekrandan bilgileri toplayarak kayıt etmek için sunucu tarafındaki metodu çağıran metod
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            if (personelKod <= 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPAB002 + "<br>");
                return;
            }

            Sonuc sonuc = servisIKY.PersonelGiderKaydet(kullanan, EkrandanAl(), hdnYeni.Text == "1");

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                Listele();
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        protected void Listele(object sender, DirectEventArgs e)
        {
            Listele();
        }

        void KontrolleriAyarla(bool yeni)
        {
            hdnYeni.Text = yeni ? "1" : "0";
            txtTarih.ReadOnly = !yeni;
            ddlYerleskeKod.ReadOnly = !yeni;
            cmbHarcamaTur.ReadOnly = !yeni;
            btnKaydet.Text = yeni ? "Ekle" : "Değiştir";
        }

        void Temizle()
        {
            ddlYerleskeKod.Clear();
            cmbHarcamaTur.Clear();
            txtTarih.Clear();
            nfUcret.Clear();
            KontrolleriAyarla(true);
        }

        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            IKYPersonelGider gider = new IKYPersonelGider();
            gider.pKod = personelKod;
            gider.yerleskeKod = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["yerleskeKod"], -1);
            gider.harcamaTur = (IKYPersonelGider.ENUMPersonelHarcamaTur)OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["harcamaTur"], -1);
            gider.tarih = new TNSDateTime(e.ExtraParams["tarihDT"]);
            if (personelKod <= 0)
                return;

            ObjectArray pler = servisIKY.PersonelGiderListele(kullanan, gider);

            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }
            else if (pler.ObjeSayisi == 1)
            {
                EkranaYaz((IKYPersonelGider)pler.objeler[0]);
            }
            else
            {
                GenelIslemler.MesajKutusu(this, "Okunan kayıt sayısı:" + pler.ObjeSayisi);
                return;
            }
        }

        private void EkranaYaz(IKYPersonelGider gider)
        {
            txtTarih.Text = gider.tarih.ToLongString();
            ddlYerleskeKod.SetValue(gider.yerleskeKod.ToString(), gider.yerleskeAdi);
            cmbHarcamaTur.SetValue((int)gider.harcamaTur);
            nfUcret.Number = gider.tutar;
            KontrolleriAyarla(false);
        }

        protected void btnKumDosyaYukle_Click(object sender, DirectEventArgs e)
        {
            IKYPersonelGider pg = EkrandanAl();
            int yil = OrtakFonksiyonlar.ConvertToInt(spnYil.Number, 0);
            int ay = OrtakFonksiyonlar.ConvertToInt(spnAy.Number, 0);
            Sonuc s = new Sonuc();
            if (yil == 0 || ay == 0)
            {
                s.DegerAta("Lütfen Yıl ve Ay Seçiniz!");
            }
            if (pg.yerleskeKod == 0)
            {
                s.DegerAta("Lütfen Yerleşke Seçiniz");
            }
            
            if (s.islemSonuc)
            {
                pg.tarih = new TNSDateTime(new DateTime(yil, ay, DateTime.DaysInMonth(yil, ay)));
                Tablo XLS = GenelIslemler.NewTablo();
                XLS.DosyaOkuAc(fuKumDosyaYukle.FileContent);
                int sat = 0;
                TNSCollection liste = new TNSCollection();
                while (true)
                {
                    string tcOrSic = XLS.HucreDegerAl(sat, 0);
                    double tutar = XLS.HucreDegerAlDbl(sat, 1);
                    sat++;
                    if (string.IsNullOrWhiteSpace(tcOrSic)) break;
                    if (tutar > 0)
                    {
                        IKYPersonelGider pgIc = new IKYPersonelGider(pg);
                        pgIc.tckimlikNo = tcOrSic;
                        pgIc.tutar = tutar;
                        liste.Add(pgIc);
                    }
                }
                if (liste.Count == 0)
                {
                    s.DegerAta("Yüklenecek veri bulunamadı");
                }
                else
                    s = servisIKY.PersonelGiderYukle(kullanan, liste);
            }
            if (s.islemSonuc)
                GenelIslemler.MesajKutusu(this, "Veriler yüklendi. " + s.bilgiStr);
            else
                GenelIslemler.MesajKutusu(this, "Veriler yüklenemedi:" + s.hataStr);
            fuKumDosyaYukle.Reset();
        }

        private IKYPersonelGider EkrandanAl()
        {
            IKYPersonelGider gider = new IKYPersonelGider();
            gider.pKod = personelKod;
            gider.tarih = new TNSDateTime(txtTarih.RawText);
            gider.yerleskeKod = OrtakFonksiyonlar.ConvertToInt(ddlYerleskeKod.Value.ToString(), 0);
            gider.harcamaTur = (IKYPersonelGider.ENUMPersonelHarcamaTur)OrtakFonksiyonlar.ConvertToInt(cmbHarcamaTur.SelectedItem.Value, 0);
            gider.tutar = nfUcret.Number;
            return gider;
        }

        [DirectMethod(Namespace = "PerGider")]
        public void CBVeriAktar()
        {
            IKYPersonelGider gider = new IKYPersonelGider();
            gider.kriterYil = OrtakFonksiyonlar.ConvertToInt(spnYil.Number, -1);
            gider.kriterAy = OrtakFonksiyonlar.ConvertToInt(spnAy.Number, -1);
            gider.harcamaTur = (IKYPersonelGider.ENUMPersonelHarcamaTur)OrtakFonksiyonlar.ConvertToInt(cmbHarcamaTur.SelectedItem.Value, 0);

            Sonuc s = servisIKY.PersonelGiderAktar(kullanan, gider);
            if (s.islemSonuc)
                Listele();
            else
                GenelIslemler.MesajKutusu("Hata", s.hataStr);
        }
    }
}
