﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class LojmanSiteBlokForm : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.LojmanSite047;
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                ddlSite.SelectedItem.Value = (Request.QueryString["siteKod"] + "").Trim();
                Listele();
                Genel.LojmanSiteDoldur(kullanan, ddlSite, siteStore);
            }
        }

        protected void Listele()
        {
            ObjectArray oa = servis.LojmanSiteBlokListele(kullanan, new LojmanSiteBlok { siteKod = OrtakFonksiyonlar.ConvertToInt(ddlSite.SelectedItem.Value, 0) });
            if (!oa.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, oa.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite002);
            stoLojmanBlokListe.DataSource = oa.objeler;
            stoLojmanBlokListe.DataBind();
        }

        void Oku()
        {
            LojmanSiteBlok form = new LojmanSiteBlok();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
            ObjectVAN ov = servis.LojmanSiteBlokOku(kullanan, form);
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                form = (LojmanSiteBlok)ov.o;
                txtKod.Text = form.kod.ToString();
                //ddlSite.Value = form.siteKod;
                txtblokAdi.Text = form.blokAdi;
                txtblokNo.Text = form.blokNo;
                txtdaireSayisi.Text = form.daireSayisi.ToString();
                chksiteGideri.Checked = (form.siteGideri == 1);
            }
            else if (!ov.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite002);
        }

        void Kaydet(DirectEventArgs e)
        {
            LojmanSiteBlok form = new LojmanSiteBlok();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0);
            form.siteKod = OrtakFonksiyonlar.ConvertToInt(ddlSite.SelectedItem.Value, 0);
            form.blokAdi = txtblokAdi.Text;
            form.blokNo = txtblokNo.Text;
            form.daireSayisi = OrtakFonksiyonlar.ConvertToInt(txtdaireSayisi.Text, 0);
            form.siteGideri = chksiteGideri.Checked ? 1 : 0;
            Sonuc sonuc = servis.LojmanSiteBlokKaydet(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite003);
                Listele();
            }
        }

        /// <summary>
        /// Lojman Site kodu olarak verilen değeri, txtkod alanına atar ve okuma işlemini çağırır.
        /// </summary>
        /// <param name="kod">Personel tipi kodu </param>
        [DirectMethod]
        public void Goster(int kod)
        {
            txtKod.Text = kod.ToString();
            Oku();
        }

        /// <summary>
        /// Listele tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnOku_Click(object sender, DirectEventArgs e)
        {
            Oku();
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        /// <summary>
        /// Yazdir tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
        }

        /// <summary>
        /// Yeni tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnYeni_Click(object sender, DirectEventArgs e)
        {
            Temizle();
        }

        /// <summary>
        /// Sil tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtKod.Text))
            {
                GenelIslemler.BilgiYaz(this, "Silmek istediğiniz bloku seçiniz.");
                return;
            }
            Sonuc sonuc = servis.LojmanSiteBlokSil(kullanan, OrtakFonksiyonlar.ConvertToInt(txtKod.Text, 0));
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.LojmanSite042);
                Listele();
            }
        }

        protected void Temizle()
        {
            txtKod.Clear();
            txtblokAdi.Clear();
            txtblokNo.Clear();
            txtdaireSayisi.Clear();
            //ddlSite.Clear();
            chksiteGideri.Clear();
        }

    }
}
