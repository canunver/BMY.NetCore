﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;
using System.Web.UI.WebControls;
using System.Web.Services;
using TNS.KYM;
using Borland.Delphi.Units;
using System.Web.UI.HtmlControls;

namespace InsanKaynaklari
{
    public partial class PersonelGoruntuleme : istemciUzayi.GenelSayfa
    {
        TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public class ListeSonuc
        {
            public string tablo;
            public int satir;
            public int toplamKayit;
            public bool yukleme = false;
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static ListeSonuc Listele(string genelSorgu, string satir, string aktiflik, string personelTurleri, string resimBilgi)
        {
            TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            ListeSonuc sonuc = new ListeSonuc();
            TNS.IKY.Personel personel = new TNS.IKY.Personel();
            personel.genelSorgu = genelSorgu;
            personel.kayitBasla = TNS.OrtakFonksiyonlar.ConvertToInt(satir, 0);
            personel.kayitToplam = 30;
            personel.aktifDurum = TNS.OrtakFonksiyonlar.ConvertToInt(aktiflik, 0);
            //if (string.IsNullOrWhiteSpace(personelTurleri))
            //    personel.personelTipleri = "1";
            //else
            personel.personelTipleri = personelTurleri;
            //Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.ObjectArray liste = servisIKY.PersonelListele(null, personel, false, true);

            if (!liste.sonuc.islemSonuc)
                throw new Exception(liste.sonuc.hataStr);
            string tablo = "";
            int sonuncuSatir = 0, cnt = 0;
            if (liste.ObjeSayisi > 0)
            {
                int icYukseklik = 245;
                int disYukseklik = 505;
                if (resimBilgi == "2")
                {
                    icYukseklik = 390;
                    disYukseklik = 455;
                }
                //tablo += "<div class=\"col-xs-12 col-md-12 col-sm-12\">";
                //string dondu = (Request.QueryString["dondu"] + "").Trim();
                //string sutunSinifi = "";
                //if(dondu=="true")
                //    sutunSinifi = "col-xs-12 col-md-4 col-sm-6";
                foreach (TNS.IKY.Personel p in liste.objeler)
                {
                    if (resimBilgi == "1")
                    {
                        tablo += " <div class=\"col-lg-3 col-xs-12 col-md-3 col-sm-4\"> " +
                               "  <div class=\"thumbnail\"> " +
                               "             <div class=\"panel-heading\">" +
                                "                <h6 class=\"panel-title\">" +
                                 "               </h6>" +
                                  "              <div class=\"heading-elements\">" +
                                   "                 <form class=\"heading-form\" action=\"#\">" +
                                    "                <div class=\"form-group\">" +
                                     "                   <label class=\"checkbox-inline checkbox-right\">" +
                                      "                      <input type=\"checkbox\" class=\"styled\"> Seç" +
                                       "                 </label>" +
                                        "            </div>" +
                                         "           </form>" +
                                          "      </div>" +
                                           " </div>" +
                                            "<div class=\"thumb\">" +
                                              "  <img src=\"" + p.resimYol + "\" alt=\"\">" +
                                            "</div>" +
                                            "<div class=\"caption\">" +
                                             "   <h6 class=\"text-semibold no-margin\">" + p.adSoyad +
                                              "       <small class=\"display-block\">" + p.kadro.unvanAd + "</small> <small class=\"display-block\">" + p.personelTipAd +
                                                   "     </small> <small class=\"display-block\">" + p.kadro.birimAd + "</small> <small class=\"display-block\">" +
                                                       "     <a href=\"#\" class=\"btn bg-teal\"><i class=\"icon-paperplane position-right\"></i>Detay</a></small>" +
                                              "  </h6>" +
                                            "</div>" +
                                       " </div>" +
                                    "</div>";
                    }
                    else
                    {
                        tablo += "<div class=\"col-xs-12 col-md-3 col-sm-4\">" +
                                  "      <div class=\"panel panel-body\">" +
                                   "         <div class=\"media\">" +
                                    "            <div class=\"media-body\">" +
                                     "               <h6 class=\"media-heading\">" + p.adSoyad +
                                      "                  </h6>" +
                                       "             <span class=\"text-muted\">" + p.kadro.unvanAd + "</span>" +
                                     "  <span class=\"text-muted\">" + p.personelTipAd + "</span>" +
                                       "    <span class=\"text-muted\">" + p.kadro.birimAd + "</span>" +
                                        "        </div>" +
                                         "   </div>" +
                                       " </div>" +
                                   " </div>";
                    }
                    //tablo += " <div class=\"col-xs-12 col-md-3 col-sm-4 alan\" id=\"alan" + p.kod + "\">";
                    //tablo += " <div class=\"thumbnail style=\"height:" + disYukseklik + "px; background-color:#F8F8F8\" ondblclick=\"DetayaGit('" + p.kod + "','" + genelSorgu + "','" + aktiflik + "'" + ",'" + personelTurleri + "', '" + resimBilgi + "');\">";
                    //if (resimBilgi == "1")
                    //    tablo += string.Format("<img src='" + p.resimYol + "'  class=\"img-thumbnail\" style=\"height: 200px;\" />");
                    //tablo += " <div class=\"caption\">";
                    //tablo += "<div class=\"row\" style=\"height:" + icYukseklik + "px; padding: 5px 5px 0 10px; \">";
                    //tablo += " <h3>" + p.adSoyad + "</h3>";
                    //tablo += " <p > " + p.KADRO.unvanAd + "<br>" + p.personelTipAd + "<br>" + p.KADRO.birimAd + "</p></div>";
                    //tablo += "<div class=\"row\"> ";
                    //tablo += " <div class=\"col-xs-6 col-md-6 col-sm-6\"> <label> <input name=\"type\" type=\"checkbox\" value=\"" + p.kod + "\" class=\"chkPersonel\"/>Seç </label></div>";
                    //tablo += " <div class=\"col-xs-6 col-md-6 col-sm-6 text-right\"<p> <a href=\"TabletPersonelDetay.aspx?pKod=" + p.kod + "&dondu=true" + "&sorgu=" + genelSorgu + "&aktiflik=" + aktiflik + "&tipler=" + personelTurleri + "&resim=" + resimBilgi + "\" class=\"btn btn-primary\" role=\"button\">Detay</a> </p> ";
                    //tablo += " </div></div> </div> </div> </div>";

                    if (cnt == liste.ObjeSayisi - 1)
                        sonuncuSatir = p.satir;
                    cnt++;
                }
                //tablo += "</div>";
            }

            if (satir != "0")
                sonuc.yukleme = true;
            sonuc.tablo = tablo;
            sonuc.satir = sonuncuSatir;
            sonuc.toplamKayit = liste.sonuc.kayitSay;

            return sonuc;
        }
    }
}