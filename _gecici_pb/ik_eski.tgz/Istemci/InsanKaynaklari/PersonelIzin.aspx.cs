﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using EkRtfReport;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;
using TNS.UZY;
using Aspose.Words;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel İzin Sınıfı
    /// </summary>
    public partial class PersonelIzin : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = null;

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            servisIKY = TNS.IKY.Arac.Tanimla();
            if (!IsPostBack)
            {
                hdnPersonelKod.Text = (Request.QueryString["personelKod"] + "").Trim();
                ctlIzinDonem.YilMaks = DateTime.Now.Year;
                ctlIzinDonem.Yil = IzinArac.DonemYiliBul(DateTime.Now.Year, DateTime.Now.Month);
                IzinTurStore.DataSource = IzinTurleri();
                IzinTurStore.DataBind();
                TelefonDoldur();

                if (TNS.DEG.Arac.ManasKullaniyor())
                {
                    txtTeklifEden.Visible = false;
                    txtImzaAtan.Visible = false;
                }
            }
        }

        private TNSCollection IzinTurleri()
        {
            return Genel.IzinTipDondur(false);
        }

        /// <summary>
        /// Girilen kritere göre Personel İzin bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel Mal Bildirimi tipinde sınıf</param>
        public void Listele(int donemYil)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0) <= 0)
                return;

            TNS.IKY.PersonelIzin kriter = new TNS.IKY.PersonelIzin();
            kriter.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            kriter.donemYil = donemYil;

            ObjectArray pler = servisIKY.PersonelIzinListele(kullanan, kriter);
            if (!pler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, pler.sonuc.hataStr);
                return;
            }

            ListeStore.DataSource = pler.objeler;
            ListeStore.DataBind();
            IzinSureBilgiHesapla(donemYil);
        }

        protected void ctlIzinDonem_Degisti(object sender, DirectEventArgs e)
        {
            Listele(OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["yil"], 0));
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel İzin bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>        
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            TNS.IKY.PersonelIzin d = new TNS.IKY.PersonelIzin();
            d.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            d.tcKimlikNo = hdnTCKimlikNo.Text;
            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            d.izinTurKod = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.ConvertToStr(ddlIzinTip.Value).Split(';')[0], 0);
            d.baslangicTarihi = Genel.TarihAlaniDegerVer(txtBaslama);
            d.bitisTarihi = Genel.TarihAlaniDegerVer(txtBitis);
            d.izinYeri = txtIzinYeri.Text;
            d.aciklama = txtAciklama.Text;
            d.telefon = ddlTelefon.Text;
            d.belgeNo = txtBelgeNo.Text;
            d.belgeTarihi = Genel.TarihAlaniDegerVer(txtBelgeTarihi);
            d.memuriyeti = txtMemuriyeti.Text;
            d.saglikKurulusu = txtSaglikKurulusu.Text;

            d.raporTarihi = Genel.TarihAlaniDegerVer(dfRaporTarihi);
            d.raporNo = txtRaporNo.Text;
            d.yatiliGecenSure = OrtakFonksiyonlar.ConvertToInt(nfYatiliGecenSure.Number, 0);
            d.yerKod = hdnYerKod.Text;
            d.imzalayan = OrtakFonksiyonlar.ConvertToInt(hdnImzaAtan.Value, 0);
            d.teklifEden = OrtakFonksiyonlar.ConvertToInt(hdnTeklifEden.Value, 0);
            d.yerineGorevli = OrtakFonksiyonlar.ConvertToInt(hdnYerineGorevli.Value, 0);
            d.izinNotu2 = txtIzinNotu2.Text;

            TNS.Sonuc sonuc = servisIKY.PersonelIzinKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                hdnKod.Value = sonuc.anahtar;
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL017);
                Listele(OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["yil"], 0));
            }
        }

        protected void GunAl(object sender, DirectEventArgs e)
        {
            int tip = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.ConvertToStr(ddlIzinTip.Value).Split(';')[0], 0);
            TNSDateTime baslangicTarihi = Genel.TarihAlaniDegerVer(txtBaslama);
            TNSDateTime bitisTarihi = Genel.TarihAlaniDegerVer(txtBitis);
            if (baslangicTarihi.Yil != 0 && bitisTarihi.Yil != 0)
                txtIzinGun.Text = TNS.IKY.IzinArac.IzinHesapla(tip, baslangicTarihi.Oku(), bitisTarihi.Oku()).ToString();
        }

        /// <summary>
        /// Sil düğmesine basınca, koda, T.C. Kimlik numarasına göre izin bilgisi silen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            int perIzinKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            int perKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);

            if (perKod <= 0 || perIzinKod <= 0)
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMIZN020);
                return;
            }

            TNS.IKY.PersonelIzin d = new TNS.IKY.PersonelIzin();
            d.personelKod = perKod;
            d.kod = perIzinKod;
            TNS.Sonuc sonuc = servisIKY.PersonelIzinSil(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPDL018);
                Listele(OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["yil"], 0));
                Temizle();
            }
        }

        /// <summary>
        /// Kullanıcı arayüzündeki alanların içeriğini temizleyen fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void YazdirAcKapa()
        {
            DateTime baslamat = Genel.TarihAlaniDegerVer(txtBaslama).Oku();
            if (baslamat <= System.DateTime.Now)
                btnYazdir.Hidden = true;
            else
                btnYazdir.Hidden = false;
        }

        string NeVeyaNaEkle(string naNeEklenecekMetin)
        {
            string neIcinKriter = "İÜiü";
            string naIcinKriter = "IUıu";
            string tmpAd = naNeEklenecekMetin.Substring(naNeEklenecekMetin.Length - 1);
            if (neIcinKriter.IndexOf(tmpAd) > -1)
                naNeEklenecekMetin += "'NE";
            else if (naIcinKriter.IndexOf(tmpAd) > -1)
                naNeEklenecekMetin += "'NA";
            return naNeEklenecekMetin;
        }

        void TelefonDoldur()
        {
            TNS.IKY.PersonelIletisim p = new TNS.IKY.PersonelIletisim();
            p.kod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);

            try
            {
                p = servisIKY.PersonelAdresListele(kullanan, p.kod);
                List<object> liste = new List<object>();
                liste.Add(new
                {
                    TIP = TelefonTipAdGetir((int)ENUMPERSONELTEL.CEP),
                    NUMARA = p.cepTelefon
                });
                liste.Add(new
                {
                    TIP = TelefonTipAdGetir((int)ENUMPERSONELTEL.EV),
                    NUMARA = p.evTelefon
                });
                liste.Add(new
                {
                    TIP = TelefonTipAdGetir((int)ENUMPERSONELTEL.IS),
                    NUMARA = p.isTelefon
                });

                TelefonStore.DataSource = liste;
                TelefonStore.DataBind();

                ddlTelefon.Value = p.cepTelefon;

                if (TNS.DEG.Arac.ManasKullaniyor() && !string.IsNullOrWhiteSpace(p.adres))
                    txtIzinYeri.Value = p.adres;
            }
            catch
            {
            }
        }

        void IzinSureBilgiHesapla(int donemYil)
        {
            IzinBilgi iBilgi = servisIKY.PersonelKullanilanIzinHesapla(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), donemYil, 0);
            List<object> liste = new List<object>();
            liste.Add(new { TURKOD = 1, TUR = TNS.IKY.PersonelIzin.IzinTipAdGetir(1), TOPLAM = iBilgi.toplam, KULLANDIGI = iBilgi.devirdenKullanilan, AKTIFKULLANDIGI = iBilgi.yildanKullanilan, KALAN = iBilgi.kalan, DEVREDEN = iBilgi.devreden, YILICI = iBilgi.yilIci });

            TNS.IKY.PersonelIzinDurum d = new TNS.IKY.PersonelIzinDurum();
            d.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Text, 0);
            d.listelemeYili = donemYil;
            ObjectArray dler = servisIKY.PersonelListeleIzinDurum(kullanan, d);

            foreach (PersonelIzinDurum iDurum in dler.objeler)
            {
                if (iDurum.tip != 1)
                {
                    if (iDurum.toplamGun == 0)
                        liste.Add(new { TURKOD = iDurum.tip, TUR = iDurum.ad, TOPLAM = 0, KULLANDIGI = 0, AKTIFKULLANDIGI = iDurum.kullanilanGun, KALAN = 0, DEVREDEN = 0, YILICI = 0 });
                    else
                        liste.Add(new { TURKOD = iDurum.tip, TUR = iDurum.ad, TOPLAM = iDurum.toplamGun, KULLANDIGI = 0, AKTIFKULLANDIGI = iDurum.kullanilanGun, KALAN = iDurum.toplamGun - iDurum.kullanilanGun, DEVREDEN = 0, YILICI = 0 });
                }
            }
            IzinSureStore.DataSource = liste;
            IzinSureStore.DataBind();

            hdnToplamIzin.Value = iBilgi.toplam.ToString();
            hdnToplamKullanilanIzin.Value = iBilgi.devirdenKullanilan.ToString();
            hdnKalanIzin.Value = iBilgi.kalan.ToString();
            grdIzinSureler.SetTitle(String.Format(Resources.InsanKaynaklari.FRMIZN054, IzinArac.DonemAdBul(donemYil)));
        }

        string TelefonTipAdGetir(int kod)
        {
            if (kod == (int)ENUMPERSONELTEL.CEP)
                return Resources.InsanKaynaklari.FRMIZN028;
            else if (kod == (int)ENUMPERSONELTEL.IS)
                return Resources.InsanKaynaklari.FRMIZN029;
            else if (kod == (int)ENUMPERSONELTEL.EV)
                return Resources.InsanKaynaklari.FRMIZN030;
            else
                return "";
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Temizle();
            //grdListeSelectionModel.ClearSelections();
            txtAciklama.Visible = false;
            txtSaglikKurulusu.Visible = false;

            txtRaporNo.Visible = false;
            dfRaporTarihi.Visible = false;
            nfYatiliGecenSure.Visible = false;
        }

        void Temizle()
        {
            hdnKod.Clear();
            ddlIzinTip.Clear();
            Genel.TarihAlanTemizle(ref txtBaslama, false);
            Genel.TarihAlanTemizle(ref txtBitis, true);
                txtIzinYeri.Clear();
            txtAciklama.Clear();

            hdnYerineGorevli.Clear();
            txtYerineGorevli.Clear();

            hdnTeklifEden.Clear();
            txtTeklifEden.Clear();

            hdnImzaAtan.Clear();
            txtImzaAtan.Clear();

            txtIzinGun.Clear();
            txtBelgeNo.Clear();
            txtBelgeTarihi.Clear();

            txtSaglikKurulusu.Clear();
            txtRaporNo.Clear();
            dfRaporTarihi.Clear();
            nfYatiliGecenSure.Clear();
            hdnYerKod.Clear();
            txtYerAd.Clear();
            txtIzinNotu2.Clear();

            BelgeStore.RemoveAll();
            BelgeStore.DataBind();
            grdTelefonSelectionModel.ClearSelections();
            //return Tuple.Create<int, int, int, int, int>(toplam, kullanilan, kalan, buYil, devreden);
        }

        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            string hata = "";
            if (kod == 0)
                hata = "Lütfen izin seçiniz.<br>";

            if (string.IsNullOrWhiteSpace(txtImzaAtan.Text))
                hata += "Uygun gören seçilmek zorundadır.<br>";

            if (!string.IsNullOrWhiteSpace(hata))
            {
                GenelIslemler.MesajKutusu("Hata", hata);
                return;
            }

            Sonuc sonuc = servisIKY.PersonelIzinYetkiKontrol(kullanan, new TNS.IKY.PersonelIzin { personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), kod = kod }, ENUMTARIHCEISLEMTIP.YAZDIR);

            if (!sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu("Hata", sonuc.hataStr);
                return;
            }

            sonuc = servisIKY.PersonelIzinImzaGuncelle(kullanan, new TNS.IKY.PersonelIzin { kod = kod, teklifEden = OrtakFonksiyonlar.ConvertToInt(hdnTeklifEden.Value, 0), imzalayan = OrtakFonksiyonlar.ConvertToInt(hdnImzaAtan.Value, 0) });
            if (!sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu("Hata", "Uygun gören ve teklif eden alanları güncellenemediği için yazdıramazsınız.");
                return;
            }

            TNS.IKY.PersonelIzin izin = new TNS.IKY.PersonelIzin();
            izin.kod = kod;
            izin.personelKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            ObjectArray pler = servisIKY.PersonelIzinListele(kullanan, izin);
            if (pler.ObjeSayisi > 0)
                izin = (TNS.IKY.PersonelIzin)pler.objeler[0];
            else
            {
                GenelIslemler.MesajKutusu("Hata", "İzin bilgisi bulunamadı.");
                return;
            }

            string raporAd = "";
            if (izin.izinTurKod == 1)
                raporAd = "PersonelYillikIzin";
            else if (izin.izinTurKod == 2)
                raporAd = "PersonelMazeretIzin";
            else if (izin.izinTurKod == 3)
                raporAd = "PersonelSihhiIzin";
            else
            {
                GenelIslemler.MesajKutusu("Hata", "İzin şablon bilgisi bulunamadı.");
                return;
            }

            string sonucDosyaad = Path.Combine(TNS.OrtakFonksiyonlar.GeciciYolBul(), Path.GetRandomFileName()) + ".docx";
            string dosyaAd = this.raporSablonYol + "\\IKY\\" + raporAd + ".docx";

            Document doc = new Document(dosyaAd);
            DocumentBuilder docb = new DocumentBuilder(doc);

            int toplamIzin = OrtakFonksiyonlar.ConvertToInt(hdnToplamIzin.Value, 0);
            int yilIci = 0; // OrtakFonksiyonlar.ConvertToInt(hdnYilIci.Value, 0);
            int devir = toplamIzin - yilIci;
            int onceKullanilanGun = servisIKY.PersonelKendindenKucukKullanilanIzinHesapla(izin.personelKod, izin.baslangicTarihi);
            int kalan = devir - (izin.kullanilanGun + onceKullanilanGun);

            if (kalan <= 0)
            {
                yilIci = yilIci + kalan;
                kalan = 0;
            }
            int toplam = yilIci + kalan;

            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "ad", izin.personelAd);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "gorevUnvan", izin.memuriyeti);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "birim", izin.personelBirim);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "telefon", izin.telefon);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "sicilNo", izin.personelSicilNo);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "devir", devir.ToString());
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "izinSuresi", System.DateTime.Now.Year - 1 + " Yılından " + kalan + " gün. " + System.DateTime.Now.Year + " Yılından " + yilIci + " gün. " + " Toplam : " + toplam + " gün.");
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "saglikKurulusu", izin.saglikKurulusu);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "neden", izin.aciklama);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "gun", izin.kullanilanGun.ToString());
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "adres", izin.izinYeri);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "baslangicT", izin.baslangicTarihi.ToString());
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "donusT", izin.bitisTarihi.ToString());
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "vekaletEden", izin.yerineGorevliAd);
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "gununT", ("..../ " + System.DateTime.Now.Month + " / " + System.DateTime.Now.Year).ToString());
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "imzaAtan", izin.imzalayanAd + "\n" + izin.imzalayanUnvan);
            if (!string.IsNullOrEmpty(izin.teklifEdenAd))
            {
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "teklifEden", izin.teklifEdenAd + "\n" + izin.teklifEdenUnvan);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "tUnvan", izin.teklifEdenUnvan);
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "uygun", "Uygun görüşle arz ederim.");
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "gununT1", ("..../ " + System.DateTime.Now.Month + " / " + System.DateTime.Now.Year).ToString());
            }
            else
            {
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "teklifEden", "");
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "uygun", "");
                GenelIslemlerIstemci.AsposeAlanaYaz(docb, "gununT1", "");
            }

            string ekler = "";
            if (izin.izinTurKod == 6 || izin.izinTurKod == 15)
            {
                PersonelBelgeler belge = new PersonelBelgeler();
                belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
                belge.tip = (int)ENUMBELGEFORMTIP.PERSONELIZIN;
                belge.tipKayitKod = kod;
                ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);
                int cnt = 1;
                foreach (PersonelBelgeler bel in belgeler.objeler)
                {
                    ekler += "Ek" + cnt + ": " + bel.belgeAdi;
                    if (cnt != belgeler.ObjeSayisi)
                        ekler += "\n";
                    cnt++;
                }
            }
            GenelIslemlerIstemci.AsposeAlanaYaz(docb, "ekler", ekler);
            doc.Save(sonucDosyaad, SaveFormat.Pdf);
            sonuc = servisIKY.PersonelTarihceKaydet(kullanan, new TNS.IKY.PersonelIzin(), izin, ENUMTARIHCE.IZINHAREKET, OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), ENUMTARIHCEISLEMTIP.YAZDIR);
            OrtakClass.DosyaIslem.DosyaGonderX(sonucDosyaad, raporAd + "_" + DateTime.Now.Ticks.ToString() + ".pdf", true, "PDF");
        }

        void BelgeListesiDoldur()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            belge.pKod = OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0);
            belge.tip = (int)ENUMBELGEFORMTIP.PERSONELIZIN;
            belge.tipKayitKod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            ObjectArray belgeler = servisIKY.PersonelBelgeListele(kullanan, belge);

            List<object> liste = new List<object>();
            foreach (PersonelBelgeler detay in belgeler.objeler)
            {
                liste.Add(new
                {
                    KOD = detay.kod,
                    PKOD = detay.pKod,
                    TIPKAYITKOD = detay.tipKayitKod,
                    TIP = detay.tip,
                    BELGEADI = detay.belgeAdi
                });
            }

            BelgeStore.DataSource = liste;
            BelgeStore.DataBind();
        }

        protected void BelgeKaydet(object sender, DirectEventArgs e)
        {
            if (string.IsNullOrEmpty(hdnKod.Value.ToString().Trim()))
            {
                btnKaydet_Click(null, null);
                //GenelIslemler.MesajKutusu(Resources.InsanKaynaklari.FRMPAB040, Resources.InsanKaynaklari.FRMPAB041);
                //return;
            }

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            int belgeBoyutu = OrtakFonksiyonlar.ConvertToInt(btnDosyaYukle.PostedFile.InputStream.Length, 0);
            if (belgeBoyutu <= 0)
                return;
            PersonelBelgeler yeniBelge = new PersonelBelgeler(OrtakFonksiyonlar.ConvertToInt(hdnPersonelKod.Value, 0), OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0), (int)ENUMBELGEFORMTIP.PERSONELIZIN, btnDosyaYukle.PostedFile.FileName, belgeBoyutu);
            btnDosyaYukle.PostedFile.InputStream.Read(yeniBelge.belge, 0, belgeBoyutu);

            Sonuc sonuc = servisIKY.PersonelBelgeKaydet(kullanan, yeniBelge);
            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            if (!string.IsNullOrEmpty(sonuc.bilgiStr))
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);

            BelgeListesiDoldur();
        }

        [DirectMethod]
        public void BelgeGoster(int kod)
        {
            Sonuc dosyaKonumuAdiUzantisi = servisIKY.PersonelBelgeListesiGetir(kullanan, new PersonelBelgeler { kod = kod });

            string[] parametreler = dosyaKonumuAdiUzantisi.anahtar.Split('\n');
            if (parametreler.Length == 3)
                OrtakClass.DosyaIslem.DosyaGonderX(parametreler[0], parametreler[1], true, parametreler[2]);
        }

        [DirectMethod]
        public void BelgeSil(int kod)
        {
            if (kod == 0)
            {
                GenelIslemler.MesajKutusu(this, "Belge seçiniz.");
                return;
            }
            Sonuc sonuc = servisIKY.PersonelBelgeSil(kullanan, new PersonelBelgeler { kod = kod });
            if (sonuc.islemSonuc)
                BelgeListesiDoldur();
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
        }

        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            hdnKod.Value = e.ExtraParams["kod"];
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            BelgeListesiDoldur();
        }

    }
}
