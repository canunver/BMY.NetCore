﻿using System;
using System.Collections;
using System.Data;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Collections.Generic;

namespace InsanKaynaklari
{
    public partial class TerfiyeHakKazananlar : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.FRMKAD025;
            yardimBag = yardimYol + "#YardimDosyasiAd";
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Genel.HizmetSebebiDoldur(ddlSgkSebep, sgkSebepStore, ENUMHizmetSebebiNevi.TERFI, false);
                spnYil.Number = DateTime.Now.Year;
                Genel.AyDoldur(ddlAy, ayStore, true);
                ddlAy.Value = DateTime.Now.Month;
                Genel.TerfiTipiDoldur(tipStore);
            }
        }

        public void Listele()
        {
            string hata = "";
            int yil = OrtakFonksiyonlar.ConvertToInt(spnYil.Number, 0);
            int ay = OrtakFonksiyonlar.ConvertToInt(ddlAy.Value, 0);
            if (yil <= 0)
                hata = "Yıl bilgisini seçmelisiniz.";
            if (ay <= 0)
                hata += " Ay bilgisini seçmelisiniz. ";
            //if (pgFiltre.Source["tip"].Value == "" || pgFiltre.Source["tip"].Value == "0")
            //hata += " Hizmet tipi bilgisini seçmelisiniz.";

            if (!string.IsNullOrEmpty(hata))
            {
                GenelIslemler.MesajKutusu("Bilgi", hata);
                return;
            }
            string yilAy = yil.ToString("0000") + ay.ToString("00") + "15";
            int tip = OrtakFonksiyonlar.ConvertToInt(ddlTip.Value, 0);
            ObjectArray terfisiGelenler = servisIKY.TerfisiGelenler(kullanan, yilAy, tip);

            if (!terfisiGelenler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, terfisiGelenler.sonuc.hataStr);
                return;
            }
            List<object> liste = new List<object>();
            bool renkAta;

            foreach (Terfi p in terfisiGelenler.objeler)
            {
                renkAta = false;
                if (p.kadroDerece == p.kazanilmisHakDerece || p.kadroDerece == p.emekliyeEsasDerece)
                    renkAta = true;
                liste.Add(new
                {
                    PKADROKOD = p.pKadroKod,
                    PKOD = p.pKod,
                    TC = p.kimlikNo,
                    ADSOYAD = p.ad,
                    SICILNO = p.sicilNo,
                    TIP = p.tip,
                    TIPAD = Genel.TerfiTipAdiDondur(p.tip),
                    BIRIMAD = p.birim,
                    UNVANAD = p.unvan,
                    KADRODERECE = p.kadroDerece,
                    KADROTARIH = p.kadroTarih.ToString(),
                    KAZANILMISHAKDERECE = p.kazanilmisHakDerece,
                    KAZANILMISHAKKADEME = p.kazanilmisHakKademe,
                    KAZANILMISHAKTARIH = p.kazanilmisHakTarih.ToString(),
                    ODEMEYEESASDERECE = p.odemeyeEsasDerece,
                    ODEMEYEESASKADEME = p.odemeyeEsasKademe,
                    ODEMEYEESASTARIH = p.odemeyeEsasTarih.ToString(),
                    EMEKLIYEESASDERECE = p.emekliyeEsasDerece,
                    EMEKLIYEESASKADEME = p.emekliyeEsasKademe,
                    EMEKLIYEESASTARIH = p.emekliyeEsasTarih.ToString(),
                    OGRENIM = p.ogrenim,
                    YDERECE = p.yukselecegiDerece,
                    RENKATA = renkAta
                });
            }
            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }

        protected void TerfiOnayinaGonder(object sender, DirectEventArgs e)
        {
            Newtonsoft.Json.Linq.JObject[] o = (Newtonsoft.Json.Linq.JObject[])JSON.Deserialize(e.ExtraParams["terfiler"], typeof(Newtonsoft.Json.Linq.JObject[]));

            if (o.Length == 0)
            {
                GenelIslemler.MesajKutusu("Bilgi", "Listeden herhangi bir başvuru seçilmediği için işlem yapılamadı.");
                return;
            }

            int sebepKod = OrtakFonksiyonlar.ConvertToInt(ddlSgkSebep.Value, 0);
            if (sebepKod <= 0)
            {
                GenelIslemler.MesajKutusu("Bilgi", "Atama gerekçesi seçiniz!");
                return;
            }

            Sonuc sonuc = new Sonuc();
            string hata = string.Empty;
            string hataFormat = "Seçili {0}.satır için {1} <br>";
            int sayac = 1, hataSayi = 1;

            foreach (Newtonsoft.Json.Linq.JObject row in o)
            {
                Terfi terfi = new Terfi();
                terfi.pKod = row.Value<int>("PKOD");
                terfi.pKadroKod = OrtakFonksiyonlar.ConvertToInt(row.Value<string>("PKADROKOD"), 0);
                terfi.durum = OrtakFonksiyonlar.ConvertToInt(ENUMTerfiDurumu.Beklemede, 0);
                terfi.hizmetSebebi = sebepKod;
                terfi.tip = row.Value<int>("TIP");
                terfi.yil = OrtakFonksiyonlar.ConvertToInt(spnYil.Number, 0);
                terfi.ay = OrtakFonksiyonlar.ConvertToInt(ddlAy.Value,0);
                sonuc = servisIKY.PersonelTerfiKaydet(kullanan, terfi);
                if (!sonuc.islemSonuc)
                    hata += string.Format(hataFormat, (sayac).ToString(), sonuc.hataStr); hataSayi++;

                sayac++;
            }

            if (string.IsNullOrEmpty(hata))
                GenelIslemler.MesajKutusu(this, "Seçili hizmetler terfiye başarıyla gönderilmiştir.");
            else
            {
                if (hataSayi != o.Length)
                    hata += "Diğer seçili hizmetler terfiye başarıyla gönderilmiştir.";

                GenelIslemler.MesajKutusu(this, hata);
            }
        }

        protected void TerfiListele(object sender, DirectEventArgs e)
        {
            Listele();
        }

        public void TerfiListesiYazdir(object sender, DirectEventArgs e)
        {
            string yilAy = spnYil.Number.ToString() + ddlAy.Value.ToString().PadLeft(2,'0');
            int tip = OrtakFonksiyonlar.ConvertToInt(ddlTip.Value, 0);
            string tipAd = Genel.TerfiTipAdiDondur(tip);

            if (string.IsNullOrEmpty(spnYil.Number.ToString()) || string.IsNullOrEmpty(ddlAy.Value.ToString()))
            {
                GenelIslemler.MesajKutusu("Bilgi", "Yıl ve ay bilgisini seçmelisiniz.");
                return;
            }

            ObjectArray terfisiGelenler = servisIKY.TerfisiGelenler(kullanan, yilAy, tip);

            Tablo XLS = GenelIslemler.NewTablo();

            string sablonAd = this.raporSablonYol + @"IKY\" + "TerfiEdeceklerListesi.xltx";
            //string sonucDosyaAd = DosyaIslem.DosyaAdUret("IKY", "");     
            //XLS.DosyaSaklamaFormatAta("xls");       
            string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            XLS.DosyaAc(sablonAd, sonucDosyaAd);

            int kaynakSatir = 0;
            int satir = 0;
            int sutun = 0;
            XLS.HucreAdAdresCoz("BaslaSatir", ref kaynakSatir, ref sutun);
            XLS.HucreAdBulYaz("YilAy", OrtakFonksiyonlar.ConvertToInt(spnYil.Number, 0) + " YILI " + ddlAy.Value + ". AY " + tipAd + " ' NA GÖRE TERFİ EDECEKLER LİSTESİ");
            satir = kaynakSatir;

            var list = servisIKY.TerfisiGelenler(kullanan, yilAy, tip);
            int sayac = 1;
            foreach (TNS.IKY.Terfi terfi in list.objeler)
            {
                satir++;
                XLS.SatirAc(satir, 1);
                XLS.HucreKopyala(kaynakSatir, sutun, kaynakSatir, sutun + 9, satir, sutun);
                XLS.HucreDegerYaz(satir, 0, sayac);
                XLS.HucreDegerYaz(satir, 1, terfi.ad);
                XLS.HucreDegerYaz(satir, 2, terfi.unvan);
                XLS.HucreDegerYaz(satir, 3, terfi.ogrenim);
                XLS.HucreDegerYaz(satir, 4, terfi.kadroDerece);
                XLS.HucreDegerYaz(satir, 5, terfi.kazanilmisHakDerece);
                XLS.HucreDegerYaz(satir, 6, terfi.kazanilmisHakKademe);
                XLS.HucreDegerYaz(satir, 7, terfi.emekliyeEsasDerece);
                XLS.HucreDegerYaz(satir, 8, terfi.emekliyeEsasKademe);
                XLS.HucreDegerYaz(satir, 9, terfi.yukselecegiDerece);
                sayac++;

                if (tip == (int)ENUMTerfiTipi.KHA)
                {
                    XLS.SutunGizle(7, 8, true);
                    if (terfi.kadroDerece == terfi.kazanilmisHakDerece)
                    {
                        XLS.KoyuYap(satir, 5, satir, 6, true);
                        XLS.YaziRenk(satir, 5, satir, 6, TabloRenk.ORANGE);
                    }
                }
                else if (tip == (int)ENUMTerfiTipi.EKEA)
                {
                    XLS.SutunGizle(5, 6, true);
                    if (terfi.kadroDerece == terfi.emekliyeEsasDerece)
                    {
                        XLS.KoyuYap(satir, 7, satir, 8, true);
                        XLS.YaziRenk(satir, 7, satir, 8, TabloRenk.ORANGE);
                    }
                }
                else
                {
                    if (terfi.kadroDerece == terfi.kazanilmisHakDerece || terfi.kadroDerece == terfi.emekliyeEsasDerece)
                    {
                        XLS.KoyuYap(satir, 5, satir, 8, true);
                        XLS.YaziRenk(satir, 5, satir, 8, TabloRenk.ORANGE);
                    }
                }
            }

            XLS.DosyaSaklaTamYol();

            DosyaIslem.DosyaGonderX(sonucDosyaAd, "TerfiEdeceklerListesi_" + DateTime.Now.Ticks.ToString() + ".xls", true, "xls", true);
        }

    }
}