﻿using System;
using System.Collections;
using System.Data;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;

namespace InsanKaynaklari
{
    public partial class PersonelHITAP : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = null;
        public int personelKod;
        public int aktarTur;
        protected void Page_Load(object sender, EventArgs e)
        {
            servisIKY = TNS.IKY.Arac.Tanimla();
            personelKod = GenelIslemlerIstemci.RequestBul(this, "personelKod", 0);
            aktarTur = GenelIslemlerIstemci.RequestBul(this, "tur", 1);
            if (!IsPostBack)
            {
                txtHITAPKul.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "HITAPKUL");
                txtHITAPPar.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "HITAPPAR");
                Genel.PersonelTurDoldur(cmbPersonelTip, personelTipStore, null);
                trpBirim.Listeners.BeforeLoad.Fn = "OrgBirimDoldur";
            }
        }

        protected void btnVeriAl_Click(object sender, DirectEventArgs e)
        {
            try
            {
                GenelIslemler.KullaniciDegiskenSakla(kullanan, "HITAPKUL", txtHITAPKul.Text);
                GenelIslemler.KullaniciDegiskenSakla(kullanan, "HITAPPAR", txtHITAPPar.Text);
                if (aktarTur == 1)
                {
                    int organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
                    int personelTip = OrtakFonksiyonlar.ConvertToInt(cmbPersonelTip.Value, 0);

                    Hitap.HitapHizmetleriAl(kullanan, servisIKY, personelKod, organizasyonKodu, personelTip, txtHITAPKul.Text, txtHITAPPar.Text);
                    X.Js.AddScript("KadroYenile('{0}');", "Aktarım tamamlandı.");
                }
                else
                    throw new Exception("Aktarım türü tanımsız");
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
            }
        }
    }
}