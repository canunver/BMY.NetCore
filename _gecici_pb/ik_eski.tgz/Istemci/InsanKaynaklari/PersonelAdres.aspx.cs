﻿using System;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel adres ve iletişim Sınıfı
    /// </summary>
    public partial class PersonelAdres : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnKod.Value = (Request.QueryString["personelKod"] + "").Trim();
            //personelTCKimlikNo = (Request.QueryString["tcKimlikNo"] + "").Trim();
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan, personelTCKimlikNo))
            //{
            //    //GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL008);
            //    personelTCKimlikNo = kullanan.mernis;
            //    btnKaydet.Hidden = true;
            //    btnAdres.Hidden = true;
            //}
            //if (string.IsNullOrEmpty(personelTCKimlikNo))
            //    GenelIslemler.SayfayaGirmesin(true, Resources.InsanKaynaklari.FRMGNL007);

            if (!IsPostBack)
            {
                if(TNS.DEG.Arac.ManasKullaniyor())
                {
                    txtTarabyaTel.Visible = false;
                    txtGoruntuluTel.Visible = false;
                }

                Temizle();
                Listele(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
            }
        }

        /// <summary>
        /// Girilen kritere göre Personel İletişim Adres bilgilerini listeleyen fonksiyon
        /// </summary>
        /// <param name="kriter">Kriter, Personel İletişim Adres tipinde sınıf</param>
        public void Listele(int kod)
        {
            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                return;

            try
            {
                PersonelIletisim iletisim = servisIKY.PersonelAdresListele(kullanan, OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
                if (!iletisim.sonuc.islemSonuc)
                {
                    GenelIslemler.MesajKutusu("Hata", iletisim.sonuc.hataStr);
                    return;
                }
                txtAdres.Text = iletisim.adres;
                //if (p.mulkDurumu > 0)
                //    ddlDurum.SetValueAndFireSelect(p.mulkDurumu.ToString());
                //txtOturmaTarihi.Text = p.tasinmaTarihi.ToString();
                //txtTebligatAdres.Text = p.tebligatAdres;
                //chkTebligatAyni.Checked = false;
                //txtTebligatAdres.Hidden = false;
                //if (p.tebligatAdres == p.adres)
                //{
                //    chkTebligatAyni.Checked = true;
                //    txtTebligatAdres.Hidden = true;
                //}
                txtIsTel.Text = iletisim.isTelefon;
                txtEvTel.Text = iletisim.evTelefon;
                txtCepTel.Text = iletisim.cepTelefon;
                txtFaks.Text = iletisim.faks;
                txtMobilImzaTel.Text = iletisim.mobilImzaTelefon;
                txtePosta.Text = iletisim.eposta.Trim();
                txtePosta2.Text = iletisim.eposta2.Trim();
                txtCep2.Text = iletisim.cepTelefon2;
                txtTarabyaTel.Text = iletisim.tarabyaTel;
                txtLojmanTel.Text = iletisim.lojmanTel;
                txtTelsizTel.Text = iletisim.telsiz;
                txtGoruntuluTel.Text = iletisim.goruntulu;
                if (iletisim.rehberdeGozuksun == 1)
                    chkRehber.Checked = true;
                else
                    chkRehber.Checked = false;
                txtURL.Text = iletisim.url;
                //txtAcilKisi.Text = p.acilKisi;
                //txtAcilKisiNumara.Text = p.acilKisiNumara;
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu(this, ex.Message);
                return;
            }
        }

        /// <summary>
        /// Kaydet butonuna basınca ekrandan bilgileri toplayarak Personel İletişim(Adres) bilgisini kaydeden fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0) == 0)
                hata += Resources.InsanKaynaklari.FRMPAB002 + "<br>";

            //if (txtAdres.Text == "")
            //    hata += " Adres bilgisi boş geçilemez.";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            PersonelIletisim iletisim = new TNS.IKY.PersonelIletisim();
            iletisim.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            iletisim.adres = txtAdres.Text;
            //if (!chkTebligatAyni.Checked)
            //    d.tebligatAdres = txtTebligatAdres.Text;
            //else
            //    d.tebligatAdres = d.adres;
            //d.mulkDurumu = OrtakFonksiyonlar.ConvertToInt(ddlDurum.SelectedItem.Value, 0);
            //d.tasinmaTarihi = Genel.TarihAlaniDegerVer(txtOturmaTarihi);
            iletisim.isTelefon = txtIsTel.Text;
            iletisim.evTelefon = txtEvTel.Text;
            iletisim.cepTelefon = txtCepTel.Text;
            iletisim.faks = txtFaks.Text;
            iletisim.eposta = txtePosta.Text;
            iletisim.eposta2 = txtePosta2.Text;
            iletisim.url = txtURL.Text;
            iletisim.cepTelefon2 = txtCep2.Text;
            iletisim.tarabyaTel = txtTarabyaTel.Text;
            iletisim.lojmanTel = txtLojmanTel.Text;
            iletisim.telsiz = txtTelsizTel.Text;
            iletisim.goruntulu = txtGoruntuluTel.Text;
            if (chkRehber.Checked)
                iletisim.rehberdeGozuksun = 1;
            //d.acilKisi = txtAcilKisi.Text;
            //d.acilKisiNumara = txtAcilKisiNumara.Text;

            Sonuc sonuc = servisIKY.PersonelAdresKaydet(kullanan, iletisim);

            if (!sonuc.islemSonuc)
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            else
            {
                GenelIslemler.MesajKutusu(this, Resources.InsanKaynaklari.FRMPIA025);
                Listele(OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0));
            }
        }

        /// <summary>
        /// Personel Adres bilgilerini MERNİS sisteminden getiren fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Image Click Event Args tipinde sınıf</param>
        protected void btnAdres_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            string tcKimlikNo = TcKimlikGetir(kod);

            if (tcKimlikNo == "")
                hata += Resources.InsanKaynaklari.FRMPKS072;

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            TNS.IKY.PersonelAdres p = new TNS.IKY.PersonelAdres();
            try
            {
                p = Genel.AdresBilgisiGetir(kullanan, tcKimlikNo);
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
                return;
            }

            txtAdres.Text = p.adres;
        }

        void Temizle()
        {
            txtAdres.Text = "";
            //chkTebligatAyni.Checked = true;
            //txtTebligatAdres.Text = "";
            //txtTebligatAdres.Hidden = true;
            //ddlDurum.Clear();
            //txtOturmaTarihi.Text = "";
            txtIsTel.Text = "";
            txtEvTel.Text = "";
            txtCepTel.Text = "";
            txtFaks.Text = "";
            txtMobilImzaTel.Text = "";
            txtePosta.Text = "";
            txtURL.Text = "";
            //txtAcilKisi.Text = "";
            //txtAcilKisiNumara.Text = "";
        }
        private string TcKimlikGetir(int kod)
        {
            TNS.IKY.Personel kriter = new TNS.IKY.Personel();
            string kimlikNo = string.Empty;
            ObjectArray pler = new ObjectArray();
            kriter.kod = kod;
            pler = servisIKY.PersonelListele(kullanan, kriter, false, true);


            foreach (TNS.IKY.Personel p in pler.objeler)
            {
                kimlikNo = p.tcKimlikNo;
            }
            return kimlikNo;
        }
    }
}
