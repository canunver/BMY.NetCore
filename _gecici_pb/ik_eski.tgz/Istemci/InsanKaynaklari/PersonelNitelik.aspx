﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelNitelik.aspx.cs"
    Inherits="InsanKaynaklari.PersonelNitelik" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />

    <ext:Viewport ID="Viewport1" runat="server">
        <Items>
            <ext:BorderLayout runat="server">
                <Center>
                    <ext:Panel runat="server" Border="false">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                        Icon="Disk">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="Onay" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout runat="server">
                                <Center>
                                    <ext:FormPanel runat="server" Frame="true" AutoScroll="true" Padding="5">
                                        <Items>
                                            <ext:TextArea runat="server" ID="txtGorev" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRN001 %>" NoteAlign="Top"
                                                Width="300" AnchorHorizontal="100%" Height="90px">
                                            </ext:TextArea>
                                            <ext:TextArea runat="server" ID="txtBilgi" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRN002 %>" NoteAlign="Top"
                                                Width="300" AnchorHorizontal="100%" Height="90px">
                                            </ext:TextArea>
                                            <ext:TextArea runat="server" ID="txtBeceri" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRN003 %>" NoteAlign="Top"
                                                Width="300" AnchorHorizontal="100%" Height="90px">
                                            </ext:TextArea>
                                        </Items>
                                    </ext:FormPanel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
