﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="TabletPersonelDetayliBilgi.aspx.cs"
    Inherits="InsanKaynaklari.TabletPersonelDetayliBilgi" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Simple Sidebar - Start Bootstrap Template</title>
    <link href="../App_themes/BootStrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../App_themes/BootStrap/css/simple-sidebar.css" rel="stylesheet">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="../App_themes/BootStrap/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $("#menu-toggle").click(function (e) {
                e.preventDefault();
                $("#wrapper").toggleClass("toggled");
            });
        });
    </script>
</head>
<body>
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand"><a href="#">Start Bootstrap </a></li>
                <li><a href="#">Dashboard</a> </li>
                <li><a href="#">Shortcuts</a> </li>
                <li><a href="#">Overview</a> </li>
                <li><a href="#">Events</a> </li>
                <li><a href="#">About</a> </li>
                <li><a href="#">Services</a> </li>
                <li><a href="#">Contact</a> </li>
            </ul>
        </div>
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="navbar-fixed-top ">
                    <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Toggle Menu</a>
                </div>
                <div class="row" id="thmListe" runat="server">
                    <div class="col-xs-12 col-md-12 col-sm-12">
                        <div class="thumbnail col-xs-12 col-md-3 col-sm-4" style="height: 500px">
                            This template has a responsive menu toggling system. The menu will appear collapsed
                            on smaller screens, and will appear non-collapsed on larger screens. When toggled
                            using the button below, the menu will appear/disappear. On small screens, the page
                            content will be pushed off canvas.</div>
                        <div class="thumbnail col-xs-12 col-md-3 col-sm-4" style="height: 500px">
                            xxx</div>
                        <div class="thumbnail col-xs-12 col-md-3 col-sm-4" style="height: 500px">
                            This template has a responsive menu toggling system. The menu will appear collapsed
                            on smaller screens, and will appear non-collapsed on larger screens. When toggled
                            using the button below, the menu will appear/disappear. On small screens, the page
                            content will be pushed off canvas.</div>
                        <div class="thumbnail col-xs-12 col-md-3 col-sm-4" style="height: 500px">
                            xxx</div>
                        <div class="thumbnail col-xs-12 col-md-3 col-sm-4" style="height: 500px">
                            This template has a responsive menu toggling system. The menu will appear collapsed
                            on smaller screens, and will appear non-collapsed on larger screens. When toggled
                            using the button below, the menu will appear/disappear. On small screens, the page
                            content will be pushed off canvas.</div>
                        <div class="thumbnail col-xs-12 col-md-3 col-sm-4" style="height: 500px">
                            xxx</div>
                        <div class="thumbnail col-xs-12 col-md-3 col-sm-4" style="height: 500px">
                            xxx</div>
                        <div class="thumbnail col-xs-12 col-md-3 col-sm-4" style="height: 500px">
                            This template has a responsive menu toggling system. The menu will appear collapsed
                            on smaller screens, and will appear non-collapsed on larger screens. When toggled
                            using the button below, the menu will appear/disappear. On small screens, the page
                            content will be pushed off canvas.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
