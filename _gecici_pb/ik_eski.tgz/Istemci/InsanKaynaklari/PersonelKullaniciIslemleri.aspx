﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelKullaniciIslemleri.aspx.cs"
    Inherits="InsanKaynaklari.PersonelKullaniciIslemleri" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript">
        function OrgBirimDoldur(node) {
            var orgBirim = { ozellikAra: false, cokluSecim: true };
            nodeLoadOrgBirimParam(node, orgBirim);
        }

        function SecilenleriAl() {
            var msg = "";
            var val = "";
            selNodes = trpBirim.getChecked();

            selNodes.forEach(function (node) {
                if (msg.length > 0) {
                    msg += ", ";
                    val += ", ";
                }
                msg += node.text;
                val += node.id;
            });
            ddlBirim.setValue(val, msg, false);
            ddlBirim.collapse();
        }
    </script>
</head>
<body>
    <ext:Store runat="server" ID="storeOneri">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="Text" />
                    <ext:RecordField Name="Value" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeRoller">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="BIRIMKOD" />
                    <ext:RecordField Name="BIRIMAD" />
                    <ext:RecordField Name="ROLKOD" />
                    <ext:RecordField Name="ROLSIRANO" />
                    <ext:RecordField Name="ROLAD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <form id="form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden runat="server" ID="hdnTcKimlikNo" />
    <ext:Hidden runat="server" ID="hdnMailAdres" />
    <ext:Viewport ID="Viewport1" runat="server" Layout="FitLayout">
        <Items>
            <ext:Panel runat="server" Layout="CardLayout" ActiveIndex="1" ID="pnlAna">
                <Items>
                    <ext:Panel ID="panelKullaniciYok" runat="server" LabelAlign="Left" Frame="true" Padding="5"
                        Title="<%$ Resources:InsanKaynaklari,FRMPKL001 %>" LabelWidth="100" LabelSeparator=":"
                        Margins="0 0 0 5">
                        <Items>
                            <ext:ComboBox runat="server" ID="cbOneriKullaniciKodu" StoreID="storeOneri" DisplayField="Text"
                                ValueField="Value" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPKL002 %>" Width="300"
                                Editable="true" ForceSelection="false" />
                        </Items>
                        <Buttons>
                            <ext:Button runat="server" ID="btnYeniKullaniciOlustur" Text="<%$ Resources:InsanKaynaklari,FRMPKL003 %>"
                                Icon="Accept">
                                <DirectEvents>
                                    <Click OnEvent="btnYeniKullaniciOlustur_Click" />
                                </DirectEvents>
                            </ext:Button>
                        </Buttons>
                    </ext:Panel>
                    <ext:Panel runat="server" ID="panelKullaniciVar" Title="<%$ Resources:InsanKaynaklari,FRMPKL018 %>"
                        Layout="BorderLayout">
                        <Items>
                            <ext:Panel ID="Panel2" runat="server" LabelAlign="Left" Padding="5" LabelWidth="100"
                                LabelSeparator=":" AutoHeight="true" Margins="5 5 5 5" Frame="true" Region="North">
                                <Items>
                                    <ext:TextField runat="server" ID="txtSQBKullaniciKodu" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPKL004 %>"
                                        ReadOnly="true" />
                                    <ext:TextField runat="server" ID="txtSQBEskiParola" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPKL005 %>" />
                                    <ext:TextField runat="server" ID="txtSQBYeniParola" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPKL006 %>" />
                                    <ext:TextField runat="server" ID="txtSQBYeniParolaTekrar" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPKL007 %>" />
                                </Items>
                                <Buttons>
                                    <ext:Button runat="server" ID="btnDegitir" Text="<%$ Resources:InsanKaynaklari,FRMPKL008 %>"
                                        Icon="DiskEdit">
                                        <DirectEvents>
                                            <Click OnEvent="btnDegistir_Click" />
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button runat="server" ID="btnYeniParolaAta" Text="<%$ Resources:InsanKaynaklari,FRMPKL009 %>"
                                        Icon="Accept">
                                        <DirectEvents>
                                            <Click OnEvent="btnYeniParolaAta_Click" />
                                        </DirectEvents>
                                    </ext:Button>
                                </Buttons>
                            </ext:Panel>
                            <ext:GridPanel runat="server" ID="gpRoller" Title="<%$ Resources:InsanKaynaklari,FRMPKL010 %>"
                                StoreID="storeRoller" AutoExpandColumn="ROLAD" Margins="5 5 5 5" Frame="false"
                                Region="Center">
                                <TopBar>
                                    <ext:Toolbar ID="Toolbar1" runat="server">
                                        <Items>
                                            <ext:Button runat="server" ID="btnRolSil" Text="<%$ Resources:InsanKaynaklari,FRMPKL017 %>"
                                                Icon="Decline">
                                                <DirectEvents>
                                                    <Click OnEvent="btnRolSil_Click">
                                                        <ExtraParams>
                                                            <ext:Parameter Name="GridSatirlari" Value="Ext1.encode(#{gpRoller}.getRowsValues({selectedOnly:true}))"
                                                                Mode="Raw" />
                                                        </ExtraParams>
                                                        <EventMask ShowMask="true" />
                                                    </Click>
                                                </DirectEvents>
                                            </ext:Button>
                                            <ext:ToolbarSpacer runat="server" Width="20" />
                                            <ext:Label runat="server" Text="Görevler: " />
                                            <ext:ComboBox runat="server" ID="cmbGorevler" DisplayField="ad" ValueField="Anahtar" Editable="false">
                                                <Store>
                                                    <ext:Store runat="server" ID="stoGorevler">
                                                        <Reader>
                                                            <ext:JsonReader>
                                                                <Fields>
                                                                    <ext:RecordField Name="Anahtar" Type="String" />
                                                                    <ext:RecordField Name="ad" Type="String" />
                                                                </Fields>
                                                            </ext:JsonReader>
                                                        </Reader>
                                                    </ext:Store>
                                                </Store>
                                            </ext:ComboBox>
                                            <ext:ToolbarSpacer runat="server" Width="20" />
                                            <ext:Label runat="server" Text="Birimler: " />
                                            <ext:DropDownField ID="ddlBirim" runat="server" Editable="false" TriggerIcon="Ellipsis"
                                                Mode="ValueText" Width="300">
                                                <Triggers>
                                                    <ext:FieldTrigger Icon="Clear" />
                                                </Triggers>
                                                <Listeners>
                                                    <TriggerClick Handler="if (index == 0) { this.clearValue(); }" />
                                                </Listeners>
                                                <Component>
                                                    <ext:Panel ID="Panel5" runat="server" Width="400">
                                                        <Items>
                                                            <ext:TreePanel ID="trpBirim" runat="server" Height="250" AutoWidth="true" AutoScroll="true"
                                                                Border="false" RootVisible="false">
                                                                <TopBar>
                                                                    <ext:Toolbar runat="server">
                                                                        <Items>
                                                                            <ext:Button runat="server" Text="Tamam" Icon="Accept">
                                                                                <Listeners>
                                                                                <Click Fn="SecilenleriAl" />
                                                                                </Listeners>
                                                                            </ext:Button>
                                                                        </Items>
                                                                    </ext:Toolbar>
                                                                </TopBar>
                                                                <Root>
                                                                    <ext:AsyncTreeNode NodeID="0" Expanded="true" Icon="Note" />
                                                                </Root>
                                                                <Listeners>
                                                                    <BeforeLoad Fn="OrgBirimDoldur" />
                                                                </Listeners>
                                                            </ext:TreePanel>
                                                        </Items>
                                                    </ext:Panel>
                                                </Component>
                                            </ext:DropDownField>
                                            <ext:ToolbarSpacer runat="server" Width="2" />
                                            <ext:Button runat="server" ID="btnGorevEkle" Text="Görev Ekle" Icon="Add">
                                            <DirectEvents>
                                                <Click OnEvent="btnGorevEkle_Click">
                                                </Click>
                                            </DirectEvents>
                                            </ext:Button>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                                <ColumnModel>
                                    <Columns>
                                        <ext:Column Header="<%$ Resources:InsanKaynaklari,FRMPKL012 %>" DataIndex="BIRIMAD"
                                            ColumnID="BIRIMAD" Width="600" />
                                        <ext:Column Header="<%$ Resources:InsanKaynaklari,FRMPKL015 %>" DataIndex="ROLAD"
                                            ColumnID="ROLAD" />
                                    </Columns>
                                </ColumnModel>
                                <SelectionModel>
                                    <ext:CheckboxSelectionModel ID="CheckboxSelectionModel1" runat="server" />
                                </SelectionModel>
                            </ext:GridPanel>
                        </Items>
                    </ext:Panel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
