﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Collections;

namespace InsanKaynaklari
{
    public partial class TanimSozluk : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        string anaKayitKod;

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Sözlük Bilgileri";
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            anaKayitKod = Request.QueryString.Get("anaKayitKod");
            //Sayfaya giriş izni varmı?
            //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                AnaKayitDoldur();
                Listele(new Sozluk());
            }
        }

        public void Listele(Sozluk kriter)
        {
            kriter.kayitKod = anaKayitKod;
            int anaKod = 0;

            ObjectArray dler = servisIKY.SozlukListele(kriter);

            if (!dler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
                return;
            }

            if (dler.objeler.Count <= 0)
                GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            List<object> tipler = new List<object>();
            foreach (TNS.IKY.Sozluk d in dler.objeler)
            {
                tipler.Add(new
                {
                    KOD = d.kod,
                    ANAKOD = d.kod + ":" + d.kayitKod,
                    KAYITKOD = d.kayitKod,
                    KAYITAD = d.ad,
                    KISAAD = d.kisaAd,
                    SEVIYE = d.seviye,
                    HITAPID = d.hitapID,
                    ANAKAYITAD = d.anaKayitAd,
                    AKOD = d.anaKod,
                });
                anaKod = d.anaKod;
            }

            ListeStore.DataSource = tipler;
            ListeStore.DataBind();

            if (!string.IsNullOrEmpty(anaKayitKod))
            {
                ddlAna.SelectedItem.Value = anaKod + ":" + anaKayitKod;
                ddlAna.ReadOnly = true;
            }
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            Sozluk d = new Sozluk();

            Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            //if(!string.IsNullOrEmpty(anaKayitKod) && string.IsNullOrEmpty(ddlAna.Value.ToString()))
            //    hata += "Ana kaydı boş geçerek ana kayıt kaydı yapamazsınız." + "<br>";

            if (txtKayitAdi.Text.Trim() == "")
                hata += "Kayıt Adı boş bırakılamaz" + "<br>";

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            Sozluk d = new Sozluk();
            d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);
            if (d.kod > 0)
                d.anaKod = OrtakFonksiyonlar.ConvertToInt(ddlAna.SelectedItem.Value.ToString().Split(':')[0],0);
            d.anaKayit = ddlAna.SelectedItem.Value.ToString();
            d.ad = txtKayitAdi.Text;
            d.kisaAd = txtKisaAdi.Text;
            d.seviye = OrtakFonksiyonlar.ConvertToInt(txtSeviye.Text.Trim(), 0);
            d.hitapID = txtHitapId.Text;
            d.kayitKod = txtKayitKodu.Text;

            Sonuc sonuc = servisIKY.SozlukKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                AnaKayitDoldur();
                Listele(new Sozluk());
                GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            }
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            Sozluk d = new Sozluk();
            int kod = OrtakFonksiyonlar.ConvertToInt(hdnKod.Value, 0);

            if (kod > 0)
            {
                d.kod = kod;
                Sonuc sonuc = servisIKY.SozlukSil(kullanan, d);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    Temizle();
                    Listele(new Sozluk());
                    GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
                }
            }
            else
                GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz unvanı seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Listele(new Sozluk());
            Temizle();
        }

        void Temizle()
        {
            txtKayitAdi.Clear();
            txtKayitKodu.Clear();
            txtKisaAdi.Clear();
            txtSeviye.Clear();
            txtHitapId.Clear();
            grdListeSelectionModel.ClearSelections();
            hdnKod.Clear();
            //if (string.IsNullOrEmpty(anaKayitKod))
            //{
                ddlAna.ReadOnly = false;
                ddlAna.Clear();
            //}
                
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            txtKayitKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["kayitKod"]);
            txtKayitAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["kayitAd"]);
            txtKisaAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["kisaAd"]);
            txtSeviye.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["seviye"]);
            txtHitapId.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["hitapId"]);
            hdnKod.Value = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["kod"]);
            string ana = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["anaKod"]);
            string[] a = ana.Split(':')[1].Split('.');
            string kayitKod ="";
            for (int i = 0; i < a.Length - 1; i++)
            {
                kayitKod += a[i];
                if(i != a.Length-2)
                    kayitKod += ".";
            }
            if (!string.IsNullOrEmpty(kayitKod))
                ddlAna.SelectedItem.Value = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["aKod"]) + ":" + kayitKod;
            else
                ddlAna.SelectedItem.Value = "";
           
            ddlAna.ReadOnly = true;
        }

        public void AnaKayitDoldur()
        {
            ObjectArray arr = servisIKY.SozlukListele(new Sozluk { kayitKod = anaKayitKod });
            string kayitAd = "";
            ArrayList al = new ArrayList();
            al.Add(new object[] { "", "root" });

            foreach (Sozluk s in arr.objeler)
            {
                kayitAd = "";
                for (int i = 1; i < s.seviye; i++)
                    kayitAd += "- ";

                kayitAd += s.ad;

                al.Add(new object[] { s.kod +":"+ s.kayitKod, kayitAd });
            }

            object[] oarr = (object[])al.ToArray(typeof(object[]));
            ddlAna.Items.Clear();
            anaKayitStore.DataSource = oarr;
            anaKayitStore.DataBind();
        }
    }
}