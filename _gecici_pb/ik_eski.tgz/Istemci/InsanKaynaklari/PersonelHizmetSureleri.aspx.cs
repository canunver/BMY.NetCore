﻿using System;
using System.Collections;
using System.Data;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.ORG;
using TNS.KYM;

namespace InsanKaynaklari
{
    public partial class PersonelHizmetSureleri : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            hdnPersonelKod.Value = (Request.QueryString["personelKod"] + "").Trim();
            if (!IsPostBack)
            {
                HizmetSureleriniHesapla();
            }
        }

        protected void HizmetSureleriniHesapla()
        {
            ObjectArray arr = servisIKY.HizmetleriGetir(kullanan, "", hdnPersonelKod.Value.ToString(), "", new TNSDateTime(), 0, "",-1);
            if (arr.sonuc.islemSonuc)
            {
                if (arr.objeler.Count > 0)
                {
                    Hizmet h = (Hizmet)arr.objeler[0];
                    txtToplamHizmet.Text = h.hizmetYilAyGun;
                    txtEKEA.Text = h.EKEAYilAyGun;
                    txtKAH.Text = h.kidemYilAyGun;
                    txtKHA.Text = h.KHAYilAyGun;
                    txtKurum.Text = Hizmet.YilAyGunDondur(h.kurumdakiSure);
                    txtIzin.Text = Hizmet.YilAyGunDondur(h.izinHizmetGunu);
                    return;
                }
                else
                    arr.sonuc.DegerAta("Aranan personel bulunamadı!");
            }
            GenelIslemler.MesajKutusu("Hata", arr.sonuc.hataStr);
        }
    }
}