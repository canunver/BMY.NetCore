﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class PersonelTipForm : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.PersonelTipForm001;
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            if (!IsPostBack)
            {
                stoHitap.DataSource = TNS.IKY.Arac.HizmetGrubuListe;
                stoHitap.DataBind();
                ObjectArray oa = servis.ListelePersonelTip(kullanan, new PersonelTipi());
                stoPersonelTipListe.DataSource = oa.objeler;
                stoPersonelTipListe.DataBind();
            }
        }

        /// <summary>
        /// Personel tipi kodu olarak verilen değeri, txtkod alanına atar ve okuma işlemini çağırır.
        /// </summary>
        /// <param name="kod">Personel tipi kodu </param>
        [DirectMethod]
        public void Goster(int kod)
        {
            txtkod.Text = kod.ToString();
            Oku();
        }

        void Oku()
        {
            PersonelTipi form = new PersonelTipi();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtkod.Text, 0);
            ObjectVAN ov = servis.OkuPersonelTip(kullanan, form);
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                form = (PersonelTipi)ov.o;
                txtkod.Text = form.kod.ToString();
                txtad.Text = form.ad;
                txtkurumDisi.Checked = (form.kurumDisi == 1);
                txtsira.Text = form.sira.ToString();
                txtkadrolu.Checked = form.kadrolu == 1;
                txtgoster.Checked = form.goster == 1;
                txtgrupAd.Text = form.grupAd;
                txtmaasGrupAd.Text = form.maasGrupAd;
                txtaktif.Checked = form.aktif == 1;
                txtterfiyeDahil.Checked = form.terfiyeDahil == 1;
                txtmaasDahil.Checked = form.maasaDahil == 1;
                txthitapMi.Checked = form.hitapMi == 1;
                txtPesinMi.Checked = form.pesinMi == 1;
                nfMaasDonemGun.Number = form.maasDonemGun;
                nfMaasOdemeGun.Number = form.maasOdemeGun;

                cmbHitap.SelectedItem.Value = form.HITAP.ToString();
                txtH1.Text = form.H1.ToString();
                txtH2.Text = form.H2.ToString();
                txtH3.Text = form.H3.ToString();
                txtH4.Text = form.H4.ToString();
                txtH5.Text = form.H5.ToString();
                txtH6.Text = form.H6.ToString();
                txtH7.Text = form.H7.ToString();
            }
            else if (!ov.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.PersonelTipForm002);
        }

        void Kaydet(DirectEventArgs e)
        {
            PersonelTipi form = new PersonelTipi();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtkod.Text, 0);
            form.ad = txtad.Text;
            form.kurumDisi = txtkurumDisi.Checked ? 1 : 0;
            form.sira = OrtakFonksiyonlar.ConvertToInt(txtsira.Text, 0);
            form.kadrolu = txtkadrolu.Checked ? 1 : 0;
            form.goster = txtgoster.Checked ? 1 : 0;
            form.grupAd = txtgrupAd.Text;
            form.maasGrupAd = txtmaasGrupAd.Text;
            form.aktif = txtaktif.Checked ? 1 : 0;
            form.terfiyeDahil = txtterfiyeDahil.Checked ? 1 : 0;
            form.maasaDahil = txtmaasDahil.Checked ? 1 : 0;
            form.maasDonemGun = OrtakFonksiyonlar.ConvertToInt(nfMaasDonemGun.Number, 0);
            form.maasOdemeGun = OrtakFonksiyonlar.ConvertToInt(nfMaasOdemeGun.Number, 0);

            form.hitapMi = txthitapMi.Checked ? 1 : 0;
            form.pesinMi = txtPesinMi.Checked ? 1 : 0;
            form.HITAP = (ENUMHizmetTablolari)OrtakFonksiyonlar.ConvertToInt(cmbHitap.SelectedItem.Value, 0);
            form.H1 = OrtakFonksiyonlar.ConvertToInt(txtH1.Text, 0);
            form.H2 = OrtakFonksiyonlar.ConvertToInt(txtH2.Text, 0);
            form.H3 = OrtakFonksiyonlar.ConvertToInt(txtH3.Text, 0);
            form.H4 = OrtakFonksiyonlar.ConvertToInt(txtH4.Text, 0);
            form.H5 = OrtakFonksiyonlar.ConvertToInt(txtH5.Text, 0);
            form.H6 = OrtakFonksiyonlar.ConvertToInt(txtH6.Text, 0);
            form.H7 = OrtakFonksiyonlar.ConvertToInt(txtH7.Text, 0);
            TNS.IKY.Arac.PersonelTipSifirla();
            Sonuc sonuc = servis.KaydetPersonelTip(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.PersonelTipForm003);
            }
        }

        /// <summary>
        /// Listele tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnOku_Click(object sender, DirectEventArgs e)
        {
            Oku();
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }
    }
}
