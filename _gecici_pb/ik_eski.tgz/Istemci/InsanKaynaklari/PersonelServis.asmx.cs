﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Web;
using System.Web;
using System.Web.Services;
using OrtakClass;
using TNS;
using TNS.KYM;

namespace InsanKaynaklari
{
    /// <summary>
    /// Summary description for PersonelServis
    /// </summary>
    [WebService(Namespace = "AnyNameSpace")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class PersonelServis : System.Web.Services.WebService
    {
        public class Elma
        {
            public string renk { get; set; }
            public int agirlik { get; set; }

            public string trackName { get; set; }
            public string artistName { get; set; }
            public string trackViewUrl { get; set; }
            public string artworkUrl30 { get; set; }
            public string artistId { get; set; }


            public Elma(string renk, int agirlik)
            {
                this.renk = renk;
                this.agirlik = agirlik;

                trackName = "aaa";
                artistName = "aaa";
                trackViewUrl = "aaa";
                artworkUrl30 = "aaa";
                artistId = "aaa";
            }
        }

        public class Cevap
        {
            public int nesneSay { get; set; }
            public IEnumerable<Object> liste { get; set; }
        }

        [WebMethod]
        public TNS.IKY.Personel PersonelOku(string sorgu)
        {
            TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            TNS.KYM.IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();
            TNS.IKY.Personel personel = new TNS.IKY.Personel();

            personel.kod = OrtakFonksiyonlar.ConvertToInt(sorgu, 0);
            if (personel.kod > 0)
            {
                personel.ogrenimListesiOlsun = true;
                personel.ailelerOlsun = true;
                personel.kadrolarOlsun = true;

                KullaniciVAN kul = servisKYM.KullaniciOku("stratek");//. GenelIslemler.SabitKullanici("stratek", ENUMKullaniciTipi.SISTEMYONETICISI); //OturumBilgisiIslem.KullaniciBilgiOku(true, true);
                TNS.ObjectArray liste = servisIKY.PersonelListele(kul.kullanici, personel, false, true);
                if (!liste.sonuc.islemSonuc)
                    throw new Exception(liste.sonuc.hataStr);
                if (liste.ObjeSayisi == 1)
                    return (TNS.IKY.Personel)liste.Al(0);
                return null;
            }
            else
                throw new Exception("Personel kodu girilmeli!");
        }

        [WebMethod]
        public Cevap PersonelSorgula(string sorgu)
        {
            TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            TNS.KYM.IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();
            TNS.IKY.Personel personel = new TNS.IKY.Personel();

            personel.genelSorgu = sorgu;
            personel.kayitBasla = 0;
            personel.kayitToplam = 30;
            personel.aktifDurumlar = "1";

            KullaniciVAN kul = servisKYM.KullaniciOku("stratek");//. GenelIslemler.SabitKullanici("stratek", ENUMKullaniciTipi.SISTEMYONETICISI); //OturumBilgisiIslem.KullaniciBilgiOku(true, true);
            TNS.ObjectArray liste = servisIKY.PersonelListele(kul.kullanici, personel, false, true);

            if (!liste.sonuc.islemSonuc)
                throw new Exception(liste.sonuc.hataStr);

            Cevap c = new Cevap();
            var tut = liste.objeler.Cast<TNS.IKY.Personel>().Select(x => new { x.kod, x.adSoyad, x.resimYol, x.unvanAd, x.personelTipAd, x.birimAd }).Cast<Object>();
            c.liste = tut;
            c.nesneSay = c.liste.Count<object>();
            return c;
            //System.Web.Script.Serialization.JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
            //this.Context.Response.Clear();
            //this.Context.Response.ContentType = "application/json";
            //this.Context.Response.Write(js.Serialize(c));
            //Context.Response.Flush();
            //Context.Response.End();
            //this.Context.ApplicationInstance.CompleteRequest();
        }
    }
}
