﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TNS.IKY;
using OrtakClass;
using TNS;
using TNS.KYM;
using System.Web.SessionState;

namespace InsanKaynaklari
{
    /// <summary>
    /// Summary description for ResimGoster
    /// </summary>
    public class RaporPersonelGnd : IHttpHandler, IRequiresSessionState
    {
        HttpContext context;
        IIKYServis servisIKY;
        Kullanici kullanan;

        public void ProcessRequest(HttpContext context)
        {
            servisIKY = TNS.IKY.Arac.Tanimla();
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            this.context = context;
            string raporKod = ParamAl("raporKod");
            string personelTurler = ParamAl("personelTurler");
            string txtIslemSira_Text = ParamAl("islemSira");
            string ddlBirim_Text = ParamAl("birim");
            string ddlBirim_Value = ParamAl("orgKod");
            string txtBaslama_Text = ParamAl("bastar");
            string txtBitis_Text = ParamAl("bittar");
            string cmbKadroDerece_Value = ParamAl("kadroDerece");
            string seciliKodlar = ParamAl("seciliKodlar");
            string aktifDurumlar = ParamAl("aktifDurumlar");
            string sonTarih_Text = ParamAl("sonTarih");
            string siralamaListesi = ParamAl("siralamaListesi");
            string sorgu = ParamAl("sorgu");
            string goster = ParamAl("goster");
            int aktiflik = OrtakFonksiyonlar.ConvertToInt(ParamAl("aktiflik"), 0);
            int siteKod = OrtakFonksiyonlar.ConvertToInt(ParamAl("site"), 0);
            int dairebosluk = OrtakFonksiyonlar.ConvertToInt(ParamAl("dairebosluk"), 0);
            int yil = OrtakFonksiyonlar.ConvertToInt(ParamAl("yil"), 0);
            int ay = OrtakFonksiyonlar.ConvertToInt(ParamAl("ay"), 0);
            int yil1 = OrtakFonksiyonlar.ConvertToInt(ParamAl("yil1"), 0);
            int yil2 = OrtakFonksiyonlar.ConvertToInt(ParamAl("yil2"), 0);
            string yerleskeler = ParamAl("yerleskeler");
            string tarihSorgu = ParamAl("tarihSorgu");
            int tarihSorguTur = OrtakFonksiyonlar.ConvertToInt(ParamAl("tarihSorguTur"), 0);
            int siralamaKod = OrtakFonksiyonlar.ConvertToInt(ParamAl("siralamaKod"), 0);
            string izinTurler = ParamAl("izinTurler");
            RaporPersonel.raporUret(servisIKY, kullanan, istemciUzayi.GenelSayfa.RaporSablonYol(), raporKod, personelTurler, txtIslemSira_Text, ddlBirim_Text, ddlBirim_Value, siralamaKod, "pdf", OrtakFonksiyonlar.ConvertToInt(cmbKadroDerece_Value, 0), string.IsNullOrWhiteSpace(goster) || goster != "0", seciliKodlar, aktifDurumlar, sonTarih_Text, siralamaListesi, true, sorgu, aktiflik, siteKod, dairebosluk, yil, ay, yil1, yil2, OrtakFonksiyonlar.ConvertToInt(ParamAl("yukumlu"), 0), yerleskeler, tarihSorgu, tarihSorguTur, izinTurler);
        }

        private string ParamAl(string param)
        {
            return this.context.Request[param] + "";
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}