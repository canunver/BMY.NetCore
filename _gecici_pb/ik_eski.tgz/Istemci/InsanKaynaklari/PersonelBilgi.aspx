﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelBilgi.aspx.cs"
    Inherits="InsanKaynaklari.PersonelBilgi" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="InsanKaynaklari" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Personel Bilgi</title>
    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
    <style type="text/css" runat="server">
        .x-tool-icon-clear {
            background-image: url(<%=TemizleIkon%>) !important;
        }
    </style>
    <script type="text/javascript">
        function Temizle() {
            txtGenelSorgu.clear();
            ddlBirim.clear();
            ddlPersonelTipGrup.clear();
            cmbPersonelTipCoklu.clear();
            grdPersonelTipCoklu.clear();
            rdAktif.setValue(true);
            rgResimYok.setValue(true);
        }

        var gAtamaDegisti;

        function Degisti() {
            gAtamaDegisti = 1;
        }

        function Kapandi(param) {
            if (gAtamaDegisti == 1)
                tabKadro.reload();
        }

        function KadroYenile() {
            tabKadro.reload();
        }

        function PersonelAtamaAc(persKod, kod) {
            gAtamaDegisti = 0;
            showPopWin('PersonelAtama.aspx?menuYok=1&personelKod=' + persKod + "&kod=" + kod, 1000, 750, true, 'Kapandi(1);');
        }

        function tabPanelAnaRender() {
            txtGenelSorgu.focus(false, 100);
        }

        function Yukle() {
            hdnIlk.setValue("1");
            ListeStore.reload();
        }

        function TabDuzenle(ind) {
            var activeTab = TabPersonelBilgi.getActiveTab();
            var activeTabIndex = TabPersonelBilgi.items.indexOf(activeTab);
            if (activeTabIndex != 0)
                TabPersonelBilgi.setActiveTab(activeTabIndex + ind);
        }

        function ResimRenderer(value, meta, record) {

            // RadioGroup value kontrolü
            // Bazı Ext.NET sürümlerinde getValue().rgResim değil, direkt value döner.
            var v = rgResimYok.getValue();
            if (v) return "";
            return '<img style="width:55px;height:70px;" src="' + value + '" />';
        }

    </script>
</head>
<body>
    <form id="Form1" runat="server" defaultbutton="btnSorguListele">
        <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <ext:Hidden ID="hdnIlk" runat="server" />
        <ext:Store runat="server" ID="storeUnvan">
            <Reader>
                <ext:JsonReader IDProperty="UnvanKod">
                    <Fields>
                        <ext:RecordField Name="UnvanKod" />
                        <ext:RecordField Name="UnvanAd" />
                    </Fields>
                </ext:JsonReader>
            </Reader>
        </ext:Store>
        <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;"
            Layout="BorderLayout">
            <Items>
                <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px"
                    Margins="104 20 10 20" Border="false" Region="Center" Layout="BorderLayout">
                    <Items>
                        <ext:Panel ID="pnlSol" runat="server" Title="<%$Resources:InsanKaynaklari,FRMPAB035%>"
                            Width="360" Collapsed="false" AutoScroll="true" Region="West" Split="true" Layout="BorderLayout">
                            <Tools>
                                <ext:Tool CustomType="icon-clear" Fn="Temizle" Qtip="Alanları Boşalt">
                                </ext:Tool>
                            </Tools>
                            <TopBar>
                                <ext:Toolbar ID="Toolbar2" runat="server">
                                    <Items>
                                        <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPBI003%>"
                                            Icon="ApplicationGo">
                                            <Listeners>
                                                <Click Handler="Yukle()" />
                                            </Listeners>
                                        </ext:Button>
                                        <ext:Button ID="btnBekleyenKayitlar" runat="server" Text="Bekleyen İşl." Icon="Hourglass">
                                            <Listeners>
                                                <Click Handler="showPopWin('PersonelKadroOnaysiz.aspx?menuYok=1&orgKod='+ddlBirim.getValue(), 900, 540, true, null);" />
                                            </Listeners>
                                        </ext:Button>
                                        <ext:ToolbarFill ID="ToolbarFill1" runat="server" />
                                    </Items>
                                </ext:Toolbar>
                            </TopBar>
                            <Items>
                                <ext:FormPanel runat="server" Height="220" LabelWidth="50" Layout="AnchorLayout"
                                    Frame="false" Header="false" Border="false" Padding="5" Region="North" LabelAlign="Left">
                                    <Items>
                                        <ext:TextField runat="server" ID="txtGenelSorgu" FieldLabel="Arama" AnchorHorizontal="97%"
                                            TabIndex="1" />
                                        <ext:ExtOrgSecim runat="server" ID="ddlBirim" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>"
                                            AnchorHorizontal="97%" />
                                        <ext:ComboBox ID="cmbUnvan" runat="server" Editable="true" Mode="Local" TriggerAction="All"
                                            ForceSelection="true" StoreID="storeUnvan" DisplayField="UnvanAd" ValueField="UnvanKod"
                                            AnchorHorizontal="97%" FieldLabel="Unvan" />
                                        <ext:MultiCombo runat="server" ID="ddlPersonelTipGrup" DisplayField="ad" ValueField="ad"
                                            FieldLabel="Grup" AnchorHorizontal="97%" SelectionMode="Checkbox">
                                            <Store>
                                                <ext:Store ID="stoPersonelTipGrup" runat="server">
                                                    <Reader>
                                                        <ext:JsonReader IDProperty="ad">
                                                            <Fields>
                                                                <ext:RecordField Name="ad" Type="String" />
                                                            </Fields>
                                                        </ext:JsonReader>
                                                    </Reader>
                                                </ext:Store>
                                            </Store>
                                            <DirectEvents>
                                                <Change OnEvent="ddlPersonelTipGrup_Changed">
                                                </Change>
                                            </DirectEvents>
                                        </ext:MultiCombo>
                                        <ext:ExtCokluSecim runat="server" ID="ctlPersonelTip" FieldLabel="Tür" AnchorHorizontal="97%"
                                            MaxWidth="400" />
                                        <ext:RadioGroup runat="server" ID="rgAktiflik" FieldLabel="Aktiflik" AnchorHorizontal="97%"
                                            ColumnsWidths="0.33,0.33,0.34">
                                            <Items>
                                                <ext:Radio runat="server" ID="rdAktif" BoxLabel="Aktif" Checked="true" InputValue="1" />
                                                <ext:Radio runat="server" ID="rdTumu" BoxLabel="Tümü" InputValue="-1" />
                                                <ext:Radio runat="server" ID="rdPasif" BoxLabel="Pasif" InputValue="0" />
                                            </Items>
                                        </ext:RadioGroup>
                                        <ext:RadioGroup runat="server" ID="rgResim" FieldLabel="Resim" AnchorHorizontal="97%"
                                            ColumnsWidths="0.33,0.66">
                                            <Items>
                                                <ext:Radio runat="server" ID="rgResimYok" BoxLabel="Yok" Checked="true" InputValue="0" />
                                                <ext:Radio runat="server" ID="rgResimVar" BoxLabel="Var" InputValue="1" />
                                            </Items>
                                        </ext:RadioGroup>
                                        <ext:ComboBox runat="server" ID="cmbSiralama" FieldLabel="Sıralama" AnchorHorizontal="97%" SelectedIndex="0">
                                            <Items>
                                                <ext:ListItem Text="Hiyerarşi" Value="1" />
                                                <ext:ListItem Text="Ad Soyad" Value="3" />
                                                <ext:ListItem Text="Birim" Value="2" />
                                                <ext:ListItem Text="Unvan" Value="4" />
                                                <ext:ListItem Text="Sicil No" Value="5" />
                                            </Items>
                                        </ext:ComboBox>
                                    </Items>
                                </ext:FormPanel>
                                <ext:Panel ID="Panel1" runat="server" Border="false" Region="Center">
                                    <Items>
                                        <ext:FitLayout ID="fitLayout3" runat="server">
                                            <Items>
                                                <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                                    Layout="FitLayout" Width="350" Border="false">
                                                    <ColumnModel ID="ColumnModel1" runat="server">
                                                        <Columns>
                                                            <ext:Column ColumnID="resimBase64" DataIndex="resimBase64" Width="60" Hidden="true">
                                                                <Renderer Fn="ResimRenderer" />
                                                            </ext:Column>
                                                            <ext:Column ColumnID="adSoyad" DataIndex="adSoyad" Header="<%$Resources:InsanKaynaklari,FRMPAB034%>" />
                                                            <ext:Column ColumnID="sicilNo" DataIndex="sicilNo" Header="Sicil No" Width="80" />
                                                            <ext:Column ColumnID="unvanAd" DataIndex="unvanAd" Header="Unvan" />
                                                            <ext:Column ColumnID="birimAd" DataIndex="birimAd" Header="Birimi" />
                                                            <ext:Column ColumnID="personelTipAd" DataIndex="personelTipAd" Header="Tür" />
                                                            <ext:Column ColumnID="unvanVekaletAd" DataIndex="unvanVekaletAd" Header="Vekalet Unvan" />
                                                        </Columns>
                                                    </ColumnModel>
                                                    <SelectionModel>
                                                        <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                                            <DirectEvents>
                                                                <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                                                    <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                                                    <ExtraParams>
                                                                        <ext:Parameter Name="KOD" Value="this.getSelected().data.kod" Mode="Raw" />
                                                                    </ExtraParams>
                                                                </RowSelect>
                                                            </DirectEvents>
                                                        </ext:RowSelectionModel>
                                                    </SelectionModel>
                                                    <Store>
                                                        <ext:Store ID="ListeStore" runat="server" OnRefreshData="ListeStore_ReadData" AutoLoad="false"
                                                            RemotePaging="true">
                                                            <Proxy>
                                                                <ext:PageProxy />
                                                            </Proxy>
                                                            <Reader>
                                                                <ext:JsonReader>
                                                                    <Fields>
                                                                        <ext:RecordField Name="kod" Type="Int" />
                                                                        <ext:RecordField Name="sicilNo" Type="String" />
                                                                        <ext:RecordField Name="adSoyad" Type="String" />
                                                                        <ext:RecordField Name="cinsiyetKayitKod" Type="String" />
                                                                        <ext:RecordField Name="personelTip" Type="Int" />
                                                                        <ext:RecordField Name="personelTipAd" Type="String" />
                                                                        <ext:RecordField Name="birimAd" Type="String" />
                                                                        <ext:RecordField Name="resimBase64" Type="String" />
                                                                        <ext:RecordField Name="unvanAd" Type="String" />
                                                                        <ext:RecordField Name="unvanVekaletAd" Type="String" />
                                                                    </Fields>
                                                                </ext:JsonReader>
                                                            </Reader>
                                                            <BaseParams>
                                                                <ext:Parameter Name="start" Value="0" Mode="Raw" />
                                                                <ext:Parameter Name="limit" Value="250" Mode="Raw" />
                                                            </BaseParams>
                                                        </ext:Store>
                                                    </Store>
                                                    <LoadMask ShowMask="true" Msg="Lütfen bekleyin..." />
                                                    <BottomBar>
                                                        <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="250" HideRefresh="true">
                                                        </ext:PagingToolbar>
                                                    </BottomBar>
                                                </ext:GridPanel>
                                            </Items>
                                        </ext:FitLayout>
                                    </Items>
                                </ext:Panel>
                            </Items>
                        </ext:Panel>
                        <ext:Panel ID="Panel2" runat="server" Border="false" Region="Center" Layout="RowLayout">
                            <Items>
                                <ext:Panel ID="pnlUst" runat="server" Title="Personel Bilgi" MonitorResize="true"
                                    Frame="true" Height="90" MinHeight="90" MaxHeight="90" Layout="ColumnLayout">
                                    <Items>
                                        <ext:Panel ID="pnlUstResim" runat="server" Border="true" Padding="1" MaxWidth="50"
                                            MinWidth="50" Width="50">
                                            <Items>
                                                <ext:Image ID="imgPersonelResim" runat="server" Width="48" Height="59" ImageUrl="../app_themes/images/bos.jpg" />
                                            </Items>
                                        </ext:Panel>
                                        <ext:FormPanel runat="server" Border="false" PaddingSummary="5" Frame="false" StyleSpec="background-color:rgb(223,232,246);"
                                            ColumnWidth="0.45">
                                            <Items>
                                                <ext:DisplayField ID="lblTipUnvan" FieldLabel="Per.Tip/Unv." runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                                <ext:DisplayField ID="lblKadroYeri" FieldLabel="Birimi" runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                                <ext:DisplayField ID="lblIletisim" FieldLabel="İletişim" runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                            </Items>
                                        </ext:FormPanel>
                                        <ext:FormPanel runat="server" Border="false" Frame="false" StyleSpec="background-color:rgb(223,232,246);"
                                            ColumnWidth="0.35">
                                            <Items>
                                                <ext:DisplayField ID="lblKurumaBasTar" FieldLabel="Baş. Tarihi" runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                                <ext:DisplayField ID="lblGorevYeri" FieldLabel="Görev Yeri" runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                                <ext:DisplayField ID="lblVekilUnv" FieldLabel="Vekil Un." runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                            </Items>
                                        </ext:FormPanel>
                                        <ext:FormPanel runat="server" Border="false" Frame="false" StyleSpec="background-color:rgb(223,232,246);"
                                            ColumnWidth="0.2">
                                            <Items>
                                                <ext:DisplayField ID="lblKadroDerece" FieldLabel="Kadro" runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                                <ext:DisplayField ID="lblKazanilmisD" FieldLabel="Kaz. Hak" runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                                <ext:DisplayField ID="lblEmekliD" FieldLabel="Emekli" runat="server" AnchorHorizontal="%96"
                                                    Height="1" LabelStyle="height:5px" StyleSpec="white-space:nowrap" />
                                            </Items>
                                        </ext:FormPanel>
                                    </Items>
                                </ext:Panel>
                                <ext:TabPanel ID="TabPersonelBilgi" runat="server" MinTabWidth="100" TabWidth="150"
                                    EnableTabScroll="true" RowHeight="1">
                                    <Plugins>
                                        <ext:TabScrollerMenu PageSize="30">
                                        </ext:TabScrollerMenu>
                                    </Plugins>
                                    <Items>
                                        <ext:Panel runat="server" Title="Kişisel" Closable="false" Padding="0" Height="200">
                                            <AutoLoad ShowMask="true" MaskMsg="<%$Resources:InsanKaynaklari,FRMORT073%>" Url="PersonelKisisel.aspx?menuYok=1&tcKimlikNo="
                                                Mode="IFrame">
                                            </AutoLoad>
                                        </ext:Panel>
                                    </Items>
                                </ext:TabPanel>
                            </Items>
                        </ext:Panel>
                    </Items>
                    <Listeners>
                        <AfterRender Fn="tabPanelAnaRender" />
                    </Listeners>
                </ext:Panel>
            </Items>
        </ext:Viewport>
        <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
