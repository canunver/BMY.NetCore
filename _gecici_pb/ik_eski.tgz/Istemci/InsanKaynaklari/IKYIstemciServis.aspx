﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="IKYIstemciServis.aspx.cs" Inherits="InsanKaynaklari.IKYIstemciServis" %>
