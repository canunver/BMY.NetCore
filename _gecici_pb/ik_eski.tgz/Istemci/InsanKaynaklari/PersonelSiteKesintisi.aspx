﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelSiteKesintisi.aspx.cs"
    Inherits="InsanKaynaklari.PersonelSiteKesintisi" %>

<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript">
        function btnKesintiGirisi_Click() {
            if (ddlSiteAra.getValue() < 1) alert("Site seçiniz!");
            else if (spnYilAra.getValue() < 1) alert("Yıl giriniz!");
            else if (ddlAyAra.getValue() < 1) alert("Ay giriniz!");
            else {
                showPopWinTop('LojmanSiteGideri.aspx?menuYok=1&siteKod=' + ddlSiteAra.getValue() + "&yil=" + spnYilAra.getValue() + "&ay=" + ddlAyAra.getValue(), 500, 400, true, '', '', true);
            }
        }

        function DegiskenSecildi(sm) {
            stoDegiskenler.each(function (sat) {
                KontrolEt(sat.data.kod, sat.data.eldenGor, sat.data.endexGor, sat.data.aciklamaGor);
            });
        }

        function KontrolEt(degiskenKod, eldenGor, endexGor, aciklamaGor) {
            var colAd = '';
            var colIndex = 0;
            if (degiskenKod) {
                secili = SeciliMi(degiskenKod);
                for (var i = 0; i < 4; i++) {
                    if (i == 0 && eldenGor == 1)
                        colAd = degiskenKod + 'Elden';
                    else if (i == 1)
                        colAd = degiskenKod + 'Dahil';
                    else if (i == 2 && endexGor == 1)
                        colAd = degiskenKod + 'Endex';
                    else if (i == 3 && aciklamaGor == 1)
                        colAd = degiskenKod + 'Aciklama';
                    colIndex = KolonBul(colAd);
                    gorunur = GoronurMu(colIndex);
                    if (gorunur != secili) {
                        GosterGizle(colIndex, secili);
                    }
                }
            }
        }

        function SeciliMi(degiskenKod) {
            for (var i = 0; i < smDegiskenler.selections.items.length; i++) {
                if (smDegiskenler.selections.items[i].data.kod == degiskenKod) return 1;
            }
            return 0;
        }

        function GoronurMu(colIndex) {
            if (colIndex >= 0) {
                if (grdListe.colModel.isHidden(colIndex))
                    return 0;
            }
            return 1;
        }

        function GosterGizle(colIndex, secili) {
            if (colIndex >= 0) {
                grdListe.colModel.setHidden(colIndex, secili == 0);
            }
        }

        function KolonBul(kolonAd) {
            return grdListe.colModel.getIndexById(kolonAd);
        }

        function EldeneAta() {
            var alanAd = sbDegisken.getValue();
            if (alanAd != "") {
                var deger = nfGirilen.getValue();
                stoListe.each(function (sat) {
                    sat.set(alanAd + 'Elden', deger);
                });
            }
        }

        //        var RenkDegis = function (value, metaData, record, rowIndex, colIndex, store) {
        //            metaData = RenkAta(true, metaData);
        //            return value;
        //        }

        //        var RenkAta = function (renklendirme, metaData) {
        //            if (renklendirme) {
        //                if (metaData.style != "") metaData.style += "; ";
        //                metaData.style += "background-color: #64FE2E;";
        //            }

        //            return metaData;
        //        }
    </script>
    <style type="text/css">
        .x-grid3-hd-inner
        {
            white-space: normal;
        }
    </style>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnYil" runat="server" />
    <ext:Hidden ID="hdnAy" runat="server" />
    <ext:Store ID="ayStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="blokStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="blokNo" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="siteStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="siteAdi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="stoListe">
        <Reader>
            <ext:ArrayReader>
                <Fields>
                    <ext:RecordField Name="kod" Type="Int" />
                    <ext:RecordField Name="siteAdi" Type="String" />
                    <ext:RecordField Name="blokNo" Type="String" />
                    <ext:RecordField Name="daireNo" Type="Int" />
                    <ext:RecordField Name="personelAd" Type="String" />
                    <ext:RecordField Name="unvanAd" Type="String" />
                    <ext:RecordField Name="siteKod" Type="String" />
                    <ext:RecordField Name="personelKod" Type="Int" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="stoDegiskenler">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="ad" />
                    <ext:RecordField Name="eldenGor" />
                    <ext:RecordField Name="endexGor" />
                    <ext:RecordField Name="aciklamaGor" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="stoDegiskenElden">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="ad" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;"
        Layout="BorderLayout">
        <Items>
            <ext:Panel ID="Panel3" runat="server" Width="230" Layout="BorderLayout" Collapsed="false"
                AutoScroll="true" Margins="104 20 10 20" Region="Center">
                <Items>
                    <ext:Panel runat="server" Height="200" Region="North" Layout="ColumnLayout">
                        <Items>
                            <ext:FormPanel ID="FormPanel1" runat="server" LabelWidth="120" Frame="false" Header="false"
                                Border="false" Padding="5" ColumnWidth="1">
                                <Items>
                                    <ext:ComboBox runat="server" ID="ddlSiteAra" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite007%>"
                                        DisplayField="siteAdi" ValueField="kod" StoreID="siteStore" Width="300" Editable="false">
                                        <DirectEvents>
                                            <Change OnEvent="SiteDegisti">
                                            </Change>
                                        </DirectEvents>
                                    </ext:ComboBox>
                                    <ext:ComboBox runat="server" ID="ddlBlokAra" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite044%>"
                                        Width="300" DisplayField="blokNo" ValueField="kod" StoreID="blokStore" Editable="false">
                                    </ext:ComboBox>
                                    <ext:SpinnerField runat="server" ID="spnYilAra" FieldLabel="Yıl" Width="300" />
                                    <ext:ComboBox runat="server" ID="ddlAyAra" StoreID="ayStore" DisplayField="AD" ValueField="KOD"
                                        FieldLabel="Ay" Width="300">
                                    </ext:ComboBox>
                                </Items>
                            </ext:FormPanel>
                            <ext:GridPanel runat="server" ID="grdDegiskenler" Width="400" StoreID="stoDegiskenler"
                                AutoExpandColumn="ad">
                                <ColumnModel>
                                    <Columns>
                                        <ext:Column DataIndex="ad" ColumnID="ad" Header="Kolonlar">
                                        </ext:Column>
                                    </Columns>
                                </ColumnModel>
                                <SelectionModel>
                                    <ext:CheckboxSelectionModel runat="server" CheckOnly="true" ID="smDegiskenler">
                                        <Listeners>
                                            <SelectionChange Fn="DegiskenSecildi" />
                                        </Listeners>
                                    </ext:CheckboxSelectionModel>
                                </SelectionModel>
                            </ext:GridPanel>
                        </Items>
                    </ext:Panel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" StoreID="stoListe"
                        Title="Personel Listesi" Region="Center" ClicksToEdit="1">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server">
                                <Items>
                                    <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:Personel,FRMPBI003%>"
                                        Icon="ApplicationGo">
                                        <DirectEvents>
                                            <Click OnEvent="PersonelListele">
                                                <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:Personel,FRMPAB020%>" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="degiskenlerAll" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdDegiskenler}.getRowsValues())" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:SelectBox runat="server" ID="sbDegisken" StoreID="stoDegiskenElden" DisplayField="ad"
                                        ValueField="kod" Hidden="true">
                                    </ext:SelectBox>
                                    <ext:NumberField runat="server" ID="nfGirilen" Hidden="true">
                                    </ext:NumberField>
                                    <ext:Button runat="server" ID="btnDegerAra" Icon="PencilAdd" Text="Eldene Ata" Hidden="true">
                                        <Listeners>
                                            <Click Fn="EldeneAta" />
                                        </Listeners>
                                    </ext:Button>
                                    <ext:Button runat="server" Text="Kaydet" ID="btnKaydet" Icon="Accept">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <EventMask ShowMask="true" Msg="Kesintiler kaydediliyor" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="param" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdListe}.getRowsValues())" />
                                                    <ext:Parameter Name="degiskenler" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdDegiskenler}.getRowsValues({selectedOnly:true}))" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button runat="server" Text="Yazdır (Site)" ID="btnYazdir" Icon="Printer">
                                        <DirectEvents>
                                            <Click OnEvent="btnYazdir_Click" IsUpload="true">
                                                <ExtraParams>
                                                    <ext:Parameter Name="Tur" Value="1" Mode="Value" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button runat="server" Text="Yazdır (Blok)" ID="btnYazdir2" Icon="Printer">
                                        <DirectEvents>
                                            <Click OnEvent="btnYazdir_Click" IsUpload="true">
                                                <ExtraParams>
                                                    <ext:Parameter Name="Tur" Value="2" Mode="Value" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button runat="server" Text="Kesinti Girişi" ID="btnKesintiGirisi" Icon="ApplicationViewDetail">
                                        <Listeners>
                                            <Click Fn="btnKesintiGirisi_Click" />
                                        </Listeners>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column Locked="true" DataIndex="siteAdi" ColumnID="siteAdi" Header="Site Adı"
                                    Width="100px" />
                                <ext:Column Locked="true" DataIndex="blokNo" ColumnID="blokNo" Header="Blok No" Width="80px" />
                                <ext:Column Locked="true" DataIndex="daireNo" ColumnID="daireNo" Header="Daire No"
                                    Width="80px" />
                                <ext:Column Locked="true" DataIndex="personelAd" ColumnID="personelAd" Header="Personel Ad"
                                    Width="150px" />
                                <ext:Column Locked="true" DataIndex="unvanAd" ColumnID="unvanAd" Header="Unvan Ad"
                                    Width="150px" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel SingleSelect="true" runat="server">
                                <%--<Listeners>
                                    <RowSelect Fn="RenkDegis" />
                                </Listeners>--%>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="250" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                        <View>
                            <ext:LockingGridView runat="server">
                            </ext:LockingGridView>
                        </View>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
