﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using TNS.KYM;
using TNS.IKY;
using OrtakClass;
using Ext1.Net;

namespace InsanKaynaklari
{
    /// <summary>
    /// Web formu ile ilgili olayları (event) ve fonksiyonları tutan sınıf
    /// </summary>
    public partial class HizmetSebebiForm : istemciUzayi.GenelSayfa
    {
        IIKYServis servis = null;

        /// <summary>
        /// Sayfa hazırlanırken, çağrılan olay (event) fonksiyon.
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.HizmetSebebi001;
            yardimBag = yardimYol + "#YardimDosyasiAd";
            servis = TNS.IKY.Arac.Tanimla();
            OrtakClass.GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            if (!IsPostBack)
            {
                ArrayList al = new ArrayList();
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.TANIMSIZ, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.TANIMSIZ)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.BASLAMA, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.BASLAMA)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.AYRILMA, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.AYRILMA)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.TERFI, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.TERFI)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.NAKILBASLAMA, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.NAKILBASLAMA)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.NAKILAYRILMA, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.NAKILAYRILMA)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.UCRETSIZAYRILMA, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.UCRETSIZAYRILMA)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.UCRETSIZIZIN, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.UCRETSIZIZIN)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.GOREVDENUZAK, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.GOREVDENUZAK)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.GOREVUZAKAYRILMA, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.GOREVUZAKAYRILMA)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.YURTDISIEGITIM, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.YURTDISIEGITIM)));
                al.Add(new IntKodStrAd((int)ENUMHizmetSebebiNevi.YURTDISIEGITIMEAYRILMA, HizmetSebebi.TipAd(ENUMHizmetSebebiNevi.YURTDISIEGITIMEAYRILMA)));
                stoTip.DataSource = al;
                stoTip.DataBind();
            }
        }

        void Listele()
        {
            HizmetSebebi form = new HizmetSebebi();
            form.sebepAdi = txtAraAd.Text;
            form.tip = (ENUMHizmetSebebiNevi)OrtakFonksiyonlar.ConvertToInt(cmbAraTip.SelectedItem.Value, 0);
            ObjectArray ov = servis.ListeleHizmetSebebi(kullanan, form);
            if (ov.sonuc.islemSonuc)
            {
                stoSebepler.DataSource = ov.objeler;
                stoSebepler.DataBind();
            }
            else
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
        }

        void Oku()
        {
            HizmetSebebi form = new HizmetSebebi();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtkod.Text, 0);
            ObjectVAN ov = servis.OkuHizmetSebebi(kullanan, form);
            if (ov.sonuc.islemSonuc && ov.o != null)
            {
                form = (HizmetSebebi)ov.o;
                txtkod.Text = form.kod.ToString();
                txtsebepAdi.Text = form.sebepAdi;
                cmbTip.SelectedItem.Value = ((int)form.tip).ToString();
            }
            else if (!ov.sonuc.islemSonuc)
                GenelIslemler.BilgiYaz(this, ov.sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.HizmetSebebi002);
        }

        /// <summary>
        /// Listele tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnListele_Click(object sender, DirectEventArgs e)
        {
            Listele();
        }

        void Kaydet(DirectEventArgs e)
        {
            HizmetSebebi form = new HizmetSebebi();
            form.kod = OrtakFonksiyonlar.ConvertToInt(txtkod.Text, 0);
            form.sebepAdi = txtsebepAdi.Text;
            form.tip = (ENUMHizmetSebebiNevi)OrtakFonksiyonlar.ConvertToInt(cmbTip.SelectedItem.Value, 0);
            Sonuc sonuc = servis.KaydetHizmetSebebi(kullanan, form);
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.HizmetSebebi003);
        }

        /// <summary>
        /// Kaydet tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            Kaydet(e);
        }

        /// <summary>
        /// Yazdir tuşuna basılınca çalışacak olay fonksiyon
        /// </summary>
        /// <param name="sender">Olayı uyandıran nesne</param>
        /// <param name="e">Olayın parametresi</param>
        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            HizmetSebebi[] records = (HizmetSebebi[])Ext.Net.JSON.Deserialize(e.ExtraParams["satirlar"], typeof(HizmetSebebi[]));
            Sonuc sonuc = servis.SilHizmetSebebleri(kullanan, new TNSCollection(records));
            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, Resources.InsanKaynaklari.HizmetSebebi003);
        }
    }
}
