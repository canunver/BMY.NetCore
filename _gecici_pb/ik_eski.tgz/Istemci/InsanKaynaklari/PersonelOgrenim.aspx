﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelOgrenim.aspx.cs"
    Inherits="InsanKaynaklari.PersonelOgrenim" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        function OgrenimKodDegisti() {
            if (ddlOgrenim.value.split(':')[1] == "08.00007" || ddlOgrenim.value.split(':')[1] == "08.00008" || ddlOgrenim.value.split(':')[1] == "08.00009" || ddlOgrenim.value.split(':')[1] == "17.00002" || ddlOgrenim.value.split(':')[1] == "17.00003" || ddlOgrenim.value.split(':')[1] == "17.00004" || ddlOgrenim.value.split(':')[1] == "17.00005" || ddlOgrenim.value.split(':')[1] == "17.00008" || ddlOgrenim.value.split(':')[1] == "17.00009") {
                ddlUniversite.setVisible(true);
                ddlFakulte.setVisible(true);
                ddlBolum.setVisible(true);
                //                txtOkulAdi.setVisible(false);
            }
            else {
                ddlUniversite.setVisible(false);
                ddlFakulte.setVisible(false);
                ddlBolum.setVisible(false);
                //                txtOkulAdi.setVisible(true);
            }
        }
        function DenklikAc() {
            if (chkDenklik.checked)
                cmpDenklik.show();
            else
                cmpDenklik.hide();
        }

        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                function (btn) {
                    if (btn == "yes") {
                        Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                    }
                });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };

        function ZorunluAlanKontrol() {
            if (!FormPanel1.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return FormPanel1.isValid();
        }  
    </script>
    <style type="text/css">
        .search-item
        {
            font: normal 11px tahoma, arial, helvetica, sans-serif;
            padding: 3px 10px 3px 10px;
            border: 1px solid #fff;
            border-bottom: 1px solid #eeeeee;
            white-space: normal;
            color: #555;
        }
        
        .search-item h3
        {
            display: block;
            font: inherit;
            font-weight: bold;
            color: #222;
        }
        
        .search-item h3 span
        {
            float: right;
            font-weight: normal;
            margin: 0 0 5px 5px;
            width: 100px;
            display: block;
            clear: none;
        }
        
        p
        {
            width: 650px;
        }
        
        .ext-ie .x-form-text
        {
            position: static !important;
        }
    </style>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden runat="server" ID="hdnPKod" />
    <ext:Hidden runat="server" ID="hdnKod" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="OGRENIMKOD" />
                    <ext:RecordField Name="UNIVERSITEKOD" />
                    <ext:RecordField Name="FAKULTEKOD" />
                    <ext:RecordField Name="BOLUMKOD" />
                    <ext:RecordField Name="OKULADI" />
                    <ext:RecordField Name="BELGETUR" />
                    <ext:RecordField Name="BELGETARIHI" Type="Date" />
                    <ext:RecordField Name="BELGENO" />
                    <ext:RecordField Name="BASLANGICTARIHI" Type="Date" />
                    <ext:RecordField Name="DERECE" />
                    <ext:RecordField Name="GECERLI" />
                    <ext:RecordField Name="OGRENIMYERI" />
                    <ext:RecordField Name="DENKLIK" />
                    <ext:RecordField Name="DENKLIKTARIHI" />
                    <ext:RecordField Name="DENKOKUL" />
                    <ext:RecordField Name="DENKBOLUM" />
                    <ext:RecordField Name="HAZIRLIK" />
                    <ext:RecordField Name="KURUMAIBRAZTARIHI" Type="Date"/>
                    <ext:RecordField Name="OgrenimKodKayitKod" />
                    <ext:RecordField Name="GIRISOKULU" />
                    <ext:RecordField Name="OGRENIMSURESI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreOgrenim" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreUniversite" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreFakulte" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreBolum" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreOgrenimYeri" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreOgrenimBelgeTur" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel ID="FPanel1" runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click" ViewStateMode="Enabled" Before="return ZorunluAlanKontrol();">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                Icon="Delete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnTemizle_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="Button1" Icon="Lightbulb" runat="server">
                                <Listeners>
                                    <MouseOver Handler="wndYardim.show();" />
                                    <MouseOut Handler="wndYardim.hide();" />
                                </Listeners>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="FormPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        Region="Center">
                        <Items>
                            <ext:ComboBox ID="ddlOgrenim" runat="server" Editable="true" TypeAhead="true" Mode="Local"
                                ForceSelection="true" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG033 %>"
                                NoteAlign="Top" AnchorHorizontal="95%" StoreID="StoreOgrenim" DisplayField="AD"
                                ValueField="KOD" SelectOnFocus="true">
                                <Listeners>
                                    <Select Handler="OgrenimKodDegisti();" />
                                </Listeners>
                            </ext:ComboBox>
                            <ext:ComboBox ID="ddlUniversite" runat="server" Editable="true" TypeAhead="false"
                                Mode="Local" ForceSelection="false" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG018 %>"
                                AnchorHorizontal="95%" StoreID="StoreUniversite" DisplayField="AD" ValueField="KOD"
                                SelectOnFocus="true">
                            </ext:ComboBox>
                            <ext:ComboBox ID="ddlFakulte" runat="server" Editable="true" TypeAhead="false" ForceSelection="false"
                                FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG019 %>" AnchorHorizontal="95%"
                                StoreID="StoreFakulte" DisplayField="AD" ValueField="KOD" SelectOnFocus="true">
                            </ext:ComboBox>
                            <ext:ComboBox ID="ddlBolum" runat="server" Editable="true" TypeAhead="false" ForceSelection="false"
                                FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG020 %>" AnchorHorizontal="95%"
                                StoreID="StoreBolum" DisplayField="AD" ValueField="KOD" SelectOnFocus="true">
                            </ext:ComboBox>
                            <ext:TextField ID="txtOkulAdi" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG017 %>"
                                AnchorHorizontal="95%" />
                            <ext:CheckboxGroup runat="server" FieldLabel="Okul Bilgisi">
                                <Items>
                                    <ext:Checkbox runat="server" ID="chkMemuriyeteBaslama" BoxLabel="Memuriyete Başladığı Okul"
                                        AnchorHorizontal="95%">
                                    </ext:Checkbox>
                                    <ext:Checkbox runat="server" ID="chkGecerli" BoxLabel="<%$ Resources:InsanKaynaklari,FRMPOG034 %>"
                                        AnchorHorizontal="95%">
                                    </ext:Checkbox>
                                </Items>
                            </ext:CheckboxGroup>
                            <ext:ComboBox ID="ddlOgrenimYeri" runat="server" Editable="true" TypeAhead="false"
                                ForceSelection="false" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG052 %>"
                                AnchorHorizontal="95%" StoreID="StoreOgrenimYeri" DisplayField="AD" ValueField="KOD"
                                SelectOnFocus="true">
                            </ext:ComboBox>
                            <ext:NumberField ID="txtOgrenimSuresi" runat="server" FieldLabel="Öğrenim Süresi"
                                Width="100" />
                            <ext:DateField runat="server" ID="txtBaslamaTarihi" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG048 %>"
                                NoteAlign="Top" Vtype="daterange">
                                <CustomConfig>
                                    <ext:ConfigItem Name="endDateField" Value="#{txtBitirmeTarihi}" Mode="Value" />
                                </CustomConfig>
                            </ext:DateField>
                            <ext:CompositeField runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG053 %>">
                            <Items>
                                <ext:ComboBox ID="ddlBelgeTur" runat="server" Editable="true" TypeAhead="false" ForceSelection="false"
                                    Width="100" StoreID="StoreOgrenimBelgeTur"
                                    DisplayField="AD" ValueField="KOD" SelectOnFocus="true">
                                </ext:ComboBox>
                                <ext:Label runat="server" Text="<%$ Resources:InsanKaynaklari,FRMPOG039 %>" />
                                <ext:TextField runat="server" ID="txtBelgeNo" Width="120" />
                            </Items>
                            </ext:CompositeField>
                            <ext:CompositeField ID="CompositeField1" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG040 %>">
                            <Items>
                                <ext:TextField runat="server" ID="txtDerecesi" Width="60" MaskRe="/[0-9]/" />
                                <ext:Label runat="server" Text="<%$ Resources:InsanKaynaklari,FRMPOG041 %>" />
                                <ext:DateField runat="server" ID="txtBitirmeTarihi" />
                            </Items>
                            </ext:CompositeField>
                            <ext:Checkbox runat="server" ID="chkDenklik" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG054 %>"
                                NoteAlign="Top">
                                <Listeners>
                                    <Check Handler="DenklikAc();" />
                                </Listeners>
                            </ext:Checkbox>
                            <ext:CompositeField ID="cmpDenklik" runat="server" Hidden="true" HideLabel="true">
                                <Items>
                                    <ext:TextField ID="txtDenklikBolum" runat="server" Note="<%$ Resources:InsanKaynaklari,FRMPOG055 %>"
                                        Width="150" NoteAlign="Top" />
                                    <ext:TextField ID="txtDenklikOkul" runat="server" Note="<%$ Resources:InsanKaynaklari,FRMPOG056 %>"
                                        Width="150" NoteAlign="Top" />
                                    <ext:DateField runat="server" ID="txtDenklikTarihi" Note="<%$ Resources:InsanKaynaklari,FRMPOG057 %>"
                                        Width="95" NoteAlign="Top">
                                    </ext:DateField>
                                </Items>
                            </ext:CompositeField>
                            <ext:Checkbox runat="server" ID="chkHazirlik" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG058 %>"
                                NoteAlign="Top" Width="250">
                            </ext:Checkbox>
                            <ext:DateField runat="server" ID="txtKurumIbrazTarihi" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG059 %>"
                                Width="95">
                            </ext:DateField>
                            <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                Frame="true" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG043 %>" TrackMouseOver="true"
                                StoreID="BelgeStore" HideHeaders="true" AutoHeight="true" AnchorHorizontal="95%" HideLabel="true">
                                <ColumnModel>
                                    <Columns>
                                        <ext:RowNumbererColumn />
                                        <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Header="<%$ Resources:InsanKaynaklari,FRMPOG043 %>"
                                            Width="250" />
                                        <ext:CommandColumn Width="30">
                                            <Commands>
                                                <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPOG044 %>" />
                                            </Commands>
                                        </ext:CommandColumn>
                                        <ext:CommandColumn Width="30">
                                            <Commands>
                                                <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMPOG045 %>" />
                                            </Commands>
                                        </ext:CommandColumn>
                                    </Columns>
                                </ColumnModel>
                                <Listeners>
                                    <Command Fn="KomutCalistir" />
                                </Listeners>
                                <SelectionModel>
                                    <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                    </ext:RowSelectionModel>
                                </SelectionModel>
                                <TopBar>
                                    <ext:Toolbar ID="Toolbar2" runat="server">
                                        <Items>
                                            <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                ButtonText="<%$ Resources:InsanKaynaklari,FRMPOG046 %>">
                                                <DirectEvents>
                                                    <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                </DirectEvents>
                                            </ext:FileUploadField>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                            </ext:GridPanel>
                        </Items>
                    </ext:FormPanel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" Width="400" AutoExpandColumn="OKULADI"
                        Border="true" Region="East">
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column DataIndex="OKULADI" Header="<%$ Resources:InsanKaynaklari,FRMPOG047 %>" />
                                <ext:DateColumn DataIndex="BASLANGICTARIHI" Header="<%$ Resources:InsanKaynaklari,FRMPOG048 %>"
                                    Width="80" Format="dd/m/Y" />
                                <ext:CheckColumn DataIndex="GIRISOKULU" Header="Memuriyete Başladığı Okul" Width="80" />
                                <ext:CheckColumn DataIndex="GECERLI" Header="<%$ Resources:InsanKaynaklari,FRMPOG049 %>"
                                    Width="80" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                <DirectEvents>
                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                        <ExtraParams>
                                            <ext:Parameter Name="RowValue" Value="Ext1.encode(#{grdListe}.getRowsValues({selectedOnly:true}))"
                                                Mode="Raw" />
                                        </ExtraParams>
                                    </RowSelect>
                                </DirectEvents>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <ext:Window ID="wndYardim" runat="server" Hidden="true" Closable="false" Frame="true"
        Width="380" Height="140" X="220" Y="10">
        <Items>
            <ext:Label ID="Label1" runat="server" Icon="Lightbulb" Text="Memuriyete başladığınız eğitim seviyesinden başlayarak tüm eğitim bilgilerini sırayla bilgilerini girerek kayıt edin. Kaydedip bitirdiğiniz bilgilerden sonra yine bu formu kullanarak başka öğrenim bilgileri kayıtlarınızı yapabilirsiniz. Kayıt ettikleriniz sağdaki listede gözükecek. Okula başlama ve bitiş tarihlerini tam olarak bilmiyorsanız 01.01.YIL olarak giriş yapınız. Belge bilgilerini eğer biliyorsanız doldurunuz." />
        </Items>
    </ext:Window>
    </form>
</body>
</html>
