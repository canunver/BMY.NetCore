﻿<%@ Page Language="C#" CodeBehind="PersonelAramaR.aspx.cs" Inherits="InsanKaynaklari.PersonelAramaR" %>

<!DOCTYPE html>
<html lang="tr">
<head>
    <title>Personel Arama</title>
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <meta content="text/html; charset=utf-8" http-equiv="Content-type" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <link href="../App_themes/BootStrap/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css" />
    <link href="../Script/BootstrapMesajKutusu.css?v=3" rel="stylesheet" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script type="text/javascript" src="../App_themes/BootStrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../Script/BootstrapMesajKutusu.js?v=2"></script>
    <script type="text/javascript" src="../Script/BootstapCheckBox.js"></script>
    <style type="text/css">
        .arkasiTransparan
        {
            background-color: transparent;
            color: black;
        }
        
        .clearer
        {
            position: absolute;
            right: 5px;
            top: 0;
            bottom: 0;
            height: 20px;
            margin: auto;
            font-size: 20px;
            cursor: pointer;
            color: #ccc;
            z-index: 1000;
            margin-top: 10px;
        }
        .chkPersonel
        {
            width: 50px;
            height: 40px;
        }
        .PersonelMenuSecildi
        {
            background-color: #FEFEFE;
        }
        body
        {
            min-height: 100vh;
        }
        .personelMenuLink
        {
            color: White;
        }
        .cift
        {
            background-color: #F8F8F8;
        }
        .grupBaslik
        {
            color: White;
        }
        
        .nav > li > a
        {
            padding-top: 5px !important;
            padding-bottom: 5px !important;
        }
        
        .nav
        {
            min-height: 40px !important;
        }
        .alarm
        {
            position: fixed;
            z-index: 1000;
        }
        .scroll-top-wrapper
        {
            position: fixed;
            opacity: 0;
            visibility: hidden;
            overflow: hidden;
            text-align: center;
            z-index: 99999999;
            background-color: #777777;
            color: #eeeeee;
            width: 50px;
            height: 48px;
            line-height: 48px;
            right: 30px;
            bottom: 30px;
            padding-top: 2px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
            border-bottom-left-radius: 10px;
            -webkit-transition: all 0.5s ease-in-out;
            -moz-transition: all 0.5s ease-in-out;
            -ms-transition: all 0.5s ease-in-out;
            -o-transition: all 0.5s ease-in-out;
            transition: all 0.5s ease-in-out;
        }
        .scroll-top-wrapper:hover
        {
            background-color: #888888;
        }
        .scroll-top-wrapper.show
        {
            visibility: visible;
            cursor: pointer;
            opacity: 1.0;
        }
        .scroll-top-wrapper i.fa
        {
            line-height: inherit;
        }
        .hucre
        {
            font-weight: bold;
            width: 150px;
        }
    </style>
    <script type="text/javascript">
        var aktifPersonel = 0;
        var menuKod = 0;
        function DetayaGit(kod) {
            if (kod > 0) {
                aktifPersonel = kod;
                aktifBolum = 2;
                EkraniKapla();
                PersonelMenuSecildi(2);
                if (screen.width >= 768) {
                    SolGoster();
                }
                else
                    $('#pBilgi').addClass('hidden');

                if ($('.scroll-top-wrapper').is('.show'))
                    $('.scroll-top-wrapper').removeClass('show');
            }
        }

        var listeBekleniyor2 = null;
        function BekleGoster2() {
            if (listeBekleniyor2 != null) return false;
            listeBekleniyor2 = BekleKutusu("Lütfen Bekleyiniz!", 2);
            return true;
        }

        function BekleGizle2() {
            BekleKaldir(listeBekleniyor2);
            listeBekleniyor2 = null;
        }

        function PersonelMenuSecildi(menuNo) {
            menuKod = menuNo;
            if (menuNo == 1) {
                aktifBolum = 1;
                EkraniKapla();
                YukariButonuGoster('listePersonel');
            }
            else {
                if (screen.width < 768)
                    SolGizle();

                $("#personelMenu li").removeClass('active');
                $("#personelMenu li").eq(menuNo - 1).addClass('active');

                var params = JSON.stringify({ 'pKod': aktifPersonel, 'bilgiKod': menuNo });
                if (BekleGoster2()) {
                    $.ajax({
                        type: "POST",
                        url: "PersonelAramaR.aspx/PersonelBilgiAl",
                        data: params,
                        timeout: 0,
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: PersonelBilgiGeldi,
                        error: PersonelBilgiHatali
                    });
                }
            }
        }

        function PersonelBilgiEkle(deger) {
            $("#personelSag").html(deger);
        }

        function PersonelBilgiGeldi(tablo_d) {
            if (aktifBolum != 2) {
                aktifBolum = 2;
                EkraniKapla();
            }
            var tablo = tablo_d.d;
            PersonelBilgiEkle(tablo.sonuc);
            if (tablo.bilgiKod == 2) {
                $("#pResimUrl").attr('src', tablo.resimUrl);
                $("#pIsim").html(tablo.isim);
                $("#pUnvan").html(tablo.unvan);
                $("#pResimUrl2").attr('src', tablo.resimUrl);
                $("#pIsim2").html(tablo.isim);
            }
            BekleGizle2();
        }

        function PersonelBilgiHatali(xhr) {
            BekleGizle2();
            console.log(xhr.responseText);
        }     
    </script>
    <script type="text/javascript">
        function Bekleme(tip) {
            var tut = BekleKutusu("Lütfen Bekleyiniz!", tip);
            setTimeout(function () { BekleKaldir(tut); }, 3000);
        }
        /*
        */
    </script>
    <script type="text/javascript">

        function SolGizliMi() {
            if (aktifBolum == 1)
                return $('#listeSol').hasClass('hidden');
            else
                return $('#personelSol').hasClass('hidden');
        }

        function SolGoster() {
            if (aktifBolum == 1) {
                $('#listeSol').removeClass('hidden');

                if (screen.width < 768) {
                    $('#listeSag').addClass('hidden');
                }
                else {
                    $('#listeSag').removeClass('col-*-12');
                    $('#listeSag').addClass('col-xs-5 col-sm-6 col-md-9 col-lg-9');
                    $('div.alan').removeClass('col-sm-4 col-md-3');
                    $('div.alan').addClass('col-sm-12 col-md-4');
                }
            }
            else {
                $('#pBilgi').addClass('hidden');
                $('#personelSol').removeClass('hidden');
                if (screen.width < 768) {
                    $('#personelSag').addClass('hidden');
                }
                else {
                    $('#personelSag').removeClass('col-*-12');
                    $('#personelSag').addClass('col-xs-12 col-sm-9 col-md-8 col-lg-8');
                }
            }
        }

        function SolGizle() {
            if (aktifBolum == 1) {
                $('#listeSol').addClass('hidden');
                if (screen.width < 768) {
                    $('#listeSag').removeClass('hidden');
                }
                else {
                    $('#listeSag').addClass('col-*-12');
                    $('#listeSag').removeClass('col-xs-5 col-sm-6 col-md-9 col-lg-9');
                    $('div.alan').removeClass('col-sm-12 col-md-4');
                    $('div.alan').addClass('col-sm-4 col-md-3');
                }
            }
            else {
                if (menuKod != 2 && menuKod != 16)
                    $('#pBilgi').removeClass('hidden');
                $('#personelSol').addClass('hidden');
                if (screen.width < 768) {
                    $('#personelSag').removeClass('hidden');
                }
                else {
                    $('#personelSag').addClass('col-*-12');
                    $('#personelSag').removeClass('col-xs-12 col-sm-9 col-md-8 col-lg-8');
                }
            }
        }

        function SolGorunurlukDegistir() {
            if (SolGizliMi()) {
                SolGoster();
                EkraniKapla();
            }
            else {
                SolGizle();
            }
        }

        function VerileriGetir() {
            var scroll = $('#listePersonel').scrollTop();
            var uzunluk = document.getElementById("listePersonel").scrollHeight;
            if ($('#listePersonel').height() + scroll == uzunluk && aranan != null) {
                if (aranan.satir < aranan.toplamKayit) {
                    ListeyiAl();
                }
            }
        }

        var listeBekleniyor = null;
        function BekleGoster() {
            if (listeBekleniyor != null) return false;
            listeBekleniyor = BekleKutusu("Lütfen Bekleyiniz!", 1);
            OlayBirak();
            return true;
        }

        function BekleGizle() {
            BekleKaldir(listeBekleniyor);
            listeBekleniyor = null;
            OlayKur();
        }

        var aranan = null;
        function ListeyiAl() {
            TumunuSecTemizle();
            if (aranan == null) return;
            if (BekleGoster()) {
                var params = { 'genelSorgu': aranan.aramaMetni, 'satir': aranan.satir, 'aktiflik': aranan.aktiflik, 'personelTurGruplari': aranan.personelTipGruplar, 'resimBilgi': aranan.resim, 'solGizli': $('#listeSol').hasClass('hidden') };
                //var params = JSON.stringify({ "genelSorgu": aranan.aramaMetni, "satir": aranan.satir, "aktiflik": aranan.aktiflik, "personelTurGruplari": aranan.personelTipGruplar, "resimBilgi": aranan.resim });
                //var params = { 'genelSorgu': aranan.aramaMetni}; //, satir: aranan.satir, aktiflik: aranan.aktiflik, personelTurGruplari: aranan.personelTipGruplar, resimBilgi: aranan.resim, solGizli: $('#listeSol').hasClass('hidden') };
                params = JSON.stringify(params);
                $.ajax({
                    type: "POST",
                    url: "PersonelAramaR.aspx/Listele",
                    data: params,
                    timeout: 0,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: PersonelListesiGeldi,
                    error: PersonelListesiHatali
                });
            }
        }

        function PersonelListesiGeldi(tablo_d) {
            if (aktifBolum != 1) {
                aktifBolum = 1;
                EkraniKapla();
            }
            var tablo = tablo_d.d;
            if (aranan.satir == 0) ListeSil();
            aranan.satir = tablo.satir;
            aranan.toplamKayit = tablo.toplamKayit;
            ListeyeEkle(tablo.tablo);
            BilgiGoster();
            SolGizle();
            CiftTusOlayiAta();
            BekleGizle();
            TumunuSec();
            $('#listePersonel').focus();
        }

        function PersonelListesiHatali(xhr, status) {
            BekleGizle();
            MesajKutusu("Hata", xhr.responseText + " " + status);
        }

        function ListeSil() {
            $("#listePersonel").html('');
            $("#listePersonel").scrollTop(0);
        }

        function ListeyeEkle(deger) {
            $("#listePersonel").append(deger);
        }

        function BilgiGoster(metin) {
            var mesaj = '';
            if (aranan.toplamKayit == 0)
                mesaj = 'Sonuç Yok.';
            else
                mesaj = aranan.satir + '/' + aranan.toplamKayit;
            $("#sonucBilgi").html(mesaj);
            EkraniKapla();
        }

        function CiftTusOlayiAta() {
            var x = document.getElementById("listePersonel").querySelectorAll(".alan");
            for (var i = 0; i < x.length; i++) {
                var timeout;
                var lastTap = 0;
                x[i].addEventListener("touchend", function (event) {
                    var currentTime = new Date().getTime();
                    var tapLength = currentTime - lastTap;
                    clearTimeout(timeout);
                    if (tapLength < 300 && tapLength > 0) {
                        DetayaGit(this.id.substring(4));
                        event.preventDefault();
                    } else {
                        timeout = setTimeout(function () {
                            clearTimeout(timeout);
                        }, 300);
                    }
                    lastTap = currentTime;
                });
                //                if (gir)
                //                    x[i].setAttribute("class", alansinifi);
            }
        }

        function AramaBaslat(yer) {
            aranan = new Object();
            aranan.aramaMetni = $("#txtAra2")[0].value; // "Can";
            aranan.aktiflik = CheckBoxlariOku("cAktiflik"); //  "1";
            aranan.personelTipGruplar = CheckBoxlariOku("ptip"); //  "Kadrolu";
            aranan.resim = CheckBoxlariOku("Ul1");
            aranan.satir = 0;
            aranan.solGizli = $('#listeSol').hasClass('hidden');
            ListeyiAl();
        }

        function UstAramayaBasildi() {
            AramaBaslat(1);
            return false;
        }

        function SolAramayaBasildi() {
            AramaBaslat(2);
            return false;
        }

        var navUa = navigator.userAgent;
        var androidMi = navUa.indexOf('Android') > -1;
        var chromeMu = navUa.indexOf('Chrome') > -1;
        var tump = "";
        var kodlar = "";

        function sonuc(tus, mailAdres, param) {
            if (tus != 1) return;

            //            var tump = CheckBoxlariOku("tumListe");

            if (param.tip == 2 && mailAdres == "") {
                MesajKutusu("Uyarı", "Lütfen, e. posta adresini giriniz!");
                return;
            }

            var params = JSON.stringify({ dosyaMail: (param.tip == 1), rapor: param.raporId + "," + param.raporAd, aktiflik: aranan.aktiflik, personelTurGruplari: aranan.personelTipGruplar, tumu: tump, mailKisi: mailAdres, kodlar: kodlar, sorgu: aranan.aramaMetni });
            if (BekleGoster2()) {
                $.ajax({
                    type: "POST",
                    url: "PersonelAramaR.aspx/RaporUret",
                    data: params,
                    timeout: 0,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: OnSucceed,
                    error: OnFailed
                });
            }

            function OnSucceed(mesaj) {
                BekleGizle2();
                try {
                    var mesParca = mesaj.d.split(':');
                    if (mesParca[0] == "1") {
                        if (androidMi && !chromeMu) {
                            try {
                                document.forms[0].target = "_blank";
                            }
                            catch (ev) { }
                            window.location.href = mesParca[1];
                        }
                        else {
                            window.location.href = mesParca[1];
                            //SayfaAcModal("Rapor Sayfası", mesParca[1]);
                        }
                    }
                    else {
                        MesajKutusu("Sonuç", mesParca[1]);
                    }
                }
                catch (e) {
                    alert(e.Message);
                }
            }

            function OnFailed(xhr, status) {
                MesajKutusu("Hata", xhr.responseText + " " + status);
                BekleGizle2();
            }
        }

        function StrYap(val) {
            if (val == undefined || val == null) return "";
            return val;
        }

        function SeciliRaporuGetir(tip, raporId, raporAd, pZorunlu) {
            if (aranan == null) {
                MesajKutusu("Uyarı", "Lütfen, önce arama işlemi yapınız!");
                return;
            }

            tump = CheckBoxlariOku("tumListe");
            kodlar = "";
            $("input:checkbox[name=type]:checked").each(function () {
                kodlar += $(this).val() + ";";
            });

            if (pZorunlu == 1 && kodlar == "" && tump != "1") {
                MesajKutusu("Uyarı", "Lütfen, kişi seçiniz ya da 'Tümünü Seç' i işaretleyiniz!");
                return;
            }

            var o = new Object();
            o.tip = tip;
            o.raporId = raporId;
            o.raporAd = raporAd;
            if (tip == 1) {
                mesaj = "Raporunu İndirmek İstediğinizden Emin misiniz?";
                etiket = "";
            }
            else {
                mesaj = "Seçtiğiniz rapor üretilerek, elektronik posta adresini girdiğiniz kişiye gönderilecektir. Onaylıyor musunuz?";
                etiket = "E. Posta Adresi";
            }
            MesajKutusu("Onay", mesaj, o, etiket, sonuc);
        }
        $(document).ready(function () {

            $("#tumListe li").click(function () {
                TumunuSec();
            });

            $(".hasclear").keyup(function () {
                $(this).next().toggle(Boolean($(this).val()));
            });
            $(".clearer").toggle(Boolean($(".hasclear").val()));
            $(".clearer").click(function () {
                $("#txtAra2")[0].value = '';
                $(this).prev().val('').focus();
                $(this).hide();
            });
        });

        function TumunuSec() {
            var sonuc = CheckBoxlariOku("tumListe");
            if (sonuc == "1")
                $(".chkPersonel").prop('checked', true);
            else
                $(".chkPersonel").prop('checked', false);
        }

        function TumunuSecTemizle() {
            //            $("#tumListe li").each(function (idx, li) {
            //                $(li).attr("data-checked", false);
            //                $(li).removeClass('active');
            //            });
        }

    </script>
    <script type="text/javascript">
        var aktifBolum = 1;
        var aktifPersonel = 0;
        function EkraninAltinaUzat(div) {
            $('#' + div).height(function (index, height) {
                return window.innerHeight - $(this).offset().top;
            });
        }

        function EkraniKapla() {
            if (aktifBolum == 1) {
                $('#bolumPersonel').addClass('hidden');
                $('#bolumListe').removeClass('hidden');
                EkraninAltinaUzat('listePersonel');
                EkraninAltinaUzat('listeSol');
            }
            else {
                $('#bolumListe').addClass('hidden');
                $('#bolumPersonel').removeClass('hidden');
                EkraninAltinaUzat('personelSol');
                EkraninAltinaUzat('personelSag');
            }
        }

        function OlayBirak() {
            $('#listePersonel').unbind("scroll");
        }

        function OlayKur() {
            $('#listePersonel').scroll(function () { VerileriGetir(); });
        }

        $(document).ready(function () {
            $("#txtAra2").keypress(function (e) {
                if (e.which === 13) {
                    SolAramayaBasildi();
                    $("#txtAra2").blur();
                    $("#listePersonel").focus();
                }
            });
            OlayKur();
            $(window).resize(function () {
                EkraniKapla();
            });
            window.onbeforeunload = HandleBackFunctionality;
            window.addEventListener("backbutton", backButtonTap, true);
            SolGoster();
            $("#txtAra2")[0].focus();
            //backpressed
        });

        function backButtonTap() {
            return false;
        }

        function HandleBackFunctionality(ev) {
            //ev.returnValue = "";
            //return false; // "Bu sayfadan ayrılmak istiyor musunuz?";
            //return null;
        }

        function GoMail(adres) {
            window.location = "mailto:" + adres;
        }
    </script>
    <script type="text/javascript">
        function YukariButonuGoster(divId) {
            if ($('#' + divId).scrollTop() > 100) {
                $('.scroll-top-wrapper').addClass('show');
            } else {
                $('.scroll-top-wrapper').removeClass('show');
            }

            $('.scroll-top-wrapper').on('click', scrollToTop);
        }

        function scrollToTop() {
            //            verticalOffset = typeof (verticalOffset) != 'undefined' ? verticalOffset : 0;
            //            element = $('#listePersonel');
            //            offset = element.offset();
            //            offsetTop = offset.top;
            //            $('#listePersonel').animate({ scrollTop: offsetTop }, 500, 'linear');
            $('body, html, #listePersonel').scrollTop(0);
            $('body, html, #personelSag').scrollTop(0);
        }
    </script>
</head>
<body style="background-color: #b8e2ff; height: 100%;">
    <div class="navbar navbar-inverse navbar-fixed-top text-center-block" role="navigation">
        <div class="container" style="margin-bottom: 9px;">
            <div class="navbar-header">
                <div  style="margin-top: 9px;">
                    <div class="input-group input-group-lg" style="width: 100%">
                        <div class="input-group-btn">
                            <button type="button" class="btn btn-primary" onclick="SolGorunurlukDegistir()">
                                <span class="glyphicon glyphicon-align-justify"></span>
                            </button>
                        </div>
                        <div class="form-group has-feedback">
                            <input type="text" class="form-control hasclear input-lg" id="txtAra2" placeholder="Arama kriteri giriniz..." />
                            <span class="clearer glyphicon glyphicon-remove-circle"></span>
                        </div>
                        <div class="input-group-btn">
                            <button type="submit" class="btn btn-primary" onclick="return UstAramayaBasildi();">
                                <span class="glyphicon glyphicon-search"></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid" style="padding-top: 60px" id="bolumListe">
        <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 hidden" id="listeSol" style="background-color: Black;
            overflow: auto; margin-top: 9px;">
            <ul class="nav nav-tabs" role="tablist" style="margin-top: 6px;">
                <li class="active"><a href="#filtre" role="tab" data-toggle="tab">Filtreler</a></li>
                <li><a href="#rapor" role="tab" data-toggle="tab">Raporlar</a></li>
            </ul>
            <div class="tab-content" style="margin-bottom: 20px;">
                <div class="tab-pane active" id="filtre">
                    <div class="row" style="margin-left: 2px; margin-right: 2px">
                        <h4 class="text-center grupBaslik">
                            Aktiflik</h4>
                        <ul id="cAktiflik" class="list-group checked-list-box">
                            <li class="list-group-item" data-style="button" data-color="info" data-checked="true"
                                value="1">Aktif</li>
                            <li class="list-group-item" data-style="button" data-color="info" value="0">Pasif</li>
                        </ul>
                    </div>
                    <div class="row" style="margin-left: 2px; margin-right: 2px">
                        <h4 class="text-center grupBaslik">
                            Personel Türleri</h4>
                        <ul id="ptip" class="list-group checked-list-box">
                            <asp:Literal ID="pTurler" runat="server"></asp:Literal>
                        </ul>
                    </div>
                    <div class="row" style="margin-left: 2px; margin-right: 2px">
                        <h4 class="text-center grupBaslik">
                            Personel Resmi</h4>
                        <ul id="Ul1" class="list-group checked-list-box">
                            <li class="list-group-item" data-style="button" data-color="info" data-checked="true"
                                value="1">Gösterilsin</li>
                        </ul>
                    </div>
                    <div class="row text-center">
                        <button class="btn btn-primary btn-md" type="submit" id="btnBas" style="width: 220px"
                            onclick="return SolAramayaBasildi();">
                            <i class="glyphicon glyphicon-search">Ara</i>
                        </button>
                    </div>
                </div>
                <div class="tab-pane" id="rapor">
                    <div class="row" style="margin-top: 5px; margin-left: 2px; margin-right: 2px">
                    </div>
                    <div class="panel-group" id="accordion" style="margin: 10px 5px 5px 5px">
                        <asp:Literal runat="server" ID="ltlRaporlar"></asp:Literal>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-*-12" id="listeSag">
            <div class="alert" style="display: block; margin: 0px 37px 0px 24px; padding: 10px 6px 10px 6px;">
                <table style="padding: 0px; margin: 0px; border-spacing: 0px;" cellpadding="0" cellspacing="0">
                    <tr style="padding: 0px; margin: 0px;">
                        <td>
                            <ul id="tumListe" class="list-group checked-list-box" style="background: transparent;
                                width: 130px; padding: 0px; margin: 0px; border: 0px">
                                <li class="list-group-item" data-color="info" data-arka="arkasiTransparan" data-checked="false"
                                    value="1" style="padding: 0px; margin: 0px; border: 0px;">Tümünü Seç</li>
                            </ul>
                        </td>
                        <td style="width: 100%;">
                            <span id="sonucBilgi" style="font-size: large; color: black; float: right"></span>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="info" id="listePersonel" style="overflow: auto; margin-top: 0px; -webkit-overflow-scrolling: touch;"
                onscroll="YukariButonuGoster('listePersonel');">
            </div>
        </div>
    </div>
    <div class="container-fluid hidden" style="padding-top: 70px" id="bolumPersonel">
        <div class="col-xs-12 col-sm-3 col-md-4 col-lg-4 hidden" id="personelSol" style="background-color: Black;
            overflow: auto">
            <div>
                <div style="float: none; margin: 0 auto; width: 50%; height: 50%; -webkit-border-radius: 50% !important;
                    -moz-border-radius: 50% !important; border-radius: 50% !important; padding-top: 10px">
                    <img class="img-responsive img-circle" alt="" id="pResimUrl" />
                </div>
                <div style="text-align: center;">
                    <div id="pIsim" style="color: #5a7391; font-size: 16px; font-weight: 600;">
                    </div>
                    <div id="pUnvan" style="color: #5b9bd1; font-size: 12px; font-weight: 600;">
                    </div>
                </div>
                <div>
                    <ul class="nav nav-pills nav-stacked" id="personelMenu">
                        <li><a href="#" onclick="PersonelMenuSecildi(1);" class="personelMenuLink">
                            <img src="../App_themes/Icon/SearchIcon.png" />
                            Arama</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(2);" class="personelMenuLink">
                            <img src="../App_themes/Icon/PersonIcon.png" />
                            Personel</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(3);" class="personelMenuLink">
                            <img src="../App_themes/Icon/CardIcon.png" />
                            Nüfus</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(4);" class="personelMenuLink">
                            <img src="../App_themes/Icon/AdressIcon.png" />
                            İletişim/Adres</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(5);" class="personelMenuLink">
                            <img src="../App_themes/Icon/MilitaryIcon.png" />
                            Askerlik</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(6);" class="personelMenuLink">
                            <img src="../App_themes/Icon/EducationIcon.png" />
                            Ögrenim</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(7);" class="personelMenuLink">
                            <img src="../App_themes/Icon/FamilyIcon.png" />
                            Aile</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(8);" class="personelMenuLink">
                            <img src="../App_themes/Icon/CourseIcon.png" />
                            Kurs</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(9);" class="personelMenuLink">
                            <img src="../App_themes/Icon/LanguageIcon.png" />
                            Dil</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(10);" class="personelMenuLink">
                            <img src="../App_themes/Icon/JobIcon.png" />
                            Hizmet</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(11);" class="personelMenuLink">
                            <img src="../App_themes/Icon/StarIcon.png" />
                            Takdir</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(12);" class="personelMenuLink">
                            <img src="../App_themes/Icon/ErrorIcon.png" />
                            Ceza</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(13);" class="personelMenuLink">
                            <img src="../App_themes/Icon/OfficerIcon.png" />
                            Memuriyet</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(14);" class="personelMenuLink">
                            <img src="../App_themes/Icon/IzinIcon.png" />
                            İzin</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(15);" class="personelMenuLink">
                            <img src="../App_themes/Icon/JobIcon.png" />
                            Eski Hizmet</a></li>
                        <li><a href="#" onclick="PersonelMenuSecildi(16);" class="personelMenuLink">
                            <img src="../App_themes/Icon/InfoIcon.png" />
                            Hepsi</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row hidden" id="pBilgi" style="margin: 0px 37px 0px 24px; padding: 10px 6px 10px 6px;">
            <table style="padding: 0px; margin: 0px; border-spacing: 0px;" cellpadding="0" cellspacing="0">
                <tr style="padding: 0px; margin: 0px;">
                    <td>
                        <img class="img-rounded" alt="" id="pResimUrl2" style="height: 80px; width: 60px;" />
                    </td>
                    <td style="padding-left: 10px;">
                        <label id="pIsim2">
                        </label>
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-xs-12 col-sm-9 col-md-8 col-lg-8" id="personelSag" style="overflow: auto;
            -webkit-overflow-scrolling: touch;" onscroll="YukariButonuGoster('personelSag');">
        </div>
    </div>
    <div class="scroll-top-wrapper">
        <span class="scroll-top-inner"><i class="glyphicon glyphicon-arrow-up"></i></span>
    </div>
</body>
</html>
