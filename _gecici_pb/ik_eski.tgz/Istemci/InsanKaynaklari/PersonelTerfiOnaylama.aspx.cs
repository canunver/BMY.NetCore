﻿using System;
using System.Collections;
using System.Data;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using System.Collections.Generic;

namespace InsanKaynaklari
{
    public partial class PersonelTerfiOnaylama : istemciUzayi.GenelSayfaV2
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = Resources.InsanKaynaklari.FRMKAD025;
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Genel.TerfiTipiDoldur(tipStore);
                Genel.TerfiDurumuDoldur(durumStore);
            }
        }

        public void Listele()
        {
            //string hata = "";
            //if (pgFiltre.Source["durum"].Value == "")
            //    hata = "Yıl bilgisini seçmelisiniz.";

            //if (!string.IsNullOrEmpty(hata))
            //{
            //    GenelIslemler.MesajKutusu("Bilgi", hata);
            //    return;
            //}
            ChkSelectionModel.ClearSelections();
            Terfi terfi = new Terfi();
            terfi.durum = OrtakFonksiyonlar.ConvertToInt(ddlDurum.Value, 0);
            terfi.tip = OrtakFonksiyonlar.ConvertToInt(ddlTip.Value, 0);
            ObjectArray terfisiGelenler = servisIKY.PersonelTerfiListele(kullanan, terfi);

            if (!terfisiGelenler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, terfisiGelenler.sonuc.hataStr);
                return;
            }
            List<object> liste = new List<object>();

            foreach (Terfi p in terfisiGelenler.objeler)
            {

                liste.Add(new
                {
                    TKOD = p.kod,
                    PKADROKOD = p.pKadroKod,
                    PKOD = p.pKod,
                    TC = p.kimlikNo,
                    ADSOYAD = p.ad,
                    SICILNO = p.sicilNo,
                    TIP = p.tip,
                    TIPAD = Genel.TerfiTipAdiDondur(p.tip),
                    BIRIMAD = p.birim,
                    UNVANAD = p.unvan,
                    SEBEP = p.hizmetSebebi,
                    KADRODERECE = p.kadroDerece,
                    KADROTARIH = p.kadroTarih.ToString(),
                    KAZANILMISHAKDERECE = p.kazanilmisHakDerece,
                    KAZANILMISHAKKADEME = p.kazanilmisHakKademe,
                    KAZANILMISHAKTARIH = p.kazanilmisHakTarih.ToString(),
                    ODEMEYEESASDERECE = p.odemeyeEsasDerece,
                    ODEMEYEESASKADEME = p.odemeyeEsasKademe,
                    ODEMEYEESASTARIH = p.odemeyeEsasTarih.ToString(),
                    EMEKLIYEESASDERECE = p.emekliyeEsasDerece,
                    EMEKLIYEESASKADEME = p.emekliyeEsasKademe,
                    EMEKLIYEESASTARIH = p.emekliyeEsasTarih.ToString(),
                    OGRENIM = p.ogrenim,
                    YDERECE = p.yukselecegiDerece,
                    YILAY = p.yil.ToString()+p.ay.ToString().PadLeft(2,'0'),
                    DURUM = p.durum,
                    SEBEPAD = p.sebepAd,
                    DURUMAD = Genel.TerfiDurumAdiDondur(p.durum),
                });
            }
            ListeStore.DataSource = liste;
            ListeStore.DataBind();
        }

        protected void TerfiOnayla(object sender, DirectEventArgs e)
        {
            int durum = 0;
            Button buton = (Button)sender;
            if (buton.ID == "btnTerfiOnayla")
                durum = OrtakFonksiyonlar.ConvertToInt(ENUMTerfiDurumu.Onay, 0);
            else
                durum = OrtakFonksiyonlar.ConvertToInt(ENUMTerfiDurumu.Red, 0);

            Newtonsoft.Json.Linq.JObject[] o = (Newtonsoft.Json.Linq.JObject[])JSON.Deserialize(e.ExtraParams["terfiler"], typeof(Newtonsoft.Json.Linq.JObject[]));

            if (o.Length == 0)
            {
                GenelIslemler.MesajKutusu("Bilgi", "Listeden herhangi bir başvuru seçilmediği için işlem yapılamadı.");
                return;
            }

            Sonuc sonuc = new Sonuc();
            string hata = string.Empty;
            string hataFormat = "Seçili {0}.satır için {1} <br>";
            int sayac = 0, cnt = 1;

            foreach (Newtonsoft.Json.Linq.JObject row in o)
            {
                if (row.Value<int>("DURUM") == OrtakFonksiyonlar.ConvertToInt(ENUMTerfiDurumu.Beklemede, 0))
                {
                    Terfi terfi = new Terfi();
                    terfi.kod = OrtakFonksiyonlar.ConvertToInt(row.Value<string>("TKOD"), 0);
                    terfi.pKod = row.Value<int>("PKOD");
                    terfi.pKadroKod = row.Value<int>("PKADROKOD");
                    terfi.durum = durum;
                    terfi.tip = row.Value<int>("TIP");
                    terfi.hizmetSebebi = row.Value<int>("SEBEP");

                    sonuc = servisIKY.EKEKHATerfiEt(kullanan, terfi);
                    if (!sonuc.islemSonuc)
                    {
                        hata += string.Format(hataFormat, (cnt).ToString(), sonuc.hataStr);
                        sayac++;
                    }
                }
                else
                    hata += string.Format(hataFormat, (cnt).ToString(), "Onay/red işlemi yapabilmeniz için seçtiğiniz hizmetin durumu 'beklemede' olmalıdır.");

                cnt++;
            }

            if (string.IsNullOrEmpty(hata))
                GenelIslemler.MesajKutusu(this, "Seçili hizmetlerin onay/red işlemi başarıyla gerçekleştirilmiştir.");
            else
            {
                if (sayac != o.Length)
                    hata += "Diğer seçili hizmetlerin onay/red işlemi başarıyla gerçekleştirilmiştir.";

                GenelIslemler.MesajKutusu(this, hata);
            }
            Listele();
        }

        protected void TerfiListele(object sender, DirectEventArgs e)
        {
            Listele();
        }

        public void TerfiListesiYazdir(object sender, DirectEventArgs e)
        {
            Terfi terfi = new Terfi();
            terfi.durum = OrtakFonksiyonlar.ConvertToInt(ddlDurum.Value, 0);
            terfi.tip = OrtakFonksiyonlar.ConvertToInt(ddlTip.Value, 0);
            string durumAd = "", tipAd = Genel.TerfiTipAdiDondur(terfi.tip);

            if (terfi.durum == (int)ENUMTerfiDurumu.Beklemede)
                durumAd = "ONAY BEKLEYENLER";
            if (terfi.durum == (int)ENUMTerfiDurumu.Red)
                durumAd = "REDDEDİLENLER";
            if (terfi.durum == (int)ENUMTerfiDurumu.Onay)
                durumAd = "TERFİ EDENLER";

            if (terfi.durum == 0)
            {
                GenelIslemler.MesajKutusu("Bilgi", "Durum bilgisini seçmelisiniz.");
                return;
            }

            Tablo XLS = GenelIslemler.NewTablo();

            string sablonAd = this.raporSablonYol + @"IKY\" + "TerfiListesi.xltx";
            //string sonucDosyaAd = DosyaIslem.DosyaAdUret("IKY", "");     
            //XLS.DosyaSaklamaFormatAta("xls");       
            string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            XLS.DosyaAc(sablonAd, sonucDosyaAd);

            int kaynakSatir = 0;
            int satir = 0;
            int sutun = 0;
            XLS.HucreAdAdresCoz("BaslaSatir", ref kaynakSatir, ref sutun);
            XLS.HucreAdBulYaz("YilAy", tipAd + "' NA GÖRE " + durumAd + " LİSTESİ");
            satir = kaynakSatir;

            ObjectArray terfisiGelenler = servisIKY.PersonelTerfiListele(kullanan, terfi);
            int sayac = 1;
            foreach (TNS.IKY.Terfi t in terfisiGelenler.objeler)
            {
                satir++;
                XLS.SatirAc(satir, 1);
                XLS.HucreKopyala(kaynakSatir, sutun, kaynakSatir, sutun + 14, satir, sutun);
                XLS.HucreDegerYaz(satir, 0, sayac);
                XLS.HucreDegerYaz(satir, 1, t.ad);
                XLS.HucreDegerYaz(satir, 2, t.statu);
                XLS.HucreDegerYaz(satir, 3, t.kazanilmisHakDerece);
                XLS.HucreDegerYaz(satir, 4, t.kazanilmisHakKademe);
                XLS.HucreDegerYaz(satir, 5, t.kazanilmisHakEkGosterge);
                XLS.HucreDegerYaz(satir, 6, t.YeniKazanilmisHakDerece);
                XLS.HucreDegerYaz(satir, 7, t.YeniKazanilmisHakKademe);
                XLS.HucreDegerYaz(satir, 8, t.YeniKazanilmisHakEkGosterge);
                XLS.HucreDegerYaz(satir, 9, t.emekliyeEsasDerece);
                XLS.HucreDegerYaz(satir, 10, t.emekliyeEsasKademe);
                XLS.HucreDegerYaz(satir, 11, t.emekliyeEsasEkGosterge); 
                XLS.HucreDegerYaz(satir, 12, t.YeniEmekliyeEsasDerece);
                XLS.HucreDegerYaz(satir, 13, t.YeniEmekliyeEsasKademe);
                XLS.HucreDegerYaz(satir, 14, t.YeniEmekliyeEsasEkGosterge);
                sayac++;
                sutun++;
            }

            XLS.DosyaSaklaTamYol();

            DosyaIslem.DosyaGonderX(sonucDosyaAd, "TerfiEdenlerinListesi_" + DateTime.Now.Ticks.ToString() + ".xls", true, "xls", true);
        }
    }
}