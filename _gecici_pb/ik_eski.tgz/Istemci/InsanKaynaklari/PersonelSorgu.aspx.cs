﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Bilgi Sınıfı
    /// </summary>
    public partial class PersonelSorgu : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Request.QueryString["menuYok"] + "" != "")
            //    tabPanelAna.Margins = "0 0 0 0";

            //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan))
            //{
            //    personelTCKimlikNo = kullanan.mernis;
            //}

            //SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                hdnYetkiliBirim.Text = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");
                trpBirim.Listeners.BeforeLoad.Fn = "OrgBirimDoldur";
                Genel.UnvanDoldur(servisIKY, this, storeUnvan);
                //Genel.KadroDereceDoldur(storeKadroDerece);
                //Genel.PersonelTurDoldur(cmbPersonelTip, personelTipStore, null);
                //personelTipStore.InsertRecord(0, new PersonelTipi());
            }
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected void PersonelListele(object sender, DirectEventArgs e)
        {
            try
            {
                //p.ad = pgFiltre.Source["ad"].Value;
                //p.soyad = pgFiltre.Source["soyad"].Value;
                //p.tcKimlikNo = pgFiltre.Source["tcKimlikNo"].Value;
                //p.personelTip = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["personelTip"].Value, 0);
                //p.sicilNo = pgFiltre.Source["sicilNo"].Value;
                //p.genelSorgu = pgFiltre.Source["genelSorgu"].Value;
                //p.KADRO.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["birim"].Value, 0);
                //p.KADRO.unvan = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["unvan"].Value, 0);
                //p.KADRO.kadroDerece = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["kadroDerece"].Value, 0);

                TNS.IKY.Personel p = new TNS.IKY.Personel();
                p.genelSorgu = txtGenelSorgu.Text;
                p.kadro.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value.ToString(), 0);
                p.kadro.unvan = OrtakFonksiyonlar.ConvertToInt(cmbUnvan.Value, 0);

                ObjectArray liste = servisIKY.PersonelListele(kullanan, p, false, true);

                if (!liste.sonuc.islemSonuc)
                    throw new Exception(liste.sonuc.hataStr);

                ArrayList extListe = new ArrayList();
                foreach (TNS.IKY.Personel per in liste.objeler)
                    extListe.Add(new object[] { per.kod, per.ad + ' ' + per.soyad, per.tcKimlikNo, per.sicilNo, per.kadro.birimAd, per.kadro.unvanAd, per.kadro.kadroDerece, per.kadro.kadroTarih.ToString(), per.kadro.kadroDurumAd, per.personelTipAd });

                ListeStore.DataSource = (object[])extListe.ToArray(typeof(object[]));
                ListeStore.DataBind();
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
            }
        }

        /// <summary>
        /// Rows the select.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.DirectEventArgs"/> instance containing the event data.</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            int kod = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["KOD"], 0);
            int tip = OrtakFonksiyonlar.ConvertToInt(Request.QueryString["tip"], 0);
            string ad = e.ExtraParams["ADSOYAD"];
            X.AddScript("parent.BilgiListeleAc(0," + kod + ",0,0,'" + ad + "', " + tip + ");");
            X.AddScript("parent.hidePopWin();");
        }
    }
}