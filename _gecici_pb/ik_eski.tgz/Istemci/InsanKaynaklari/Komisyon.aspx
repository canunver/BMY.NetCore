﻿<%@ Page Language="C#" Inherits="InsanKaynaklari.Komisyon" CodeBehind="Komisyon.aspx.cs" %>

<%@ Register TagPrefix="ext" Namespace="Ext1.Net" Assembly="Ext1.Net" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>Personel Site Kesintisi</title>
    <script type="text/javascript" language="javascript">
        function SatirDegisti() {
            if (smListe.hasSelection())
                Ext1.net.DirectMethods.Goster(smListe.getSelected().data.kod, smListe.getSelected().data.siteAdi, smListe.getSelected().data.blokNo, smListe.getSelected().data.daireNo, smListe.getSelected().data.personelAd, smListe.getSelected().data.unvanAd, smListe.getSelected().data.siteKod);
        }
        var tipRenderer = function (value) {
            var r = tipStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.ad;
        };
        function Temizle() {
        }
        function Yukle() {
            //            hdnIlk.setValue("1");
            stoListe.reload();
        }
        function GridSatirEkle(grid, satirSayi) {
            try {
                var rowIndex = 0;
                for (var i = 0; i < satirSayi; i++) {
                    if (i == 0)
                        rowIndex = grid.addRecord();
                    else
                        grid.addRecord();
                }
                grid.getView().focusRow(rowIndex);
            } catch (e) {
            }
        }
        var imzaTurRenderer = function (value) {
            var r = imzaTurStore.getById(value);
            if (Ext1.isEmpty(r))
                return "";
            return r.data.ad;
        };
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager runat="server">
    </ext:ResourceManager>
    <ext:Hidden ID="hdnKomisyonKod" runat="server" />
    <ext:Store ID="imzaTurStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="ad" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="tipStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="kod">
                <Fields>
                    <ext:RecordField Name="kod" />
                    <ext:RecordField Name="ad" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport runat="server" Layout="BorderLayout" StyleSpec="background-color: transparent;">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout" Margins="104 20 10 20">
                <Items>
                    <ext:Panel ID="pnlSol" runat="server" Title="Komisyon Karar Listesi" Width="600"
                        Collapsed="false" AutoScroll="true" Region="West" Split="true" Layout="BorderLayout">
                        <%--<Tools>
                            <ext:Tool CustomType="icon-clear" Fn="Temizle" Qtip="Alanları Boşalt">
                            </ext:Tool>
                        </Tools>--%>
                        <%-- <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server">
                                <Items>
                                    <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPBI003%>"
                                        Icon="ApplicationGo">
                                        <Listeners>
                                            <Click Handler="Yukle()" />
                                        </Listeners>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>--%>
                        <Items>
                            <%--  <ext:FormPanel ID="FormPanel2" runat="server" Height="150" LabelWidth="100" Layout="AnchorLayout"
                                Frame="false" Header="false" Border="false" Padding="5" Region="North" LabelAlign="Left">
                                <Items>
                                    <ext:ComboBox runat="server" ID="ddlSiteAra" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite007%>"
                                        DisplayField="siteAdi" ValueField="kod" StoreID="siteStore" Width="300px">
                                        <DirectEvents>
                                            <Change OnEvent="SiteDegisti">
                                            </Change>
                                        </DirectEvents>
                                    </ext:ComboBox>
                                    <ext:ComboBox runat="server" ID="ddlBlokAra" FieldLabel="<%$Resources:InsanKaynaklari,LojmanSite044%>"
                                        Width="300px" DisplayField="blokNo" ValueField="kod" StoreID="blokStore">
                                    </ext:ComboBox>
                                    <ext:CompositeField ID="CompositeField1" runat="server">
                                        <Items>
                                            <ext:Label ID="Label2" runat="server" Text="Yıl: " Width="100px">
                                            </ext:Label>
                                            <ext:SpinnerField runat="server" ID="spnYilAra" Width="195px" />
                                        </Items>
                                    </ext:CompositeField>
                                    <ext:ComboBox runat="server" ID="ddlAyAra" StoreID="ayStore" DisplayField="AD" ValueField="KOD"
                                        FieldLabel="Ay" Width="300px">
                                    </ext:ComboBox>
                                </Items>
                            </ext:FormPanel>--%>
                            <ext:Panel ID="Panel2" runat="server" Border="false" Region="Center">
                                <Items>
                                    <ext:FitLayout ID="fitLayout3" runat="server">
                                        <Items>
                                            <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                                Layout="FitLayout" Width="250" Border="false">
                                                <Store>
                                                    <ext:Store runat="server" ID="stoListe" OnRefreshData="stoListe_ReadData" AutoLoad="true"
                                                        RemotePaging="true">
                                                        <Reader>
                                                            <ext:JsonReader>
                                                                <Fields>
                                                                    <ext:RecordField Name="kod" Type="Int" />
                                                                    <ext:RecordField Name="kararTarihiDT" Type="Date" />
                                                                    <ext:RecordField Name="kararSayisi" Type="String" />
                                                                </Fields>
                                                            </ext:JsonReader>
                                                        </Reader>
                                                    </ext:Store>
                                                </Store>
                                                <ColumnModel>
                                                    <Columns>
                                                        <ext:DateColumn DataIndex="kararTarihiDT" ColumnID="kararTarihiDT" Header="Karar Tarihi"
                                                            Width="200" Format="dd.MM.yyyy" />
                                                        <ext:Column DataIndex="kararSayisi" ColumnID="kararSayisi" Header="Karar Sayısı"
                                                            Width="200" />
                                                    </Columns>
                                                </ColumnModel>
                                                <SelectionModel>
                                                    <ext:RowSelectionModel runat="server" ID="smListe">
                                                        <Listeners>
                                                            <SelectionChange Fn="SatirDegisti" />
                                                        </Listeners>
                                                    </ext:RowSelectionModel>
                                                </SelectionModel>
                                            </ext:GridPanel>
                                        </Items>
                                    </ext:FitLayout>
                                </Items>
                            </ext:Panel>
                        </Items>
                    </ext:Panel>
                    <ext:Panel ID="Panel3" runat="server" Border="false" Region="Center" Layout="RowLayout">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, LojmanSite037%>"
                                        TabIndex="17" Icon="DatabaseSave">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Title="<%$ Resources:InsanKaynaklari, LojmanSite038%>"
                                                    Message="<%$ Resources:InsanKaynaklari, LojmanSite039%>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, LojmanSite040%>" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="imzaBilgileri" Value="Ext1.util.JSON.encode(#{gridImza}.getRowsValues())"
                                                        Mode="Raw" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnSil" runat="server" Text="Sil" Icon="TableDelete">
                                        <DirectEvents>
                                            <Click OnEvent="btnSil_Click">
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnYeni" runat="server" Text="Yeni Kayıt" Icon="PageWhite">
                                        <DirectEvents>
                                            <Click OnEvent="btnYeni_Click">
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnKomisyonKarari" runat="server" Text="Yazdır" Icon="PageWord">
                                        <DirectEvents>
                                            <Click OnEvent="KomisyonKarariYazdir" Timeout="900000" IsUpload="true">
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:FormPanel ID="FormPanel1" runat="server" Border="false" Height="180"
                                Padding="5" AutoScroll="true">
                                <Items>
                                    <ext:DateField runat="server" ID="txtKararTarihi" TabIndex="1" FieldLabel="Karar Tarihi">
                                    </ext:DateField>
                                    <ext:TextField runat="server" ID="txtKararSayisi" TabIndex="2" FieldLabel="Karar Sayısı" Width="98">
                                    </ext:TextField>
                                    <ext:DateField runat="server" ID="txtToplantiTarihi" TabIndex="3" FieldLabel="Toplantı Tarihi">
                                    </ext:DateField>
                                    <ext:TextArea runat="server" ID="txtYonerge" TabIndex="4" FieldLabel="Yönerge" AnchorHorizontal="90%">
                                    </ext:TextArea>
                                </Items>
                            </ext:FormPanel>
                            <ext:GridPanel ID="gridImza" runat="server" AutoScroll="true" Frame="true" StripeRows="true"
                                TrackMouseOver="true" AutoWidth="true" ColumnLines="true" ClicksToEdit="1" RowHeight="1">
                                <ColumnModel>
                                    <Columns>
                                        <ext:RowNumbererColumn />
                                        <ext:Column Header="İmza Tipi" DataIndex="tipInt" Width="90" Sortable="false">
                                            <Renderer Fn="tipRenderer" />
                                            <Editor>
                                                <ext:ComboBox runat="server" ID="ddlTip" DisplayField="ad" ValueField="kod" StoreID="tipStore"
                                                    Mode="Local" TriggerAction="All" Resizable="true" ListWidth="200">
                                                </ext:ComboBox>
                                            </Editor>
                                        </ext:Column>
                                        <ext:Column Header="Kişi Tipi" DataIndex="imzaTurInt" Width="90" Sortable="false">
                                            <Renderer Fn="imzaTurRenderer" />
                                            <Editor>
                                                <ext:ComboBox runat="server" ID="ddlImzaTur" DisplayField="ad" ValueField="kod" StoreID="imzaTurStore"
                                                    Mode="Local" TriggerAction="All" Resizable="true" ListWidth="200">
                                                </ext:ComboBox>
                                            </Editor>
                                        </ext:Column>
                                        <ext:Column Header="Unvan" DataIndex="unvan" Width="50" Sortable="false">
                                            <Editor>
                                                <ext:TextField runat="server" ID="txtUnvan">
                                                </ext:TextField>
                                            </Editor>
                                        </ext:Column>
                                        <ext:Column Header="İsim" DataIndex="isim" Width="50" Sortable="false">
                                            <Editor>
                                                <ext:TextField runat="server" ID="txtIsim">
                                                </ext:TextField>
                                            </Editor>
                                        </ext:Column>
                                        <ext:Column Header="Sıra No" DataIndex="siraNo" Width="50" Sortable="false">
                                            <Editor>
                                                <ext:NumberField runat="server" ID="txtSiraNo" MaxValue="4" MinValue="1">
                                                </ext:NumberField>
                                            </Editor>
                                        </ext:Column>
                                    </Columns>
                                </ColumnModel>
                                <View>
                                    <ext:GridView ID="GridView1" ForceFit="true" runat="server">
                                    </ext:GridView>
                                </View>
                                <TopBar>
                                    <ext:Toolbar ID="Toolbar3" runat="server">
                                        <Items>
                                            <ext:SplitButton ID="btnYeniSatir" runat="server" Text="Yeni Satır" Icon="Add">
                                                <Listeners>
                                                    <Click Handler="GridSatirEkle(#{gridImza}, 1);" />
                                                </Listeners>
                                            </ext:SplitButton>
                                            <ext:Button ID="btnSatirSil" runat="server" Text="Satır Sil" Icon="Delete" Disabled="true">
                                                <Listeners>
                                                    <Click Handler="#{gridImza}.deleteSelected(); if (!#{gridImza}.hasSelection()) {#{btnSatirSil}.disable();}" />
                                                </Listeners>
                                            </ext:Button>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                                <SelectionModel>
                                    <ext:RowSelectionModel ID="RowSelectionModel1" SingleSelect="false" runat="server">
                                        <Listeners>
                                            <RowSelect Handler="#{btnSatirSil}.enable();" />
                                            <RowDeselect Handler="if (!#{gridImza}.hasSelection()) {#{btnSatirSil}.disable();}" />
                                        </Listeners>
                                    </ext:RowSelectionModel>
                                </SelectionModel>
                                <Store>
                                    <ext:Store ID="imzaStore" runat="server">
                                        <Reader>
                                            <ext:JsonReader IDProperty="kod">
                                                <Fields>
                                                    <ext:RecordField Name="kod" />
                                                    <ext:RecordField Name="komisyonKod" />
                                                    <ext:RecordField Name="tipInt" />
                                                    <ext:RecordField Name="unvan" />
                                                    <ext:RecordField Name="isim" />
                                                    <ext:RecordField Name="imzaTurInt" />
                                                     <ext:RecordField Name="siraNo" />
                                                </Fields>
                                            </ext:JsonReader>
                                        </Reader>
                                    </ext:Store>
                                </Store>
                            </ext:GridPanel>
                        </Items>
                    </ext:Panel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
