﻿<%@ Page Language="C#" CodeBehind="KadroKontenjan.aspx.cs" Inherits="InsanKaynaklari.KadroKontenjan" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript" src="../Personel/ModulScripts/Ortak.js?mc=03022015"></script>
    <script type="text/javascript" language="javascript">
        function GirisAc(kod) {
            Ext1.net.DirectMethods.Listele(kod);
        }

        var unvanRenderer = function (value) {
            var r = storeUnvan.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.UnvanAd;
        };

    </script>
</head>
<body>
    <form id="form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Store runat="server" ID="storeKadroKontenjan">
        <Reader>
            <ext:JsonReader>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeIslemTur">
        <Reader>
            <ext:JsonReader IDProperty="IslemKod">
                <Fields>
                    <ext:RecordField Name="IslemKod">
                    </ext:RecordField>
                    <ext:RecordField Name="IslemAd">
                    </ext:RecordField>
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeUnvan">
        <Reader>
            <ext:JsonReader IDProperty="UnvanKod">
                <Fields>
                    <ext:RecordField Name="UnvanKod" />
                    <ext:RecordField Name="UnvanAd" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center>
                    <ext:Panel ID="pnlAna" runat="server" AutoScroll="true">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:ExtOrgSecim runat="server" ID="ddlBirim" FieldLabel="<%$ Resources:InsanKaynaklari, FRMKAD008 %>"
                                        AnchorHorizontal="97%" LabelWidth="30"
                                        LabelAlign="Right"/>
                                    <ext:ToolbarSpacer ID="ToolbarSpacer2" runat="server" Width="5">
                                    </ext:ToolbarSpacer>
                                    <ext:TextField runat="server" ID="txtSira" FieldLabel="<%$ Resources:InsanKaynaklari, FRMKAD009 %>"
                                        Width="100" LabelWidth="40" LabelAlign="Right" ReadOnly="true">
                                    </ext:TextField>
                                    <ext:ToolbarSpacer runat="server" Width="5">
                                    </ext:ToolbarSpacer>
                                    <ext:Button runat="server" ID="btnListele" Icon="Report" Text="<%$ Resources:InsanKaynaklari, FRMKAD007 %>">
                                        <DirectEvents>
                                            <Click OnEvent="btnListele_Click">
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, FRMKAD002 %>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button runat="server" ID="btnKaydet" Icon="Disk" Text="<%$ Resources:InsanKaynaklari, FRMKAD005 %>">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari, FRMKAD006 %>"
                                                    Title="<%$ Resources:InsanKaynaklari, FRMKAD005 %>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari, FRMKAD002 %>" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="paramKadroKontenjan" Value="Ext1.encode(#{grdKadroKontenjan}.getRowsValues(false, false, false))"
                                                        Mode="Raw" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMGAN003 %>"
                                        Icon="PageWhite">
                                        <DirectEvents>
                                            <Click OnEvent="btnTemizle_Click">
                                                <EventMask ShowMask="true" Msg="Lütfen bekleyin..." />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button runat="server" ID="btnYazdir" Icon="Printer" Text="<%$ Resources:InsanKaynaklari, FRMKAD022 %>"
                                        AutoPostBack="true" OnClick="btnYazdir_Click">
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="BorderLayout2" runat="server">
                                <North>
                                    <ext:FormPanel ID="FormPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                                        AutoHeight="true" LabelWidth="120">
                                        <Items>
                                            <ext:Container runat="server" Layout="HBoxLayout">
                                                <Items>
                                                    <ext:ComboBox ID="cmbIslemTur" runat="server" StoreID="storeIslemTur" Editable="true"
                                                        Width="250" DisplayField="IslemAd" ValueField="IslemKod" Mode="Local" TriggerAction="All"
                                                        FieldLabel="<%$ Resources:InsanKaynaklari, FRMKAD011 %>">
                                                    </ext:ComboBox>
                                                    <ext:ToolbarSpacer runat="server" Width="20">
                                                    </ext:ToolbarSpacer>
                                                    <ext:DisplayField ID="txtIslemTarih" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMKAD012 %>"
                                                        Width="250" Height="30" />
                                                </Items>
                                            </ext:Container>
                                            <ext:Container runat="server" Layout="HBoxLayout">
                                                <Items>
                                                    <ext:DateField ID="txtDayanakBelgeTarih" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMKAD017 %>"
                                                        Width="250" Height="35" />
                                                    <ext:ToolbarSpacer ID="ToolbarSpacer1" runat="server" Width="20">
                                                    </ext:ToolbarSpacer>
                                                    <ext:TextField runat="server" ID="txtDayanakBelgeNo" FieldLabel="<%$ Resources:InsanKaynaklari, FRMKAD018 %>"
                                                        Width="250" Height="35" />
                                                </Items>
                                            </ext:Container>
                                            <ext:Panel runat="server" Border="false" Height="60">
                                                <Items>
                                                    <ext:TextArea ID="txtAciklama" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMKAD013 %>"
                                                        Width="520" StyleSpec="height:50px;" />
                                                </Items>
                                            </ext:Panel>
                                        </Items>
                                    </ext:FormPanel>
                                </North>
                                <Center Split="true">
                                    <ext:GridPanel ID="grdKadroKontenjan" runat="server" StripeRows="true" Header="false"
                                        TrackMouseOver="true" Layout="FitLayout" StoreID="storeKadroKontenjan" ClicksToEdit="1"
                                        Width="600">
                                        <BottomBar>
                                            <ext:Toolbar runat="server">
                                                <Items>
                                                    <ext:Button ID="btnYeniSatir" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMKAD014 %>"
                                                        Icon="Add">
                                                        <Listeners>
                                                            <Click Handler="
                                                                var rowIndex = #{grdKadroKontenjan}.addRecord(); 
                                                                #{grdKadroKontenjan}.getView().focusRow(rowIndex); 
                                                                #{grdKadroKontenjan}.startEditing(rowIndex, 0);
                                                                " />
                                                        </Listeners>
                                                    </ext:Button>
                                                    <ext:Button ID="btnSatirSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMKAD015 %>"
                                                        Icon="Delete" Disabled="true">
                                                        <Listeners>
                                                            <Click Handler="#{grdKadroKontenjan}.deleteSelected();if (!#{grdKadroKontenjan}.hasSelection()) {#{btnSatirSil}.disable();}" />
                                                        </Listeners>
                                                    </ext:Button>
                                                </Items>
                                            </ext:Toolbar>
                                        </BottomBar>
                                        <View>
                                            <ext:GridView ID="GridView1" ForceFit="true" runat="server">
                                            </ext:GridView>
                                        </View>
                                        <SelectionModel>
                                            <ext:RowSelectionModel ID="RowSelectionModel1" SingleSelect="false" runat="server">
                                                <Listeners>
                                                    <RowSelect Handler="#{btnSatirSil}.enable();" />
                                                    <RowDeselect Handler="if (!#{grdKadroKontenjan}.hasSelection()) {#{btnSatirSil}.disable();}" />
                                                </Listeners>
                                            </ext:RowSelectionModel>
                                        </SelectionModel>
                                    </ext:GridPanel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
