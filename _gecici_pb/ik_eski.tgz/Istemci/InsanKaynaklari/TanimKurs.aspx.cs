﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimKurs : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Kurs Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Listele(new Kurs());
            }
        }

        public void Listele(Kurs kriter)
        {
            //ObjectArray dler = servisIKY.KursListele(kriter);

            //if (!dler.sonuc.islemSonuc)
            //{
            //    GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
            //    return;
            //}

            //if (dler.objeler.Count <= 0)
            //    GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            //List<object> tipler = new List<object>();
            //foreach (TNS.IKY.Kurs d in dler.objeler)
            //    tipler.Add(new
            //    {
            //        KURSKODU = d.kod,
            //        KURSADI = d.ad,
            //    });

            //ListeStore.DataSource = tipler;
            //ListeStore.DataBind();
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            //Kurs d = new Kurs();
            //d.ad = txtKursAdi.Text.Trim();
            //Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            //if (txtKursAdi.Text.Trim() == "")
            //{
            //    GenelIslemler.HataYaz(this, "Kurs alanı boş bırakılamaz.");
            //    return;
            //}

            //Kurs d = new Kurs();
            //d.kod = OrtakFonksiyonlar.ConvertToInt(hdnKursKodu.Value, 0);
            //d.ad = txtKursAdi.Text;

            //Sonuc sonuc = servisIKY.KursKaydet(kullanan, d);

            //if (!sonuc.islemSonuc)
            //    GenelIslemler.HataYaz(this, sonuc.hataStr);
            //else
            //{
            //    Temizle();
            //    Listele(new Kurs());
            //    GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            //}
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            //Kurs d = new Kurs();
            //int kod = OrtakFonksiyonlar.ConvertToInt(hdnKursKodu.Value, 0);

            //if (kod > 0)
            //{
            //    d.kod = kod;
            //    Sonuc sonuc = servisIKY.KursSil(kullanan, d);

            //    if (!sonuc.islemSonuc)
            //        GenelIslemler.HataYaz(this, sonuc.hataStr);
            //    else
            //    {
            //        Temizle();
            //        Listele(new Kurs());
            //        GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
            //    }
            //}
            //else
            //    GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz kursu seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            //Listele(new Kurs());
            //Temizle();
        }

        //void Temizle()
        //{
        //    hdnKursKodu.Value = "";
        //    txtKursAdi.Text = "";
        //    grdListeSelectionModel.ClearSelections();
        //}

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            //hdnKursKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["kursKodu"]);
            //txtKursAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["kursAdi"]);
        }
    }
}
