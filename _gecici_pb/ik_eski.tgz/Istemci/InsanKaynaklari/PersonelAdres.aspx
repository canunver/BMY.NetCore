﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelAdres.aspx.cs"
    Inherits="InsanKaynaklari.PersonelAdres" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="FitLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click" Before="var valid= #{frmBilgi}.getForm().isValid(); if (!valid) {Ext1.Msg.alert('Hata', 'Lütfen, ikamet adresi, e-posta ve web adresi bilgilerinizi kontrol edin.');} return valid;">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnAdres" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRM074%>"
                                Icon="House">
                                <DirectEvents>
                                    <Click OnEvent="btnAdres_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="Button1" Icon="Lightbulb" runat="server">
                                <Listeners>
                                    <MouseOver Handler="wndYardim.show();" />
                                    <MouseOut Handler="wndYardim.hide();" />
                                </Listeners>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="frmBilgi" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        LabelWidth="130" MonitorValid="true">
                        <Items>
                            <ext:TextArea ID="txtAdres" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMPID027%>"
                                AnchorHorizontal="97%" />
                            <ext:FieldSet runat="server" Title="<%$ Resources:InsanKaynaklari,FRMPRM073 %>">
                                <Items>
                                    <ext:TextField ID="txtIsTel" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMORT003%>"
                                        Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtTarabyaTel" runat="server" FieldLabel="Telefon (Tarabya)" Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtEvTel" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMORT002%>"
                                        Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtCepTel" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMORT004%>"
                                        NoteAlign="Top" Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtCep2" runat="server" FieldLabel="Telefon (GSM2)" NoteAlign="Top"
                                        Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtFaks" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMORT007%>"
                                        NoteAlign="Top" Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtLojmanTel" runat="server" FieldLabel="Lojman" NoteAlign="Top"
                                        Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtTelsizTel" runat="server" FieldLabel="Telsiz" NoteAlign="Top"
                                        Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtGoruntuluTel" runat="server" FieldLabel="Görüntülü" NoteAlign="Top"
                                        Width="300">
                                    </ext:TextField>
                                </Items>
                            </ext:FieldSet>
                            <ext:FieldSet runat="server" Title="Internet Bilgileri">
                                <Items>
                                    <ext:TextField ID="txtMobilImzaTel" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMORT008%>" NoteAlign="Top" Width="300" Hidden="true">
                                    </ext:TextField>
                                    <ext:TextField ID="txtePosta" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMORT005%>" NoteAlign="Top" Vtype="email" Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtePosta2" runat="server" FieldLabel="Kişisel E-Posta" NoteAlign="Top" Vtype="email" Width="300">
                                    </ext:TextField>
                                    <ext:TextField ID="txtURL" runat="server" FieldLabel="<%$Resources:InsanKaynaklari,FRMORT006%>" NoteAlign="Top" Vtype="url" Width="300" />
                                    <ext:Checkbox runat="server" ID="chkRehber" FieldLabel="Rehberde Gözüksün" BoxLabel="Evet">
                                    </ext:Checkbox>
                                </Items>
                            </ext:FieldSet>
                        </Items>
                    </ext:FormPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <ext:Window runat="server" Hidden="true" Closable="false" Frame="true" Width="300"
        Height="50" X="220" Y="10" ID="wndYardim">
        <Items>
            <ext:Label ID="Label1" runat="server" Icon="Lightbulb" Text="Adres bilgisini getir düğmesine basarak ulusal adres veritabanına kayıtlı olan ikametgah bilgilerinizi getirin ve diğer bilgileri girdikten sonra kaydet düğmesiyle bilgileri kaydedin." />
        </Items>
    </ext:Window>
    </form>
</body>
</html>
