﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ListePersonelMaasParam.aspx.cs"
    Inherits="InsanKaynaklari.ListePersonelMaasParam" %>

<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript">
        var degisenler = true;
        function DegistiIsaretiKoy() {
            degisenler = false;
        }

        function DosyaYukleAc() {
            wndDosyaYukle.show();
        }

        function DegiskenSecildi(sm) {
            stoDegiskenler.each(function (sat) {
                KontrolEt(sat.data.degiskenAd);
            });
        }

        function KontrolEt(degiskenKod) {
            if (degiskenKod) {
                secili = SeciliMi(degiskenKod);
                var colIndex = KolonBul(degiskenKod);
                gorunur = GoronurMu(colIndex);
                if (gorunur != secili) {
                    GosterGizle(colIndex, secili);
                }
            }
        }

        function SeciliMi(degiskenKod) {
            for (var i = 0; i < smDegiskenler.selections.items.length; i++) {
                if (smDegiskenler.selections.items[i].data.degiskenAd == degiskenKod) return 1;
            }
            return 0;
        }

        function GoronurMu(colIndex) {
            if (colIndex >= 0) {
                if (grdListe.colModel.isHidden(colIndex))
                    return 0;
            }
            return 1;
        }

        function GosterGizle(colIndex, secili) {
            if (colIndex >= 0) {
                grdListe.colModel.setHidden(colIndex, secili == 0);
            }
        }

        function KolonBul(kolonAd) {
            return grdListe.colModel.getIndexById(kolonAd);
            //            for (var i = 0; i < grdListe.colModel.columns.length; i++) {
            //                if (grdListe.colModel.columns[i].id == kolonAd) 
            //                    return grdListe.colModel.columns[i];
            //            }
            //            return null;
        }

        function ddlBirim_SetValue(nodeId, birimAd) {
            ddlBirim.setValue(nodeId, birimAd, false);
        }

        function MuhasebeBirimGoster() {
            yil = new Date().getYear();
            kurum = "";
            var muhasebe = cmbMuhasebe.getValue();

            showPopWin("../ButceMuhasebe/ListeMuhasebeBirim.aspx?menuYok=1&yil=" + yil + "&kurum=" + kurum + "&muhasebe=" + muhasebe, 500, 300, true, null);
        }

        function KisilereAta() {
            var alanAd = sbDegisken.getValue();
            if (alanAd != "") {
                var deger = nfGirilen.getValue();
                stoListe.each(function (sat) {
                    sat.set(alanAd, deger);
                });
            }
        }

        function KodAdGetir(tur) {
            //ServerIslemleri.KodAdGetir(tur);
        }
    </script>
    <style type="text/css">
        .x-grid3-hd-inner
        {
            white-space: normal;
        }
    </style>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Store ID="stoListe" runat="server">
        <Reader>
            <ext:ArrayReader>
                <Fields>
                    <ext:RecordField Name="tcKimlikNo" />
                    <ext:RecordField Name="ad" />
                    <ext:RecordField Name="soyad" />
                    <ext:RecordField Name="unvan" Type="Int" />
                    <ext:RecordField Name="unvanAd" />
                    <ext:RecordField Name="kadroDerece" Type="Int" />
                    <ext:RecordField Name="sicilNo" Type="String" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="stoDegiskenler">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="degiskenAd" Type="String" />
                    <ext:RecordField Name="veriTipiStr" Type="String" />
                    <ext:RecordField Name="aciklama" Type="String" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="stoIslecler">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="kod" Type="Int" />
                    <ext:RecordField Name="ad" Type="String" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;"
        Layout="BorderLayout">
        <Items>
            <ext:Panel ID="Panel3" runat="server" Width="230" Layout="BorderLayout" Collapsed="false"
                AutoScroll="true" Margins="104 20 10 20" Region="Center">
                <Items>
                    <ext:Panel runat="server" Height="140" Region="North" Layout="ColumnLayout">
                        <Items>
                            <ext:FormPanel ID="FormPanel1" runat="server" LabelWidth="120" Layout="AnchorLayout"
                                Frame="false" Header="false" Border="false" Padding="5" ColumnWidth="0.5">
                                <Items>
                                    <ext:ExtMuhSecim ID="cmbMuhasebe" runat="server" FieldLabel="Muhasebe" Width="460"
                                        Editable="true" MinChars="2" SelectOnFocus="true">
                                    </ext:ExtMuhSecim>
                                    <ext:CompositeField ID="CompositeFieldBirim" runat="server" AnchorHorizontal="%98">
                                        <Items>
                                            <ext:TriggerField ID="txtBirim" runat="server" FieldLabel="Birim" TriggerIcon="Search"
                                                Width="100">
                                                <Listeners>
                                                    <TriggerClick Fn="MuhasebeBirimGoster" />
                                                    <Blur Handler="KodAdGetir('Birim')" />
                                                </Listeners>
                                            </ext:TriggerField>
                                            <ext:Label ID="lblBirimAd" runat="server" TabIndex="0" AnchorHorizontal="%80" />
                                        </Items>
                                    </ext:CompositeField>
                                    <ext:MultiCombo runat="server" ID="cmbBordroTurler" DisplayField="ad" AnchorHorizontal="99%"
                                        FieldLabel="Bordro Tür" ValueField="kod" Editable="false" >
                                        <Store>
                                            <ext:Store ID="stoBordroTurler" runat="server">
                                                <Reader>
                                                    <ext:JsonReader>
                                                        <Fields>
                                                            <ext:RecordField Name="kod" />
                                                            <ext:RecordField Name="ad" />
                                                        </Fields>
                                                    </ext:JsonReader>
                                                </Reader>
                                            </ext:Store>
                                        </Store>
                                    </ext:MultiCombo>
                                    <ext:TextField runat="server" ID="txtSorgu" FieldLabel="Arama Kriteri" AnchorHorizontal="99%" />
                                </Items>
                            </ext:FormPanel>
                            <ext:FormPanel ID="FormPanel2" runat="server" LabelWidth="120" Layout="AnchorLayout"
                                Frame="false" Header="false" Border="false" Padding="5" ColumnWidth="0.5">
                                <Items>
                                    <ext:ComboBox ID="ddlUnvan" runat="server" Editable="true" TypeAhead="true" Mode="Local"
                                        ForceSelection="true" FieldLabel="<%$ Resources:Personel,FRMPRK050 %>" AnchorHorizontal="99%"
                                        DisplayField="UnvanAd" ValueField="UnvanKod" SelectOnFocus="true">
                                        <Store>
                                            <ext:Store ID="unvanStore" runat="server">
                                                <Reader>
                                                    <ext:JsonReader IDProperty="UnvanKod">
                                                        <Fields>
                                                            <ext:RecordField Name="UnvanKod" Type="Int" />
                                                            <ext:RecordField Name="UnvanAd" />
                                                        </Fields>
                                                    </ext:JsonReader>
                                                </Reader>
                                            </ext:Store>
                                        </Store>
                                    </ext:ComboBox>
                                    <ext:FieldSet runat="server" Title="Alan Koşulları" HideLabels="true">
                                        <Items>
                                            <ext:CompositeField runat="server">
                                                <Items>
                                                    <ext:ComboBox runat="server" ID="cmbAlan1" StoreID="stoDegiskenler" DisplayField="aciklama"
                                                        Width="300" ValueField="degiskenAd" Editable="false">
                                                    </ext:ComboBox>
                                                    <ext:ComboBox runat="server" ID="cmbIslec1" StoreID="stoIslecler" DisplayField="ad"
                                                        ValueField="kod" Width="100" Editable="false">
                                                    </ext:ComboBox>
                                                    <ext:NumberField runat="server" ID="deger1">
                                                    </ext:NumberField>
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField ID="CompositeField1" runat="server">
                                                <Items>
                                                    <ext:ComboBox runat="server" ID="cmbAlan2" StoreID="stoDegiskenler" DisplayField="aciklama"
                                                        Width="300" ValueField="degiskenAd" Editable="false">
                                                    </ext:ComboBox>
                                                    <ext:ComboBox runat="server" ID="cmbIslec2" StoreID="stoIslecler" DisplayField="ad"
                                                        ValueField="kod" Width="100" Editable="false">
                                                    </ext:ComboBox>
                                                    <ext:NumberField runat="server" ID="deger2">
                                                    </ext:NumberField>
                                                </Items>
                                            </ext:CompositeField>
                                        </Items>
                                    </ext:FieldSet>
                                </Items>
                            </ext:FormPanel>
                            <ext:GridPanel runat="server" ID="grdDegiskenler" Width="200" StoreID="stoDegiskenler"
                                AutoExpandColumn="aciklama">
                                <ColumnModel>
                                    <Columns>
                                        <ext:Column DataIndex="aciklama" ColumnID="aciklama" Header="Kolonlar">
                                        </ext:Column>
                                    </Columns>
                                </ColumnModel>
                                <SelectionModel>
                                    <ext:CheckboxSelectionModel runat="server" CheckOnly="true" ID="smDegiskenler">
                                        <Listeners>
                                            <SelectionChange Fn="DegiskenSecildi" />
                                        </Listeners>
                                    </ext:CheckboxSelectionModel>
                                </SelectionModel>
                            </ext:GridPanel>
                        </Items>
                    </ext:Panel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" StoreID="stoListe"
                        Title="Personel Listesi" Region="Center" ClicksToEdit="1">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server">
                                <Items>
                                    <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:Personel,FRMPBI003%>"
                                        Icon="ApplicationGo">
                                        <DirectEvents>
                                            <Click OnEvent="PersonelListele">
                                                <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:Personel,FRMPAB020%>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:SelectBox runat="server" ID="sbDegisken" StoreID="stoDegiskenler" DisplayField="aciklama"
                                        ValueField="degiskenAd">
                                    </ext:SelectBox>
                                    <ext:NumberField runat="server" ID="nfGirilen" DecimalPrecision="6">
                                    </ext:NumberField>
                                    <ext:Button runat="server" ID="btnDegerAra" Icon="PencilAdd" Text="Kisilere Ata">
                                        <Listeners>
                                            <Click Fn="KisilereAta" />
                                        </Listeners>
                                    </ext:Button>
                                    <ext:Button runat="server" Text="Kaydet" ID="btnKaydet" Icon="Accept">
                                        <DirectEvents>
                                            <Click OnEvent="btnKaydet_Click">
                                                <EventMask ShowMask="true" Msg="Bordro kaydediliyor" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="param" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdListe}.getRowsValues({dirtyRowsOnly:degisenler}))" />
                                                    <ext:Parameter Name="degiskenler" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdDegiskenler}.getRowsValues({selectedOnly:true}))" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button runat="server" Text="Dosya Yükle" ID="Button2" Icon="ArrowUp">
                                        <Listeners>
                                            <Click Fn="DosyaYukleAc" />
                                        </Listeners>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column ColumnID="tcKimlikNo" DataIndex="tcKimlikNo" Width="100" Header="<%$ Resources:Personel,FRMPAB019 %>"
                                    Locked="true" />
                                <ext:Column ColumnID="ad" DataIndex="ad" Width="80" Header="<%$ Resources:Personel,FRMPAB021 %>"
                                    Locked="true" />
                                <ext:Column ColumnID="soyad" DataIndex="soyad" Width="80" Header="<%$ Resources:Personel,FRMPAB022 %>"
                                    Locked="true" />
                                <ext:Column ColumnID="unvanAd" Locked="true" DataIndex="unvanAd" Width="80" Header="<%$ Resources:Personel,FRMPAB036 %>" />
                                <ext:Column ColumnID="sicilNo" Locked="true" DataIndex="sicilNo" Width="60" Header="Sicil" />
                            </Columns>
                        </ColumnModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="250" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                        <View>
                            <ext:LockingGridView runat="server">
                            </ext:LockingGridView>
                        </View>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    <ext:Window runat="server" ID="wndDosyaYukle" Title="Giriş Alanları Dosya Yükleme" Layout="FormLayout" Modal="true" Hidden="true" Width="400" Height="160" Padding="5">
        <Items>
            <ext:ComboBox runat="server" ID="cmbAnahtar" FieldLabel="Anahtar Alan" Editable="false">
                <Items>
                    <ext:ListItem Text="Kimlik No" Value="1" />
                    <ext:ListItem Text="Sicil No" Value="2" />
                </Items>
            </ext:ComboBox>
            <ext:ComboBox runat="server" ID="cmbVeri" FieldLabel="Veri Alan" ValueField="kod" DisplayField="ad" Editable="false">
                <Store>
                    <ext:Store runat="server" ID="stoVeri">
                        <Reader>
                            <ext:JsonReader>
                                <Fields>
                                    <ext:RecordField Name="kod" Type="String" />
                                    <ext:RecordField Name="ad" Type="String" />
                                </Fields>
                            </ext:JsonReader>
                        </Reader>
                    </ext:Store>
                </Store>
            </ext:ComboBox>
            <ext:Label ID="Label1" runat="server" HideLabel="true" Text="Birinci sütununda anahtar alanda seçtiğiniz veriler, ikinci sütunda ise yüklenecek veriler olan excel dosyasını seçiniz." />
            <ext:FileUploadField runat="server" ID="fuDosya" FieldLabel="Dosya" ButtonOnly="true" ButtonText="Dosya Seç">
                <DirectEvents>
                    <FileSelected OnEvent="fuDosya_Selected">
                        <EventMask ShowMask="true" Msg="Dosya yükleniyor..." />
                        <ExtraParams>
                            <ext:Parameter Name="param" Mode="Raw" Value="Ext1.util.JSON.encode(#{grdListe}.getRowsValues())" />
                        </ExtraParams>
                    </FileSelected>
                </DirectEvents>
            </ext:FileUploadField>
        </Items>
    </ext:Window>
    </form>
</body>
</html>
