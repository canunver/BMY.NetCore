﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Bilgi Sınıfı
    /// </summary>
    public partial class PersonelAtamaSorgu : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Request.QueryString["menuYok"] + "" != "")
            //    tabPanelAna.Margins = "0 0 0 0";

            //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
            //if (!TNS.IKY.Yetki.YetkiVarMiOkumaya(kullanan))
            //{
            //    personelTCKimlikNo = kullanan.mernis;
            //}

            //SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                hdnYetkiliBirim.Text = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");

                //if (GenelIslemlerIstemci.OrgSemaPersonelKullaniyorMu())
                trpBirim.Listeners.BeforeLoad.Fn = "OrgBirimDoldur";
                Genel.UnvanDoldur(servisIKY, this, storeUnvan);
                Genel.KadroDereceDoldur(storeKadroDerece);
                Genel.PersonelTurDoldur(cmbPersonelTip, personelTipStore, null);
                Genel.SozlukDoldur(ddlSinif, sinifStore, OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.KADROSINIF, 0).ToString().PadLeft(2, '0'), false);
                //Genel.SozlukDoldur(ddlAtamaSekli, atamaSekliStore, OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.ATAMASEKLI, 0).ToString().PadLeft(2, '0'));
                //Genel.SozlukDoldur(ddlAtamaTuru, atamaTuruStore, OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.ATAMATURU, 0).ToString().PadLeft(2, '0'));
                //Genel.SozlukDoldur(ddlHareketDurumu, hareketDurumuStore, OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.HAREKETDURUMU, 0).ToString().PadLeft(2, '0'));
                Genel.KadroDurumuDoldur(ddlHareketDurumu, hareketDurumuStore, false);
                Genel.HizmetSebebiDoldur(ddlAtamaSekli, atamaSekliStore, ENUMHizmetSebebiNevi.TANIMSIZ, true);
            }
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected void PersonelAtamaListele(object sender, DirectEventArgs e)
        {
            try
            {
                TNS.IKY.PersonelKadro p = new TNS.IKY.PersonelKadro();
                p.sinifi = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["sinif"].Value, 0);
                //p.atama.atamaTuru = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["atamaTuru"].Value,0);
                p.personelTCKimlikNo = pgFiltre.Source["tcKimlikNo"].Value.ToString();
                p.personelTip = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["personelTur"].Value, 0);
                p.hizmetSebebiKod = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["atamaSekli"].Value, 0);
                p.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["birim"].Value, 0);
                p.unvan = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["unvan"].Value, 0);
                p.kadroDerece = OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["kadroDerece"].Value, 0);
                p.kadroDurum = (ENUMKadroDurumu)OrtakFonksiyonlar.ConvertToInt(pgFiltre.Source["hareketDurumu"].Value, 0);
                //p.eskiHizmetFlag = 1;

                ObjectArray liste = servisIKY.PersonelKadroListele(kullanan, p, false);

                if (!liste.sonuc.islemSonuc)
                    throw new Exception(liste.sonuc.hataStr);
                if (liste == null || liste.ObjeSayisi <= 0)
                {
                    GenelIslemler.HataYaz(this, Resources.InsanKaynaklari.FRMKAD016);

                    storeListe.DataSource = new List<object>();
                    storeListe.DataBind();
                    return;
                }

                List<object> list = new List<object>();
                foreach (TNS.IKY.PersonelKadro k in liste.objeler)
                {
                    object degerler = new
                    {
                        KADROKOD = k.kod,
                        PERSONELKOD = k.personelKod,
                        ADSOYAD = k.personelAdSoyad,
                        TCKIMLIKNO = k.personelTCKimlikNo,
                        BIRIM = k.birimAd,
                        SINIF = k.sinifAd,
                        UNVAN = k.unvanAd,
                        KADRODERECE = k.kadroDerece,
                        ATAMATARIHI = k.atamaTarihi.ToString(),
                        ATAMASEKLI = k.hizmetSebebiAd,
                        ATAMANEDENI = k.hizmetSebebi,
                        PERSONELTUR = k.personelTipAd,
                        HAREKETDURUMU = k.kadroDurum,
                        HAREKETDURUMUAD = k.kadroDurumAd,
                        ESKIKADROKOD = k.eskiKod
                    };
                    list.Add(degerler);
                }

                storeListe.DataSource = list;
                storeListe.DataBind();
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
            }
        }

        //Kalkacak
        protected void NodeLoad(object sender, NodeLoadEventArgs e)
        {
            Genel.BirimDoldur(e);
        }

        ///// <summary>
        ///// Rows the select.
        ///// </summary>
        ///// <param name="sender">The sender.</param>
        ///// <param name="e">The <see cref="Ext1.Net.DirectEventArgs"/> instance containing the event data.</param>
        //protected void SatirSecildi(object sender, DirectEventArgs e)
        //{
        //    int atamaKod = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["ATAMAKOD"], 0);
        //    int personelKod = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["PERSONELKOD"], 0);
        //    X.AddScript("parent.BilgiListeleAc(" + atamaKod + "," + personelKod +" );");
        //    X.AddScript("parent.hidePopWin();");
        //}
    }
}