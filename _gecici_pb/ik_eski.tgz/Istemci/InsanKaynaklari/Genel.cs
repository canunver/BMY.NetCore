﻿using System;
using System.Collections;
using System.Drawing;
using System.Web.UI.WebControls;
using OrtakClass;
using TNS;
using TNS.KPM;
using TNS.KYM;
using TNS.IKY;
using TNS.ORG;
using TNS.UZY;
using System.Web.UI;
using Ext1.Net;
using System.Collections.Generic;
//using CrystalDecisions.Shared;
//using CrystalDecisions.CrystalReports.Engine;
using System.Globalization;

namespace Ext1.Net
{
    public class ExtIzinDonem : Ext1.Net.TextField
    {
        private Ext1.Net.Spinner sp = new Spinner();

        public int Yil
        {
            get
            {
                return OrtakFonksiyonlar.ConvertToInt(this.Attributes["Yil"], 1);
            }
            set
            {
                this.Attributes.Add("Yil", value.ToString());
                sp.Value = value;
            }
        }

        public int YilMaks
        {
            get
            {
                return sp.MaxValue;
            }
            set
            {
                sp.MaxValue = value;
            }
        }

        public int YilMin
        {
            get
            {
                return sp.MinValue;
            }
            set
            {
                sp.MinValue = value;
            }
        }

        public ExtIzinDonem()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            sp.ID = SpinnerID(this.ClientID);
            sp.Listeners.Spin.Handler = "Ext1.net.DirectMethod.request('IzinDonemBul', {url:'../InsanKaynaklari/TanimIzinTur.aspx', specifier:'static', params:{yil:this.value}, success:function(r){\r\n" + this.ClientID + ".yil=" + sp.ID + ".value;" + this.ClientID + ".setValue(r);" + this.ClientID + ".fireEvent('change');\r\n}});";
            this.Plugins.Add(sp);
            this.ReadOnly = true;
        }

        private string SpinnerID(string dllId)
        {
            return dllId + "_spin";
        }
    }
}

namespace InsanKaynaklari
{
    /// <summary>
    /// Ortak fonksiyonların bulunduğu sınıf
    /// </summary>
    public class Genel
    {
        static IUZYServis servisUZY = TNS.UZY.Arac.Tanimla();
        static IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// EXT.combo box empty text alanı dolu ise submit edildiğinde listeden bir değer seçilmez ise empty text value değer olarak dönüyor.
        /// </summary>
        /// <param name="cmb">Combobox kontrolü</param>
        /// <returns></returns>
        public static string ComboDegerDondur(Ext1.Net.ComboBox cmb)
        {
            string deger = "";

            if (cmb.SelectedItem.Value != "")
                deger = OrtakFonksiyonlar.ConvertToStr(cmb.SelectedItem.Value);

            return deger;
        }

        /// <summary>
        /// Kullanıcı Yönetim Servisine bağlanarak, Veri tabanı, Kullanıcı adı ve Şifre bilgilerini alan fonksiyon
        /// </summary>
        /// <param name="kullanan">Kullanıcı bilgisini tutan, Kullanici tipinde sınıf</param>
        /// <param name="userID">Kullanıcı adı bilgisini tutan, String tipinde sınıf</param>
        /// <param name="password">Şifre bilgisini tutan, String tipinde sınıf</param>
        /// <param name="dataSource">Veri kaynağı bilgisini tutan, String tipinde sınıf</param>
        public static void VeriTabaniBaglantiBilgileriniAl(Kullanici kullanan, ref string userID, ref string password, ref string dataSource, ref string veriTabani)
        {
            TNS.KYM.IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();

            string[] degerler = servisKYM.VeriErisimDegeriVer(kullanan, "BaglantiSatiriIKY").Split(';');

            for (int i = 0; i < degerler.Length; i++)
            {
                degerler[i] = degerler[i].Trim();

                if (degerler[i].ToUpper().StartsWith("DATA SOURCE="))
                {
                    int yer = degerler[i].IndexOf("=");
                    dataSource = degerler[i].Substring(yer + 1).Trim();
                }
                else if (degerler[i].ToUpper().IndexOf("USER") > -1)
                {
                    int yer = degerler[i].IndexOf("=");
                    userID = degerler[i].Substring(yer + 1).Trim();
                }
                else if (degerler[i].ToUpper().StartsWith("PASSWORD="))
                {
                    int yer = degerler[i].IndexOf("=");
                    password = degerler[i].Substring(yer + 1).Trim();
                }
                else if (degerler[i].ToUpper().IndexOf("CATALOG") > -1)
                {
                    int yer = degerler[i].IndexOf("=");
                    veriTabani = degerler[i].Substring(yer + 1).Trim();
                }
            }
        }

        //public static void CrystalReportKapat(ReportDocument rd)
        //{
        //    if (rd == null)
        //        return;

        //    if (rd.Database != null)
        //    {
        //        if (rd.Database.Tables != null && rd.Database.Tables.Count > 0)
        //            foreach (CrystalDecisions.CrystalReports.Engine.Table table in rd.Database.Tables)
        //                table.Dispose();
        //        rd.Database.Dispose();
        //    }
        //    if (rd.DataDefinition != null)
        //        rd.DataDefinition.Dispose();
        //    if (rd.DataSourceConnections != null)
        //        rd.DataSourceConnections.Clear();
        //    rd.Close();
        //    rd.Dispose();
        //    GC.Collect();
        //}

        ///// <summary>
        ///// Personel Ad ve Soyad bilgilerini MERNİS sisteminden getiren fonksiyon
        ///// </summary>
        ///// <param name="tcKimlikNo">TC kimlik no.</param>
        ///// <returns></returns>
        //public static string AdSoyadGetir(Kullanici kullanan, string tcKimlikNo)
        //{
        //    KullaniciVAN kVAN = GenelIslemler.MernisOku(kullanan, tcKimlikNo);

        //    if (kVAN.sonuc.islemSonuc && !string.IsNullOrEmpty(kVAN.kullanici.ad + kVAN.kullanici.soyad))
        //        return kVAN.kullanici.ad + " " + kVAN.kullanici.soyad;
        //    else
        //        return null;
        //}

        /// <summary>
        /// Personel Adres bilgilerini MERNİS sisteminden getiren fonksiyon
        /// </summary>
        /// <param name="kullanan">Kullanan.</param>
        /// <param name="tcKimlikNo">TC kimlik no.</param>
        /// <returns></returns>
        public static TNS.IKY.PersonelAdres AdresBilgisiGetir(Kullanici kullanan, string tcKimlikNo)
        {
            IKPMServis servisKPM = TNS.KPM.Arac.Tanimla();

            TNS.KPM.Istek istek = new TNS.KPM.Istek();
            istek.istekTur = ((int)ENUMIstekTur.IKAMETGAH);
            istek.tcKimlikNo = tcKimlikNo;
            istek.adSoyad = kullanan.ADSOYAD; // AdSoyadGetir(kullanan, istek.tcKimlikNo);//Nufus kaydı için isim göndermek gerekiyor.
            istek.islemYapan = kullanan.kullaniciKodu;
            istek.islemTarih.Yaz(DateTime.Now);

            ObjectArray ikametgahList = servisKPM.IkametgahRaporla(kullanan, istek);

            TNS.KPM.Kisi ikametgah = new TNS.KPM.Kisi();
            TNS.IKY.PersonelAdres p = new TNS.IKY.PersonelAdres();

            if (!ikametgahList.sonuc.islemSonuc)
                throw new Exception(ikametgahList.sonuc.hataStr);

            if (ikametgahList.ObjeSayisi > 0)
                ikametgah = (TNS.KPM.Kisi)ikametgahList.objeler[0];
            else
                throw new Exception(ikametgahList.sonuc.bilgiStr);

            p.mahalle = ikametgah.adres.mahalle;
            p.caddeSokak = ikametgah.adres.sokak;
            p.binaDaireNo = ikametgah.adres.numara;
            p.ilKod = ikametgah.adres.il;
            p.ilceKod = ikametgah.adres.ilce;

            string adres = "";
            if (ikametgah.adres.koy.Trim() != "")
                adres += ikametgah.adres.koy + " ";
            if (ikametgah.adres.bucak.Trim() != "")
                adres += ikametgah.adres.bucak + " ";
            if (ikametgah.adres.mahalle.Trim() != "")
                adres += ikametgah.adres.mahalle + " ";
            if (ikametgah.adres.sokak.Trim() != "")
                adres += ikametgah.adres.sokak + " ";
            if (ikametgah.adres.numara.Trim() != "")
                adres += "No: " + ikametgah.adres.numara + " ";
            if (ikametgah.adres.ilce.Trim() != "")
                adres += ikametgah.adres.ilce + " / ";
            if (ikametgah.adres.il.Trim() != "")
                adres += ikametgah.adres.il;

            p.adres = adres;

            return p;
        }

        /// <summary>
        /// Personel Kimlik bilgilerini MERNİS sisteminden getiren fonksiyon
        /// </summary>
        /// <param name="kullanan">Kullanan.</param>
        /// <param name="tcKimlikNo">TC kimlik no.</param>
        /// <returns></returns>
        public static TNS.IKY.Personel KimlikBilgisiGetir(Kullanici kullanan, string tcKimlikNo)
        {
            IKPMServis servisKPM = TNS.KPM.Arac.Tanimla();

            TNS.KPM.Istek istek = new TNS.KPM.Istek();
            istek.istekTur = ((int)ENUMIstekTur.NUFUSCUZDANORNEK);
            istek.tcKimlikNo = tcKimlikNo;
            istek.adSoyad = kullanan.ADSOYAD; //AdSoyadGetir(kullanan, istek.tcKimlikNo);//Nufus kaydı için isim göndermek gerekiyor.
            istek.islemYapan = kullanan.kullaniciKodu;
            istek.islemTarih.Yaz(DateTime.Now);
            istek.entegrasyon = true;

            ObjectArray nufusList = servisKPM.NufusKayitOrnekRaporla(kullanan, istek);

            TNS.KPM.Kisi nufusOrnek = new TNS.KPM.Kisi();
            TNS.IKY.Personel p = new TNS.IKY.Personel();

            if (!nufusList.sonuc.islemSonuc)
                throw new Exception("Nüfus sorgusu hata ile sonuçlandı: " + nufusList.sonuc.hataStr);

            if (nufusList.ObjeSayisi > 0)
                nufusOrnek = (TNS.KPM.Kisi)nufusList.objeler[0];
            else
                throw new Exception("Nüfus Sorgusu Boş Kayıt Döndürdü");

            p.tcKimlikNo = nufusOrnek.tcKimlikNo;
            p.nufus.cuzdanSeriNo = nufusOrnek.nufusCuzdani.nufusCuzdanSeri;
            p.nufus.cuzdanKayitNo = nufusOrnek.nufusCuzdani.kayitNo;
            p.nufus.cuzdanVerilisTarihi = new TNSDateTime(nufusOrnek.nufusCuzdani.verilisTarihi.ToString());
            p.nufus.cuzdanVerilisNedeni = nufusOrnek.nufusCuzdani.verilisNedeniAciklama;
            p.nufus.cuzdanVerildigiYer = nufusOrnek.nufusCuzdani.verildigiYer;
            p.nufus.nufusMahalleKoy = nufusOrnek.kayitliOlduguYer.mahalleKoy;
            p.nufus.nufusCiltNo = nufusOrnek.kayitliOlduguYer.ciltNo.ToString();
            p.nufus.nufusAileSiraNo = nufusOrnek.kayitliOlduguYer.aileSiraNo.ToString();
            p.nufus.nufusSiraNo = nufusOrnek.kayitliOlduguYer.bireySiraNo.ToString();

            p.ad = nufusOrnek.ad;
            p.soyad = nufusOrnek.soyad;
            p.nufus.anaAd = nufusOrnek.anaAd;
            p.nufus.babaAd = nufusOrnek.babaAd;
            p.nufus.dogumYeri = nufusOrnek.dogumYeri;
            p.nufus.dogumTarihi = new TNSDateTime(nufusOrnek.dogumTarihi.ToString());
            p.nufus.dini = nufusOrnek.din.ToString();
            p.nufus.ilkSoyad = nufusOrnek.kizlikSoyad;
            p.nufus.ilkSoyad = nufusOrnek.kizlikSoyad;

            p.nufus.kanGrubu = nufusOrnek.kanGrubu;

            p.nufus.cinsiyeti = nufusOrnek.cinsiyet == 2 ? ENUMCINSIYET.KADIN : ENUMCINSIYET.ERKEK;
            p.nufus.medeniHali = nufusOrnek.medeniHal;
            //p.nufus.kanGrubu = nufusOrnek.kanGrubu;

            p.nufus.nufusIlKod = nufusOrnek.kayitliOlduguYer.ilce.il.kod.ToString();
            p.nufus.nufusIlceKod = nufusOrnek.kayitliOlduguYer.ilce.kod.ToString();

            return p;
        }

        public static void CinsiyetDoldur(ComboBox ddlCinsiyet, Store cinsiyetStore)
        {
            ddlCinsiyet.Items.Clear();
            cinsiyetStore.DataSource = TNS.IKY.Arac.CinsiyetListe;
            cinsiyetStore.DataBind();
        }

        public static void TahsisTipDoldur(ComboBox ddl, Store store)
        {
            ddl.Items.Clear();
            store.InsertRecord(0, new { KOD = 0, AD = "" });
            store.DataSource = TNS.IKY.Arac.TahsisTipListe;
            store.DataBind();
        }

        public static void KomisyonTipDoldur(ComboBox ddl, Store store)
        {
            ddl.Items.Clear();
            store.InsertRecord(0, new { KOD = 0, AD = "" });
            store.DataSource = TNS.IKY.Arac.KomisyonTipListe;
            store.DataBind();
        }

        public static void ImzaTurDoldur(ComboBox ddl, Store store)
        {
            ddl.Items.Clear();
            store.InsertRecord(0, new { KOD = 0, AD = "" });
            store.DataSource = TNS.IKY.Arac.ImzaTurListe;
            store.DataBind();
        }

        public static ObjectArray unvanlar = null;

        /// <summary>
        /// Unvans the doldur.
        /// </summary>
        /// <param name="servisIKY">The servis PER.</param>
        /// <param name="p">The p.</param>
        /// <param name="storeUnvan">The store unvan.</param>
        /// <param name="bosEkle">if set to <c>true</c> [bos ekle].</param>
        public static void UnvanDoldur(IIKYServis servisIKY, Page p, Store storeUnvan)
        {
            if (unvanlar == null)
            {
                unvanlar = servisIKY.UnvanListele(new Unvan());
                if (!unvanlar.sonuc.islemSonuc)
                {
                    GenelIslemler.HataYaz(p, unvanlar.sonuc.hataStr);
                    return;
                }
                if (unvanlar.objeler.Count <= 0)
                {
                    GenelIslemler.BilgiYaz(p, unvanlar.sonuc.bilgiStr);
                    return;
                }

                unvanlar.objeler.Insert(0, new Unvan { UnvanKod = 0, ad = string.Empty, sinifAd = string.Empty });
            }
            storeUnvan.DataSource = unvanlar.objeler;
            storeUnvan.DataBind();
        }

        public static void UnvanDoldur(ComboBox ddlUnvan, Store unvanStore)
        {
            ObjectArray dler = servisIKY.UnvanListele(new Unvan { aktif = true });

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    ddlUnvan.Items.Clear();
                    unvanStore.DataSource = dler.objeler;
                    unvanStore.DataBind();
                }
            }
        }

        public static void HizmetSebebiDoldur(ComboBox ddl, Store store, ENUMHizmetSebebiNevi sebepler, bool tipKod)
        {
            ObjectArray dler = servisIKY.HizmetSebebiListele(sebepler);

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    ArrayList al = new ArrayList();
                    ddl.Items.Clear();
                    al.Add(new StrKodStrAd("", ""));
                    foreach (HizmetSebebi d in dler.objeler)
                        al.Add(new StrKodStrAd(tipKod ? d.tipKod : d.kod.ToString(), d.sebepAdi));

                    store.DataSource = al;
                    store.DataBind();
                }
            }
        }

        public static void EskiHizmetTipiDoldur(ComboBox ddl, Store store)
        {
            ObjectArray dler = servisIKY.EskiHizmetTipiListele();

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    ArrayList al = new ArrayList();
                    ddl.Items.Clear();
                    al.Add(new object[] { 0, "" });
                    foreach (EskiHizmetTipi d in dler.objeler)
                        al.Add(new object[] { d.kod, d.hizmetAdi });

                    store.DataSource = (object[])al.ToArray(typeof(object[]));
                    store.DataBind();
                }
            }
        }

        public static TNSCollection IzinTipDondur(bool sifresizGiris)
        {
            if (TNS.IKY.Arac.izinTipListesi == null)
            {
                TNS.IKY.Arac.izinTipListesi = servisIKY.IzinTurListele(new IzinTur());
            }
            TNSCollection t = new TNSCollection();
            foreach (IzinTur item in TNS.IKY.Arac.izinTipListesi.objeler)
            {
                if (!sifresizGiris || item.gorulebilirlik == 1)
                {
                    t.Add(item);
                }
            }
            return t;
        }


        /// <summary>
        /// Kadro işlemleri sayfalarında işlem tipi kontrolünü sabit verileri yükleyen yordam.
        /// </summary>
        /// <param name="storeIslemTur">Store ad.</param>
        /// <param name="bosEkle">Değer <c>true</c> ise boş satır ekler.</param>
        public static void KadroIslemTurDoldur(Store storeIslemTur, bool bosEkle)
        {
            List<object> list = new List<object>();
            if (bosEkle)
                list.Add(new { IslemKod = 0, IslemAd = string.Empty });
            foreach (EnumKadroKontenjanIslemTur tur in System.Enum.GetValues(typeof(EnumKadroKontenjanIslemTur)))
            {
                object obje = new
                {
                    IslemKod = (int)tur,
                    IslemAd = Resources.InsanKaynaklari.ResourceManager.GetString("FRMKAD010_" + (int)tur)
                };
                list.Add(obje);
            }
            storeIslemTur.DataSource = list;
            storeIslemTur.DataBind();
        }

        /// <summary>
        /// Ekrandan alınan birim değeri Organizsyon kodu ve muhasebe birim olabilir. Bu değerleri Personel sınıfındaki alanlara atayan yordam
        /// </summary>
        /// <param name="d">Personel sınıfı</param>
        /// <param name="birim">Birim kodu</param>
        public static void BirimDegerleriniAyarla(ref TNS.IKY.Personel d, string birim)
        {
            //if (GenelIslemlerIstemci.OrgSemaPersonelKullaniyorMu())
            //{
            //    d.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(birim, 0);
            //    if (d.organizasyonKodu > 0)
            //    {
            //        OrganizasyonBirim orgBirim = TNS.ORG.Arac.OrgBirimBul(d.organizasyonKodu);
            //        if (orgBirim != null)
            //        {
            //            d.muhasebeKodu = OrtakFonksiyonlar.ConvertToInt(orgBirim.muhasebekodu, 0);
            //            d.birimKodu = orgBirim.muhasebebirim;
            //            d.kurum = orgBirim.kurumsalkod;
            //        }
            //    }
            //}
            //else
            //{
            //    string[] parcaliKod = birim.ToString().Split('-');
            //    d.kurum = parcaliKod[0];
            //    d.muhasebeKodu = OrtakFonksiyonlar.ConvertToInt(parcaliKod[1], 0);
            //    d.birimKodu = parcaliKod[2];
            //}
        }

        /// <summary>
        /// Sozluk bilgisini listeyen fonksiyon.
        /// </summary>
        /// <returns></returns>
        public static object[] SozlukYukle(Sozluk sozluk)
        {
            ObjectArray sozluktmp = new ObjectArray();
            bool ozel = sozluk.ozel;
            sozluktmp = servisIKY.SozlukListele(sozluk);
            string kayitAd = "";
            ArrayList al = new ArrayList();
            al.Add(new object[] { 0, "" });
            foreach (Sozluk s in sozluktmp.objeler)
            {
                kayitAd = "";
                for (int i = 2; i < s.seviye; i++)
                    kayitAd += "- ";

                kayitAd += s.ad;
                s.ozel = ozel;
                if (s.ozel)
                    al.Add(new object[] { s.kod + ":" + s.kayitKod, kayitAd });
                else
                    al.Add(new object[] { s.kod, kayitAd });
            }

            return (object[])al.ToArray(typeof(object[]));
        }

        public static void SozlukDoldur(ComboBox ddl, Store store, string kayitKod, bool ozel)
        {
            ddl.Items.Clear();
            store.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = kayitKod, seviye = 2, ozel = ozel });
            store.DataBind();
        }

        public static void KadroDereceDoldur(Store storeKadroDerece)
        {
            List<object> dereceler = new List<object>();

            dereceler.Add(new { DereceKod = 0, DereceAd = string.Empty });
            for (int i = 1; i <= 15; i++)
                dereceler.Add(new { DereceKod = i, DereceAd = i.ToString() });

            storeKadroDerece.DataSource = dereceler;
            storeKadroDerece.DataBind();
        }

        internal static void PersonelTipGrupDoldur(MultiCombo ddlPersonelTipGrup, Store stoPersonelTipGrup)
        {
            if (ddlPersonelTipGrup != null)
                ddlPersonelTipGrup.Items.Clear();
            stoPersonelTipGrup.DataSource = TNS.IKY.Arac.PersonelTipGrupListe;
            stoPersonelTipGrup.DataBind();
        }

        public static TNSCollection PersonelTurDondur(string[] tipGruplar)
        {
            if (tipGruplar == null || tipGruplar.Length == 0)
                return TNS.IKY.Arac.PersonelTipListe;
            else
            {
                PersonelTipi pt = new PersonelTipi();
                pt.tipGruplar = tipGruplar;
                return TNS.IKY.Arac.Tanimla().ListelePersonelTip(null, pt).objeler;
            }
        }

        public static void PersonelTurDoldur(ComboBox cmbPersonelTur, Store personelTurStore, string[] tipGruplar)
        {
            if (cmbPersonelTur != null)
                cmbPersonelTur.Items.Clear();

            if (tipGruplar == null || tipGruplar.Length == 0)
                personelTurStore.DataSource = TNS.IKY.Arac.PersonelTipListe;
            else
            {
                PersonelTipi pt = new PersonelTipi();
                pt.tipGruplar = tipGruplar;
                personelTurStore.DataSource = TNS.IKY.Arac.Tanimla().ListelePersonelTip(null, pt).objeler;
            }
            personelTurStore.DataBind();
        }

        public static void LojmanSiteDoldur(Kullanici kullanan, ComboBox cmbSite, Store siteStore)
        {
            if (cmbSite != null)
                cmbSite.Items.Clear();

            siteStore.DataSource = servisIKY.LojmanSiteListele(kullanan, new LojmanSite()).objeler;
            siteStore.DataBind();
        }

        public static void LojmanSiteBlokDoldur(Kullanici kullanan, ComboBox cmb, Store store, int siteKod)
        {
            if (cmb != null)
                cmb.Items.Clear();

            store.DataSource = servisIKY.LojmanSiteBlokListele(kullanan, new LojmanSiteBlok { siteKod = siteKod }).objeler;
            store.DataBind();
        }

        public static void LojmanSiteBlokDaireDoldur(Kullanici kullanan, ComboBox cmb, Store store, int blokKod)
        {
            if (cmb != null)
                cmb.Items.Clear();

            store.DataSource = servisIKY.LojmanSiteBlokDaireListele(kullanan, new LojmanSiteBlokDaire { blokKod = blokKod }).objeler;
            store.DataBind();
        }

        public static void BosDaireListesi(Kullanici kullanan, ComboBox cmb, Store store, int blokKod)
        {
            if (cmb != null)
                cmb.Items.Clear();

            store.DataSource = servisIKY.BosDaireListesi(kullanan, blokKod).objeler;
            store.DataBind();
        }

        public static void SozlukGiderTuruDoldur(Kullanici kullanan, ComboBox cmb, Store Store)
        {
            if (cmb != null)
                cmb.Items.Clear();

            Store.DataSource = servisIKY.SozlukGiderListele(kullanan, new SozlukGider()).objeler;
            Store.DataBind();
        }

        public static void LojmanTurleriniDoldur(Kullanici kullanan, ComboBox cmb, Store store)
        {
            if (cmb != null)
                cmb.Items.Clear();

            store.DataSource = servisIKY.LojmanTurleriniListele(kullanan, new LojmanTuru()).objeler;
            store.DataBind();
            store.InsertRecord(0, new LojmanTuru { kod = 0, etiket = "" });
            //store.AddRecord(new LojmanTuru { kod = 0, etiket="" });
        }

        public static void SinifDoldur(ComboBox ddlSinif, Store sinifStore)
        {
            ddlSinif.Items.Clear();
            sinifStore.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.KADROSINIF, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            sinifStore.DataBind();
        }

        public static void YemekhaneDoldur(DropDownField cmbYerleske, ComboBox ddlYerleske, Store yerleskeStore, Kullanici kullanan)
        {
            //if (ddlYerleske != null)
            //{
            //    ddlYerleske.Items.Clear();
            //    yerleskeStore.InsertRecord(0, "");
            //}

            yerleskeStore.DataSource = new TNSCollection();
            //yerleskeStore.DataSource = servisIKY.PersonelYerleskeListele(kullanan, new IKYYerleske { yemekhaneVarmi = 1 }).objeler;
            yerleskeStore.DataBind();
        }

        public static void KadroDurumuDoldur(ComboBox ddl, Store store, bool ozel)
        {
            ddl.Items.Clear();
            ArrayList al = new ArrayList();
            al.Add(new Sozluk { kod = (int)ENUMKadroDurumu.YENI, ad = TNS.IKY.Arac.KayitDurumuAdOl(ENUMKadroDurumu.YENI) });
            al.Add(new Sozluk { kod = (int)ENUMKadroDurumu.AKTIFKAYIT, ad = TNS.IKY.Arac.KayitDurumuAdOl(ENUMKadroDurumu.AKTIFKAYIT) });
            al.Add(new Sozluk { kod = (int)ENUMKadroDurumu.AKTIFKAPANIYOR, ad = TNS.IKY.Arac.KayitDurumuAdOl(ENUMKadroDurumu.AKTIFKAPANIYOR) });
            al.Add(new Sozluk { kod = (int)ENUMKadroDurumu.AKTIFKAPANDI, ad = TNS.IKY.Arac.KayitDurumuAdOl(ENUMKadroDurumu.AKTIFKAPANDI) });
            al.Add(new Sozluk { kod = (int)ENUMKadroDurumu.AYRILDI, ad = TNS.IKY.Arac.KayitDurumuAdOl(ENUMKadroDurumu.AYRILDI) });
            al.Add(new Sozluk { kod = (int)ENUMKadroDurumu.REDDEDILDI, ad = TNS.IKY.Arac.KayitDurumuAdOl(ENUMKadroDurumu.REDDEDILDI) });
            store.DataSource = al;
            store.DataBind();
        }

        public static void YakinlikDerecesiDoldur(ComboBox ddl, Store store)
        {
            ddl.Items.Clear();
            store.DataSource = TNS.IKY.Arac.YakinlikListe;
            store.DataBind();
        }

        public static void AyrilmaNedeniDoldur(ComboBox ddl, Store store)
        {
            ddl.Items.Clear();
            store.DataSource = Genel.SozlukYukle(new Sozluk { kayitKod = OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.AYRILMANEDENI, 0).ToString().PadLeft(2, '0'), seviye = 2 }); ;
            store.DataBind();
        }

        public static int SozlukKoduGetir(string kayitKod)
        {
            ObjectArray list = servisIKY.SozlukListele(new Sozluk { kayitKod = kayitKod, birebir = true });
            foreach (Sozluk s in list.objeler)
                return s.kod;
            return 0;
        }

        public static Sozluk SozlukBilgiGetir(int sozlukKod)
        {
            if (sozlukKod == 0)
                return new Sozluk();
            var list = servisIKY.SozlukListele(new Sozluk { kod = sozlukKod });
            foreach (Sozluk s in list.objeler)
                return s;
            return new Sozluk();
        }

        /// <summary>
        /// DateField alanı boş bırakıldığında '' olarak değil 01.01.0001 olarak değer döndürdüğü için kayıt sırasında hata veriyor.
        /// 
        /// </summary>
        /// <param name="kontrol">Ext Tarih alanı.</param>
        /// <returns>TNSDateTime tipinde değer döndürür</returns>
        public static TNSDateTime TarihAlaniDegerVer(Ext1.Net.DateField kontrol)
        {
            TNSDateTime tarih = new TNSDateTime();

            if (!kontrol.IsEmpty)
                tarih = new TNSDateTime(kontrol.Text.Trim());

            return tarih;
        }

        /// <summary>
        /// Resim dosyalarının istenilen ölçekte boyutlarndırılması işlemini yapan metod
        /// </summary>
        /// <param name="orjinalDosya">Resim dosyasının adresi (http veya klasör yolu)</param>
        /// <param name="boyut">Ölçeklendirmede kullanılacak büyüklük</param>
        /// <param name="kayitDosya">Ölçeklendirme işleminden sonra dosyanın kayıt edileceği klasör yolu</param>
        public static void ResmiKucult(string orjinalDosya, int boyut, string kayitDosya)
        {
            if (string.IsNullOrEmpty(orjinalDosya))
                return;

            if (System.IO.File.Exists(kayitDosya))
                return;

            Bitmap orjinalResim = new Bitmap(1, 1);

            orjinalResim = new Bitmap(orjinalDosya);

            int dosyaGenislik = 0;
            int dosyaYukseklik = 0;

            if (orjinalResim.Width > orjinalResim.Height)
            {
                dosyaGenislik = boyut;
                dosyaYukseklik = orjinalResim.Height * boyut / orjinalResim.Width;
            }
            else
            {
                dosyaGenislik = orjinalResim.Width * boyut / orjinalResim.Height;
                dosyaYukseklik = boyut;
            }

            //**
            //Bitmap kucukResim = new Bitmap(dosyaGenislik, dosyaYukseklik);
            //using (Graphics graphics = Graphics.FromImage(kucukResim))
            //{
            //    graphics.CompositingQuality = CompositingQuality.HighSpeed;
            //    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            //    graphics.CompositingMode = CompositingMode.SourceCopy;
            //    graphics.DrawImage(orjinalResim, 0, 0, dosyaGenislik, dosyaYukseklik);
            //}
            //try
            //{
            //    Directory.CreateDirectory(Path.GetDirectoryName(kayitDosya));
            //    kucukResim.Save(kayitDosya);
            //}
            //catch { }
            //**

            //using (MemoryStream memoryStream = new MemoryStream())
            //{
            //   kucukResim.Save(memoryStream, ImageFormat.Jpeg);
            //memoryStream.WriteTo(Response.OutputStream);

            //}
        }

        /// <summary>
        ///  Verilen Mernis koduna sahip cağrafik yer bilgisinin kod değerini almak için
        /// </summary>
        /// <param name="mernisKod">The mernis kod.</param>
        /// <returns></returns>
        public static string CografyaKodunaCevir(string mernisKod)
        {
            return servisUZY.UzayDegeriStr(new Kullanici(), "COGRAFYAMERNIS", mernisKod, true);
        }

        public static PersonelBelgeler PersonelBelge()
        {
            PersonelBelgeler belge = new PersonelBelgeler();
            return belge;
        }

        public static string DegerAlStr(Newtonsoft.Json.Linq.JObject item, string fieldName)
        {
            try
            {
                return item.Value<string>(fieldName);
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static double DegerAlDbl(Newtonsoft.Json.Linq.JObject item, string fieldName)
        {
            try
            {
                return item.Value<double>(fieldName);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public static int DegerAlInt(Newtonsoft.Json.Linq.JObject item, string fieldName)
        {
            try
            {
                return item.Value<int>(fieldName);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public static TNSDateTime DegerAlDateTime(Newtonsoft.Json.Linq.JObject item, string fieldName)
        {
            try
            {
                DateTime dt = item.Value<DateTime>(fieldName);
                if (dt == DateTime.MinValue)
                    return null;
                return new TNSDateTime(dt);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static bool DegerAlBool(Newtonsoft.Json.Linq.JObject item, string fieldName)
        {
            try
            {
                return item.Value<bool>(fieldName);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tarihAlan"></param>
        /// <param name="pozitif"></param>
        public static void TarihAlanTemizle(ref Ext1.Net.DateField tarihAlan, bool pozitif)
        {
            tarihAlan.SetValue("01.01." + (DateTime.Now.Year + ((pozitif ? 1 : -1) * 300)).ToString("d4"));
            tarihAlan.Clear();
        }

        public static void BirimDoldur(NodeLoadEventArgs e)
        {
            TNS.ORG.IORGServis orgServis = TNS.ORG.Arac.Tanimla();
            ObjectArray obler = orgServis.OrganizasyonBirimListele(new OrganizasyonBirim(), false, false);
            //Ext1.Net.TreeNodeCollection nodes = new Ext1.Net.TreeNodeCollection();
            //if (!obler.sonuc.islemSonuc || obler.objeler.Count <= 0)
            //    return nodes.ToJson();
            foreach (OrganizasyonBirim d in obler.objeler)
            {
                AsyncTreeNode dal = new AsyncTreeNode(d.kod.ToString(), d.adi);
                if (d.altDalVar)
                    e.Nodes.Add(dal);
                else
                {
                    dal.Leaf = true;
                    e.Nodes.Add(dal);
                }
            }
        }

        public static void YilDoldur(ComboBox ddl, Store store, bool storeMu)
        {
            ddl.Items.Clear();
            if (!storeMu)
            {
                for (int i = 2000; i <= DateTime.Now.Year; i++)
                    ddl.Items.Add(new Ext1.Net.ListItem(i.ToString(), i.ToString()));
            }
            else
            {
                List<object> yillar = new List<object>();

                yillar.Add(new { KOD = 0, AD = string.Empty });
                for (int i = 2000; i <= DateTime.Now.Year + 5; i++)
                    yillar.Add(new { KOD = i, AD = i.ToString() });

                store.DataSource = yillar;
                store.DataBind();
            }
        }

        public static void AyDoldur(ComboBox ddl, Store store, bool storeMu)
        {
            ddl.Items.Clear();
            if (!storeMu)
            {
                for (int i = 1; i < 13; i++)
                    ddl.Items.Add(new Ext1.Net.ListItem(DateTimeFormatInfo.CurrentInfo.GetMonthName(i), i.ToString()));
            }
            else
            {
                List<object> aylar = new List<object>();

                aylar.Add(new { KOD = 0, AD = string.Empty });
                for (int i = 1; i < 13; i++)
                    aylar.Add(new { KOD = i, AD = DateTimeFormatInfo.CurrentInfo.GetMonthName(i) });

                store.DataSource = aylar;
                store.DataBind();
            }
        }

        public static void TerfiTipiDoldur(Store store)
        {
            store.DataSource = new object[]
                    {
                        new object[] { 0  ,""},
                        new object[] { 1 ,"Sadece K.H.A."},
                        new object[] { 2 ,"Sadece E.K.E.A."},
                        new object[] { 3 ,"K.H.A. ve E.K.E.A."}
                    };

            store.DataBind();
        }

        public static void DinamikListeDoldur(Store store)
        {
            List<object> listeler = new List<object>();
            for (int i = 0; i < PersonelRaporlari.dinamikKolonAdlar.Length; i++)
            {
                listeler.Add(new { Kod = i, Baslik = PersonelRaporlari.dinamikKolonAdlar[i], Siralama = 0 });
            }

            store.DataSource = listeler;

            store.DataBind();
        }

        public static void AktiflikDoldur(Store store)
        {
            store.DataSource = new object[]
                    {
                        new object[] {-1 ,"Tümü"},
                        new object[] { 0  ,"Pasif"},
                        new object[] { 1 ,"Aktif"}
                    };

            store.DataBind();
        }

        public static void TerfiDurumuDoldur(Store store)
        {
            store.DataSource = new object[]
                    {
                        new object[] { 0  ,""},
                        new object[] { 1 ,"Beklemede"},
                        new object[] { 2 ,"Onaylandı"},
                        new object[] { 3 ,"Reddedildi"}
                    };

            store.DataBind();
        }

        public static string TerfiTipAdiDondur(int tip)
        {
            string ad = "K.H.A. veya E.K.E.A.";
            if (tip == OrtakFonksiyonlar.ConvertToInt(ENUMTerfiTipi.EKEA, 0))
                ad = "E.K.E.A.";
            else if (tip == OrtakFonksiyonlar.ConvertToInt(ENUMTerfiTipi.KHA, 0))
                ad = "K.H.A.";
            else if (tip == OrtakFonksiyonlar.ConvertToInt(ENUMTerfiTipi.KHAEKEA, 0))
                ad = "K.H.A. ve E.K.E.A.";

            return ad;
        }

        public static string TerfiDurumAdiDondur(int tip)
        {
            string ad = "";
            if (tip == OrtakFonksiyonlar.ConvertToInt(ENUMTerfiDurumu.Beklemede, 0))
                ad = "Beklemede";
            else if (tip == OrtakFonksiyonlar.ConvertToInt(ENUMTerfiDurumu.Onay, 0))
                ad = "Onaylandı";
            else if (tip == OrtakFonksiyonlar.ConvertToInt(ENUMTerfiDurumu.Red, 0))
                ad = "Reddedildi";

            return ad;
        }

        internal static void AcikKadroDoldur(Store stoAtanacagiKadro, int orgKod, bool bosEkle, int pKod)
        {
            TNS.IKY.PersonelKadro pk = new TNS.IKY.PersonelKadro();
            pk.bosKadrolar = true;
            pk.kisiHaric = pKod;
            ObjectArray oa = servisIKY.DoluBosKadroListele(pk);
            if (bosEkle)
            {
                oa.objeler.Add(new TNS.IKY.KadroDoluBos());
            }
            stoAtanacagiKadro.DataSource = oa.objeler;
            stoAtanacagiKadro.DataBind();
        }

        internal static bool StringdeVarMi(int i_islemKod, string islemlerListe)
        {
            if (string.IsNullOrWhiteSpace(islemlerListe)) return false;
            string[] islerDizi = islemlerListe.Split(',', ';');
            for (int j = 0; j < islerDizi.Length; j++)
            {
                if (OrtakFonksiyonlar.ConvertToInt(islerDizi[j], -1) == i_islemKod)
                    return true;
            }
            return false;
        }
    }

}

