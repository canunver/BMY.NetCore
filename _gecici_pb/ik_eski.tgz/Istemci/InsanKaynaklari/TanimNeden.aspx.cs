﻿using System;
using System.Collections.Generic;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;

namespace InsanKaynaklari
{
    public partial class TanimNeden : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "İşe Başlama-Ayrılma Neden Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Listele(new Neden());
            }
        }

        public void Listele(Neden kriter)
        {
            ObjectArray dler = servisIKY.NedenListele(kriter);

            if (!dler.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, dler.sonuc.hataStr);
                return;
            }

            if (dler.objeler.Count <= 0)
                GenelIslemler.MesajKutusu(this, dler.sonuc.bilgiStr);

            List<object> tipler = new List<object>();
            foreach (TNS.IKY.Neden d in dler.objeler)
                tipler.Add(new
                {
                    KODU = d.kod,
                    ADI = d.ad,
                    BASLAMA = d.baslama,
                    AYRILMA = d.ayrilma
                });

            ListeStore.DataSource = tipler;
            ListeStore.DataBind();
        }

        protected void btnAra_Click(object sender, DirectEventArgs e)
        {
            Neden d = new Neden();
            d.kod = OrtakFonksiyonlar.ConvertToInt(txtNedenKodu.Text.Trim(), 0);
            d.ad = txtNedenAdi.Text.Trim();
            Listele(d);
        }

        protected void btnKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(txtNedenKodu.Text.Trim(), 0) == 0)
                hata = "Neden Kodu boş bırakılamaz" + "<br>";
            if (txtNedenAdi.Text.Trim() == "")
                hata += "Neden adı boş bırakılamaz" + "<br>";

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            Neden d = new Neden();
            d.kod = OrtakFonksiyonlar.ConvertToInt(txtNedenKodu.Text.Trim(), 0);
            d.ad = txtNedenAdi.Text;
            d.baslama = OrtakFonksiyonlar.ConvertToInt(chkBaslama.Checked, 0);
            d.ayrilma = OrtakFonksiyonlar.ConvertToInt(chkAyrilma.Checked, 0);

            Sonuc sonuc = servisIKY.NedenKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                Temizle();
                Listele(new Neden());
                GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            }
        }

        protected void btnSil_Click(object sender, DirectEventArgs e)
        {
            Neden d = new Neden();
            int kod = OrtakFonksiyonlar.ConvertToInt(txtNedenKodu.Text.Trim(), 0);

            if (kod > 0)
            {
                d.kod = kod;
                Sonuc sonuc = servisIKY.NedenSil(kullanan, d);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    Temizle();
                    Listele(new Neden());
                    GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
                }
            }
            else
                GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz ünvanı seçin.");
        }

        protected void btnTemizle_Click(object sender, DirectEventArgs e)
        {
            Listele(new Neden());
            Temizle();
        }

        void Temizle()
        {
            txtNedenKodu.Text = "";
            txtNedenAdi.Text = "";
            chkBaslama.Checked = false;
            chkAyrilma.Checked = false;
            grdListeSelectionModel.ClearSelections();
        }

        /// <summary>
        /// grdListe kontrolünün CellClick olayını işler
        /// </summary>
        /// <param name="sender">Olayın başlatılmasını sağlayan kontrol bilgilerini saklar</param>
        /// <param name="e">Olay değerlerini içerir</param>
        protected void SatirSecildi(object sender, DirectEventArgs e)
        {
            txtNedenKodu.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["NedenKodu"]);
            txtNedenAdi.Text = OrtakFonksiyonlar.ConvertToStr(e.ExtraParams["NedenAdi"]);
            chkBaslama.Checked = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["NedenBaslama"], 0) > 0;
            chkAyrilma.Checked = OrtakFonksiyonlar.ConvertToInt(e.ExtraParams["NedenAyrilma"], 0) > 0;
        }
    }
}
