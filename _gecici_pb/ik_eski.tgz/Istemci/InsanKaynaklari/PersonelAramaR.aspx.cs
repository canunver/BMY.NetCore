﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;
using System.Web.UI.WebControls;
using System.Web.Services;
using TNS.KYM;
using Borland.Delphi.Units;
using System.Web.UI.HtmlControls;

namespace InsanKaynaklari
{
    public partial class PersonelAramaR : istemciUzayi.GenelSayfa
    {
        //TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
        public class ListeSonuc
        {
            public string tablo = "";
            public int satir = 0;
            public int toplamKayit = 0;
            public bool yukleme = false;
        }

        public class PBilgiSonuc
        {
            public string resimUrl = "";
            public string unvan = "";
            public string isim = "";
            public string sonuc = "";
            public int bilgiKod = 0;
        }

        public static HtmlBaglamaSinifi[] htmlOzlukBaglama = 
        {
            new HtmlBaglamaSinifi("resimBase64", ""), 
            new HtmlBaglamaSinifi("adSoyad", ""),
            new HtmlBaglamaSinifi("tcKimlikNo", ""),
            new HtmlBaglamaSinifi("unvanAd", ""),
            new HtmlBaglamaSinifi("mailLink", ""),
            new HtmlBaglamaSinifi("birimAd", ""),
            new HtmlBaglamaSinifi("cepTelefon", ""),
            new HtmlBaglamaSinifi("isTelefon", ""),
            new HtmlBaglamaSinifi("kadroBaslangicTarihi", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("medeniDurumuAd", ""),
            new HtmlBaglamaSinifi("personelTipAd", ""),
            new HtmlBaglamaSinifi("yas", ""),
        };

        public static string htmlOzluk = @"<div class='panel panel-primary'>
        <div class='panel-heading'>
            <h3 class='panel-title'>
                <b>Personel Bilgisi</b></h3>
        </div>
        <div class='panel-body'>
            <div class='row'>
                <img class='img-responsive col-xs-3 col-sm-2 col-md-2' style='padding-bottom: 10px'
                    src='{resimBase64}' />
                <label class='col-xs-9 col-sm-9 col-md-9'>
                    <h3>{adSoyad}</h3>
                </label>
            </div>
            <table class='table table-condensed'>
                <tbody>
                    <tr>
                        <td class='hucre'>TC No</td>
                        <td>: {tcKimlikNo}</td>
                    </tr>
                    <tr>
                        <td class='hucre'>Unvanı</td>
                        <td>: {unvanAd}</td>
                    </tr>
                    <tr>
                        <td class='hucre'>Birimi</td>
                        <td>: {birimAd}</td>
                    </tr>
                    <tr>
                        <td class='hucre'>Kadro Tarihi</td>
                        <td>: {kadroBaslangicTarihi}</td>
                    </tr>
                    <tr>
                        <td class='hucre'>Personel Türü</td>
                        <td>: {personelTipAd}</td>
                    </tr>
                    <tr>
                        <td class='hucre'>Medeni Durumu</td>
                        <td>: {medeniDurumuAd}</td>
                    </tr>
                    <tr>
                        <td class='hucre'>Yaş</td>
                        <td>: {yas}</td>
                    </tr>
                    <tr>
                        <td class='hucre'>Mail Adres</td>
                        <td>: {mailLink}</td>
                    </tr>                    
                    <tr>
                        <td class='hucre'>Cep Telefon</td>
                        <td>: {cepTelefon}</td>
                    </tr>
                    <tr>
                        <td class='hucre'>Harici Telefon</td>
                        <td>: {isTelefon}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>";


        public static string htmlNufus = @"<div class='panel panel-danger'>
    <div class='panel-heading'>
        <h3 class='panel-title'>
            <b>Nüfus Bilgisi</b>
        </h3>
    </div>
    <div class='panel-body'>
        <table class='table table-condensed'>
            <tbody>
                <tr>
                    <td class='hucre'>Cinsiyeti</td>
                    <td>: {cinsiyetAd}</td>
                </tr>
                <tr>
                    <td class='hucre'>Cüz Seri No</td>
                    <td>: {cuzdanSeriNo}</td>
                </tr>
                <tr>
                    <td class='hucre'>Baba Adı</td>
                    <td>: {babaAd}</td>
                </tr>
                <tr>
                    <td class='hucre'>Ana Adı</td>
                    <td>: {anaAd}</td>
                </tr>
                <tr>
                    <td class='hucre'>Doğum Yeri</td>
                    <td>: {dogumYeri}</td>
                </tr>
                <tr>
                    <td class='hucre'>Doğum Tarihi</td>
                    <td>: {dogumTarihi}</td>
                </tr>
                <tr>
                    <td class='hucre'>Medeni Hali</td>
                    <td>: {medeniHaliAd}</td>
                </tr>
                <tr>
                    <td class='hucre'>Dini</td>
                    <td>: {dini}</td>
                </tr>
                <tr>
                    <td class='hucre'>İli</td>
                    <td>: {ilAd}</td>
                </tr>
                <tr>
                    <td class='hucre'>İlçesi</td>
                    <td>: {ilceAd}</td>
                </tr>
                <tr>
                    <td class='hucre'>Mahalle/Köyü</td>
                    <td>: {nufusMahalleKoy}</td>
                </tr>
                <tr>
                    <td class='hucre'>Cilt No / Aile No / Birey No</td>
                    <td>: {nufusCiltNo} / {nufusAileSiraNo} / {nufusSiraNo}</td>
                </tr>
                <tr>
                    <td class='hucre'>Cüz. Ver. Yer.</td>
                    <td>: {cuzdanVerildigiYer}</td>
                </tr>
                <tr>
                    <td class='hucre'>Cüz. Ver. Nedeni</td>
                    <td>: {cuzdanVerilisNedeni}</td>
                </tr>
                <tr>
                    <td class='hucre'>Cüz. Ver. Tarihi</td>
                    <td>: {cuzdanVerilisTarihi}</td>
                </tr>
                <tr>
                    <td class='hucre'>Cüz. Kayıt No</td>
                    <td>: {cuzdanKayitNo}</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>";
        public static HtmlBaglamaSinifi[] htmlNufusBaglama = 
        {
            new HtmlBaglamaSinifi("cinsiyetAd", ""),
            new HtmlBaglamaSinifi("cuzdanSeriNo", ""),
            new HtmlBaglamaSinifi("babaAd", ""),
            new HtmlBaglamaSinifi("anaAd", ""),
            new HtmlBaglamaSinifi("dogumYeri", ""),
            new HtmlBaglamaSinifi("dogumTarihi", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("medeniHaliAd", ""),
            new HtmlBaglamaSinifi("dini", ""),
            new HtmlBaglamaSinifi("ilAd", ""),
            new HtmlBaglamaSinifi("ilceAd", ""),
            new HtmlBaglamaSinifi("nufusMahalleKoy", ""),
            new HtmlBaglamaSinifi("nufusCiltNo", ""),
            new HtmlBaglamaSinifi("nufusAileSiraNo", ""),
            new HtmlBaglamaSinifi("nufusSiraNo", ""),
            new HtmlBaglamaSinifi("cuzdanVerildigiYer", ""),
            new HtmlBaglamaSinifi("cuzdanVerilisNedeni", ""),
            new HtmlBaglamaSinifi("cuzdanVerilisTarihi", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("cuzdanKayitNo", ""),
        };

        public static string htmlIletisim = @"<div id='adres' class='panel panel-default'>
            <div class='panel-heading'>
                <h3 class='panel-title'>
                    <b>İletişim/Adres Bilgisi</b>
                </h3>
            </div>
            <div class='panel-body'>
                <table class='table table-condensed'>
                        <tr>
                            <td class='hucre'>Adres</td>
                            <td>: {adres}</td>
                        </tr>
                        <tr>
                            <td class='hucre'>İş Tel</td>
                            <td>: {isTelefon}</td>
                        </tr>
                        <tr>
                            <td class='hucre'>Cep Tel 1</td>
                            <td>: {cepTelefon}</td>
                        </tr>
                        <tr>
                            <td class='hucre'>E-Posta</td>
                            <td>: {mailLink}</td>
                        </tr>
                        <tr>
                            <td class='hucre'>Cep Tel 2</td>
                            <td>: {cepTelefon2}</td>
                        </tr>
                        <tr>
                            <td class='hucre'>Fax</td>
                            <td>: {faks}</td>
                        </tr>
                        <tr>
                            <td class='hucre'>Lojman</td>
                            <td>: {lojmanTel}</td>
                        </tr>
                        <tr>
                            <td class='hucre'>Görüntülü</td>
                            <td>: {goruntulu}</td>
                        </tr>
                        <tr>
                            <td class='hucre'>Telsiz/Kademe</td>
                            <td>: {telsiz}</td>
                        </tr>
                </table>
            </div>
        </div>";

        public static HtmlBaglamaSinifi[] htmlIletisimBaglama = 
        {
            new HtmlBaglamaSinifi("adres", ""),
            new HtmlBaglamaSinifi("isTelefon", ""),
            new HtmlBaglamaSinifi("cepTelefon", ""),
            new HtmlBaglamaSinifi("mailLink", ""),
            new HtmlBaglamaSinifi("cepTelefon2", ""),
            new HtmlBaglamaSinifi("faks", ""),
            new HtmlBaglamaSinifi("lojmanTel", ""),
            new HtmlBaglamaSinifi("goruntulu", ""),
            new HtmlBaglamaSinifi("telsiz", ""),        
        };

        public static string htmlAskerlik = @"<div class='panel panel-warning'>
    <div class='panel-heading'>
        <h3 class='panel-title'>
            <b>Askerlik Bilgisi</b>
        </h3>
    </div>
    <div class='panel-body'>
        <table class='table table-condensed'>
            <tr>
                <td class='hucre'>Durumu</td>
                <td>: {askerlikDurumuAd}</td>
            </tr>
            <tr>
                <td class='hucre'>Başlangıç Tarihi</td>
                <td>: {askerlikBaslamaTarihiST}</td>
            </tr>
            <tr>
                <td class='hucre'>Bitiş Tarihi</td>
                <td>: {terhisTarihiST}</td>
            </tr>
            <tr>
                <td class='hucre'>İntikal Tarihi</td>
                <td>: {ibrazIntikalTarihiST}</td>
            </tr>
            <tr>
                <td class='hucre'>Şubesi</td>
                <td>: {askerlikSubesi}</td>
            </tr>
            <tr>
                <td class='hucre'>Sınıfı</td>
                <td>: {sinifAd}</td>
            </tr>
            <tr>
                <td class='hucre'>Belge No</td>
                <td>: {belgeNo}</td>
            </tr>
            <tr>
                <td class='hucre'>Belge Tarihi</td>
                <td>: {belgeTarihiST}</td>
            </tr>
            <tr>
                <td class='hucre'>Asteğmen Nasbı</td>
                <td>: {astegmenNaspTarihiST}</td>
            </tr>
            <tr>
                <td class='hucre'>Sayılmayan Gün</td>
                <td>: {sayilmayanGunSayisi}</td>
            </tr>
            <tr>
                <td class='hucre'>Açıklama</td>
                <td>: {aciklama}</td>
            </tr>
        </table>
    </div>
</div>";
        public static HtmlBaglamaSinifi[] htmlAskerlikBaglama = 
        {
                new HtmlBaglamaSinifi("askerlikDurumuAd", ""),
                new HtmlBaglamaSinifi("askerlikBaslamaTarihiST", ""),
                new HtmlBaglamaSinifi("terhisTarihiST", ""),
                new HtmlBaglamaSinifi("ibrazIntikalTarihiST", ""),
                new HtmlBaglamaSinifi("askerlikSubesi", ""),
                new HtmlBaglamaSinifi("sinifAd", ""),
                new HtmlBaglamaSinifi("belgeNo", ""),
                new HtmlBaglamaSinifi("belgeTarihiST", ""),
                new HtmlBaglamaSinifi("astegmenNaspTarihiST", ""),
                new HtmlBaglamaSinifi("sayilmayanGunSayisi", ""),
                new HtmlBaglamaSinifi("aciklama", ""),
        };

        public static string htmlOgrenim = @"<div class='panel {panelClass} tab-pane fade in active'>
    <div class='panel-heading'>
        <h3 class='panel-title'>
            <b>{ogrenimAdi}</b>
        </h3>
    </div>
    <div class='panel-body'>
        <table class='table table-condensed'>
            <tr>
                <td class='hucre'>Okul Adı</td>
                <td>: {okulAdi}</td>
            </tr>
            <tr>
                <td class='hucre'>Bitirme Tarihi</td>
                <td>: {belgeTarihi}</td>
            </tr>
        </table>
    </div>
</div>";
        public static HtmlBaglamaSinifi[] htmlOgrenimBaglama = 
        {
            new HtmlBaglamaSinifi("panelClass", ""),
            new HtmlBaglamaSinifi("ogrenimAdi", ""),
            new HtmlBaglamaSinifi("okulAdi", ""),
            new HtmlBaglamaSinifi("belgeTarihi", "dd.MM.yyyy"),
        };

        public static string htmlAile = @"<div class='panel {panelClass}'>
  <div class='panel-heading'>
      <h3 class='panel-title'>
           <b>{yakinlik}</b>
   </h3>
</div>
  <div class='panel-body'>
      <table class='table table-condensed'>
        <tr><td class='hucre'>Ad Soyad</td><td>: {ad}</td></tr>
        <tr><td class='hucre'>Öğrenim Bilgisi</td><td>: {ogrenimAd}</td></tr>    
        <tr><td class='hucre'>Bakmakla Yükümlü</td><td>: {yukumlu}</td></tr>
   </table>
</div>
</div>";      //<tr><td class='hucre'>Çalışma Durumu</td><td>: {durumAd}</td></tr>

        public static HtmlBaglamaSinifi[] htmlAileBaglama = 
        {
            new HtmlBaglamaSinifi("panelClass", ""),
            new HtmlBaglamaSinifi("yakinlik", ""),
            new HtmlBaglamaSinifi("ad", ""),
            new HtmlBaglamaSinifi("ogrenimAd", ""),
            new HtmlBaglamaSinifi("durumAd", ""),
            new HtmlBaglamaSinifi("yukumlu", ""),
        };

        public static string htmlKurs = @"<div class='panel {panelClass}'>
  <div class='panel-heading'>
      <h3 class='panel-title'>
           <b>{bitirmeTarihi_Yil}</b>
   </h3>
</div>
  <div class='panel-body'>
      <table class='table table-condensed'>
         <tr><td class='hucre'>Kurs Adı</td><td>: {kursAdi}</td></tr>
         <tr><td class='hucre'>Aldığı Yer</td><td>: {aldigiYer}</td></tr>
         <tr><td class='hucre'>Başlama Tarihi</td><td>: {baslamaTarihi}</td></tr>
         <tr><td class='hucre'>Bitirme Tarihi</td><td>: {bitirmeTarihi}</td></tr>
   </table>
</div>
</div>";

        public static HtmlBaglamaSinifi[] htmlKursBaglama = 
        {
            new HtmlBaglamaSinifi("panelClass", ""),
            new HtmlBaglamaSinifi("bitirmeTarihi_Yil", ""),
            new HtmlBaglamaSinifi("kursAdi", ""),
            new HtmlBaglamaSinifi("aldigiYer", ""),
            new HtmlBaglamaSinifi("baslamaTarihi", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("bitirmeTarihi", "dd.MM.yyyy"),
        };

        public static string htmlDil = @"<div class='panel {panelClass}'>
                      <div class='panel-heading'>
                          <h3 class='panel-title'>
                               <b>{dilAdi}</b>
                       </h3>
                    </div>
                      <div class='panel-body'> 
                          <table class='table table-condensed'>
                               <tr><td class='hucre'>Dil Seviyesi</td><td>: {dilSeviyesi}</td></tr>
                               <tr><td class='hucre'>Sınav Türü</td><td>: {belgeAdi}</td></tr>
                               <tr><td class='hucre'>Sınav Düzeyi</td><td>: {duzey}</td></tr>
                               <tr><td class='hucre'>Başlangıç Tarihi</td><td>: {tarih}</td></tr>
                               <tr><td class='hucre'>Sınav Puanı</td><td>: {puan}</td></tr>
                       </table>
                    </div>
                    </div>";

        public static HtmlBaglamaSinifi[] htmlDilBaglama = 
        {
            new HtmlBaglamaSinifi("panelClass", ""),
            new HtmlBaglamaSinifi("dilAdi", ""),
            new HtmlBaglamaSinifi("dilSeviyesi", ""),
            new HtmlBaglamaSinifi("belgeAdi", ""),
            new HtmlBaglamaSinifi("duzey", ""),
            new HtmlBaglamaSinifi("tarih", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("puan", ""),
        };

        public static string htmlKadro = @"<div class='panel {panelClass}'>
    <div class='panel-heading'>
       <h3 class='panel-title'>
            <b>{unvanAd}</b>
       </h3>
    </div>
    <div class='panel-body'>
        <table class='table table-condensed'>
         <tr><td class='hucre'>Memuriyeti</td><td>: {gorevYeri}</td></tr>
         <tr><td class='hucre'>Başlama Tarihi</td><td>: {atamaTarihi}</td></tr>
         <tr><td class='hucre'>Başlangıç Sebebi</td><td>: {hizmetSebebiAd}</td></tr>
         <tr><td class='hucre'>Bitiş Tarihi</td><td>: {ayrilmaTarihi}</td></tr>
         <tr><td class='hucre'>Bitiş Sebebi</td><td>: {ayrilmaGerekcesiAd}</td></tr>
         <tr><td class='hucre'>Kadro Derece/Kademe/Ek Göst.</td><td>: {kadroDerece}/{odemeEsasKademe}/{odemeEsasEkGosterge}</td></tr>
         <tr><td class='hucre'>Kaz. Derece/Kademe/Ek Göst.</td><td>: {kazanilmisHakDerece}/{kazanilmisHakKademe}/{kazanilmisEkGosterge}</td></tr>
         <tr><td class='hucre'>Em. Derece/Kademe/Ek Göst.</td><td>: {emekliyeEsasDerece}/{emekliyeEsasKademe}/{emekliyeEsasEkGosterge}</td></tr>
        </table>
    </div>
</div>"; //         <tr><td class='hucre'>Memuriyeti</td><td>: {gorevYeri}</td></tr>

        public static HtmlBaglamaSinifi[] htmlKadroBaglama = 
        {
            new HtmlBaglamaSinifi("panelClass", ""),
            new HtmlBaglamaSinifi("unvanAd", ""),
            new HtmlBaglamaSinifi("gorevYeri", ""),
            new HtmlBaglamaSinifi("hizmetSebebiAd", ""),
            new HtmlBaglamaSinifi("atamaTarihi", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("ayrilmaGerekcesiAd", ""),
            new HtmlBaglamaSinifi("ayrilmaTarihi", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("kadroDerece", ""),            
            new HtmlBaglamaSinifi("odemeEsasKademe", ""),
            new HtmlBaglamaSinifi("odemeEsasEkGosterge", ""),
            new HtmlBaglamaSinifi("kazanilmisHakDerece", ""),
            new HtmlBaglamaSinifi("kazanilmisHakKademe", ""),
            new HtmlBaglamaSinifi("kazanilmisEkGosterge", ""),
            new HtmlBaglamaSinifi("emekliyeEsasDerece", ""),
            new HtmlBaglamaSinifi("emekliyeEsasKademe", ""),
            new HtmlBaglamaSinifi("emekliyeEsasEkGosterge", ""),
        };

        public static string htmlEskiHizmet = @"<div class='panel {panelClass}'>
    <div class='panel-heading'>
       <h3 class='panel-title'>
            <b>{eskiHizmetTipi}</b>
       </h3>
    </div>
    <div class='panel-body'>
        <table class='table table-condensed'>
         <tr><td class='hucre'>Yıl/Ay/Gün</td><td>: {yilAyGun}</td></tr>        
        </table>
    </div>
</div>";

        public static HtmlBaglamaSinifi[] htmlEskiHizmetBaglama = 
        {
            new HtmlBaglamaSinifi("eskiHizmetTipi", ""),
            new HtmlBaglamaSinifi("yilAyGun", ""),
        };


        public static string htmlTakdirCeza = @"<div class='panel {panelClass} tab-pane fade in active'> 
    <div class='panel-heading'> 
        <h3 class='panel-title'> 
            <b>{cezaOdulTipiAdi}</b> 
        </h3>
    </div>
    <div class='panel-body'> 
        <table class='table table-condensed'>    
            <tr><td class='hucre'>Verilen Tarih</td><td>: {tarih}</td></tr> 
            <tr><td class='hucre'>Veren Kurum</td><td>: {verenKurum}</td></tr> 
            <tr><td class='hucre'>Veren Unvanı</td><td>: {verenUnvani}</td></tr> 
        </table> 
    </div> 
</div>";
        public static HtmlBaglamaSinifi[] htmlTakdirCezaBaglama = 
        {
            new HtmlBaglamaSinifi("panelClass", ""),
            new HtmlBaglamaSinifi("cezaOdulTipiAdi", ""),
            new HtmlBaglamaSinifi("tarih", ""),
            new HtmlBaglamaSinifi("verenKurum", ""),
            new HtmlBaglamaSinifi("verenUnvani", ""),

        };

        public static string htmlGuncelHizmet = @"<div class='panel panel-primary'>
    <div class='panel-heading'>
        <h3 class='panel-title'>
            <b>Memuriyet Bilgisi</b>
        </h3>
    </div>
    <div class='panel-body'>
        <table class='table table-condensed'>
            <tr>
                <td class='hucre'>TC No</td>
                <td>: {personelTC}</td>
            </tr>
            <tr>
                <td class='hucre'>Sicili</td>
                <td>: {personelSicil}</td>
            </tr>
            <tr>
                <td class='hucre'>İlk İşe Başladığı Tarih</td>
                <td>: {memuriyeteBasladigiTarih}</td>
            </tr>
            <tr>
                <td class='hucre'>Kuruma Başlama Tarihi</td>
                <td>: {kurumaBasladigiTarih}</td>
            </tr>
            <tr>
                <td class='hucre'>Kadro Başlama Tarihi</td>
                <td>: {kadroyaGectigiTarih}</td>
            </tr>
            <tr>
                <td class='hucre'>Memuriyet Toplamı</td>
                <td>: {hizmetGunu_Yil}</td>
            </tr>
            <tr>
                <td class='hucre'>Kadro Derecesi</td>
                <td>: {kadroDerece}</td>
            </tr>
            <tr>
                <td class='hucre'>EkGostergesi</td>
                <td>: {ekGosterge}</td>
            </tr>
            <tr>
                <td class='hucre'>Kazanılmış Derece/Kademe</td>
                <td>: {kDerece} / {kKademe}</td>
            </tr>
            <tr>
                <td class='hucre'>Emekli Derece/Kademe</td>
                <td>: {eDerece} / {eKademe}</td>
            </tr>
            <tr>
                <td class='hucre'>Geldiği Kurum</td>
                <td>: {geldigiKurum}</td>
            </tr>
        </table>
    </div>
</div>";
        public static HtmlBaglamaSinifi[] htmlGuncelHizmetBaglama = 
        {
            new HtmlBaglamaSinifi("personelTC", ""),
            new HtmlBaglamaSinifi("personelSicil", ""),
            new HtmlBaglamaSinifi("memuriyeteBasladigiTarih", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("kurumaBasladigiTarih", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("kadroyaGectigiTarih", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("hizmetGunu_Yil", ""),
            new HtmlBaglamaSinifi("kadroDerece", ""),
            new HtmlBaglamaSinifi("ekGosterge", ""),
            new HtmlBaglamaSinifi("kDerece", ""),
            new HtmlBaglamaSinifi("kKademe", ""),
            new HtmlBaglamaSinifi("eDerece", ""),
            new HtmlBaglamaSinifi("eKademe", ""),
            new HtmlBaglamaSinifi("geldigiKurum", ""),
        };

        public static string htmlIzin = @"<div class='panel {panelClass} tab-pane fade in active'>
    <div class='panel-heading'>
        <h3 class='panel-title'>
            <b>{izinTuru}</b>
        </h3>
    </div>
    <div class='panel-body'>
        <table class='table table-condensed'>
            <tr>
                <td class='hucre'>Başlama Tarihi</td>
                <td>: {baslamaTarihi}</td>
            </tr>
            <tr>
                <td class='hucre'>Dönüş Tarihi</td>
                <td>: {donusTarihi}</td>
            </tr>
            <tr>
                <td class='hucre'>İzin Süresi</td>
                <td>: {izinSuresi}</td>
            </tr>
        </table>
    </div>
</div>";
        public static HtmlBaglamaSinifi[] htmlIzinBaglama = 
        {
            new HtmlBaglamaSinifi("panelClass", ""),
            new HtmlBaglamaSinifi("izinTuru", ""),
            new HtmlBaglamaSinifi("baslamaTarihi", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("donusTarihi", "dd.MM.yyyy"),
            new HtmlBaglamaSinifi("izinSuresi", ""),
        };

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PersonelTurDoldur();
                RaporDoldur();
            }
        }

        public static string PersonelTipleriBul(TNS.IKY.IIKYServis servisIKY, string personelTurGruplari)
        {
            string personelTurler = "";
            if (!string.IsNullOrWhiteSpace(personelTurGruplari))
            {
                PersonelTipi pt = new PersonelTipi();
                pt.tipGruplar = personelTurGruplari.Split(',');
                pt.aktif = 1;
                ObjectArray ptipler = servisIKY.ListelePersonelTip(null, pt);
                foreach (PersonelTipi item in ptipler.objeler)
                {
                    if (personelTurler != "") personelTurler += ";";
                    personelTurler += item.kod.ToString();
                }
            }
            return personelTurler;
        }

        [WebMethod]
        public static PBilgiSonuc PersonelBilgiAl(int pKod, int bilgiKod)
        {
            PBilgiSonuc pBilgisonuc = new PBilgiSonuc();
            pBilgisonuc.bilgiKod = bilgiKod;

            if (pKod < 1) return pBilgisonuc;
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, false);
            TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            string sonuc = "";
            if (bilgiKod == 2 || bilgiKod == 16)
            {
                TNS.IKY.Personel p = new TNS.IKY.Personel { kod = pKod };
                ObjectArray dler = servisIKY.PersonelListele(kul, p, true, false);

                if (dler.ObjeSayisi == 1)
                {
                    p = (TNS.IKY.Personel)dler[0];
                    pBilgisonuc.resimUrl = p.resimYol;
                    pBilgisonuc.unvan = p.unvanAd;
                    pBilgisonuc.isim = p.adSoyad;
                }
                sonuc += HtmlBaglamaSinifi.HTMLBind(htmlOzluk, new TNSCollection(p), htmlOzlukBaglama);
            }

            if (bilgiKod == 3 || bilgiKod == 16)
            {
                TNS.IKY.PersonelNufus bilgi = servisIKY.PersonelNufusListele(kul, pKod);
                sonuc += HtmlBaglamaSinifi.HTMLBindProp(htmlNufus, bilgi, htmlNufusBaglama);
            }
            if (bilgiKod == 4 || bilgiKod == 16)
            {
                TNS.IKY.PersonelIletisim iletisim = servisIKY.PersonelAdresListele(kul, pKod);
                sonuc += HtmlBaglamaSinifi.HTMLBindProp(htmlIletisim, iletisim, htmlIletisimBaglama);
            }
            if (bilgiKod == 5 || bilgiKod == 16)
            {
                TNS.IKY.PAskerlik bilgi = servisIKY.PersonelAskerlikListele(kul, pKod);
                sonuc += HtmlBaglamaSinifi.HTMLBindProp(htmlAskerlik, bilgi, htmlAskerlikBaglama);
            }
            if (bilgiKod == 6 || bilgiKod == 16)
            {
                TNS.IKY.PersonelOgrenim ogr = new TNS.IKY.PersonelOgrenim();
                ogr.personelKod = pKod;
                ObjectArray listeler = servisIKY.PersonelOgrenimListele(kul, ogr);

                int cnt = 1;
                string sonucIc = "";
                foreach (TNS.IKY.PersonelOgrenim o in listeler.objeler)
                {
                    string sinif;
                    if (cnt++ % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";
                    TNSCollection veriler = new TNSCollection(sinif, o.ogrenimAdi, o.okulAdi, o.belgeTarihi);
                    sonucIc += HtmlBaglamaSinifi.HTMLBindCollectionSatir(htmlOgrenim, veriler, htmlOgrenimBaglama);
                }
                sonuc += "<div class='panel-group'><div class='panel-heading'><h3 class='panel-title'><b>Öğrenim Bilgisi</b></h3></div>" + sonucIc + "</div>";
            }
            if (bilgiKod == 7 || bilgiKod == 16)
            {
                TNS.IKY.PersonelOgrenim ogr = new TNS.IKY.PersonelOgrenim();
                ogr.personelKod = pKod;
                ObjectArray listeler = servisIKY.PersonelAileListele(kul, 0, pKod, null, null, null, 0);

                int cnt = 1;
                string sonucIc = "";
                foreach (TNS.IKY.PersonelAile a in listeler.objeler)
                {
                    string sinif;
                    if (cnt++ % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";
                    string yukumlu = "";
                    if (a.bakmaklaYukumlu == 1)
                        yukumlu = "✓";

                    TNSCollection veriler = new TNSCollection(sinif, TNS.IKY.Arac.YakinlikAd(a.yakinlik), a.ad + " " + a.soyad, a.ogrenimAd, a.durumAd, yukumlu);
                    sonucIc += HtmlBaglamaSinifi.HTMLBindCollectionSatir(htmlAile, veriler, htmlAileBaglama);
                }
                sonuc += "<div class='panel-group'><div class='panel-heading'><h3 class='panel-title'><b>Aile Bilgisi</b></h3></div>" + sonucIc + "</div>";
            }
            if (bilgiKod == 8 || bilgiKod == 16)
            {
                TNS.IKY.PersonelKurs pkurs = new TNS.IKY.PersonelKurs();
                pkurs.personelKod = pKod;
                ObjectArray listeler = servisIKY.PersonelKursListele(kul, pkurs);

                int cnt = 1;
                string sonucIc = "";
                foreach (TNS.IKY.PersonelKurs k in listeler.objeler)
                {
                    string sinif;
                    if (cnt++ % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    TNSCollection veriler = new TNSCollection(sinif, k.baslamaTarihi.Yil, k.kursAdi, k.aldigiYer, k.baslamaTarihi, k.bitirmeTarihi);
                    sonucIc += HtmlBaglamaSinifi.HTMLBindCollectionSatir(htmlKurs, veriler, htmlKursBaglama);
                }
                sonuc += "<div class='panel-group'><div class='panel-heading'><h3 class='panel-title'><b>Kurs Bilgisi</b></h3></div>" + sonucIc + "</div>";
            }
            if (bilgiKod == 9 || bilgiKod == 16)
            {
                TNS.IKY.PersonelDil pdil = new TNS.IKY.PersonelDil();
                pdil.personelKod = pKod;
                ObjectArray listeler = servisIKY.PersonelDilListele(kul, pdil);

                int cnt = 1;
                string sonucIc = "";
                foreach (TNS.IKY.PersonelDil d in listeler.objeler)
                {
                    string sinif;
                    if (cnt++ % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    TNSCollection veriler = new TNSCollection(sinif, d.dilAdi, d.dilSeviyesi, d.belgeAdi, d.duzey, d.tarih, d.puan);
                    sonucIc += HtmlBaglamaSinifi.HTMLBindCollectionSatir(htmlDil, veriler, htmlDilBaglama);
                }
                sonuc += "<div class='panel-group'><div class='panel-heading'><h3 class='panel-title'><b>Dil Bilgisi</b></h3></div>" + sonucIc + "</div>";
            }
            if (bilgiKod == 10 || bilgiKod == 16)
            {
                TNS.IKY.PersonelKadro kadro = new TNS.IKY.PersonelKadro();
                kadro.personelKod = pKod;
                kadro.eskiHizmetTipiFlag = 2;

                ObjectArray listeler = servisIKY.PersonelKadroListele(kul, kadro, false);

                int cnt = 1;
                string sonucIc = "";
                foreach (TNS.IKY.PersonelKadro k in listeler.objeler)
                {
                    string sinif;
                    if (cnt++ % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    TNSCollection veriler = new TNSCollection(sinif, k.unvanAd, k.gorevYeri
                                , k.hizmetSebebiAd
                                , k.atamaTarihi
                                , k.ayrilmaGerekcesiAd
                                , k.ayrilmaTarihi
                                , k.kadroDerece
                                , k.odemeyeEsasKademe
                                , k.odemeyeEsasEkGosterge
                                , k.kazanilmisHakDerece
                                , k.kazanilmisHakKademe
                                , k.kazanilmisEkGosterge
                                , k.emekliyeEsasDerece
                                , k.emekliyeEsasKademe
                                , k.emekliyeEsasEkGosterge);
                    sonucIc += HtmlBaglamaSinifi.HTMLBindCollectionSatir(htmlKadro, veriler, htmlKadroBaglama);
                }
                sonuc += "<div class='panel-group'><div class='panel-heading'><h3 class='panel-title'><b>Hizmet Bilgisi</b></h3></div>" + sonucIc + "</div>";
            }
            if (bilgiKod == 11 || bilgiKod == 16)
            {
                sonuc += TakdirCezaListele(servisIKY, kul, pKod, true);
            }
            if (bilgiKod == 12 || bilgiKod == 16)
            {
                sonuc += TakdirCezaListele(servisIKY, kul, pKod, false);
            }
            if (bilgiKod == 13 || bilgiKod == 16)
            {
                ObjectArray dler = servisIKY.HizmetleriGetir(kul, "", pKod.ToString(), "", null, 0, "", -1);
                TNS.IKY.BirimUnvan gc;
                if (dler.ObjeSayisi == 1)
                {
                    TNS.IKY.Hizmet d = (TNS.IKY.Hizmet)dler.objeler[0];
                    gc = d.guncelHizmet;
                    gc.hizmetGunu_Yil = TNS.IKY.Hizmet.YilDondur(d.hizmetGunu);
                }
                else
                    gc = new BirimUnvan();
                sonuc += HtmlBaglamaSinifi.HTMLBind(htmlGuncelHizmet, new TNSCollection(gc), htmlGuncelHizmetBaglama);
            }
            if (bilgiKod == 14 || bilgiKod == 16)
            {
                TNS.IKY.PersonelIzin izin = new TNS.IKY.PersonelIzin();
                izin.personelKod = pKod;
                ObjectArray listeler = servisIKY.PersonelIzinListele(kul, izin);

                string sonucIc = "";
                foreach (TNS.IKY.PersonelIzin i in listeler.objeler)
                {
                    string sinif;
                    if (i.izinTurKod == 1)
                        sinif = "panel-success";
                    else if (i.izinTurKod == 6)
                        sinif = "panel-info";
                    else if (i.izinTurKod == 10)
                        sinif = "panel-warning";
                    else
                        sinif = "panel-active";
                    TNSCollection veriler = new TNSCollection(sinif, i.izinTipAd, i.baslangicTarihi, i.bitisTarihi, i.kullanilanGun);
                    sonucIc += HtmlBaglamaSinifi.HTMLBindCollectionSatir(htmlIzin, veriler, htmlIzinBaglama);
                }

                IzinBilgi iBilgi = servisIKY.PersonelKullanilanIzinHesapla(kul, pKod, IzinArac.DonemYiliBul(DateTime.Now.Year, DateTime.Now.Month), 0);
                string izinBilgi = "Toplam: " + iBilgi.toplam + " Kullanılan: " + iBilgi.devirdenKullanilan + " Kalan: " + iBilgi.kalan;

                sonuc += "<div class='panel-group'><div class='panel-heading'><h3 class='panel-title'><b>İzin Bilgisi</b></br></br><b>" + iBilgi.devirdenKullanilan + "<b></h3></div>" + sonucIc + "</div>";
            }
            if (bilgiKod == 15 || bilgiKod == 16)
            {
                TNS.IKY.PersonelKadro kadro = new TNS.IKY.PersonelKadro();
                kadro.personelKod = pKod;
                kadro.eskiHizmetTipiFlag = 1;

                ObjectArray listeler = servisIKY.PersonelKadroListele(kul, kadro, false);

                int cnt = 1;
                string sonucIc = "";
                foreach (TNS.IKY.PersonelKadro k in listeler.objeler)
                {
                    string sinif;
                    if (cnt++ % 2 == 0)
                        sinif = "panel-success";
                    else
                        sinif = "panel-info";

                    TNSCollection veriler = new TNSCollection(k.personelTipAd, Hizmet.YilAyGunDondur(k.hizmetGunSayisi));
                    sonucIc += HtmlBaglamaSinifi.HTMLBindCollectionSatir(htmlEskiHizmet, veriler, htmlEskiHizmetBaglama);
                }
                sonuc += "<div class='panel-group'><div class='panel-heading'><h3 class='panel-title'><b>Eski Hizmet Bilgisi</b></h3></div>" + sonucIc + "</div>";
            }
            pBilgisonuc.sonuc = sonuc;
            return pBilgisonuc;
        }

        private static string TakdirCezaListele(TNS.IKY.IIKYServis servisIKY, Kullanici kul, int pKod, bool takdirMi)
        {
            TNS.IKY.PersonelCezaOdul takcez = new TNS.IKY.PersonelCezaOdul();
            takcez.personelKod = pKod;

            if (takdirMi)
                takcez.cezaOdulTipiKayitKodu = "30.00001";
            else
                takcez.cezaOdulTipiKayitKodu = "30.00002";

            ObjectArray listeler = servisIKY.PersonelCezaOdulListele(kul, takcez);

            int cnt = 1;
            string sonucIc = "";
            foreach (TNS.IKY.PersonelCezaOdul co in listeler.objeler)
            {
                string sinif;
                if (cnt++ % 2 == 0)
                    sinif = "panel-success";
                else
                    sinif = "panel-info";

                TNSCollection veriler = new TNSCollection(sinif, co.cezaOdulTipiAdi, co.tarih, co.verenKurum, co.verenUnvani);
                sonucIc += HtmlBaglamaSinifi.HTMLBindCollectionSatir(htmlTakdirCeza, veriler, htmlTakdirCezaBaglama);
            }
            return "<div class='panel-group'><div class='panel-heading'><h3 class='panel-title'><b>" + (takdirMi ? "Takdir" : "Ceza") + " Bilgisi</b></h3></div>" + sonucIc + "</div>";
        }

        [WebMethod]
        public static ListeSonuc Listele(string genelSorgu, string satir, string aktiflik, string personelTurGruplari, string resimBilgi, bool solGizli)
        {
            TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            ListeSonuc sonuc = new ListeSonuc();
            TNS.IKY.Personel personel = new TNS.IKY.Personel();
            personel.genelSorgu = genelSorgu;
            personel.kayitBasla = TNS.OrtakFonksiyonlar.ConvertToInt(satir, 0);
            personel.kayitToplam = 30;
            personel.aktifDurumlar = aktiflik;
            personel.personelTipleri = PersonelTipleriBul(servisIKY, personelTurGruplari);
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, false);
            TNS.ObjectArray liste = servisIKY.PersonelListele(kul, personel, false, true);

            if (!liste.sonuc.islemSonuc)
                throw new Exception(liste.sonuc.hataStr);
            string tablo = "", sinif = "";
            int sonuncuSatir = 0, cnt = 0;
            if (liste.ObjeSayisi > 0)
            {
                if (solGizli)
                    sinif = "col-md-3 col-sm-4";
                else
                    sinif = "col-md-4 col-sm-12";

                foreach (TNS.IKY.Personel p in liste.objeler)
                {
                    tablo += " <div class='col-xs-12 " + sinif + " alan' id='alan" + p.kod + "'>";
                    tablo += " <div class='thumbnail' style='background-color:#F8F8F8' ondblclick=\"DetayaGit('" + p.kod + "');\">";
                    if (resimBilgi == "1")
                        tablo += string.Format("<img src='" + p.resimBase64 + "' class='img-rounded' style='height: 120px;width:90px;' />");
                    tablo += "<div class='caption'>";
                    tablo += "<div class='row' style='height:210px; padding: 5px 5px 0 10px;'>";
                    tablo += "<h3>" + p.adSoyad + "</h3>";
                    tablo += "<p> " + p.kadro.unvanAd + "<br>" + p.personelTipAd + "<br>" + p.kadro.birimAd + "</p></div>";
                    tablo += "<div class='row'> ";
                    tablo += "<div class='col-xs-6 col-md-6 col-sm-6'><label class='kisiSinifi'><input name='type' type='checkbox' value='" + p.kod + "' class='chkPersonel' />SEÇ</label></div>";
                    tablo += "<div class='col-xs-6 col-md-6 col-sm-6 text-right'<p><a href='#' onclick=\"DetayaGit('" + p.kod + "');\" class='btn btn-primary' style='height:50px;font-weight:bold;font-size:large;text-align=center;' role='button'>Detay</a></p>";
                    tablo += "</div></div></div></div></div>";

                    if (cnt == liste.ObjeSayisi - 1)
                        sonuncuSatir = p.satir;
                    cnt++;
                }
            }

            if (satir != "0")
                sonuc.yukleme = true;
            sonuc.tablo = tablo;
            sonuc.satir = sonuncuSatir;
            sonuc.toplamKayit = liste.sonuc.kayitSay;

            return sonuc;
        }

        [WebMethod]
        public static string RaporUret(bool dosyaMail, string rapor, string aktiflik, string personelTurGruplari, string tumu,
                                     string mailKisi, string kodlar, string sorgu)
        {
            string raporKod = rapor.Split(',')[0];
            string raporAd = rapor.Split(',')[1];
            string mesaj = "";
            TNS.IKY.IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();
            Kullanici kul = OturumBilgisiIslem.KullaniciBilgiOku(true, false);

            if (tumu == "1")
            {
                kodlar = "";
                TNS.IKY.Personel personel = new TNS.IKY.Personel();
                personel.genelSorgu = sorgu;
                personel.aktifDurumlar = aktiflik;
                personel.personelTipleri = PersonelTipleriBul(servisIKY, personelTurGruplari);
                TNS.ObjectArray pler = servisIKY.PersonelListele(kul, personel, false, true);
                if (pler.ObjeSayisi > 0)
                {
                    foreach (TNS.IKY.Personel p in pler.objeler)
                        kodlar += p.kod + ";";
                }
            }
            if (dosyaMail)
            {
                string url = RaporPersonel.adresUret(raporKod, "", "", "", "", 0, "pdf", 0, false, kodlar, aktiflik, "", "", sorgu, -1, 0, 0, 0, 0, 0, 0, 0, "", "", 0, "");
                return "1:" + url;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(mailKisi))
                {
                    mesaj = "Mail Gönderilecek Kişiyi Giriniz.";
                    return mesaj;
                }
                string dosyaAd = RaporPersonel.raporUret(servisIKY, kul, istemciUzayi.GenelSayfa.RaporSablonYol(), raporKod, "", "", "", "", 0, "pdf", 0, false, kodlar, aktiflik, "", "", false, sorgu, -1, 0, 0, 0, 0, 0, 0, 0, "", "", 0, "");
                TNSCollection ekDosyaIsimleri = new TNSCollection();
                EPostaEki ek = new EPostaEki();
                ek.dosyaAd = dosyaAd;
                ek.ek = null;
                ek.ad = raporAd + ".pdf";
                ekDosyaIsimleri.Add(ek);
                string sonuc = OrtakFonksiyonlar.MailAt(kul.emailAdresi, mailKisi, "Raporlar", raporAd + " Raporu", true, false, ekDosyaIsimleri);
                try
                {
                    System.IO.File.Delete(dosyaAd);
                }
                catch
                {
                }
                if (!string.IsNullOrWhiteSpace(sonuc) && sonuc != "1")
                    mesaj = sonuc;
                else
                    mesaj = "Mail Gönderildi.";
                return "2:" + mesaj;
            }
        }

        protected void RaporDoldur()
        {
            string raporlar = "";
            foreach (RaporPersonel.RaporGrubu grup in RaporPersonel.raporGrubu)
            {
                raporlar += "<div class='panel panel-default' >" +
                              " <div class='panel-heading' style='padding-left:2px;'> " +
                              "     <span class='panel-title' > " +
                               "        <a data-toggle='collapse'  data-parent='#accordion' href='#" + grup.KOD + "'>" + grup.AD + "</a>" +
                               "    </span>" +
                             "  </div>" +
                             " <div id='" + grup.KOD + "' class='panel-collapse collapse'><table class='panel-body'>";
                bool tek = true;

                foreach (RaporPersonel.RaporTanim item in RaporPersonel.raporTanimlar)
                {
                    if (item.KOD == "GR009" || item.KOD == "IK021")
                        continue;

                    if (item.raporGrubu == grup.KOD)
                    {
                        raporlar += "<tr class='row " + (tek ? "tek" : "cift") + "'>" +
                          "<td style='width:100%;padding:5px 0px 5px 8px;font-size:18px;white-space: normal;'>" + item.AD + "</td>" +
                          "<td style='width:100px;padding:5px 0px 5px 2px;float:left;'>" +
                          "<button style='margin:0px 10px 0px 0px;' type='button' class='btn btn-primary' onclick=\"SeciliRaporuGetir(1,'" + item.KOD + "','" + item.AD + "', " + grup.pZorunlu + ")\"><i class='glyphicon glyphicon-download-alt'></i></button>" +
                            //"</td><td style='width:44px;padding:5px 0px 5px 2px;float:right;'>" +
                          "<button  type='button' class='btn btn-primary' onclick=\"SeciliRaporuGetir(2,'" + item.KOD + "','" + item.AD + "', " + grup.pZorunlu + ")\"><i class='glyphicon glyphicon-send'></i></button>" +
                          "</td></tr>";
                        tek = !tek;
                    }
                }
                raporlar += "  </table></div></div>";
            }
            ltlRaporlar.Text = raporlar;
        }

        protected void PersonelTurDoldur()
        {
            string turler = ""; // "<ul id='ptip' class='list-group checked-list-box'>";
            ArrayList col = TNS.IKY.Arac.PersonelTipGrupListe;
            string isaretli = "false";
            bool ilk = true;
            foreach (PersonelTipi tip in col)
            {
                isaretli = "false";
                if (ilk)
                {
                    isaretli = "true";
                    ilk = false;
                }

                turler += "<li class='list-group-item' data-style='button' data-checked='" + isaretli + "' value='" + tip.ad + "'>" + tip.ad + "</li>";
            }
            // turler += "</ul>";
            pTurler.Text = turler;
        }
    }
}