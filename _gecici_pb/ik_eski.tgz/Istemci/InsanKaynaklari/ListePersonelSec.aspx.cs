﻿using System;
using System.Web.UI.WebControls;
using TNS.ORG;
using TNS.BKD;
using OrtakClass;
using TNS;
using System.Data;
using WebServisler.EvrakServis;
using TNS.IKY;
using System.Collections.Generic;
using Ext1.Net;
using System.Collections;

namespace InsanKaynaklari
{
    /// <summary>
    /// Görevlendirme sınıfı
    /// </summary>
    public partial class ListePersonelSec : istemciUzayi.GenelSayfa
    {
        IIKYServis servisPER = TNS.IKY.Arac.Tanimla();
        string personelTip;
        string tarihStr;
        string tarihStr2;
        private int maas;
        /// <summary>
        /// Sayfanın yüklenmesi sırasında çağrılan fonksiyon
        /// </summary>
        /// <param name="sender">Çağıran, object tipinde sınıf</param>
        /// <param name="e">Olay argümanı, Event Args tipinde sınıf</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Sayfaya giriş izni varmı?
            //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, "Gorevlendirme.aspx");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            personelTip = GenelIslemlerIstemci.RequestBul(this, "perTip", "");
            maas = GenelIslemlerIstemci.RequestBul(this, "maas", 0);
            tarihStr = GenelIslemlerIstemci.RequestBul(this, "tarih", "");
            tarihStr2 = GenelIslemlerIstemci.RequestBul(this, "tarih2", "");

            if (!IsPostBack)
            {
                string muhKod = GenelIslemlerIstemci.RequestBul(this, "muhasebe", "");
                string birKod = GenelIslemlerIstemci.RequestBul(this, "birim", "");
                hdnSecKapat.Text = GenelIslemlerIstemci.RequestBul(this, "secKapat", "");
                int cokluSec = GenelIslemlerIstemci.RequestBul(this, "cokluSec", 0);
                if (cokluSec == 1)
                {
                    CheckboxSelectionModel csm = new CheckboxSelectionModel();
                    csm.ID = "csm";
                    grdListe.SelectionModel.Add(csm);
                    grdListe.ColumnModel.Columns[0].Hidden = true;
                    btnSecKapat.Hidden = false;
                    btnSec.Hidden = false;
                }

                if (!string.IsNullOrEmpty(muhKod) && !string.IsNullOrEmpty(birKod) && birKod.Length == 3)
                {
                    var servisORG = TNS.ORG.Arac.Tanimla();
                    OrganizasyonBirim ob = new OrganizasyonBirim();
                    ob.muhasebekodu = muhKod;
                    ob.muhasebebirim = birKod;
                    ObjectArray oa = servisORG.OrganizasyonBirimListele(ob, false, false);
                    if (oa.sonuc.islemSonuc && oa.ObjeSayisi > 0)
                    {
                        ob = (OrganizasyonBirim)oa.objeler[0];
                        if (!kullanan.KullaniciTipiIceriyorMu((int)TNS.KYM.ENUMKullaniciTipi.SISTEMYONETICISI))
                        {
                            ddlBirim.Enabled = false;
                            ddlBirim.Disabled = true;
                        }
                        X.AddScript("ddlBirim_SetValue('{0}', '{1}');", ob.kod.ToString(), ob.adi);
                    }
                }

                ddlBirim.KullanicininBirimleri = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");
            }
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected void PersonelListele(object sender, DirectEventArgs e)
        {
            PersonelListeleIC(sender, e);
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected void PersonelListeleIC(object sender, DirectEventArgs e)
        {
            try
            {
                TNS.IKY.Personel p = new TNS.IKY.Personel();
                p.genelSorgu = txtGenelSorgu.Text;
                p.personelTipleri = personelTip;
                p.aktifDurum = 1;
                if (!string.IsNullOrWhiteSpace(tarihStr))
                {
                    p.aktifTarih = new TNSDateTime(tarihStr);
                    p.aktifTarihSon = new TNSDateTime(tarihStr2);
                    p.aktifTarihSon.AddDays(1);
                    p.aktifTarihTur = 10;
                    p.aktifDurum = -1;
                }
                int birim = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value, 0);
                if (birim > 0)
                {
                    p.kadro.organizasyonKodu = birim;
                }

                ObjectArray liste = servisPER.PersonelListele(kullanan, p, false, true);

                if (!liste.sonuc.islemSonuc)
                    throw new Exception(liste.sonuc.hataStr);

                ListeStore.DataSource = liste.objeler;
                ListeStore.DataBind();
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
            }
        }
    }
}
