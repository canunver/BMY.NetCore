﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelAtama.aspx.cs"
    Inherits="InsanKaynaklari.PersonelAtama" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
    <script type="text/javascript" language="javascript">
        function Degisti() {
            parent.Degisti();
        }

        function DDFieldRenderer(ddFld, eskiDd) {
            var renk;
            if (ddFld.getText() == eskiDd.getValue())
                renk = "black";
            else
                renk = "red";
            ddFld.el.dom.style.color = renk;
        }

        function TextFieldRenderer(txtFld, eskiTxt) {
            var renk;
            if (txtFld.getValue() == eskiTxt.getValue())
                renk = "black";
            else
                renk = "red";
            txtFld.el.dom.style.color = renk;
        }

        function TextFieldRendererDK(txtFld, eskiTxt, yer) {
            var renk;
            if (txtFld.getValue() == eskiTxt.getValue())
                renk = "black";
            else
                renk = "red";
            txtFld.el.dom.style.color = renk;
            Ext1.net.DirectMethods.GostergeHesapla(yer);
        }

        function DateFieldRenderer(dtFld, eskiDt) {
            var renk;
            if ((dtFld.getValue() - eskiDt.getValue()) == 0)
                renk = "black";
            else
                renk = "red";
            dtFld.el.dom.style.color = renk;
        }

        function ComboboxRender(combo, eskiTxt) {
            var renk;
            if (combo.getText() == eskiTxt.getValue())
                renk = "black";
            else
                renk = "red";
            combo.el.dom.style.color = renk;
        }

        function ComboboxRenderVal(combo, eskiHdn) {
            var renk;
            if (combo.getValue() == eskiHdn.getValue())
                renk = "black";
            else
                renk = "red";
            combo.el.dom.style.color = renk;
        }

        function ZorunluAlanKontrol() {
            var isValid = pnlYeniKadro.isValid();
            if (!isValid)
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            return isValid;
        }

        var OrgBirimDoldur = function (node) {
            var orgBirim = { personelMi: 1, yetkiliOlduguMuhasebeBirim: hdnYetkiliBirim.value };
            nodeLoadOrgBirimParam(node, orgBirim);
        };

        function cmbPersonelTipDegisti(deger) {
            Ext1.net.DirectMethods.cmbPersonelTipDegisti(deger);
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <ext:Hidden ID="hdnYetkiliBirim" runat="server" />
        <ext:Hidden ID="hdnPersonelKod" runat="server" />
        <ext:Hidden ID="hdnEskiKadroKod" runat="server" />
        <ext:Hidden ID="hdnYeniPKadroKod" runat="server" />
        <ext:Hidden ID="hdnYeniKadroDurum" runat="server" />
        <ext:Store ID="unvanStore" runat="server">
            <Reader>
                <ext:JsonReader IDProperty="UnvanKod">
                    <Fields>
                        <ext:RecordField Name="UnvanKod" />
                        <ext:RecordField Name="UnvanAd" />
                    </Fields>
                </ext:JsonReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="hizmetKurumuStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="hizmetTuruStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="sinifStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="atamaTuruStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="atamaSekliStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Store ID="ayrilmaNedeniStore" runat="server">
            <Reader>
                <ext:ArrayReader IDProperty="KOD">
                    <Fields>
                        <ext:RecordField Name="KOD" />
                        <ext:RecordField Name="AD" />
                    </Fields>
                </ext:ArrayReader>
            </Reader>
        </ext:Store>
        <ext:Viewport ID="Viewport1" runat="server" Layout="FitLayout">
            <Items>
                <ext:Panel ID="tabPanelAna" runat="server" Layout="RowLayout" Border="true">
                    <TopBar>
                        <ext:Toolbar ID="Toolbar1" runat="server">
                            <Items>
                                <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:Personel, FRMPRK016%>"
                                    Icon="Disk">
                                    <DirectEvents>
                                        <Click OnEvent="btnKaydet_Click" Before="return ZorunluAlanKontrol();">
                                            <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                Title="Onay" />
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                                <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                    Icon="PageWhite">
                                    <DirectEvents>
                                        <Click OnEvent="btnYeniKayit_Click">
                                            <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                        </Click>
                                    </DirectEvents>
                                </ext:Button>
                            </Items>
                        </ext:Toolbar>
                    </TopBar>
                    <Items>
                        <ext:FormPanel runat="server" Height="80" Frame="true" Hidden="true">
                            <Items>
                                <ext:FieldSet runat="server" Title="Personel Bilgisi" Hidden="true">
                                    <Items>
                                        <ext:TextField runat="server" ID="txtKisiBilgi" FieldLabel="Kişi Bilgisi" ReadOnly="true"
                                            AnchorHorizontal="96%" />
                                        <ext:TextField runat="server" ID="txtOkulBilgi" FieldLabel="Okul Bilgisi" ReadOnly="true"
                                            AnchorHorizontal="96%" />
                                    </Items>
                                </ext:FieldSet>
                            </Items>
                        </ext:FormPanel>
                        <ext:Panel ID="Panel2" runat="server" Frame="true" AutoScroll="true" Padding="5"
                            RowHeight="1" Layout="FitLayout">
                            <Items>
                                <ext:Panel runat="server" MinHeight="606" Layout="ColumnLayout" AutoWidth="true">
                                    <Items>
                                        <ext:FormPanel ID="pnlEskiKadro" runat="server" ColumnWidth="0.47" Title="Eski Kadro"
                                            Frame="true" AutoScroll="true">
                                            <Items>
                                                <ext:Hidden ID="hdnPersonelTipEski" runat="server" />
                                                <ext:TextField ID="cmbPersonelTipEski" runat="server" ReadOnly="false" FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS079%>"
                                                    AnchorHorizontal="96%" />
                                                <ext:TextField ID="txtHizmetGrubuEski" runat="server" ReadOnly="false" FieldLabel="Hizmet Grubu"
                                                    AnchorHorizontal="96%" />
                                                <ext:TextField ID="ddlBaslamaGerekcesiEski" runat="server" FieldLabel="Başlangıç Sebebi"
                                                    AnchorHorizontal="96%" ReadOnly="true" DataIndex="sgkSebep" />
                                                <ext:CompositeField runat="server" FieldLabel="Tarih/Açıklama" AnchorHorizontal="96%"
                                                    LabelWidth="0" HideLabels="true">
                                                    <Items>
                                                        <ext:DateField ID="txtAtamaTarihiEski" runat="server" FieldLabel="Tarihi" Width="90"
                                                            ReadOnly="true" DataIndex="atamaTarihi" />
                                                        <ext:TextField ID="txtAtamaNedeniEski" runat="server" FieldLabel="Nedeni" Flex="1"
                                                            ReadOnly="true" DataIndex="atamaNedeni" />
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:TextField ID="txtGorevYeriEski" runat="server" AnchorHorizontal="96%" FieldLabel="Görev Yeri"
                                                    ReadOnly="true" Hidden="true" />
                                                <ext:TextField ID="ddlBirimEski" runat="server" FieldLabel="Kadro Birimi" AnchorHorizontal="96%"
                                                    ReadOnly="true" DataIndex="birimAd" />
                                                <ext:TextField ID="ddlGorevBirimEski" runat="server" FieldLabel="Görev Yeri" AnchorHorizontal="96%"
                                                    ReadOnly="true" DataIndex="birimAd" />
                                                <ext:TextField ID="ddlUnvanEski" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK050 %>"
                                                    AnchorHorizontal="96%" ReadOnly="true" />
                                                <ext:TextField ID="ddlVekaletUnvaniEski" runat="server" FieldLabel="Vekil Unvanı"
                                                    AnchorHorizontal="96%" ReadOnly="true" />
                                                <ext:CompositeField ID="CompositeField5" runat="server" FieldLabel="Evrak" ReadOnly="true"
                                                    AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtEvrakNoEski" runat="server" Width="80" Note="<%$ Resources:InsanKaynaklari,FRMPRK052 %>"
                                                            NoteAlign="Top" />
                                                        <ext:TextField ID="txtYasalDayanakEski" runat="server" Width="80" Note="<%$ Resources:InsanKaynaklari,FRMPRK053 %>"
                                                            NoteAlign="Top" />
                                                        <ext:DateField ID="txtOnayTarihEski" runat="server" Width="80" Note="Onay Tarihi"
                                                            NoteAlign="Top" />
                                                        <ext:TextField ID="txtMeslekKoduEski" runat="server" Width="80" Note="Meslek Kodu"
                                                            NoteAlign="Top" />
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:TextField ID="txtAciklamaEski" runat="server" Width="310" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK014 %>"
                                                    NoteAlign="Top" ReadOnly="true" />
                                                <ext:CompositeField ID="CompositeField6" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK055 %>"
                                                    ReadOnly="true" AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtKadroDereceEski" runat="server" Width="50" Note="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                                            NoteAlign="Top" />
                                                        <ext:Label ID="Label5" runat="server" Width="50" Text="Kademe" />
                                                        <ext:DateField ID="txtKadroTarihEski" runat="server" Width="90" Note="<%$ Resources:InsanKaynaklari,FRMPRK057 %>"
                                                            NoteAlign="Top" />
                                                        <ext:Label ID="Label6" runat="server" Width="50" Text="<%$ Resources:InsanKaynaklari,FRMPRK058 %>" />
                                                        <ext:Label ID="Label7" runat="server" Width="70" Text="<%$ Resources:InsanKaynaklari,FRMPRK059 %>" />
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:CompositeField ID="CompositeField8" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK060 %>"
                                                    ReadOnly="true" AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtKazanilmisHakDereceEski" runat="server" Width="50" />
                                                        <ext:TextField ID="txtKazanilmisHakKademeEski" runat="server" Width="50" />
                                                        <ext:DateField ID="txtKazanilmisHakTarihEski" runat="server" Width="90" />
                                                        <ext:TextField ID="txtKazanilmisGostergeEski" runat="server" Width="50" />
                                                        <ext:TextField ID="txtKazanilmisEkGostergeEski" runat="server" Width="50" />
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:CompositeField ID="CompositeField10" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK062 %>"
                                                    ReadOnly="true" AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtEmekliyeEsasDereceEski" runat="server" Width="50" />
                                                        <ext:TextField ID="txtEmekliyeEsasKademeEski" runat="server" Width="50" />
                                                        <ext:DateField ID="txtEmekliyeEsasTarihEski" runat="server" Width="90" />
                                                        <ext:TextField ID="txtEmekliGostergeEski" runat="server" Width="50" />
                                                        <ext:TextField ID="txtEmekliEkGostergeEski" runat="server" Width="50" />
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:CompositeField ID="CompositeField9" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK061 %>"
                                                    ReadOnly="true" AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtOdemeyeEsasDereceEski" runat="server" Width="50" />
                                                        <ext:TextField ID="txtOdemeyeEsasKademeEski" runat="server" Width="50" />
                                                        <ext:DateField ID="txtOdemeyeEsasTarihEski" runat="server" Width="90" />
                                                        <ext:TextField ID="txtOdemeyeEsasGostergeEski" runat="server" Width="50" />
                                                        <ext:TextField ID="txtOdemeyeEsasEkGostergeEski" runat="server" Width="50" />
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:FieldSet ID="FieldSet1" runat="server" Title="Ayrılış">
                                                    <Items>
                                                        <ext:TextField ID="ddlAyrilmaGerekcesiEski" runat="server" FieldLabel="Sebebi" AnchorHorizontal="96%"
                                                            ReadOnly="true" />
                                                        <ext:TextField ID="txtAyrilmaNedeniEski" runat="server" FieldLabel="Ayrılma Nedeni"
                                                            AnchorHorizontal="96%" ReadOnly="true" />
                                                        <ext:DateField ID="txtAyrilmaTarihiEski" runat="server" Width="90" FieldLabel="Ayrılma Tarihi"
                                                            ReadOnly="true" />
                                                        <ext:Label ID="Label1" runat="server" Width="80" FieldLabel="Gid. Birim" />
                                                        <ext:TextField ID="txtHizmetGunuEski" runat="server" Width="80" FieldLabel="Hizmet Gün Sayısı"
                                                            ReadOnly="true" />
                                                    </Items>
                                                </ext:FieldSet>
                                                <ext:Label ID="lblAtanacagiKadro" runat="server" Width="80" FieldLabel="Atanacağı Kadro" />
                                            </Items>
                                        </ext:FormPanel>
                                        <ext:FormPanel ID="pnlYeniKadro" runat="server" ColumnWidth="0.53" Title="Yeni Kadro"
                                            Frame="true" AutoScroll="true" MonitorValid="true" HideLabels="true" LabelWidth="0">
                                            <Items>
                                                <ext:ComboBox ID="cmbPersonelTip" runat="server" Editable="false" TypeAhead="true"
                                                    Mode="Local" ForceSelection="true" SelectOnFocus="true" DisplayField="ad" ValueField="kod"
                                                    FieldLabel="<%$Resources:InsanKaynaklari,FRMPKS079%>" AnchorHorizontal="96%">
                                                    <Store>
                                                        <ext:Store ID="personelTipStore" runat="server">
                                                            <Reader>
                                                                <ext:JsonReader IDProperty="kod">
                                                                    <Fields>
                                                                        <ext:RecordField Name="kod" Type="Int" />
                                                                        <ext:RecordField Name="ad" />
                                                                    </Fields>
                                                                </ext:JsonReader>
                                                            </Reader>
                                                        </ext:Store>
                                                    </Store>
                                                    <Listeners>
                                                        <AfterRender Handler="return ComboboxRenderVal(cmbPersonelTip, hdnPersonelTipEski);" />
                                                        <Change Handler="cmbPersonelTipDegisti(cmbPersonelTip.getValue()); return ComboboxRenderVal(cmbPersonelTip, hdnPersonelTipEski);" />
                                                    </Listeners>
                                                </ext:ComboBox>
                                                <ext:TextField ID="txtHizmetGrubuYeni" runat="server" ReadOnly="false" FieldLabel="Hizmet Grubu/Kurumu"
                                                    AnchorHorizontal="96%" />
                                                <ext:ComboBox ID="ddlBaslamaGerekcesi" runat="server" TypeAhead="true" Mode="Local"
                                                    ForceSelection="true" SelectOnFocus="true" DisplayField="ad" ValueField="kod"
                                                    FieldLabel="Sebebi" AnchorHorizontal="96%" DataIndex="sgkSebep">
                                                    <Store>
                                                        <ext:Store ID="sgkSebepStoreGir" runat="server">
                                                            <Reader>
                                                                <ext:JsonReader IDProperty="kod">
                                                                    <Fields>
                                                                        <ext:RecordField Name="kod" Type="String" />
                                                                        <ext:RecordField Name="ad" Type="String" />
                                                                    </Fields>
                                                                </ext:JsonReader>
                                                            </Reader>
                                                        </ext:Store>
                                                    </Store>
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Clear" />
                                                    </Triggers>
                                                    <Listeners>
                                                        <TriggerClick Handler="ddlBaslamaGerekcesi.clear()" />
                                                        <AfterRender Handler="return ComboboxRender(ddlBaslamaGerekcesi, ddlBaslamaGerekcesiEski);" />
                                                        <Change Handler="return ComboboxRender(ddlBaslamaGerekcesi, ddlBaslamaGerekcesiEski);" />
                                                    </Listeners>
                                                </ext:ComboBox>
                                                <ext:CompositeField runat="server" FieldLabel="Tarih/Açıklama" AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:DateField ID="txtAtamaTarihi" runat="server" FieldLabel="Tarihi" Width="90"
                                                            DataIndex="atamaTarihi">
                                                            <Listeners>
                                                                <AfterRender Handler="return DateFieldRenderer(txtAtamaTarihi, txtAtamaTarihiEski);" />
                                                                <Change Handler="return DateFieldRenderer(txtAtamaTarihi, txtAtamaTarihiEski);" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                        <ext:TextField ID="txtAtamaNedeni" runat="server" FieldLabel="Nedeni" Flex="1" DataIndex="atamaNedeni">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtAtamaNedeni, txtAtamaNedeniEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtAtamaNedeni, txtAtamaNedeniEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:TextField ID="txtGorevYeri" runat="server" AnchorHorizontal="96%" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM005 %>"
                                                    Hidden="true">
                                                    <Listeners>
                                                        <AfterRender Handler="return TextFieldRenderer(txtGorevYeri, txtGorevYeriEski);" />
                                                        <Change Handler="return TextFieldRenderer(txtGorevYeri, txtGorevYeriEski);" />
                                                    </Listeners>
                                                </ext:TextField>
                                                <ext:ExtOrgSecim ID="ddlBirim" runat="server" AnchorHorizontal="96%" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>"
                                                    DataIndex="birimAd">
                                                    <Listeners>
                                                        <AfterRender Handler="return DDFieldRenderer(ddlBirim, ddlBirimEski);" />
                                                        <Change Handler="return DDFieldRenderer(ddlBirim, ddlBirimEski);" />
                                                    </Listeners>
                                                </ext:ExtOrgSecim>
                                                <ext:ExtOrgSecim ID="ddlGorevBirim" runat="server" AnchorHorizontal="96%" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRM026%>"
                                                    DataIndex="birimAd">
                                                    <Listeners>
                                                        <AfterRender Handler="return DDFieldRenderer(ddlGorevBirim, ddlGorevBirimEski);" />
                                                        <Change Handler="return DDFieldRenderer(ddlGorevBirim, ddlGorevBirimEski);" />
                                                    </Listeners>
                                                </ext:ExtOrgSecim>
                                                <ext:ComboBox ID="ddlUnvan" runat="server" Editable="true" TypeAhead="true" Mode="Local"
                                                    ForceSelection="true" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK050 %>"
                                                    AnchorHorizontal="96%" StoreID="unvanStore" DisplayField="UnvanAd" ValueField="UnvanKod"
                                                    SelectOnFocus="true">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Clear" />
                                                    </Triggers>
                                                    <Listeners>
                                                        <TriggerClick Handler="ddlUnvan.clear()" />
                                                        <AfterRender Handler="return ComboboxRender(ddlUnvan, ddlUnvanEski);" />
                                                        <Change Handler="return ComboboxRender(ddlUnvan, ddlUnvanEski);" />
                                                    </Listeners>
                                                </ext:ComboBox>
                                                <ext:ComboBox ID="ddlVekaletUnvani" runat="server" TypeAhead="true" Mode="Local"
                                                    ForceSelection="true" FieldLabel="Görünen Unvani" AnchorHorizontal="96%" StoreID="unvanStore"
                                                    DisplayField="UnvanAd" ValueField="UnvanKod" SelectOnFocus="true">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Clear" />
                                                    </Triggers>
                                                    <Listeners>
                                                        <TriggerClick Handler="ddlVekaletUnvani.clear()" />
                                                        <AfterRender Handler="return ComboboxRender(ddlVekaletUnvani, ddlVekaletUnvaniEski);" />
                                                        <Change Handler="return ComboboxRender(ddlVekaletUnvani, ddlVekaletUnvaniEski);" />
                                                    </Listeners>
                                                </ext:ComboBox>
                                                <ext:CompositeField ID="CompositeField7" runat="server" FieldLabel="Evrak" AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtEvrakNo" runat="server" Width="90" Note="<%$ Resources:InsanKaynaklari,FRMPRK052 %>"
                                                            NoteAlign="Top">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtEvrakNo, txtEvrakNoEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtEvrakNo, txtEvrakNoEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:TextField ID="txtYasalDayanak" runat="server" Width="120" Note="<%$ Resources:InsanKaynaklari,FRMPRK053 %>"
                                                            NoteAlign="Top">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtYasalDayanak, txtYasalDayanakEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtYasalDayanak, txtYasalDayanakEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:DateField ID="txtOnayTarih" runat="server" Width="90" Note="Onay Tarihi" NoteAlign="Top">
                                                            <Listeners>
                                                                <AfterRender Handler="return DateFieldRenderer(txtOnayTarih, txtOnayTarihEski);" />
                                                                <Change Handler="return DateFieldRenderer(txtOnayTarih, txtOnayTarihEski);" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                        <ext:TextField ID="txtMeslekKodu" runat="server" Width="80" Note="Meslek Kodu"
                                                            NoteAlign="Top">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtMeslekKodu, txtMeslekKoduEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtMeslekKodu, txtMeslekKoduEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:TextField ID="txtAciklama" runat="server" AnchorHorizontal="96%" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK014 %>"
                                                    NoteAlign="Top">
                                                    <Listeners>
                                                        <AfterRender Handler="return TextFieldRenderer(txtAciklama, txtAciklamaEski);" />
                                                        <Change Handler="return TextFieldRenderer(txtAciklama, txtAciklamaEski);" />
                                                    </Listeners>
                                                </ext:TextField>
                                                <ext:CompositeField ID="CompositeField4" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK055 %>"
                                                    AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtKadroDerece" runat="server" Width="50" Note="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                                            NoteAlign="Top">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtKadroDerece, txtKadroDereceEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtKadroDerece, txtKadroDereceEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:Label ID="Label2" runat="server" Width="50" Text="Kademe" />
                                                        <ext:DateField ID="txtKadroTarih" runat="server" Width="90" Note="<%$ Resources:InsanKaynaklari,FRMPRK057 %>"
                                                            NoteAlign="Top">
                                                            <Listeners>
                                                                <AfterRender Handler="return DateFieldRenderer(txtKadroTarih, txtKadroTarihEski);" />
                                                                <Change Handler="return DateFieldRenderer(txtKadroTarih, txtKadroTarihEski);" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                        <ext:Label ID="Label3" runat="server" Width="50" Text="<%$ Resources:InsanKaynaklari,FRMPRK058 %>" />
                                                        <ext:Label ID="Label4" runat="server" Width="70" Text="<%$ Resources:InsanKaynaklari,FRMPRK059 %>" />
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:CompositeField ID="CompositeField2" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK060 %>"
                                                    AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtKazanilmisHakDerece" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtKazanilmisHakDerece, txtKazanilmisHakDereceEski);" />
                                                                <Change Handler="return TextFieldRendererDK(txtKazanilmisHakDerece, txtKazanilmisHakDereceEski, 1);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:TextField ID="txtKazanilmisHakKademe" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtKazanilmisHakKademe, txtKazanilmisHakKademeEski);" />
                                                                <Change Handler="return TextFieldRendererDK(txtKazanilmisHakKademe, txtKazanilmisHakKademeEski, 1);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:DateField ID="txtKazanilmisHakTarih" runat="server" Width="90">
                                                            <Listeners>
                                                                <AfterRender Handler="return DateFieldRenderer(txtKazanilmisHakTarih, txtKazanilmisHakTarihEski);" />
                                                                <Change Handler="return DateFieldRenderer(txtKazanilmisHakTarih, txtKazanilmisHakTarihEski);" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                        <ext:TextField ID="txtKazanilmisGosterge" runat="server" Width="50" ReadOnly="true" />
                                                        <ext:TextField ID="txtKazanilmisEkGosterge" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtKazanilmisEkGosterge, txtKazanilmisEkGostergeEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtKazanilmisEkGosterge, txtKazanilmisEkGostergeEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:CompositeField ID="CompositeField3" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK062 %>"
                                                    AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtEmekliyeEsasDerece" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtEmekliyeEsasDerece, txtEmekliyeEsasDereceEski);" />
                                                                <Change Handler="return TextFieldRendererDK(txtEmekliyeEsasDerece, txtEmekliyeEsasDereceEski, 2);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:TextField ID="txtEmekliyeEsasKademe" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtEmekliyeEsasKademe, txtEmekliyeEsasKademeEski);" />
                                                                <Change Handler="return TextFieldRendererDK(txtEmekliyeEsasKademe, txtEmekliyeEsasKademeEski, 2);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:DateField ID="txtEmekliyeEsasTarih" runat="server" Width="90">
                                                            <Listeners>
                                                                <AfterRender Handler="return DateFieldRenderer(txtEmekliyeEsasTarih, txtEmekliyeEsasTarihEski);" />
                                                                <Change Handler="return DateFieldRenderer(txtEmekliyeEsasTarih, txtEmekliyeEsasTarihEski);" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                        <ext:TextField ID="txtEmekliGosterge" runat="server" Width="50" ReadOnly="true" />
                                                        <ext:TextField ID="txtEmekliEkGosterge" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtEmekliEkGosterge, txtEmekliEkGostergeEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtEmekliEkGosterge, txtEmekliEkGostergeEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:CompositeField ID="CompositeField1" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPRK061 %>"
                                                    AnchorHorizontal="96%">
                                                    <Items>
                                                        <ext:TextField ID="txtOdemeyeEsasDerece" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtOdemeyeEsasDerece, txtOdemeyeEsasDereceEski);" />
                                                                <Change Handler="return TextFieldRendererDK(txtOdemeyeEsasDerece, txtOdemeyeEsasDereceEski, 3);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:TextField ID="txtOdemeyeEsasKademe" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtOdemeyeEsasKademe, txtOdemeyeEsasKademeEski);" />
                                                                <Change Handler="return TextFieldRendererDK(txtOdemeyeEsasKademe, txtOdemeyeEsasKademeEski, 3);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:DateField ID="txtOdemeyeEsasTarih" runat="server" Width="90">
                                                            <Listeners>
                                                                <AfterRender Handler="return DateFieldRenderer(txtOdemeyeEsasTarih, txtOdemeyeEsasTarihEski);" />
                                                                <Change Handler="return DateFieldRenderer(txtOdemeyeEsasTarih, txtOdemeyeEsasTarihEski);" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                        <ext:TextField ID="txtOdemeyeEsasGosterge" runat="server" Width="50" ReadOnly="true" />
                                                        <ext:TextField ID="txtOdemeyeEsasEkGosterge" runat="server" Width="50">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtOdemeyeEsasEkGosterge, txtOdemeyeEsasEkGostergeEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtOdemeyeEsasEkGosterge, txtOdemeyeEsasEkGostergeEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                    </Items>
                                                </ext:CompositeField>
                                                <ext:FieldSet runat="server" Title="Ayrılış">
                                                    <Items>
                                                        <ext:ComboBox ID="ddlAyrilmaGerekcesi" runat="server" TypeAhead="true" Mode="Local"
                                                            ForceSelection="true" SelectOnFocus="true" DisplayField="ad" ValueField="kod"
                                                            FieldLabel="Sebebi" AnchorHorizontal="96%" DataIndex="ayrilmaGerekce">
                                                            <Store>
                                                                <ext:Store ID="sgkSebepStoreCik" runat="server">
                                                                    <Reader>
                                                                        <ext:JsonReader IDProperty="kod">
                                                                            <Fields>
                                                                                <ext:RecordField Name="kod" Type="String" />
                                                                                <ext:RecordField Name="ad" Type="String" />
                                                                            </Fields>
                                                                        </ext:JsonReader>
                                                                    </Reader>
                                                                </ext:Store>
                                                            </Store>
                                                            <Triggers>
                                                                <ext:FieldTrigger Icon="Clear" />
                                                            </Triggers>
                                                            <Listeners>
                                                                <TriggerClick Handler="ddlAyrilmaGerekcesi.clear()" />
                                                                <AfterRender Handler="return ComboboxRender(ddlAyrilmaGerekcesi, ddlAyrilmaGerekcesiEski);" />
                                                                <Change Handler="return ComboboxRender(ddlAyrilmaGerekcesi, ddlAyrilmaGerekcesiEski);" />
                                                            </Listeners>
                                                        </ext:ComboBox>
                                                        <ext:TextField ID="txtAyrilmaNedeni" runat="server" FieldLabel="Ayrılma Nedeni" AnchorHorizontal="96%">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtAyrilmaNedeni, txtAyrilmaNedeniEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtAyrilmaNedeni, txtAyrilmaNedeniEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                        <ext:DateField ID="txtAyrilmaTarihi" runat="server" Width="90" FieldLabel="Ayrılma Tarihi">
                                                            <Listeners>
                                                                <AfterRender Handler="return DateFieldRenderer(txtAyrilmaTarihi, txtAyrilmaTarihiEski);" />
                                                                <Change Handler="return DateFieldRenderer(txtAyrilmaTarihi, txtAyrilmaTarihiEski);" />
                                                            </Listeners>
                                                        </ext:DateField>
                                                        <ext:ExtOrgSecim ID="ddlTayinOlacagiBirim" runat="server" AnchorHorizontal="96%" FieldLabel="Gid. Birim"
                                                            DataIndex="tayinOlacagiBirim">
                                                        </ext:ExtOrgSecim>
                                                        <ext:TextField ID="txtHizmetGunu" runat="server" Width="80" FieldLabel="Hizmet Gün Sayısı">
                                                            <Listeners>
                                                                <AfterRender Handler="return TextFieldRenderer(txtHizmetGunu, txtHizmetGunuEski);" />
                                                                <Change Handler="return TextFieldRenderer(txtHizmetGunu, txtHizmetGunuEski);" />
                                                            </Listeners>
                                                        </ext:TextField>
                                                    </Items>
                                                </ext:FieldSet>
                                                <ext:Hidden runat="server" ID="hdnIliskiliKadroIslemNo" />
                                                <ext:ComboBox ID="cmbAtanacagiKadro" runat="server" TypeAhead="true" Mode="Local"
                                                    ForceSelection="true" SelectOnFocus="true" DisplayField="Aciklama" ValueField="ID"
                                                    FieldLabel="Atanacağı Kadro" AnchorHorizontal="96%">
                                                    <Triggers>
                                                        <ext:FieldTrigger Icon="Clear" />
                                                    </Triggers>
                                                    <Listeners>
                                                        <TriggerClick Handler="cmbAtanacagiKadro.clear()" />
                                                    </Listeners>
                                                    <Store>
                                                        <ext:Store runat="server" ID="stoAtanacagiKadro">
                                                            <Reader>
                                                                <ext:JsonReader IDProperty="ID">
                                                                    <Fields>
                                                                        <ext:RecordField Name="ID" Type="String" />
                                                                        <ext:RecordField Name="Aciklama" Type="String" />
                                                                    </Fields>
                                                                </ext:JsonReader>
                                                            </Reader>
                                                        </ext:Store>
                                                    </Store>
                                                </ext:ComboBox>
                                            </Items>
                                        </ext:FormPanel>
                                    </Items>
                                </ext:Panel>
                            </Items>
                        </ext:Panel>
                    </Items>
                </ext:Panel>
            </Items>
        </ext:Viewport>
    </form>
</body>
</html>
