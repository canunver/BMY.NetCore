﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelKurs.aspx.cs" Inherits="InsanKaynaklari.PersonelKurs" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        var KomutCalistir = function (command, record, row) {
            if (command == 'BelgeSil') {
                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
                function (btn) {
                    if (btn == "yes") {
                        Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
                    }
                });
            }
            else if (command == 'BelgeGoster')
                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        };
        function ZorunluAlanKontrol() {
            if (!FPanel1.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return FPanel1.isValid();
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden runat="server" ID="hdnKod" />
    <ext:Hidden ID="hdnPKod" runat="server" />
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KURSKODU" />
                    <ext:RecordField Name="TARIH" />
                    <ext:RecordField Name="ALDIGIYER" />
                    <ext:RecordField Name="BASLAMATARIH" Type="Date" />
                    <ext:RecordField Name="BITIRMETARIH" Type="Date" />
                    <ext:RecordField Name="PUAN" />
                    <ext:RecordField Name="DERECE" />
                    <ext:RecordField Name="KURSADI" />
                    <ext:RecordField Name="DERSSAATI" />
                    <ext:RecordField Name="EGITIMYERI" />
                    <ext:RecordField Name="YIL" />
                    <ext:RecordField Name="DONEM" />
                    <ext:RecordField Name="GUN" />
                    <ext:RecordField Name="DOSYANO" />
                    <ext:RecordField Name="ACIKLAMA" />
                </Fields>
            </ext:JsonReader>
        </Reader>
        <SortInfo Field="BITIRMETARIH" Direction="DESC" />
    </ext:Store>
    <ext:Store ID="StoreKurs" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="StoreEgitimYeri" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click" ViewStateMode="Enabled" Before="return ZorunluAlanKontrol();">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="<%$ Resources:InsanKaynaklari,FRMORT079 %>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                Icon="Delete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                            Title="<%$ Resources:InsanKaynaklari,FRMORT079 %>" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnTemizle_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="Button1" Icon="Lightbulb" runat="server">
                                <Listeners>
                                    <MouseOver Handler="wndYardim.show();" />
                                    <MouseOut Handler="wndYardim.hide();" />
                                </Listeners>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="FPanel1" runat="server" Frame="true" Padding="5" LabelWidth="130" AutoScroll="true"
                        Region="Center">
                        <Items>
                            <ext:ComboBox ID="ddlKurs" runat="server" Editable="true" TypeAhead="false" Mode="Local"
                                ForceSelection="true" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK001%>"
                                AnchorHorizontal="96%" StoreID="StoreKurs" DisplayField="AD" ValueField="KOD" SelectOnFocus="true">
                            </ext:ComboBox>
                            <ext:TextField ID="txtKursAdi" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK002%>"
                                AnchorHorizontal="96%">
                            </ext:TextField>
                            <ext:DateField ID="dfTarih" runat="server" FieldLabel="tarih" Hidden="true">
                            </ext:DateField>
                            <ext:CompositeField ID="CompositeField1" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK045%>" AnchorHorizontal="96%">
                                <Items>
                                    <ext:DateField ID="txtBaslamaTarihi" runat="server" Note="<%$ Resources:InsanKaynaklari, FRMPRK004%>"
                                        NoteAlign="Top" Vtype="daterange">
                                        <CustomConfig>
                                            <ext:ConfigItem Name="endDateField" Value="#{txtBitirmeTarihi}" Mode="Value" />
                                        </CustomConfig>
                                    </ext:DateField>
                                    <ext:DateField ID="txtBitirmeTarihi" runat="server" Note="<%$ Resources:InsanKaynaklari, FRMPRK005%>"
                                        NoteAlign="Top" Vtype="daterange">
                                        <CustomConfig>
                                            <ext:ConfigItem Name="startDateField" Value="#{txtBaslamaTarihi}" Mode="Value" />
                                        </CustomConfig>
                                    </ext:DateField>
                                </Items>
                            </ext:CompositeField>
                            <ext:TextField ID="txtAlinanYer" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK012%>"
                                AnchorHorizontal="96%">
                            </ext:TextField>
                            <ext:ComboBox ID="ddlOgrenimYeri" runat="server" Editable="true" TypeAhead="false"
                                ForceSelection="false" FieldLabel="<%$ Resources:InsanKaynaklari,FRMPOG052 %>"
                                AnchorHorizontal="96%" StoreID="StoreEgitimYeri" DisplayField="AD" ValueField="KOD" SelectOnFocus="true">
                            </ext:ComboBox>
                            <ext:CompositeField ID="CompositeField2" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK044%>" AnchorHorizontal="96%">
                                <Items>
                                    <ext:TextField ID="txtGun" runat="server" Note="<%$ Resources:InsanKaynaklari, FRMPRK006%>"
                                        Width="100" NoteAlign="Top">
                                    </ext:TextField>
                                    <ext:TextField ID="txtDersSaati" runat="server" Note="<%$ Resources:InsanKaynaklari, FRMPRK007%>"
                                        Width="100" NoteAlign="Top">
                                    </ext:TextField>
                                </Items>
                            </ext:CompositeField>
                            <ext:CompositeField ID="CompositeField4" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK046%>" AnchorHorizontal="96%">
                                <Items>
                                    <ext:ComboBox ID="ddlYil" runat="server" Note="<%$ Resources:InsanKaynaklari, FRMPRK008%>"
                                        Width="100" NoteAlign="Top">
                                    </ext:ComboBox>
                                    <ext:ComboBox ID="ddlDonem" runat="server" Note="<%$ Resources:InsanKaynaklari, FRMPRK009%>"
                                        Width="100" NoteAlign="Top">
                                        <Items>
                                            <ext:ListItem Text="" Value="" />
                                            <ext:ListItem Text="<%$ Resources:InsanKaynaklari, FRMPRK010%>" Value="I. 6 Aylık" />
                                            <ext:ListItem Text="<%$ Resources:InsanKaynaklari, FRMPRK011%>" Value="II. 6 Aylık" />
                                        </Items>
                                    </ext:ComboBox>
                                </Items>
                            </ext:CompositeField>
                            <ext:TextField ID="txtDerece" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK074%>"
                                Width="100" >
                            </ext:TextField>
                            <ext:TextField ID="txtPuan" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK015%>"
                                Width="100" >
                            </ext:TextField>
                            <ext:TextField ID="txtDosyaNo" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK003%>"
                                Width="100" >
                            </ext:TextField>
                            <ext:TextArea ID="txtAciklama" runat="server" FieldLabel="<%$ Resources:InsanKaynaklari, FRMPRK014%>"
                                AnchorHorizontal="96%" Height="40">
                            </ext:TextArea>
                            <ext:GridPanel ID="gridBelgeler" runat="server" StripeRows="true" Header="false"
                                Frame="true" FieldLabel="Belgeler" TrackMouseOver="true" StoreID="BelgeStore"
                                HideLabel="true" HideHeaders="true" AutoHeight="true" AnchorHorizontal="96%">
                                <ColumnModel>
                                    <Columns>
                                        <ext:RowNumbererColumn />
                                        <ext:Column ColumnID="BELGEADI" DataIndex="BELGEADI" Header="<%$ Resources:InsanKaynaklari,FRMORT063 %>"
                                            Width="250" />
                                        <ext:CommandColumn Width="30">
                                            <Commands>
                                                <ext:GridCommand Icon="PageWhiteMagnify" CommandName="BelgeGoster" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMORT064 %>" />
                                            </Commands>
                                        </ext:CommandColumn>
                                        <ext:CommandColumn Width="30">
                                            <Commands>
                                                <ext:GridCommand Icon="PageWhiteDelete" CommandName="BelgeSil" ToolTip-Text="<%$ Resources:InsanKaynaklari,FRMORT065 %>" />
                                            </Commands>
                                        </ext:CommandColumn>
                                    </Columns>
                                </ColumnModel>
                                <Listeners>
                                    <Command Fn="KomutCalistir" />
                                </Listeners>
                                <SelectionModel>
                                    <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                    </ext:RowSelectionModel>
                                </SelectionModel>
                                <TopBar>
                                    <ext:Toolbar ID="Toolbar2" runat="server">
                                        <Items>
                                            <ext:FileUploadField ID="btnDosyaYukle" runat="server" ButtonOnly="true" Icon="PageWhiteAdd"
                                                ButtonText="Belge Ekle">
                                                <DirectEvents>
                                                    <FileSelected IsUpload="true" OnEvent="BelgeKaydet" />
                                                </DirectEvents>
                                            </ext:FileUploadField>
                                        </Items>
                                    </ext:Toolbar>
                                </TopBar>
                            </ext:GridPanel>
                        </Items>
                    </ext:FormPanel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" Width="400" AutoExpandColumn="KURSADI"
                        Border="true" Region="East">
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column ColumnID="KURSADI" DataIndex="KURSADI" Header="<%$ Resources:InsanKaynaklari,FRMPRK020 %>" />
                                <ext:DateColumn ColumnID="BASLAMATARIH" DataIndex="BASLAMATARIH" Header="<%$ Resources:InsanKaynaklari,FRMPRK004 %>"
                                    Format="dd/m/Y" />
                                <ext:DateColumn ColumnID="BITIRMETARIH" DataIndex="BITIRMETARIH" Header="<%$ Resources:InsanKaynaklari, FRMPRK005 %>"
                                    Format="dd/m/Y" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                <DirectEvents>
                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                        <ExtraParams>
                                            <ext:Parameter Name="RowValue" Value="Ext1.encode(#{grdListe}.getRowsValues({selectedOnly:true}))"
                                                Mode="Raw" />
                                        </ExtraParams>
                                    </RowSelect>
                                </DirectEvents>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <ext:Window ID="wndYardim" runat="server" Hidden="true" Closable="false" Frame="true"
        Width="380" Height="140" X="220" Y="10">
        <Items>
            <ext:Label ID="Label1" runat="server" Icon="Lightbulb" Text="Memuriyet sırasında aldığınız kurs, seminer veya verdiğiniz eğitimleri sırasıyla bilgilerini girerek kayıt ediniz. Kaydedip bitirdiğiniz bilgilerden sonra yine bu formu kullanarak başka eğitim bilgileri kayıtlarınızı yapabilirsiniz. Başlama ve bitiş tarihlerini tam olarak bilemiyorsanız 01.01.YIL olarak giriş yapabilirsiniz." />
        </Items>
    </ext:Window>
    </form>
</body>
</html>
