﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using Ext1.Net;
using OrtakClass;
using TNS;
using TNS.IKY;
using TNS.UZY;
using TNS.ORG;

namespace InsanKaynaklari
{
    /// <summary>
    /// Personel Bilgi Sınıfı
    /// </summary>
    public partial class LojmanSiteYetki : istemciUzayi.GenelSayfa
    {
        IIKYServis servisIKY = TNS.IKY.Arac.Tanimla();

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            if (!IsPostBack)
            {
                hdnYetkiliBirim.Text = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");
                trpBirim.Listeners.BeforeLoad.Fn = "OrgBirimDoldur";
                Genel.UnvanDoldur(servisIKY, this, storeUnvan);
                hdnSiteKod.Value = (Request.QueryString["siteKod"] + "").Trim();
                Genel.SozlukDoldur(ddlYetkiTip, yetkiTipStore, OrtakFonksiyonlar.ConvertToInt(ENUMSozlukUnsurlari.SITEYONETICITIPI, 0).ToString().PadLeft(2, '0'), false);
            }
        }

        /// <summary>
        /// Personels the liste yenile.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Ext1.Net.StoreRefreshDataEventArgs"/> instance containing the event data.</param>
        protected void PersonelListele(object sender, DirectEventArgs e)
        {
            try
            {
                TNS.IKY.Personel p = new TNS.IKY.Personel();
                p.genelSorgu = txtGenelSorgu.Text;
                p.kadro.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value.ToString(), 0);
                p.kadro.unvan = OrtakFonksiyonlar.ConvertToInt(cmbUnvan.Value, 0);

                ObjectArray liste = servisIKY.PersonelListele(kullanan, p, false, true);

                if (!liste.sonuc.islemSonuc)
                    throw new Exception(liste.sonuc.hataStr);

                ArrayList extListe = new ArrayList();
                foreach (TNS.IKY.Personel per in liste.objeler)
                    extListe.Add(new object[] { per.kod, per.ad + ' ' + per.soyad, per.tcKimlikNo, per.sicilNo, per.kadro.birimAd, per.kadro.unvanAd, per.kadro.kadroDerece, per.kadro.kadroTarih.ToString(), per.kadro.kadroDurumAd, per.personelTipAd });

                ListeStore.DataSource = (object[])extListe.ToArray(typeof(object[]));
                ListeStore.DataBind();
            }
            catch (Exception ex)
            {
                GenelIslemler.MesajKutusu("Hata", ex.Message);
            }
        }

        public void YetkiListesi(object sender, DirectEventArgs e)
        {
            TNS.IKY.Personel p = new TNS.IKY.Personel();
            p.genelSorgu = txtGenelSorgu.Text;
            p.kadro.organizasyonKodu = OrtakFonksiyonlar.ConvertToInt(ddlBirim.Value.ToString(), 0);
            p.kadro.unvan = OrtakFonksiyonlar.ConvertToInt(cmbUnvan.Value, 0);

            ObjectArray list = servisIKY.PersonelLojmanliListele(kullanan, p);
            yetkiListeStore.DataSource = list.objeler;
            yetkiListeStore.DataBind();
        }

        protected void btnYetkiKaydet_Click(object sender, DirectEventArgs e)
        {
            string hata = "";
            if (OrtakFonksiyonlar.ConvertToInt(hdnSiteKod.Value, 0) == 0)
                hata += "Site bilgisi olmadığından kayıt yapamazsınız.";

            if (hata != "")
            {
                GenelIslemler.MesajKutusu(this, hata);
                return;
            }

            string listeBilgileri = e.ExtraParams["YetkiListeBilgileri"];
            Newtonsoft.Json.Linq.JObject[] satirlar = (Newtonsoft.Json.Linq.JObject[])JSON.Deserialize(listeBilgileri, typeof(Newtonsoft.Json.Linq.JObject[]));

            //if (listeBilgileri.Trim().Length > 0)
            //{
            if (satirlar.Length > 0)
            {
                ObjectArray pler = new ObjectArray();

                //XmlNode xml = JSON.DeserializeXmlNode("{records:{record:" + listeBilgileri + "}}");
                //foreach (XmlNode row in xml.SelectNodes("records/record"))
                //{
                foreach (Newtonsoft.Json.Linq.JObject satir in satirlar)
                {
                    IKYSiteYetki y = new IKYSiteYetki();
                    //y.kod = Genel.DegerAlInt(satir, "kod");
                    y.yetkiliOlduguSiteKod = OrtakFonksiyonlar.ConvertToInt(hdnSiteKod.Value, 0);
                    y.pkod = Genel.DegerAlInt(satir, "pkod");
                    y.aktif = 1;
                    y.tip = Genel.DegerAlInt(satir, "tip");

                    if (y.tip > 0)
                        pler.objeler.Add(y);
                }
                Sonuc sonuc = new Sonuc();

                if (pler.ObjeSayisi > 0)
                    sonuc = servisIKY.LojmanSiteYetkiKaydet(kullanan, (TNS.IKY.IKYSiteYetki[])pler.objeler.ToArray(typeof(TNS.IKY.IKYSiteYetki)));
                else
                    sonuc = new Sonuc(false, "Kayıt edilecek veri bulunamadı. Yetki tipini seçiniz.", "");

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    if (!string.IsNullOrWhiteSpace(sonuc.hataStr))
                        GenelIslemler.MesajKutusu("Bilgi", sonuc.hataStr + "</br>Başka yetkililer eklemek isterseniz yeniden arama yaparak ekleyebilirsiniz.");
    
                    //X.AddScript("parent.YetkiListele(" + OrtakFonksiyonlar.ConvertToInt(hdnSiteKod.Value,0) + ");");
                    //X.AddScript("parent.hidePopWin();");
                    //X.AddScript("alert('deneme');");
                }
            }
            else
                GenelIslemler.HataYaz(this, "Ekleyeceğiniz yetkiliyi seçiniz.");
        }
    }
}