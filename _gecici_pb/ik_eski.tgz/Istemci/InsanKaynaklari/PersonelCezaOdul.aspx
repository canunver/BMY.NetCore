﻿<%@ Page Language="C#" CodeBehind="PersonelCezaOdul.aspx.cs" Inherits="InsanKaynaklari.PersonelCezaOdul" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        function ZorunluAlanKontrol() {
            if (!pnlformpanel1.isValid()) {
                Ext1.Msg.alert('Uyarı', 'Kırmızı renk ile işaretlenen alanları boş bırakamazsınız.')
            }
            return pnlformpanel1.isValid();
        }

        //        var KomutCalistir = function (command, record, row) {
        //            if (command == 'BelgeSil') {
        //                Ext1.Msg.confirm("Uyarı", "Ekli doküman silinecek. Onaylıyor musunuz?",
        //                function (btn) {
        //                    if (btn == "yes") {
        //                        Ext1.net.DirectMethods.BelgeSil(record.data.KOD);
        //                    }
        //                });
        //            }
        //            else if (command == 'BelgeGoster')
        //                Ext1.net.DirectMethods.BelgeGoster(record.data.KOD);
        //        };
    </script>
    <script src="../Personel/ModulScripts/Ortak.js?mc=03022015" type="text/javascript"></script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Hidden ID="hdnPersonelKod" runat="server" />
    <ext:Hidden ID="hdnKod" runat="server" />
    <%--<ext:Hidden ID="hdnBelgeKod" runat="server" />--%>
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="CEZAODULTIPI" />
                    <ext:RecordField Name="TARIH" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="cezaOdulTipiStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <%--    <ext:Store ID="BelgeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="KAYITKOD" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BELGEADI" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>--%>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel runat="server" Border="false" Region="Center" Layout="BorderLayout">
                <TopBar>
                    <ext:Toolbar ID="Toolbar1" runat="server">
                        <Items>
                            <ext:Button ID="btnKaydet" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK016%>"
                                Icon="Disk">
                                <DirectEvents>
                                    <Click OnEvent="btnKaydet_Click" Before="return ZorunluAlanKontrol();">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnSil" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK017%>"
                                Icon="Delete">
                                <DirectEvents>
                                    <Click OnEvent="btnSil_Click">
                                        <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT075 %>"
                                            Title="Onay" />
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                            <ext:Button ID="btnTemizle" runat="server" Text="<%$ Resources:InsanKaynaklari, FRMPRK018%>"
                                Icon="PageWhite">
                                <DirectEvents>
                                    <Click OnEvent="btnTemizle_Click">
                                        <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                    </Click>
                                </DirectEvents>
                            </ext:Button>
                        </Items>
                    </ext:Toolbar>
                </TopBar>
                <Items>
                    <ext:FormPanel ID="pnlformpanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                        LabelWidth="100" Region="Center">
                        <Items>
                            <ext:ComboBox runat="server" ID="ddlTip" FieldLabel="Ceza/Ödül Tipi" NoteAlign="Top"
                                Editable="false" AnchorHorizontal="96%" DisplayField="AD" ValueField="KOD" StoreID="cezaOdulTipiStore">
                            </ext:ComboBox>
                            <ext:DateField runat="server" ID="txtTarih" FieldLabel="Tarih">
                            </ext:DateField>
                            <ext:FieldSet runat="server" Title="Veren">
                                <Items>
                                    <ext:TextField runat="server" ID="txtVerenKurum" FieldLabel="Kurum" AnchorHorizontal="96%">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ID="txtVerenAd" FieldLabel="Ad" AnchorHorizontal="96%">
                                    </ext:TextField>
                                    <ext:TextField runat="server" ID="txtVerenUnvan" FieldLabel="Unvan" AnchorHorizontal="96%">
                                    </ext:TextField>
                                </Items>
                            </ext:FieldSet>
                            <ext:TextField runat="server" ID="txtAlanUnvan" FieldLabel="Alan Unvan" NoteAlign="Top"
                                AnchorHorizontal="96%">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtCinsi" FieldLabel="Cinsi" NoteAlign="Top" AnchorHorizontal="96%">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtSebebi" FieldLabel="Sebebi" NoteAlign="Top"
                                AnchorHorizontal="96%">
                            </ext:TextField>
                            <ext:TextField runat="server" ID="txtDayanak" FieldLabel="Dayanak" NoteAlign="Top"
                                AnchorHorizontal="96%">
                            </ext:TextField>
                            <ext:FieldSet runat="server" Title="Belge">
                                <Items>
                                    <ext:TextField runat="server" ID="txtBelgeNo" FieldLabel="No" AnchorHorizontal="96%">
                                    </ext:TextField>
                                    <ext:DateField runat="server" ID="txtBelgeTarihi" FieldLabel="Tarih" >
                                    </ext:DateField>
                                    <ext:TextField runat="server" ID="txtBelgeCinsi" FieldLabel="Cinsi" AnchorHorizontal="96%">
                                    </ext:TextField>
                                </Items>
                            </ext:FieldSet>
                        </Items>
                    </ext:FormPanel>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                        StoreID="ListeStore" Layout="FitLayout" Width="350" AutoExpandColumn="CEZAODULTIPI"
                        Border="true" Region="East" Split="true">
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column ColumnID="CEZAODULTIPI" DataIndex="CEZAODULTIPI" Header="Ceza/Ödül Tipi" />
                                <ext:Column ColumnID="TARIH" DataIndex="TARIH" Header="Tarih" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:RowSelectionModel ID="grdListeSelectionModel" runat="server" SingleSelect="true">
                                <DirectEvents>
                                    <RowSelect OnEvent="SatirSecildi" Buffer="100">
                                        <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                        <ExtraParams>
                                            <ext:Parameter Name="kod" Value="this.getSelected().data.KOD" Mode="Raw" />
                                        </ExtraParams>
                                    </RowSelect>
                                </DirectEvents>
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <BottomBar>
                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true">
                            </ext:PagingToolbar>
                        </BottomBar>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
