﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="PersonelTerfiOnaylama.aspx.cs"
    Inherits="InsanKaynaklari.PersonelTerfiOnaylama" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript">
        var durumRenderer = function (value) {
            var r = durumStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
        var tipRenderer = function (value) {
            var r = tipStore.getById(value);
            if (Ext1.isEmpty(r)) {
                return "";
            }
            return r.data.AD;
        };
    </script>
</head>
<body>
    <form id="form1" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Store ID="sgkSebepStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="durumStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="tipStore" runat="server">
        <Reader>
            <ext:ArrayReader IDProperty="KOD">
                <Fields>
                    <ext:RecordField Name="KOD" />
                    <ext:RecordField Name="AD" />
                </Fields>
            </ext:ArrayReader>
        </Reader>
    </ext:Store>
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader IDProperty="TKOD">
                <Fields>
                    <ext:RecordField Name="TKOD" />
                    <ext:RecordField Name="PKADROKOD" />
                    <ext:RecordField Name="PKOD" />
                    <ext:RecordField Name="TC" />
                    <ext:RecordField Name="ADSOYAD" />
                    <ext:RecordField Name="SICILNO" />
                    <ext:RecordField Name="TIP" />
                    <ext:RecordField Name="BIRIMAD" />
                    <ext:RecordField Name="UNVANAD" />
                    <ext:RecordField Name="SEBEP" />
                    <ext:RecordField Name="KADRODERECE" />
                    <ext:RecordField Name="KADROTARIH" />
                    <ext:RecordField Name="KAZANILMISHAKDERECE" />
                    <ext:RecordField Name="KAZANILMISHAKKADEME" />
                    <ext:RecordField Name="KAZANILMISHAKTARIH" />
                    <ext:RecordField Name="ODEMEYEESASDERECE" />
                    <ext:RecordField Name="ODEMEYEESASKADEME" />
                    <ext:RecordField Name="ODEMEYEESASTARIH" />
                    <ext:RecordField Name="EMEKLIYEESASDERECE" />
                    <ext:RecordField Name="EMEKLIYEESASKADEME" />
                    <ext:RecordField Name="EMEKLIYEESASTARIH" />
                    <ext:RecordField Name="TIPAD" />
                    <ext:RecordField Name="OGRENIM" />
                    <ext:RecordField Name="YDERECE" />
                    <ext:RecordField Name="YILAY" />
                    <ext:RecordField Name="DURUM" />
                    <ext:RecordField Name="SEBEPAD" />
                    <ext:RecordField Name="DURUMAD" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" Layout="BorderLayout">
        <Items>
            <ext:Panel ID="Panel1" runat="server" Border="false" Region="Center" Layout="BorderLayout"
                Margins="104 20 10 20">
                <Items>
                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="true" TrackMouseOver="true"
                        StoreID="ListeStore" Border="true" Region="Center">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar2" runat="server" HideLabels="true">
                                <Items>
                                    <ext:Label runat="server" Text="Durum:" />
                                    <ext:ComboBox runat="server" ID="ddlDurum" StoreID="durumStore" DisplayField="AD"
                                        ValueField="KOD" Width="100" />
                                    <ext:ToolbarSpacer Width="10" />

                                    <ext:Label ID="Label1" runat="server" Text="Tip:" />
                                    <ext:ComboBox runat="server" ID="ddlTip" StoreID="tipStore"
                                        DisplayField="AD" ValueField="KOD" Width="100"/>
                                    <ext:ToolbarSpacer Width="10" />
                                    <ext:Button ID="btnSorguListele" runat="server" Text="<%$Resources:InsanKaynaklari,FRMPBI003%>"
                                        Icon="ApplicationGo">
                                        <DirectEvents>
                                            <Click OnEvent="TerfiListele">
                                                <EventMask ShowMask="true" MinDelay="200" Msg="<%$Resources:InsanKaynaklari,FRMPAB020%>" />
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnYazdir" runat="server" Text="Yazdır" Icon="PageWord">
                                        <DirectEvents>
                                            <Click OnEvent="TerfiListesiYazdir" Timeout="900000" IsUpload="true">
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:ToolbarSpacer Width="20" />
                                    <ext:ToolbarSeparator />
                                    <ext:ToolbarSpacer Width="20" />
                                    <ext:Button ID="btnTerfiOnayla" runat="server" Text="Terfiyi Onayla" Icon="Accept">
                                        <DirectEvents>
                                            <Click OnEvent="TerfiOnayla">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="<%$ Resources:InsanKaynaklari, FRMIZN003%>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="terfiler" Value="Ext1.util.JSON.encode(#{grdListe}.getRowsValues({ selectedOnly: true }))"
                                                        Mode="Raw" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnTerfiRed" runat="server" Text="Terfiyi Reddet" Icon="TableDelete">
                                        <DirectEvents>
                                            <Click OnEvent="TerfiOnayla">
                                                <Confirmation ConfirmRequest="true" Message="<%$ Resources:InsanKaynaklari,FRMORT074 %>"
                                                    Title="<%$ Resources:InsanKaynaklari, FRMIZN003%>" />
                                                <EventMask ShowMask="true" Msg="<%$ Resources:InsanKaynaklari,FRMORT073 %>" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="terfiler" Value="Ext1.util.JSON.encode(#{grdListe}.getRowsValues({ selectedOnly: true }))"
                                                        Mode="Raw" />
                                                </ExtraParams>
                                            </Click>
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <%--<ext:CheckColumn DataIndex="Terfi" Width="120" Editable="true" Header="Terfi Et" />--%>
                                <ext:Column DataIndex="TIPAD" Header="Terfi Tipi" Width="120" />
                                <ext:Column DataIndex="DURUMAD" Header="Terfi Durumu" Width="100" />
                                <ext:Column DataIndex="YILAY" Header="Yıl Ay" Width="50" />
                                <ext:Column DataIndex="TC" Header="KimlikNo" Width="90" />
                                <ext:Column DataIndex="ADSOYAD" Header="Ad Soyad" Width="120" />
                                <ext:Column DataIndex="SicilNo" Header="Kurum Sicil No" Width="90" />
                                <ext:Column DataIndex="BIRIMAD" Header="<%$ Resources:InsanKaynaklari,FRMPRK068 %>"
                                    Width="150" />
                                <ext:Column DataIndex="UNVANAD" Header="<%$ Resources:InsanKaynaklari,FRMPRK050 %>"
                                    Width="110" />
                                <ext:Column DataIndex="SEBEPAD" Header="Hizmet Sebebi" Width="110" />
                                <ext:Column DataIndex="OGRENIM" Header="Öğrenim Türü" Width="80" />
                                <ext:Column DataIndex="KADRODERECE" Header="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                    Width="43" Align="Center" />
                                <ext:Column DataIndex="KADROTARIH" Header="<%$ Resources:InsanKaynaklari,FRMPRK057 %>"
                                    Width="63" Align="Center" />
                                <ext:Column DataIndex="KAZANILMISHAKDERECE" Header="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                    Width="43" Align="Center" />
                                <ext:Column DataIndex="KAZANILMISHAKKADEME" Header="<%$ Resources:InsanKaynaklari,FRMPRK067 %>"
                                    Width="46" Align="Center" />
                                <ext:Column DataIndex="KAZANILMISHAKTARIH" Header="<%$ Resources:InsanKaynaklari,FRMPRK057 %>"
                                    Width="63" Align="Center" />
                                <ext:Column DataIndex="EMEKLIYEESASDERECE" Header="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                    Width="43" Align="Center" />
                                <ext:Column DataIndex="EMEKLIYEESASKADEME" Header="<%$ Resources:InsanKaynaklari,FRMPRK067 %>"
                                    Width="46" Align="Center" />
                                <ext:Column DataIndex="EMEKLIYEESASTARIH" Header="<%$ Resources:InsanKaynaklari,FRMPRK057 %>"
                                    Width="63" Align="Center" />
                                <ext:Column DataIndex="ODEMEYEESASDERECE" Header="<%$ Resources:InsanKaynaklari,FRMPRK056 %>"
                                    Width="43" Align="Center" />
                                <ext:Column DataIndex="ODEMEYEESASKADEME" Header="<%$ Resources:InsanKaynaklari,FRMPRK067 %>"
                                    Width="46" Align="Center" />
                                <ext:Column DataIndex="ODEMEYEESASTARIH" Header="<%$ Resources:InsanKaynaklari,FRMPRK057 %>"
                                    Width="63" Align="Center" />
                                <ext:Column DataIndex="YDERECE" Header="Derece" Width="90" Align="Center" />
                            </Columns>
                        </ColumnModel>
                        <SelectionModel>
                            <ext:CheckboxSelectionModel ID="ChkSelectionModel" runat="server" KeepSelectionOnClick="Always">
                            </ext:CheckboxSelectionModel>
                        </SelectionModel>
                        <View>
                            <ext:GridView ID="GridView1" runat="server">
                                <HeaderGroupRows>
                                    <ext:HeaderGroupRow>
                                        <Columns>
                                            <ext:HeaderGroupColumn ColSpan="11" Header="Kişi Bilgileri" Align="Center" />
                                            <ext:HeaderGroupColumn Header="<%$ Resources:InsanKaynaklari,FRMPRK055 %>" ColSpan="2"
                                                Align="Center" />
                                            <ext:HeaderGroupColumn Header="<%$ Resources:InsanKaynaklari,FRMPRK060 %>" ColSpan="3"
                                                Align="Center" />
                                            <ext:HeaderGroupColumn Header="<%$ Resources:InsanKaynaklari,FRMPRK062 %>" ColSpan="3"
                                                Align="Center" />
                                            <ext:HeaderGroupColumn Header="<%$ Resources:InsanKaynaklari,FRMPRK061 %>" ColSpan="3"
                                                Align="Center" />
                                            <ext:HeaderGroupColumn Header="Yükselebileceği" Align="Center" />
                                        </Columns>
                                    </ext:HeaderGroupRow>
                                </HeaderGroupRows>
                            </ext:GridView>
                        </View>
                        <%--<SelectionModel>
                                    <ext:RowSelectionModel ID="RowSelectionModel1" runat="server" SingleSelect="true">
                                        <DirectEvents>
                                            <RowSelect OnEvent="RowSelect" Buffer="100">
                                                <EventMask ShowMask="true" />
                                                <ExtraParams>
                                                    <ext:Parameter Name="KOD" Value="this.getSelected().id" Mode="Raw" />
                                                </ExtraParams>
                                            </RowSelect>
                                        </DirectEvents>
                                    </ext:RowSelectionModel>
                                </SelectionModel>--%>
                    </ext:GridPanel>
                </Items>
            </ext:Panel>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
