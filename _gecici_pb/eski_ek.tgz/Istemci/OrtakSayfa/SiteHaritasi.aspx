<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="SiteHaritasi.aspx.cs" Inherits="Istemci.OrtakSayfa.SiteHaritasiForm" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="head" runat="server">
    <title>Site Haritas&#305;</title>
    <style type="text/css">
        .treeview ul
        {
            margin: 0;
            padding: 0;
        }
        .treeview li
        {
            font-weight: normal;
            list-style-type: none;
            background: url(../App_themes/Theme1/images/tree_closed.gif) no-repeat left 0px;
            padding-left: 20px;           
            margin-bottom: 0px;
            margin-top: 0px;
        }
        .treeview li.submenu
        {        	
            font-weight: bold;
            background: url(../App_themes/Theme1/images/tree_open.gif) no-repeat left 0px;            
        }
    </style>

    <script language="JavaScript" type="text/javascript">
        function SiteHaritasiYukleniyorGizle() {
            try { parent.SiteHaritasiYukleniyorGizle(); } catch (e) { }
        }
        function go(adres) {
            try { parent.SiteHaritasiMenuGosterGizle(''); } catch (e) { }
            parent.location.href = adres;
        }
    </script>

</head>
<body style="margin-top: 5px; font-size: 10pt;">
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <div style="margin-left: -25px;">
        <asp:Literal ID="ltlListe" runat="server"></asp:Literal></div>
    </form>
</body>
</html>
