using System;
using System.Web.UI.WebControls;
using OrtakClass;

namespace OrtakSayfa
{
    public partial class Hata : System.Web.UI.Page
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            string tur = Request.QueryString["bilgi"] + "";

            if (tur != "")
                divHata.Visible = false;
            else
                divInfo.Visible = false;

            TNS.ObjectArray hataStr = new TNS.ObjectArray();
            string bilgi = (string)Session["BilgiSatiri"];
            if (bilgi == null) bilgi = "";
            int sayac = TNS.OrtakFonksiyonlar.StringiParcala(bilgi, "<br>", hataStr);
            string mesaj = "";

            for (int i = 0; i < sayac; i++)
                if (hataStr.AlStr(i).Trim() != "")
                {
                    if (((String)hataStr.Al(i)).IndexOf("HataGizleAc") > -1)
                        mesaj += "<br>" + hataStr.AlStr(i).Trim() + "";
                    else
                        mesaj += "<li>&nbsp;" + hataStr.AlStr(i).Trim() + "</li>";
                }

            if (tur != "")
                lblUyari.Text = mesaj;
            else
                lblHata.Text = mesaj;
        }
    }
}
