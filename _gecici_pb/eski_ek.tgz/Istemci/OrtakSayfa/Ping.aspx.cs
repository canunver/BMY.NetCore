﻿using OrtakClass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Istemci.OrtakSayfa
{
    public partial class Ping : System.Web.UI.Page
    {
        TNS.KYM.Kullanici kullanan;
        int tur, say;
        StringBuilder sb;
        protected void Page_Load(object sender, EventArgs e)
        {
            sb = new StringBuilder();
            DebugYaz("Page_Load (?t=3&s=10 şeklinde parametre verilebilir, 1: session bağlantısı yok, basit sunucu çağrısı; 2: session çağrısı, basit sunucu çağrısı; 3: VT Oku; 4: VT Yaz;5: VT Oku ve Yaz -  s: tekrar sayısı)");
            tur = GenelIslemlerIstemci.RequestBul(this, "t", 3);
            say = GenelIslemlerIstemci.RequestBul(this, "s", 10);
            if (tur >= 2 && tur != 6)
            {
                kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
                DebugYaz("Kullanıcı okundu, işlem sayısı=" + say + "<br />");
            }
            else
            {
                kullanan = new TNS.KYM.Kullanici();
                DebugYaz("Kullanıcı okunmadı, işlem sayısı=" + say + "<br />");
            }
            if (tur == 3 || tur == 4 || tur == 5 || tur == 6)
                VeriTabaniOkuYaz(say);
            else
                DegiskenOku(say);
            DebugYaz("İşlemler bitti");

            if (tur == 6)
            {
                string sonuc = sb.ToString();
                if (sonuc.IndexOf("HataOlustu:") > -1)
                {
                    Response.Clear();
                    Response.Write(sonuc);
                    Response.End();
                }
                else
                    Response.Write("SorunYok");
            }
            else
                ltlMetin.Text = sb.ToString();
        }

        private void VeriTabaniOkuYaz(int islemSay)
        {
            TNS.KYM.IKYMServis tut = TNS.KYM.Arac.Tanimla();
            for (int i = 0; i < islemSay; i++)
            {
                DebugYaz("İşlem No:" + i + " Gir");
                string deger = tut.Ping(kullanan, tur);
                DebugYaz("İşlem No: " + i + " Çık (" + deger + ")<br />");
            }
        }


        private void DegiskenOku(int islemSay)
        {
            for (int i = 0; i < islemSay; i++)
            {
                DebugYaz("İşlem No:" + i + " Gir");
                string deger = TNS.DEG.Arac.DegiskenDegerBul(0, "/TEST" + i.ToString());
                DebugYaz("İşlem No:" + i + " Çık<br />");
            }
        }

        private void DebugYaz(string v, bool brEkle = true)
        {
            sb.AppendLine(TNS.DEG.Arac.MS() + ": " + v + (brEkle ? "<br />" : ""));
        }
    }
}