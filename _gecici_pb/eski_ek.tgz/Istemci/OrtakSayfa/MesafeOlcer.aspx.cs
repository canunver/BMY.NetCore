﻿using Ext1.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OrtakClass;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Web.Script.Serialization;
using TNS;

namespace OrtakSayfa
{
    [Serializable()]
    public class MesafeOlcerNesne
    {
        public string lat = "";
        public string lng = "";
        public string cevap = "";
    }


    public partial class MesafeOlcer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (!IsPostBack)
            {
                txtKey.Text = "";
                txtLocations.Text = "";
                txtLocations2.Text = "";
            }
        }


        protected void btnDosyalariAl_Click(object sender, DirectEventArgs e)
        {
            ObjectArray liste = new ObjectArray();

            string locations = txtLocations.Text;
            string[] location = locations.Split('\r', '\n');

            foreach (string pair in location)
            {
                string[] point = pair.Split('\t');

                if (point.Length == 2)
                {
                    MesafeOlcerNesne msf = new MesafeOlcerNesne();
                    msf.lat = point[0].Replace(",", ".").Replace("\t", "").Trim();
                    msf.lng = point[1].Replace(",", ".").Replace("\t", "").Trim();

                    liste.objeler.Add(msf);
                }
            }

            string sorguParam = "";
            string hataYol = System.Configuration.ConfigurationManager.AppSettings.Get("HataDosyasi") + "";
            hataYol = Path.GetDirectoryName(hataYol);
            foreach (MesafeOlcerNesne msf1 in liste.objeler)
            {
                foreach (MesafeOlcerNesne msf2 in liste.objeler)
                {
                    sorguParam = msf1.lat + "_" + msf1.lng + "-" + msf2.lat + "_" + msf2.lng;

                    string kontrolDosyaAdi = Path.Combine(hataYol, sorguParam + ".json");
                    if (File.Exists(kontrolDosyaAdi)) continue;

                    DataGetir(msf1, msf2, sorguParam);
                }
            }
        }

        protected void btnDosyalariAl2_Click(object sender, DirectEventArgs e)
        {
            ObjectArray liste = new ObjectArray();

            string locations = txtLocations2.Text;
            string[] location = locations.Split('\r', '\n');

            string sorguParam = "";
            string hataYol = System.Configuration.ConfigurationManager.AppSettings.Get("HataDosyasi") + "";
            hataYol = Path.GetDirectoryName(hataYol);
            foreach (string pair in location)
            {
                string[] point = pair.Split('\t');

                if (point.Length == 4)
                {
                    MesafeOlcerNesne msf1 = new MesafeOlcerNesne();
                    msf1.lat = point[0].Replace(",", ".").Replace("\t", "").Trim();
                    msf1.lng = point[1].Replace(",", ".").Replace("\t", "").Trim();

                    MesafeOlcerNesne msf2 = new MesafeOlcerNesne();
                    msf2.lat = point[2].Replace(",", ".").Replace("\t", "").Trim();
                    msf2.lng = point[3].Replace(",", ".").Replace("\t", "").Trim();


                    sorguParam = msf1.lat + "_" + msf1.lng + "-" + msf2.lat + "_" + msf2.lng;




                    string kontrolDosyaAdi = Path.Combine(hataYol, sorguParam + ".json");
                    if (File.Exists(kontrolDosyaAdi)) continue;

                    DataGetir(msf1, msf2, sorguParam);
                }
            }

            GenelIslemler.MesajKutusu("Bilgi", "İşlem Tamamlandı");
        }


        void DataGetir(MesafeOlcerNesne msf1, MesafeOlcerNesne msf2, string sorguParam)
        {
            string cevap = "";
            string url = "";
            string key = txtKey.Text;

            url = "https://www.mapquestapi.com/directions/v2/route?key=" + key + "&from=" + msf1.lat + "," + msf1.lng + "&to=" + msf2.lat + "," + msf2.lng + "&outFormat=json&unit=k&ambiguities=ignore&routeType=shortest&doReverseGeocode=false&enhancedNarrative=false&avoidTimedConditions=false\r";

            string sonuc = "";
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.AutomaticDecompression = DecompressionMethods.GZip;

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    cevap = reader.ReadToEnd();
                }

                OrtakFonksiyonlar.HataDosyaYaz(sorguParam + ".json", cevap, true);
                sonuc = "";
            }
            catch (Exception ex)
            {
                sonuc = "___hata";
                OrtakFonksiyonlar.HataDosyaYaz(sorguParam + sonuc + ".json", ex.Message + " * " + ex.StackTrace + "*" + url, true);
            }

            OrtakFonksiyonlar.HataDosyaYaz("MesafeOlcer.txt", sorguParam + sonuc, false);

        }


        protected void btnDosyalariOku_Click(object sender, DirectEventArgs e)
        {
            Tablo XLS = new TabloJ();

            XLS.BosDosyaAc(DosyaIslem.DosyaAdUret());
            XLS.HucreDegerYaz(0, 0, "Nereden");
            XLS.HucreDegerYaz(0, 1, "Nereye");
            XLS.HucreDegerYaz(0, 2, "Mesafe (km)");
            XLS.HucreDegerYaz(0, 3, "Zaman");
            XLS.HucreDegerYaz(0, 4, "Zaman (sn)");
            XLS.HucreDegerYaz(0, 5, "Kullanılan Yakıt");

            string hataYol = System.Configuration.ConfigurationManager.AppSettings.Get("HataDosyasi") + "";
            hataYol = Path.GetDirectoryName(hataYol);
            string kontrolYol = hataYol;

            string[] dosyalar = Directory.GetFiles(kontrolYol, "*.json");

            int satir = 1;
            foreach (string dosya in dosyalar)
            {
                string json = OrtakFonksiyonlar.HataDosyaOku(dosya);

                JObject o = null;

                try
                {
                    o = JObject.Parse(json);
                }
                catch { }

                if (o == null) continue;

                string dosyaAdi = Path.GetFileNameWithoutExtension(dosya);
                string[] parcalar = dosyaAdi.Split('-');
                string[] p1 = parcalar[0].Split('_');
                string[] p2 = parcalar[1].Split('_');

                try
                {
                    string lat1 = p1[0];
                    string lng1 = p1[1];

                    string lat2 = p2[0];
                    string lng2 = p2[1];

                    string distance = o["route"]["distance"].ToString();
                    string formattedTime = o["route"]["formattedTime"].ToString();
                    string fuelUsed = o["route"]["fuelUsed"].ToString();
                    string time = o["route"]["time"].ToString();


                    XLS.HucreDegerYaz(satir, 0, lat1 + "," + lng1);
                    XLS.HucreDegerYaz(satir, 1, lat2 + "," + lng2);
                    XLS.HucreDegerYaz(satir, 2, OrtakFonksiyonlar.ConvertToDbl(distance));
                    XLS.HucreDegerYaz(satir, 3, formattedTime);
                    XLS.HucreDegerYaz(satir, 4, OrtakFonksiyonlar.ConvertToDbl(time));
                    XLS.HucreDegerYaz(satir, 5, OrtakFonksiyonlar.ConvertToDbl(fuelUsed));
                    satir++;
                }
                catch
                {
                }
            }

            XLS.DosyaSaklaTamYol();
            DosyaIslem.DosyaGonder(XLS.SonucDosyaAd(), "Mesafe.xls", true, "xls");

        }
    }
}
