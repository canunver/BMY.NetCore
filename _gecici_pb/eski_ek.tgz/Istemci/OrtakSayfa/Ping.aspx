﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Ping.aspx.cs" Inherits="Istemci.OrtakSayfa.Ping"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Deneme</title>
</head>
<body>
    <form id="Form1" runat="server">
        <div><asp:TextBox runat="server" ID="txtZaman"></asp:TextBox></div>
        
        <div><asp:Literal runat="server" ID="ltlMetin"></asp:Literal></div>
    </form>
    <script type="text/javascript">
        var d = new Date();
        var n = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds() + "." + d.getMilliseconds();
        document.getElementById("txtZaman").value = n;
    </script>
</body>
</html>
