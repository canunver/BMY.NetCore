﻿<%@ Control Language="C#" CodeBehind="IsSecim.ascx.cs" Inherits="OrtakSayfa.IsSecim" %>
<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>

<ext:Window runat="server" ID="wndIsSecim" Title="İş Seçimi" Width="600" Height="400" Layout="FitLayout" Hidden="true" Modal="true" Closable="true">
    <Items>
        <ext:Panel runat="server" Layout="RowLayout">
            <Items>
                <ext:FormPanel runat="server" Padding="10" Height="70">
                    <Items>
                        <ext:TextField runat="server" FieldLabel="Ad" ID="txtIsAdi" AnchorHorizontal="98%" />
                        <ext:ComboBox runat="server" FieldLabel="İl Kodu" ID="cmbIlKodu" ValueField="kod" DisplayField="ad" AnchorHorizontal="98%" Editable="false">
                            <Store>
                                <ext:Store runat="server" ID="stoIlKodu">
                                    <Reader>
                                        <ext:JsonReader>
                                            <Fields>
                                                <ext:RecordField Name="kod" Type="Int" />
                                                <ext:RecordField Name="ad" Type="String" />
                                            </Fields>
                                        </ext:JsonReader>
                                    </Reader>
                                </ext:Store>
                            </Store>
                        </ext:ComboBox>
                    </Items>
                </ext:FormPanel>
                <ext:GridPanel runat="server" ID="grdIsSecim" Title="İş Listesi" Layout="FitLayout" RowHeight="1">
                    <TopBar>
                        <ext:Toolbar runat="server">
                            <Items>
                                <ext:Button runat="server" ID="btnIsAra" Text="Listele" Icon="Lightning">
                                    <DirectEvents>
                                        <Click OnEvent="btnIsAra_Click" />
                                    </DirectEvents>
                                </ext:Button>
                            </Items>
                        </ext:Toolbar>
                    </TopBar>
                    <Store>
                        <ext:Store ID="stoIsSecim" runat="server">
                            <Reader>
                                <ext:JsonReader>
                                    <Fields>
                                        <ext:RecordField Name="siraNo" Type="Int" />
                                        <ext:RecordField Name="ioiProjeAdi" Type="String" />
                                        <ext:RecordField Name="ilAdi" Type="String" />
                                    </Fields>
                                </ext:JsonReader>
                            </Reader>
                        </ext:Store>
                    </Store>
                    <ColumnModel>
                        <Columns>
                            <ext:Column Header="İş Kodu" DataIndex="siraNo" Width="70" />
                            <ext:Column Header="İş Adı" DataIndex="ioiProjeAdi" Width="300" />
                            <ext:Column Header="İl Adı" DataIndex="ilAdi" Width="170" />
                        </Columns>
                    </ColumnModel>
                    <Listeners>
                        <RowDblClick Fn="gridRowDblClick" />
                    </Listeners>
                </ext:GridPanel>
            </Items>
        </ext:Panel>
    </Items>
</ext:Window>
