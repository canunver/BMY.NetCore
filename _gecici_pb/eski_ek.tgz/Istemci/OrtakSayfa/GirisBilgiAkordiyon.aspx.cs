﻿using System;
using System.Xml;
using OrtakClass;
using TNS;
using Ext1.Net;

namespace OrtakSayfa
{
    public partial class GirisBilgiAkordiyon : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            string yonlendir = this.Request["yonlendir"];
            if (!string.IsNullOrEmpty(yonlendir))
            {
                string param = "";
                for (int i = 0; i < this.Request.QueryString.Count; i++)
                {
                    string degisken = this.Request.QueryString.AllKeys[i];
                    string deger = this.Request.QueryString[i];
                    if (degisken != "yonlendir")
                    {
                        if (!string.IsNullOrEmpty(param)) param += "&";
                        param += degisken + "=" + deger;
                    }
                }
                string ekle = "?";
                if (yonlendir.Contains(ekle)) ekle = "&";
                panelSayfa.AutoLoad.Url = yonlendir + ekle + param;
            }
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            AkordiyonMenuOlustur();
        }

        private void AkordiyonMenuOlustur()
        {
            XmlNode anaNode = GenelIslemlerIstemci.MenuNodeBul(kullanan, string.Empty, true);
            if (anaNode == null)
            {
                GenelIslemler.HataYaz(this, Resources.Istemci.IST040);
                return;
            }

            int aktifMenu = OrtakFonksiyonlar.ConvertToInt(GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "AKTIFMENU"), 0);
            if (aktifMenu <= 0)
                aktifMenu = 1;

            AkordiyonMenuOlustur(panelMenu, anaNode, 0, aktifMenu);
        }

        private void AkordiyonMenuOlustur(Ext1.Net.Panel anaPanel, XmlNode anaNode, int grupNo, int aktifMenu)
        {
            if (anaNode == null || !anaNode.HasChildNodes)
                return;

            for (int i = 0; i < anaNode.ChildNodes.Count; i++)
            {
                XmlNode node = anaNode.ChildNodes[i];

                string url = GenelIslemlerIstemci.OzellikVer(node, "URL");
                string id = GenelIslemlerIstemci.OzellikVer(node, "ID");
                string text = istemciUzayi.GenelSayfa.MenuAd(node, id);
                string tip = GenelIslemlerIstemci.OzellikVer(node, "Tip");

                if (!string.IsNullOrEmpty(tip) && tip == "Grup")
                {
                    grupNo++;

                    Ext1.Net.Panel p = new Ext1.Net.Panel();
                    p.Title = text.ToUpper();
                    p.Border = false;
                    p.Listeners.BeforeExpand.Handler = "AktifMenuKaydet('" + grupNo + "');";
                    p.AutoScroll = true;

                    p.Collapsed = (grupNo != aktifMenu);
                    anaPanel.Items.Add(p);

                    Ext1.Net.TreePanel tp = new Ext1.Net.TreePanel();
                    tp.RootVisible = false;
                    tp.UseArrows = true;
                    tp.Animate = true;
                    tp.ContainerScroll = true;
                    //tp.AutoScroll = true;
                    Ext1.Net.TreeNode giris = new Ext1.Net.TreeNode("Ana");
                    tp.Root.Add(giris);
                    tp.Border = false;
                    tp.Listeners.Click.Fn = "MenuSecildi";
                    p.Items.Add(tp);
                    TreeMenuOlustur(node, giris, true);
                }

            }
        }

        private void TreeMenuOlustur(XmlNode anaNode, Ext1.Net.TreeNode tNode, bool acikGoster)
        {
            if (anaNode == null || !anaNode.HasChildNodes)
                return;

            for (int i = 0; i < anaNode.ChildNodes.Count; i++)
            {
                XmlNode node = anaNode.ChildNodes[i];
                Ext1.Net.TreeNode icNode = new Ext1.Net.TreeNode();
                string url = GenelIslemlerIstemci.OzellikVer(node, "URL");
                string id = GenelIslemlerIstemci.OzellikVer(node, "ID");
                string text = istemciUzayi.GenelSayfa.MenuAd(node, id);
                string tip = GenelIslemlerIstemci.OzellikVer(node, "Tip");
                icNode.CustomAttributes.Add(new ConfigItem("url", MenuYokEkle(url), ParameterMode.Value));
                icNode.CustomAttributes.Add(new ConfigItem("icID", id, ParameterMode.Value));
                icNode.Text = text;
                icNode.SingleClickExpand = true;
                icNode.Expanded = acikGoster;
                if (!string.IsNullOrEmpty(tip))
                {
                    if (tip != "Kolon")
                    {
                        tNode.Nodes.Add(icNode);
                    }
                    else
                        icNode = tNode;
                    TreeMenuOlustur(node, icNode, false);
                }
                else if (!string.IsNullOrEmpty(url))
                {
                    tNode.Nodes.Add(icNode);
                }
            }
        }

        private Ext1.Net.Panel AltGrupPanelOl(string baslik)
        {
            Ext1.Net.Panel p = new Ext1.Net.Panel();
            p.Title = baslik.ToUpper();
            p.FormGroup = true;
            p.PaddingSummary = "0 20";
            p.AutoScroll = true;
            p.Collapsed = true;

            return p;
        }

        private Ext1.Net.LinkButton LinkOl(string text, string url)
        {
            Ext1.Net.LinkButton l = new Ext1.Net.LinkButton();
            l.Text = text;
            l.Icon = Ext1.Net.Icon.BulletBlue;
            l.Listeners.Click.Handler = "SayfaAc('" + MenuYokEkle(url) + "');";
            return l;
        }

        private string MenuYokEkle(string url)
        {
            if (string.IsNullOrEmpty(url)) return url;
            string[] parcaliUrl = url.Split('?');
            url = parcaliUrl[0] + "?menuYok=1";
            if (parcaliUrl.Length > 1)
                url += "&" + parcaliUrl[1];
            return url;
        }

        private Ext1.Net.MenuSeparator LinkAyracOl()
        {
            return new Ext1.Net.MenuSeparator();
        }
    }
}