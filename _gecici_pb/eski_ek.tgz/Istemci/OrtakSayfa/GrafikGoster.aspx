﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="GrafikGoster.aspx.cs" Inherits="OrtakSayfa.GrafikGoster" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <link rel="stylesheet" type="text/css" href="../Script/ext-4.0.7-gpl/resources/css/ext-all.css" />
    <script type="text/javascript" src="../Script/ext-4.0.7-gpl/ext-all.js?mc=03022015"></script>
    <script type="text/javascript">
        function itemmouseup(o, seriName) {
            try {
                parent.itemmouseup(o, seriName);
            } catch (e) {

            }
        }

        function YenidenBoyutla(panelUst, turW, buyukW, turH, buyukH, baslikH) {
            var w, h;
            if (turW == 2) {
                w = (panelUst.width * buyukW) / 100;
                w -= 10;
            }
            else w = buyukW;
            panelUst.items.items[0].setWidth(w);
            panelUst.items.items[1].setWidth(w);

            if (turH == 2) {
                h = (panelUst.height * buyukH) / 100;
                h -= 20;
            }
            else h = buyukH;


            if (baslikH == 0) {
                panelUst.items.items[0].hide();
            }
            else {
                panelUst.items.items[0].setHeight(baslikH);
                h -= (baslikH);
            }
            panelUst.items.items[1].setHeight(h);
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
    </form>
</body>
</html>
