﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OrtakClass;

namespace OrtakSayfa
{
    public partial class GrafikGoster : System.Web.UI.Page
    {
        public GrafikAdres[] grafikAdresler = 
        {
            new GrafikAdres("1", "PerformansButce", "PerformansButce.GrafikDataUret"),
            new GrafikAdres("2", "Kullanici", "KYM.KullanimGrafik"),
            new GrafikAdres("3", "ButceHazirlikv2", "ButceHazirlikv2.GrafikDataUret"),
            new GrafikAdres("4", "EkonomikGosterge", "EkonomikGosterge.EKGGrafikUret"),
            new GrafikAdres("5", "PerformansButce", "PerformansButce.OgrenciProfiliGDU"),
            new GrafikAdres("6", "PerformansButce", "PerformansButce.OkulIciSurecGDU"),
            new GrafikAdres("7", "GorevYonetimi", "GorevYonetimi.GorevYonetimi.GorevGrafik"),
            new GrafikAdres("8", "Teftis", "Teftis.MufettisRaporTuru"),
            new GrafikAdres("9", "Teftis", "Teftis.GrafikUret"),
            new GrafikAdres("99", "Istemci", "OrtakSayfa.GrafikDataUret")
        };

        protected void Page_Load(object sender, EventArgs e)
        {
            TNS.KYM.Kullanici kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false);

            string param = Request["param"];
            //hdnParam.Text = param;
            if (!string.IsNullOrEmpty(param))
            {
                string[] paramParca = param.Split('-');
                GrafikAdres ga = GrafikAdres.GrafikBul(grafikAdresler, paramParca[0]);
                if (ga != null)
                {
                    System.Runtime.Remoting.ObjectHandle oh = Activator.CreateInstance(ga.dllAd, ga.sinifAd);
                    if (oh != null)
                    {
                        try
                        {
                            OrtakClass.IChartGenerator ob = (OrtakClass.IChartGenerator)oh.Unwrap();
                            string grafikData = ob.Generate(kullanan, param, false);
                            ClientScript.RegisterClientScriptBlock(typeof(int), "ext", grafikData, true);
                        }
                        catch (Exception ex)
                        {
                            GenelIslemler.MesajKutusu(this, ex.Message);
                        }
                    }
                }
            }
        }


    }

    public class GrafikAdres
    {
        public string dllAd;
        public string sinifAd; //name space'i de içermeli
        public string grafikNo;

        public static GrafikAdres GrafikBul(GrafikAdres[] grafikAdresler, string grafikNo)
        {
            foreach (GrafikAdres item in grafikAdresler)
            {
                if (item.grafikNo == grafikNo) return item;
            }
            return null;
        }

        public GrafikAdres(string grafikNo, string dllAd, string sinifAd)
        {
            this.grafikNo = grafikNo;
            this.dllAd = dllAd;
            this.sinifAd = sinifAd;
        }
    }

    public class GrafikDataUret : OrtakClass.IChartGenerator
    {
        public string Generate(TNS.KYM.Kullanici kullanan, string data, bool exportData)
        {

            TNSSerie s1 = new TNSSerie();
            s1.type = SerieType.gauge;
            s1.highlight = new TNSSerieHighlight();
            s1.highlight.segment_margin = 10;
            //s1.axis = new Position[] { Position.left, Position.bottom };
            s1.xField = new string[] { "Meyve" };
            s1.yField = new string[] { "Mutfaktaki Miktar (KG)" };
            //s1.markerConfig = new MarkerConfig();
            //s1.markerConfig.type = "cross";
            //s1.markerConfig.size = 4;
            //s1.markerConfig.radius = 4;
            //s1.markerConfig.stroke_width = 0;

            //s1.title = "Görüntülenme Sayısı";
            //c.series.Add(s1);
            ExtCollection seriDizisi = new ExtCollection();
            seriDizisi.Add(s1);
            System.Data.DataTable dt = new System.Data.DataTable();
            dt.Columns.Add("Meyve", typeof(string));
            dt.Columns.Add("Mutfaktaki Miktar (KG)", typeof(double));


            dt.Rows.Add("Elma (12 Kg)", (double)12);
            //dt.Rows.Add("Armut (5 Kg)", (double)5);
            //dt.Rows.Add("Vişne (19 Kg)", (double)19);
            //dt.Rows.Add("Portakal (27 Kg)", (double)27);
            //if (ytl.objeler.Count == 0)
            //    dt.Rows.Add(0, 0);
            TNSChart gr = OrtakClass.ChartTool.GenerateFromTable(
                "Mutfaktaki Meyvelerin Cinslerine Göre Dağılımı",
                "font-size: 20px; font-family: Verdana; text-align: center;",
                null,
                "Görüntülenme Sayısı",
                null, dt, 0, AxisType.Gauge, 1, seriDizisi, null, null, null, 0, null, null, 0, null, false, 0);
            gr.insetPadding = 30;
            return gr.ToJSON();
        }
    }
}