﻿<%@ Page Language="C#" Inherits="OrtakSayfa.TertipBilgiXML" CodeBehind="TertipBilgiXML.aspx.cs" %>
