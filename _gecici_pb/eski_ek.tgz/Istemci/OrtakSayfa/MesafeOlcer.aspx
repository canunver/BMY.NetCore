﻿<%@ Page Language="C#" CodeBehind="MesafeOlcer.aspx.cs" Inherits="OrtakSayfa.MesafeOlcer" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <ext:Panel runat="server" LabelWidth="150">
            <TopBar>
                <ext:Toolbar runat="server">
                    <Items>

                        <ext:Button runat="server" ID="btnDosyalariAl" Text="Dosyaları Al (1 Konum)" Hidden="true">
                            <DirectEvents>
                                <Click OnEvent="btnDosyalariAl_Click" IsUpload="true" Timeout="9900000">
                                    <EventMask ShowMask="true" Msg="Lütfen bekleyin" />
                                </Click>
                            </DirectEvents>
                        </ext:Button>
                        <ext:Button runat="server" ID="btnDosyalariAl2" Text="Dosyaları Al (2 Konum)">
                            <DirectEvents>
                                <Click OnEvent="btnDosyalariAl2_Click" IsUpload="true" Timeout="9900000">
                                    <EventMask ShowMask="true" Msg="Lütfen bekleyin" />
                                </Click>
                            </DirectEvents>
                        </ext:Button>
                        <ext:Button runat="server" ID="btnDosyalariOku" Text="Dosyaları Oku">
                            <DirectEvents>
                                <Click OnEvent="btnDosyalariOku_Click" IsUpload="true" Timeout="9900000" />
                            </DirectEvents>
                        </ext:Button>

                    </Items>
                </ext:Toolbar>

            </TopBar>
            <Items>
                <ext:TextField runat="server" ID="txtKey" FieldLabel="MapQuest Consumer Key" Width="600"></ext:TextField>
                <ext:TextArea runat="server" ID="txtLocations" FieldLabel="1 Konumlu Bilgi" Width="600" Height="300" Hidden="true"></ext:TextArea>
                <ext:TextArea runat="server" ID="txtLocations2" FieldLabel="2 Konumlu Bilgi" Width="600" Height="300"></ext:TextArea>
            </Items>

        </ext:Panel>
    </form>
</body>
</html>
