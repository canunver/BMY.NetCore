﻿<%@ Page Language="C#" Inherits="OrtakSayfa.SifremiUnuttum" CodeBehind="SifremiUnuttum.aspx.cs" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Şifremi Unuttum</title>
    <link href="~/App_themes/Form.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <form id="form" runat="server">
        <ext:ResourceManager ID="ResourceManager1" runat="server" />
        <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
        <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
            <Items>
                <ext:BorderLayout ID="BorderLayout1" runat="server">
                    <Center>
                        <ext:Panel ID="Panel1" runat="server">
                            <TopBar>
                                <ext:Toolbar ID="Toolbar1" runat="server">
                                    <Items>
                                        <ext:Button ID="btnParolaDegistir" runat="server" Text="Yeni Parolamı e-posta Adresime Gönder"
                                            Icon="Accept">
                                            <DirectEvents>
                                                <Click OnEvent="btnParolaDegistir_Click">
                                                    <EventMask Msg="Lütfen Bekleyiniz" ShowMask="true" />
                                                </Click>
                                            </DirectEvents>
                                        </ext:Button>
                                        <ext:ToolbarFill runat="server" />
                                        <ext:Button ID="btnKapat" runat="server" Text="Kapat" Icon="Delete">
                                            <Listeners>
                                                <Click Handler="parent.hidePopWin();" />
                                            </Listeners>
                                        </ext:Button>

                                    </Items>
                                </ext:Toolbar>
                            </TopBar>
                            <Items>
                                <ext:BorderLayout ID="BorderLayout2" runat="server">
                                    <Center MarginsSummary="5">
                                        <ext:FormPanel ID="FormPanel1" runat="server" AutoHeight="true" Frame="true" Margins="5 5 5 5" LabelWidth="1">
                                            <Items>
                                                <ext:Label ID="lblHata" runat="server" Hidden="true">
                                                </ext:Label>
                                                <ext:TextField ID="txtTCKimlikNo" runat="server" Note="T.C. Kimlik No/E-Posta Adresi" NoteAlign="Top" Width="400" AutoFocus="true">
                                                </ext:TextField>
                                                <ext:Panel ID="Panel2" runat="server">
                                                    <Content>
                                                        <div class="bilgiKutusu">
                                                            <li>Yukarıdaki alana T.C. Kimlik No veya E-Posta Adresi yazınız.</li>
                                                            <li>İşlem sonucunda yeni parolanız kullanıcı bilgilerinizde kayıtlı olan e-posta adresine
                                                        gönderilecektir. Eğer e-posta adresini bilmiyorsanız görevliler ile irtibata geçin.</li>
                                                        </div>
                                                    </Content>
                                                </ext:Panel>
                                            </Items>
                                        </ext:FormPanel>
                                    </Center>
                                </ext:BorderLayout>
                            </Items>
                        </ext:Panel>
                    </Center>
                </ext:BorderLayout>
            </Items>
        </ext:Viewport>
        <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
