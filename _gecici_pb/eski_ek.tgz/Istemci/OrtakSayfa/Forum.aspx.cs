﻿using System;
using System.Web.Security;
using OrtakClass;
using TNS.FRM;
using TNS.KYM;
using TNS;

namespace OrtakSayfa
{
    public partial class Forum : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string sUrl = System.Configuration.ConfigurationManager.AppSettings.Get("ForumURL");
            string kurumAd = string.Empty;
            Kullanici kullanan = null;

            string kullaniciKoduWS = Request.QueryString["user"];
            string parolaWS = Request.QueryString["hash"];
            string urlWS = Request.QueryString["url"];

            //Maliye dışından gelen kullanıcılar için
            if (!(string.IsNullOrEmpty(kullaniciKoduWS) || string.IsNullOrEmpty(parolaWS) || string.IsNullOrEmpty(urlWS)))
            {
                kullaniciKoduWS = Server.UrlDecode(OrtakFonksiyonlar.SifreCoz(kullaniciKoduWS));

                try
                {
                    WebServisler.tr.gov.sgb.uygulama.ForumServis.Servis forumWS = new WebServisler.tr.gov.sgb.uygulama.ForumServis.Servis();
                    forumWS.Url = urlWS + "/Servis/Forum.asmx";
                    WebServisler.tr.gov.sgb.uygulama.ForumServis.ForumKullaniciW fk = forumWS.KullaniciGirisYapabilirMi(kullaniciKoduWS, parolaWS);
                    if (!fk.sonuc.islemSonuc)
                    {
                        Response.Write(fk.sonuc.hataStr);
                        return;
                    }

                    kurumAd = fk.calistigiKurum;

                    kullanan = new Kullanici();
                    kullanan.kullaniciKodu = fk.kullaniciKodu;
                    if (!string.IsNullOrEmpty(kurumAd))
                        kullanan.kullaniciKodu += " (" + kurumAd + ")";
                    kullanan.ad = fk.ad;
                    kullanan.soyad = fk.soyad;
                    kullanan.emailAdresi = fk.emailAdresi;
                    kullanan.calistigiBirim = fk.calistigiBirim;
                    kullanan.unvan = fk.unvan;
                }
                catch { }
            }

            if (string.IsNullOrEmpty(sUrl))
            {
                Response.Write("Sistemde kurulu Soru-Cevap sayfaları bulunamadı.");
                return;
            }

            if (kullanan == null)
                kullanan = OturumBilgisiIslem.KullaniciBilgiOku(false);

            IFRMServis servisFRM = TNS.FRM.Arac.Tanimla();
            int giris = servisFRM.ForumAyarla(kullanan);

            if (giris > 0)
            {
                string idName = String.Format("{0};{1};{2}", giris, 1, kullanan.kullaniciKodu);
                FormsAuthentication.SetAuthCookie(idName, true);
            }

            ClientScript.RegisterStartupScript(this.GetType(), "forum", "window.location='" + sUrl + "';", true);
        }
    }
}
