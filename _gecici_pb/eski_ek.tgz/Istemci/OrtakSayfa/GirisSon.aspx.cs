﻿using OrtakClass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS.KYM;

namespace Istemci.OrtakSayfa
{
    public partial class GirisSon : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // 1) Sadece lokal makine (127.0.0.1 / ::1) erişebilsin
            if (!Request.IsLocal)
            {
                Response.StatusCode = 403;
                Response.End();
                return;
            }

            // 2) Sadece POST izin ver (GET ile çalışmasın)
            if (!string.Equals(Request.HttpMethod, "POST", StringComparison.OrdinalIgnoreCase))
            {
                Response.StatusCode = 405; // Method Not Allowed
                Response.End();
                return;
            }

            // 3) İstersen ekstra bir “iç anahtar” kontrolü
            //var internalKey = Request.Headers["X-Internal-Key"];
            //if (internalKey != "BURAYA_COK_GIZLI_BIR_DEGER")
            //{
            //    Response.StatusCode = 403;
            //    Response.End();
            //    return;
            //}

            // BURADAN SONRASI: Artık bu isteğin sadece senin uygulamandan geldiğini varsayıyoruz

            string kulKod = Request.Form["KullaniciKodu"];
            string ipAdres = Request.Form["ipAdres"];

            TNS.KYM.IKYMServis servisKym = TNS.KYM.Arac.Tanimla();
            KullaniciVAN kullanici = servisKym.KullaniciOku(kulKod);
            string tut = Session.SessionID;
            OturumBilgisiIslem a = new OturumBilgisiIslem();
            kullanici.kullanici.aktifKultur = System.Threading.Thread.CurrentThread.CurrentUICulture.Name;
            kullanici.kullanici.telefon = ipAdres;
            kullanici.kullanici.ipAddress = ipAdres;
            a.KullaniciBilgiYaz(kullanici.kullanici);

            // veya kullanıcıyı zaten Giris.aspx'te çözmüşsen buraya sadece kullanıcıId bile gönderebilirsin

            // Burada doğrulama değil, sadece Session dolduruyorsan:
            // var kullanici = KullaniciBul(kulKod, sifre) ... (veya ID ile)
            // Session["Kullanici"] = kullanici;

            // Başarılı ise 200 dön
            Response.StatusCode = 200;
            Response.Write(tut);
            Response.End();
        }
    }
}