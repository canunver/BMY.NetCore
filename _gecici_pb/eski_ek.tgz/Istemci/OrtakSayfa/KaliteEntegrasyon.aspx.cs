﻿using System;
using System.Web.Security;
using OrtakClass;
using TNS.KYM;
using TNS;
using System.Text;

namespace OrtakSayfa
{
    public partial class KaliteEntegrasyon : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Kullanici kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);

            string sUrl = System.Configuration.ConfigurationManager.AppSettings.Get("KaliteURL") + "";
            if (string.IsNullOrEmpty(sUrl))
            {
                GenelIslemler.SayfayaGirmesin(false, "Kalite Dokümantasyon Sistemi sayfaları bulunamadı.");
                return;
            }

            bool yetkiVar = kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI, (int)ENUMKullaniciTipi.KALITEDOKUMANTASYONKULLANICISI);
            if (!yetkiVar)
            {
                GenelIslemler.SayfayaGirmesin(false, "Kalite Dokümantasyon Sistemini kullanma yetkiniz yok. Sİstem Yöneticisine başvurun.");
                return;
            }

            string tcKimlikNo = kullanan.mernis;
            string adi = kullanan.ad;
            string soyadi = kullanan.soyad;
            string unvan = kullanan.unvan;
            string kkodu = kullanan.kullaniciKodu;
            string parola = kullanan.parola;
            string eposta = kullanan.emailAdresi;
            string kultur = kullanan.aktifKultur;
            string yetkiliBirimler = kullanan.yetkiTipiDegerleri["Kalite Sistemi Birimi"];
            string yetkiliRoller = kullanan.yetkiTipiDegerleri["Kalite Sistemi Rolü"];

            string sablon = "TCKIMLIKNO:'{0}', ADI:'{1}', SOYADI:'{2}', UNVAN:'{3}', KKODU:'{4}', PAROLA:'{5}', EPOSTA:'{6}', KULTUR:'{7}', YETKILIBIRIMLER:'{8}', YETKILIROLLER:'{9}', GIRISTARIHI:'{10}'";
            string giris = string.Format(sablon, tcKimlikNo, adi, soyadi, unvan, kkodu, parola, eposta, kultur, yetkiliBirimler, yetkiliRoller, DateTime.Now.ToString());
            giris = "{" + giris + "}";
            giris = OrtakFonksiyonlar.Sifrele(giris, "KaliteSistemi(KDS2014)");
            sUrl += "?param=" + giris;

            ClientScript.RegisterStartupScript(this.GetType(), "forum", "window.location='" + sUrl + "';", true);
        }
    }
}
