﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Ext1.Net;
using OrtakClass;
using System.Collections;

namespace OrtakSayfa
{
    public partial class ExtGridGoster : System.Web.UI.Page
    {
        public GrafikAdres[] grafikAdresler = 
        {
            new GrafikAdres("1", "PerformansButce", "PerformansButce.GridUret"),
            new GrafikAdres("2", "Teftis", "Teftis.GridUret"),
            //new GrafikAdres("2", "Kullanici", "KYM.KullanimGrafik"),
            //new GrafikAdres("3", "ButceHazirlikv2", "ButceHazirlikv2.GrafikDataUret"),
            //new GrafikAdres("4", "EkonomikGosterge", "EkonomikGosterge.EKGGrafikUret"),
            //new GrafikAdres("5", "PerformansButce", "PerformansButce.OgrenciProfiliGDU"),
            new GrafikAdres("99", "Istemci", "OrtakSayfa.ExtGridUret")
        };

        protected void Page_Load(object sender, EventArgs e)
        {
            TNS.KYM.Kullanici kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false);
            string param = Request["param"];

            string hata = null;
            if (!string.IsNullOrEmpty(param))
            {
                string[] paramParca = param.Split('-');
                GrafikAdres ga = GrafikAdres.GrafikBul(grafikAdresler, paramParca[0]);

                if (ga != null)
                {
                    System.Runtime.Remoting.ObjectHandle oh = Activator.CreateInstance(ga.dllAd, ga.sinifAd);
                    if (oh != null)
                    {
                        try
                        {
                            OrtakClass.IExtGridGenerator ob = (OrtakClass.IExtGridGenerator)oh.Unwrap();
                            hata = ob.Generate(kullanan, this, grdRapor, param);
                        }
                        catch (Exception ex)
                        {
                            hata = ex.Message;
                        }
                    }
                }
            }
            if (!string.IsNullOrEmpty(hata))
            {
                X.AddScript("HataGoster('{0}')", hata);
            }
        }
    }

    public class ExtGridUret : OrtakClass.IExtGridGenerator
    {
        public string Generate(TNS.KYM.Kullanici kullanan, System.Web.UI.Page page, Ext1.Net.GridPanel grd, string param)
        {
            Store str = new Store();
            grd.Store.Add(str);
            Ext1.Net.ArrayReader ar = new ArrayReader();
            str.Reader.Add(ar);
            ChartTool.GridNumberAlanEkle(grd, str, "IlKod", RecordFieldType.Int, "İl Kodu", true, false, 0);
            ChartTool.GridStringAlanEkle(grd, str, "IlAd",  "İl Adı", true, true);

            ArrayList al = new ArrayList();
            for (int i = 0; i < 19; i++)
            {
                object[] o = new object[] { i, i.ToString() + ". İl" };
                al.Add(o);
            }

            str.DataSource = al;
            str.DataBind();
            return null;
        }

        /*
         * 
         * 
         * 
         *    <style type="text/css">    
         *      .icon-combo-item {        
         *          background-repeat: no-repeat ! important;        
         *          background-position: 3px 50% ! important;        
         *          padding-left: 24px ! important;    
         *      }         
         *      .headerText {
         *          display:block;        
         *          height:128px;        
         *          width:128px;        
         *          margin-left:auto;        
         *          margin-right:auto;        
         *          text-align: left;        
         *          -webkit-transform: rotate(-90deg);             
         *          -moz-transform: rotate(-90deg);             
         *          -o-transform: rotate(-90deg);             
         *          filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=3);     
         *       }     
         *       .x-grid3-hd-fullName, .x-grid3-hd-AYP, .x-grid3-hd-Race, .x-grid3-hd-ELL, .x-grid3-hd-SWD, .x-grid3-hd-FRL, .x-grid3-hd-ReadBAT1, .x-grid3-hd-ReadBAT2, .x-grid3-hd-MathBAT1, .x-grid3-hd-MathBAT2    {        
         *          margin-top:120px;        
         *          text-align: center;     
         *       }    
         *    </style>         
         * 
         * 
         * */


    }
}