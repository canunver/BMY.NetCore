﻿using Ext.Net;
using OrtakClass;
using System;
using System.Collections;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.DynamicData;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using TNS;
using TNS.BHMv2;
using TNS.KYM;
using TNS.YAT;

namespace OrtakSayfa
{
    public partial class IsSecim : Ext1.Net.Component
    {
    }
}
