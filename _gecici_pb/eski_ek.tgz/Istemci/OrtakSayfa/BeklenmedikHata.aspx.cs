﻿using Istemci;
using System;
using System.Web;
using TNS;

namespace OrtakSayfa
{
    public partial class BeklenmedikHata : System.Web.UI.Page, System.Web.SessionState.IRequiresSessionState
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            try
            {
                Exception ex = new Exception();

                if (Server.GetLastError() != null)
                    ex = Server.GetLastError().GetBaseException();
                else
                {
                    ex = (Exception)Application["TheException"];
                    Application["TheException"] = null;
                }

                string kulAd = "Kullanıcı bilgisi okunamadı";

                //if (HttpContext.Current.Request.Cookies == null)
                {
                    HttpCookie cookie = HttpContext.Current.Request.Cookies["KullaniciAdi"];
                    if (cookie != null)
                    {
                        kulAd = cookie.Value;
                    }
                }
                //else
                //    kulAd = "cookie null";

                if (HttpContext.Current.Session != null)
                {
                    TNS.KYM.Kullanici kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false);
                    if (kullanan == null)
                        kulAd = "Kullanıcı bilgisi boş";
                    else
                    {
                        if (!string.IsNullOrEmpty(kullanan.ad))
                            kulAd = kullanan.ad + " " + kullanan.soyad + " (" + kullanan.kullaniciKodu + ")";
                    }
                }

                //Gönderilecek hata (mail için) içeriğinin hazırlanması
                //*******************************************************
                TNS.KYM.IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();
                string hataMesaj = HataMesajOl(kulAd, Request, ex, true, out string HataKod);
                try
                {
                    TNS.OrtakFonksiyonlar.HataDosyaYaz("Hata" + System.DateTime.Now.ToString("yyyyMMdd") + ".htm", "<br>***<br>" + hataMesaj + "<br>***", false);

                    try
                    {
                        string yazilimMailAdresi = TNS.KYM.Arac.ServerWebConfigOku("yazilimMailAdresi", "");
                        if (string.IsNullOrWhiteSpace(yazilimMailAdresi)) yazilimMailAdresi = "bilgi@stratek.com.tr";
                        servisKYM.EPostaGonder("", yazilimMailAdresi, "[HATA-SGB.NET]", hataMesaj, true, false, null);
                    }
                    catch { }

                    try
                    {
                        hataMesaj = hataMesaj.Replace("<br>", " - ");
                        hataMesaj = hataMesaj.Replace("'", " ");
                        Sonuc sonuc = servisKYM.DBHataKaydet(kulAd, HataKod, OrtakClass.GenelIslemler.RemoveHTML(hataMesaj), OrtakClass.GenelIslemler.GetIPAddress());
                    }
                    catch { }
                }
                catch (Exception eHata)
                {
                    TNS.OrtakFonksiyonlar.HataDosyaYaz("HataIc" + System.DateTime.Now.ToString("yyyyMMdd") + ".htm", "<br>***<br>" + eHata.Message.ToString() + "<br>****<br>" + eHata.StackTrace.ToString() + "." + eHata.HelpLink + "<br>*********************", false);
                }
                //*******************************************************


                //Ekranda gösterilecek hata içeriğinin hazırlanması
                //*******************************************************
                lblHata.Text = HataMesajOl(kulAd, Request, ex, false, out string hataKod);
            }
            catch { }

            Server.ClearError();
        }

        private string HataMesajOl(string kulAd, HttpRequest Request, Exception ex, bool detayli, out string hataKod)
        {
            string hataMesaj = "";
            hataMesaj += "<b>Kullanıcı : </b>" + kulAd + "<br>";
            hataKod = HataKoduUret(ex);
            hataMesaj += "<b>Hata Kodu : </b>" + hataKod + "<br>";

            if (detayli || ex.GetType() != typeof(HttpException))
                hataMesaj += "<b>Yol : </b>" + SayfaAd(Request.Url, detayli) + "<br>";
            hataMesaj += "<b>Hata Tarihi : </b>" + DateTime.Now + "<br>";
            if (detayli)
            {
                hataMesaj += "<b>Hata Mesajı : </b>" + Server.HtmlEncode(ex.Message) + "<br>";
                hataMesaj += "<b><u>Hata Sayfa ve Konumu</u></b><br>" + Server.HtmlEncode(ex.StackTrace) + ". " + ex.HelpLink + "<br>";
            }
            else
            {
                bool goster = Request.Url.AbsoluteUri.IndexOf("hatagoster=1") > -1;
                if (!goster)
                    goster = (System.Configuration.ConfigurationManager.AppSettings.Get("HataGoster") + "") == "1";

                if (goster)
                {
                    hataMesaj += "<b>Hata Mesajı : </b>" + Server.HtmlEncode(ex.Message) + "<br>";
                    hataMesaj += "<b><u>Hata Sayfa ve Konumu</u></b><br>" + Server.HtmlEncode(ex.StackTrace) + ". " + ex.HelpLink + "<br>";
                }
            }
            return hataMesaj;
        }

        private string HataKoduUret(Exception ex)
        {
            string tip = ex.GetType().Name;

            if (tip == "NullReferenceException") return "HAT001";
            else if (tip == "SqlException") return "HAT002";
            else if (tip == "InvalidOperationException") return "HAT003";
            else if (tip == "HttpException") return "HAT004";
            else if (tip == "TimeoutException") return "HAT005";
            else if (tip == "FormatException") return "HAT006";
            else if (tip == "IndexOutOfRangeException") return "HAT007";
            else if (tip == "TehlikeliIcerik") return "HAT008";
            else if (tip == "HttpRequestValidationException") return "HAT009";
            return "HAT000 (" + tip + ")";
        }

        private string SayfaAd(Uri uri, bool detayli)
        {
            if (uri != null)
            {
                if (detayli)
                    return Server.HtmlEncode(uri.AbsoluteUri);
                else
                {
                    if (uri.Segments != null && uri.Segments.Length > 0)
                        return Server.HtmlEncode(uri.Segments[uri.Segments.Length - 1]);
                }
            }
            return "";
        }

        //private string Filtrele(string mesaj)
        //{
        //    mesaj = mesaj.Replace("|", ".");
        //    mesaj = mesaj.Replace("&", ".");
        //    mesaj = mesaj.Replace(";", ".");
        //    mesaj = mesaj.Replace("$", ".");
        //    mesaj = mesaj.Replace("%", ".");
        //    mesaj = mesaj.Replace("@", ".");
        //    mesaj = mesaj.Replace("'", ".");
        //    mesaj = mesaj.Replace("\"", ".");
        //    mesaj = mesaj.Replace("\\", ".");
        //    mesaj = mesaj.Replace("<", ".");
        //    mesaj = mesaj.Replace(">", ".");
        //    mesaj = Server.HtmlEncode(mesaj);

        //    return mesaj;
        //}
    }
}
