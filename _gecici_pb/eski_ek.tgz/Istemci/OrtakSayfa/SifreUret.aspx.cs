﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS;
using OrtakClass;
using TNS.KYM;

namespace OrtakSayfa
{
    public partial class SifreUret : istemciUzayi.GenelSayfaV3
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI))
            {
                throw new Exception("Yetkiniz yok!");
            }
        }

        protected void btnSifrele_Click(object sender, EventArgs e)
        {
            if (AnahtarVer() != "")
                txtCikti.Text = OrtakFonksiyonlar.Sifrele(txtGirdi.Text.Trim(), AnahtarVer());
            else
                txtCikti.Text = OrtakFonksiyonlar.Sifrele(txtGirdi.Text.Trim());
        }

        protected void btnSifreCoz_Click(object sender, EventArgs e)
        {
            if (AnahtarVer() != "")
                txtCikti.Text = OrtakFonksiyonlar.SifreliCoz(txtGirdi.Text.Trim(), AnahtarVer());
            else
                txtCikti.Text = OrtakFonksiyonlar.SifreCoz(txtGirdi.Text.Trim());
        }


        string AnahtarVer()
        {
            return txtAnahtar.Text.Trim();
        }
    }
}
