using System;
using System.Data;
using System.IO;
using OrtakClass;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;

namespace Istemci.OrtakSayfa
{
    public partial class GuvenlikResmi : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GuvenlikKodu();
        }

        private void GuvenlikKodu()
        {
            Bitmap gFonResmi = new Bitmap(80, 25);
            Graphics gKodu = Graphics.FromImage(gFonResmi);
            gKodu.Clear(Color.Beige);
            Random rnd = new Random();
            ImageFormat gResimTuru = ImageFormat.Png;
            Point gPoint = new Point(10, 0);
            SolidBrush gBoyama = new SolidBrush(Color.SandyBrown);
            Font gFont = new Font(FontFamily.GenericSerif.Name, 16, FontStyle.Strikeout);
            string karakterler = "123456789QWERTYUIPASDFGHJKLZXCVBNM";
            string kelime = "";
            for (int i = 0; i < 4; i++)
                kelime += karakterler[rnd.Next(0, karakterler.Length)].ToString();

            gKodu.DrawString(kelime, gFont, gBoyama, gPoint);
            gFonResmi.Save(Response.OutputStream, gResimTuru);
            OturumBilgisiIslem.BilgiYazDegisken("guvenlikKodu", kelime);
            gKodu.Dispose();
            gFonResmi.Dispose();
        }
    }
}