﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OrtakClass;
using System.Data;
using System.Drawing;
using TNS.UZY;
using System.IO;
using EkRtfReport;
using System.Text;
using TNS.DEG;
using TNS;
using System.Collections;
using Ext1.Net;

namespace Istemci.OrtakSayfa
{
    public partial class Uzay : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        

        protected void deneme_click(object sender, EventArgs e)
        {

            TNS.UZY.IUZYServis uzy = TNS.UZY.Arac.Tanimla();
            TNS.KYM.Kullanici kul = new TNS.KYM.Kullanici();
            //if (string.IsNullOrEmpty(txtEkAlanlar.Text))
            //{
            txtSonuc.Text = uzy.UzayDegeriDbl(kul, txtUzayAd.Text, txtUzaySorgu.Text, false, txtUzayAlan.Text).ToString("0.00");
            txtSorgu.Text = uzy.UzayKosulStr(kul, txtUzayAd.Text, txtUzaySorgu.Text, false, txtUzayAlan.Text);
            //}
            //else
            //{
            //    string[] alanlar = txtEkAlanlar.Text.Split(',');
            //    DataTable dt = uzy.UzayDataTableDondur(kul, txtUzayAd.Text, txtUzaySorgu.Text, false, txtUzayAlan.Text, alanlar);
            //    if (dt != null)
            //    {

            //        if (dt.Rows.Count > 0)
            //        {
            //            StringBuilder sb = new StringBuilder();
            //            int col = dt.Columns.Count;

            //            sb.Append("<table>");
            //            sb.Append("<tr>");
            //            for (int i = 0; i < col; i++)
            //            {
            //                sb.Append("<td>");
            //                sb.Append(dt.Rows[0].ItemArray[i].GetType());
            //                sb.Append("</td>");
            //            }
            //            sb.Append("</tr>");
            //            sb.AppendLine();
            //            foreach (DataRow item in dt.Rows)
            //            {
            //                sb.Append("<tr>");
            //                for (int i = 0; i < col; i++)
            //                {
            //                    sb.Append("<td>");
            //                    sb.Append(item.ItemArray[i].ToString());
            //                    if (dt.Rows[0].ItemArray[i].GetType() == typeof(System.Decimal))
            //                    {
            //                        decimal d = (decimal)dt.Rows[0].ItemArray[i];
            //                        double dob = Convert.ToDouble(d);
            //                    }
            //                    sb.Append("</td>");
            //                }

            //                sb.Append("</tr>");
            //                sb.AppendLine();
            //            }
            //            sb.Append("</table>");
            //            ltlTable.Text = sb.ToString();
            //        }
            //    }
            //    else
            //        ltlTable.Text = "Hatalı sorgu. Lütfen ek alanları ve toplam kolonunu kontrol ediniz!";
            //}
        }

        protected void btnDegiskenYaz_click(object sender, EventArgs e)
        {
        }

        //private void FormulDeneme()
        //{
        //    TNS.Calculator c = new Calculator();

        //    Variable[] v = new Variable[2];
        //    v[0] = new Variable("yevmiye", VariableType.Money);
        //    v[1] = new Variable("gun", VariableType.Integer);

        //    Formula[] f = new Formula[1];
        //    f[0] = new Formula("calisma", VariableType.Money, txtFormula.Text);

        //    string hata = c.PrepareCalculator("Ornek", "Bordro", v, f);
        //    if (string.IsNullOrEmpty(hata))
        //    {
        //        Hashtable htIn = new Hashtable();
        //        Hashtable htOut = new Hashtable();
        //        htIn["yevmiye"] = OrtakFonksiyonlar.ConvertToDbl(txtYevmiye.Text);
        //        htIn["gun"] = OrtakFonksiyonlar.ConvertToInt(txtGun.Text, 0);
        //        try
        //        {
        //            c.ExecuteCalc(htIn, htOut);
        //            TextField3.Text = htOut["calisma"].ToString();
        //        }
        //        catch (Exception ex)
        //        {
        //            TextField3.Text = ex.Message;
        //        }
        //    }
        //    else
        //        TextField2.Text = hata;
        //}

        void ExcelYaz()
        {
            Tablo XLS = GenelIslemler.NewTablo();
            int kaynakSatir = 0;
            int sutun = 0;
            int satir = 0;

            string sablonAd = "CezalilarListesi.xlt";
            string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            XLS.DosyaAc(Server.MapPath("~") + "/RaporSablon/TRM/" + sablonAd, sonucDosyaAd);
            XLS.HucreAdAdresCoz("baslaSatir", ref kaynakSatir, ref sutun);

            satir = kaynakSatir;
            decimal d=1.0020M;
            for (int i = 0; i < 20; i++)
            {
                satir++;
                XLS.SatirAc(satir, 1);

                //XLS.HucreKopyala(kaynakSatir, sutun, kaynakSatir, sutun + 2, satir, sutun);
                //if (satir == 3)
                //    XLS.HucreAdBulYaz("aciklama", i);

                XLS.HucreDegerYaz(satir, 0, satir - 2);
                XLS.HucreDegerYaz(satir, 1, i);
                XLS.HucreDegerYaz(satir, 2, d);
                d += 0.02M;
            }

            XLS.DosyaSaklaTamYol();
            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "CezalilarListesi", true, GenelIslemler.ExcelTur());
        }

        protected void btnClick(object sender, DirectEventArgs e)
        {
            ExcelYaz();
        }
    }
}
