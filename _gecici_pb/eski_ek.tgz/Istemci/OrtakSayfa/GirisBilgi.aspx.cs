﻿using System;
using System.Web.UI.WebControls;
using OrtakClass;
using Ext.Net.Utilities;
using Ext1.Net;
using System.Web.UI;
using TNS;

namespace OrtakSayfa
{
    public partial class GirisBilgi : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (Request.QueryString["islem"] + "" == "menuSakla")
            {
                AktifMenuKaydet(Request.QueryString["tur"] + "");
                return;
            }
            AspxdenYukle();
        }

        /// <summary>
        /// Kullanıcı üst menüyü tıklatıp alt menü açtığında açtığı tabın postback işleminden sonra tekrar gösterilebilmesi için açılan tab kayıt edilir. Ajax ile çağrılır.
        /// </summary>
        /// <param name="aktifMenu">Aktif tab numarası.</param>
        void AktifMenuKaydet(string aktifMenu)
        {
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "AKTIFMENU", aktifMenu);
        }

        public void AspxdenYukle()
        {
            string ldapAdres = TNS.DEG.Arac.DegiskenDegerBul(0, "LDAP");
            //LDAP değilse parola süre kontrolü yapılsın
            if (string.IsNullOrWhiteSpace(ldapAdres))
            {
                bool kontrol = GenelIslemler.ParolaSuresiKontrol(null, true, false);
                if (kontrol)
                {
                    GenelIslemler.ExtNotification("Parola kullanım süreniz dolmuştur. Güvenlik açısından parolanızı değiştirmeniz gerekmektedir. <a href='../KYM/ParolaDegistir.aspx'>Buraya</a> tıklayarak parola değiştirme sayfasını açabilirsiniz.", "Bilgi", Icon.Key);
                }
            }

            formAdi = Resources.Istemci.ISTGB006;
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            if (!X.IsAjaxRequest)
            {
                PortalColumn[] pcDizi = new PortalColumn[3];
                TNS.KYM.BilgiEkranYerlesim[] bilgiEkranYerlesim = TNS.KYM.Arac.ModulYerlesimBul(kullanan);
                for (int i = 0; i < 3; i++)
                {
                    PortalColumn pc = new PortalColumn();
                    pc.StyleSpec = "padding: 10px 10px 10px 10px;";
                    pc.ID = "portalcolumn" + i.ToString();
                    if (i == 0) pc.ColumnWidth = .50;
                    else if (i == 1) pc.ColumnWidth = .30;
                    else if (i == 2) pc.ColumnWidth = .20;
                    pcDizi[i] = pc;
                    PortalDB.Items.Add(pc);
                }
                for (int i = 0; i < bilgiEkranYerlesim.Length; i++)
                {
                    TNS.KYM.BilgiEkran bilgiEkran = TNS.KYM.Arac.bilgiEkranlar[bilgiEkranYerlesim[i].ekranIndex];
                    if (bilgiEkran.KullaniliyorMu())
                    {
                        Portlet pl = new Portlet();
                        pl.Title = bilgiEkran.BaslikBul();
                        pl.Height = bilgiEkran.yukseklik;
                        pl.AutoScroll = false;
                        pl.AutoWidth = true;
                        pl.ID = bilgiEkran.resId;
                        if (bilgiEkran.AyarVarMi())
                        {
                            Tool ti = new Tool(ToolType.Gear);
                            ti.Qtip = "Değişiklik Yap";
                            ti.Fn = "editPortlet";
                            ti.Handler = pl.ID + ".getBody().AyarAc();";
                            pl.Tools.Add(ti);
                        }
                        pl.Icons.Add(Icon.ApplicationViewDetail);
                        try
                        {
                            if (bilgiEkran.sayfaAdres.StartsWith(":"))
                            {
                                Istemci.DashBoard.Genel.Generic uc = (Istemci.DashBoard.Genel.Generic)LoadControl("../Dashboard/Genel/Generic.ascx");
                                uc.ClassPath = bilgiEkran.sayfaAdres;
                                pl.ContentControls.Add(uc);
                            }
                            else if (bilgiEkran.sayfaAdres.IndexOf(".ascx") > 0)
                            {
                                Control uc = LoadControl(bilgiEkran.sayfaAdres);
                                pl.ContentControls.Add(uc);
                            }
                            else
                            {
                                pl.AutoLoad.Url = bilgiEkran.sayfaAdres;
                                pl.AutoLoad.ShowMask = true;
                                pl.AutoLoad.Mode = LoadMode.IFrame;
                            }
                        }
                        catch (Exception ex)
                        {
                            pl.Html = ex.Message;
                        }
                        pcDizi[bilgiEkranYerlesim[i].ekranCol].Items.Add(pl);
                    }
                }
            }
        }

        public void AscxdenYukle()
        {
            formAdi = Resources.Istemci.ISTGB006;
            SayfaUstAltBolumYaz(this);
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
            if (!X.IsAjaxRequest)
            {
                //Control uc = LoadControl("../Dashboard/Evrak/EvrakSayisi.ascx");
                //Portlet5.ContentControls.Add(uc);

                //uc = LoadControl("../Dashboard/Genel/PersonelBilgisi.ascx");
                //Portlet2.ContentControls.Add(uc);

                //uc = LoadControl("../Dashboard/Genel/HavaDurumu.ascx");
                //Portlet1.ContentControls.Add(uc);

                //uc = LoadControl("../Dashboard/Genel/KurBilgisi.ascx");
                //Portlet6.ContentControls.Add(uc);

                //uc = LoadControl("../Dashboard/Genel/SikKullanilan.ascx");
                //Portlet3.ContentControls.Add(uc);
            }
        }
    }
}

