﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ExtGridGoster.aspx.cs"
    Inherits="OrtakSayfa.ExtGridGoster" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <script type="text/javascript">
        function HataGoster(hata) {
            alert(hata);
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:FitLayout ID="BorderLayout1" runat="server">
                <Items>
                    <ext:GridPanel runat="server" ID="grdRapor">
                    </ext:GridPanel>
                </Items>
            </ext:FitLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
