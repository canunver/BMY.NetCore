﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="SayfaMenu.aspx.cs" Inherits="OrtakSayfa.SayfaMenu" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <script type="text/javascript" language="javascript">
        function SayfaAc(adres, baslik) {
            altPencere.setTitle(baslik);
            altPencere.load(adres);
            altPencere.show();
        }
    </script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <div class="form">
        <asp:Literal ID="ltlLink" runat="server"></asp:Literal>
    </div>
    <ext:Window ID="altPencere" runat="server" Icon="Calendar" BodyStyle="background-color: #fff;"
        Hidden="true" Width="750" Height="450" Layout="AnchorLayout" Modal="true" Resizable="true">
        <AutoLoad Url="" ShowMask="true" Mode="IFrame">
        </AutoLoad>
    </ext:Window>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
