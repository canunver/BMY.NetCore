﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Uzay.aspx.cs" Inherits="Istemci.OrtakSayfa.Uzay" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript" src="../Script/EXTVeriYapistir.js?mc=03022015"></script>
    <script type="text/javascript">
    </script>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:Label runat="server" Text="UzayAd"></asp:Label>
        <asp:TextBox ID="txtUzayAd" runat="server" Width="30%"></asp:TextBox>
        <br />
        <asp:Label ID="Label1" runat="server" Text="UzaySorgu"></asp:Label>
        <asp:TextBox ID="txtUzaySorgu" runat="server" Width="90%"></asp:TextBox>
        <br />
        <asp:Label ID="Label4" runat="server" Text="UzayAlan"></asp:Label>
        <asp:TextBox ID="txtUzayAlan" runat="server" Width="90%"></asp:TextBox>
        <br />
        <asp:Button runat="server" ID="btnTest" Text="Sorgula" OnClick="deneme_click" />
        <br />
        <asp:Label ID="Label2" runat="server" Text="Cevap"></asp:Label>
        <asp:TextBox runat="server" ID="txtSonuc"></asp:TextBox>
        <br />
        <asp:Label ID="Label3" runat="server" Text="Sorgu"></asp:Label>
        <asp:TextBox runat="server" ID="txtSorgu" Width="90%" TextMode="MultiLine" Height="60" Wrap="true"></asp:TextBox>
        <%--
   <asp:Label ID="Label5" runat="server" Text="Ek alanlar"></asp:Label>
        <asp:TextBox ID="txtEkAlanlar" runat="server" Width="90%"></asp:TextBox>
        <br />
        <asp:Literal ID="ltlTable" runat="server"></asp:Literal>
        <asp:Label ID="Label6" runat="server" Text="Degisken Yıl"></asp:Label>
        <asp:TextBox runat="server" ID="txtDegiskenYil" Width="90%"></asp:TextBox>
        <asp:Label ID="Label7" runat="server" Text="Degisken Ad"></asp:Label>
        <asp:TextBox runat="server" ID="txtDegiskenAd" Width="90%"></asp:TextBox>
        <asp:Label ID="Label8" runat="server" Text="Degisken Değer"></asp:Label>
        <asp:TextBox runat="server" ID="txtDegiskenDeger" Width="90%"></asp:TextBox>
        <asp:Button runat="server" ID="btnDegiskenYaz" Text="Değisken Yaz" OnClick="btnDegiskenYaz_click" />
        <asp:Button runat="server" ID="btnChartYaz" Text="Chart Yaz" OnClick="btnChartYaz_click" />--%>
    </div>
    </form>
</body>
</html>
