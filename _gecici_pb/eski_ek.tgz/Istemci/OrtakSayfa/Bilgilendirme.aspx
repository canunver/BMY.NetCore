﻿<%@ Page Language="C#" CodeBehind="Bilgilendirme.aspx.cs" Inherits="OrtakSayfa.Bilgilendirme" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <table border="0" width="100%" cellpadding="3" cellspacing="3">
        <tr>
            <td>
                <div class="module bilgi">
                    <div>
                        <table width="100%" cellpadding="2" cellspacing="2">
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    <br />
                                    <asp:Label ID="lblKod" runat="server"></asp:Label><br />
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </td>
        </tr>
    </table>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
