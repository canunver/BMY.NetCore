﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
//using CrystalDecisions.CrystalReports.Engine;
//using CrystalDecisions.Shared;
using TNS.KYM;
using OrtakClass;
using TNS;
using Ext1.Net;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace Istemci.OrtakSayfa
{
    public partial class CRViewer : System.Web.UI.Page
    {
        string baglantiStr;
        string raporAd;
        Hashtable ht;
        protected void Page_Init(object sender, EventArgs e)
        {
            baglantiStr = GenelIslemlerIstemci.RequestBul(this, "baglanti", "BaglantiSatiriBHMv2");
            raporAd = GenelIslemlerIstemci.RequestBul(this, "raporAd", "");
            if (string.IsNullOrEmpty(raporAd)) return;
            ht = new Hashtable();
            int parSay = 0;
            while (true)
            {
                parSay++;
                string ek = parSay.ToString();
                string parAd = GenelIslemlerIstemci.RequestBul(this, "p" + ek, "");
                if (string.IsNullOrEmpty(parAd)) break;
                string parDeger = GenelIslemlerIstemci.RequestBul(this, "d" + ek, "");
                string parTip = GenelIslemlerIstemci.RequestBul(this, "t" + ek, "");
                object o;
                if (parTip == "1")
                    o = OrtakFonksiyonlar.ConvertToInt(parDeger, 0);
                else
                    o = parDeger;
                ht[parAd] = o;
            }
            GenerateReport();
        }

        protected void GenerateReport()
        {
            Kullanici kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);

            string userID = string.Empty;
            string password = string.Empty;
            string sunucu = string.Empty;
            string veriTabani = string.Empty;
            TNS.KYM.Arac.VeriTabaniBaglantiBilgileriniAl(kullanan, baglantiStr, out userID, out password, out sunucu, out veriTabani);

            //SqlConnection conStr = new SqlConnection(string.Format("Data Source={0};Initial Catalog={1};User ID={2};Password={3}", sunucu, veriTabani, userID, password));
            //SqlCommand cmd = new SqlCommand("SELECT * FROM Rep_GRBS ", conStr);
            //SqlDataAdapter adp = new SqlDataAdapter(cmd);
            //DataSet ds = new DataSet();
            //adp.Fill(ds, "Rep_GRBS");
            ConnectionInfo ci = new ConnectionInfo();
            ci.ServerName = sunucu;// string.Format("UID={0};PWD={1};Driver=SQL Server;Server={2};Database={3}", userID, password, sunucu, veriTabani);
            ci.DatabaseName = veriTabani;
            ci.UserID = userID;
            ci.Password = password;


            ReportDocument rapor = new ReportDocument();
            string raporSablonYol = TNS.Raporlama.RaporlamaServis.RaporSablonYolGetir(System.Configuration.ConfigurationManager.AppSettings.Get("RaporSablonYol") + "");
            rapor.Load(raporSablonYol + raporAd);
            foreach (DictionaryEntry item in ht)
            {
                rapor.SetParameterValue((string)item.Key, item.Value);
            }
            TablolariBagla(ci, rapor);
            CrystalReportViewer1.ReportSource = rapor;
            CrystalReportViewer1.DataBind();
        }

        private void TablolariBagla(ConnectionInfo connectionInfo, ReportDocument rapor)
        {
            foreach (CrystalDecisions.CrystalReports.Engine.Table tab in rapor.Database.Tables)
            {
                TableLogOnInfo logInfo = tab.LogOnInfo;
                logInfo.ConnectionInfo = connectionInfo;
                tab.ApplyLogOnInfo(logInfo);
            }
        }
    }
}