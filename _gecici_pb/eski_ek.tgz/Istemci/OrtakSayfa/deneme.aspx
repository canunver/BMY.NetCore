﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="deneme.aspx.cs" Inherits="Istemci.OrtakSayfa.deneme" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<%@ Register Assembly="OrtakClass" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title></title>
    <script type="text/javascript" language="javascript" src="../Script/EXTVeriYapistir.js?mc=03022015"></script>
    <script type="text/javascript">
        function btnClick() {
            ClipBoardVeriYaz("Can");
        }

        function btnClick2() {
        }

        //        function panelLoaded() {
        //            try {
        //                var chart;
        //                var store1 = new Ext1.data.JsonStore({
        //                    fields: ['name', 'data1', 'data2', 'data3'],
        //                    data: [{
        //                        name: 'Summer',
        //                        data1: 123,
        //                        data2: 147,
        //                        data3: 152
        //                    }, {
        //                        name: 'Fall',
        //                        data1: 118,
        //                        data2: 130,
        //                        data3: 160
        //                    }, {
        //                        name: 'Winter',
        //                        data1: 140,
        //                        data2: 125,
        //                        data3: 120
        //                    }, {
        //                        name: 'Spring',
        //                        data1: 130,
        //                        data2: 120,
        //                        data3: 100
        //                    }]
        //                });

        //                chart = new Ext1.chart.ColumnChart({
        //                    title: "Mest",
        //                    store: store1,
        //                    height: 325,
        //                    xField: 'name',
        //                    yField: 'data1',
        //                    legend: {
        //                        position: 'right'
        //                    },
        //                    animate: true,
        //                    shadow: true,
        //                    style: 'background:#fff',
        //                    xAxis: new Ext1.chart.CategoryAxis({
        //                        title: 'Month'
        //                    }),
        //                    yAxis: new Ext1.chart.NumericAxis({
        //                        title: '% Complete'
        //                    }),
        //                    extraStyle: {
        //                        xAxis: {
        //                            labelRotation: -90
        //                        }
        //                    }
        //                });

        //                chart = new Ext1.chart.Chart(
        //                {
        //                    id: 'chartCmp',
        //                    width: 300,
        //                    height: 300,
        //                    animate: true,
        //                    store: store1,
        //                    shadow: true,
        //                    theme: 'Category1',
        //                    legend: {
        //                        position: 'right'
        //                    },
        //                    axes: [{
        //                        type: 'Numeric',
        //                        grid:true,
        //                        position: 'left',
        //                        fields: ['data1', 'data2', 'data3'],
        //                        minimum: 0,
        //                        title: 'Number of Hits'
        //                    }, {
        //                        type: 'Category',
        //                        position: 'bottom',
        //                        fields: ['name'],
        //                        title: 'Month of the Year',
        //                        grid: true
        //                    }],
        //                    series: [{
        //                        type: 'bar',
        //                        axis: 'left',
        //                        xField: 'name',
        //                        yField: ['data1', 'data2', 'data3']
        //                    }]
        //                }
        //);

        //              var graphWin = new Ext1.Window({
        //                  title: 'Resizeable Graph Window',
        //                  resizeable: true,
        //                  width: 400,
        //                  height: 400,
        //                  layout: 'fit',
        //                  items: [chart]
        //              });
        //              graphWin.show();
        //                Chart1Panel.add(chart);
        //                Chart1Panel.doLayout();
        //            }
        //            catch (e) { alert(e.toString()); }

        //        }


        var veri = {
            "info": {
                "_postman_id": "d1c5104b-4220-4c47-b9e4-7a0617251c3d",
                "name": "YetniNetApinizerForPaksis",
                "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
                "_exporter_id": "30191684"
            },
            "item": [
                {
                    "name": "JWTtokenYetkinet",
                    "request": {
                        "method": "POST",
                        "header": [],
                        "body": {
                            "mode": "urlencoded",
                            "urlencoded": [
                                {
                                    "key": "grant_type",
                                    "value": "password",
                                    "type": "text"
                                },
                                {
                                    "key": "username",
                                    "value": "sgbNetUser",
                                    "type": "text"
                                },
                                {
                                    "key": "password",
                                    "value": "cid34h&9xH5o",
                                    "type": "text"
                                },
                                {
                                    "key": "client_id",
                                    "value": "13d32c2c-837b-45ea-a10b-6b6f0443d66b",
                                    "type": "text"
                                },
                                {
                                    "key": "client_secret",
                                    "value": "-",
                                    "type": "text"
                                }
                            ]
                        },
                        "url": {
                            "raw": "https://api.tarimorman.gov.tr/auth/jwt",
                            "protocol": "https",
                            "host": [
                                "api",
                                "tarimorman",
                                "gov",
                                "tr"
                            ],
                            "path": [
                                "auth",
                                "jwt"
                            ]
                        }
                    },
                    "response": []
                },
                {
                    "name": "ADKontrol",
                    "request": {
                        "method": "POST",
                        "header": [
                            {
                                "key": "Authorization",
                                "value": "eyJraWQiOiJiNmQyMmY1Ni04NzRmLTQ3MTEtYTc3OC1kNWNjNWJmMTg2NzgiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJndW5kZW1Vc2VyIiwiYXVkIjoiI0dXIzEzZDMyYzJjLTgzN2ItNDVlYS1hMTBiLTZiNmYwNDQzZDY2YiIsImV4cCI6MTY1MTEzNjE1NywianRpIjoiMktHZGUydTVBMFdnLUpLeGoyaG5mQSIsImlhdCI6MTY1MTEzMjU1NywiWC1BcHBsaWNhdGlvbk5hbWUiOiJZZXRraU5ldCIsIlgtQ2xpZW50SW5mbyI6Imd1bmRlbVVzZXIiLCJzY29wZSI6IiIsIlgtSXNzdWVkQXQiOiIyMDIyLTA0LTI4IDA3OjU1OjU3LjQxNSIsIlgtRXhwaXJlc0F0IjoiMjAyMi0wNC0yOCAwODo1NTo1Ny40MTUiLCJYLUV4cGlyZXNJbk1pbGxpcyI6MzYwMDAwMCwiWC1SZWZyZXNoVG9rZW4iOiI4ODA1OTBmNi0wNmI3LTQ1YzMtOGQ4Yy0yNzczNjZlZDUzNjMiLCJYLVJlZnJlc2hUb2tlbklzc3VlZEF0IjoiMjAyMi0wNC0yOCAwNzo1NTo1Ny40MTUiLCJYLVJlZnJlc2hUb2tlbkV4cGlyZXNJbk1pbGxpcyI6MTgwMDAwLCJYLVJlZnJlc2hUb2tlbkV4cGlyZXNBdCI6IjIwMjItMDQtMjggMDc6NTg6NTcuNDE1IiwiWC1SZWZyZXNoQ291bnQiOjB9.R3YzJCvzOEcXt2R2YOfrce0gtyuemrv7Akwa0A4GezBgNXofqe_xLZC1s17cYGiwsl6Ih51xPH-FQMek2hMOdSo_bvxhqoDw6OA4i7x89yF8ISwRm9B0FDoniUXE_SDHjiUcZDUE_K7t5aHF6zaBURdmNrjUx1Gs6B-4H1bhyQoUBLdAtzJY4X0yMzAyWzPIGYiJGSSJcosDH7TS6oKw80Ceal7bymzL46o-Kojx4nEIkW8kBju5TePPghuqNL-6rPKXUDb9HCRqzwUoNpU6j39yq9HD0EI6A9zrYWkF58c4_Uzml7zARJGr_m_jiIUqKgkXx6EPpRKD3hlw7bKQbQ",
                                "type": "text"
                            }
                        ],
                        "body": {
                            "mode": "raw",
                            "raw": "{\r\n    \"ADKontrol\": {\r\n        \"sKullaniciAdi\": \"\",\r\n        \"sParola\": \"\"\r\n    }\r\n}",
                            "options": {
                                "raw": {
                                    "language": "json"
                                }
                            }
                        },
                        "url": {
                            "raw": "https://api.tarimorman.gov.tr/YetkiNet/ADKontrol",
                            "protocol": "https",
                            "host": [
                                "api",
                                "tarimorman",
                                "gov",
                                "tr"
                            ],
                            "path": [
                                "YetkiNet",
                                "ADKontrol"
                            ]
                        }
                    },
                    "response": []
                }
            ],
            "auth": {
                "type": "bearer",
                "bearer": [
                    {
                        "key": "token",
                        "value": "eyJraWQiOiJiNmQyMmY1Ni04NzRmLTQ3MTEtYTc3OC1kNWNjNWJmMTg2NzgiLCJhbGciOiJSUzI1NiJ9.eyJYLUV4cGlyZXNBdCI6IjIwMjMtMDktMjlUMTQ6MDc6MzEuOTUxWiIsImF1ZCI6IiNHVyMxM2QzMmMyYy04MzdiLTQ1ZWEtYTEwYi02YjZmMDQ0M2Q2NmIiLCJYLUlzc3VlZEF0IjoiMjAyMy0wOS0yOVQxMzowNzozMS45NTFaIiwiWC1BcHBsaWNhdGlvbk5hbWUiOiJZZXRraU5ldEFEIiwic2NvcGUiOiIiLCJpc3MiOiJwYWtzaXNMZGFwVXNlciIsImV4cCI6MTY5NTk5NjQ1MSwiaWF0IjoxNjk1OTkyODUxLCJqdGkiOiJjMDhlMjdjZC1mZDljLTRjNDAtOTM5NS00ZWJmNjZkOTQ3MWEiLCJYLUV4cGlyZXNJbk1pbGxpcyI6MzYwMDAwMH0.lHrgIZjiiIhX9INgu3mrfkaABR8uoRGwi4-mjTZDsYwX4m7M9y62Wcg0JbSfJfw8gZEZh0J1Rc9vpiQZE6DPTWi6_6l4_zc82-hPjhJ7cfRTThJQ4ZjtZe0tg4RzSf3holQqpm8whrUlBQM29-dBZgddqC3rKXFkrKt2bi8p2_GBNNhE6N6CDl-tdXaK3qttSMJxEUKUvTK5bcHwc9GilUJeHKbCHMmuGItN5hrOr-JAR05ZKrHBNyxWV66clDmthZRVlWSXtbh5C_ZKNIL48fk8ohZMbIhB6CHVyFdd6BYMwn9NIkEvUvBEYFwrrBMs69aX5hrhXhPnK0IsAMW0Gg\"",
                        "type": "string"
                    }
                ]
            },
            "event": [
                {
                    "listen": "prerequest",
                    "script": {
                        "type": "text/javascript",
                        "exec": [
                            ""
                        ]
                    }
                },
                {
                    "listen": "test",
                    "script": {
                        "type": "text/javascript",
                        "exec": [
                            ""
                        ]
                    }
                }
            ]
        }

        function BilgiYaz(mesaj) {
            console.log(mesaj);
            txtSonuc.setValue(mesaj);
        }
        function AjaxCall() {
            const xhttp = new XMLHttpRequest();
            xhttp.onload = function () {
                BilgiYaz(this.responseText);
            };

            xhttp.onreadystatechange = function () {
                BilgiYaz("onreadystatechange" + this.readyState);
                if (this.readyState == 4)
                    if (this.status != 200) {
                        BilgiYaz("status:" + this.status)
                    }
            };

            BilgiYaz("Başladı" + veri.item[0].name);

            xhttp.open("POST", "https://api.tarimorman.gov.tr/auth/jwt");
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send();
        }
    </script>
</head>
<body>
    <form id="form1" runat="server">
        <ext:ResourceManager ID="rm1x" runat="server" />
        <ext:Viewport runat="server" Layout="FitLayout">
            <Items>
                <ext:FormPanel runat="server">
                    <TopBar>
                        <ext:Toolbar runat="server">
                            <Items>
                                <ext:Button runat="server" ID="btnx" Text="Test Button">
                                    <DirectEvents>
                                        <Click OnEvent="btnx_Click" IsUpload="true" />
                                    </DirectEvents>
                                </ext:Button>

                                <ext:Button runat="server" ID="Button1" Text="AJAX Test">
                                    <DirectEvents>
                                        <Click OnEvent="AjaxCall" />
                                    </DirectEvents>
                                </ext:Button>

                            </Items>
                        </ext:Toolbar>
                    </TopBar>
                    <Items>
                        <ext:NumberField runat="server" ID="nfRakam" FieldLabel="Solda Alan" Width="400" Text="2">
                        </ext:NumberField>
                        <ext:NumberField runat="server" ID="nfRakam2" FieldLabel="Ustte Alan" Width="400" Text="2">
                        </ext:NumberField>
                        <ext:DateField runat="server" ID="dfTar1" FieldLabel="Tar 1" Width="400">
                        </ext:DateField>
                        <ext:DateField runat="server" ID="dfTar2" FieldLabel="Tar 2" Width="400">
                        </ext:DateField>
                        <ext:Checkbox runat="server" ID="cbIsGunu" FieldLabel="İş Günü" BoxLabel="Evet">
                        </ext:Checkbox>
                        <ext:TextField runat="server" ID="txtSonuc" FieldLabel="İş Günü" AnchorHorizontal="90%" />
                        <ext:Label runat="server" ID="lbltut" AnchorHorizontal="90%" />
                    </Items>
                </ext:FormPanel>
            </Items>
        </ext:Viewport>
        <%--    <ext:GridPanel runat="server" Height="150" ID="gpx">
        <TopBar>
            <ext:Toolbar runat="server">
                <Items>
                    <ext:Button runat="server" Text="Bas">
                        <Listeners>
                            <Click Handler="EXTVeriYapistir(gpx, 0 ,0);" />
                        </Listeners>
                    </ext:Button>
                </Items>
            </ext:Toolbar>
        </TopBar>
        <Store>
            <ext:Store runat="server" ID="stoKaynak">
                <Reader>
                    <ext:JsonReader>
                        <Fields>
                            <ext:RecordField Name="t1">
                            </ext:RecordField>
                            <ext:RecordField Name="t5">
                            </ext:RecordField>
                            <ext:RecordField Name="t2" Type="Float">
                            </ext:RecordField>
                            <ext:RecordField Name="t3" Type="Int">
                            </ext:RecordField>
                            <ext:RecordField Name="t4" Type="Boolean">
                            </ext:RecordField>
                            <ext:RecordField Name="t6">
                            </ext:RecordField>
                        </Fields>
                    </ext:JsonReader>
                </Reader>
            </ext:Store>
        </Store>
        <ColumnModel>
            <Columns>
                <ext:Column DataIndex="t6" Hidden="true">
                    <Editor>
                        <ext:TextField ID="TextField1" runat="server">
                        </ext:TextField>
                    </Editor>
                </ext:Column>
                <ext:Column DataIndex="t1" Hidden="false">
                    <Commands>
                        <ext:ImageCommand Icon="Add">
                        </ext:ImageCommand>
                    </Commands>
                </ext:Column>
                <ext:Column DataIndex="t5">
                    <Editor>
                        <ext:TextField runat="server">
                        </ext:TextField>
                    </Editor>
                </ext:Column>
                <ext:CommandColumn>
                    <Commands>
                        <ext:GridCommand Text="E">
                        </ext:GridCommand>
                    </Commands>
                </ext:CommandColumn>
                <ext:CheckColumn DataIndex="t4">
                    <Editor>
                        <ext:Checkbox runat="server">
                        </ext:Checkbox>
                    </Editor>
                </ext:CheckColumn>
                <ext:NumberColumn DataIndex="t2">
                    <Editor>
                        <ext:NumberField runat="server">
                        </ext:NumberField>
                    </Editor>
                </ext:NumberColumn>
                <ext:NumberColumn DataIndex="t3">
                    <Editor>
                        <ext:NumberField ID="NumberField1" runat="server">
                        </ext:NumberField>
                    </Editor>
                </ext:NumberColumn>
            </Columns>
        </ColumnModel>
    </ext:GridPanel>
        --%>
        <%--  
    <asp:TextBox ID="txtCode" runat="server" Height="213px" TextMode="MultiLine" 
        Width="587px"></asp:TextBox>
    <br />
    <asp:Button Text="Kod Ekle" runat="server" OnClick="btnKodEkle_Click" />
    <asp:Button Text="Çalıştır" runat="server" OnClick="btnElma_Click" 
        ID="Button1" />
    <br />
    <asp:TextBox ID="txt" runat="server" Width="583px"></asp:TextBox>--%>
        <%--<div>
        <asp:Label runat="server" Text="UzayAd"></asp:Label>
        <asp:TextBox ID="txtUzayAd" runat="server" Width="30%"></asp:TextBox>
        <br />
        <asp:Label ID="Label1" runat="server" Text="UzaySorgu"></asp:Label>
        <asp:TextBox ID="txtUzaySorgu" runat="server" Width="90%"></asp:TextBox>
        <br />
        <asp:Label ID="Label4" runat="server" Text="UzayAlan"></asp:Label>
        <asp:TextBox ID="txtUzayAlan" runat="server" Width="90%"></asp:TextBox>
        <br />
        <asp:Label ID="Label5" runat="server" Text="Ek alanlar"></asp:Label>
        <asp:TextBox ID="txtEkAlanlar" runat="server" Width="90%"></asp:TextBox>
        <br />
        <asp:Label ID="Label2" runat="server" Text="Cevap"></asp:Label>
        <asp:TextBox runat="server" ID="txtSonuc"></asp:TextBox>
        <asp:Label ID="Label3" runat="server" Text="Sorgu"></asp:Label>
        <asp:TextBox runat="server" ID="txtSorgu" Width="90%"></asp:TextBox>
        <asp:Button runat="server" ID="btnTest" Text="deneme" OnClick="deneme_click" />
        <asp:Literal ID="ltlTable" runat="server"></asp:Literal>
        <asp:Label ID="Label6" runat="server" Text="Degisken Yıl"></asp:Label>
        <asp:TextBox runat="server" ID="txtDegiskenYil" Width="90%"></asp:TextBox>
        <asp:Label ID="Label7" runat="server" Text="Degisken Ad"></asp:Label>
        <asp:TextBox runat="server" ID="txtDegiskenAd" Width="90%"></asp:TextBox>
        <asp:Label ID="Label8" runat="server" Text="Degisken Değer"></asp:Label>
        <asp:TextBox runat="server" ID="txtDegiskenDeger" Width="90%"></asp:TextBox>
        <asp:Button runat="server" ID="btnDegiskenYaz" Text="Değisken Yaz" OnClick="btnDegiskenYaz_click" />
        <asp:Button runat="server" ID="btnChartYaz" Text="Chart Yaz" OnClick="btnChartYaz_click" />
    </div>--%>
    </form>
</body>
</html>
