﻿namespace OrtakSayfa
{
    internal class BilgiVAN
    {
    }
}