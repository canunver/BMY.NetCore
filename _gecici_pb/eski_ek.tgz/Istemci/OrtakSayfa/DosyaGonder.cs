﻿using System.Web;
using System;
namespace OrtakSayfa
{
    public class DosyaGonderHandler : IHttpHandler
    {
        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.Clear();
            OrtakClass.DosyaIslem.DosyaGonderX(@"C:\sources\asp.net\Sgb.NETv2\Istemci\Dosyalar\Falan.pdf", "Yalan.pdf", false, "pdf", false);
        }
    }
}