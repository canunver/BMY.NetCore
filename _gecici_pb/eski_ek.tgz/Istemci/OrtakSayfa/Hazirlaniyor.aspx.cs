﻿using System;
using System.IO;
using System.Web.UI.WebControls;
using OrtakClass;

namespace OrtakSayfa
{
    public partial class Hazirlaniyor : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Hazırlanıyor";
            SayfaUstAltBolumYaz(this);

            lblHazirlaniyor.Text = "Bu sayfa hazırlanma aşamasındadır.";

            //int a = 0;
            //int b = 5 / a;//TCCB hata üretilmesi için

            throw new FileLoadException("Dosya yok hatası");

            //TNS.KYM.Kullanici k = null;
            //string adi = k.ad;
        }
    }
}
