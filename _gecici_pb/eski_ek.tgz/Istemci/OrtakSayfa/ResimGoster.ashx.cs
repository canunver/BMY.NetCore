﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Drawing;

namespace Istemci.OrtakSayfa
{
    /// <summary>
    /// Summary description for ResimGoster
    /// </summary>
    public class ResimGoster : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            try
            {
                string path = context.Request["path"] + "";
                if (string.IsNullOrEmpty(path))
                    return;

                Image img = OrtakClass.ResimIslemleri.LoadImageFromPath(path);
                System.IO.MemoryStream ms = new System.IO.MemoryStream();
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                img.Dispose();
                context.Response.ClearContent();
                context.Response.ContentType = "image/JPEG";
                context.Response.Buffer = false;
                context.Response.BinaryWrite(ms.ToArray());
                context.Response.Flush();
                context.Response.End();
            }
            catch { return; }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}