﻿using System;
using System.Web.Security;
using OrtakClass;
using TNS.KYM;
using TNS;
using System.Text;

namespace OrtakSayfa
{
    public partial class GorevYonetimiEntegrasyon : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Kullanici kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);

            string sUrl = System.Configuration.ConfigurationManager.AppSettings.Get("GorevURL") + "";
            if (string.IsNullOrEmpty(sUrl))
            {
                GenelIslemler.SayfayaGirmesin(false, "Görev Yönetimi Sistemi sayfaları bulunamadı.");
                return;
            }

            bool yetkiVar = kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI, (int)ENUMKullaniciTipi.GOREVYONETIMIKULLANICISI);
            if (!yetkiVar)
            {
                GenelIslemler.SayfayaGirmesin(false, "Görev Yönetimi Sistemini kullanma yetkiniz yok. Sİstem Yöneticisine başvurun.");
                return;
            }

            string tcKimlikNo = kullanan.mernis;
            string adi = kullanan.ad;
            string soyadi = kullanan.soyad;
            string unvan = kullanan.unvan;
            string kkodu = kullanan.kullaniciKodu;
            string parola = kullanan.parola;
            string eposta = kullanan.emailAdresi;
            string kultur = kullanan.aktifKultur;
            string yetkiliBirimler = kullanan.yetkiTipiDegerleri["Görev Yönetimi Sistemi Birimi"];
            string yetkiliRoller = kullanan.yetkiTipiDegerleri["Görev Yönetimi Sistemi Rolü"];
            string sayfa = Request.QueryString["sayfa"] + "";

            string sablon = "TCKIMLIKNO:'{0}', ADI:'{1}', SOYADI:'{2}', UNVAN:'{3}', KKODU:'{4}', PAROLA:'{5}', EPOSTA:'{6}', KULTUR:'{7}', YETKILIBIRIMLER:'{8}', YETKILIROLLER:'{9}', GIRISTARIHI:'{10}', SAYFA:'{11}'";
            string giris = string.Format(sablon, tcKimlikNo, adi, soyadi, unvan, kkodu, parola, eposta, kultur, yetkiliBirimler, yetkiliRoller, DateTime.Now.ToString(), sayfa);
            giris = "{" + giris + "}";
            giris = OrtakFonksiyonlar.Sifrele(giris, "GorevSistemi(GIT2014)");
            sUrl += "?param=" + giris;

            //string yonlendirenSayfa = Request.UrlReferrer.PathAndQuery;
            //ClientScript.RegisterStartupScript(this.GetType(), "anasayfa", "window.top.location='" + yonlendirenSayfa + "';", true);
            //ClientScript.RegisterStartupScript(this.GetType(), "forum", "window.open('" + sUrl + "','_blank');", true);

            ClientScript.RegisterStartupScript(this.GetType(), "anasayfa", "window.top.location='" + sUrl + "';", true);
        }
    }
}
