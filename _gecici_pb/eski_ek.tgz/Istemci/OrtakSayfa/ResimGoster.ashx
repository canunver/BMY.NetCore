﻿<%@ WebHandler Language="C#" CodeBehind="ResimGoster.ashx.cs" Class="Istemci.OrtakSayfa.ResimGoster" %>
