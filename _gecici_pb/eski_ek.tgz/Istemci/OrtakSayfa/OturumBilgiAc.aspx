﻿<%@ Page Language="C#" CodeBehind="OturumBilgiAc.aspx.cs" Inherits="OrtakSayfa.OturumBilgiAc" EnableViewState="false" %>
<html>
<head>
    <title></title>
    <script type="text/javascript">
        window.close();
    </script>
    
</head>
	<body>
    </body>
</html>
