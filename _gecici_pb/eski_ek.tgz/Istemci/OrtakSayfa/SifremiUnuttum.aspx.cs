﻿using System;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using OrtakClass;

namespace OrtakSayfa
{
    public partial class SifremiUnuttum : System.Web.UI.Page
    {
        IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();

        protected void Page_Load(object sender, System.EventArgs e)
        {
            //formAdi = "Şifremi Unuttum";
            lblHata.Hidden = true;
        }

        protected void btnParolaDegistir_Click(object sender, System.EventArgs e)
        {
            string gelenBilgi = txtTCKimlikNo.Text.Trim();

            if (gelenBilgi != "")
            {
                string uye = servisKYM.KullaniciVarMi(gelenBilgi);
                if (uye == "")
                    GenelIslemler.MesajKutusu(this, "Verilen T.C Kimlik Numarası/E-Posta Adresi bilgisine ait bir kullanıcı bulunamadı.");
                else
                {
                    string[] parcalar = uye.Split('-');
                    string kisi = parcalar[0];
                    if (parcalar.Length > 1)
                    {
                        string tcNo = parcalar[1];

                        Sonuc sonuc = servisKYM.KullaniciyaYeniParolaAta(tcNo.Trim());
                        if (sonuc.islemSonuc)
                        {
                            GenelIslemler.MesajKutusu(this, "Yeni parolanız e-posta adresine gönderildi. (" + kisi + ")");
                            ClientScript.RegisterStartupScript(this.GetType(), "kapat", "parent.hidePopWin();", true);
                        }
                        else
                            GenelIslemler.MesajKutusu(this, "Yeni parola oluşturma işleminde hata oluştu.");
                    }
                }
            }
            else
                GenelIslemler.MesajKutusu(this, "Lütfen T.C Kimlik Numarası veya E-Posta Adresi bilgisini girin.");
        }
    }
}
