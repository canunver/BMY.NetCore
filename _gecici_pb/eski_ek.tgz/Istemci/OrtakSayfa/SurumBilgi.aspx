﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="SurumBilgi.aspx.cs" Inherits="OrtakSayfa.SurumBilgi" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager ID="ResourceManager1" runat="server" ViewStateMode="Enabled" />
    <ext:Store ID="listeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="ad" />
                    <ext:RecordField Name="tarih" Type="Date" />
                    <ext:RecordField Name="surum" />
                    <ext:RecordField Name="firma" />
                </Fields>
            </ext:JsonReader>
        </Reader>
        <SortInfo Field="ad" />
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center MarginsSummary="104 20 10 20">
                    <ext:GridPanel ID="grdListe" runat="server" StoreID="listeStore" StripeRows="true"
                        Header="false" StyleSpec="background-color:white;padding:10px" TrackMouseOver="true">
                        <TopBar>
                            <ext:Toolbar runat="server">
                                <Items>
                                    <ext:Checkbox ID="chkSGBdll" runat="server" BoxLabel="<%$Resources:Istemci,ISTSUR002 %>"
                                        AutoPostBack="true">
                                    </ext:Checkbox>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <SelectionModel>
                            <ext:RowSelectionModel SingleSelect="true">
                            </ext:RowSelectionModel>
                        </SelectionModel>
                        <ColumnModel ID="ColumnModel1" runat="server">
                            <Columns>
                                <ext:Column ColumnID="ad" DataIndex="ad" Header="Dosya Adı" Align="Left" Width="150">
                                </ext:Column>
                                <ext:DateColumn ColumnID="tarih" DataIndex="tarih" Header="Dosya Tarihi" Width="100"
                                    Format="dd.MM.yyyy HH:mm">
                                </ext:DateColumn>
                                <ext:Column ColumnID="surum" DataIndex="surum" Header="Sürüm" Align="Left" Width="100">
                                </ext:Column>
                                <ext:Column ColumnID="firma" DataIndex="firma" Header="Üretici Firma" Align="Left"
                                    Width="200">
                                </ext:Column>
                            </Columns>
                        </ColumnModel>
                    </ext:GridPanel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
