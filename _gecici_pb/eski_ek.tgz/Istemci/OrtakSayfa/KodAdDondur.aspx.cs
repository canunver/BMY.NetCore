using System;
using System.Web.UI.WebControls;
using OrtakClass;
using Ext1.Net;
using System.Data;

namespace OrtakSayfa
{
    public partial class KodAdDondur : System.Web.UI.Page
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            Response.Cache.SetExpires(DateTime.Now);

            string yil = Request.QueryString["yil"] + "";
            string kodTur = Request.QueryString["kodTur"] + "";
            string kosul = GenelIslemler.TurkceleAJAX(Request.QueryString["kosul"] + "");
            string degerYazKontrol = Request.QueryString["degerYazKontrol"] + "";
            if (degerYazKontrol.Length > 15 || degerYazKontrol.IndexOf(' ') >= 0)
                degerYazKontrol = "00";
            string esitle = Request.QueryString["esitle"] + "";

            bool bEsitle = true;

            if (esitle != "")
            {
                try { bEsitle = Convert.ToBoolean(esitle); }
                catch { }
            }

            string ad = GenelIslemler.KodAd(Convert.ToInt16(kodTur), kosul, bEsitle);

            Response.Write(degerYazKontrol + "," + ad);
        }
    }
}
