﻿<%@ Page Language="c#" Inherits="OrtakSayfa.Hata" CodeBehind="Hata.aspx.cs" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <title></title>
</head>
<body>
    <form runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <div id="divHata" runat="server" class="hataKutusu">
        Yapmak istediğiniz işlem, aşağıda listelenen nedenden dolayı <b>hata</b> ile sonuçlandı.
        Lütfen hatayı düzelterek işleminizi tekrar deneyin.
        <asp:Label ID="lblHata" runat="server"></asp:Label>
    </div>
    <div id="divInfo" runat="server" class="uyariKutusu">
        Yapmak istediğiniz işlemin sonucu aşağıda listelenmiştir.
        <asp:Label ID="lblUyari" runat="server"></asp:Label>
    </div>
    <br />
    </form>
</body>
</html>
