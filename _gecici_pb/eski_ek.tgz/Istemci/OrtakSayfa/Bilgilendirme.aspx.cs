using System;
using System.Web.UI.WebControls;
using OrtakClass;

namespace OrtakSayfa
{
    public partial class Bilgilendirme : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = "Bilgilendirme";
            SayfaUstAltBolumYaz(this);

            lblKod.Text = (string)Session["BilgiSatiri"];
        }
    }
}
