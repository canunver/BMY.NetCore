﻿using System;
using System.Diagnostics;
using System.IO;
using System.Data;
using TNS;

namespace OrtakSayfa
{
    public partial class SurumBilgi : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = Resources.Istemci.ISTSUR001;

            if (!IsPostBack)
            {
                SayfaUstAltBolumYaz(this);
            }
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //string anaYol = @"D:\inetpub\wwwroot\sgb.netV2\Istemci\bin";
            System.Reflection.Assembly sistemBilgi = System.Reflection.Assembly.GetExecutingAssembly();
            string anaYol = Path.GetDirectoryName(sistemBilgi.CodeBase);
            anaYol = anaYol.Replace("file:\\", "");

            DataTable dt = new DataTable();

            dt.Columns.Add("ad");
            dt.Columns.Add("tarih", Type.GetType("System.DateTime"));
            dt.Columns.Add("surum");
            dt.Columns.Add("firma");

            DirectoryInfo dirInfo = new DirectoryInfo(anaYol);
            if (dirInfo.Exists)
            {
                FileInfo[] files = dirInfo.GetFiles();

                foreach (FileInfo f in files)
                {
                    if (f.Extension != ".dll") continue;
                    string dosyaYolu = Path.Combine(anaYol, f.Name);

                    FileVersionInfo fInfo = FileVersionInfo.GetVersionInfo(dosyaYolu);

                    string firmaAdi = fInfo.CompanyName + "";
                    if (chkSGBdll.Checked && !firmaAdi.StartsWith("SGB.net")) continue;

                    dt.Rows.Add(f.Name, f.LastWriteTime.ToString(), fInfo.FileVersion, firmaAdi);
                }
            }
            listeStore.DataSource = dt;
            listeStore.DataBind();
        }
    }
}