﻿<%@ Page Language="C#" CodeBehind="BeklenmedikHata.aspx.cs" Inherits="OrtakSayfa.BeklenmedikHata" EnableSessionState="True" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <script language="javascript" type="text/javascript" src="../script/hideshow.js?mc=03022015"></script>
</head>
<body style="margin: 30px 30px 30px 30px">
    <form id="form1" runat="server">
    <div class="hataKutusu">
        <div>
            <table width="100%" cellpadding="2" cellspacing="2">
                <tr>
                    <td>
                        <p>
                            Yapmak istediğiniz işlem,&nbsp; beklenmeyen bir <b>hata</b> ile sonuçlandı.</p>
                        <p>
                            Hata sistem tarafından kaydedilmiştir. En kısa zamanda hata düzeltilecektir.</p>
                        <p>
                            <strong>Elimizde olmayan bu durumdan dolayı özür dileriz.</strong></p>
                        <div class="bilgiKutusu">
                            <li><a href="#" onclick="javascript:history.back()">Önceki sayfaya dönmek için tıklayın.</a></li>
                            <li><a href="#" onclick="javascript:hideshow('degerBolgesi')">Oluşan hata ile ilgili
                                detay bilgileri görmek için tıklayın.</a></li>
                            <div id="degerBolgesi">
                                <table id="tblAna2" cellspacing="2" cellpadding="2" width="100%" align="center" border="0">
                                    <tr>
                                        <td>
                                            &nbsp;
                                        </td>
                                        <td>
                                            <br />
                                            <asp:Label ID="lblHata" runat="server"></asp:Label>
                                            <br />
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    </form>
</body>
</html>
