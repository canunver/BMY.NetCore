﻿<%@ Page Language="C#" CodeBehind="SifreUret.aspx.cs" Inherits="OrtakSayfa.SifreUret" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="~/App_themes/Form.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <form id="form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <div class="form">
        <div class="row">
            <div class="yaziAlanK">
                İşlenecek Veri</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtGirdi" runat="server" CssClass="veriAlan" Columns="150"></asp:TextBox></div>
            <div class="kolonArasi">
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                İşlenen Veri</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtCikti" runat="server" CssClass="veriAlan" Columns="150"></asp:TextBox></div>
            <div class="kolonArasi">
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Anahtar</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtAnahtar" runat="server" CssClass="veriAlan" Columns="150"></asp:TextBox></div>
            <div class="kolonArasi">
            </div>
        </div>
        <div class="footer">
            &nbsp;</div>
    </div>
    <br />
    <div class="row" style="width: 729px">
        <asp:Button ID="btnSifrele" runat="server" TabIndex="1" Width="100px" Text="Şifrele"
            CssClass="dugme" OnClick="btnSifrele_Click"></asp:Button>&nbsp;
        <asp:Button ID="btnSifreCoz" runat="server" TabIndex="2" Width="100px" Text="Şifre Çöz"
            CssClass="dugme" OnClick="btnSifreCoz_Click"></asp:Button>
    </div>
    <br />
    </form>
</body>
</html>
