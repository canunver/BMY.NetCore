﻿<%@ Page Language="C#" CodeBehind="SureUzat.aspx.cs" Inherits="OrtakSayfa.SureUzat"
    EnableViewState="false" %>

<html>
<head>
    <title></title>

    <script type="text/javascript">
        function yenile() {

            sx = window.location.href;
            var yer = sx.indexOf('?v');
            if (yer > 0)
                sx = sx.substring(0, yer);
            window.location = sx + "?v=" + String(Math.random()).substr(2, 1)

        }
        setTimeout('yenile()', 15 * 60 * 1000)
    </script>

</head>
<body>
</body>
</html>
