﻿using System;
using System.Xml;
using OrtakClass;

namespace OrtakSayfa
{
    public partial class SayfaMenu : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["menuID"]))
                    SayfaMenuYaz(Request.QueryString["menuID"]);
            }
            //Sayfa adı bilgisi postback kısmından geliyor
            SayfaUstAltBolumYaz(this);
        }

        private void SayfaMenuYaz(string menuID)
        {
            XmlNode anaNode = GenelIslemlerIstemci.MenuNodeBul(kullanan, menuID, true);
            if (anaNode != null)
            {
                //GenelIslemler.HataYaz(this, string.Format(Resources.Istemci.IST038, menuID));
                //return;
                string text = istemciUzayi.GenelSayfa.MenuAd(anaNode, menuID);
                formAdi = string.IsNullOrEmpty(text) ? Resources.Istemci.ResourceManager.GetString(GenelIslemlerIstemci.OzellikVer(anaNode, "ID")) : text;
                ltlLink.Text = "<table><tr>" + SayfaMenuOlustur(anaNode) + "</tr></table>";
            }
        }

        private string SayfaMenuOlustur(XmlNode anaNode)
        {
            string urlLink = string.Empty;

            if (anaNode == null || !anaNode.HasChildNodes)
                return urlLink;

            for (int i = 0; i < anaNode.ChildNodes.Count; i++)
            {
                XmlNode node = anaNode.ChildNodes[i];

                string url = GenelIslemlerIstemci.OzellikVer(node, "URL");
                string id = GenelIslemlerIstemci.OzellikVer(node, "ID");
                string text = istemciUzayi.GenelSayfa.MenuAd(node, id);
                string tip = GenelIslemlerIstemci.OzellikVer(node, "Tip");
                string altPencere = GenelIslemlerIstemci.OzellikVer(node, "AltPencere");

                if (!string.IsNullOrEmpty(id))
                    text = string.IsNullOrEmpty(text) ? Resources.Istemci.ResourceManager.GetString(id) : text;
                else
                    text = "";

                if (tip == "Kolon")
                    urlLink += "<td style=\"vertical-align:top;width:180px\">";

                if (!string.IsNullOrEmpty(url) && !string.IsNullOrEmpty(text))
                {
                    if(altPencere=="1")
                        urlLink += "<a alt='" + text + "' onclick=\"SayfaAc('" + url + "', '" + text + "');\">" + text + "</a>" + "<br />";
                    else
                        urlLink += "<a href='" + url + "' alt='" + text + "' target='_top'>" + text + "</a>" + "<br />";
                    if (i == anaNode.ChildNodes.Count - 1)
                        urlLink += "<br />";
                }
                else if (!string.IsNullOrEmpty(url))
                {
                    urlLink += "<a href='" + url + "' alt='" + id + "' target='_top'>" + id + "</a>" + "<br />";
                    if (i == anaNode.ChildNodes.Count - 1)
                        urlLink += "<br />";
                }
                else if (!string.IsNullOrEmpty(text))
                {
                    if (tip == "UstMenu")
                        urlLink += "<strong style=\"font-size:medium;color:red\">" + text + "</strong>" + "<br />";
                    else if (tip == "AltBolum")
                        urlLink += "<strong style=\"font-size:small;color:red\">" + text + "</strong>" + "<br />";
                    else
                        urlLink += text + "<br />";
                }

                urlLink += SayfaMenuOlustur(node);

                if (tip == "Kolon")
                    urlLink += "</td><td>&nbsp;&nbsp;</td>";
            }

            return urlLink;
        }
    }
}