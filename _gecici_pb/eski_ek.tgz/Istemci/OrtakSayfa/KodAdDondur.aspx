﻿<%@ Page language="c#" Inherits="OrtakSayfa.KodAdDondur" CodeBehind="KodAdDondur.aspx.cs" %>
