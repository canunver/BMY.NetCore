﻿using System;
using System.Data;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI;
using TNS;
using OrtakClass;

namespace Istemci.OrtakSayfa
{
    public partial class SiteHaritasiForm : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (!IsPostBack)
            {
                Listele();
            }
        }

        private void Listele()
        {
            if (kullanan == null)
                kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false);

            string[] yetkiKod;
            if (kullanan.kullaniciTipi != null)
            {
                yetkiKod = new string[kullanan.kullaniciTipi.Length];

                for (int i = 0; i < kullanan.kullaniciTipi.Length; i++)
                    yetkiKod[i] = ((int)kullanan.kullaniciTipi[i]).ToString();
            }
            else
                yetkiKod = null;

            TNS.XMLBirim xml;
            try
            {
                string xmlYolDosya = System.Configuration.ConfigurationManager.AppSettings.Get("MenuXML");
                xml = TNS.XMLBirim.XMLOku(xmlYolDosya);
            }
            catch (Exception)
            {
                xml = null;
            }

            if (xml != null)
            {
                TNS.TNSCollection menuListe = new TNS.TNSCollection();
                string menuIcerik = "";

                ListeOlustur(xml, yetkiKod, ref menuIcerik);
                if (menuIcerik != "")
                {
                    if (menuIcerik.StartsWith("<ul>"))
                        menuIcerik = menuIcerik.Insert(3, " class='treeview'");

                    if (menuIcerik.EndsWith("</li>"))
                        menuIcerik = menuIcerik.Substring(0, menuIcerik.Length - 5);

                    ltlListe.Text = menuIcerik;
                }

            }
        }

        private void ListeOlustur(TNS.XMLBirim xml, string[] yetkiKod, ref string menuIcerik)
        {
            string icerik = "";
            TNS.XMLBirim cocuk;
            int cocukSayisi = xml.CocukSayisi();
            bool yetkiVar = false;
            string text = "";

            if (cocukSayisi > 0)
            {
                menuIcerik += "<ul>";
                for (int i = 0; i < cocukSayisi; i++)
                {
                    cocuk = xml.CocukAl(i);
                    yetkiVar = YetkiKontrol(cocuk.OzellikAl("Yetki"), yetkiKod);

                    if (yetkiVar)
                    {
                        //Erdal --- menuID kalktı
                        //id = cocuk.OzellikAl("ID");
                        //text = istemciUzayi.GenelSayfa.KaynakOkuIstemci(cocuk.OzellikAl("ID"));
                        //url = cocuk.OzellikAl("URL");

                        //if (url.IndexOf("?") > -1) { ayirac = "&"; } else { ayirac = "?"; }
                        //icerik = "<li><a onclick=\"javascript:go('" + url + ayirac + "menuID=" + id + "');return false;\" target='_parent' style=\"color: black; text-decoration: none;\" onmouseover=\"this.style.textDecoration='underline';window.status='" + text + "';\" onmouseout=\"this.style.textDecoration='none'\">" + text + "</a>";
                        ////icerik = "<li><a href='" + url + ayirac + "menuID=" + id + "' target='_parent'>" + text + "</a>";

                        text = istemciUzayi.GenelSayfa.KaynakOkuIstemci(cocuk.OzellikAl("ID"));
                        icerik = "<li><a onclick=\"javascript:go('" + cocuk.OzellikAl("URL") + "');return false;\" target='_parent' style=\"color: black; text-decoration: none;\" onmouseover=\"this.style.textDecoration='underline';window.status='" + text + "';\" onmouseout=\"this.style.textDecoration='none'\">" + text + "</a>";

                        if (cocuk.CocukSayisi() == 0)
                        {
                            menuIcerik += icerik;
                            menuIcerik += "</li>";
                        }
                        else
                        {
                            if (icerik.StartsWith("<li>")) { icerik = icerik.Insert(3, " class='submenu'"); }
                            menuIcerik += icerik;
                            ListeOlustur(cocuk, yetkiKod, ref menuIcerik);
                        }
                    }
                }
                menuIcerik += "</ul></li>";
            }

        }
        private bool YetkiKontrol(string yetki, string[] yetkiKod)
        {
            if (!string.IsNullOrEmpty(yetki))
            {
                foreach (var yetkiXml in yetki.Split(','))
                    foreach (string yetkiKullanici in yetkiKod)
                        if (yetkiXml == yetkiKullanici) { return true; }
            }
            return false;
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            base.ClientScript.RegisterStartupScript(this.GetType(), "SiteHaritasiYukleniyorGizle", "<script>SiteHaritasiYukleniyorGizle();</script>");
        }
    }
}
