﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS;
using OrtakClass;

namespace OrtakSayfa
{
    public partial class Cikis : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();

            // 2) Session cookie'yi tarayıcıda geçersiz kıl
            //    Remove sadece server collection'dan atar, o yüzden işe yarayan kısım Expires'tır
            if (Request.Cookies["ASP.NET_SessionId"] != null)
            {
                HttpCookie c = new HttpCookie("ASP.NET_SessionId", "");
                c.HttpOnly = true;                 // İstersen Secure, SameSite da eklersin
                c.Expires = DateTime.UtcNow.AddDays(-1); // Geçmiş tarihe al -> tarayıcı siler
                Response.Cookies.Add(c);
            }
            string yazilimUrl = GenelIslemler.YazilimURLBul(this.Request, false);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "cikis", "window.top.location='" + yazilimUrl + "'", true);
        }
    }
}
