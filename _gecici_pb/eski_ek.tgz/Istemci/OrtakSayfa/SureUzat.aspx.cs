using System;
using System.Web;
using System.Web.SessionState;

namespace OrtakSayfa
{
    public partial class SureUzat : System.Web.UI.Page
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            Session["OtomatikSureUzat"] = "1";
        }
    }
}
