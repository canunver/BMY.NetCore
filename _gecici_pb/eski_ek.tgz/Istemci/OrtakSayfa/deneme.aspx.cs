using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OrtakClass;
using System.Data;
using System.Drawing;
using TNS.UZY;
using System.IO;
using EkRtfReport;
using System.Text;
using TNS.DEG;
using TNS;
using System.Collections;
using Ext1.Net;
using System.Threading;
using System.Net;

namespace Istemci.OrtakSayfa
{
    public partial class deneme : istemciUzayi.GenelSayfaV3
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //int a = 0;
            //int b = 5 / a;

            //deneme_click(sender, e);
            //ArrayList al = new ArrayList();
            //al.Add(new { t1 = "a", t5 = "b", t2 = 2.2, t3 = 5, t4 = true });
            //al.Add(new { t1 = "c", t5 = "zz", t2 = 1.2, t3 = 1, t4 = false });
            //stoKaynak.DataSource = al;
            //stoKaynak.DataBind();

            //MailAt();
        }

        //private void DetayYaz(Tablo XLS, int satir, int sutun, int siraNo)
        //{
        //    if (siraNo != 0)
        //    {
        //        XLS.HucreDegerYaz(satir, sutun, siraNo.ToString());
        //        XLS.HucreDegerYaz(satir, sutun + 1, "hesapPlanKod");
        //        XLS.HucreDegerYaz(satir, sutun + 2, "hesapPlanAd");
        //        XLS.HucreDegerYaz(satir, sutun + 4, "olcuBirimAd");
        //    }
        //    else
        //    {
        //        XLS.HucreBirlestir(satir, sutun, satir, sutun + 3);
        //        XLS.HucreDegerYaz(satir, sutun, "Toplam");

        //        for (int m = sutun; m <= sutun + 14; m++)
        //            XLS.KoyuYap(satir, m, true);
        //    }

        //    XLS.HucreDegerYaz(satir, sutun + 5, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 6, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 7, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 8, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 9, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 10, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 11, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 12, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 13, (double)0);
        //    XLS.HucreDegerYaz(satir, sutun + 14, (double)0);
        //}

        //private void XLSTest()
        //{
        //    int baslaSutun = -1;
        //    int baslaSatir = -1;
        //    //int yil = -1;
        //    Tablo XLS = new TabloJ();

        //    //XLS.BosDosyaAc(DosyaIslem.DosyaAdUret());
        //    //XLS.HucreDegerYaz(1, 0, "Yıldaki Ay Sayısı");
        //    //XLS.HucreDegerYaz(1, 1, 12);
        //    //XLS.KoyuYap(1, 0, true);
        //    XLS.DosyaAc(@"D:\sources\asp.net\Sgb.NETv2\Istemci\RaporSablon\TMM\TASINIRSAYIMCETVELI.xlt", DosyaIslem.DosyaAdUret());
        //    XLS.HucreAdAdresCoz("BaslaSatir", ref baslaSatir, ref baslaSutun);


        //    int satir = baslaSatir + 1;

        //    for (int i = 0; i < 2; i++)
        //    {
        //        XLS.SatirAc(satir, 7);
        //        XLS.HucreKopyala(baslaSatir - 7, baslaSutun, baslaSatir - 1, baslaSutun + 14, satir, baslaSutun);

        //        XLS.HucreBirlestir(satir, baslaSutun, satir, baslaSutun + 14);

        //        for (int j = satir + 2; j < satir + 4; j++)
        //        {
        //            XLS.HucreBirlestir(j, baslaSutun, j, baslaSutun + 1);
        //            XLS.HucreBirlestir(j, baslaSutun + 3, j, baslaSutun + 8);
        //            XLS.HucreBirlestir(j, baslaSutun + 10, j, baslaSutun + 11);
        //            XLS.HucreBirlestir(j, baslaSutun + 13, j, baslaSutun + 14);
        //        }


        //        //XLS.HucreKopyala(satir - 1, baslaSutun, satir - 1, baslaSutun, satir, baslaSutun);
        //        XLS.YaziTipBuyuklugu(satir, baslaSutun, 8);
        //        XLS.HucreDegerYaz(satir, baslaSutun, "YTL");
        //        XLS.KoyuYap(satir, baslaSutun, true);
        //        XLS.DuseyHizala(satir, baslaSutun, 2);
        //        XLS.YatayHizala(satir, baslaSutun, 2);

        //        XLS.HucreDegerYaz(satir, baslaSutun, "Deneme");

        //        XLS.HucreDegerYaz(satir + 2, baslaSutun + 3, "cetvel.ilAd");
        //        XLS.HucreDegerYaz(satir + 2, baslaSutun + 10, "cetvel.ilKod");
        //        XLS.HucreDegerYaz(satir + 2, baslaSutun + 13, "ddlYil");
        //        XLS.HucreDegerYaz(satir + 3, baslaSutun + 3, "kurAd");
        //        XLS.HucreDegerYaz(satir + 3, baslaSutun + 10, "kurKod");
        //        XLS.HucreDegerYaz(satir + 3, baslaSutun + 13, "eskiHesapKod");

        //        XLS.HucreBirlestir(satir + 5, baslaSutun, satir + 6, baslaSutun);
        //        XLS.HucreBirlestir(satir + 5, baslaSutun + 1, satir + 6, baslaSutun + 1);
        //        XLS.HucreBirlestir(satir + 5, baslaSutun + 2, satir + 6, baslaSutun + 3);
        //        XLS.HucreBirlestir(satir + 5, baslaSutun + 4, satir + 6, baslaSutun + 4);

        //        for (int j = baslaSutun + 5; j < baslaSutun + 14; j += 2)
        //            XLS.HucreBirlestir(satir + 5, j, satir + 5, j + 1);

        //        satir += 6;
        //        for (int deneme = 0; deneme < 15; deneme++)
        //        {
        //            satir++;

        //            XLS.SatirAc(satir, 1);
        //            XLS.HucreKopyala(baslaSatir, baslaSutun, baslaSatir, baslaSutun + 14, satir, baslaSutun);
        //            XLS.HucreBirlestir(satir, baslaSutun + 2, satir, baslaSutun + 3);

        //            DetayYaz(XLS, satir, baslaSutun, deneme + 1);
        //        }
        //        satir++;
        //        XLS.SatirAc(satir, 1);
        //        XLS.HucreKopyala(baslaSatir, baslaSutun, baslaSatir, baslaSutun + 14, satir, baslaSutun);

        //        //Toplam yazıyor burada
        //        DetayYaz(XLS, satir, baslaSutun, 0);
        //        XLS.SayfaSonuKoy(satir + 3);
        //        satir += 3;
        //    }

        //    XLS.DosyaSaklaTamYol();
        //    DosyaIslem.DosyaGonder(XLS.SonucDosyaAd(), "TASINIRSAYIMCETVELI.xls", true, "xls");
        //}

        protected void btnElma_Click(object sender, EventArgs e)
        {
            //EkRtf ekRtf1 = new EkRtf();
            //ekRtf1.CreateVar("TARIH", DateTime.Now.ToShortDateString());
            //int[] donemYillar = new int[] { 12, 13 };
            //ekRtf1.CreateVar("DONEM", donemYillar[0] + " - " + donemYillar[1]);
            //ekRtf1.CreateVar("BIRIM", "Elma");
            //ekRtf1.CreateVar("BASLIK", "Tema, Amaç, Hedef Raporu ğüşiöç ĞÜŞİÖÇıI");
            //ekRtf1.CreateVar("TABLO", txt.Text);
            //ekRtf1.InFile = @"d:\sources\asp.net\sgb.netv2\istemci\RaporSablon\PEB\TemaAmacHedefAgacRapor.rtf";
            //ekRtf1.OutFile = ekRtf1.CreateTmpFileName();
            //ekRtf1.Execute();
            //ekRtf1.ReportData.Clear();

            //OrtakClass.DosyaIslem.DosyaGonder(ekRtf1.OutFile, "Tema, Amaç, Hedef Raporu", true, "doc");
            //Istemci.Raporlama.RaporAbonelik.AbonelikRaporlariOlustur();
        }

        string postData = @"{
            'info': {
                '_postman_id': 'd1c5104b-4220-4c47-b9e4-7a0617251c3d',
                'name': 'YetniNetApinizerForPaksis',
                'schema': 'https://schema.getpostman.com/json/collection/v2.1.0/collection.json',
                '_exporter_id': '30191684'
            },
            'item': [
                {
                    'name': 'JWTtokenYetkinet',
                    'request': {
                        'method': 'POST',
                        'header': [],
                        'body': {
                            'mode': 'urlencoded',
                            'urlencoded': [
                                {
                                    'key': 'grant_type',
                                    'value': 'password',
                                    'type': 'text'
                                },
                                {
                                    'key': 'username',
                                    'value': 'sgbNetUser',
                                    'type': 'text'
                                },
                                {
                                    'key': 'password',
                                    'value': 'cid34h&9xH5o',
                                    'type': 'text'
                                },
                                {
                                    'key': 'client_id',
                                    'value': '13d32c2c-837b-45ea-a10b-6b6f0443d66b',
                                    'type': 'text'
                                },
                                {
                                    'key': 'client_secret',
                                    'value': '-',
                                    'type': 'text'
                                }
                            ]
                        },
                        'url': {
                            'raw': 'https://api.tarimorman.gov.tr/auth/jwt',
                            'protocol': 'https',
                            'host': [
                                'api',
                                'tarimorman',
                                'gov',
                                'tr'
                            ],
                            'path': [
                                'auth',
                                'jwt'
                            ]
                        }
                    },
                    'response': []
                },
                {
                    'name': 'ADKontrol',
                    'request': {
                        'method': 'POST',
                        'header': [
                            {
                                'key': 'Authorization',
                                'value': 'eyJraWQiOiJiNmQyMmY1Ni04NzRmLTQ3MTEtYTc3OC1kNWNjNWJmMTg2NzgiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJndW5kZW1Vc2VyIiwiYXVkIjoiI0dXIzEzZDMyYzJjLTgzN2ItNDVlYS1hMTBiLTZiNmYwNDQzZDY2YiIsImV4cCI6MTY1MTEzNjE1NywianRpIjoiMktHZGUydTVBMFdnLUpLeGoyaG5mQSIsImlhdCI6MTY1MTEzMjU1NywiWC1BcHBsaWNhdGlvbk5hbWUiOiJZZXRraU5ldCIsIlgtQ2xpZW50SW5mbyI6Imd1bmRlbVVzZXIiLCJzY29wZSI6IiIsIlgtSXNzdWVkQXQiOiIyMDIyLTA0LTI4IDA3OjU1OjU3LjQxNSIsIlgtRXhwaXJlc0F0IjoiMjAyMi0wNC0yOCAwODo1NTo1Ny40MTUiLCJYLUV4cGlyZXNJbk1pbGxpcyI6MzYwMDAwMCwiWC1SZWZyZXNoVG9rZW4iOiI4ODA1OTBmNi0wNmI3LTQ1YzMtOGQ4Yy0yNzczNjZlZDUzNjMiLCJYLVJlZnJlc2hUb2tlbklzc3VlZEF0IjoiMjAyMi0wNC0yOCAwNzo1NTo1Ny40MTUiLCJYLVJlZnJlc2hUb2tlbkV4cGlyZXNJbk1pbGxpcyI6MTgwMDAwLCJYLVJlZnJlc2hUb2tlbkV4cGlyZXNBdCI6IjIwMjItMDQtMjggMDc6NTg6NTcuNDE1IiwiWC1SZWZyZXNoQ291bnQiOjB9.R3YzJCvzOEcXt2R2YOfrce0gtyuemrv7Akwa0A4GezBgNXofqe_xLZC1s17cYGiwsl6Ih51xPH-FQMek2hMOdSo_bvxhqoDw6OA4i7x89yF8ISwRm9B0FDoniUXE_SDHjiUcZDUE_K7t5aHF6zaBURdmNrjUx1Gs6B-4H1bhyQoUBLdAtzJY4X0yMzAyWzPIGYiJGSSJcosDH7TS6oKw80Ceal7bymzL46o-Kojx4nEIkW8kBju5TePPghuqNL-6rPKXUDb9HCRqzwUoNpU6j39yq9HD0EI6A9zrYWkF58c4_Uzml7zARJGr_m_jiIUqKgkXx6EPpRKD3hlw7bKQbQ',
                                'type': 'text'
                            }
                        ],
                        'body': {
                            'mode': 'raw',
                            'raw': '{\r\n    \'ADKontrol\': {\r\n        \'sKullaniciAdi\': \'\',\r\n        \'sParola\': \'\'\r\n    }\r\n}',
                            'options': {
                                'raw': {
                                    'language': 'json'
                                }
                            }
                        },
                        'url': {
                            'raw': 'https://api.tarimorman.gov.tr/YetkiNet/ADKontrol',
                            'protocol': 'https',
                            'host': [
                                'api',
                                'tarimorman',
                                'gov',
                                'tr'
                            ],
                            'path': [
                                'YetkiNet',
                                'ADKontrol'
                            ]
                        }
                    },
                    'response': []
                }
            ],
            'auth': {
                'type': 'bearer',
                'bearer': [
                    {
                        'key': 'token',
                        'value': 'eyJraWQiOiJiNmQyMmY1Ni04NzRmLTQ3MTEtYTc3OC1kNWNjNWJmMTg2NzgiLCJhbGciOiJSUzI1NiJ9.eyJYLUV4cGlyZXNBdCI6IjIwMjMtMDktMjlUMTQ6MDc6MzEuOTUxWiIsImF1ZCI6IiNHVyMxM2QzMmMyYy04MzdiLTQ1ZWEtYTEwYi02YjZmMDQ0M2Q2NmIiLCJYLUlzc3VlZEF0IjoiMjAyMy0wOS0yOVQxMzowNzozMS45NTFaIiwiWC1BcHBsaWNhdGlvbk5hbWUiOiJZZXRraU5ldEFEIiwic2NvcGUiOiIiLCJpc3MiOiJwYWtzaXNMZGFwVXNlciIsImV4cCI6MTY5NTk5NjQ1MSwiaWF0IjoxNjk1OTkyODUxLCJqdGkiOiJjMDhlMjdjZC1mZDljLTRjNDAtOTM5NS00ZWJmNjZkOTQ3MWEiLCJYLUV4cGlyZXNJbk1pbGxpcyI6MzYwMDAwMH0.lHrgIZjiiIhX9INgu3mrfkaABR8uoRGwi4-mjTZDsYwX4m7M9y62Wcg0JbSfJfw8gZEZh0J1Rc9vpiQZE6DPTWi6_6l4_zc82-hPjhJ7cfRTThJQ4ZjtZe0tg4RzSf3holQqpm8whrUlBQM29-dBZgddqC3rKXFkrKt2bi8p2_GBNNhE6N6CDl-tdXaK3qttSMJxEUKUvTK5bcHwc9GilUJeHKbCHMmuGItN5hrOr-JAR05ZKrHBNyxWV66clDmthZRVlWSXtbh5C_ZKNIL48fk8ohZMbIhB6CHVyFdd6BYMwn9NIkEvUvBEYFwrrBMs69aX5hrhXhPnK0IsAMW0Gg\'',
                        'type': 'string'
                    }
                ]
            },
            'event': [
                {
                    'listen': 'prerequest',
                    'script': {
                        'type': 'text/javascript',
                        'exec': [
                            ''
                        ]
                    }
                },
                {
                    'listen': 'test',
                    'script': {
                        'type': 'text/javascript',
                        'exec': [
                            ''
                        ]
                    }
                }
            ]
        }";


        protected void AjaxCall(object sender, DirectEventArgs e)
        {
            try
            {
                WebRequest request = WebRequest.Create("https://api.tarimorman.gov.tr/auth/jwt");
                request.Method = "POST";
                request.ContentType = "application/json";

                // Güvenlik protokolünü belirt
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

                // Veriyi yaz
                using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(postData);
                }

                // Cevabı al
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream dataStream = response.GetResponseStream())
                    {
                        using (StreamReader reader = new StreamReader(dataStream))
                        {
                            // Cevabı ekrana yazdır
                            string responseBody = reader.ReadToEnd();
                            txtSonuc.Text = "Cevap: " + responseBody;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                txtSonuc.Text = ("Hata: " + ex.Message);
            }
        }

        protected void btnx_Click(object sender, DirectEventArgs e)
        {
            //string tut = HttpUtility.UrlEncode(OrtakFonksiyonlar.Sifrele("TNS-" + DateTime.Now.Ticks.ToString() + "-" + Convert.ToInt64(nfRakam.Number).ToString() + "-2017-12-1", "!STRATEK2Bordro!"));
            //txtSonuc.Text = tut;
            KimlikSorgula(sender, e);
        }

        protected void btnx_ClickE1(object sender, DirectEventArgs e)
        {
            //nfRakam.Number = TNS.ResmiTatil.GunBul(dfTar1.SelectedDate, dfTar2.SelectedDate, true, cbIsGunu.Checked);
            IkiBoyutluTablo ib = new IkiBoyutluTablo();
            ib.ustBaslik1 = "Üst başlık";
            ib.ustBaslik2 = "Alt Başlık";
            ib.kosegenYazi = "KÖŞE";

            ib.veriler = new ArrayList();
            Random r = new Random();
            ib.soldaAlanSayisi = Convert.ToInt16(nfRakam.Number);
            ib.ustteAlanSayisi = Convert.ToInt16(nfRakam2.Number);

            StrKodStrAd[] liste = new StrKodStrAd[ib.ToplamAlanSayisi];
            TabloUret(ib, r, 0, liste);

            string uz = "xlsx";
            string tut = OrtakClass.IkiBoyutluTablo.TabloUret(ib, uz, null);
            DosyaIslem.DosyaGonderX(tut, "Deneme" + DosyaIslem.DosyaAdUretSade() + "." + uz, true, uz, true);
        }

        private void TabloUret(IkiBoyutluTablo ib, Random r, int derinlik, StrKodStrAd[] liste)
        {
            int lv = Sifirsiz(r, derinlik == 0 ? 6 : 4);
            for (int i = 0; i < (derinlik == 0 ? 4 : 3); i++)
            {
                liste[derinlik] = new StrKodStrAd(OrtakFonksiyonlar.MetinYap(lv, 3), OrtakFonksiyonlar.YaziylaParasiz(lv));
                lv += Sifirsiz(r, 2);
                if (derinlik >= ib.ToplamAlanSayisi - 1)
                {
                    IkiBoyutluTabloVeri ibv = new IkiBoyutluTabloVeri();
                    for (int j = 0; j < liste.Length; j++)
                    {
                        ibv.boyutlar.Add(liste[j]);
                    }
                    ibv.veri = (double)r.Next(500);
                    ibv.veriTip = TNS.VariableType.Money;
                    ib.veriler.Add(ibv);
                }
                else
                    TabloUret(ib, r, derinlik + 1, liste);
            }
        }

        private int Sifirsiz(Random r, int ust)
        {
            return r.Next(ust) + 1;
        }

        //protected void btnx_Click(object sender, DirectEventArgs e)
        //{
        //    nfRakam.Number = TNS.ResmiTatil.GunBul(dfTar1.SelectedDate, dfTar2.SelectedDate, true, cbIsGunu.Checked);
        //}

        protected void deneme_click(object sender, EventArgs e)
        {
            //RTFDocument doc = new RTFDocument();
            //RTFTable tab = new RTFTable();
            //tab.SatirSay = 1;
            //tab.SutunSay = 1;

            //tab.DefHucreFormat = new RTFParagrafFormat();

            //tab.DefYukseklik = RTFDocument.CMtoTwips(0.5);
            //tab.Sutun(0).Genislik = RTFDocument.CMtoTwips(2.6);

            //RTFHucreVeri hcr = new RTFHucreVeri();
            //hcr.ParcaEkle(new RTFFormatliYazi(OrtakClass.GenelIslemler.TurkceYok("Hedef ĞÜŞİÖÇ Hedef ğüşıöç damam"), new RTFYaziFormat(0, 0, true)));
            //tab[0, 0] = hcr;

            //doc.ParcaEkle(tab);
            //StringWriter sw = new StringWriter();
            //tab.Save(sw);
            //txt.Text = sw.ToString();

            //TNS.UZY.IUZYServis uzy = TNS.UZY.Arac.Tanimla();
            //TNS.KYM.Kullanici kul = new TNS.KYM.Kullanici();
            //if (string.IsNullOrEmpty(txtEkAlanlar.Text))
            //{
            //    txtSonuc.Text = uzy.UzayDegeriDbl(kul, txtUzayAd.Text, txtUzaySorgu.Text, false, txtUzayAlan.Text).ToString("0.00");
            //    txtSorgu.Text = uzy.UzayKosulStr(kul, txtUzayAd.Text, txtUzaySorgu.Text, false, txtUzayAlan.Text);
            //}
            //else
            //{
            //    string[] alanlar = txtEkAlanlar.Text.Split(',');
            //    DataTable dt = uzy.UzayDataTableDondur(kul, txtUzayAd.Text, txtUzaySorgu.Text, false, txtUzayAlan.Text, alanlar);
            //    if (dt != null)
            //    {

            //        if (dt.Rows.Count > 0)
            //        {
            //            StringBuilder sb = new StringBuilder();
            //            int col = dt.Columns.Count;

            //            sb.Append("<table>");
            //            sb.Append("<tr>");
            //            for (int i = 0; i < col; i++)
            //            {
            //                sb.Append("<td>");
            //                sb.Append(dt.Rows[0].ItemArray[i].GetType());
            //                sb.Append("</td>");
            //            }
            //            sb.Append("</tr>");
            //            sb.AppendLine();
            //            foreach (DataRow item in dt.Rows)
            //            {
            //                sb.Append("<tr>");
            //                for (int i = 0; i < col; i++)
            //                {
            //                    sb.Append("<td>");
            //                    sb.Append(item.ItemArray[i].ToString());
            //                    if (dt.Rows[0].ItemArray[i].GetType() == typeof(System.Decimal))
            //                    {
            //                        decimal d = (decimal)dt.Rows[0].ItemArray[i];
            //                        double dob = Convert.ToDouble(d);
            //                    }
            //                    sb.Append("</td>");
            //                }

            //                sb.Append("</tr>");
            //                sb.AppendLine();
            //            }
            //            sb.Append("</table>");
            //            ltlTable.Text = sb.ToString();
            //        }
            //    }
            //    else
            //        ltlTable.Text = "Hatalı sorgu. Lütfen ek alanları ve toplam kolonunu kontrol ediniz!";
            //}
        }

        protected void btnDegiskenYaz_click(object sender, EventArgs e)
        {
        }

        //private void FormulDeneme()
        //{
        //    TNS.Calculator c = new Calculator();

        //    Variable[] v = new Variable[2];
        //    v[0] = new Variable("yevmiye", VariableType.Money);
        //    v[1] = new Variable("gun", VariableType.Integer);

        //    Formula[] f = new Formula[1];
        //    f[0] = new Formula("calisma", VariableType.Money, txtFormula.Text);

        //    string hata = c.PrepareCalculator("Ornek", "Bordro", v, f);
        //    if (string.IsNullOrEmpty(hata))
        //    {
        //        Hashtable htIn = new Hashtable();
        //        Hashtable htOut = new Hashtable();
        //        htIn["yevmiye"] = OrtakFonksiyonlar.ConvertToDbl(txtYevmiye.Text);
        //        htIn["gun"] = OrtakFonksiyonlar.ConvertToInt(txtGun.Text, 0);
        //        try
        //        {
        //            c.ExecuteCalc(htIn, htOut);
        //            TextField3.Text = htOut["calisma"].ToString();
        //        }
        //        catch (Exception ex)
        //        {
        //            TextField3.Text = ex.Message;
        //        }
        //    }
        //    else
        //        TextField2.Text = hata;
        //}

        void ExcelYaz()
        {
            Tablo XLS = GenelIslemler.NewTablo();
            int kaynakSatir = 0;
            int sutun = 0;
            int satir = 0;

            string sablonAd = "CezalilarListesi.xlt";
            string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            XLS.DosyaAc(Server.MapPath("~") + "/RaporSablon/TRM/" + sablonAd, sonucDosyaAd);
            XLS.HucreAdAdresCoz("baslaSatir", ref kaynakSatir, ref sutun);

            satir = kaynakSatir;
            decimal d = 1.0020M;
            for (int i = 0; i < 20; i++)
            {
                satir++;
                XLS.SatirAc(satir, 1);

                //XLS.HucreKopyala(kaynakSatir, sutun, kaynakSatir, sutun + 2, satir, sutun);
                //if (satir == 3)
                //    XLS.HucreAdBulYaz("aciklama", i);

                XLS.HucreDegerYaz(satir, 0, satir - 2);
                XLS.HucreDegerYaz(satir, 1, i);
                XLS.HucreDegerYaz(satir, 2, d);
                d += 0.02M;
            }

            XLS.DosyaSaklaTamYol();
            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "CezalilarListesi", true, GenelIslemler.ExcelTur());
        }

        protected void btnClick(object sender, DirectEventArgs e)
        {
            //ExcelYaz();

            //SorguOlc();
        }

        protected void KimlikSorgula(object sender, DirectEventArgs e)
        {
            try
            {
                TNS.KPM.IKPMServis serKPM = TNS.KPM.Arac.Tanimla();

                TNS.KPM.Istek istek = new TNS.KPM.Istek();
                istek.istekTur = ((int)TNS.KPM.ENUMIstekTur.NUFUSCUZDANORNEK);
                istek.tcKimlikNo = "13195976012";
                istek.islemYapan = "Sistem";
                istek.entegrasyon = true;

                ObjectArray nufusList = serKPM.NufusKayitOrnekRaporla(kullanan, istek);

                if (!nufusList.sonuc.islemSonuc)
                {
                    txtSonuc.Text = (nufusList.sonuc.hataStr);
                }
                else if (nufusList.ObjeSayisi == 0)
                    txtSonuc.Text = (nufusList.sonuc.bilgiStr);
                else
                {
                    TNS.KPM.Kisi nufusOrnek = (TNS.KPM.Kisi)nufusList.objeler[0];

                    txtSonuc.Text = $"{nufusOrnek.ad}-{nufusOrnek.soyad}-{nufusOrnek.tcKimlikNo}-{new TNSDateTime(nufusOrnek.dogumTarihi.Oku())}-{nufusOrnek.anaAd}-{nufusOrnek.babaAd}-{nufusOrnek.cinsiyetAciklama}";
                }
            }
            catch (Exception ex)
            {
                txtSonuc.Text = (ex.Message);
            }
        }

        void SorguOlc()
        {
            string sql = "SELECT  EVREVRAK.EVREVRAKNO, EVREVRAK.YIL, EVREVRAK.EVRAKTIPI, EVREVRAK.EVRAKBIRIMKODU, EVREVRAK.EVRAKNO, EVREVRAK.EVRAKTARIH, EVREVRAK.GELDIGIYERTUR, EVREVRAK.GELDIGIYER, EVREVRAK.GELENEVRAKNO, EVREVRAK.GELENEVRAKTARIH, EVREVRAK.KONU, EVREVRAK.GIZLILIK, EVREVRAK.GELISSEKLI, EVREVRAK.YAZIDURUM, EVREVRAK.CEVAPSURESI, EVREVRAK.ACIKLAMA, EVREVRAK.EKADEDI, EVREVRAK.HAVALEBIRIMKODU, EVREVRAK.EVRAKTURU, EVREVRAK.PARAF, EVREVRAK.ANTET, EVREVRAK.ICERIK, EVREVRAK.IMZA1, EVREVRAK.IMZA2, EVREVRAK.IMZA3, EVREVRAK.EK, EVREVRAK.ALTBILGI, EVREVRAK.OLUSTURMATARIHI, EVREVRAK.IMZATARIHI, EVREVRAK.EKYAZIALAN, EVREVRAK.SIRANO, EVREVRAK.DOSYANO, EVREVRAK.EVRAKICERIK, EVREVRAK.EVRAKCINSI, EVREVRAK.ESASNO, EVREVRAK.EVRAKBELGETUR, EVREVRAK.IMZAYOLU, EVREVRAK.BILGIEDINME, EVREVRAK.KISISELBILGI, EVREVRAK.DOSYASIVAR, EVREVRAK.BAKANLIKEVRAKNO, EVREVRAK.BASKANLIKEVRAKNO, EVREVRAK.DAGITIMTARIH, EVREVRAK.DINAMIKSAYFAKOD, EVREVRAK.DINAMIKSURECNO, EVREVRAK.SURECAD, EVREVRAK.KAYITISLEM, EVREVRAK.RESMIBELGE, EVREVRAK.DIL, EVREVRAK.EIMZALANDI, EVREVRAK.EIMZATARIHI, EVREVRAK.EIMZALAYAN, EVREVRAK.URETICI, EVREVRAK.URETIMTARIHI, EVREVRAK.IMZABITTI, EVREVRAK.URETIMVERSIYON, EVREVRAK.GIZLILIKGECERLILIKSURE, EVREVRAK.ILETIMTARIHI, EVREVRAK.ARSIVLEMETARIHI, EVREVRAK.TRANSFERTARIHI, EVREVRAK.IMHATARIHI,EVRYAZIDURUMU.AD, EVRGIZLILIK.AD, EVRGELISSEKLI.AD,EVREVRAKHAREKETSONDURUM.SIRANO, EVREVRAKHAREKETSONDURUM.BIRIMKOD1, EVREVRAKHAREKETSONDURUM.BIRIMKOD2, EVREVRAKHAREKETSONDURUM.KISI1, EVREVRAKHAREKETSONDURUM.KISI2, EVREVRAKHAREKETSONDURUM.ISLEMYAPAN, EVREVRAKHAREKETSONDURUM.ISLEMTARIH, EVREVRAKHAREKETSONDURUM.ISLEM, EVREVRAKHAREKETSONDURUM.KISI1AD, EVREVRAKHAREKETSONDURUM.KISI2AD, EVREVRAKHAREKETSONDURUM.ISLEMYAPANAD, EVREVRAKHAREKETSONDURUM.OKUNDU, EVREVRAKHAREKETSONDURUM.HAVALENOTU ,EVRBKD1.AD AS BIRIMAD1,EVRBKD2.AD AS BIRIMAD2 ,EVRBKD0.AD AS BIRIMAD3, TS1.PREVRAKNO, TS1.ASIL, DOSYAPLANKODLARI,0 as 'TASFIYEKOD',(SELECT COUNT(EVREVRAKNO) FROM EVREVRAKSICIL WHERE EVREVRAKNO=EVREVRAK.EVREVRAKNO) AS EVRAKSAYISI FROM EVREVRAK INNER JOIN EVREVRAKSICIL TS1 ON EVREVRAK.EVREVRAKNO = TS1.EVREVRAKNO  INNER JOIN EVREVRAKHAREKETSONDURUM ON TS1.PREVRAKNO = EVREVRAKHAREKETSONDURUM.PREVRAKNO  LEFT OUTER JOIN EVRYAZIDURUMU ON EVREVRAK.YAZIDURUM = EVRYAZIDURUMU.KOD  LEFT OUTER JOIN EVRGIZLILIK ON EVREVRAK.GIZLILIK = EVRGIZLILIK.KOD  LEFT OUTER JOIN EVRGELISSEKLI ON EVREVRAK.GELISSEKLI = EVRGELISSEKLI.KOD   LEFT OUTER  JOIN EVRBIRIM EVRBKD0 ON EVREVRAK.HAVALEBIRIMKODU = EVRBKD0.KOD   LEFT OUTER  JOIN EVRBIRIM EVRBKD2 ON EVREVRAKHAREKETSONDURUM.BIRIMKOD2 = EVRBKD2.KOD   LEFT OUTER  JOIN EVRBIRIM EVRBKD1 ON EVREVRAKHAREKETSONDURUM.BIRIMKOD1 = EVRBKD1.KOD CROSS APPLY (Select TDP.DOSYAPLANKODU + ';' From EVREVRAKDOSYAPLANI TDP Where TDP.PREVRAKNO = TS1.PREVRAKNO For XML PATH ('')) dd(DOSYAPLANKODLARI) WHERE EVREVRAKHAREKETSONDURUM.BIRIMKOD1 LIKE '%' AND EVREVRAK.YIL=2014 AND EVREVRAK.EVRAKTARIH >= {ts '2014-01-01 00:00:00.000'} AND EVREVRAK.EVRAKTARIH <= {ts '2015-01-01 00:00:00.000'} AND EVREVRAK.EVRAKBIRIMKODU LIKE 'B.07.0.SGB%' AND TS1.ASIL=1 AND EVREVRAKHAREKETSONDURUM.ISLEM<>99 AND EVREVRAKHAREKETSONDURUM.ISLEM<>61 ORDER BY EVREVRAK.EVRAKTARIH DESC,EVREVRAK.EVRAKNO";

            DateTime t1 = DateTime.Now;
            VTSorgula s = new VTSorgula(sql, "BaglantiSatiriEVR", 100);
            DataRow r = s.satirOku();
            DateTime t2 = DateTime.Now;

            GenelIslemler.MesajKutusu("", t2.ToString() + "," + t1.ToString());
        }

        //void MailAt()
        //{

        //    for (int i = 0; i < 100; i++)
        //    {
        //        ParameterizedThreadStart paraThread = new ParameterizedThreadStart(Gonder);
        //        Thread th = new Thread(paraThread);
        //        th.Name = "BordroMailAt";
        //        th.Start(i);
        //    }
        //}


        //void Gonder(object sayac)
        //{
        //    //TNS.OrtakFonksiyonlar.MailAt("melih@stratek.com.tr", "melih@stratek.com.tr", TNS.OrtakFonksiyonlar.ConvertToInt(sayac, 0) + " nolu posta", "");
        //}
    }
}
