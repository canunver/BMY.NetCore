using System;
using TNS.MUH;
using TNS;

namespace OrtakSayfa
{
    public partial class TertipBilgiXML : System.Web.UI.Page
    {
        private void Page_Load(object sender, System.EventArgs e)
        {
            string yil = Request.QueryString["Yil"] + "";
            string tertip = Request.QueryString["Tertip"] + "";
            string muhasebe = Request.QueryString["Muhasebe"] + "";
            string birim = Request.QueryString["Birim"] + "";

            string aciklama = "";//yil + tertip;

            TNS.MUH.IMUHServis servisMUH = TNS.MUH.Arac.Tanimla();

            OdenekDurumKriter kriter = new OdenekDurumKriter();

            kriter.yil = OrtakFonksiyonlar.ConvertToInt(yil, 0);
            string[] dizi = tertip.Split('-');
            if (dizi.Length > 0) kriter.tertip.kodlar[0] = dizi[0];
            if (dizi.Length > 1) kriter.tertip.kodlar[1] = dizi[1];
            if (dizi.Length > 2) kriter.tertip.kodlar[2] = dizi[2];
            if (dizi.Length > 3)
            {
                if (dizi[3].Length > 4)
                    kriter.tertip.kodlar[3] = dizi[3].Substring(0, 4);
                else
                    kriter.tertip.kodlar[3] = dizi[3];
            }
            kriter.konsolide = true;
            kriter.harcamaGoster = true;
            kriter.odenekGondermeGoster = true;
            kriter.muhasebe = OrtakFonksiyonlar.ConvertToInt(muhasebe, 0);
            kriter.birim = birim;
            kriter.detay = ENUMOdenekDurumDetay.KONSOLIDE;
            ObjectArray oVAN;
            try
            {
                oVAN = servisMUH.OdenekDurum(kriter);
            }
            catch (Exception ex)
            {
                oVAN = new ObjectArray();
                oVAN.sonuc = new TNS.Sonuc(false, ex.Message, "");
            }

            if (oVAN.sonuc.islemSonuc)
            {
                System.Globalization.NumberFormatInfo n = (System.Globalization.NumberFormatInfo)System.Globalization.CultureInfo.CurrentCulture.NumberFormat.Clone();
                n.NumberDecimalDigits = 2;

                TNS.MUH.OdenekDurum o = (TNS.MUH.OdenekDurum)oVAN.objeler[0];

                double gonderme = (o.onayliOdenekGonderme + o.onaysizOdenekGonderme) - (o.onayliTenkis + o.onaysizTenkis);
                double odeGonSerbest = o.serbest - ((o.onayliOdenekGonderme + o.onaysizOdenekGonderme) - (o.onayliTenkis + o.onaysizTenkis));
                double tenkisSerbest = o.onayliOdenekGonderme - (o.onayliTenkis + o.onaysizTenkis) - o.harcama;

                Response.Write("<BILGI");
                Response.Write(" KBO='" + o.kbo.ToString("N", n) + "'");
                Response.Write(" EKLENEN='" + o.eklenen.ToString("N", n) + "'");
                Response.Write(" DUSULEN='" + o.dusulen.ToString("N", n) + "'");
                Response.Write(" SONDURUM='" + o.toplamOdenek.ToString("N", n) + "'");
                Response.Write(" TOPSERBEST='" + o.serbest.ToString("N", n) + "'");
                Response.Write(" GONDERILEN='" + gonderme.ToString("N", n) + "'");
                Response.Write(" HARCANAN='" + o.harcama.ToString("N", n) + "'");
                Response.Write(" KALANSERBEST='" + (o.serbest - Math.Max(gonderme, o.harcama)).ToString("N", n) + "'");
                Response.Write(" ODEGONSERBEST='" + odeGonSerbest.ToString("N", n) + "'");
                Response.Write(" TENKISSERBEST='" + tenkisSerbest.ToString("N", n) + "'");
                Response.Write(" ACIKLAMA='" + aciklama + "'");
                Response.Write("/>");
            }
            else
            {
                Response.Write("<BILGI");
                Response.Write(" KBO='" + "-1" + "'");
                Response.Write(" EKLENEN='" + "-1" + "'");
                Response.Write(" DUSULEN='" + "-1" + "'");
                Response.Write(" SONDURUM='" + "-1" + "'");
                Response.Write(" TOPSERBEST='" + "-1" + "'");
                Response.Write(" GONDERILEN='" + "-1" + "'");
                Response.Write(" HARCANAN='" + "-1" + "'");
                Response.Write(" KALANSERBEST='" + "-1" + "'");
                Response.Write(" ODEGONSERBEST='" + "-1" + "'");
                Response.Write(" TENKISSERBEST='" + "-1" + "'");
                Response.Write(" ACIKLAMA='" + "-1" + "'");
                Response.Write("/>");
            }
        }
    }
}
