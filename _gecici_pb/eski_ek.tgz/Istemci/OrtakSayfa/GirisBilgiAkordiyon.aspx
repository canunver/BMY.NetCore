﻿<%@ Page Language="C#" CodeBehind="GirisBilgiAkordiyon.aspx.cs" Inherits="OrtakSayfa.GirisBilgiAkordiyon" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_Themes/Form.css" type="text/css" rel="stylesheet" />
    <script type="text/javascript" language="javascript">
        function AktifMenuKaydet(bilgi) {
            var adres = "GirisBilgi.aspx?islem=menuSakla&tur=" + bilgi;
            $.ajax({ url: adres });
        }

        function SayfaBaslikAta(baslik) {
            panelSayfa.setTitle(baslik);
        }

        var mevzuatUrl;
        var yardimUrl;
        function MevzuatUrlAta(url) {
            mevzuatUrl = url;
        }

        function YardimUrlAta(url) {
            yardimUrl = url;
        }

        function MevzuatAc() {
            showPopWin(mevzuatUrl, 835, 400, true, null);
        }

        function YardimAc() {
            showPopWin(yardimUrl, 835, 400, true, null);
        }

        function SayfaAc(url, yeni) {
            if (yeni) {
                var yeniUrl = window.location.pathname + "?yonlendir=" + Ext1.util.Format.htmlEncode(url);
                window.open(yeniUrl);
            }
            else {
                panelSayfa.autoLoad.url = url;
                panelSayfa.reload();
            }
        }

        function MenuSecildi(par1, par2) {
            if (par1.attributes.url != "") {
                SayfaAc(par1.attributes.url, par2.ctrlKey);
            }
        }
    </script>
</head>
<body>
    <form id="form1" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:ResourceManager runat="server" />
    <ext:Viewport runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout runat="server">
                <Center MarginsSummary="104 20 20 20">
                    <ext:Panel runat="server" Header="false" Border="false" StyleSpec="background-color:white;padding:2px">
                        <Items>
                            <ext:BorderLayout runat="server">
                                <West>
                                    <ext:Panel ID="panelMenu" runat="server" Layout="Accordion" Collapsible="true" StyleSpec="width:25%;"
                                        AutoScroll="true">
                                        <LayoutConfig>
                                            <ext:AccordionLayoutConfig OriginalHeader="true" />
                                        </LayoutConfig>
                                    </ext:Panel>
                                </West>
                                <Center>
                                    <ext:Panel ID="panelSayfa" runat="server" Title="<%$ Resources:Istemci, ISTGB006 %>">
                                        <AutoLoad Url="GirisBilgi.aspx?menuYok=1" ShowMask="true" MaskMsg="<%$ Resources:Istemci, IST041 %>"
                                            Mode="IFrame">
                                        </AutoLoad>
                                    </ext:Panel>
                                </Center>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>