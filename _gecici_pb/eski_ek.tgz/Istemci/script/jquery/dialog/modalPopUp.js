﻿function showPopWin(url, width, height, showCloseBox, returnFunc) {
    showPopWin2(url, width, height, showCloseBox, returnFunc);
}

function showPopWin2(url, width, height, showCloseBox, beforeCloseFunc) {
    showPopWinTop(url, width, height, showCloseBox, beforeCloseFunc, null);
}

function showPopWin3(url, width, height, showCloseBox, beforeCloseFunc, title) {
    showPopWinTop2(url, width, height, showCloseBox, beforeCloseFunc, title);
}

var win;
var tur;
function showPopWinTop(url, width, height, showCloseBox, beforeCloseFunc, title) {
    var windowConfig = {
        id: "WindowCommon",
        autoShow: false,
        modal: true,
        width: width,
        height: height,
        resizable: false,
        title: title,
        hidden: false,
        closeAction: "close",
        listeners: {
            hide: function () {
                if (beforeCloseFunc != null)
                    eval(beforeCloseFunc);
            }
        },
        autoLoad: {
            url: url,
            mode: "iframe",
            showMask: true,
            maskMsg: "Lütfen Bekleyiniz...",
            nocache: true,
            triggerEvent: "show",
            reloadOnEvent: true
        }
    };

    var parent;
    if (title == null)
        parent = extKontrol;
    else {
        parent = window.top.extKontrol;
        tur = "TOP";
    }

    win = parent.getCmp(windowConfig.id);
    if (win) {
        if (win.autoLoad.url != url) {
            try {
                win.close();
            }
            catch (e) { }
            win = null;
        }
    }
    if (!win)
        win = new parent.Window(windowConfig);
    else
        win.show();

    window.setTimeout('setTitle()', 1000);
}

function showPopWinTop2(url, width, height, showCloseBox, beforeCloseFunc, title) {
    var hedef;
    var hedefScr;
    if (title == null) {
        hedef = extKontrol;
        hedefScr = window;
    }
    else {
        hedef = window.top.extKontrol;
        hedefScr = window.top;
        tur = "TOP";
    }

    if (tur == "TOP") {
        $("body").css("overflow", "hidden");
    }

    if (width == -1 || width > hedefScr.innerWidth) width = hedefScr.innerWidth / 1.3;
    if (height == -1 || height > hedefScr.innerHeight) height = hedefScr.innerHeight / 1.3;

    var windowConfig = {
        id: UUID(),
        autoShow: false,
        modal: true,
        width: width,
        height: height,
        resizable: false,
        title: title,
        hidden: false,
        maximizable: true,
        closeAction: "close",
        listeners: {
            hide: function () {
                try {
                    $("body").css("overflow", "auto");
                } catch (e) { }

                if (beforeCloseFunc != null)
                    eval(beforeCloseFunc);
            }
        },
        autoLoad: {
            url: url,
            mode: "iframe",
            showMask: true,
            maskMsg: "Lütfen Bekleyiniz...",
            nocache: true,
            triggerEvent: "show",
            reloadOnEvent: true
        }
    };

    win = new hedef.Window(windowConfig);

    window.setTimeout('setTitle()', 1000);
    //X.AddScript("hidePopWin(parentAutoLoadControl.id);");
    //<ext:Button ID="btnKapat" Text="Kapat" runat="server" Icon="Decline" OnClientClick="hidePopWin(parentAutoLoadControl.id);" />
}

function showPopExt3(url, width, height, showCloseBox, beforeCloseFunc, topWindow) {
    windowConfig = {
        //id: UUID(),
        autoShow: true,
        layout: "fit",
        modal: false,
        width: width,
        height: height,
        resizable: true,
        title: "",
        hidden: false,
        closeAction: "destroy",
        minimizable: false,
        maximizable: true,
        collapsible: true,
        listeners: {
            destroy: function () {
                if (beforeCloseFunc != null)
                    eval(beforeCloseFunc);
            }
        },
        loader: {
            url: url,
            autoLoad: true,
            renderer: 'frame',
            nocache: true,
            triggerEvent: "show",
            reloadOnEvent: true,
            //parentRef: "parentAutoLoadControl",
            loadMask: { showMask: true, maskMsg: "Lütfen Bekleyiniz..." }
        }
    };

    var hedef;
    if (topWindow == null)
        hedef = Ext;
    else {
        hedef = window.top.Ext;
        tur = "TOP";
    }

    win = new hedef.Window(windowConfig);

    window.setTimeout('setTitle()', 1000);
}


function setTitle() {
    try {
        if (win) {
            var title = "";

            if (tur == "TOP")
                title = window.top.WindowCommon_IFrame.document.title;
            else
                title = WindowCommon_IFrame.document.title;
            win.setTitle(title);
        }
    }
    catch (e) { }
}

function hidePopWin(id) {
    if (win) {
        win.close();
    }
    else {
        try {
            parent.extKontrol.getCmp(id).close();
        }
        catch (e) { }
    }
}

function UUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

function bilgiYaz(msg) {
}

function hataYaz(msg) {
}

function HideStatus() {
}

function MaxLength(control, maxlength) {
    maxlength -= 1;
    var text = control.value; //$("[id$='" + control.id + "']").val();
    if (text.length > maxlength)
        control.value = text.substring(0, maxlength);
}
