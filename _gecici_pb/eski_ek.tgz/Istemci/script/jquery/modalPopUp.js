﻿function showPopWin2(url, width, height, showCloseBox, beforeCloseFunc) {

    var div = createDiv(width, height);
    var frm = createIframe(div.id, url, width, height);

//    var I = document.getElementById('generated_ifrm');
//    var doc2 = I.contentWindow ? I.contentWindow.document : I.contentDocument;

//    if (!doc2 && window.frames['generated_ifrm'])
//        doc2 = window.frames['generated_ifrm'].window.document;

//    if (doc2 && doc2.title) 
//            div.title = doc2.title

//        alert($('title', frames["generated_ifrm"].document).text());
   
//    alert(frm.title);


    $(div).dialog({
        autoOpen: false,
        modal: true,
        width: width,
        height: height,
        beforeClose: function () {
            var iframe = document.getElementById("generated_ifrm");
            iframe.src = "../OrtakSayfa/bekle.htm";
            eval(beforeCloseFunc);
        }
    });

    $(div).dialog("open");
}

function createDiv(width, height, title) {
    var divId = "generated_div";
    var div = document.getElementById(divId);
    if (div == null) {
        if (document.createElement && (div = document.createElement('div'))) {
            div.name = div.id = divId;
            document.body.appendChild(div);
        }
    }

//    div.title = document.title;
    div.style.width = width + "px";
    div.style.height = height + "px";

    return div;
}

function createIframe(parentDivId, url, width, height) {
    var iframeId = "generated_ifrm";
    var iframe = document.getElementById(iframeId);
    if (iframe == null) {
        if (document.createElement && (iframe = document.createElement('iframe'))) {
            iframe.name = iframe.id = iframeId;
            iframe.frameBorder = "0";
            
            document.getElementById(parentDivId).appendChild(iframe);
        }
    }

    iframe.title = "iframe Title"
    iframe.src = url;
    iframe.style.width = (width) + "px";
    iframe.style.height = (height - 33) + "px";

   alert(iframe.body);

    return iframe;
}