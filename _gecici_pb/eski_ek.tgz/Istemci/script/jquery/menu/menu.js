(function ($) {

    $.fn.superfish = function (o) {
        var $sf = this,

        defaults = {
            hoverClass: 'sfHover',
            pathClass: 'overideThisToUse',
            delay: 100,
            animation: { opacity: 'show' },
            speed: 200
        },

        over = function () {
            clearTimeout(this.sfTimer);
            clearTimeout($sf[0].sfTimer);
            $(this).showSuperfishUl().siblings().hideSuperfishUl();
        },

        out = function () {
            var $$ = $(this);
            if (!$$.is('.' + o.bcClass)) {
                this.sfTimer = setTimeout(function () {
                    $$.hideSuperfishUl();
                    if (!$('.' + o.hoverClass, $sf).length) {
                        over.call($currents.hideSuperfishUl());
                    }
                }, o.delay);
            }
        };

        $.fn.extend(
        {
            hideSuperfishUl: function () {
                return this.removeClass(o.hoverClass).find('ul:visible').hide().end();
            },

            showSuperfishUl: function () {
                return this.addClass(o.hoverClass).find('>ul:hidden').animate(o.animation, o.speed).end();
            },

            applySuperfishHovers: function () {
                return this[($.fn.hoverIntent) ? 'hoverIntent' : 'hover'](over, out);
            }
        });

        o = $.extend({ bcClass: 'sfbreadcrumb' }, defaults, o || {});
        var $currents = $('li:has(ul)', this).filter('.' + o.pathClass);
        if ($currents.length) {
            $currents.each(
                function () {
                    $(this).removeClass(o.pathClass).addClass(o.hoverClass + ' ' + o.bcClass);
                }
            );
        }

        var $sfHovAr = $('li:has(ul)', this).applySuperfishHovers(over, out).end().not('.' + o.bcClass).hideSuperfishUl().end();
        $(window).unload(
            function () {
                $sfHovAr.unbind('mouseover').unbind('mouseout');
            }
        );

        return this.addClass('superfish').blur(
            function () {
                out.call(this);
            }
        );
    };

    function superfishFocusBlur() {
        var $a = $(this), $li = $a.parents('li');
        $a.focus(superfishOverCall).blur(superfishRemoveClass);
    }

    function superfishOverCall() {
        over.call($li);
        return false;
    }

    function superfishRemoveClass() {
        $li.removeClass(o.hoverClass);
    }

    $.fn.bgIframe = $.fn.bgiframe = function (s) {
        if ($.browser.msie && /6.0/.test(navigator.userAgent)) {
            s = $.extend({ top: '-1px', left: '0px', width: '180px', height: 'auto', opacity: true, src: 'javascript:false;' }, s || {});
            var prop = function (n) {
                return n && n.constructor == Number ? n + 'px' : n;
            },
            html = '<iframe class="bgiframe"frameborder="0"tabindex="-1"src="' + s.src + '"' + 'style="display:block;position:absolute;z-index:-1;' + (s.opacity !== false ? 'filter:Alpha(Opacity=\'0\');' : '') + 'top:' + (s.top == 'auto' ? 'expression(((parseInt(this.parentNode.currentStyle.borderTopWidth)||0)*-1)+\'px\')' : prop(s.top)) + ';' + 'left:' + (s.left == 'auto' ? 'expression(((parseInt(this.parentNode.currentStyle.borderLeftWidth)||0)*-1)+\'px\')' : prop(s.left)) + ';' + 'width:' + (s.width == 'auto' ? 'expression(this.parentNode.offsetWidth+\'px\')' : prop(s.width)) + ';' + 'height:' + (s.height == 'auto' ? 'expression(this.parentNode.offsetHeight+\'px\')' : prop(s.height)) + ';' + '"/>';
            return this.each(
                function () {
                    if ($('> iframe.bgiframe', this).length == 0) this.insertBefore(document.createElement(html), this.firstChild);
                }
            );
        }
        return this;
    };

    $.fn.hoverIntent = function (f, g) {
        var cfg = { sensitivity: 6, interval: 100, timeout: 0 };
        cfg = $.extend(cfg, g ? { over: f, out: g} : f);
        var cX, cY, pX, pY;
        var track = function (ev) {
            cX = ev.pageX;
            cY = ev.pageY;
        };

        var compare = function (ev, ob) {
            ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
            if ((Math.abs(pX - cX) + Math.abs(pY - cY)) < cfg.sensitivity) {
                $(ob).unbind("mousemove", track);
                ob.hoverIntent_s = 1;
                return cfg.over.apply(ob, [ev]);
            }
            else {
                pX = cX;
                pY = cY;
                ob.hoverIntent_t = setTimeout(
                    function () {
                        compare(ev, ob);
                    },
                    cfg.interval);
            }
        };

        var delay = function (ev, ob) {
            ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
            ob.hoverIntent_s = 0;
            return cfg.out.apply(ob, [ev]);
        };

        var handleHover = function (e) {
            var p = (e.type == "mouseover" ? e.fromElement : e.toElement) || e.relatedTarget;
            while (p && p != this) {
                try {
                    p = p.parentNode;
                }
                catch (e) {
                    p = this;
                }
            }
            if (p == this) {
                return false;
            }
            var ev = jQuery.extend({}, e);
            var ob = this;
            if (ob.hoverIntent_t) {
                ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
            }

            if (e.type == "mouseover") {
                pX = ev.pageX;
                pY = ev.pageY;
                $(ob).bind("mousemove", track);
                if (ob.hoverIntent_s != 1) {
                    ob.hoverIntent_t = setTimeout(function () { compare(ev, ob); }, cfg.interval);
                }
            }
            else {
                $(ob).unbind("mousemove", track);
                if (ob.hoverIntent_s == 1) {
                    ob.hoverIntent_t = setTimeout(function () { delay(ev, ob); }, cfg.timeout);
                }
            }
        };
        return this.mouseover(handleHover).mouseout(handleHover);
    };
})(jQuery);

$(document).ready(
    function () {
        try {
            if (jQuery.browser.msie) {
                $("#hunt3").superfish({ animation: { opacity: "show", height: "show"} }).find(">li:has(ul)").mouseover(
               function () { $("ul", this).bgIframe({ opacity: false }); }).find("a").focus(function () { $("ul", $("#hunt3>li:has(ul)")).bgIframe({ opacity: false }); });
            }
            else {
                $("#hunt3").superfish({ animation: { opacity: "show", height: "show"} });
            }
        } catch (e) { }
    }
);

function easytabs(menunr, active) {
    if (menunr == autochangemenu) {
        currenttab = active;
    }
    if ((menunr == autochangemenu) && (stoponhover == 1)) {
        stop_autochange()
    }
    else if ((menunr == autochangemenu) && (stoponhover == 0)) {
        counter = 0;
    }
    menunr = menunr - 1;
    for (i = 1; i <= tabcount[menunr]; i++) {
        document.getElementById(tablink_idname[menunr] + i).className = '';
        document.getElementById(tabcontent_idname[menunr] + i).style.display = 'none';
    }
    document.getElementById(tablink_idname[menunr] + active).className = 'active';
    document.getElementById(tabcontent_idname[menunr] + active).style.display = 'block';

    AktifMenuKaydet(active);
}

function AktifMenuKaydet(bilgi) {
    var adres = "../OrtakSayfa/GirisBilgi.aspx?islem=menuSakla&tur=" + bilgi;
    $.ajax({ url: adres });
}

var timer;
counter = 0;
var totaltabs = tabcount[autochangemenu - 1];
var currenttab = loadtabs[autochangemenu - 1];

function start_autochange() {
    counter = counter + 1;
    timer = setTimeout("start_autochange()", 1000);
    if (counter == changespeed + 1) {
        currenttab++;
        if (currenttab > totaltabs) {
            currenttab = 1
        }
        easytabs(autochangemenu, currenttab);
        restart_autochange();
    }
}

function restart_autochange() {
    clearTimeout(timer);
    counter = 0;
    start_autochange();
}

function stop_autochange() {
    clearTimeout(timer);
    counter = 0;
}

$(document).ready(
 function () {
     try {
         document.getElementById('tablink' + activetab).className = 'active';
         document.getElementById('tabcontent' + activetab).style.display = 'block';

     } catch (e) {

     }


     //     var menucount = loadtabs.length;
     //     var a = 0;
     //     var b = 1;
     //     do {
     //         easytabs(b, loadtabs[a]);
     //         a++;
     //         b++;
     //     }
     //     while (b <= menucount);
     //     if (autochangemenu != 0) {
     //         start_autochange();
     //     }
 });
