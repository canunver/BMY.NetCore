﻿function windowSize() {
    var myWidth = 0, myHeight = 0;
    if (typeof (window.innerWidth) == 'number') {
        //Non-IE
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    } else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        //IE 6+ in 'standards compliant mode'
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
        //alert("2/" + myWidth + "*" + myHeight)
    } else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
        //IE 4 compatible
        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    }
    return myWidth + "x" + myHeight;
}

function LoadingKonumAyarla(control) {
    var scrWH = windowSize();
    var srcWHA = scrWH.split('x');
    var scrW = srcWHA[0];
    var scrH = srcWHA[1];


    var h = Number(Number(scrH) - 75) / 2;
    var w = Number(Number(scrW) - 200) / 2;

    try {
        document.getElementById(control).style.top = h + " px";
        document.getElementById(control).style.left = w + " px";
    }
    catch (e) {

    }
}