﻿function KontrolDevam() {
    if (hdnIkiAsamaliGiris.value == "1" || hdnIkiAsamaliGiris.value == "2") {
        try {
            var kullaniciAd = $("#txtKKod").val();
            var parola = $("#txtParola").val();
            var gKod = $("#txtRegisterGuvenlikKodu").val();
            Ext1.net.DirectMethods.ParolaDogruMu(kullaniciAd, parola, gKod,
                {
                    eventMask: {
                        showMask: true,
                        msg: "Lütfen Bekleyin..."
                    },
                    success: function (result) {
                        if (result.islemSonuc) {
                            wndIkinciSeviye.show();
                            return false;
                        }
                        else {
                            Ext1.Msg.alert('Hata Oluştu', result.hataStr);
                            return false;
                        }
                    },
                    failure: function (errorMsg) {
                        Ext1.Msg.alert('Hata Oluştu', errorMsg);
                        return false;
                    }
                });
        } catch (e) {
            Ext1.Msg.alert('Hata Oluştu', e);
        }
        return false;
    }
    else
        $('#btnGirisASP').click();
}