﻿var globalTabTur;

function DivisionOlustur(strId, strClass, strInner) {
    var dv = document.createElement('div');
    if (strId != null && strId != "")
        dv.setAttribute('id', strId);
    if (strClass != null && strClass != "")
        dv.className = strClass;
    if (strInner != null && strInner != "")
        dv.innerHTML = strInner;
    return dv;
}


function HTTPCevap(param, o) {
    o.DivDegerAta(param);
}

function TnsTabSayfa(ilgiliDivAd, engelliMi, gizliMi, onSecEvent, onSecParam, dinamikMi, icerikYuklemeAdresi, paramEvalStr, tusKapatGorunur) {
    this.ilgiliDivAd = ilgiliDivAd;
    this.engelliMi = engelliMi;
    this.gizliMi = gizliMi;
    this.onSecEvent = onSecEvent;
    this.onSecParam = onSecParam;
    this.dinamikMi = dinamikMi;
    this.icerikYuklemeAdresi = icerikYuklemeAdresi;
    this.paramEvalStr = paramEvalStr;
    this.lastParam = "";
    this.tusKapatGorunur = tusKapatGorunur;
}

TnsTabSayfa.prototype.DivDegerAta = function(icerik) {
    //icerik = "<html> <head > <title>Untitled Page</title> </head> <body> dhjdjdhjdhdjh </body> </html>";
    var objDiv = document.getElementById(this.ilgiliDivAd);
    try {
        objDiv.innerHTML = icerik;
    }
    catch (e) {
        //alert(icerik);
    }
};

TnsTabSayfa.prototype.Yenile = function(mutlaka) {
    if (this.dinamikMi) {
        var yenile;
        var param;

        if (this.paramEvalStr != null && this.paramEvalStr != "")
            param = eval(this.paramEvalStr);
        else
            param = "";

        if (mutlaka || this.lastParam == "" || param != this.lastParam)
            yenile = true;
        else
            yenile = false;

        if (yenile) {
            this.lastParam = param;
            if (param != "" && param != null)
                adres = this.icerikYuklemeAdresi + param;
            else
                adres = this.icerikYuklemeAdresi;

            if (globalTabTur == 1) {
                var objDiv = document.getElementById(this.ilgiliDivAd + "_ifrm");
                objDiv.src = adres;
            }
            else {
                this.DivDegerAta("Yükleniyor....");
                var httpCagir = new HttpCagir(adres, HTTPCevap, this);
            }
        }
    }
};

function TnsTab(tabID, alanID, gizliAlanID, tabTur, dinamikContId, autoPostBack) {
    this.tabID = tabID;
    this.alanID = alanID;
    this.gizliAlanID = gizliAlanID;
    this.dinamikContId = dinamikContId;
    globalTabTur = tabTur;

    this.parcalar = new Array();
    this.secili = -1;
    this.autoPostBack = autoPostBack;
    this.uzunluk = 0;
    this.gorunenGenislik = 0;
}

TnsTab.prototype.ParcaEkle = function(ilgiliDivAd, engelliMi, gizliMi, onSecEvent, onSecParam, dinamikMi, icerikYuklemeAdresi, paramEvalStr, tusKapatGorunur) {
    var tut = this.parcalar.length;
    this.parcalar[tut] = new TnsTabSayfa(ilgiliDivAd, engelliMi, gizliMi, onSecEvent, onSecParam, dinamikMi, icerikYuklemeAdresi, paramEvalStr, tusKapatGorunur);
};

TnsTab.prototype.SonrakiTabItemSagEkBul = function(siraNo, Secili) {
    for (var i = siraNo + 1; i < this.parcalar.length; i++) {
        if (!this.parcalar[i].gizliMi) {
            if (i == Secili)
                return "a";
            else
                return "p";
        }
    }
    return "";
};

TnsTab.prototype.IlkGorunenSeciliMi = function(Secili) {
    for (var i = 0; i < this.parcalar.length; i++) {
        if (!this.parcalar[i].gizliMi) {
            if (i == Secili)
                return true;
            else
                return false;
        }
    }
    return false;
};

TnsTab.prototype.TabSecIc = function(tabNo, mutlakaYenile, eventOlsun) {
    document.getElementById(this.alanID).value = tabNo;
    if (this.dinamikContId != null && this.dinamikContId != "") {
        try {
            document.getElementById(this.dinamikContId).style.display = "none";
        }
        catch (e) {
        }
    }

    var sonEk = "p";
    if (this.IlkGorunenSeciliMi(tabNo)) sonEk = "a";

    var divDeg = document.getElementById(this.tabID + "_SOL");
    divDeg.className = "tab_sol_" + sonEk;
    var uzunluk = divDeg.offsetWidth;
    var aktifTabPos = -1;
    var aktifTabUzunluk = -1;
    var gizlilerStr = "";
    for (var i = 0; i < this.parcalar.length; i++) {
        var o = this.parcalar[i];
        var cerceveID = this.tabID + i + "_C";
        var icID = this.tabID + i + "_I";
        var resID = this.tabID + i + "_R";
        var sagID = this.tabID + i + "_S";

        var pasif = false;

        if (i == tabNo) {
            pasif = false;
            o.gizliMi = false;
        }
        else {
            pasif = true;
        }

        var sagsonek;
        var classStr;
        if (pasif) {
            classStr = "tab_pasif";
            sagsonek = "p";
        }
        else {
            classStr = "tab_aktif";
            sagsonek = "a";
        }

        sagsonek += this.SonrakiTabItemSagEkBul(i, tabNo);

        divDeg = document.getElementById(cerceveID);
        divDeg.className = classStr;
        document.getElementById(icID).className = classStr;
        try {
            document.getElementById(resID).className = classStr;
        }
        catch (e) { }
        document.getElementById(sagID).className = "tab_sag_" + sagsonek;
        if (o.gizliMi) {
            divDeg.style.display = "none";
            gizlilerStr += i.toString() + ";";
        }
        else {
            divDeg.style.display = "";
        }

        if (!o.engelliMi && !o.gizliMi && i == tabNo) {
            try {
                document.getElementById(o.ilgiliDivAd).style.display = "";
            }
            catch (e) { }
            if (o.dinamikMi) {
                document.getElementById(this.dinamikContId).style.display = "";
            }
        }
        else {
            try {
                document.getElementById(o.ilgiliDivAd).style.display = "none";
            }
            catch (e) { }
        }

        if (i == tabNo) {
            aktifTabPos = uzunluk;
            aktifTabUzunluk = divDeg.offsetWidth;
            if (o.onSecEvent != null && o.onSecEvent != "") {
                try { eval(o.onSecEvent + "(o, '" + o.onSecParam + "');"); } catch (err) { }
            }
            o.Yenile(mutlakaYenile);
        }
        uzunluk += divDeg.offsetWidth;
    }
    this.uzunluk = uzunluk;
    divDeg = document.getElementById("tab" + this.tabID + "Ic");
    this.gorunenGenislik = divDeg.offsetWidth;
    if (this.uzunluk <= this.gorunenGenislik) {
        goster = "none";
    }
    else
        goster = "";
    document.getElementById("tab" + this.tabID + "TusSag").style.display = goster;
    document.getElementById("tab" + this.tabID + "TusSol").style.display = goster;
    if (aktifTabPos > -1) {
        var icDiv = document.getElementById("tab" + this.tabID + "EnIc");
        if (icDiv.style.pixelLeft + aktifTabPos < 0)
            this.SolAyarla(icDiv, aktifTabPos);
        else if (icDiv.style.pixelLeft + aktifTabPos + aktifTabUzunluk > this.gorunenGenislik) {
            this.SolAyarla(icDiv, this.gorunenGenislik - (icDiv.style.pixelLeft + aktifTabPos + aktifTabUzunluk));
        }
    }
    document.getElementById(this.gizliAlanID).value = gizlilerStr;

    if (this.autoPostBack != "" && eventOlsun)
        eval(this.autoPostBack);
};

TnsTab.prototype.TabSecGiris = function(tabNo) {
    this.TabSecIc(tabNo, false, false);
};

TnsTab.prototype.TabSec = function(tabNo) {
    this.TabSecIc(tabNo, false, true);
};

TnsTab.prototype.TabSecResim = function(tabNo) {
    this.TabSecIc(tabNo, true, true);
};

TnsTab.prototype.SeciliSira = function() {
    return document.getElementById(this.alanID).value;
}

TnsTab.prototype.Yenile = function() {
    this.TabSecIc(this.SeciliSira(), false, true);
};

TnsTab.prototype.TabGizle = function(siraNo) {
    var secili = this.SeciliSira();
    this.parcalar[siraNo].gizliMi = true;
    if (secili == siraNo) secili = -1;
    this.TabSecIc(secili, false, false);
};

TnsTab.prototype.TabKaydir = function(yon) {//0: sol; 1:sağ
    var icDiv = document.getElementById("tab" + this.tabID + "EnIc");
    var fark = 120;
    var yer = icDiv.style.pixelLeft;
    if (yon == 1) {
        yer -= fark;
    }
    else {
        yer += fark;
    }
    this.SolAyarla(icDiv, yer);
};

TnsTab.prototype.SolAyarla = function(icDiv, yer) {
    if ((yer + this.uzunluk) < this.gorunenGenislik)
        yer = this.gorunenGenislik - this.uzunluk;
    if (yer > 0)
        yer = 0;
    icDiv.style.pixelLeft = yer;
}

TnsTab.prototype.TabMenuRadioClick = function(radioId) {
    var menuId = this.tabID + "_menu";
    var menuDiv = document.getElementById(menuId);
    for (var i = 0; i < this.parcalar.length; i++) {
        var radBut = document.getElementById(this.tabID + "radMenu" + i.toString());
        if (radBut) {
            radBut.checked = (radioId == i);
        }
    }
}

TnsTab.prototype.TabMenuIslem = function(islemKod) {
    var anaDiv = document.getElementById("tab" + this.tabID);
    var menuId = this.tabID + "_menu";
    var menuDiv = document.getElementById(menuId);
    if (menuDiv != null) {
        if (islemKod == 1) {
            secili = this.SeciliSira();
            for (var i = 0; i < this.parcalar.length; i++) {
                var radBut = document.getElementById(this.tabID + "radMenu" + i.toString());
                var buSecilmis = false;
                if (radBut && radBut.checked) {
                    secili = i;
                    buSecilmis = true;
                }

                var goster;
                if (buSecilmis) {
                    goster = 1;
                }
                else {
                    var chkBut = document.getElementById(this.tabID + "chkMenu" + i.toString());
                    if (chkBut) {
                        if (chkBut.checked)
                            goster = 1;
                        else
                            goster = 0;
                    }
                    else
                        goster = -1;
                }
                if (goster >= 0) {
                    this.parcalar[i].gizliMi = (goster == 0);
                }
            }
            this.TabSec(secili);
        }
        anaDiv.removeChild(menuDiv);
    }
}

TnsTab.prototype.MenuBaslikEkle = function(anaDiv) {
    var satir = DivisionOlustur("", "tabrow", "");
    satir.appendChild(DivisionOlustur("", "tabcol", "Seç"));
    satir.appendChild(DivisionOlustur("", "tabcol", "Göster"));
    var icStr = "";
    var onclickevent = "onclick=\"" + "js_" + this.tabID + ".TabMenuIslem(1);" + "\"";
    icStr = "<input type=\"button\" id=\"Tamam\" Value=\"Tamam\" " + onclickevent + "/>";
    //    onclickevent = "onclick=\"" + "js_" + this.tabID + ".TabMenuIslem(0);" + "\"";
    //    icStr += "<input type=\"button\" id=\"İptal\" Value=\"İptal\" " + onclickevent + "/>";
    var komutDiv = DivisionOlustur("", "tabtext", icStr);
    komutDiv.style.textAlign = "center";
    satir.appendChild(komutDiv);
    anaDiv.appendChild(satir);
};

TnsTab.prototype.MenuSatirEkle = function(anaDiv) {
    for (var i = 0; i < this.parcalar.length; i++) {
        var satir = DivisionOlustur("", "tabrow", "");
        var strSec;
        if (i == this.SeciliSira()) strSec = "checked";
        else strSec = "";
        var onclickevent = "onclick=\"" + "js_" + this.tabID + ".TabMenuRadioClick(" + i.toString() + ");" + "\"";

        if (this.parcalar[i].engelliMi)
            strSec = "";
        else
            strSec = "<input type=\"radio\" id=\"" + this.tabID + "radMenu" + i.toString() + "\" " + strSec + " " + onclickevent + "/>";

        satir.appendChild(DivisionOlustur("", "tabcol", strSec));


        if (this.parcalar[i].tusKapatGorunur) {
            if (this.parcalar[i].gizliMi) strSec = "";
            else strSec = "checked";

            strSec = "<input type=\"checkbox\" id=\"" + this.tabID + "chkMenu" + i.toString() + "\"" + strSec + "/>";
        }
        else
            strSec = "";
        satir.appendChild(DivisionOlustur("", "tabcol", strSec));
        var icStr = document.getElementById(this.tabID + i + "_I").innerHTML;
        var komutDiv = DivisionOlustur("", "tabtext", icStr);
        satir.appendChild(komutDiv);
        anaDiv.appendChild(satir);
    }
};

TnsTab.prototype.TabMenuGoster = function() {
    var anaDiv = document.getElementById("tab" + this.tabID);
    var menuId = this.tabID + "_menu";
    var menuDiv = document.getElementById(menuId);
    if (menuDiv == null) {
        var dv = document.createElement('div');
        dv.setAttribute('id', menuId);
        dv.className = "tnstabsec";
        dv.style.position = "absolute";
        dv.style.pixelLeft = document.getElementById("tab" + this.tabID + "TusMenu").offsetLeft;
        dv.style.pixelTop = 25;
        dv.style.pixelWidth = 400;
        dv.style.pixelHeight = 250;
        dv.style.overflow = "hidden";
        this.MenuBaslikEkle(dv);

        var dv2 = document.createElement('div');
        dv2.setAttribute('id', menuId);
        dv2.className = "tnstabsec";
        dv2.style.border = "none";
        dv2.style.position = "relative";
        dv2.style.pixelLeft = 0;
        dv2.style.pixelTop = 0;
        dv2.style.pixelWidth = 400;
        dv2.style.pixelHeight = 210;

        this.MenuSatirEkle(dv2);
        dv.appendChild(dv2);
        anaDiv.appendChild(dv);
    }
    else {
        anaDiv.removeChild(menuDiv);
    }
};