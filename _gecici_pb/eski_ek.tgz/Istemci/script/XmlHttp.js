function HttpCagir(httpAdres, method, param) {
    var http = getHTTPObject();

    if (http != null) {
        http.open("GET", httpAdres, true);
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded;charset=iso-8859-9")
        http.onreadystatechange = function () {
            if (http.readyState == 4) {
                try {

                    if (http.responseXML == null || http.responseXML.documentElement == null)
                        method(http.responseText, param);
                    else
                        method(http.responseXML.documentElement, param);
                }
                catch (err) { }
            }
        }
        http.send(null);
    }

    function getHTTPObject() {
        var xmlhttp = null;

        if (typeof XMLHttpRequest != 'undefined') {
            try {
                xmlhttp = new XMLHttpRequest();
            }
            catch (err)
            { xmlhttp = null; }
        }

        if (xmlhttp == null) {
            try {
                xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
            }
            catch (errDis) {
                try {
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                catch (errIc)
                { xmlhttp = false; }
            }
        }

        return xmlhttp;
    }
}

var http = getHTTPObject(); // We create the HTTP Object

function kodAdGetir(kodTur, degerYazKontrol, esitle, kosul, kosulTur) {
    var deger = "";

    for (i = 0; i < kosul.length; i++) {
        if (deger != "")
            deger += "-";

        if (kosulTur == "DEGISKEN") {
            if (kosul[i] == "") return;
            deger += kosul[i];
        }
        else if (kosulTur == "KONTROLDENOKU") {
            if (document.getElementById(kosul[i]).value == "") {
                document.getElementById(degerYazKontrol).innerText = "";
                return;
            }
            deger += document.getElementById(kosul[i]).value;
        }
    }
    if (deger != "") {
        deger = urlKodla(deger);
        http.open("GET", "../ortakSayfa/kodAdDondur.aspx?kodTur=" + kodTur + "&kosul=" + deger + "&esitle=" + esitle + "&degerYazKontrol=" + degerYazKontrol, true);

        http.onreadystatechange = handleHttpResponse;
        http.send(null);
    }
    else {
        if (degerYazKontrol != "") {
            if (degerYazKontrol.indexOf("|") > 0) {
                listeAlan = degerYazKontrol.split("|");
                koordinat = listeAlan[1].split("x");
                document.getElementById(listeAlan[0]).SetValue(koordinat[0], koordinat[1], "", true);
            }
            else
                document.getElementById(degerYazKontrol).innerHTML = "";
        }
    }
}

function handleHttpResponse() {
    //alert("http.readyState="+http.readyState);
    if (http.readyState == 4) {
        try {
            //alert("http.responseText="+http.responseText);
            result = http.responseText.split(",");
            //alert("result="+result);
            if (result[0].indexOf("|") > 0) {
                listeAlan = result[0].split("|");
                koordinat = listeAlan[1].split("x");

                if (listeAlan[0].substring(0, 3) == "fpL") {
                    var hucre = document.getElementById(listeAlan[0]).GetCellByRowCol(koordinat[0], koordinat[1]);
                    if (hucre) {
                        var durum = hucre.getAttribute("FpCellType");
                        hucre.removeAttribute("FpCellType");
                        document.getElementById(listeAlan[0]).SetValue(koordinat[0], koordinat[1], result[1], true);
                        if (durum != "")
                            hucre.setAttribute("FpCellType", durum);
                    }
                }
                else
                    document.getElementById(listeAlan[0]).SetValue(koordinat[0], koordinat[1], result[1], true);
            }
            else {
                if (result[0].substr(0, 3) == "txt" || result[0].substr(0, 3) == "hdn")
                    document.getElementById(result[0]).value = result[1];
                else
                    document.getElementById(result[0]).innerHTML = result[1];
            }
        }
        catch (e) {
        }
    }
}

function getHTTPObject() {
    var xmlhttp;
    /*@cc_on
    @if (@_jscript_version >= 5)
    try {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
        try {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        } catch (E) {
            xmlhttp = false;
        }
    }
    @else
            xmlhttp = false;
            @end
    @*/
    if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
        try {
            xmlhttp = new XMLHttpRequest();
        } catch (e) {
            xmlhttp = false;
        }
    }
    return xmlhttp;
}

function urlKodla(str) {

    str = str.replace(/Ç/g, "C|");
    str = str.replace(/Ü/g, "U|");
    str = str.replace(/Ö/g, "O|");
    str = str.replace(/ç/g, "c|");
    str = str.replace(/ü/g, "u|");
    str = str.replace(/ö/g, "o|");
    str = escape(str);

    return str;
} 
