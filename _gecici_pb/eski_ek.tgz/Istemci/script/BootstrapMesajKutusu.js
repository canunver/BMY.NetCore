﻿function StrEkle(On, Arka) {
    if (On == null || On == undefined || On == "") return Arka;
    if (Arka == null || Arka == undefined || Arka == "") return On;
    return On + ' ' + Arka;
}

var stack_bottomright = { "dir1": "up", "dir2": "left", "push": "top" };
var stack_bottomleft = { "dir1": "up", "dir2": "right", "push": "top" };
var stack_topleft = { "dir1": "down", "dir2": "right", "push": "bottom" };
var stack_topright = { "dir1": "down", "dir2": "left", "push": "bottom" };

function PopUpMesajZamanAyarla(zaman) {
    PNotify.prototype.options.delay = zaman;
    update_timer_display();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///yer: 0->sağ alt,2-> sol üst , 3->sol alt, diğer-> sağ üst
///yazi: Pencerenin içinde gösterilecek metin
///baslik: Pencerenin başlık kısmında gösterilecek metin
///tip: 1-> success 2->error diğer -> info
///sure: 1-> success 2->error 3-> notice diğer -> info
///opacity: 0-1 arasında şeffaflık, çalışmadı
///icon: No, 'ui-icon ui-icon-locked', 'glyphicon glyphicon-envelope' gibi ikon ismi
///addclass: Ek class ismi
///hide: false verilirse, automatik olarak gizlenmez.
///shadow: gölge olsun mu
///width: Genişlik '270px' gibi dizgi olacak
///min_width: Min. Genişlik '270px' gibi dizgi olacak
///height: Yükseklik '270px' gibi dizgi olacak
///min_height: Min. Yükseklik '270px' gibi dizgi olacak
///
///Not:pnotify.custom.min.css ve pnotify.custom.min.js eklenmeli
function PopUpMesaj(yer, yazi, baslik, tip, sure, opacity, icon, addclass, hide, shadow, width, min_width, height, min_height) {
    var o = new Object();

    o.mobile = { swipe_dismiss: false };

    if (sure != null && sure != undefined && sure > 0) {
        o.delay = sure;
    }
    if (yer == 0) {
        addclass = StrEkle(addclass, "stack-bottomright");
        o.stack = stack_bottomright;
    }
    else if (yer == 1) {
        addclass = StrEkle(addclass, "stack-topright");
        o.stack = stack_topright;
    }
    else if (yer == 2) {
        addclass = StrEkle(addclass, "stack-topleft");
        o.stack = stack_topleft;
    }
    else if (yer == 3) {
        addclass = StrEkle(addclass, "stack-bottomleft");
        o.stack = stack_bottomleft;
    }

    if (min_height != null && min_height != undefined && min_height != '') {
        o.min_height = min_height;
    }

    if (height != null && height != undefined && height != '') {
        o.height = height;
    }

    if (width != null && width != undefined && width != '') {
        o.width = width;
    }

    if (min_width != null && min_width != undefined && min_width != '') {
        o.min_width = min_width;
    }

    if (opacity != null && opacity != undefined) {
        o.opacity = opacity;
    }

    if (shadow != null && shadow != undefined) {
        o.shadow = shadow;
    }

    if (hide != null && hide != undefined) {
        o.hide = hide;
    }

    icTip = 'info';
    if (tip == 1)
        icTip = 'success';
    else if (tip == 2)
        icTip = 'error';
    else if (tip == 3)
        icTip = 'notice';

    if (baslik != null && baslik != undefined && baslik != '') {
        o.title = baslik;
    }
    if (yazi != null && yazi != undefined && yazi != '') {
        o.text = yazi;
    }

    o.type = icTip;
    o.styling = 'bootstrap3';
    if (icon != null && icon != undefined) {
        o.icon = icon;
    }
    if (addclass != null && addclass != undefined && addclass != '') {
        o.addclass = addclass;
    }
    return new PNotify(o);
}

function BekleKutusu(baslik, tur) {
    if (tur == undefined || tur == null)
        tur = 1;

    if (baslik == undefined || baslik == null)
        baslik = 'Lütfen Bekleyiniz...';

    if (tur == 3) {
        var s = window.top;
        $(s).block({
            message: '<i class="icon-spinner spinner"></i>&nbsp;' + baslik,
            css: {
                border: 'none',
                padding: '15px',
                backgroundColor: '#000',
                '-webkit-border-radius': '10px',
                '-moz-border-radius': '10px',
                opacity: .6,
                color: '#fff'
            }
        });

        return s;
    }

    var s = "<div class='modal fade' role='dialog'>";
    s += "<div class='modal-dialog'>";
    s += "<div class='modal-content'>";
    if (tur != 2) {
        s += "<div class='modal-header'>";
        s += baslik;
        s += "</div>";
    }
    s += "<div class='modal-body'>";
    if (tur == 2)
        s += "<button class='btn btn-lg btn-warning' style='width:100%'><span class='glyphicon glyphicon-refresh spinning'></span> " + baslik + "</button>";
    else
        s += "<div class='progress progress-striped active'><div class='progress-bar' style='width: 100%;'></div></div>";

    s += "</div>";
    s += "</div>";
    s += "</div>";
    s += "</div>";
    var $s = $(s);
    $s.modal({ backdrop: "static", keyboard: false });
    return $s;
}

function BekleKaldir($s) {
    try { $s.modal('hide'); } catch (e) { }
    try { $.unblockUI() } catch (e) { }
}

function MesajKutusu(baslik, icerik, gelenParam, girisEtiket, fonksiyon) {
    var s = "<div class='modal fade' role='dialog'>";
    s += "<div class='modal-dialog'>";
    s += "<div class='modal-content'>";
    s += "<div class='modal-header'>";
    s += "<button type='button' class='close' data-dismiss='modal'>";
    s += "&times;</button>";
    s += "<h4 class='modal-title'>";
    s += baslik + "</h4>";
    s += "</div>";
    s += "<div class='modal-body'>";
    s += "<p>" + icerik + "</p>";
    var girisVar = false;
    if (girisEtiket != undefined && girisEtiket != "" && girisEtiket != null) {
        s += "<div class='form-group'>";
        s += "<label for='recipient-name' class='control-label'>" + girisEtiket + "</label>";
        s += "<input type='text' class='form-control' id='txtGiris'>";
        s += "</div>";
        girisVar = true;
    }
    s += "</div>";
    s += "<div class='modal-footer'>";
    if (!(fonksiyon == undefined || fonksiyon == null)) {
        s += "<button type='button' class='btn btn-default' id='btnHayir'>Hayır</button>";
        tusAd = 'Evet';
    }
    else
        tusAd = 'Tamam';
    s += "<button type='button' class='btn btn-primary' id='btnEvet'>" + tusAd + "</button>";
    s += "</div>";
    s += "</div>";
    s += "</div>";
    s += "</div>";
    var $s = $(s);
    //$s.children('#btnHayir').addClass('hidden');
    btnNo = -1;
    girilen = "";
    $s.on('click', '#btnHayir', function () {
        btnNo = 0;
        $s.modal('hide');
    });
    $s.on('click', '#btnEvet', function () {
        btnNo = 1;
        if (girisVar)
            girilen = $s.find('#txtGiris').val();
        $s.modal('hide');
    });

    $s.on('hidden.bs.modal',
                function () {
                    if (fonksiyon != undefined && fonksiyon != null)
                        fonksiyon(btnNo, girilen, gelenParam);
                });
    $s.on('shown.bs.modal',
                function () {
                    if (girisVar)
                        $s.find('#txtGiris').focus();
                    else
                        $s.find('#btnEvet').focus();
                });

    $s.modal({ backdrop: "static", keyboard: true });
}

function UzYukAyarla(ad, w) {
    if (w != undefined && w != null && w != "") {
        sw = ad + ":" + w;
    }
    else {
        var uz;
        if (ad[0] == "w")
            uz = parseInt(window.innerWidth * 0.8);
        else
            uz = window.innerHeight - 60;
        if (uz < 100) uz = 100;
        sw = ad + ":" + uz + "px";
    }
    return sw;
}

//function KaldirBakalim(th) {
//    alert(1);
//}

function SayfaAcModal(baslik, url, w, h, hareketli, gelenParam, fonksiyon) {
    //url = "../OrtakSayfa/bekle.htm";
    var sw = UzYukAyarla('width', w);
    var sh = UzYukAyarla('height', h);
    var s = "<div class='modal fade' role='dialog' style='max-height:2000px;' >";
    s += "<div class='modal-dialog' style='" + sw + ";' role='document'>";
    s += "<div class='modal-content' style='" + sh + ";'>";
    s += "<div class='modal-header' style='height:50px;'>";
    s += "<button type='button' class='close' data-dismiss='modal'>";
    s += "&times;</button>";
    s += "<h5 class='modal-title' >";
    s += baslik + "</h5>";
    s += "</div>";
    s += "<div class='modal-body' style='height:92%;'>";

    s += "<div class='modal-content' id='bekle'>";
    s += "<div class='modal-header'>";
    s += "Lütfen Bekleyiniz...";
    s += "</div>";
    s += "<div class='modal-body'><div class='progress progress-striped active'><div class='progress-bar' style='width: 100%;'></div></div></div>";
    s += "</div>";
    s += "<iframe id='ifrSayfa' width='100%' height='100%' frameborder='0' src='" + url + "'></iframe>";
    s += "</div>";
    s += "</div>";
    s += "</div>";
    s += "</div>";
    var $s = $(s);

    $s.on('hidden.bs.modal',
                function () {
                    if (fonksiyon != undefined && fonksiyon != null)
                        fonksiyon(gelenParam);
                });
    try {
        if (hareketli != undefined && hareketli != null && hareketli == true) {
            $s.find('.modal-content').resizable({
                //alsoResize: ".modal-dialog",
                //minHeight: 150
            });
            $s.find('.modal-dialog').draggable();

            $s.on('show.bs.modal', function () {
                $(this).find('.modal-body').css({
                    'max-height': '100%'
                });
            });
        }
    }
    catch (ev) {
    }
    var $frm = $s.find('#ifrSayfa');
    $s.modal({ backdrop: "static", keyboard: true });
    var frm = $frm.get(0);
    if (frm.addEventListener) {
        setTimeout(Kontrol, 100);

        var say = 0;
        function Kontrol() {
            say++;
            if ((frm.contentWindow &&
            frm.contentWindow.document &&
            frm.contentWindow.document.body &&
            frm.contentWindow.document.body.children) || say > 100) {
                var bekle = $s.find('#bekle');
                bekle.addClass("hidden");
            }
            else {
                setTimeout(Kontrol, 100);
            }
        }
    }
    else {
        frm.onload = function () {
            var bekle = $s.find('#bekle');
            bekle.addClass("hidden");
        };
    }
}