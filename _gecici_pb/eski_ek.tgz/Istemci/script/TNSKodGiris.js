﻿function KodGirisSecimAc(adres, kodId, kodAdId, sayfaEkParamEvalStr, dogrulaEvalStr, genislik, yukseklik) {
    if (sayfaEkParamEvalStr != '')
        adres += eval(sayfaEkParamEvalStr);

    var hataMesaj = '';
    if (dogrulaEvalStr != '') {
        hataMesaj = eval(dogrulaEvalStr);
    }

    if (hataMesaj != "") {
        alert(hataMesaj);
    }
    else {
        showPopWin(adres, genislik, yukseklik, true, null);
    }
}
