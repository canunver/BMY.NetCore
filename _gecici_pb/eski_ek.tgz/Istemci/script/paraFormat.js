﻿function ScriptParaCevir(para) {
    if (para != "") {
        try {
            para = para.replace(/\./g, '');
            para = para.replace(/,/g, '.');
        }
        catch (e)
        { }
    }
    else
        para = "0";

    return para;
}

function ParayiFormatla(control, kurusEkle) {
    var col = control.GetActiveCol();
    var row = control.GetActiveRow();
    var deger = control.GetValue(row, col);

    deger = deger.replace(/,/g, '.');

    if (isFinite(deger)) {
        deger = formatCurrency(deger, kurusEkle);
        control.SetValue(row, col, deger, true);
    }
}

function ParaNoktaKoy(control, gelenDeger) {
    var col = control.GetActiveCol();
    var row = control.GetActiveRow();
    var deger = control.GetValue(row, col);

    deger = deger.replace(/\./g, '');

    var parca = deger.split(',');

    if (isFinite(parca[0])) {
        deger = parca[0];
        for (var i = 0; i < Math.floor((deger.length - (1 + i)) / 3); i++)
            deger = deger.substring(0, deger.length - (4 * i + 3)) + '.' + deger.substring(deger.length - (4 * i + 3));

        if (isFinite(parca[1]))
            deger += "," + parca[1];

        control.SetValue(row, col, deger, true);
    }
}

function ParaNoktala(deger) {
    deger = deger.replace(/\./g, '');
    var parca = deger.split(',');

    if (isFinite(parca[0])) {
        deger = parca[0];
        for (var i = 0; i < Math.floor((deger.length - (1 + i)) / 3); i++)
            deger = deger.substring(0, deger.length - (4 * i + 3)) + '.' + deger.substring(deger.length - (4 * i + 3));

        if (isFinite(parca[1]))
            deger += "," + parca[1];
    }

    return deger;
}

function formatCurrency(num, kurusEkle) {
    var isNegative = false;

    if (isNaN(num)) {
        num = "0";
    }
    if (num < 0) {
        num = Math.abs(num);
        isNegative = true;
    }
    cents = Math.floor((num * 100 + 0.5) % 100);
    num = Math.floor((num * 100 + 0.5) / 100).toString();
    if (cents < 10) {
        cents = "0" + cents;
    }
    for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
        num = num.substring(0, num.length - (4 * i + 3)) + '.' + num.substring(num.length - (4 * i + 3));
    }

    var result = 0;
    if (kurusEkle == true)
        result = num + ',' + cents;
    else
        result = num;
    if (isNegative) {
        result = "-" + result;
    }
    return result;
}

function ConvertToDbl(deger, hataDeger) {
    if (typeof (deger) == "number") return deger;
    if (typeof (deger) == "string") {
        var icDeger = deger.replace(/\./g, "");
        icDeger = icDeger.replace(",", ".");

        try {
            d = parseFloat(icDeger);
        }
        catch (errInfo) {
            d = hataDeger;
        }
        if (isNaN(d)) d = hataDeger;
        return d;
    }
    return 0;

}
        
        
