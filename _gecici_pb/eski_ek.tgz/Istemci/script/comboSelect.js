﻿	var timerid     = null;
	var matchString = "";
	var mseconds    = 1000;	// Length of time before search string is reset

	function shiftHighlight(keyCode,targ)
	{
		// Convert ASCII Code to a string
		keyVal      = String.fromCharCode(keyCode); 
		// Add to previously typed characters
		matchString = matchString + keyVal; 
		// Calculate length of array -1
		elementCnt  = targ.length - 1;	
		for (i = elementCnt; i > 0; i--)
		{
			if (targ.options[i].selected)
				targ.options[i].selected = false;
		} 


		for (i = elementCnt; i > 0; i--)
		{
			// convert text in SELECT to lower case
			selectText = targ.options[i].text.toLowerCase(); 

			if (selectText.substr(0,matchString.length) == 	matchString.toLowerCase())
			{
				// Make the relevant OPTION selected
				targ.options[i].selected = true; 
				i=0;
			}
		}
		// Clear the timeout
		clearTimeout(timerid); 
		// Set a new timeout to reset the key press string
		timerid = setTimeout('matchString = ""',mseconds); 
		// to prevent IE from doing its own highlight switching
		
		return false; 
	}