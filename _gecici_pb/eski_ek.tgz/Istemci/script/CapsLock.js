
function capsLockKontrol(e) {
    var myKeyCode = 0;
    var myShiftKey = false;

    // Internet Explorer 4+
    if (document.all) {
        myKeyCode = e.keyCode;
        myShiftKey = e.shiftKey;

        // Netscape 4
    } else if (document.layers) {
        myKeyCode = e.which;
        myShiftKey = (myKeyCode == 16) ? true : false;

        // Netscape 6
    } else if (document.getElementById) {
        myKeyCode = e.which;
        myShiftKey = (myKeyCode == 16) ? true : false;

    }
    // Shift'e bas�lmadan b�y�k harf, caps lock a��k
    if ((myKeyCode >= 65 && myKeyCode <= 90) && !myShiftKey) {
        document.getElementById('lblCapsHata').style.visibility = "visible";
    } // Shift'e bas�larak k���k harf, caps lock a��k 
    else if ((myKeyCode >= 97 && myKeyCode <= 122) && myShiftKey)
        document.getElementById('lblCapsHata').style.visibility = "visible";
    else
        document.getElementById('lblCapsHata').style.visibility = "hidden";
}

