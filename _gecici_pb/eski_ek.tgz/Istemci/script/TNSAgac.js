﻿var COCUKYOK="0";
var COCUKOKU="1";
var COCUKVARACIK="2";
var COCUKVARKAPALI="3";

function CevapGeldi(cevap, param)
{
	var div = document.getElementById(param.IcDivId);		
	div.innerHTML = cevap;
}

function ServerCagir(AgacId, IcDivId, ResimId, Deger)
{		
	var objAgac = document.getElementById(AgacId);
	var adres = objAgac.getAttribute("YukleAdres");
	if(adres != null)
	{
		param = new Object;
		param.IcDivId = IcDivId;
		adres += Deger;
	
		var c1 = new HttpCagir(adres, CevapGeldi, param);
	}
}

function AcKapaDiv(AgacId, IcDivId, ResimId, Deger) 
{
	var objAgac = document.getElementById(AgacId);
	var kapaliSatirGif = objAgac.getAttribute("KapaliResim");
	var acikSatirGif = objAgac.getAttribute("AcikResim");
	var classResim = objAgac.getAttribute("ClassResim");

	var obj = document.getElementById(IcDivId);
	var cocukTur = obj.getAttribute("COCUKTUR");
			
	if(cocukTur == COCUKOKU)
	{
		ServerCagir(AgacId, IcDivId, ResimId, Deger);			
		obj.setAttribute("COCUKTUR", COCUKVARACIK);
		visible = false;
	}
	else
		visible=(obj.style.display != "none")		
	gif=document.getElementById(ResimId);
	if (visible) 
	{
		obj.style.display = "none";
		gif.src= kapaliSatirGif;
	} 
	else 
	{
		obj.style.display="block";
		gif.src=acikSatirGif;
	}		
}  

