﻿function ClipBoardVeriYaz(veri, toFile) {
    if (toFile)
    {
        var blob = new Blob([veri], { type: 'text/tab-separated-values;charset=utf-8;' });
        var link = document.createElement("a");
        if (link.download !== undefined) {
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", "veriler.csv");
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
    navigator.clipboard.writeText(veri);
}

function RemoveEnterTab(val, removeEnterTab) {
    if (removeEnterTab == undefined || removeEnterTab == null || removeEnterTab)
        return val.replace(/\t/g, "\\t").replace(/\r/g, "\\r").replace(/\n/g, "\\n");
    else
        return val;
}

function AddEnterTab(val, addEnterTab) {
    if (addEnterTab == undefined || addEnterTab == null || addEnterTab)
        return val.replace(/\\t/g, "\t").replace(/\\r/g, "\r").replace(/\\n/g, "\n");
    else
        return val;
}

function KolonDiziOl(gp, prmCol, hepsi) {
    var clmns = gp.colModel.columns;
    var kolonDizi = new Array();
    var kolonDiziSay = 0;
    for (var i = prmCol; i < clmns.length; i++) {
        var clmn = clmns[i];
        if (clmn.dataIndex != "" && !clmn.hidden) {
            if (clmn.editor != null || clmn.editable || hepsi) {
                kolonDizi[kolonDiziSay] = gp.store.getFieldByName(clmn.dataIndex);
                kolonDiziSay++;
            }
        }
    }
    return kolonDizi;
}

function RemoveR(satir) {
    var uz = satir.length;
    if (satir[uz - 1] == '\r')
        return satir.substring(0, uz - 1);
    return satir;
}

function EXTVeriYapistir(gp, prmRow, prmCol, satirAc, fnc, addEnterTab) {
    if (prmRow === -1 && prmCol === -1 && gp === null)
        return false;

    navigator.clipboard.readText().then(text => {
        var data = text.toString();
        if (data == null || data == undefined || data == "")
            return true;

        var startRowIndex;
        var startColIndex;

        var kolonDizi = KolonDiziOl(gp, prmCol);
        var rowValues = data.split('\n');

        var kopyaUzunluk = rowValues.length;
        if (kopyaUzunluk == 0) return true;
        while (true) {
            if (rowValues[kopyaUzunluk - 1] == "" || rowValues[kopyaUzunluk - 1] == "\r") kopyaUzunluk--;
            else break;
            if (kopyaUzunluk < 1) break;
        }

        var sonSatir = prmRow + kopyaUzunluk;
        var satSay = gp.store.getCount();
        if (satSay < sonSatir && satirAc) {
            try {
                for (i = 0; i < sonSatir - satSay; i++) {
                    gp.store.add(new gp.store.recordType({}));
                }
            } catch (ex) { }
        }

        satSay = gp.store.getCount();
        if (satSay < sonSatir) {
            kopyaUzunluk = satSay - prmRow;
        }
        //**Panodaki verinin satırları arasında dön
        for (var rowIndex = 0; rowIndex < kopyaUzunluk; rowIndex++) {
            var tut = RemoveR(rowValues[rowIndex]);

            var colValues = tut.split('\t');
            SetValue(gp, prmRow + rowIndex, prmCol, colValues, kolonDizi, fnc, addEnterTab);
        }
    });
}

function SetValue(gridPanel, rowIndex, startColIndex, colValues, kolonDizi, fnc, addEnterTab) {
    var rec = gridPanel.store.getAt(rowIndex);
    if (!rec) return;
    for (var i = 0; i < Math.min(kolonDizi.length, colValues.length); i++) {
        if (kolonDizi[i] != null) {
            var val = AddEnterTab(colValues[i], addEnterTab);
            if (kolonDizi[i].type.type == "int" || kolonDizi[i].type.type == "float") {
                try {
                    val = val.replace(/\./g, '');
                    val = val.replace(/,/g, '.');
                    if (kolonDizi[i].type.type == "int")
                        val = parseInt(val);
                    else
                        val = parseFloat(val);
                }
                catch (ex) {
                    val = 0;
                }
            }
            //            else if (kolonDizi[i].type.type == "bool")
            //                val = parseInt();
            var e;
            if (fnc) {
                e = new Object();
                e.originalValue = rec.get(kolonDizi[i].name);
            }
            rec.set(kolonDizi[i].name, val);
            if (fnc) {
                e.column = i + startColIndex;
                e.grid = gridPanel;
                e.record = rec;
                e.field = kolonDizi[i].name;
                e.value = val;
                e.row = rowIndex;
                fnc(e);
            }
        }
    }
}

function GetRecord(st, colValues) {
    var rec = new st.recordType({});
    for (var i = 0; i < Math.min(colValues.length, st.fields.length); i++) {
        var field = st.fields.items[i];
        var val = colValues[i];
        if (field.type.type == "int" || field.type.type == "float")
            try {
                val = val.replace(/\./g, '');
                val = val.replace(/,/g, '.');
                if (field.type.type == "int")
                    val = parseInt(val);
                else
                    val = parseFloat(val);
            }
            catch (ex) {
                val = 0;
            }
        rec.set(field.name, val);
    }
    return rec;
}

function PasteStore(st, callBack) {
    navigator.clipboard.readText().then(
        data => {
            if (data == null || data == undefined || data == "")
                return true;
            var rowValues = data.split('\n');

            for (var rowIndex = 0; rowIndex < rowValues.length; rowIndex++) {
                if (rowValues[rowIndex] != "" || rowIndex < rowValues.length - 1) {
                    var colValues = RemoveR(rowValues[rowIndex]).split('\t'); //split(new RegExp("\\t", "g"));
                    st.add(GetRecord(st, colValues));
                }
            }
            if (callBack)
                callBack();
        }
    );
}

var replaceAllTabs = new RegExp('\t', 'g');
var replaceAllREnters = new RegExp('\r', 'g');
var replaceAllNEnters = new RegExp('\n', 'g');

function RemoveEnterTab(val, RemoveEnterTab) {
    if (RemoveEnterTab == undefined || RemoveEnterTab == null || RemoveEnterTab) {
        return val.replace(replaceAllTabs, "\\t").replace(replaceAllREnters, "\\r").replace(replaceAllNEnters, "\\n")
    }
    else
        return val;
}

function CopyRecord(fields, rec, iFormat, fFormat, dFormat, removeEnterTab) {
    var sat = "";
    for (var i = 0; i < fields.length; i++) {
        if (i != 0) sat += "\t";
        var field = fields[i];
        if (field != null) {
            var val = rec.get(field.name);
            if (val != null) {
                if (field.type.type == "int") {
                    sat += Ext1.util.Format.number(val, iFormat);
                }
                else if (field.type.type == "float") {
                    sat += Ext1.util.Format.number(val, fFormat);
                }
                else if (field.type.type == "date") {
                    sat += val.dateFormat(dFormat);
                }
                else
                    sat += RemoveEnterTab(val.toString(), removeEnterTab);
            }
        }
    }
    sat += "\r\n";
    return sat;
}

function CopyStore(st, iFormat, fFormat, dFormat, removeEnterTab, toFile) {
    if (iFormat == undefined || iFormat == null) iFormat = "0.000/i";
    if (fFormat == undefined || fFormat == null) fFormat = "0.000,00/i";
    if (dFormat == undefined || dFormat == null) dFormat = "Y-m-d H:i:s";
    var data = "";

    var kolonDizi = new Array();
    var kolonDiziSay = 0;

    for (var i = 0; i < st.fields.length; i++) {
        kolonDizi[kolonDiziSay] = st.fields.items[i];
        kolonDiziSay++;
    }

    st.each(
        function (rec) {
            data += CopyRecord(kolonDizi, rec, iFormat, fFormat, dFormat, removeEnterTab);
        }
    );
    ClipBoardVeriYaz(data, toFile);
}

function CopyGrid(gp, iFormat, fFormat, dFormat, removeEnterTab) {
    if (iFormat == undefined || iFormat == null) iFormat = "0.000/i";
    if (fFormat == undefined || fFormat == null) fFormat = "0.000,00/i";
    if (dFormat == undefined || dFormat == null) dFormat = "Y-m-d H:i:s";

    var startRowIndex;
    var startColIndex;

    var kolonDizi = KolonDiziOl(gp, 0);

    var data = "";
    var seciliSay = gp.selModel.selections.items.length;

    if (seciliSay >= 1) {
        for (var i = 0; i < gp.selModel.selections.items.length; i++) {
            data += CopyRecord(kolonDizi, gp.selModel.selections.items[i], iFormat, fFormat, dFormat, removeEnterTab);
        }
    }
    else {
        var basla = 0;
        var satirSay = 0;
        gp.store.each(
            function (rec) {
                if (satirSay >= basla) {
                    data += CopyRecord(kolonDizi, rec, iFormat, fFormat, dFormat);
                }
                satirSay++;
            }
        );
    }
    ClipBoardVeriYaz(data);
}


/* EXT Grid başlıklara değer atama, include edilmelidir.
<script language="Javascript" type="text/javascript" src="../script/paraFormat.js"></script>

*/
function HGToplamDegerAl(grid, rowNo, colNo) {
    return ConvertToDbl(grid.view.headerGroupRows[rowNo][colNo].header, 0);
}

function HGToplamDegerAta(grid, rowNo, colNo, toplam) {
    HeaderAyarla(grid, rowNo, colNo, formatCurrency(toplam, false));
}

function ToplamDegerAl(grid, colNo) {
    var col = grid.colModel.getColumnAt(colNo);
    return ConvertToDbl(col.header, 0);
}

function ToplamDegerAta(grid, colNo, toplam) {
    grid.colModel.setColumnHeader(colNo, formatCurrency(toplam, false));
}

function HeaderAyarla(grid, satir, sutun, baslik) {
    grid.view.headerGroupRows[satir][sutun].header = baslik;

    var rows = grid.view.mainHd.select(".x-grid3-hd-row", true).elements;
    var tds = rows[satir].select("td", true).elements;

    tds[sutun].child("div").dom.lastChild.nodeValue = baslik;
}

function OranIslem(grd, kaynakSutunAd, kaynakToplam, hedefSutunAd, hedefToplam) {
    grd.store.each(
        function (rec) {
            var yeniDeger;
            if (hedefToplam === 0 || kaynakToplam === 0) return false;
            var eskiDeger = rec.get(kaynakSutunAd);
            if (eskiDeger === kaynakToplam)
                yeniDeger = hedefToplam;
            else
                yeniDeger = Math.round(((eskiDeger / kaynakToplam) * hedefToplam) / 1000) * 1000;
            rec.set(hedefSutunAd, yeniDeger);
            kaynakToplam -= eskiDeger;
            hedefToplam -= yeniDeger;
        }
    );

    return hedefToplam;
}

