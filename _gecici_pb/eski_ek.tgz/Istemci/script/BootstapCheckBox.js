﻿function CheckBoxlariOku(cbID) {
    var counter = 0;
    var aktiflik = "";
    $("#" + cbID + " li.active").each(function (idx, li) {
        if (counter != 0)
            aktiflik += ",";
        aktiflik += $(li).attr('value');
        counter++;
    });
    return aktiflik;
}


$(function () {
    $('.list-group.checked-list-box .list-group-item').each(function () {

        // Settings
        var $widget = $(this);
        var $checkbox = $('<input type="checkbox" class="hidden" />');
        var color = ($widget.data('color') ? $widget.data('color') : "primary");
        var arka = ($widget.data('arka') ? $widget.data('arka') : "");
        var style = ($widget.data('style') == "button" ? "btn-" : "list-group-item-");
        var settings = {
            on: {
                icon: 'glyphicon glyphicon-check'
            },
            off: {
                icon: 'glyphicon glyphicon-unchecked'
            }
        };

        $widget.css('cursor', 'pointer')
        $widget.append($checkbox);

        // Event Handlers
        $widget.on('click', function () {
            $checkbox.prop('checked', !$checkbox.is(':checked'));
            $checkbox.triggerHandler('change');
            updateDisplay();
        });

        $checkbox.on('change', function () {
            updateDisplay();
        });
        init();

        // Actions
        function updateDisplay() {
            var isChecked = $checkbox.is(':checked');

            // Set the button's state
            $widget.data('state', (isChecked) ? "on" : "off");

            // Set the button's icon
            $widget.find('.state-icon').removeClass().addClass('state-icon ' + settings[$widget.data('state')].icon);

            // Update the button's color
            if (isChecked) {
                $widget.addClass(style + color + ' active');
                if (arka != '') {
                    $widget.removeClass(arka);
                }
            } else {
                $widget.removeClass(style + color + ' active');
                if (arka != '') {
                    $widget.addClass(arka);
                }
            }
        }

        // Initialization
        function init() {
            if ($widget.data('checked') == true) {
                $checkbox.prop('checked', !$checkbox.is(':checked'));
            }

            updateDisplay();

            // Inject the icon if applicable
            if ($widget.find('.state-icon').length == 0) {
                $widget.prepend('<span class="state-icon ' + settings[$widget.data('state')].icon + '"></span>');
            }
        }
    });
});

