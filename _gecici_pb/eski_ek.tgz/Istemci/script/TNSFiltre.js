﻿function FiltreTemizle(control) {
    alanlar = control.getElementsByTagName("input");
    for (var i = 0; i < alanlar.length; i++) {
        var tip = alanlar[i].type;
        if (tip == 'hidden' || tip == 'text')
            alanlar[i].value = "";
    }
}

function DivGosterKapat(divAd, yukseklik) {
    var div = document.getElementById(divAd);
    var h = div.style.height;
    if (h == "0px") {
        div.style.height = yukseklik + "px";
        div.style.overflow = "visible";
    }
    else {
        div.style.height = "0px";
        div.style.overflow = "hidden";
    }
}

function AdGecerliMi(txtAd) {
    var icerik = txtAd.value;
    if (icerik == null || icerik == "") {
        alert(fiMesaj3);
        return false;
    }
    else
        return true;
}

function fiDogrula(mesajNo) {
    var mesaj = "";
    if (mesajNo == 1)
        mesaj = fiMesaj1;
    else if (mesajNo == 2)
        mesaj = fiMesaj2;

    return confirm(mesaj);
}
