function TnsAjaxDDL(ddlID, textID, valueID, reloadAddress) {
    this.ddlID = ddlID;
    this.textID = textID;
    this.valueID = valueID;
    this.reloadAddress = reloadAddress;
    this.ItemChange();
}

TnsAjaxDDL.prototype.ItemChange = function() {
    
    var selectCtrl = document.getElementById(this.ddlID);
    var textCtrl = document.getElementById(this.textID);
    var valueCtrl = document.getElementById(this.valueID);
    if (selectCtrl.selectedIndex > -1) {
        textCtrl.value = selectCtrl.options[selectCtrl.selectedIndex].text;
        valueCtrl.value = selectCtrl.options[selectCtrl.selectedIndex].value;
        //alert(valueCtrl.value+":"+textCtrl.value);
    }
    else {
        textCtrl.value = "";
        valueCtrl.value = "";
    }
}

TnsAjaxDDL.prototype.HTTPCevap = function(param) {

    if (param != null) {
        var selectCtrl = document.getElementById(this.ddlID);
        selectCtrl.options.length = 0;
        if (param.childNodes != null && !isNaN(param.childNodes.length)) {

            for (var i = 0; i < param.childNodes.length; i++) {
                var node = param.childNodes[i];
                selectCtrl.options[i] = new Option(node.getAttribute('text'), node.getAttribute('value'));


            }
            var textCtrl = document.getElementById(this.valueID);

            selectCtrl.value = textCtrl.value;
        }
        selectCtrl.onchange();
    }
}


function HTTPCevap(param, o) {
    o.HTTPCevap(param);
}


TnsAjaxDDL.prototype.Reload = function(param) {
    var httpCagir = new HttpCagir(this.reloadAddress + param, HTTPCevap, this);
}    
