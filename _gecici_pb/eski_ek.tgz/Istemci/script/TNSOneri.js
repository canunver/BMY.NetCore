﻿function CagriDonus(deger, param) {
    param.aramaOnermeyiIsle(deger);
}

function baslar(baslayan, aranan) {
    if (aranan != '' && (baslayan.toString()).indexOf(aranan.toString()) == 0) {
        return false;
    }

    return true;
}

function StringSondanParcaAl(s, u) {
    if (s == null || s == "") return "";
    var l = s.length;
    if (l < u) return "";
    if (l == u) return s;
    return s.substring(l - u);
}

function DivisionResim(strId, strClass, sol, ust, strWidth, strHeight, strInner) {
    var dv = document.getElementById(strId);
    if (dv == null)
        dv = document.createElement('div');
    dv.setAttribute('id', strId);
    if (strClass != null && strClass != "")
        dv.className = strClass;
    dv.innerHTML = strInner;

    dv.style.position = "fixed";
    dv.style.left = sol.toString() + "px";
    dv.style.top = ust.toString() + "px";
    dv.style.width = strWidth;
    dv.style.height = strHeight;
    dv.style.cursor = "pointer";
    dv.style.backgroundColor = "White";
    dv.style.overflow = "hidden";
    dv.style.zIndex = "0";
    return dv;
}

function DivisionListe(strId, strClass) {
    var dv = document.getElementById(strId);
    if (dv == null)
        dv = document.createElement('div');
    dv.setAttribute('id', strId);
    if (strClass != null && strClass != "")
        dv.className = strClass;
    dv.style.cursor = "pointer";
    dv.style.backgroundColor = "White";
    dv.style.overflow = "auto";
    dv.style.borderStyle = "solid";
    dv.style.borderWidth = "1px";
    dv.style.borderColor = "gray";
    dv.style.zIndex = "100";
    dv.style.display = "none";
    dv.style.position = "fixed";
    dv.style.left = "0 px";
    dv.style.top = "0 px";
    return dv;
}

function TnsOneri(nesne_ClientID, txt_ClientID, hf_ClientID, sonucGetirAdres, sonucGetirAdresParametreler, loadingImagePath, tumVeriGoster, etiket) {
    this.nesne_ClientID = nesne_ClientID;
    this.txt_ClientID = txt_ClientID;
    this.imgId = "";
    this.txtControl = document.getElementById(txt_ClientID);
    this.hfControl = document.getElementById(hf_ClientID);
    this.sonucGetirAdres = sonucGetirAdres;

    uzanti = StringSondanParcaAl(this.sonucGetirAdres, 5);
    this.ek = "&";
    if (uzanti == ".aspx" || uzanti == ".html") {
        this.ek = "?";
    }
    else {
        uzanti = StringSondanParcaAl(sonucGetirAdres, 4);
        if (uzanti == ".asp" || uzanti == ".htm") {
            this.ek = "?";
        }
    }

    this.sonucGetirAdresParametreler = sonucGetirAdresParametreler;
    if(baslar(this.sonucGetirAdresParametreler, "param")) this.sonucGetirAdresParametreler += "()";
    this.loadingImagePath = loadingImagePath;
    var ben = this;
    this.etiket = etiket;
    this.oncekiDeger = "";
    this.bulunmayanGirdi = "";
    this.simdikiDegerOriginal = "";
    this.divId = this.txt_ClientID + "_div";
    this.etiketGoster();
    this.txtControl.onblur = function () { if(ben.listede == 0) ben.divGizle(); ben.etiketGoster(); };
    this.txtControl.onkeydown = function () { ben.tusBas(event); };
    this.txtControl.onkeyup = function () { ben.aramaOner(event); };
    this.txtControl.onfocus = function () { ben.etiketKaldir(); return false; };
    this.YerBul();
    this.listeDiv = null;
    this.currentDivId = -1;
    this.maxDivId = -1;
    if (tumVeriGoster == "True") {
        //window.status = "bura";
        this.txtControl.onclick = function () { ben.tumVeriGoster(event); }
    }
}

TnsOneri.prototype.ListeDivOl = function()
{
    if (this.listeDiv == null) {
        var ben = this;
        this.listeDiv = DivisionListe(this.divId, "");
        this.listede = 0;
        this.listeDiv.onfocus = function () { ben.divGoster(); }
        this.listeDiv.onmouseover = function () { ben.listede = 1; };
        this.listeDiv.onmouseout = function () { ben.listede = 0; };

        document.body.appendChild(this.listeDiv);
    }
}
 
TnsOneri.prototype.YerBul = function () {
    this.sol = 0;
    this.ust = 0;
    var obj = this.txtControl;
    if (obj.offsetParent) {
        while (1) {
            this.sol += obj.offsetLeft;
            this.ust += obj.offsetTop;
            if (!obj.offsetParent)
                break;
            obj = obj.offsetParent;
        }
    }
    else if (obj.x) {
        this.sol += obj.x;
        this.ust += obj.y;
    }
}

TnsOneri.prototype.divGizle = function () {
    this.listede = 0;
    this.maxDivId = -1;
    if (this.listeDiv != null) {
        this.listeDiv.innerHTML = "";
        this.listeDiv.style.display = "none";
    }
}

TnsOneri.prototype.divGoster = function () {
    this.ListeDivOl();
    if (this.listeDiv.innerHTML != "")
        this.listeDiv.style.display = "block";
    else
        this.listeDiv.style.display = "none";
}

TnsOneri.prototype.islemYapResmiGizle = function () {
    if (this.imgId != "") {
        var tut = this.imgId;
        this.imgId = "";
        document.body.removeChild(document.getElementById(tut));
    }
}

TnsOneri.prototype.divYenile = function (sHeight, innerHTML) {
    this.ListeDivOl();
    this.YerBul();
    dv = this.listeDiv;
    dv.innerHTML = innerHTML;

    dv.style.position = "fixed";
    dv.style.left = this.sol.toString() + "px";
    dv.style.top = (this.ust + 20).toString() + "px";
    dv.style.width = this.txtControl.offsetWidth.toString() + "px";
    dv.style.height = sHeight;
    dv.style.display = "block";
    dv.scrollTop = 0;
}

TnsOneri.prototype.islemYapResmiGoster = function () {
    this.imgId = this.txt_ClientID + "_img"
    document.body.appendChild(DivisionResim(this.imgId, "", this.sol + this.txtControl.offsetWidth - 18, this.ust + 3, "16px", "16px", "<img src='" + this.loadingImagePath + "' style='position:absolute;width: 16px; height: 16px; z-index=100'/>"));
}

TnsOneri.prototype.tusBas = function (e) {
    var key = window.event ? e.keyCode : e.which;
    if (key == 13 || key == 9) {
        e.keyCode = 9;
        try {
            this.divGizle();
        }
        catch (err) { }
    }
}


TnsOneri.prototype.aramaOner = function (e) {
    var key = window.event ? e.keyCode : e.which;
    //sag veya sol,shift,ctrl,alt ok tuslari basildi ise cik
    if (key == 37 || key == 39 || key == 16 || key == 17 || key == 18)
        return;

    if (key == 40 || key == 38) {
        this.scrollDiv(key);
        return;
    }

    var simdikiDeger = this.txtControl.value;

    //Text kontrolün içerisinde değişiklik yapıldığında önceki değere ait bilgileri sıfırla
    if (simdikiDeger != this.oncekiDeger) {
        this.hfControl.value = "";
        this.oncekiDeger = "";
    }

    if (simdikiDeger == "") {
        this.divGizle();
        return;
    }

    if (simdikiDeger.length > 3) {
        this.simdikiDegerOriginal = simdikiDeger;
        try { simdikiDeger = urlKodla(simdikiDeger); } catch (e) { }

        if (baslar(this.simdikiDegerOriginal, this.bulunmayanGirdi)) {
            this.islemYapResmiGoster();

            //cağıran yerin paramfonksiyonu yazması beklenir.
            var parametreDeger = "";
            try { parametreDeger = eval(this.sonucGetirAdresParametreler); } catch (err) { }
            var adres = this.sonucGetirAdres + this.ek + parametreDeger + "&girdi=" + simdikiDeger;
            var c1 = new HttpCagir(adres, CagriDonus, this);
            delete (c1);
        }
        else {
            this.divGizle();
        }
    }
    else {
        this.divGizle();
    }
}

TnsOneri.prototype.aramaDivOlustur = function (deger) {
    this.bulunmayanGirdi = this.simdikiDegerOriginal;
    if (deger == null || deger == "") {
        this.divGizle();
        return;
    }
    try {
        var str = deger.split("~");
        if (str.length > 1) {
            this.bulunmayanGirdi = "";
            var divValue = "";
            var divValueFirst = "";
            var divValueSecond = "";
            innerHTML = "";
            this.currentDivId = -1;
            this.maxDivId = str.length - 2;
            for (i = 0; i < str.length - 1; i++) {
                try {
                    divValue = str[i].split(";");
                    divValueFirst = divValue[0];
                    divValueSecond = divValue[1];
                }
                catch (e) {
                    divValueFirst = "";
                    divValueSecond = str[i];
                }

                var suggest = '<div nowrap ';
                suggest += 'id=div' + i;
                suggest += ' value="' + divValueFirst + '"';
                suggest += ' onmouseover="javascript:' + this.nesne_ClientID + '.oneriUstu(this);"';
                suggest += ' onmouseout="javascript:' + this.nesne_ClientID + '.oneriDisi(this);"';
                suggest += ' onclick="javascript:' + this.nesne_ClientID + '.aramaAta(this);"';
                suggest += ' class="oneri_satiri">' + divValueSecond + '</div>';
                //alert(suggest);
                innerHTML += suggest;
            }
            if (str.length < 7)
                sHeight = (str.length) * 20 + "px";
            else
                sHeight = "150px";

            this.divYenile(sHeight, innerHTML);
        }
    }
    catch (e) { alert(e); }
}

//Called when the AJAX response is returned.
TnsOneri.prototype.aramaOnermeyiIsle = function (deger) {
    this.aramaDivOlustur(deger);
    this.islemYapResmiGizle();
}

//Mouse over function
TnsOneri.prototype.oneriUstu = function (div) {
    if (div != null) {
        div.className = 'oneri_satiri_secili';
        this.txtControl.value = div.innerHTML;
        this.hfControl.value = div.attributes["value"].nodeValue
        this.oncekiDeger = div.innerHTML;
    }
    else {
        this.txtControl.value = this.simdikiDegerOriginal;
        this.hfControl.value = "";
        this.oncekiDeger = "";
    }
}

//Mouse out function
TnsOneri.prototype.oneriDisi = function (div) {
    div.className = 'oneri_satiri';
}

//Click function
TnsOneri.prototype.aramaAta = function (div) {
    //window.status += "1";
    this.txtControl.value = div.innerHTML;
    this.hfControl.value = div.attributes["value"].nodeValue;
    this.oncekiDeger = div.innerHTML;

    this.divGizle();

    this.txtControl.focus();
    this.txtControl.select();
}

TnsOneri.prototype.tumVeriGoster = function (event) {
    var simdikiDeger = this.txtControl.value;
    this.simdikiDegerOriginal = simdikiDeger;
    try { simdikiDeger = urlKodla(simdikiDeger); } catch (e) { }

    this.islemYapResmiGoster();

    var parametreDeger = "";
    try { parametreDeger = eval(this.sonucGetirAdresParametreler); } catch (err) { }
    var adres = this.sonucGetirAdres + this.ek + parametreDeger + "&girdi=" + simdikiDeger;
    var c1 = new HttpCagir(adres, CagriDonus, this);
    delete (c1);
}

TnsOneri.prototype.scrollDiv = function (key) {
    if (this.maxDivId < 0) return;
    var eskiAktifSatir = this.currentDivId;
    if (key == 40) { //down arrow
        if (this.currentDivId == this.maxDivId)
            this.currentDivId = -1;
        else
            this.currentDivId++;
    }
    else {
        if (this.currentDivId == -1)
            this.currentDivId = this.maxDivId;
        else
            this.currentDivId--;
    }

    if (eskiAktifSatir != -1) {
        this.oneriDisi(document.getElementById('div' + eskiAktifSatir));
    }

    if (this.currentDivId == -1)
        this.oneriUstu(null);
    else {
        var dv = document.getElementById('div' + this.currentDivId);
        this.oneriUstu(dv);
        this.scroll(key, dv);
    }
}

TnsOneri.prototype.scroll = function (key, aktifDiv) {
    if (key == 40) { //down arrow
        if (aktifDiv.offsetTop + aktifDiv.offsetHeight > this.listeDiv.scrollTop + this.listeDiv.offsetHeight) // taştı
        {
            this.listeDiv.scrollTop += aktifDiv.offsetTop + aktifDiv.offsetHeight - this.listeDiv.offsetHeight;
        }
        else if (this.listeDiv.scrollTop > aktifDiv.offsetTop)
            this.listeDiv.scrollTop = aktifDiv.offsetTop;
    }
    else {

        if (this.listeDiv.scrollTop > aktifDiv.offsetTop)
            this.listeDiv.scrollTop = aktifDiv.offsetTop;
        else if (aktifDiv.offsetTop + aktifDiv.offsetHeight > this.listeDiv.scrollTop + this.listeDiv.offsetHeight) // taştı
        {
            this.listeDiv.scrollTop += aktifDiv.offsetTop + aktifDiv.offsetHeight - this.listeDiv.offsetHeight;
        }

    }
}

TnsOneri.prototype.etiketGoster = function () {
    if (this.etiket != "") {
        if (this.txtControl.value == null || this.txtControl.value == "" || this.txtControl.value == this.etiket) {
            this.txtControl.value = this.etiket;
            this.txtControl.style.fontStyle = "italic";
//            this.saklaWeight = this.txtControl.style.fontWeight;
//            this.txtControl.style.fontWeight = "100";
        }
    }
}

TnsOneri.prototype.etiketKaldir = function () {
    if (this.etiket != "") {
        if (this.txtControl.value == this.etiket) {
            this.txtControl.value = "";
            this.txtControl.style.fontStyle = "normal";
//            this.txtControl.style.fontWeight = this.saklaWeight;

            var r = this.txtControl.createTextRange();
            r.moveStart("character", 0);
            r.select();
        }
    }
}