﻿function MaxLength(kontrol, kontrolLbl, maxKarakterSayisi, gorunsunMu) {

    var txt = document.getElementById(kontrol);
    var karakterSayisi = txt.value.length;

    if (gorunsunMu == "1") {
        var lbl = document.getElementById(kontrolLbl);
        lbl.innerHTML = eval(maxKarakterSayisi) - eval(karakterSayisi);
    }

    if (eval(karakterSayisi) >= eval(maxKarakterSayisi)) {
        txt.value = txt.value.substring(0, eval(maxKarakterSayisi));
        if (gorunsunMu == "1")
            lbl.innerHTML = "0";
    } else {
        if (gorunsunMu == "1")
            lbl.innerHTML = eval(maxKarakterSayisi) - eval(karakterSayisi);
    }
}