﻿var datePickerDivID = "datepicker";
var iFrameDivID = "datepickeriframe";
var dayArrayShort = new Array('Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz');
var dayArrayMed = new Array('Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt');
var dayArrayLong = new Array('Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar');
var monthArrayShort = new Array('Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara');
var monthArrayMed = new Array('Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara');
var monthArrayLong = new Array('Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık');
var defaultDateSeparator = ".";
var defaultDateFormat = "dmy";
var dateSeparator = defaultDateSeparator;
var dateFormat = defaultDateFormat;

function displayDatePicker(dateFieldName, displayBelowThisObject, dtFormat, dtSep) {
    var targetDateField = document.getElementsByName(dateFieldName).item(0);
    if (!displayBelowThisObject) displayBelowThisObject = targetDateField;
    if (dtSep) dateSeparator = dtSep;
    else
        dateSeparator = defaultDateSeparator;
    if (dtFormat) dateFormat = dtFormat;
    else
        dateFormat = defaultDateFormat;

    var x, y, parent;
    if (dateFieldName.substring(0, 3) == 'fpL') {
        parent = displayBelowThisObject.GetCellByRowCol(displayBelowThisObject.GetActiveRow(), displayBelowThisObject.GetActiveCol());
        x = parent.offsetLeft;
        y = parent.offsetTop + parent.offsetHeight - document.getElementById(dateFieldName + '_view').scrollTop;

        if (x + 145 > document.body.offsetWidth)
            x = x - 145;
    }
    else {
        parent = displayBelowThisObject;
        x = parent.offsetLeft;
        y = parent.offsetTop + parent.offsetHeight;
    }

    while (parent.offsetParent) {
        parent = parent.offsetParent;
        x += parent.offsetLeft;
        y += parent.offsetTop;
    }

    drawDatePicker(targetDateField, x, y, dateFieldName);
}

function drawDatePicker(targetDateField, x, y, dateFieldName) {
    var dt = getFieldDate(targetDateField.value); if (!document.getElementById(datePickerDivID)) { var newNode = document.createElement("div"); newNode.setAttribute("id", datePickerDivID); newNode.setAttribute("class", "dpDiv"); newNode.setAttribute("style", "visibility: hidden;"); document.body.appendChild(newNode); } var pickerDiv = document.getElementById(datePickerDivID); pickerDiv.style.position = "absolute"; pickerDiv.style.left = x + "px"; pickerDiv.style.top = y + "px"; pickerDiv.style.visibility = (pickerDiv.style.visibility == "visible" ? "hidden" : "visible"); pickerDiv.style.display = (pickerDiv.style.display == "block" ? "none" : "block"); pickerDiv.style.zIndex = 10000;
    refreshDatePicker(dateFieldName, dt.getFullYear(), dt.getMonth(), dt.getDate());
}

function refreshDatePicker(dateFieldName, year, month, day) {
    var thisDay = new Date();
    if ((month >= 0) && (year > 0)) { thisDay = new Date(year, month, 1); } else { day = thisDay.getDate(); thisDay.setDate(1); }
    var crlf = "\r\n";
    var TABLE = "<table cols=7 class='dpTable'>" + crlf; var xTABLE = "</table>" + crlf; var TR = "<tr class='dpTR'>"; var TR_title = "<tr class='dpTitleTR'>"; var TR_days = "<tr class='dpDayTR'>"; var TR_todaybutton = "<tr class='dpTodayButtonTR'>"; var xTR = "</tr>" + crlf; var TD = "<td class='dpTD' onMouseOut='this.className=\"dpTD\";' onMouseOver=' this.className=\"dpTDHover\";' "; var TD_title = "<td colspan=5 class='dpTitleTD'>"; var TD_buttons = "<td class='dpButtonTD'>"; var TD_todaybutton = "<td colspan=7 class='dpTodayButtonTD'>"; var TD_days = "<td class='dpDayTD'>"; var TD_selected = "<td class='dpDayHighlightTD' onMouseOut='this.className=\"dpDayHighlightTD\";' onMouseOver='this.className=\"dpTDHover\";' "; var xTD = "</td>" + crlf; var DIV_title = "<div class='dpTitleText'>"; var DIV_selected = "<div class='dpDayHighlight'>"; var xDIV = "</div>"; var html = TABLE; html += TR_title; html += TD_buttons + getButtonCode(dateFieldName, thisDay, -1, "&lt;") + xTD; html += TD_title + DIV_title + monthArrayLong[thisDay.getMonth()] + " " + thisDay.getFullYear() + xDIV + xTD; html += TD_buttons + getButtonCode(dateFieldName, thisDay, 1, "&gt;") + xTD; html += xTR; html += TR_days; for (i = 0; i < dayArrayShort.length; i++) html += TD_days + dayArrayShort[i] + xTD; html += xTR; html += TR; for (i = 1; i < thisDay.getDay(); i++) html += TD + "&nbsp;" + xTD; do {
        dayNum = thisDay.getDate(); TD_onclick = " onclick=\"updateDateField('" + dateFieldName + "', '" + getDateString(thisDay) + "');\">"; if (dayNum == day) html += TD_selected + TD_onclick + DIV_selected + dayNum + xDIV + xTD; else
            html += TD + TD_onclick + dayNum + xTD; if (thisDay.getDay() == 0) html += xTR + TR; thisDay.setDate(thisDay.getDate() + 1);
    } while (thisDay.getDate() > 1)if (thisDay.getDay() > 0) { for (i = 6; i > thisDay.getDay(); i--) html += TD + "&nbsp;" + xTD; } html += xTR; var today = new Date(); var todayString = "Today is " + dayArrayMed[today.getDay()] + ", " + monthArrayMed[today.getMonth()] + " " + today.getDate(); html += TR_todaybutton + TD_todaybutton; html += "<button class='dpTodayButton' onClick='refreshDatePicker(\"" + dateFieldName + "\");'>Bugün</button> "; html += "<button class='dpTodayButton' onClick='updateDateField(\"" + dateFieldName + "\");'>Kapat</button>"; html += xTD + xTR; html += xTABLE; document.getElementById(datePickerDivID).innerHTML = html; adjustiFrame();
}

function getButtonCode(dateFieldName, dateVal, adjust, label) {
    var newMonth = (dateVal.getMonth() + adjust) % 12; var newYear = dateVal.getFullYear() + parseInt((dateVal.getMonth() + adjust) / 12); if (newMonth < 0) { newMonth += 12; newYear += -1; } return "<button class='dpButton' onClick='refreshDatePicker(\"" + dateFieldName + "\", " + newYear + ", " + newMonth + ");'>" + label + "</button>";
}

function getDateString(dateVal) { var dayString = "00" + dateVal.getDate(); var monthString = "00" + (dateVal.getMonth() + 1); dayString = dayString.substring(dayString.length - 2); monthString = monthString.substring(monthString.length - 2); switch (dateFormat) { case "dmy": return dayString + dateSeparator + monthString + dateSeparator + dateVal.getFullYear(); case "ymd": return dateVal.getFullYear() + dateSeparator + monthString + dateSeparator + dayString; case "mdy": default: return monthString + dateSeparator + dayString + dateSeparator + dateVal.getFullYear(); } }

function getFieldDate(dateString) { var dateVal; var dArray; var d, m, y; try { dArray = splitDateString(dateString); if (dArray) { switch (dateFormat) { case "dmy": d = parseInt(dArray[0], 10); m = parseInt(dArray[1], 10) - 1; y = parseInt(dArray[2], 10); break; case "ymd": d = parseInt(dArray[2], 10); m = parseInt(dArray[1], 10) - 1; y = parseInt(dArray[0], 10); break; case "mdy": default: d = parseInt(dArray[1], 10); m = parseInt(dArray[0], 10) - 1; y = parseInt(dArray[2], 10); break; } dateVal = new Date(y, m, d); } else if (dateString) { dateVal = new Date(dateString); } else { dateVal = new Date(); } } catch (e) { dateVal = new Date(); } return dateVal; }

function splitDateString(dateString) {
    var dArray; if (dateString.indexOf("/") >= 0) dArray = dateString.split("/"); else if (dateString.indexOf(".") >= 0) dArray = dateString.split("."); else if (dateString.indexOf("-") >= 0) dArray = dateString.split("-"); else if (dateString.indexOf("\\") >= 0) dArray = dateString.split("\\"); else
        dArray = false; return dArray;
}

function updateDateField(dateFieldName, dateString) {
    var targetDateField = document.getElementsByName(dateFieldName).item(0);
    if (dateString) {
        if (dateFieldName.substring(0, 3) == 'fpL') {
            targetDateField.SetValue(targetDateField.GetActiveRow(), targetDateField.GetActiveCol() - 1, dateString, true);
        }
        else targetDateField.value = dateString;
    }
    var pickerDiv = document.getElementById(datePickerDivID); pickerDiv.style.visibility = "hidden"; pickerDiv.style.display = "none"; adjustiFrame(); targetDateField.focus(); if ((dateString) && (typeof (datePickerClosed) == "function")) datePickerClosed(targetDateField);
}

function adjustiFrame(pickerDiv, iFrameDiv) {
    var is_opera = (navigator.userAgent.toLowerCase().indexOf("opera") != -1); if (is_opera) return; try { if (!document.getElementById(iFrameDivID)) { var newNode = document.createElement("iFrame"); newNode.setAttribute("id", iFrameDivID); newNode.setAttribute("src", "javascript:false;"); newNode.setAttribute("scrolling", "no"); newNode.setAttribute("frameborder", "0"); document.body.appendChild(newNode); } if (!pickerDiv) pickerDiv = document.getElementById(datePickerDivID); if (!iFrameDiv) iFrameDiv = document.getElementById(iFrameDivID); try { iFrameDiv.style.position = "absolute"; iFrameDiv.style.width = pickerDiv.offsetWidth; iFrameDiv.style.height = pickerDiv.offsetHeight; iFrameDiv.style.top = pickerDiv.style.top; iFrameDiv.style.left = pickerDiv.style.left; iFrameDiv.style.zIndex = pickerDiv.style.zIndex - 1; iFrameDiv.style.visibility = pickerDiv.style.visibility; iFrameDiv.style.display = pickerDiv.style.display; } catch (e) { } } catch (ee) { }
}