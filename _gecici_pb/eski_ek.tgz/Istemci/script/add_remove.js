﻿function hepsini_sec_listbox(kaynak) {
  	for(var i=0; i<kaynak.options.length; i++)
      kaynak.options[i].selected=true;
}

function hepsini_sec(kaynak) {
	hepsini_sec_listbox(document.forms[0].elements[kaynak]);
}

function listeye_ekle(kaynak,hedef,maxAktarilacak){
	if (maxAktarilacak<1)
		maxAktarilacak=99999;
	liste_islem(document.forms[0].elements[kaynak],document.forms[0].elements[hedef],maxAktarilacak);
}

function listeden_cikart(kaynak,hedef){
	liste_islem(document.forms[0].elements[hedef],document.forms[0].elements[kaynak],99999);
}

function liste_islem(kaynak,hedef,maxAktarilacak) {
	if (kaynak.options.selectedIndex=="-1")
	{
		alert('Lutfen ilk once aktarmak istediginiz degeri secin.');
		return;
	}
	
  	for(var i=0;i<kaynak.options.length;i++)
  	{
		if (kaynak.options[i].selected) 
		{
			var j=hedef.options.length;
			if ((maxAktarilacak-1)>=j)
			{
				hedef.options[hedef.options.length]=new Option(kaynak.options[i].text,kaynak.options[i].value);
				kaynak.options[i]=null;
				i=-1;
			}
			else
			{
				alert("Secim yapilacak deger sayisi maksimum "+maxAktarilacak+" adetten fazla olamaz.");
				return;
			}
		}
  	}
}

function listeye_ekle_sayfa(kaynak,adAlan,degerAlan){
	var element = document.forms[0].elements[kaynak];
	var intLen = element.options.length;
	var deger="";

	if (!element)
		return;
		
	rFrame = window.opener;
	rFrameDoc = rFrame.document;
	var rSel = rFrameDoc.getElementById(adAlan);
	rSel.length=0;
	rFrameDoc.getElementById(degerAlan).value = "";
	
	if (intLen>0)
	{
		if (rSel)
		{
			try
			{
			    rSel.options.length=0;
    			
			    for (var i = 0; i < intLen; ++i)
			    {
				    var oOption = rFrameDoc.createElement("OPTION");
				    oOption.text=element.options[i].text;
				    oOption.value=element.options[i].value;
				    deger+=element.options[i].value+";";
				    rSel.options.add(oOption,rSel.length);
			    }
				rFrameDoc.getElementById(degerAlan).value = deger;
			}
			catch (e)
			{
			    ad=element.options[0].text;
			    deger=element.options[0].value;

			    rFrameDoc.getElementById(degerAlan).value = deger;
			    
                if (adAlan.substr(0,3)=="txt")
                    rSel.value=ad;
                else
    			    rSel.innerHTML=ad;
			}
		}
	}
}

function hedef_liste_olustur(kaynak,hedef,degerlerAlan) {
	var element = document.forms[0].elements[kaynak];
	var intLen = element.options.length;
	var eklemeYapildi=false;

	if (!element)
		return;
		
	rFrame = window.opener;
	rFrameDoc = rFrame.document;
	var rSel = rFrameDoc.getElementById(degerlerAlan);
	var degerler=rSel.value;
	var deger=degerler.split(';');

	if (intLen>0 && deger.length>0)
	{
		for (var i = 0; i < intLen; ++i)
		{
			for (var j=0;j<deger.length-1;j++)
			{
				if (element.options[i].value==deger[j])
				{
					element.options[i].selected=true;
					eklemeYapildi = true;
					deger[j] = "";			
				}
			}
    }
    for (var j = 0; j < deger.length - 1; j++) {
        if (deger[j] == "") continue;
        var hlist = document.forms[0].elements[hedef];
        hlist.options[hlist.options.length] = new Option(deger[j], deger[j]);
    }

	if (eklemeYapildi)
		listeye_ekle(kaynak,hedef,99999);
	}
}

function hedef_liste_olustur_listeden(kaynak, hedef)
{
    for(var i=0; i<kaynak.options.length; i++)
    {
	    var oOption = document.createElement("OPTION");
	    oOption.text=kaynak.options[i].text;
	    oOption.value=kaynak.options[i].value;
	    hedef.options.add(oOption,hedef.options.length);
    }
}

function listeye_ekle_tree() {
	var index=-1;
	var kaynak=document.getElementById(lstDest);

	for (var i=0; i<trwListe.AllNodes.length; i++)
	{
		if (trwListe.AllNodes[i].Selected == true)
		{
			if (trwListe.AllNodes[i].Text=="Oranlar")
			{
				var deger="";
				var baslik="";
				
				var Degoran=document.getElementById('ddlOran').options[document.getElementById('ddlOran').selectedIndex].value;
				var DegoranAd=document.getElementById('txtOranAd').value;
				var DegalanX=document.getElementById('ddlAlanX').options[document.getElementById('ddlAlanX').selectedIndex].value;
				var DegalanY=document.getElementById('ddlAlanY').options[document.getElementById('ddlAlanY').selectedIndex].value;
				
				var Adoran=document.getElementById('ddlOran').options[document.getElementById('ddlOran').selectedIndex].text;
				var AdoranAd=document.getElementById('txtOranAd').value;
				var AdalanX=document.getElementById('ddlAlanX').options[document.getElementById('ddlAlanX').selectedIndex].text;
				var AdalanY=document.getElementById('ddlAlanY').options[document.getElementById('ddlAlanY').selectedIndex].text;

				deger=Degoran +";"+ DegoranAd +";"+ DegalanX +";"+ DegalanY +";";
				baslik=AdoranAd;
			
				kaynak.options[kaynak.options.length]=new Option(baslik,deger);
			}
			else if (trwListe.AllNodes[i].Value!="")
			{
				kaynak.options[kaynak.options.length]=new Option(trwListe.AllNodes[i].Text,trwListe.AllNodes[i].Value);
				document.getElementById('ddlAlanX').options[kaynak.options.length-1]=new Option(trwListe.AllNodes[i].Text,trwListe.AllNodes[i].Value);
				document.getElementById('ddlAlanY').options[kaynak.options.length-1]=new Option(trwListe.AllNodes[i].Text,trwListe.AllNodes[i].Value);
			}
			else
				alert('Listeye eklenecek sütun bilgisi için bu bölümün detayındaki bilgilerden bir tanesini seçmeniz gerekmektedir.');
			index=i;
			break;
		}
	}
	
	if (index==-1)
	{
		alert('Lütfen ilk önce aktarmak istediğiniz değeri seçin.');
		return;
	}
}

function listeden_cikart_tree() {
	var deger=0;
	var kaynak=document.getElementById(lstDest);

	if (kaynak.options.selectedIndex=="-1")
	{
		alert('Lütfen ilk önce çıkartmak istediğiniz değeri seçin.');
		return;
	}
	
  	for(var i=0;i<kaynak.options.length;i++)
  	{
		if (kaynak.options[i].selected) 
		{
			deger=kaynak.options[i].value;
			kaynak.options[i]=null;

  			for(var j=0;j<kaynak.options.length;j++)
  			{
				if (kaynak.options[j].value.indexOf(";"+deger)>0)
					kaynak.options[j]=null;
  			}
			i=-1;

			kaynak1=document.getElementById('ddlAlanX');
  			for(var j=0;j<kaynak1.options.length;j++)
  			{
				if (kaynak1.options[j].value==deger) 
				{
					kaynak1.options[j]=null;
					j=-1;
				}
			}

			kaynak1=document.getElementById('ddlAlanY');
  			for(var j=0;j<kaynak1.options.length;j++)
  			{
				if (kaynak1.options[j].value==deger) 
				{
					kaynak1.options[j]=null;
					j=-1;
				}
  			}
		}
	}
}

function listeyeEkleKodAd(hedef, kod, ad, yon) {
   var ekleYer = 0;
   if(yon != 2) 
      ekleYer = hedef.options.length;
      
   for(var j=0; j<hedef.options.length; j++) {
      if (hedef.options[j].selected) {
         hedef.options[j].selected = false;
         if(yon != 2) 
            ekleYer = j + 1;
         else
            ekleYer = j - 1;
         break;
      }
   }
      
   var oOption = document.createElement("OPTION");
   oOption.text = ad;
   oOption.value = kod;
   oOption.selected = true;
   hedef.options.add(oOption, ekleYer);
}

function YerDegistir(islemListe, tasinacak, yeniYer)
{
   var tut = islemListe.options[tasinacak];
   var oOption = document.createElement("OPTION");

   oOption.text = tut.text;
   oOption.value = tut.value;
   oOption.selected = tut.selected;

   islemListe.removeChild(tut);
   islemListe.options.add(oOption, yeniYer);
}

function listede_yukari(islemListe)
{
   //İlk seçili olmayanı bul
   var ilkSeciliOlmayan = -1;
   for(var j=0; j<islemListe.options.length; j++) {
      if (islemListe.options[j].selected == false) {
         ilkSeciliOlmayan = j;
         break;
      }
   }
   if(ilkSeciliOlmayan == -1) return;
   
   for(var j=ilkSeciliOlmayan + 1; j<islemListe.options.length; j++) {
      if (islemListe.options[j].selected) {
         YerDegistir(islemListe, j, j-1);
      }
   }
}

function listede_asagi(islemListe)
{
   //İlk seçili olmayanı bul
   var sonSeciliOlmayan = -1;
   for(var j=islemListe.options.length - 1; j >= 0; j--) {
      if (islemListe.options[j].selected == false) {
         sonSeciliOlmayan = j;
         break;
      }
   }
   if(sonSeciliOlmayan == -1) return;
   
   for(var j=sonSeciliOlmayan - 1; j>=0; j--) {
      if (islemListe.options[j].selected) {
         YerDegistir(islemListe, j, j+1);
      }
   }
}

function listeden_sil(islemListe)
{
   for(var j=0; j<islemListe.options.length; j++) {
      if (islemListe.options[j].selected) {
           var tut = islemListe.options[j];
           islemListe.removeChild(tut);
           j--;
      }
   }
}