﻿// Tablolarla ilgili işlemler - Bu bölümü Ortak'a taşı
function FPCellDegerYaz(kontrol, row, col, deger, noEvent) {
    var hucre = kontrol.GetCellByRowCol(row, col);
    if (hucre) {
        var durum = hucre.getAttribute("FpCellType");
        hucre.removeAttribute("FpCellType");
        kontrol.SetValue(row, col, deger, noEvent);
        if (durum != "")
            hucre.setAttribute("FpCellType", durum);
    }
}

function tabloBul(tabloId) {
    return document.getElementById(tabloId);
}

function satirBul(tablo, satirNo) {
    return tablo.rows[satirNo];
}

function hucreBul(satir, sutunNo) {
    return satir.cells[sutunNo];
}

function hucreDegerBul(hucre) {
    return hucre.innerText;
}

function hucreDegerAta(hucre, deger) {
    hucre.innerText = deger;
}

function FPKolonBaslikDegerAta(control, row, col, deger) {
    var span = document.getElementById(control.id + "_" + "colHeader");
    var tablo = span.firstChild;
    hucreDegerAta(hucreBul(satirBul(tablo, row), col), deger)
}

function FPKolonBaslikDegerAl(control, row, col) {
    var span = document.getElementById(control.id + "_" + "colHeader");
    var tablo = span.firstChild;

    return hucreDegerBul(hucreBul(satirBul(tablo, row), col));
}



/* Farpoint HeaderCheckBox */
function FpLCheckBoxSelectAll(id, e, topla) {
    CheckBoxSelectAllByParent(id, e); if (topla) { FpLSelectTopla(id); }
}
/* Farpoint RowCheckBox */
function FpLCheckBoxSelectTopla(e) {
    var list = e.id.split('_'); if (list.length > 1) { FpLSelectTopla(list[0]); }
}

/* Satır Toplam Hesapla */
function FpLSelectTopla(id) {
    var fpL = document.getElementById(id); if (fpL == null) return;
    var colCount = fpL.GetColCount();
    var startCol = 2;
    var colHeaderIndex = 2;
    var colValue = new Array();
    var colValueToplam = new Array();
    var tmpValue;

    /*Sayfa Toplam Başla*/
    var span = document.getElementById(id + "_colHeader");
    var table = span.firstChild;
    var tr = table.rows(colHeaderIndex);

    for (var j = startCol; j < colCount; j++) {
        tr.cells(j - startCol + 1).innerText = "";
    }

    var list = fpL.getElementsByTagName('input');
    for (var i = 1; i < list.length; i++) {
        if ((list[i].type == 'checkbox') && (!list[i].disabled)) {
            if (list[i].checked) {
                for (var j = startCol; j < colCount; j++) {
                    colValue[j - startCol] = myParseFloat(MyReplace(fpL.GetValue(i - 1, j), '.', ''));
                    colValueToplam[j - startCol] = myParseFloat(MyReplace(tr.cells(j - startCol + 1).innerText, '.', ''));
                    colValueToplam[j - startCol] = colValueToplam[j - startCol] + colValue[j - startCol];
                    tr.cells(j - startCol + 1).innerText = CurrencyFormatted(colValueToplam[j - startCol]);
                }
            }
        }
    }

}

/* Farpoint : Satır içinde bulunan 'a href click' işlemi yapar. Hüseyin*/
function FpLRowAClick(control, row, col) {
    var rowElement = control.GetCellByRowCol(row, col);
    if (rowElement != null) {
        var a = rowElement.getElementsByTagName('a');
        if (a != null && a.length == 1) { a[0].click(); }
    }
}
/* Farpoint : işlem türüne göre sonraki(islem=1) veya önceki(islem=-1) satır seçimi yapar. Satırda link varsa 'a href click' işlemi yapar. Hüseyin*/
function FpLSonrakiOnceki(FpLid, islem) {
    var control = document.getElementById(FpLid);
    var rowCount = control.GetRowCount();
    var row = control.GetActiveRow();
    if ((islem == 1 && row < rowCount - 1) || (islem == -1 && row > 0)) {
        if (row == -1) { row = 0; }
        row = row + islem;
        control.SetActiveCell(row, 0);
        FpLRowAClick(control, row, 1);
    }
}

/* Farpoint : Checkbox (Column[0]) seçili olan satırları siler Hüseyin*/
function FpLChkSelectRowDelete(FpLid) {
    var control = document.getElementById(FpLid);
    var rowCount = control.GetRowCount();
    var rowElement;
    var inputs;
    var deleteIndexList = "";
    for (var i = 0; i < rowCount; i++) {
        rowElement = control.GetCellByRowCol(i, 0);
        inputs = rowElement.getElementsByTagName('input');
        if (inputs != null && inputs.length == 1) {
            if ((inputs[0].type == 'checkbox') && (!inputs[0].disabled) && (inputs[0].checked)) {
                deleteIndexList = deleteIndexList + i + "_";
            }
        }
    }
    var msg1 = "Seçili satırlar listeden silinecektir. Bu işlemi onaylıyormusunuz?";
    var msg2 = "Seçili satır bulunanmadı. \nLütfen silmek istediğiniz satırları listeden seçiniz.";
    if (deleteIndexList != "") {
        if (confirm(msg1)) {
            control.CallBack(control.id + ".satirsil_" + deleteIndexList);
            return true;
        }
    }
    else {
        alert(msg2);
    }
    return false;
}

function AktifRowControl(control) {
    if (control.GetActiveRow() == -1)
        control.SetActiveCell(0, 1);
}

function FPHucreLinkClick(control, sat, sut) {
    var td = control.GetCellByRowCol(sat, sut);
    td.firstChild.click();

}

function AktifRowDegisti(control) {
    AktifRowControl(control);
    var sat = control.GetActiveRow();
    var sut = 1;
    FPHucreLinkClick(control, sat, sut);
}

function AktifRowIslem(control, say) {
    AktifRowControl(control);
    var sat = control.GetActiveRow();
    sat = sat + say;
    var satSay = control.RowCount;
    if (sat >= satSay)
        sat = 0;
    else if (sat < 0)
        sat = satSay - 1;

    control.SetActiveCell(sat, 1);
    AktifRowDegisti(control);
}

function Onceki(control) {
    AktifRowIslem(control, -1);
}

function Sonraki(control) {
    AktifRowIslem(control, 1);
}

function Simdiki(control) {
    AktifRowIslem(control, 0);
}

/* Farpoint : kod ve ad bilgilerine sahip Farpoint listesini kişiselleştirme işlemi yapar. */
function FpLListeSekli(fpLid, value) {
    var hdnFpLListeSekli = document.getElementById('hdnFpLListeSekli'); if (hdnFpLListeSekli != null) { hdnFpLListeSekli.value = value; }
    var control = document.getElementById(fpLid);
    control.CallBack('FpLListeSekli' + '!' + value);
}
/* Farpoint : Farpoint listesini temizler. */
function FpLTemizle(fpLid) {
    var control = document.getElementById(fpLid);
    control.CallBack('FpLTemizle');
}
/* Farpoint : Farpoint listesine bos satır ekler. value=eklenecekSatirSayısı */
function FpLSatirEkle(fpLid, value) {
    var control = document.getElementById(fpLid);
    control.CallBack('FpLSatirEkle' + '!' + value);
}

function FPDegerAta(kontrol, sat, sut, deger, virgulle, sonParam) {
    var hucre = kontrol.GetCellByRowCol(sat, sut);
    var durum = hucre.getAttribute("FpCellType");
    hucre.removeAttribute("FpCellType");

    if (virgulle)
        deger = ParaNoktala(deger.toString());
    if (sonParam == undefined || sonParam == null) sonParam = true;
    kontrol.SetValue(sat, sut, deger, sonParam);
}