﻿function NullSifir(deger) {
    if (deger) return deger;
    return 0;
}

// Değeri integer'a dönüştüren yardımcı fonksiyon
function IntYap(value, defaultValue = 0) {
    var parsed = parseInt(value, 10);
    return isNaN(parsed) ? defaultValue : parsed;
}

function parseFloatTR(value, ek) {
    if (ek) {
        console.log(ek + ": " + value);
    }
    if (typeof value === "number") return value; // Eğer zaten sayıysa direkt döndür
    if (!value) return 0;
    let degisen = value.replace(/\./g, "").replace(",", ".");
    if (ek) {
        console.log(ek + ": " + degisen);
    }
    return parseFloat(degisen);
}

function formatTarih(gelenTarih) {
    if (!gelenTarih || !(gelenTarih instanceof Date) || isNaN(gelenTarih.getTime())) {
        return '';
    }

    var gun = gelenTarih.getDate().toString().padStart(2, '0');
    var ay = (gelenTarih.getMonth() + 1).toString().padStart(2, '0');
    var yil = gelenTarih.getFullYear();

    return gun + '/' + ay + '/' + yil;
}

function formatTarihYMD(gelenTarih) {
    if (!gelenTarih || !(gelenTarih instanceof Date) || isNaN(gelenTarih.getTime())) {
        return '';
    }

    var gun = gelenTarih.getDate().toString().padStart(2, '0');
    var ay = (gelenTarih.getMonth() + 1).toString().padStart(2, '0');
    var yil = gelenTarih.getFullYear();

    return yil + '-' + ay + '-' + gun;
}
function formatNumberTNS(gelenDeger, fracDig) {
    if (fracDig === undefined || fracDig === null) fracDig = 2;
    if (gelenDeger == undefined || gelenDeger == null) return "";
    if (typeof gelenDeger === "number") {
        var fls = gelenDeger.toLocaleString("tr-TR", { minimumFractionDigits: fracDig, maximumFractionDigits: fracDig });
        return fls;
    }

    var value = gelenDeger.replace(/\./g, "").replace(",", ".");
    if (!isNaN(value) && value !== "") {
        var fl = parseFloat(value);
        var fls = fl.toLocaleString("tr-TR", { minimumFractionDigits: fracDig, maximumFractionDigits: fracDig });
        return fls;
    }
    else
        return gelenDeger;
    ;
}

function formatNumber(gelenDeger, fracDig) {
    return formatNumberTNS(gelenDeger, fracDig);
}

// Select2 bileşenlerini temizleyip yeni veriyi ekleyerek güncelleyen fonksiyon
function updateSelect2(selector, kod, ad) {
    var $select = $(selector);
    $select.empty();
    if (ad) {
        var newOption = new Option(ad, kod, true, true);
        $select.append(newOption);
        $select.val(kod).trigger('change');
    }
}

// Tarih formatlama fonksiyonu (yyyy-MM-dd)
function formatDate(dateStr) {
    if (!dateStr) return "";
    return dateStr.split("T")[0]; // Tarih kısmını al
}

function select2Tercume() {
    return {
        noResults: function () {
            return "Sonuç bulunamadı";
        },
        inputTooShort: function () {
            return "Lütfen daha fazla karakter giriniz";
        },
        searching: function () {
            return "Aranıyor...";
        },
        loadingMore: function () {
            return "Daha fazla sonuç yükleniyor...";
        },
        errorLoading: function () {
            return "Sonuç yüklenirken hata oluştu!";
        },
    };
}

function toJsonDate(dateStr) {
    if (!dateStr) return null;

    var dt = new Date(dateStr);
    if (isNaN(dt.getTime())) return null;

    return "/Date(" + dt.getTime() + ")/";
}

function parseJsonDateTNS(tnsDate) {
    if (!tnsDate) return "";
    return tnsDate.Yil + '-' +
        String(tnsDate.Ay).padStart(2, '0') + '-' +
        String(tnsDate.Gun).padStart(2, '0');
}

let gunler = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
function GunAdBul(dt) {
    let day = dt.getDay();
    return gunler[day];
}

function parseJsonDateDT(jsonDate) {
    if (!jsonDate) return new Date();
    var timestamp = parseInt(jsonDate.replace(/\/Date\((\d+)\)\//, "$1"), 10);
    // DateTime.MinValue kontrolü (0001-01-01)
    if (!timestamp || timestamp === -62135596800000) {
        return new Date(); // Boş tarih olarak döndür
    }
    var dateObj = new Date(timestamp);
    return dateObj;
}

function parseJsonDate(jsonDate) {
    var dateObj = parseJsonDateDT(jsonDate);
    return dateObj.getFullYear() + '-' +
        String(dateObj.getMonth() + 1).padStart(2, '0') + '-' +
        String(dateObj.getDate()).padStart(2, '0');
}

function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var d = new Date();
        d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + d.toUTCString();
    }
    document.cookie = name + "=" + encodeURIComponent(value) + expires + "; path=/; SameSite=Lax";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
    return null;
}

function ListeleriOlustur(url, tip, $sel) {
    var kodlar = $.ajax({
        url: url,
        method: 'POST',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        data: JSON.stringify({ tip: tip }),
        success: function (res) {
            $sel.empty();
            $sel.append($('<option>', { value: '', text: 'Seçiniz...' }));
            (res.d.objeler || []).forEach(function (x) {
                $sel.append($('<option>', { value: x.kod, text: x.ad }));
            });
        }
    });
}

function getInt(val) {
    var s = (val == null ? "" : String(val)).trim();
    if (s === "") return 0;
    var n = parseInt(s, 10);
    return isNaN(n) ? 0 : n;
}

function ajaxErrAlert(xhr) {
    MesajKutusu("Sunucu hatası", (xhr.responseText || xhr.statusText));
}

var extKontrol = null;

function csrfTokenGetir() {
    var el = document.getElementsByName("genelSayfaFormId");
    if (el && el.length > 0 && el[0].value)
        return el[0].value;

    // 2) Meta tag (form yoksa buradan)
    var meta = document.querySelector('meta[name="genelSayfaFormId"]');
    if (meta) return meta.getAttribute("content") || "";

    return "";
}

function extTokenEkle(cfg) {
    cfg = cfg || {};
    var token = csrfTokenGetir();
    if (!token) return cfg;

    // 1) Header (en temiz)
    cfg.headers = cfg.headers || {};
    cfg.headers["X-CSRF-Token"] = token;

    // 2) Params (bazı Ext.NET sürümlerinde daha garanti)
    cfg.params = cfg.params || {};
    if (!cfg.params.genelSayfaFormId) cfg.params.genelSayfaFormId = token;

    return cfg;
}

function csrfBeforeSend(xhr, settings) {
    try {
        // Sadece aynı origin istekleri
        if (settings.url && settings.url.indexOf("http") !== 0) {
            var token = csrfTokenGetir();
            if (token)
                xhr.setRequestHeader("X-CSRF-Token", token);
        }
    } catch (e) { }
}

$(document).ready(function () {
    try {
        if (eval("Ext1") != null) {
            extKontrol = Ext1;
            extKontrol.isExt1 = true;
            extKontrol.isExt3 = false;
        }
        else {
            extKontrol = Ext;
            extKontrol.isExt1 = false;
            extKontrol.isExt3 = true;
        }
    } catch (e) {
        extKontrol = Ext;
        extKontrol.isExt1 = false;
        extKontrol.isExt3 = true;
    }


    try {
        if (window.jQuery) {
            $.ajaxSetup({
                beforeSend: function (xhr, settings) {
                    csrfBeforeSend(xhr, settings);
                }
            });
        }
    }
    catch { }
});

function GridElemanBul(kontrol, onceki, secili, ayrac) {
    var chk;
    var parcali1;
    var parcali2;
    var objeSayisi = 0;
    var i = 0;
    for (i = 1; i < kontrol.rows.length; i++) {
        chk = kontrol.rows[i].cells[0].childNodes[0].name;
        if (chk && chk.indexOf(ayrac) != -1) {
            parcali1 = secili.split(ayrac);
            parcali2 = chk.split(ayrac);
            if (parcali1[0] == parcali2[0])
                objeSayisi += 1;
        }
    }

    var bulunan = -1;
    for (i = 1; i <= objeSayisi; i++) {
        if (kontrol.rows[i].cells[0].childNodes[0].name == secili) {
            bulunan = i;
            break;
        }
    }

    if (onceki && bulunan > 1)
        bulunan -= 1;
    else if (onceki && bulunan == 1)
        bulunan = objeSayisi;
    else if (!onceki && bulunan < objeSayisi)
        bulunan += 1;
    else if (!onceki && bulunan == objeSayisi)
        bulunan = 1;

    if (bulunan != -1)
        return kontrol.rows[bulunan].cells[0].childNodes[0].name;
    else
        return kontrol.rows[1].cells[0].childNodes[0].name;
}

function OncekiEleman(kontrolID, seciliID, ayrac) {
    return GridElemanBul(document.getElementById(kontrolID), true, document.getElementById(seciliID).value, ayrac);
}

function SonrakiEleman(kontrolID, seciliID, ayrac) {
    return GridElemanBul(document.getElementById(kontrolID), false, document.getElementById(seciliID).value, ayrac);
}

function ListeSec(kontrol) {
    if (kontrol) {
        secim = kontrol.rows[0].cells[0].childNodes[0].checked;
        for (var i = 1; i < kontrol.rows.length; i++) {
            kontrol.rows[i].cells[0].childNodes[0].checked = secim;
        }
    }
}

function BelgeYazdirKapat() {
    if (window.yardimSay > 0) {
        for (var i = 0; i < window.yardimSay; i++) {
            if (window.yardimSayfaAd[i].indexOf("BelgeYazdir.aspx") > -1) {
                try { window.yardimSayfa[i].close(); }
                catch (Err) { }
            }
        }
    }
}

function KillEnter() {
    if (window.event.keyCode == 13)
        window.event.keyCode = 0;
}

function BelgeOnayAl(islemTip) {
    var mesaj = "";
    var belgeNo = "";

    if (islemTip == "Kaydet") {
        try {
            belgeNo = "YOK";
            belgeNo = document.getElementById('txtBelgeNo').value;
        }
        catch (e) { }

        if (belgeNo == "YOK")
            mesaj = res_JSGEN001;
        else if (belgeNo == "")
            mesaj = res_JSGEN002;
        else
            mesaj = StrFormat(res_JSGEN003, belgeNo);
    }
    else if (islemTip == "İptal")
        mesaj = res_JSGEN004;
    else if (islemTip == "Arsiv")
        mesaj = res_JSGEN005;
    else if (islemTip == "OnayKaldir")
        mesaj = res_JSGEN006;
    else if (islemTip == "Onay")
        mesaj = res_JSGEN007;
    else if (islemTip == "OnayTek")
        mesaj = res_JSGEN008;
    else if (islemTip == "OnayTekKaldir")
        mesaj = res_JSGEN009;
    else if (islemTip == "YevmiyeNoKaldir")
        mesaj = res_JSGEN010;
    else if (islemTip == "YevmiyeNoVer")
        mesaj = res_JSGEN011;
    else if (islemTip == "HızlıKaydet")
        mesaj = res_JSGEN012;
    else if (islemTip == "HızlıKontrol")
        mesaj = res_JSGEN013;
    else if (islemTip == "HızlıKontrolKaydet")
        mesaj = res_JSGEN014;
    else if (islemTip == "IcmalNoVer")
        mesaj = res_JSGEN015;
    else if (islemTip == "IcmalYazdir")
        mesaj = res_JSGEN016;
    else if (islemTip == "MuhasebatGonder")
        mesaj = res_JSGEN017;
    else if (islemTip == "Tahsis")
        mesaj = res_JSGEN018;
    else if (islemTip == "Temizle")
        mesaj = res_JSGEN019;
    else if (islemTip == "Yazdir")
        mesaj = res_JSGEN020;
    else if (islemTip == "TasinirOzellikSil")
        mesaj = res_JSGEN021;
    else if (islemTip == "Sil")
        mesaj = res_JSGEN022;
    else if (islemTip == "Aktar")
        mesaj = res_JSGEN023;
    else if (islemTip == "ebutcedenAktar")
        mesaj = res_JSGEN024;
    else if (islemTip == "belgeTurDegistir")
        mesaj = res_JSGEN025;
    else if (islemTip == "odemeEmriOlustur")
        mesaj = res_JSGEN026;
    else if (islemTip == "harcamaBirimDegistir")
        mesaj = res_JSGEN027;
    else if (islemTip == "YeniYap")
        mesaj = res_JSGEN028;
    else if (islemTip == "epostaGonder")
        mesaj = res_JSGEN029;
    else if (islemTip == "evrakKaydet")
        mesaj = res_JSGEN030;
    else if (islemTip == "evrakHavale")
        mesaj = res_JSGEN031;
    else if (islemTip == "evrakDosyayaKaldir")
        mesaj = res_JSGEN032;
    else if (islemTip == "evrakDosyadanAl")
        mesaj = res_JSGEN033;
    else if (islemTip == "evrakGidenNoAl")
        mesaj = res_JSGEN034;
    else if (islemTip == "evrakHavaleGeriAl")
        mesaj = res_JSGEN035;
    else if (islemTip == "evrakIptalEt")
        mesaj = res_JSGEN036;
    else if (islemTip == "evrakIptalGeriAl")
        mesaj = res_JSGEN037;
    else if (islemTip == "evrakTeslimAl")
        mesaj = res_JSGEN038;
    else if (islemTip == "evrakGeriGonder")
        mesaj = res_JSGEN039;
    else if (islemTip == "evrakImzala")
        mesaj = res_JSGEN040;
    else if (islemTip == "kaydet")
        mesaj = res_JSGEN041;
    else if (islemTip == "sablonKaydet")
        mesaj = res_JSGEN042;
    else if (islemTip == "sablonSil")
        mesaj = res_JSGEN043;
    else if (islemTip == "DegOnayla")
        mesaj = res_JSGEN044;
    else if (islemTip == "eImzala")
        mesaj = res_JSGEN047;

    islemTip = "";
    return confirm(mesaj);
}

function PopupWin(url, w, h, id) {
    var l = (screen.width - w) / 2;
    var t = (screen.height - h) / 2;
    //var l =465;
    //var t = 30;

    windowpop = window.open(url, id, "width=" + w + ",height=" + h + ",left=" + l.toString() + ",top=" + t.toString() + ",resizable=no,scrollbars=no,status=yes,location=no,toolbar=no,menubar=no");
    windowpop.focus();
    return windowpop;
}

function HesapPlaniKurum(kurum) {
    var rKurum;

    if (kurum.replace(".", "").substring(0, 2) == "38")
        rKurum = "38";
    else if (parseInt(kurum.replace(".", "").substring(0, 2), 0) >= 40)
        rKurum = kurum.replace(".", "");
    else
        rKurum = "12";

    return rKurum;
}

function kurumDegistiMi(kurum) {
    if (kurum != document.getElementById('ddlKurum').value)
        return window.confirm(res_JSGEN045);
    else
        return true;
}

function findPosX(obj) {
    var curleft = 0;
    if (obj.offsetParent) {
        while (obj.offsetParent) {
            curleft += obj.offsetLeft
            obj = obj.offsetParent;
        }
    }
    else if (obj.x)
        curleft += obj.x;
    return curleft;
}

function findPosY(obj) {
    var curtop = 0;
    if (obj.offsetParent) {
        while (obj.offsetParent) {
            curtop += obj.offsetTop
            obj = obj.offsetParent;
        }
    }
    else if (obj.y)
        curtop += obj.y;
    return curtop;
}

function up_down(f, bDir, sName) {
    var el = f.elements[sName]
    var idx = el.selectedIndex
    if (idx == -1)
        alert(res_JSGEN046)
    else {
        var nxidx = idx + (bDir ? -1 : 1)
        if (nxidx < 0) nxidx = el.length - 1
        if (nxidx >= el.length) nxidx = 0
        var oldVal = el[idx].value
        var oldText = el[idx].text
        el[idx].value = el[nxidx].value
        el[idx].text = el[nxidx].text
        el[nxidx].value = oldVal
        el[nxidx].text = oldText
        el.selectedIndex = nxidx
    }
}

function ShowProgress() {
    img = document.getElementById('divBekle');
    if (img)
        img.style.display = "block";
}

function HideProgress() {
    img = document.getElementById('divBekle');
    if (img)
        img.style.display = "none";
}

function DugmeAktifYap(kontrol) {
    try {
        dugme = document.getElementById(kontrol);
        dugme.disabled = false;
    } catch (Err) { }
}

function CheckBoxSelectAllByParent(id, e) {
    var obj = document.getElementById(id);
    if (obj != null) {
        var list = obj.getElementsByTagName('input');
        for (var i = 1; i < list.length; i++) {
            if ((list[i].type == 'checkbox') && (!list[i].disabled)) {
                list[i].checked = e.checked;
            }
        }
    }
}

function windowSize() {
    var o = windowSizeObj();
    return o.w + "x" + o.h;
}

function windowSizeObj() {
    var donDeger = new Object();
    if (typeof (window.innerWidth) == 'number') {
        //Non-IE
        donDeger.w = window.innerWidth;
        donDeger.h = window.innerHeight;
    } else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        //IE 6+ in 'standards compliant mode'
        donDeger.w = document.documentElement.clientWidth;
        donDeger.h = document.documentElement.clientHeight;
        //alert("2/" + myWidth + "*" + myHeight)
    } else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
        //IE 4 compatible
        donDeger.w = document.body.clientWidth;
        donDeger.h = document.body.clientHeight;
    }
    else {
        donDeger.w = 0;
        donDeger.h = 0;
    }
    return donDeger;
}

function getElementTop(Elem) {
    var elem = null;
    if (document.getElementById) {
        elem = document.getElementById(Elem);
    } else if (document.all) {
        elem = document.all[Elem];
    }
    yPos = elem.offsetTop;
    tempEl = elem.offsetParent;
    while (tempEl != null) {
        yPos += tempEl.offsetTop;
        tempEl = tempEl.offsetParent;
    }
    return yPos;
}

function getElementLeft(Elem) {
    var elem = null;
    if (document.getElementById) {
        elem = document.getElementById(Elem);
    } else if (document.all) {
        elem = document.all[Elem];
    }
    yPos = elem.offsetLeft;
    tempEl = elem.offsetParent;
    while (tempEl != null) {
        yPos += tempEl.offsetLeft;
        tempEl = tempEl.offsetParent;
    }
    return yPos;
}

function IframeIslem(ifrmID, ifrmElementID, param) {
    var frm = window.frames[ifrmID];
    if (frm != null) {
        var element = frm.document.getElementById(ifrmElementID);
        if (element != null) {
            if (param == "click") { element.click(); }
        }
    }
}
function IframeSrc(ifrmID, ifrmAdres) {
    var frm = document.getElementById(ifrmID);
    if (frm != null) { frm.src = ifrmAdres; }
}
/*Iframe de bulunan fonksiyonu çağırır.  Sonuç: 'ifrmFunctionName(params);' */
function IframeFunction(ifrmID, ifrmFunctionName, params) {
    var param = '';
    if (params != undefined) {
        param = "'";
        params = params.split(',');
        for (var i = 0; i < params.length; i++) { if (i > 0) param += ",'"; param += params[i] + "'"; }
    }
    var func = new Function("window.frames['" + ifrmID + "']." + ifrmFunctionName + "(" + param + ");");
    return func();
}
/* __doPostBack : 'a href click' işlemlerini '__doPostBack' ile server'a gönder. */
function IframeBtnIslem(ifrmID, target, arg) {
    if (target == undefined) target = '';
    if (arg == undefined) arg = '';
    IframeFunction(ifrmID, '__doPostBack', target + ',' + arg);
}
/* __doPostBack : 'a href click' işlemlerini '__doPostBack' ile server'a gönder. */
function BtnIslem(target, arg) {
    if (target == undefined) target = '';
    if (arg == undefined) arg = '';
    __doPostBack(target, arg);
}
/*IDList: 'element1,element2,element3,...' */
function ElementTemizle(IDList) {
    var elements = IDList.split(',');
    var element;
    for (var i = 0; i < elements.length; i++) {
        element = document.getElementById(elements[i]);
        if (element != null) {
            if (element.tagName == 'INPUT') { element.value = ''; }
            else if (element.tagName == 'SELECT') { element.options.selectedIndex = 0; }
        }
    }
}
/*IDList: 'element1=a,element2=b,element3=c,...' */
function ElementDegerAta(IDList) {
    var elements = IDList.split(',');
    var element;
    for (var i = 0; i < elements.length; i++) {
        element = elements[i].split('=');
        if (element.length == 2) {
            element[0] = document.getElementById(element[0]);
            if (element[0] != null) {
                if (element[0].tagName == 'INPUT' || element.tagName == 'SELECT') { element[0].value = element[1]; }
            }
        }
    }
}

function StrFormat() {
    if (arguments.length == 0)
        return "";
    var fmtStr = arguments[0];
    for (i = 1; i < arguments.length; i++) {
        fmtStr = fmtStr.replace('{' + (i - 1) + '}', arguments[i]);
    }
    return fmtStr;
}

function LoadingKonumAyarla(control) {
    var scrWH = windowSize();
    var srcWHA = scrWH.split('x');
    var scrW = srcWHA[0];
    var scrH = srcWHA[1];
    var h = Number(Number(scrH) - 75) / 2;
    var w = Number(Number(scrW) - 200) / 2;

    try {
        document.getElementById(control).style.top = h + "px";
        document.getElementById(control).style.left = w + "px";
    }
    catch (e) {

    }
}

function includeCssToHead(cssFilePath) {
    var css = document.createElement("link");
    var head = document.getElementsByTagName('head')[0];

    //css = document.createElement("link")
    css.setAttribute("rel", "stylesheet")
    css.setAttribute("type", "text/css")
    css.setAttribute("href", cssFilePath)

    head.appendChild(css);
}


function includeScriptToBody(jsFilePath) {
    var js = document.createElement("script");

    js.type = "text/javascript";
    js.src = jsFilePath;

    document.body.appendChild(js);
}

function includeScriptToHead(jsFilePath) {
    // adding the script tag to the head as suggested before
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = jsFilePath;

    // then bind the event to the callback function 
    // there are several events for cross browser compatibility
    // script.onreadystatechange = callback;
    // script.onload = callback

    // fire the loading
    head.appendChild(script);
}


function mesajKutusu(mesaj) {

    var divId = "mesajKutusu_div";
    var div = document.getElementById(divId);
    if (div == null) {
        if (document.createElement && (div = document.createElement('div'))) {
            div.name = div.id = divId;
            document.body.appendChild(div);
        }
    }

    div.innerHTML = mesaj;

    $(div).dialog({
        autoOpen: false,
        modal: true,
        width: "500px",
        resizable: false,
        buttons:
        {
            "Tamam": function () {
                $(this).dialog("close");
            }
        }
    });

    $(div).dialog("open");

}

function nodeLoadPar(kodNo, yil, kod, node, kodAd) {
    nodeLoadPar2(kodNo, yil, kod, node, kodAd, false, true);
}

function nodeLoadPar2(kodNo, yil, kod, node, kodAd, checkli, ikonVar) {
    nodeLoadPar3(kodNo, yil, kod, node, kodAd, checkli, ikonVar, 0);
}

function nodeLoadPar3(kodNo, yil, kod, node, kodAd, checkli, ikonVar, yetkiKodu, aramaMetni) {
    if (aramaMetni == undefined) aramaMetni = "";
    if (!aramaMetni) aramaMetni = "";
    var ustKod;
    if (node.id == -1 || node.id == "-1")
        ustKod = "";
    else
        ustKod = node.id;
    var sayfa;
    if (kodNo == "SPG")
        sayfa = '../PerformansButce/DonemSec.aspx';
    else if (kodNo == "30")
        sayfa = '../Evrak/TanimDtvtBirimKaydet.aspx';
    else
        sayfa = '../ButceHazirlikv2/KodAgac.aspx';
    extKontrol.net.DirectMethod.request(
        'KodAgacOlExt',
        {
            success: function (result) {
                //extKontrol.Msg.alert('Message', "");
                var data = eval("(" + result + ")");
                try {
                    node.loadNodes([]);
                    NodeCocuklariAc(node, data);
                } catch (e) {
                    console.log(result);
                    console.log(data);
                }
            },
            failure: function (errorMsg) {
                extKontrol.Msg.alert('Failure', errorMsg);
            },
            specifier: 'static',
            type: 'load',
            url: sayfa,
            params: { kodNo: kodNo, yil: yil, ustKod: ustKod, secili: kod, kodAd: kodAd, checkli: checkli, ikonVar: ikonVar, yetkiKodu: yetkiKodu, aramaMetni: aramaMetni }
        }
    );
}
function NodeCocuklariAc(node, data) {

    for (var i = 0; i < data.length; i++) {
        var nodeIc;
        if (data[i].leaf) {
            nodeIc = new extKontrol.tree.TreeNode({ id: data[i].id, text: data[i].text, leaf: true });
            //nodeIc.leaf = true;
        }
        else {
            if (data[i].children) {
                nodeIc = new extKontrol.tree.TreeNode({ id: data[i].id, text: data[i].text, leaf: false });
                //nodeIc.loadNodes([]);
                NodeCocuklariAc(nodeIc, data[i].children);
                nodeIc.expanded = true;
            }
            else {
                nodeIc = new extKontrol.tree.AsyncTreeNode({ id: data[i].id, text: data[i].text, leaf: false });
            }
        }
        node.appendChild(nodeIc);
    }
}


function nodeLoadOrgBirim(node) {
    nodeLoadOrgBirimParam(node, null);
}

function nodeLoadOrgBirimParam(node, orgBirim) {
    if (node.attributes.asynMi == "0") {
        return;
    }
    var shwMsk = true;
    if (orgBirim.showMask == false)
        shwMsk = false;
    extKontrol.net.DirectMethod.request(
        'NodeLoad',
        {
            success: function (result) {
                if (result == "")
                    return;
                var data = eval("(" + result + ")");
                node.loadNodes(data);
            },

            failure: function (errorMsg) {
                extKontrol.Msg.alert('Failure', errorMsg);
            },
            specifier: 'static',
            url: '../Organizasyon/ORGBirim.aspx',
            params: { nodeID: node.id, orgBirim: orgBirim },
            eventMask: { showMask: shwMsk, msg: "Lütfen Bekleyin..." }
        }
    );
}

function nodeLoadOdaParam(node, odaBilgi) {
    if (node.attributes.asynMi == "0") {
        return;
    }
    var shwMsk = true;
    if (odaBilgi.showMask == false)
        shwMsk = false;
    extKontrol.net.DirectMethod.request(
        'NodeLoad',
        {
            success: function (result) {
                if (result == "")
                    return;
                var data = eval("(" + result + ")");
                node.loadNodes(data);
            },

            failure: function (errorMsg) {
                extKontrol.Msg.alert('Failure', errorMsg);
            },
            specifier: 'static',
            url: '../KYM/TanimOda.aspx',
            params: { nodeID: node.id, odaBilgi: odaBilgi },
            eventMask: { showMask: shwMsk, msg: "Lütfen Bekleyin..." }
        }
    );
}

function nodeLoadButceKod(node, kodBilgi) {
    nodeLoadPar3(kodBilgi.kodNo, kodBilgi.yil, node.id, node, kodBilgi.kodAd, kodBilgi.checkli, kodBilgi.ikonVar, kodBilgi.yetkiKodu, kodBilgi.adi)
}

function OrgBirimBul(node, returnFnc) {
    extKontrol.net.DirectMethod.request(
        'OrgBirimBul',
        {
            success: function (result) {
                returnFncCagir(returnFnc, result);
            },

            failure: function (errorMsg) {
                extKontrol.Msg.alert('Failure', errorMsg);
            },
            specifier: 'static',
            url: '../Organizasyon/ORGBirim.aspx',
            params: { nodeID: node.id },
            eventMask: { showMask: true, msg: "Lütfen Bekleyin..." }
        }
    );
}

function MuhasebeBirimBul(node, returnFnc) {
    extKontrol.net.DirectMethod.request(
        'MuhasebeBirimBul',
        {
            success: function (result) {
                returnFncCagir(returnFnc, result);
            },

            failure: function (errorMsg) {
                extKontrol.Msg.alert('Failure', errorMsg);
            },
            specifier: 'static',
            url: '../GelirSurecleri/SurecForm.aspx',
            params: { nodeID: node.id },
            eventMask: { showMask: true, msg: "Lütfen Bekleyin..." }
        }
    );
}

function returnFncCagir(returnFnc, result) {
    var parIndex = returnFnc.indexOf('(');
    if (parIndex > -1) {
        var fnc = returnFnc.substr(0, parIndex);
        var params = returnFnc.substr(parIndex + 1, returnFnc.indexOf(')') - parIndex - 1);

        if (params != "")
            returnFnc = fnc + "(" + params + ", ";
        else
            returnFnc = fnc + "(";
    }
    else
        returnFnc += "(";

    eval(returnFnc + "'" + extKontrol.util.JSON.encode(result) + "');");
}

function StoreRenderer(store, value) {
    return StoreRendererFieldAd(store, value, "Name")
}

function StoreRendererFieldAd(store, value, fieldName) {
    var r = store.getById(value);

    if (extKontrol.isEmpty(r)) {
        return "";
    }

    return r.data[fieldName];
}

function nodeLoadMuhasebeBirim(node) {
    extKontrol.net.DirectMethod.request(
        'MuhasebeBirimNodeLoad',
        {
            success: function (result) {
                if (result == "")
                    return;
                var data = eval("(" + result + ")");
                node.loadNodes(data);
            },

            failure: function (errorMsg) {
                extKontrol.Msg.alert('Failure', errorMsg);
            },
            specifier: 'static',
            url: '../ButceMuhasebe/ListeMuhasebeBirim.aspx',
            params: { muhasebeKod: node.id }
        }
    );
}

function NodeYukle(node, onceSil, data, loadNodesCagir) {
    if (onceSil) {
        try {
            node.removeAll();
        }
        catch (e) { }
    }
    NodeYukleRec(node, data);
    if (loadNodesCagir) {
        var x = new Array();
        try {
            node.loadNodes(x);
        }
        catch (ex) { }
    }
    node.expand();
}

function NodeYukleRec(node, data) {
    for (var i = 0; i < data.length; i++) {
        var nodeIc;
        if (data[i].leaf) {
            nodeIc = new extKontrol.tree.TreeNode({ id: data[i].id, text: data[i].text, leaf: false });
            nodeIc.leaf = true;
        }
        else {
            if (data[i].children) {
                nodeIc = new extKontrol.tree.TreeNode({ id: data[i].id, text: data[i].text, leaf: false });
                NodeYukleRec(nodeIc, data[i].children)
            }
            else {
                nodeIc = new extKontrol.tree.AsyncTreeNode({ id: data[i].id, text: data[i].text, leaf: false });
            }
        }
        node.appendChild(nodeIc);
    }
}

function PadLeft(val, ch, num) {
    var re = new RegExp(".{" + num + "}$");
    var pad = "";
    if (!ch) ch = " ";
    do {
        pad += ch;
    } while (pad.length < num);
    return re.exec(pad + val)[0];
}

function PadRight(val, ch, num) {
    var re = new RegExp("^.{" + num + "}");
    var pad = "";
    if (!ch) ch = " ";
    do {
        pad += ch;
    } while (pad.length < num);
    return re.exec(val + pad)[0];
}

function ReplaceAll(strDeger, eskiDeger, yeniDeger) {
    var regEx = new RegExp(eskiDeger);
    while (strDeger.indexOf(eskiDeger) >= 0)
        strDeger = strDeger.replace(regEx, yeniDeger);
    return strDeger;
}

function RemoveAll(strDeger, removeDeger) {
    return ReplaceAll(strDeger, removeDeger, '');
}

function GridHucreDegerAl(hucre) {
    if (hucre.innerText)
        return hucre.innerText;
    else {
        return RemoveAll(RemoveAll(hucre.textContent, "\n"), " ");
    }
}