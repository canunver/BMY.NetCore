﻿function trim(str) { return str.replace(/^\s*|\s*$/g, ""); }

//FPDegerAta_TertipListe(node, document.all.rdPB_fpL, sutun, sutunAciklama, tertipTur, ekoUzun)

function FPDegerAta_TertipListe(node, fp, sutun, sutunAciklama, tertipTur, ekoUzun, noEventKod, noEventAciklama) {
    var donusDeger;
    donusDeger = -1;

    if (1 == 1)//if(node.TreeView.ClientID.indexOf(tertipTur)>0)
    {
        var aciklama = "";
        var tDiziAciklama = node.text.split('-');
        if (tDiziAciklama.length > 1)
            aciklama = tDiziAciklama[tDiziAciklama.length - 1];

        var tertip = "";
        var tDizi = node.id.split('-');

        //      if (node.TreeView.ClientID.indexOf("Gider")>0)
        //      {
        //           if (tDizi.length>4)
        //           {
        //            if(ekoUzun==0 || ekoUzun==tDizi[4].length)
        //               tertip=tDizi[1] + "-" + tDizi[2] +"-"+ tDizi[3] +"-"+tDizi[4];
        //            }
        //      }
        //      else if (node.TreeView.ClientID.indexOf("Hesap")>0)
        //      {
        if (tDizi.length > 1)
            tertip = tDizi[1];
        else
            tertip = node.id;

        if (tertip != "") {
            var satir = fp.GetActiveRow();

            if (satir == null) {
                for (var i = 0; i < fp.GetRowCount(); i++) {
                    if (fp.GetValue(i, sutun).length < 2) {
                        satir = i;
                        break;
                    }
                }
            }

            if (satir != null) {
                if (sutun >= 0) {
                    fp.SetValue(satir, sutun, tertip, noEventKod);
                    donusDeger = satir;
                }
                if (sutunAciklama >= 0)
                    fp.SetValue(satir, sutunAciklama, aciklama, noEventAciklama);
            }
            else
                alert("Lutfen bos satir aciniz.");
        }
    }
    return donusDeger;
}

function FPDegerAta_ButceKodListe(node, fp, sutun, sutunAciklama, tertipTur, ekoUzun, noEventKod, noEventAciklama) {
    var donusDeger;
    donusDeger = -1;

    var tDiziKod = node.Value.split('-');
    var gelenTur = "";
    if (tDiziKod.length > 0)
        gelenTur = tDiziKod[0];

    if (gelenTur == tertipTur) {
        var aciklama = "";
        var tDiziAciklama = node.Text.split('-');
        if (tDiziAciklama.length > 1)
            aciklama = tDiziAciklama[tDiziAciklama.length - 1];

        var butceKod = "";
        if (tDiziKod.length > 1)
            butceKod = tDiziKod[1];


        if (butceKod.length >= ekoUzun) {
            var satir = fp.GetActiveRow();

            if (satir == null) {
                for (var i = 0; i < fp.GetRowCount(); i++) {
                    if (fp.GetValue(i, sutun).length < 2) {
                        satir = i;
                        break;
                    }
                }
            }

            if (satir != null) {
                if (sutun >= 0) {
                    fp.SetValue(satir, sutun, butceKod, noEventKod);
                    donusDeger = satir;
                }
                if (sutunAciklama >= 0)
                    fp.SetValue(satir, sutunAciklama, aciklama, noEventAciklama);
            }
            else
                alert("Lutfen bos satir aciniz.");
        }
    }
    return donusDeger;
}

function NodeSecildiPopUp(node) {
    if (window.opener != null)
        NodeSecildiGenelWin(window.opener.top, node, "PopUpAcanVar")
    else
        NodeSecildiGenelWin(parent, node, "PopUpAcanYok")
}

function NodeSecildiGenel(node) {
    NodeSecildiGenelWin(parent, node, "Normal");
}

function NodeSecildiGenelWin(win, node, cagiranBilgi) {
    if (win.frames.length != 0) {
        for (var i = 0; i < win.frames.length; i++) {
            try {
                NodeSecildiGenelWin(win.frames[i], node, cagiranBilgi + win.frames[i].name);
            }
            catch (err) { }
        }
    }
    else {
        try {
            win.NodeSecildiYerel(node);
        }
        catch (err) { }
    }
}


function ProcessClientClickTreeFirma(node) {
    if (node != null) {
        if (node.Value != "") {
            var tDiziAciklama = node.Value.split('|');

            if (tDiziAciklama.length >= 5) {
                parent.document.getElementById('txtIlgiliAd').value = tDiziAciklama[0];
                parent.document.getElementById('txtIlgiliNo').value = tDiziAciklama[1];
                parent.document.getElementById('txtIlgiliVD').value = tDiziAciklama[2];
                parent.document.getElementById('txtIlgiliBankaAd').value = tDiziAciklama[3];
                parent.document.getElementById('txtIlgiliBankaNo').value = tDiziAciklama[4];

                parent.hidePopWin();
            }
        }
    }
}


function ProcessClientClickTreeMuhasebeBirim(node) {
    var muhasebe;
    var birim;
    var bilgi;
    var yer;
    var ad;

    if (node != null) {
        bilgi = node.Value;
        yer = bilgi.indexOf("-");

        if (bilgi != "") {
            muhasebe = trim(bilgi.substring(0, yer))
            birim = trim(bilgi.substring(yer + 1));
            opener.document.getElementById('txtMuhasebe').value = muhasebe;
            opener.document.getElementById('txtBirim').value = birim;

            bilgi = node.Text;
            yer = bilgi.indexOf("-");

            ad = trim(bilgi.substring(yer + 1));
            if (birim == "") {
                opener.document.getElementById('lblMuhasebeAd').innerText = ad;
                opener.document.getElementById('lblBirimAd').innerText = "";
            }
            else {
                opener.document.getElementById('lblBirimAd').innerText = ad;
                var ustAd = node.Parent.Text;
                yer = ustAd.indexOf("-");
                ustAd = trim(ustAd.substring(yer + 1));
                opener.document.getElementById('lblMuhasebeAd').innerText = ustAd;

            }
        }
    }
}


function ProcessClientClickTreeButceKod(node) {
    var seviye = node.Level - 1;
    var yer1 = 0;
    var yer2 = 0;
    var pAd = new Array(5);
    var pKod = new Array(5);
    var bilgi1 = "";
    var bilgi2 = "";

    pKod[1] = "";
    pKod[2] = "";

    try {
        if (node.Text != "") {
            bilgi1 = node.Text;
            bilgi2 = node.Value;

            yer1 = bilgi1.indexOf("-");
            yer2 = bilgi2.indexOf("*");

            pKod[1] = trim(bilgi2.substring(0, yer2))

            pKod[2] = trim(bilgi1.substring(0, yer1))
            pAd[2] = trim(bilgi1.substring(yer1 + 1));
        }

        if (pKod[2] != "") {
            parent.frames["ana"].document.getElementById('ddlKodTur').value = pKod[1];
            parent.frames["ana"].document.getElementById('txtKod').innerText = pKod[2];
        }
    }
    catch (e) {
    }

    try {
        if (pKod[1] == "1")
            parent.frames["ana"].document.getElementById('txtKur').innerText = pKod[2];
        if (pKod[1] == "2")
            parent.frames["ana"].document.getElementById('txtFon').innerText = pKod[2];
        if (pKod[1] == "3")
            parent.frames["ana"].document.getElementById('txtFin').innerText += pKod[2];
        if (pKod[1] == "4")
            parent.frames["ana"].document.getElementById('txtEko').innerText += pKod[2];
        if (pKod[1] == "5")
            parent.frames["ana"].document.getElementById('txtGEko').innerText += pKod[2];
        if (pKod[1] == "6")
            parent.frames["ana"].document.getElementById('txtFEko').innerText += pKod[2];
    }
    catch (e) {
    }
}

function OdenekHesapla() {
    var k1 = document.getElementById('ddlKatsayi').value;
    var yer = k1.indexOf("*");
    var d1 = k1.substring(0, yer);
    var d2 = k1.substring(yer + 1);
    var odenek = document.getElementById('txtOdenek1').value;

    d1 = d1.replace(",", ".");
    d2 = d2.replace(",", ".");

    for (var say = 0; say < 3; say = say + 1)
        odenek = odenek.replace(".", "");

    for (var say = 0; say < 3; say = say + 1)
        odenek = odenek.replace(",", "");

    var f1 = parseFloat(d1);
    var f2 = parseFloat(d2);

    var odenek2 = odenek * f1;
    document.getElementById('txtOdenek2').innerText = parseInt(odenek2);
    document.getElementById('txtOdenek3').innerText = parseInt(odenek2 * f2);
}

function OdenekHesaplaListe(kolon) {
    var k1 = document.getElementById('ddlKatsayi').value;
    var yer = k1.indexOf("*");
    var d1 = k1.substring(0, yer);
    var d2 = k1.substring(yer + 1);
    var odenek = 0;
    var odenek2 = 0;

    d1 = d1.replace(",", ".");
    d2 = d2.replace(",", ".");

    var f1 = parseFloat(d1);
    var f2 = parseFloat(d2);

    //bekle.style.left=100;
    //bekle.style.top=100;

    for (var i = 0; i < fpListe.GetRowCount(); i = i + 1) {
        if (fpListe.GetValue(i, 0).length > 2) {
            odenek = fpListe.GetValue(i, kolon);

            for (var say = 0; say < 3; say = say + 1)
                odenek = odenek.replace(".", "");

            for (var say = 0; say < 3; say = say + 1)
                odenek = odenek.replace(",", "");

            odenek = parseInt(odenek);

            if (parseInt(odenek) > 0) {
                odenek2 = odenek * f1;
                fpListe.SetValue(i, kolon + 1, parseInt(odenek2));
                fpListe.SetValue(i, kolon + 2, parseInt(odenek2 * f2));
            }
            else {
                fpListe.SetValue(i, kolon + 1, "0");
                fpListe.SetValue(i, kolon + 2, "0");
            }
        }
    }
    //bekle.style.left=-100;
    //bekle.style.top=-100;
}
