﻿const columnTypes = {
    KurusKolon: {
        cellStyle: { textAlign: "right" }, // Sayıları sağa hizala
        valueFormatter: function (params) {
            if (params.value == null) return "";
            return new Intl.NumberFormat('tr-TR', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(params.value);
        }
    },
    LiraKolon: {
        cellStyle: { textAlign: "right" }, // Sayıları sağa hizala
        valueFormatter: function (params) {
            if (params.value == null) return "";
            return new Intl.NumberFormat('tr-TR', {
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            }).format(params.value);
        }
    }
};

var AGTurkceAyar = {
    page: 'Sayfa',
    more: 'Daha fazla',
    to: '-',
    of: '/',
    next: 'Sonraki',
    last: 'Son',
    first: 'İlk',
    previous: 'Önceki',
    loadingOoo: 'Yükleniyor...',
    noRowsToShow: 'Gösterilecek kayıt yok',
    filterOoo: 'Filtrele...',
    applyFilter: 'Uygula',
    equals: 'Eşittir',
    notEqual: 'Eşit değil',
    lessThan: 'Küçüktür',
    greaterThan: 'Büyüktür',
    contains: 'İçerir',
    notContains: 'İçermez',
    startsWith: 'İle başlar',
    endsWith: 'İle biter'
    // ihtiyaca göre diğerlerini de ekleyebilirsin
};

window.StrGrid = window.StrGrid || {};

// Basit HTML5 date input kullanan cell editor
StrGrid.DatePickerEditor = function () { };

StrGrid.DatePickerEditor.prototype.init = function (params) {
    this.params = params;
    var eInput = document.createElement('input');
    eInput.type = 'date';
    eInput.className = 'ag-input-field-input ag-text-field-input';
    var v = params.value;

    if (v) {
        var iso = null;
        if (typeof v === 'string') {
            v = v.trim();
            // dd.MM.yyyy → yyyy-MM-dd
            var m = v.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
            if (m) {
                iso = m[3] + '-' + m[2] + '-' + m[1];
            } else if (/^\d{4}-\d{2}-\d{2}/.test(v)) {
                iso = v.substring(0, 10);
            }
        }
        if (iso) eInput.value = iso;
    }

    this.eInput = eInput;
};

StrGrid.DatePickerEditor.prototype.getGui = function () {
    return this.eInput;
};

StrGrid.DatePickerEditor.prototype.afterGuiAttached = function () {
    if (this.eInput) {
        this.eInput.focus();
        this.eInput.select();
    }
};

StrGrid.DatePickerEditor.prototype.getValue = function () {
    // input type=date her zaman yyyy-MM-dd döndürür
    return this.eInput && this.eInput.value ? this.eInput.value : null;
};

StrGrid.DatePickerEditor.prototype.destroy = function () { };

StrGrid.DatePickerEditor.prototype.isPopup = function () {
    return false;
};

StrGrid.attachSubmit = function (formId, gridId, collector) {
    var f = document.getElementById(formId);
    if (!f) return;

    // grid bazlı kayıt
    f.__strgridSubmit = f.__strgridSubmit || {};
    f.__strgridCollectors = f.__strgridCollectors || {};

    if (!f.__strgridSubmit[gridId]) {
        f.__strgridSubmit[gridId] = true;
        f.__strgridCollectors[gridId] = collector;
    }

    // onsubmit sadece 1 kere bağlansın
    if (f.__strgridWrapped) return;
    f.__strgridWrapped = true;

    var old = f.onsubmit;
    f.onsubmit = function (e) {
        try {
            var m = f.__strgridCollectors || {};
            for (var k in m) {
                try { m[k] && m[k](); } catch (ex2) { console.error("StrGrid.collector:", ex2); }
            }
        } catch (ex) {
            console.error("StrGrid.attachSubmit:", ex);
        }
        return (typeof old === 'function') ? old.call(f, e) : true;
    };
};

// --- Clipboard utils (HTTPS yoksa fallback) ---
StrGrid.writeClipboardText = async function (text) {
    try {
        if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(text);
            return true;
        }
    } catch (e) { }
    // fallback: hidden textarea + execCommand
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.left = "-9999px";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { }
    document.body.removeChild(ta);
    return ok;
};

StrGrid.readClipboardText = async function () {
    if (navigator.clipboard && window.isSecureContext) {
        return await navigator.clipboard.readText();
    }
    // HTTP ortamda "read" çoğu zaman yasak; kullanıcıdan Ctrl+V ile textarea'ya yapıştırma gerekir
    // Basit çözüm: prompt açıp yapıştırmasını istemek
    return window.prompt("Panodaki (TAB/ENTER ayrımlı) veriyi buraya yapıştırın:");
};

StrGrid._flattenColDefs = function (defs, out) {
    out = out || [];
    if (!defs) return out;

    for (var i = 0; i < defs.length; i++) {
        var d = defs[i];
        if (!d) continue;

        if (d.children && d.children.length) {
            StrGrid._flattenColDefs(d.children, out);
        } else {
            out.push(d);
        }
    }
    return out;
};

StrGrid.copyAll = async function (api) {
    if (!api || !api.getColumnDefs) return false;

    var defs = api.getColumnDefs() || [];
    var flat = StrGrid._flattenColDefs(defs, []);

    // tüm kolonların id listesi
    var colIds = [];
    for (var i = 0; i < flat.length; i++) {
        var id = flat[i].field || flat[i].colId;
        if (id) colIds.push(id);
    }
    if (colIds.length === 0) return false;

    // başlangıç: aktif hücre yoksa 0,0
    var startRow = 0;
    var startColIndex = 0;

    var fc = api.getFocusedCell ? api.getFocusedCell() : null;
    if (fc && typeof fc.rowIndex === "number" && fc.rowIndex >= 0) startRow = fc.rowIndex;

    if (fc && fc.column && fc.column.getColId) {
        var focusedColId = fc.column.getColId();
        var idx = colIds.indexOf(focusedColId);
        if (idx >= 0) startColIndex = idx;
    }

    var rowCount = api.getDisplayedRowCount ? api.getDisplayedRowCount() : 0;
    if (rowCount <= 0) return false;

    var lines = [];
    for (var r = startRow; r < rowCount; r++) {
        var rowNode = api.getDisplayedRowAtIndex ? api.getDisplayedRowAtIndex(r) : null;
        var parts = [];

        for (var c = startColIndex; c < colIds.length; c++) {
            var fid = colIds[c];
            var v = (rowNode && rowNode.data) ? rowNode.data[fid] : "";
            if (v === null || v === undefined) v = "";
            v = String(v).replace(/\r?\n/g, " ");
            parts.push(v);
        }
        lines.push(parts.join("\t"));
    }

    return await StrGrid.writeClipboardText(lines.join("\n"));
};



StrGrid._getColDefById = function (api, colId) {
    if (api.getColumnDef) return api.getColumnDef(colId);

    // fallback: columnDefs içinde ara
    var defs = (api.getColumnDefs ? (api.getColumnDefs() || []) : []);
    var flat = StrGrid._flattenColDefs(defs, []);
    for (var i = 0; i < flat.length; i++) {
        var id = flat[i].field || flat[i].colId;
        if (id === colId) return flat[i];
    }
    return null;
};

StrGrid._isEditable = function (colDef, api, rowNode, colId) {
    if (!colDef) return true; // colDef yoksa engelleme yapmayalım

    // editable false ise direkt geç
    if (colDef.editable === false) return false;

    // editable function ise çalıştır
    if (typeof colDef.editable === "function") {
        try {
            return !!colDef.editable({
                data: rowNode ? rowNode.data : null,
                node: rowNode,
                colDef: colDef,
                column: (api.getColumn && api.getColumn(colId)) ? api.getColumn(colId) : null,
                api: api,
                context: api.context
            });
        } catch (e) {
            return false;
        }
    }

    // editable true / undefined ise izin ver
    return true;
};

StrGrid._normalizeNumberText = function (txt) {
    if (txt == null) return txt;
    txt = String(txt).trim();
    if (txt === "") return txt;

    // Boşlukları kaldır (1 234,56 gibi)
    var s = txt.replace(/\s+/g, "");

    // Eğer hem nokta hem virgül varsa muhtemelen binlik+ondalık karışık:
    // 1.234,56  -> 1234.56
    // 1,234.56  -> 1234.56 (tersi de olabilir ama genelde bu gelir)
    if (s.indexOf(",") >= 0 && s.indexOf(".") >= 0) {
        // Son görünen ayırıcı hangisi? (ondalık genelde sondadır)
        var lastComma = s.lastIndexOf(",");
        var lastDot = s.lastIndexOf(".");
        if (lastComma > lastDot) {
            // 1.234,56 -> binlik '.' kaldır, ',' -> '.'
            s = s.replace(/\./g, "").replace(/,/g, ".");
        } else {
            // 1,234.56 -> binlik ',' kaldır (nadir), '.' kalsın
            s = s.replace(/,/g, "");
        }
        return s;
    }

    // Sadece virgül varsa: 12,22 -> 12.22
    if (s.indexOf(",") >= 0) {
        // Sayıya benziyor mu? (başında eksi olabilir)
        if (/^-?\d+(,\d+)?$/.test(s)) {
            return s.replace(/,/g, ".");
        }
    }

    return txt;
};


StrGrid._applyValueToCell = function (api, rowNode, colId, pastedText) {
    var colDef = StrGrid._getColDefById(api, colId);

    if (!StrGrid._isEditable(colDef, api, rowNode, colId)) return false;

    var raw = (pastedText == null) ? "" : String(pastedText);
    var txt = StrGrid._normalizeNumberText(raw);

    // 1) valueParser varsa önce parse et
    var newValue = txt;
    if (colDef && typeof colDef.valueParser === "function") {
        try {
            var parsed = colDef.valueParser({
                newValue: txt,
                oldValue: rowNode.data ? rowNode.data[colId] : undefined,
                data: rowNode.data,
                node: rowNode,
                colDef: colDef,
                api: api,
                context: api.context
            });

            // parser null döndürüyorsa "tanıyamadım" kabul edip ham metni kullan
            if (parsed !== null && parsed !== undefined) newValue = parsed;
        } catch (e) {
            // parser patlarsa ham değerle devam
        }
    }

    // 2) valueSetter varsa onu çağır (edit davranışına en yakın)
    if (colDef && typeof colDef.valueSetter === "function") {
        try {
            var ok = colDef.valueSetter({
                newValue: newValue,
                oldValue: rowNode.data ? rowNode.data[colId] : undefined,
                data: rowNode.data,
                node: rowNode,
                colDef: colDef,
                api: api,
                context: api.context
            });
            if (ok) return true;
            // ok=false ise aşağıya düşüp direkt yazalım
        } catch (e) {
            // setter patlarsa aşağıya düş
        }
    }

    // 3) setter yoksa direkt yaz
    if (rowNode.setDataValue) {
        rowNode.setDataValue(colId, newValue);
    } else if (rowNode.data) {
        rowNode.data[colId] = newValue;
    }
    return true;
};

StrGrid._parseTsv = function (text) {
    if (text == null) return [];
    text = String(text).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    var lines = text.split("\n");
    while (lines.length && lines[lines.length - 1] === "") lines.pop();
    var matrix = [];
    for (var i = 0; i < lines.length; i++) {
        matrix.push(lines[i].split("\t"));
    }
    return matrix;
};

StrGrid._getColIdsAll = function (api) {
    var defs = api.getColumnDefs ? (api.getColumnDefs() || []) : [];
    var flat = StrGrid._flattenColDefs(defs, []);
    var ids = [];
    for (var i = 0; i < flat.length; i++) {
        var id = flat[i].field || flat[i].colId;
        if (id) ids.push(id);
    }
    return ids;
};

StrGrid._ensureRowCount = function (api, neededRowCount, colIds) {
    var current = api.getDisplayedRowCount ? api.getDisplayedRowCount() : 0;
    if (current >= neededRowCount) return;

    var addCount = neededRowCount - current;
    colIds = colIds || StrGrid._getColIdsAll(api);

    var newRows = [];
    for (var i = 0; i < addCount; i++) {
        var o = {};
        for (var c = 0; c < colIds.length; c++) {
            o[colIds[c]] = "";
        }
        newRows.push(o);
    }

    if (api.applyTransaction) api.applyTransaction({ add: newRows });
    else if (api.updateRowData) api.updateRowData({ add: newRows });
};

StrGrid.pasteAllFromClipboard = async function (api) {
    if (!api) return false;

    api.stopEditing && api.stopEditing();

    var text = await StrGrid.readClipboardText();
    if (text == null) return false;

    var matrix = StrGrid._parseTsv(text);
    if (!matrix.length) return false;

    var colIds = StrGrid._getColIdsAll(api);
    if (!colIds.length) return false;

    // başlangıç hücresi
    var startRow = 0;
    var startColIndex = 0;

    var fc = api.getFocusedCell ? api.getFocusedCell() : null;
    if (fc && typeof fc.rowIndex === "number" && fc.rowIndex >= 0) startRow = fc.rowIndex;

    if (fc && fc.column && fc.column.getColId) {
        var id = fc.column.getColId();
        var idx = colIds.indexOf(id);
        if (idx >= 0) startColIndex = idx;
    }

    // satır yetmiyorsa ekle
    var needed = startRow + matrix.length;
    StrGrid._ensureRowCount(api, needed);

    // yaz
    for (var r = 0; r < matrix.length; r++) {
        var rowIndex = startRow + r;
        var rowNode = api.getDisplayedRowAtIndex ? api.getDisplayedRowAtIndex(rowIndex) : null;
        if (!rowNode) continue;

        var rowArr = matrix[r];
        for (var c = 0; c < rowArr.length; c++) {
            var colIndex = startColIndex + c;
            if (colIndex >= colIds.length) break;

            var colId = colIds[colIndex];
            StrGrid._applyValueToCell(api, rowNode, colId, rowArr[c]);
        }
    }

    api.refreshCells && api.refreshCells({ force: true });
    return true;
};

function ListeyeDegerYazSP(kontrol, row, col, deger, noEvent) {
    var gridId = (typeof kontrol === "string") ? kontrol : kontrol.id;
    var apiVar = gridId + "_gridApi";      // render sırasında window['{id}_gridApi'] olarak atanıyor
    var api = window[apiVar];
    if (!api) {
        console.warn("Grid API bulunamadı:", apiVar);
        return;
    }

    var model = api.getModel();
    var node = model.getRow(row);
    if (!node) {
        var colCount = api.getColumnDefs().length;
        var satir = {};
        for (var i = 0; i < colCount; i++)
            satir["c" + i] = null;

        // istediğin index'e ekle
        api.applyTransaction({
            add: [satir],
            addIndex: row
        });

        model = api.getModel();
        node = model.getRow(row);
    }

    var field = "c" + col;
    node.data[field] = deger;

    if (noEvent) {
        api.refreshCells({ rowNodes: [node], columns: [field], force: true, suppressFlash: true });
    } else {
        api.applyTransaction({ update: [node.data] });
    }
}

function SatirSec(api, rowIndex) {
    var node = api.getDisplayedRowAtIndex(rowIndex);
    if (node) {
        api.deselectAll();
        node.setSelected(true);
        api.ensureIndexVisible(rowIndex);
    }
}

function SatirEkle(kontrolId, arayaEkle) {
    var api = window[kontrolId + "_gridApi"];
    if (!api) {
        console.warn("Grid API bulunamadı:", kontrolId);
        return;
    }

    var yeniSatir = {};
    var colDefs = api.getColumnDefs();
    for (var i = 0; i < colDefs.length; i++) {
        yeniSatir[colDefs[i].field] = null;
    }

    var addIndex = undefined;
    if (arayaEkle) {
        var sel = api.getSelectedNodes()[0];
        addIndex = sel ? sel.rowIndex : 0;
    }

    api.applyTransaction({
        add: [yeniSatir],
        addIndex: addIndex
    });

    // yeni satırı seç (isteğe bağlı)
    api.deselectAll();
    var rowIndex = arayaEkle
        ? (addIndex || 0)
        : api.getDisplayedRowCount() - 1;
    SatirSec(api, rowIndex)
}

function ArayaSatirEkle(kontrolId) {
    SatirEkle(kontrolId, true);
}

function BosSatirEkle(kontrolId) {
    SatirEkle(kontrolId, false);
}

function SatirSil(kontrolId) {
    var api = window[kontrolId + "_gridApi"];
    if (!api) {
        console.warn("Grid API bulunamadı:", kontrolId);
        return;
    }

    var selNodes = api.getSelectedNodes();
    if (!selNodes || selNodes.length === 0) {
        console.warn("Silinecek satır seçili değil.");
        return;
    }

    var silinecekVeriler = [];
    for (var i = 0; i < selNodes.length; i++) {
        silinecekVeriler.push(selNodes[i].data);
    }

    api.applyTransaction({
        remove: silinecekVeriler
    });

    // Yeni seçimi ayarla (FarPoint hissi için)
    var yeniIndex = selNodes[0].rowIndex;
    if (yeniIndex >= api.getDisplayedRowCount())
        yeniIndex = api.getDisplayedRowCount() - 1;

    if (yeniIndex >= 0)
        SatirSec(api, yeniIndex);
}
