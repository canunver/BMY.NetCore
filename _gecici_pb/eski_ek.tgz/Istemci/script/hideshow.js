﻿	function hideshow(saklaAlan)
	{
		if (!document.getElementById|document.all)
			return;
		else
		{
			if (document.getElementById)
				oalan = eval ("document.getElementById('" + saklaAlan + "')");
			else
				oalan = eval ("document.getElementById('" + saklaAlan+ "')");
		}
			
		if (oalan.style.display=="none")
			oalan.style.display="" ;
		else
			oalan.style.display="none";
	}
	
	function kontrolluhideshow(alan,kontrolAlan,kontrolDeger)
	{
		var deger=new Boolean(kontrolDeger);
		
		if (!document.getElementById|document.all)
			return;
		else
		{
			oalan = eval ("document.getElementById('" + alan+ "')");
			okontrolalan=eval ("document.getElementById('" + kontrolAlan+ "')");
		}	

		if (okontrolalan.checked==deger)
			oalan.style.display="";
		else
			oalan.style.display="none";
	}