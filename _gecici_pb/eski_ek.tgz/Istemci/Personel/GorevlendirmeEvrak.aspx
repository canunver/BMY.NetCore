﻿<%@ Page Language="C#" CodeBehind="GorevlendirmeEvrak.aspx.cs" Inherits="Personel.GorevlendirmeEvrak" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <meta http-equiv="Pragma" content="no-cache" />
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript" src="ModulScripts/Gorevlendirme.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript">
        function VeriGoster(kod) {
            parent.document.all.hdnTCKimlikNo.value = kod;
            parent.document.forms[0].submit();
            parent.hidePopWin();
        }
    </script>
</head>
<body style="margin: 10px; text-align: left;">
    <form id="aspnetForm" runat="server">
    <input type="hidden" id="hdnGorevKod" runat="server" />
    <div class="form" style="width: 99%;" align="center">
        <div class="row">
            <div class="yaziAlan">
                Evrak Birim Kodu</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan" style="width: 80px;">
                <asp:DropDownList ID="ddlEvrakBirimKod" runat="server">
                </asp:DropDownList>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                Geldiği Yer</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan" style="width: 80px;">
                <asp:TextBox ID="txtGeldigiYer" runat="server" CssClass="veriAlan"></asp:TextBox></div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                Evrak Konu</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan" style="width: 80px;">
                <asp:TextBox ID="txtKonu" runat="server" CssClass="veriAlan"></asp:TextBox></div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                İmza Bilgisi</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan" style="width: 80px;">
                <asp:TextBox ID="txtImzaBilgi" runat="server" CssClass="veriAlan"></asp:TextBox></div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                Paraf</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan" style="width: 80px;">
                <asp:TextBox ID="txtParaf" runat="server" CssClass="veriAlan"></asp:TextBox></div>
        </div>
        <div class="row">
            <div class="footer">
                &nbsp;</div>
        </div>
        <div class="row">
            <center>
                <asp:Button ID="btnEvrakKaydet" runat="server" Text="Evrak Kaydet" CssClass="dugme"
                    OnClick="btnEvrakKaydet_Click" />
            </center>
        </div>
        <div class="row">
            <div class="footer">
                &nbsp;</div>
        </div>
    </div>
    </form>
</body>
</html>
