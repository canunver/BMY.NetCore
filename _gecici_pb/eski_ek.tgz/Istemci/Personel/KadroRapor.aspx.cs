﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class KadroRapor : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Kadro Bilgileri Raporu";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            lblHata.Visible = false;

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            this.txtUnvan.Attributes.Add("onblur", "kodAdGetir('22','lblUnvan',true,new Array('txtUnvan'),'KONTROLDENOKU');");

            if (!IsPostBack)
            {
                SinifDoldur();
                UstBirimDoldur();
                VizeDoldur();
            }

            if (txtUnvan.Text.Trim() != "")
                lblUnvan.Text = GenelIslemler.KodAd(22, txtUnvan.Text.Trim(), true);
        }

        protected void btnListele_Click(object sender, EventArgs e)
        {
            Tablo XLS = GenelIslemler.NewTablo();
            int satir = 0;
            int sutun = 0;
            int kaynakSatir = 0;

            string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            string sablonAd = "PER-KadroRapor.xlt";
            XLS.DosyaAc(raporSablonYol + "\\OMK\\" + sablonAd, sonucDosyaAd);

            XLS.HucreAdAdresCoz("BaslaSatir", ref kaynakSatir, ref sutun);

            satir = kaynakSatir;

            ObjectArray klar = new ObjectArray();
            Kadro kriter = new Kadro();
            kriter.teskilat = OrtakFonksiyonlar.ConvertToInt(ddlTeskilat.SelectedValue, 0);
            kriter.ustBirim = OrtakFonksiyonlar.ConvertToInt(ddlUstBirim.SelectedValue, 0);
            kriter.sinif = OrtakFonksiyonlar.ConvertToInt(ddlSinif.SelectedValue, 0);
            kriter.unvan = OrtakFonksiyonlar.ConvertToInt(txtUnvan.Text, 0);
            kriter.kadro = OrtakFonksiyonlar.ConvertToInt(txtKadro.Text, 0);
            kriter.vizeTarih = new TNSDateTime(ddlVizeTarihi.SelectedItem.Text);
            kriter.sayIl = OrtakFonksiyonlar.ConvertToInt(txtSayIl.Text, 0);
            kriter.sayTip = OrtakFonksiyonlar.ConvertToInt(txtSayTip.Text, 0);
            kriter.sayIlce = OrtakFonksiyonlar.ConvertToInt(txtSayIlce.Text, 0);

            klar = servisPER.KadroRapor(kullanan, kriter);

            XLS.HucreAdBulYaz("txtVizeTarihi", kriter.vizeTarih.ToString());

            int eTeskilat = 0;
            int eUstBirim = 0;
            int eSinif = 0;
            int eUnvan = 0;
            int eSayIl = 0;
            int eSayTip = 0;
            int eSayIlce = 0;
            string durum = "";
            foreach (Kadro k in klar.objeler)
            {
                if (eTeskilat != k.teskilat || eUstBirim != k.ustBirim || eSinif != k.sinif || eUnvan != k.unvan || eSayIl != k.sayIl || eSayTip != k.sayTip || eSayIlce != k.sayIlce)
                {
                    satir++;
                    XLS.SatirAc(satir, 1);
                    XLS.HucreKopyala(kaynakSatir, sutun, kaynakSatir, sutun + 25, satir, sutun);
                    durum = "";
                }

                XLS.HucreDegerYaz(satir, 0, k.teskilat + "-" + k.teskilatAd);
                XLS.HucreDegerYaz(satir, 1, k.ustBirim + "-" + k.ustBirimAd);
                XLS.HucreDegerYaz(satir, 2, k.sinif + "-" + k.sinifAd);
                XLS.HucreDegerYaz(satir, 3, k.unvan + "-" + k.unvanAd);
                XLS.HucreDegerYaz(satir, 4, k.sayIl.ToString() + k.sayTip.ToString() + k.sayIlce.ToString() + "-" + k.muhasebeAd);

                if (!kriter.vizeTarih.isNull)
                    XLS.HucreDegerYaz(satir, 4 + k.kadro, k.oncesiAdet.ToString() + "/" + k.adet.ToString());
                else
                    XLS.HucreDegerYaz(satir, 4 + k.kadro, k.adet.ToString());

                if (!kriter.vizeTarih.isNull)
                {
                    if ((k.oncesiAdet + k.adet) >= 0 && durum != "HATA")
                    {
                        durum = "TAMAM";
                        XLS.HucreDegerYaz(satir, 4 + 16, durum);
                    }
                    else
                    {
                        durum = "HATA";
                        XLS.HucreDegerYaz(satir, 4 + 16, durum);
                        XLS.ArkaPlanRenk(satir, 4 + 16, TabloRenk.YELLOW2);
                    }
                }

                eTeskilat = k.teskilat;
                eUstBirim = k.ustBirim;
                eSinif = k.sinif;
                eUnvan = k.unvan;
                eSayIl = k.sayIl;
                eSayTip = k.sayTip;
                eSayIlce = k.sayIlce;
            }
            XLS.DosyaSaklaTamYol();
            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "KadroRapor", true, GenelIslemler.ExcelTur());
        }

        void SinifDoldur()
        {
            ObjectArray dler = new ObjectArray();
            dler = servisPER.SinifListele(new Sinif());
            ddlSinif.Items.Add(new ListItem("", ""));

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    foreach (Sinif d in dler.objeler)
                        ddlSinif.Items.Add(new ListItem(d.kod.ToString() + "-" + d.ad, d.kod.ToString()));
                }
            }
        }

        void UstBirimDoldur()
        {
            ObjectArray dler = new ObjectArray();
            dler = servisPER.UstBirimListele(new UstBirim());
            ddlUstBirim.Items.Add(new ListItem("", ""));

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    foreach (UstBirim d in dler.objeler)
                        ddlUstBirim.Items.Add(new ListItem(d.kod.ToString() + "-" + d.ad, d.kod.ToString()));
                }
            }
        }

        void VizeDoldur()
        {
            ddlVizeTarihi.Items.Add(new ListItem("Kadro Mevcudu", ""));

            ObjectArray dler = new ObjectArray();
            dler = servisPER.KadroVizeListele();
            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    foreach (string d in dler.objeler)
                        ddlVizeTarihi.Items.Add(new ListItem(d, d));
                }
            }
        }
    }
}