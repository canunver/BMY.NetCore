﻿<%@ Page Language="C#" CodeBehind="Personel.aspx.cs" Inherits="Personel.Personel"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
	<title></title>
	<link href="../App_themes/Form.css" type="text/css" rel="stylesheet"/>
	<link href="../App_themes/popupDialog.css" type="text/css" rel="stylesheet" />
	<script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
	<script language="JavaScript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>
	<script language="Javascript" type="text/javascript" src="../script/popupDialog.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript" src="../script/popupDialog2.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript">
        var personelListeGoster=false;
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <asp:label id="lblHata" Visible="false" Runat="server"></asp:label>
    <input type="hidden" id="hdnTCKimlikNo" runat="server" />
    <div class="form">
        <div class="kolonArasi">
            <fieldset style="margin:0px;padding:5px;">
	            <table cellpadding="2" cellspacing="2" width="100%">
	                <tr>
	                    <td>
	                        <asp:Button runat="server" ID="btnKaydet" CssClass="dugme" Text="Kaydet" OnClick="btnKaydet_Click" Width="80" />
                            <asp:Button runat="server" ID="btnAra" CssClass="dugme" Text="Bul" OnClick="btnAra_Click" Width="80" />
                            <asp:Button runat="server" ID="btnTemizle" CssClass="dugme" Text="Temizle" OnClick="btnTemizle_Click" Width="80" />
                            <asp:Button runat="server" ID="btnYazdir" CssClass="dugme" Text="Yazdır" OnClick="btnYazdir_Click" Width="80" />
                        </td>
	                    <td align="right">
                            <input type="button" id="btnDil" class="dugme" style="width:70px;" value="Dil Bilgisi" onclick="Javascript:PersonelDilAc();return false;" />
                            <input type="button" id="btnKurs" class="dugme" style="width:70px;" value="Kurs Bilgisi" onclick="Javascript:PersonelKursAc();return false;" />
                            <input type="button" id="btnAile" class="dugme" style="width:70px;" value="Aile Bilgisi" onclick="Javascript:PersonelAileAc();return false;" />
	                    </td>
	                </tr>
	            </table>
	        </fieldset>
            <asp:Label ID="lblGuncelleme" runat="server"></asp:Label>
            <fieldset class="row">
                <legend><img src="../App_Themes/images/masa.gif" alt="Birim Bilgileri" width="16" height="16" align="left" />Birim Bilgileri</legend>
                <div class="row">
                    <div class="yaziAlanK">Muhasebe Kodu</div>
		            <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:TextBox id="txtMuhasebe" runat="server" CssClass="veriAlan" MaxLength="5" Columns="7"></asp:TextBox></div>
                    <div class="veriAlan"><input type="image" alt="Muhasebe Listesi" style="height:14px;width:16px;" class="veriAlan" onclick="javascript:MuhasebeGoster();return false;" tabindex="100" src="../App_themes/images/bul1.gif" /></div>
			        <div class="kolonArasi"></div>
			        <div class="veriAlan"><asp:label id="lblMuhasebeAd" Width="100%" runat="server" CssClass="veriAlan"></asp:label></div>
                </div>
                <div class="row">
                    <div class="yaziAlanK">Birim Kodu</div>
		            <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:TextBox id="txtBirim" runat="server" CssClass="veriAlan" MaxLength="3" Columns="7"></asp:TextBox></div>
                    <div class="veriAlan"><input type="image" alt="Muhasebe Birim Listesi" style="height:14px;width:16px;" class="veriAlan" onclick="javascript:MuhasebeBirimGoster();return false;" tabindex="100" src="../App_themes/images/bul1.gif" /></div>
			        <div class="kolonArasi"></div>
			        <div class="veriAlan"><asp:label id="lblBirimAd" Width="100%" runat="server" CssClass="veriAlan"></asp:label></div>
                </div>
	        </fieldset>
            <fieldset class="row">
                <legend><img src="../App_Themes/images/personel.gif" alt="Personel Bilgileri" width="16" height="16" align="left" />Personel Bilgileri</legend>
	            <div class="row">
		            <div class="yaziAlanK">T.C.Kimlik No&nbsp;<a href="http://tckimlik.nvi.gov.tr/Web/" target="_blank"><img alt="Kullanıcının T.C. Kimlik Numarası öğrenmek için lütfen tıklayın" src="../App_themes/images/dunya.gif" /></a></div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtMernisNo" runat="server" CssClass="veriAlan" Columns="20" MaxLength="11"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="veriAlan"><asp:ImageButton id="imgKimlik" tabIndex="100" runat="server" CssClass="veriAlan" Height="17" Width="22" OnClick="imgKimlik_Click" ImageUrl="../App_themes/images/kimlik4.gif" ToolTip="Verilen T.C.Kimlik Numarasından ad ve soyad bilgilerini getir"></asp:ImageButton></div>
		            <div class="kolonArasi"></div>
		            <div class="veriAlan"><asp:label id="lblMernisHata" runat="server" CssClass="veriAlan" Width="100%"></asp:label></div>
                </div>
	            <div class="row">
		            <div class="yaziAlanK">Sicil No</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox ID="txtSicilNo" runat="server" CssClass="veriAlan" Columns="20" MaxLength="10"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlanK">Adı</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtAd" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlanK">Soyadı</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtSoyad" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlanK">Baba Adı</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtBaba" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlanK">Ana Adı</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtAna" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlanK">Doğum Tarihi</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtDogumTarih" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlanK">Cinsiyeti</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan">
		                <asp:DropDownList ID="ddlCinsiyet" runat="server" CssClass="veriAlanDDL" Width="140">
                            <asp:ListItem Text="" Value=""></asp:ListItem>
		                    <asp:ListItem Text="Erkek" Value="1"></asp:ListItem>
		                    <asp:ListItem Text="Kadın" Value="2"></asp:ListItem>
		                </asp:DropDownList>
		            </div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">Medeni Hali</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;">
		                <asp:DropDownList ID="ddlMedeniHali" runat="server" CssClass="veriAlanDDL" Width="100%">
		                    <asp:ListItem Text="" Value=""></asp:ListItem>
		                    <asp:ListItem Text="Bekar" Value="1"></asp:ListItem>
		                    <asp:ListItem Text="Evli" Value="2"></asp:ListItem>
		                </asp:DropDownList>
		            </div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlan">Kan Grubu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan">
		                <asp:DropDownList ID="ddlKanGrubu" runat="server" CssClass="veriAlanDDL" Width="140">
		                    <asp:ListItem Text="" Value=""></asp:ListItem>
		                    <asp:ListItem Text="ABRH-"></asp:ListItem>
		                    <asp:ListItem Text="ABRH+"></asp:ListItem>
		                    <asp:ListItem Text="ARH-"></asp:ListItem>
		                    <asp:ListItem Text="ARH+"></asp:ListItem>
		                    <asp:ListItem Text="BRH-"></asp:ListItem>
		                    <asp:ListItem Text="BRH+"></asp:ListItem>
		                    <asp:ListItem Text="ORH-"></asp:ListItem>
		                    <asp:ListItem Text="ORH+"></asp:ListItem>
		                </asp:DropDownList>
		            </div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">İş Telefonu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtIsTel" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlan">Cep Telefonu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtCepTel" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">Ev Telefonu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtEv" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlan">Faks Numarası</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtFaks" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">Vergi Dairesi</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtVergiDairesi" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlan">Adresi</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtAdres" runat="server" CssClass="veriAlan" Columns="20" MaxLength="255"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">e-posta</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtEPosta" runat="server" CssClass="veriAlan" Columns="20" MaxLength="50"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlan">Sosyal Güvenlik No</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtEmekliSicilNo" runat="server" CssClass="veriAlan" Columns="20" MaxLength="50"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">Askerlik Durumu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;">
		            <asp:DropDownList ID="ddlAskerlik" runat="server" CssClass="veriAlanDDL" Width="100%">
		                <asp:ListItem Text="" Value=""></asp:ListItem>
		                <asp:ListItem Text="Tamamladı" Value="1"></asp:ListItem>
		                <asp:ListItem Text="Tecilli" Value="2"></asp:ListItem>
		                <asp:ListItem Text="Muaf" Value="3"></asp:ListItem>
		                <asp:ListItem Text="Askerde" Value="4"></asp:ListItem>
		                <asp:ListItem Text="Bakaya" Value="5"></asp:ListItem>
		                <asp:ListItem Text="Yapmadı" Value="6"></asp:ListItem>
		            </asp:DropDownList></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlan">Öğrenim Durumu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:DropDownList ID="ddlOgrenim" runat="server" CssClass="veriAlanDDL"></asp:DropDownList></div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">Sağlık Karne No</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtKarneNo" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlan">Eş Durumu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan">
		                <asp:DropDownList ID="ddlEsDurum" runat="server" CssClass="veriAlanDDL">
		                    <asp:ListItem Text="" Value=""></asp:ListItem>
		                    <asp:ListItem Text="Çalışıyor" Value="1"></asp:ListItem>
		                    <asp:ListItem Text="Çalışıyor (Çocuk Yardımı Alıyor)" Value="2"></asp:ListItem>
		                    <asp:ListItem Text="Çalışmıyor" Value="3"></asp:ListItem>
		                    <asp:ListItem Text="Ücretsiz İzin" Value="4"></asp:ListItem>
		                </asp:DropDownList>
		            </div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">Durumu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;">
		                <asp:DropDownList ID="ddlDurum" runat="server" CssClass="veriAlanDDL" Width="100%">
		                    <asp:ListItem Text="" Value=""></asp:ListItem>
		                    <asp:ListItem Text="Çalışıyor" Value="1"></asp:ListItem>
		                    <asp:ListItem Text="Vekaleten" Value="2"></asp:ListItem>
		                    <%--<asp:ListItem Text="Geçici Görevlendirme" Value="3"></asp:ListItem>--%>
		                    <asp:ListItem Text="Geçici Görevli (Gelen)" Value="10"></asp:ListItem>
		                    <asp:ListItem Text="Geçici Görevli (Giden)" Value="11"></asp:ListItem>
		                    <asp:ListItem Text="Ücretsiz İzin" Value="5"></asp:ListItem>
		                    <asp:ListItem Text="İstifa" Value="6"></asp:ListItem>
		                    <asp:ListItem Text="Emekli" Value="7"></asp:ListItem>
		                    <asp:ListItem Text="Nakil" Value="8"></asp:ListItem>
		                    <asp:ListItem Text="Vefat" Value="9"></asp:ListItem>
		                </asp:DropDownList>
		            </div>
                </div>
	        </fieldset>

            <fieldset class="row">
                <legend><img src="../App_Themes/images/banka.gif" alt="Banka Bilgileri" width="16" height="16" align="left" />Banka Bilgileri</legend>
                <div class="row">
		            <div class="yaziAlanK">Banka</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:DropDownList ID="ddlBanka" runat="server" CssClass="veriAlanDDL"></asp:DropDownList></div>
                </div>
                <div class="row">
		            <div class="yaziAlanK">Şube Kodu</div>
		            <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:TextBox id="txtBankaSubeKodu" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></div>
			        <div class="veriAlan"><input type="image" alt="Banka Şube Listesi" class="veriAlan" onclick="javascript:BankaSubeEkle();return false;" tabindex="100" src="../App_themes/images/bul1.gif" /></div>
			        <div class="kolonArasi"></div>
			        <div class="veriAlan"><asp:label id="lblBankaSubeAd" Width="100%" runat="server" CssClass="veriAlan"></asp:label></div>
                </div>
                <div class="row">
		            <div class="yaziAlanK">Hesap No/IBAN No</div>
		            <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:TextBox id="txtBankaHesapNo" runat="server" CssClass="veriAlan" Columns="30" MaxLength="100"></asp:TextBox></div>
                </div>
	        </fieldset>
            
            <fieldset class="row">
                <legend><img src="../App_Themes/images/evrakBirim.gif" alt="Evrak Birim Bilgileri" width="16" height="16" align="left" />Evrak Birim Bilgileri</legend>
                <div class="row">
		            <div class="yaziAlan">Evrak Birim Kodu</div>
		            <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:TextBox id="txtEvrakBirimKod" runat="server" CssClass="veriAlan" Columns="20" MaxLength="50"></asp:TextBox></div>
			        <div class="veriAlan"><input type="image" alt="Evrak Birim Listesi" class="veriAlan" onclick="javascript:EvrakBirimEkle();return false;" tabindex="100" src="../App_themes/images/bul1.gif" /></div>
			        <div class="kolonArasi"></div>
			        <div class="veriAlan"><asp:label id="lblEvrakBirimKod" Width="100%" runat="server" CssClass="veriAlan"></asp:label></div>
                </div>
	        </fieldset>

            <fieldset class="row">
                <legend><img src="../App_Themes/images/memuriyet.gif" alt="Memuriyet Bilgileri" width="16" height="16" align="left" />Memuriyet Bilgileri</legend>
                <div class="row">
                    <div class="yaziAlanK">İstihdam Şekli</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;">
		                <select id="ddlIstihdamm" runat="server" onchange="javascript:PanelGoster();return false;">
		                </select>
		            </div>
		            <%--<div class="veriAlan" style="width:140px;">
		                <asp:DropDownList ID="ddlIstihdam" runat="server" CssClass="veriAlanDDL" AutoPostBack="true" OnSelectedIndexChanged="ddlIstihdam_SelectedIndexChanged">
		                    <asp:ListItem Text="" Value=""></asp:ListItem>
		                    <asp:ListItem Text="Memur" Value="1"></asp:ListItem>
		                    <asp:ListItem Text="Sözleşmeli" Value="2"></asp:ListItem>
		                    <asp:ListItem Text="Geçici Personel" Value="3"></asp:ListItem>
		                </asp:DropDownList>
		            </div>--%>
                </div>
	            <div class="row">
		            <div class="yaziAlan">Memur. Baş. Tarihi</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtMemurBaslaTarih" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">İşe Giriş Tarihi</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtIseGirisTarihi" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlan">İşten Çıkış Tarihi</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtIstenCikisTarihi" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></div>
                </div>
	        </fieldset>

            <fieldset class="row"">
                <legend><img src="../App_Themes/images/kadro.gif" alt="Kadro Bilgileri" width="16" height="16" align="left" />Kadro Bilgileri</legend>
                <div class="row">
                    <div class="yaziAlanK">Üst Birim Kodu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:DropDownList ID="ddlUstBirim" runat="server" CssClass="veriAlanDDL"></asp:DropDownList></div>
                </div>
                <div class="row">
                    <div class="yaziAlanK">Teşkilat Kodu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;">
		                <asp:DropDownList ID="ddlTeskilat" runat="server" CssClass="veriAlanDDL">
		                    <asp:ListItem Text="" Value=""></asp:ListItem>
		                    <asp:ListItem Text="Merkez" Value="1"></asp:ListItem>
		                    <asp:ListItem Text="Taşra" Value="2"></asp:ListItem>
		                </asp:DropDownList>
		            </div>
                </div>
                <div class="row">
                    <div class="yaziAlanK">Sınıf Kodu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:DropDownList ID="ddlSinif" runat="server" CssClass="veriAlanDDL"></asp:DropDownList></div>
                </div>
	            <div class="row">
		            <div class="yaziAlanK">Ünvan Kodu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtUnvan" runat="server" CssClass="veriAlan" MaxLength="5" Columns="7"></asp:TextBox></div>
		            <div class="veriAlan"><input type="image" alt="Ünvan Listesi" class="veriAlan" onclick="javascript:UnvanEkle();return false;" tabindex="100" src="../App_themes/images/bul1.gif" /></div>
			        <div class="kolonArasi"></div>
		            <div class="veriAlan"><asp:label id="lblUnvan" Width="100%" runat="server" CssClass="veriAlan"></asp:label></div>
                </div>
                <div class="row">
		            <div class="yaziAlan">Kıdem Ay/Yıl</div>
		            <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:TextBox id="txtKidemAy" runat="server" CssClass="veriAlan" MaxLength="2" Columns="5"></asp:TextBox></div>
                    <div class="ikiNokta">/</div>
                    <div class="veriAlan"><asp:TextBox id="txtKidemYil" runat="server" CssClass="veriAlan" MaxLength="4" Columns="5"></asp:TextBox></div>
                </div>
                <div class="row">
                    <br />
                    <table>
                        <tr>
                            <td></td>
                            <td></td>
                            <td class="yaziAlanZorunluK" width="60">Derece</td>
                            <td class="yaziAlanZorunluK" width="60">Kademe</td>
                            <td class="yaziAlanZorunluK" width="100">Tarih</td>
                            <td class="yaziAlanZorunluK" width="90">Ek Gösterge</td>
                        </tr>
                        <tr>
                            <td class="yaziAlanK">Kadro</td>
                            <td class="ikiNokta">:</td>
                            <td><asp:TextBox id="txtKadroDerece" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                            <td></td>
                            <td><asp:TextBox id="txtKadroDereceTarih" runat="server" CssClass="veriAlan" MaxLength="10" Columns="10"></asp:TextBox></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td class="yaziAlan">Kazanılmış Hak</td>
                            <td class="ikiNokta">:</td>
                            <td><asp:TextBox id="txtKazHakDerece" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                            <td><asp:TextBox id="txtKazHakKademe" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                            <td><asp:TextBox id="txtKazHakTarih" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td class="yaziAlan">Ödemeye Esas</td>
                            <td class="ikiNokta">:</td>
                            <td><asp:TextBox id="txtOdeEsDerece" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                            <td><asp:TextBox id="txtOdeEsKademe" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                            <td><asp:TextBox id="txtOdeEsTarih" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></td>
                            <td><asp:TextBox id="txtOdeEsEkGosterge" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                        </tr>
                        <tr>
                            <td class="yaziAlan">Emekliye Esas</td>
                            <td class="ikiNokta">:</td>
                            <td><asp:TextBox id="txtEmEsDerece" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                            <td><asp:TextBox id="txtEmEsKademe" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                            <td><asp:TextBox id="txtEmEsTarih" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></td>
                            <td><asp:TextBox id="txtEmEsEkGosterge" runat="server" CssClass="veriAlan" Columns="5" MaxLength="5"></asp:TextBox></td>
                        </tr>
                    </table>
                </div>
	        </fieldset>
	        
	        <fieldset class="row" id="fldPersonelKatsayi">
                <legend><img src="../App_Themes/images/memuriyet.gif" alt="Personel Kümülatif Toplam Bilgileri" width="16" height="16" align="left" />Personel Kümülatif Toplam Bilgileri</legend>
                <div class="row">
                    <div class="yaziAlanK">Yıl</div>
                    <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:dropdownlist id="ddlYil" runat="server" CssClass="veriAlanDDL"></asp:dropdownlist></div>
                    <div class="kolonArasi"></div>
                    <div class="yaziAlanK">Ay</div>
                    <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:dropdownlist id="ddlAy" runat="server" CssClass="veriAlanDDL"></asp:dropdownlist></div>
                    <div class="kolonArasi"></div>
                    <div class="yaziAlanK">Kümülatif Toplam</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtKumulatifToplam" runat="server" CssClass="veriAlan" Columns="10" MaxLength="10"></asp:TextBox></div>
                </div>
                <div class="row">
                    <div class="yaziAlanK">Son Kümülatif Toplam</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:Label id="lblSonKumulatifToplam" runat="server" CssClass="veriAlan"></asp:Label></div>
                </div>
	           
	        </fieldset>
        </div>
    </div>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
    <script language="Javascript" type="text/javascript">
        if (personelListeGoster)
        window.setTimeout("showPopWin('PersonelListe.aspx' , 600, 500, true, null);", 20);
    </script>
</body>
</html>
