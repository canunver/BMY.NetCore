﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class GorevlendirmeYerTarih : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();
        public string personel = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Görevlendirme Yer Tarih Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            lblHata.Visible = false;

            //Sayfaya giriş izni varmı?
            if (!TNS.PER.Yetki.YetkiVarMiOkumaya(kullanan))
                GenelIslemler.SayfayaGirmesin(true);

            personel = Request.QueryString["tcKimlikNo"] + "";

            if (!IsPostBack)
            {

            }

        }

        protected void btnKaydet_Click(object sender, EventArgs e)
        {
            Sonuc kontrol = KontrolEt();
            if (kontrol.islemSonuc)
            {
                ObjectArray liste = new ObjectArray();
                if (Session["GorevlendirmeYerTarih"] != null)
                {
                    liste = (ObjectArray)Session["GorevlendirmeYerTarih"];
                }

                TNS.PER.GorevYerTarih yerTarih = GorevlendirmeYerTarihNesneDoldur();
                liste.objeler.Add(yerTarih);
                Session["GorevlendirmeYerTarih"] = liste;

                ClientScript.RegisterStartupScript(this.GetType(), "kaydet", "GorevlendirmeYerTarihKaydet();", true);
            }
            else
            {
                GenelIslemler.MesajKutusu(this, kontrol.hataStr);
            }
        }

        private TNS.PER.GorevYerTarih GorevlendirmeYerTarihNesneDoldur()
        {
            TNS.PER.GorevYerTarih yerTarih = new TNS.PER.GorevYerTarih();
            string yer = string.Empty;
            string ilKod = string.Empty;
            string ilceKod = string.Empty;
            string[] ilIlceKod = null;

            yer = txtBulunduguYer.Value;
            ilIlceKod = yer.Split('-');
            if (ilIlceKod.Length > 1)
            {
                yerTarih.bulunduguIlKod = ilIlceKod[0];
                yerTarih.bulunduguIlceKod = ilIlceKod[1];
            }
            yer = txtGidecegiYer.Value;
            ilIlceKod = yer.Split('-');
            if (ilIlceKod.Length > 1)
            {
                yerTarih.gidecegiIlKod = ilIlceKod[0];
                yerTarih.gidecegiIlceKod = ilIlceKod[1];
            }

            yerTarih.bulunduguYer = txtBulunduguYer.Text;
            yerTarih.gidecegiYer = txtGidecegiYer.Text;
            yerTarih.baslangicTarihi = new TNSDateTime(txtGorevBaslangicTarihi.Text);
            yerTarih.bitisTarihi = new TNSDateTime(txtGorevBitisTarihi.Text);
            return yerTarih;
        }

        private Sonuc KontrolEt()
        {
            Sonuc sonuc = new Sonuc(true, "", "");

            string hata = string.Empty;
            hata = KontrolBaslikBilgileri();

            if (string.IsNullOrEmpty(hata))
            {
                if (Session["GorevlendirmeYerTarih"] != null)
                {
                    ObjectArray liste = new ObjectArray();
                    liste = (ObjectArray)Session["GorevlendirmeYerTarih"];

                    TNS.PER.GorevYerTarih yerTarih = GorevlendirmeYerTarihNesneDoldur();
                    bool listedeVarMi = KontrolListedeVarMi(liste, yerTarih);

                    if (listedeVarMi)
                    {
                        sonuc.islemSonuc = false;
                        sonuc.hataStr = "Bu kayıt daha önce listeye eklenmiş.";
                    }
                }
            }
            else
            {
                sonuc.islemSonuc = false;
                sonuc.hataStr = hata;
            }

            return sonuc;
        }
        private string KontrolBaslikBilgileri()
        {
            string hata = string.Empty;

            if (txtBulunduguYer.Text.Trim() == string.Empty)
                hata += "Bulunduğu yer bilgisi boş bırakılamaz.<br>";
            if (txtBulunduguYer.Value.Trim() == string.Empty)
                hata += "Bulunduğu yer bilgisinde hata!.<br>";
            if (txtGidecegiYer.Text.Trim() == string.Empty)
                hata += "Gideceği yer bilgisi boş bırakılamaz.<br>";
            if (txtGidecegiYer.Value.Trim() == string.Empty)
                hata += "Gideceği yer bilgisinde hata!.<br>";
            if (txtGorevBaslangicTarihi.Text == string.Empty)
                hata += "Görev Başlangıç Tarihi boş bırakılamaz.<br>";
            if (txtGorevBitisTarihi.Text.Trim() == string.Empty)
                hata += "Görev Bitiş Tarihi boş bırakılamaz.<br>";

            if (hata == string.Empty)
            {
                TNSDateTime baslangicTarihi = new TNSDateTime(txtGorevBaslangicTarihi.Text);
                if (baslangicTarihi.isNull)
                    hata += "Görev Başlangıç Tarihi formatı yanlış girilmiş.";

                TNSDateTime bitisTarihi = new TNSDateTime(txtGorevBitisTarihi.Text);
                if (bitisTarihi.isNull)
                    hata += "Görev Bitiş Tarihi formatı yanlış girilmiş.";

                if (hata == string.Empty)
                {
                    if (!(baslangicTarihi.Yil <= bitisTarihi.Yil && baslangicTarihi.Ticks < bitisTarihi.Ticks))
                        hata = "Görev Başlangıç Tarihi, Görev Bitiş Tarihinden büyük olamaz.<br>";
                }
            }
            return hata;
        }
        private bool KontrolListedeVarMi(ObjectArray liste, TNS.PER.GorevYerTarih yerTarih)
        {
            //KmL
            //yer ve tarih bilgilerine ait kontroller arttrılabilir.
            if (liste != null && liste.ObjeSayisi > 0)
            {
                foreach (TNS.PER.GorevYerTarih yt in liste.objeler)
                {
                    //if (yt.bulunduguYerKod == yerTarih.bulunduguYerKod && yt.gidecegiYerKod == yerTarih.gidecegiYerKod)
                    return false;
                }
            }
            return false;
        }


    }
}
