﻿<%@ Page Language="C#" CodeBehind="KadroGiris.aspx.cs" Inherits="Personel.KadroGiris"  %>
<%@ Register TagPrefix="Farpoint" Namespace="FarPoint.Web.Spread" Assembly="FarPoint.Web.Spread" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
	<title></title>
	<link href="../App_themes/Form.css" type="text/css" rel="stylesheet"/>
	<link href="../App_themes/popupDialog.css" type="text/css" rel="stylesheet" />
	<script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
	<script language="Javascript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>
	<script language="JavaScript" type="text/javascript" src="../script/popupDialog.js?mc=03022015"></script>
    <script language="JavaScript" type="text/javascript" src="../script/popupDialog2.js?mc=03022015"></script>
	<script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal id="ltlUstBolum" runat="server"></asp:Literal>
	<asp:label id="lblHata" Visible="false" Runat="server"></asp:label>
    <div class="form">
	    <table width="600" cellspacing="2" cellpadding="2" border="0">
		    <tr>
			    <td>
				    <table>
					    <tr>
						    <td class="yaziAlanK" style="width:110px;">Dosya&nbsp;Yükle</td>
						    <td class="yaziAlanK" style="width:5px;">:</td>
						    <td class="veriAlan" style="width:150px;"><input class="dugme" id="fileListe" type="file" size="30" name="fileListe" runat="server" /></td>
					    </tr>
				    </table>
			    </td>
		    </tr>
	    </table>
	</div>
	<br>
	<center>
	    <asp:button id="btnDosyaYukle" runat="server" CssClass="dugme" Text="Tahsis Tenkis Bilgilerini Yükle" OnClick="btnDosyaYukle_Click"></asp:button>
	</center>
    <asp:Literal id="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
