﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class GorevlendirmeAna : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }
    }
}
