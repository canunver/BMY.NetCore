﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;
using WebServisler.EvrakServis;
//using WebServisler.EvrakServisLocal;

namespace Personel
{
    public partial class GorevlendirmeEvrak : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Görevlendirme Evrak Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);

            //Sayfaya giriş izni varmı?
            if (!TNS.PER.Yetki.YetkiVarMiOkumaya(kullanan))
                GenelIslemler.SayfayaGirmesin(true);

            if (!IsPostBack)
            {
                EvrakBirimKodDoldur();
            }
        }

        private void EvrakBirimKodDoldur()
        {
            EvrakServis servis = new EvrakServis();
            string[] liste = servis.EvrakBirimKodListeGetir(kullanan.kullaniciKodu, kullanan.parola);
            for (int i = 0; i < liste.Length; i++)
            {
                ddlEvrakBirimKod.Items.Add(new ListItem(liste[i], liste[i]));
            }
        }

        protected void btnEvrakKaydet_Click(object sender, EventArgs e)
        {
            EvrakServis servis = new EvrakServis();
            EvrakSinifW evrak = new EvrakSinifW();

            evrak.evrakBirimKodu = ddlEvrakBirimKod.SelectedItem.Text;
            evrak.bulunduguYer = evrak.evrakBirimKodu;
            evrak.yil = DateTime.Now.Year;
            evrak.evrakOlusturmaTarihi = DateTime.Now.ToString();
            evrak.evrakTarih = DateTime.Now.ToString();
            evrak.evrakTipi = ENUMEvrakTipi.GELEN;
            //evrak.evrakTuru = ENUMGidenEvrakTuru.ICYAZISMA;
            evrak.geldigiYer = txtGeldigiYer.Text; //kullanicidan alınacak
            evrak.imza1 = txtImzaBilgi.Text; //kullanıcidan alınacak
            evrak.gizlilik = ENUMGizlilik.HIZMETEOZEL;
            evrak.paraf = txtParaf.Text; //kullanicidan alinacak
            evrak.yaziDurum = ENUMYaziDurum.DILEKCE;
            evrak.konu = txtKonu.Text;
            evrak.icerik = "yazi metni";

            EvrakBilesenleriW bilesen = new EvrakBilesenleriW();
            servis.EvrakBilesenleriGetir(kullanan.kullaniciKodu, kullanan.parola, evrak.evrakBirimKodu);
            evrak.altBilgi = bilesen.altBilgi;
            evrak.antet = bilesen.antet;

            WebServisler.EvrakServis.Sonuc sonuc = servis.EvrakKaydet(kullanan.kullaniciKodu, kullanan.parola, evrak);

            if (sonuc.islemSonuc)
            {
                string[] nolar = sonuc.anahtar.Split('-');
                string evrEvrakNo = nolar[0];
                string prEvrakNo = nolar[1];

                IPERServis servisPER = TNS.PER.Arac.Tanimla();
                int gorevYil = DateTime.Now.Year;
                int gorevKod = OrtakFonksiyonlar.ConvertToInt(hdnGorevKod.Value, 0);
                TNS.Sonuc sonucGorev = servisPER.GorevEvrakBilgiKaydet(kullanan, gorevYil, gorevKod, evrEvrakNo, prEvrakNo);

                if (sonucGorev.islemSonuc)
                    GenelIslemler.MesajKutusu(this, sonucGorev.bilgiStr);
                else
                    GenelIslemler.MesajKutusu(this, sonucGorev.hataStr);
            }
            else
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);

        }

    }
}
