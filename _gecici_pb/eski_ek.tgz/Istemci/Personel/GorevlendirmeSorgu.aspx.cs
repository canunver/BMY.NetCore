﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class GorevlendirmeSorgu : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();
        public const string GorevlendirmeYerTarih = "GorevlendirmeYerTarih";
        public const string GorevlendirmePersonel = "GorevlendirmePersonel";

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Görevlendirme Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            lblHata.Visible = false;

            //Sayfaya giriş izni varmı?
            //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            //Sayfaya giriş izni varmı?
            if (!TNS.PER.Yetki.YetkiVarMiOkumaya(kullanan))
                GenelIslemler.SayfayaGirmesin(true);

            this.txtMuhasebe.Attributes.Add("onblur", "kodAdGetir('11','lblMuhasebeAd',true,new Array('txtMuhasebe'),'KONTROLDENOKU');");
            this.txtBirim.Attributes.Add("onblur", "kodAdGetir('12','lblBirimAd',false,new Array('txtBirim','txtMuhasebe'),'KONTROLDENOKU');");

            //if (Request.Form["__EVENTTARGET"] == "DoldurSessionGorevlendirmeYerTarih")
            //{
            //    DoldurSessionGorevlendirmeYerTarih();
            //}

            //if (Request.Form["__EVENTTARGET"] == "DoldurSessionGorevlendirmePersonel")
            //{
            //    DoldurSessionGorevlendirmePersonel();
            //}

            if (!IsPostBack)
            {

            }
        }

        protected void btnListele_Click(object sender, EventArgs e)
        {
            Listele();
        }

        private void Listele()
        {
            string yetki = OrtakFonksiyonlar.YetkiTipiDegeriBul(kullanan.yetkiTipiDegerleri, "Personel Saymanlık-Birim Yetkisi");

            Gorev gorev = new Gorev();
            gorev.muhasebeKod = OrtakFonksiyonlar.ConvertToInt(txtMuhasebe.Text, 0);
            gorev.birimKod = txtBirim.Text;
            gorev.tur = OrtakFonksiyonlar.ConvertToInt(ddlTur.SelectedValue, 0);
            gorev.islemKod = OrtakFonksiyonlar.ConvertToInt(ddlIslemTur.SelectedValue, 0);

            ObjectArray liste = servisPER.GorevSorgula(kullanan, gorev);

            if (liste.sonuc.islemSonuc)
            {
                if (liste.ObjeSayisi > 0)
                {
                    DataTable dt = new DataTable();
                    dt.Columns.Add("kod");
                    dt.Columns.Add("muhasebe");
                    dt.Columns.Add("muhasebeAd");
                    dt.Columns.Add("birim");
                    dt.Columns.Add("birimAd");
                    dt.Columns.Add("tur");
                    dt.Columns.Add("turAd");
                    dt.Columns.Add("islemKod");
                    dt.Columns.Add("islemAd");

                    foreach (Gorev g in liste.objeler)
                        dt.Rows.Add(g.kod, g.muhasebeKod, g.muhasebeKod + "-" + g.muhasebeAd, g.birimKod, g.birimKod + "- " + g.birimAd, g.tur, TurAdiAl(g.tur), g.islemKod, IslemAdiAl(g.islemKod));

                    gvGorevler.DataSource = dt;
                    gvGorevler.DataBind();
                    gvGorevler.RowStyle.Height = 20;

                    for (int i = 0; i < gvGorevler.Rows.Count; i++)
                        gvGorevler.Rows[i].Cells[1].Text = Server.HtmlDecode(gvGorevler.Rows[i].Cells[1].Text);

                    Session[GorevlendirmeYerTarih] = null;
                    Session[GorevlendirmePersonel] = null;
                }
                else
                    GenelIslemler.MesajKutusu(this, "Listelenecek bilgi bulunmamaktadır.");

            }
            else
                GenelIslemler.HataYaz(this, liste.sonuc.hataStr, liste.sonuc.vtHatasi);
        }

        private string IslemAdiAl(int islemKod)
        {
            switch (islemKod)
            {
                case 24:
                    return "Yurtiçi Görev";
                case 25:
                    return "Yurtdışı Görev";
                case 26:
                    return "Denetim Görev";
                default:
                    return "Tanımsız";
            }
        }

        private string TurAdiAl(int tur)
        {
            switch (tur)
            {
                case 1:
                    return "Eğitim";
                case 2:
                    return "Sınav";
                case 3:
                    return "Vekalet";
                case 4:
                    return "Görev";
                case 5:
                    return "Keşif";
                case 6:
                    return "Denetim";
                default:
                    return "Tanımsız";
            }
        }


    }
}
