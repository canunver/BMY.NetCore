﻿<%@ Page Language="C#" CodeBehind="GorevlendirmePersonelListe.aspx.cs" Inherits="Personel.GorevlendirmePersonelListe" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <meta http-equiv="Pragma" content="no-cache" />
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />

    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="ModulScripts/Gorevlendirme.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript">
        function VeriGoster(kod) {
            parent.document.all.hdnTCKimlikNo.value = kod;
            parent.document.forms[0].submit();
            parent.hidePopWin();
        }
    </script>

</head>
<body style="margin: 10px; text-align: left;">
    <form id="aspnetForm" runat="server">
    <div class="form" style="width: 99%;" align="center">
        <div id="pnlPersonelListeEkle" runat="server">
            <div class="row">
                <div class="yaziAlan" style="width: 400px;">
                    Listenizde toplam
                    <asp:LinkButton ID="lbtListeToplam" runat="server" Text="0" OnClick="lbtListeToplam_Click"></asp:LinkButton>
                    personel bulunmaktadır.</div>
            </div>
            <div class="row">
                <div class="yaziAlan">
                    TC Kimlik No</div>
                <div class="ikiNokta">
                    :</div>
                <div class="veriAlan" style="width: 80px;">
                    <asp:TextBox ID="txtKimlikNo" runat="server" CssClass="veriAlan"></asp:TextBox></div>
            </div>
            <div class="row">
                <div class="yaziAlan">
                    Adı</div>
                <div class="ikiNokta">
                    :</div>
                <div class="veriAlan" style="width: 80px;">
                    <asp:TextBox ID="txtAd" runat="server" CssClass="veriAlan"></asp:TextBox></div>
            </div>
            <div class="row">
                <div class="yaziAlan">
                    Soyadı</div>
                <div class="ikiNokta">
                    :</div>
                <div class="veriAlan" style="width: 80px;">
                    <asp:TextBox ID="txtSoyad" runat="server" CssClass="veriAlan"></asp:TextBox></div>
            </div>
            <div class="row" style="text-align: left;">
                <asp:RadioButton runat="server" ID="rdHarcama" Text="Harcama Birimindeki" Checked="true"
                    GroupName="birim" />
                <asp:RadioButton runat="server" ID="rdMuhasebe" Text="Muhasebe Birimindeki" GroupName="birim" />
                <asp:RadioButton runat="server" ID="rdTumPersonel" Text="Tüm Personeller" GroupName="birim" />
            </div>
            <div class="row">
                <div class="footer">
                    &nbsp;</div>
            </div>
            <div class="row">
                <center>
                    <asp:Button ID="btnBul" runat="server" Text="Bul" CssClass="dugme" OnClick="btnBul_Click" />
                </center>
            </div>
            <div class="row">
                <div class="footer">
                    &nbsp;</div>
            </div>
            <div id="pnlPersonelListe" runat="server" class="row" style="overflow: auto; height: 325px;
                width: 550px;" align="left">
                <asp:DataGrid ID="dgPersonelListe" runat="server" Width="96%" AutoGenerateColumns="False"
                    BorderWidth="1px" BorderColor="Gray" CellPadding="3" Font-Bold="False" Font-Italic="False"
                    Font-Names="Tahoma" Font-Overline="False" Font-Size="8pt" Font-Strikeout="False"
                    Font-Underline="False" ForeColor="#333333" PageSize="1">
                    <AlternatingItemStyle BackColor="White" ForeColor="#284775" />
                    <ItemStyle BackColor="#F7F6F3" ForeColor="#333333" />
                    <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" Font-Italic="False" Font-Names="Tahoma"
                        Font-Overline="False" Font-Size="8pt" Font-Strikeout="False" Font-Underline="False"
                        ForeColor="White" HorizontalAlign="Center" VerticalAlign="Middle" />
                    <Columns>
                        <asp:TemplateColumn HeaderText="">
                            <ItemTemplate>
                                <asp:CheckBox ID="chkPersonel" runat="server" />
                            </ItemTemplate>
                            <HeaderTemplate>
                                <input id="chkSelectAll" onclick="javascript:SelectAllCheckbox(this);" type="checkbox" />
                            </HeaderTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="TC Kimlik No">
                            <ItemTemplate>
                                <asp:Label ID="lblTCKimlikNo" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "tckimlikno")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Ad">
                            <ItemTemplate>
                                <asp:Label ID="lblAd" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "ad")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Soyad">
                            <ItemTemplate>
                                <asp:Label ID="lblSoyad" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "soyad")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Unvan Kod" Visible="false">
                            <ItemTemplate>
                                <asp:Label ID="lblUnvanKod" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "unvankod")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Unvan">
                            <ItemTemplate>
                                <asp:Label ID="lblUnvan" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "unvan")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Muhasebe Kod">
                            <ItemTemplate>
                                <asp:Label ID="lblMuhasebeKod" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "muhasebe")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Birim Kod">
                            <ItemTemplate>
                                <asp:Label ID="lblBirimKod" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "birim")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Kadro Derece" Visible="false">
                            <ItemTemplate>
                                <asp:Label ID="lblKadroDerece" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "kadroderece")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Ek Gösterge" Visible="false">
                            <ItemTemplate>
                                <asp:Label ID="lblEkGosterge" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "ekgosterge")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                    </Columns>
                </asp:DataGrid>
            </div>
            <div class="row">
                <center>
                    <asp:Button ID="btnListeyeEkle" runat="server" Text="Listeye Ekle" CssClass="dugme"
                        OnClick="btnListeyeEkle_Click" />
                </center>
            </div>
            <div class="row">
                <div class="footer">
                    &nbsp;</div>
            </div>
        </div>
        <div id="pnlSecilenPersonelListeGoster" runat="server" visible="false">
            <div class="row">
                <div class="veriAlan">
                    <asp:LinkButton ID="lbtYeniPersonelEkle" runat="server" Text="Yeni Ekle" OnClick="lbtYeniPersonelEkle_Click" />
                </div>
            </div>
            <div class="row">
                <div class="footer">
                    &nbsp;</div>
            </div>
            <div id="pnlSecilenPersonelListe" runat="server" class="row" style="overflow: auto;
                height: 400px; width: 550px;" align="left">
                <asp:DataGrid ID="dgSecilenPersonelListe" runat="server" Width="96%" AutoGenerateColumns="False"
                    BorderWidth="1px" BorderColor="Gray" CellPadding="3" Font-Bold="False" Font-Italic="False"
                    Font-Names="Tahoma" Font-Overline="False" Font-Size="8pt" Font-Strikeout="False"
                    Font-Underline="False" ForeColor="#333333" PageSize="1">
                    <AlternatingItemStyle BackColor="White" ForeColor="#284775" />
                    <ItemStyle BackColor="#F7F6F3" ForeColor="#333333" />
                    <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" Font-Italic="False" Font-Names="Tahoma"
                        Font-Overline="False" Font-Size="8pt" Font-Strikeout="False" Font-Underline="False"
                        ForeColor="White" HorizontalAlign="Center" VerticalAlign="Middle" />
                    <Columns>
                        <asp:TemplateColumn HeaderText="">
                            <ItemTemplate>
                                <asp:CheckBox ID="chkPersonel" runat="server" />
                            </ItemTemplate>
                            <HeaderTemplate>
                                <input id="chkSelectAll" onclick="javascript:SelectAllCheckbox(this);" type="checkbox" />
                            </HeaderTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="TC Kimlik No">
                            <ItemTemplate>
                                <asp:Label ID="lblTCKimlikNo" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "tckimlikno")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Ad">
                            <ItemTemplate>
                                <asp:Label ID="lblAd" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "ad")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Soyad">
                            <ItemTemplate>
                                <asp:Label ID="lblSoyad" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "soyad")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Unvan Kod" Visible="false">
                            <ItemTemplate>
                                <asp:Label ID="lblUnvanKod" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "unvankod")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Unvan">
                            <ItemTemplate>
                                <asp:Label ID="lblUnvan" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "unvan")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Muhasebe Kod">
                            <ItemTemplate>
                                <asp:Label ID="lblMuhasebeKod" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "muhasebe")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Birim Kod">
                            <ItemTemplate>
                                <asp:Label ID="lblBirimKod" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "birim")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Kadro Derece">
                            <ItemTemplate>
                                <asp:Label ID="lblKadroDerece" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "kadroderece")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                        <asp:TemplateColumn HeaderText="Ek Gösterge">
                            <ItemTemplate>
                                <asp:Label ID="lblEkGosterge" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "ekgosterge")%>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateColumn>
                    </Columns>
                </asp:DataGrid>
            </div>
            <div class="row">
                <center>
                    <asp:Button ID="btnSeciliPersonelSil" runat="server" Text="Seçili Olanları Sil" CssClass="dugme"
                        OnClick="btnSeciliPersonelSil_Click" />
                </center>
            </div>
            <div class="row">
                <div class="footer">
                    &nbsp;</div>
            </div>
        </div>
    </div>
    <div class="row" style="text-align: right;">
        <input type="button" value="Kapat" class="dugme" onclick="GorevlendirmePersonelKaydet();" />
    </div>
    </form>
</body>
</html>
