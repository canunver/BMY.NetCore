﻿<%@ Page Language="C#" CodeBehind="GorevlendirmeSorgu.aspx.cs" Inherits="Personel.GorevlendirmeSorgu" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <link href="../App_themes/popupDialog.css" type="text/css" rel="stylesheet" />

    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>

    <script language="JavaScript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="../script/popupDialog.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="../script/popupDialog2.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="ModulScripts/Gorevlendirme.js?mc=03022015"></script>

</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <asp:Label ID="lblHata" Visible="false" runat="server"></asp:Label>
    <img src="../App_themes/images/belgeduzenlepasif.gif" alt="Belge Düzenleme" style="cursor: hand"
        onclick="parent.document.getElementById('frameIslem').cols='100%,0,0';document.scrolling=false;" />
    <img src="../App_themes/images/belgearamaaktif.gif" alt="Belge Arama" />
    <input type="hidden" id="hdnTCKimlikNo" runat="server" />
    <div class="form" style="width: 100%; margin-top: -2px;">
        <div class="row">
            <div class="yaziAlanK">
                Muhasebe Birimi Kodu</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtMuhasebe" runat="server" CssClass="veriAlan" MaxLength="5" Width="50px"></asp:TextBox>
            </div>
            <div class="veriAlan">
                <input type="image" id="imgMuhasebe" runat="server" alt="Muhasebe Listesi" style="height: 14px;
                    width: 16px;" class="veriAlan" onclick="javascript:MuhasebeGoster();return false;"
                    tabindex="100" src="../App_themes/images/bul1.gif" />
            </div>
            <div class="kolonArasi">
            </div>
            <div class="veriAlan" style="width: 575px">
                <asp:Label ID="lblMuhasebeAd" Width="100%" runat="server" CssClass="veriAlan"></asp:Label>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Harcama Birimi Kodu</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtBirim" runat="server" CssClass="veriAlan" MaxLength="15" Width="50px"></asp:TextBox>
            </div>
            <div class="veriAlan">
                <input type="image" id="imgBirim" runat="server" alt="Harcama Birim Listesi" style="height: 14px;
                    width: 16px;" class="veriAlan" onclick="javascript:MuhasebeBirimGoster();return false;"
                    tabindex="100" src="../App_themes/images/bul1.gif" />
            </div>
            <div class="kolonArasi">
            </div>
            <div class="veriAlan">
                <asp:Label ID="lblBirimAd" Width="100%" runat="server" CssClass="veriAlan"></asp:Label>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                Türü</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:DropDownList ID="ddlTur" runat="server" CssClass="veriAlanDDL">
                    <asp:ListItem Text="Hepsi" Value="0"></asp:ListItem>
                    <asp:ListItem Text="Eğitim" Value="1"></asp:ListItem>
                    <asp:ListItem Text="Sınav" Value="2"></asp:ListItem>
                    <asp:ListItem Text="Vekalet" Value="3"></asp:ListItem>
                    <asp:ListItem Text="Görev" Value="4"></asp:ListItem>
                    <asp:ListItem Text="Keşif" Value="5"></asp:ListItem>
                    <asp:ListItem Text="Denetim" Value="6"></asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                İşlem Türü</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:DropDownList ID="ddlIslemTur" runat="server" CssClass="veriAlanDDL">
                    <asp:ListItem Text="Hepsi" Value="0"></asp:ListItem>
                    <asp:ListItem Text="Yurtiçi Görev Yolluğu" Value="24"></asp:ListItem>
                    <asp:ListItem Text="Yurtdışı Görev Yolluğu" Value="25"></asp:ListItem>
                    <asp:ListItem Text="Denetim Görev Yolluğu" Value="26"></asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>
        <div class="footer">
            &nbsp;</div>
        <div class="row">
            <center>
                <asp:Button ID="btnListele" runat="server" Text="Listele" CssClass="dugme" OnClick="btnListele_Click" />
            </center>
        </div>
        <div class="footer">
            &nbsp;</div>
    </div>
    <div class="row">
        <div style="overflow: auto; width: 100%; height: 450px; border: solid 1px gray;">
            <asp:GridView ID="gvGorevler" runat="server" CellPadding="1" ForeColor="#333333"
                GridLines="None" Width="870px" AutoGenerateColumns="false">
                <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" HorizontalAlign="Center"
                    Height="30px" />
                <RowStyle BackColor="#F7F6F3" ForeColor="#333333" HorizontalAlign="Left" />
                <AlternatingRowStyle BackColor="White" ForeColor="#284775" />
                <Columns>
                    <asp:TemplateField ItemStyle-Width="20px" HeaderText="<a href='javascript:ListeSec();'><font color=yellow>Seç</font></a>">
                        <ItemTemplate>
                            <asp:CheckBox ID="chkSecim" runat="server" />
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="kod" Visible="false" HeaderText="GorevKodGizli"></asp:BoundField>
                    <asp:TemplateField HeaderText="Kod">
                        <ItemStyle Width="40px" BorderColor="LightGray" HorizontalAlign="Center" />
                        <ItemTemplate>
                            <a href="javascript:BelgeAc('<%# DataBinder.Eval(Container.DataItem, "kod")%>');">
                                <%# DataBinder.Eval(Container.DataItem, "kod")%></a>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="muhasebe" HeaderText="Muhasebe" Visible="false" />
                    <asp:BoundField DataField="muhasebeAd" HeaderText="Muhasebe Birimi Adı" ItemStyle-Width="160px" />
                    <asp:BoundField DataField="birim" HeaderText="Harcama Birimi" Visible="false" />
                    <asp:BoundField DataField="birimAd" HeaderText="Harcama Birimi Adı" ItemStyle-Width="160px" />
                    <asp:BoundField DataField="tur" HeaderText="Tür" Visible="false"></asp:BoundField>
                    <asp:BoundField DataField="turAd" HeaderText="Tür" ItemStyle-Width="80px" ItemStyle-HorizontalAlign="Center" />
                    <asp:BoundField DataField="islemKod" HeaderText="İşlem Adı" Visible="false" />
                    <asp:BoundField DataField="islemAd" HeaderText="İşlem Adı" ItemStyle-Width="80px"
                        ItemStyle-HorizontalAlign="Center" />
                </Columns>
            </asp:GridView>
        </div>
    </div>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
