﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class KadroGiris : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();
        /*****************************
         * Aktarım dosyası virgul ayıraclı ve aşağıdaki sırada olacaktır
         * T_TENTAH,T_KARARNAME,T_YIL,T_TEKLIF_NO,T_TESKILAT,T_USTBIRIM,T_SINIF,T_UNVAN,T_KADRO,T_ALT_IL,T_ALT_TIP,T_ALT_ILCE,
           T_SAY_IL,T_SAY_TIP,T_SAY_ILCE,T_TENTAHGUN,T_TENTAHAY,T_TENTAHYIL,T_VIZEGUN,T_VIZEAY,T_VIZEYIL,T_ICMAL_NO,
           T_ADET,T_DOLU_BOS,T_TARIH,T_DURUM
         *****************************/

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Tahsis-Tenkis Bilgileri Aktarım Formu";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            lblHata.Visible = false;

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);
        }

        protected void btnDosyaYukle_Click(object sender, System.EventArgs e)
        {
            if (fileListe.PostedFile == null)
                GenelIslemler.HataYaz(this, "Yüklemek istediğiniz dosyanın içi boş.");
            else
            {
                System.Web.HttpPostedFile myFile = fileListe.PostedFile;
                int nFileLen = myFile.ContentLength;
                if (nFileLen > 0)
                    BilgileriKaydet(myFile);
                else
                    GenelIslemler.HataYaz(this, "Lütfen ilk önce yüklemek istediğiniz excel dosyasını seçin.");
            }
        }

        void BilgileriKaydet(System.Web.HttpPostedFile myFile)
        {
            ObjectArray klar = new ObjectArray();
            string dosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();

            int nFileLen = myFile.ContentLength;
            byte[] myData = new byte[nFileLen];
            myFile.InputStream.Read(myData, 0, nFileLen);
            myFile.SaveAs(dosyaAd);

            StreamReader sr = new StreamReader(dosyaAd);
            string satir = sr.ReadLine();
            int siraNo = 0;
            bool ilkKezSilinecek = true;
            while (satir != null)
            {
                string[] parcalar = satir.Split(';');
                if (parcalar.Length > 10)
                {
                    siraNo++;
                    Kadro k = new Kadro();
                    k.tahsisTenkis = OrtakFonksiyonlar.ConvertToInt(parcalar[0], 0);
                    //k.kararname = OrtakFonksiyonlar.ConvertToInt(parcalar[1], 0);
                    k.yil = OrtakFonksiyonlar.ConvertToInt(parcalar[2], 0);
                    k.teklifNo = OrtakFonksiyonlar.ConvertToInt(parcalar[3], 0);
                    k.teskilat = OrtakFonksiyonlar.ConvertToInt(parcalar[4], 0);
                    k.ustBirim = OrtakFonksiyonlar.ConvertToInt(parcalar[5], 0);
                    k.sinif = OrtakFonksiyonlar.ConvertToInt(parcalar[6], 0);
                    k.unvan = OrtakFonksiyonlar.ConvertToInt(parcalar[7], 0);
                    k.kadro = OrtakFonksiyonlar.ConvertToInt(parcalar[8], 0);
                    k.altIl = OrtakFonksiyonlar.ConvertToInt(parcalar[9], 0);
                    k.altTip = OrtakFonksiyonlar.ConvertToInt(parcalar[10], 0);
                    k.altIlce = OrtakFonksiyonlar.ConvertToInt(parcalar[11], 0);
                    k.sayIl = OrtakFonksiyonlar.ConvertToInt(parcalar[12], 0);
                    k.sayTip = OrtakFonksiyonlar.ConvertToInt(parcalar[13], 0);
                    k.sayIlce = OrtakFonksiyonlar.ConvertToInt(parcalar[14], 0);
                    //int tenGun = OrtakFonksiyonlar.ConvertToInt(parcalar[15], 0);
                    //int tenAy = OrtakFonksiyonlar.ConvertToInt(parcalar[16], 0);
                    //int tenYil = OrtakFonksiyonlar.ConvertToInt(parcalar[17], 0);
                    //int vizeGun = OrtakFonksiyonlar.ConvertToInt(parcalar[18], 0);
                    //int vizeAy = OrtakFonksiyonlar.ConvertToInt(parcalar[19], 0);
                    //int vizeYil = OrtakFonksiyonlar.ConvertToInt(parcalar[20], 0);
                    //k.vizeTarih = new TNSDateTime(vizeGun + "." + vizeAy + "." + vizeYil);
                    //if (k.vizeTarih.isNull)
                    //    k.vizeTarih = new TNSDateTime(tenGun + "." + tenAy + "." + tenYil);
                    k.vizeTarih = new TNSDateTime(DateTime.Now.ToShortDateString());

                    k.icmalNo = OrtakFonksiyonlar.ConvertToInt(parcalar[21], 0);
                    int adet = OrtakFonksiyonlar.ConvertToInt(parcalar[22], 0);
                    //k.doluBos = OrtakFonksiyonlar.ConvertToInt(parcalar[23], 0);
                    //k.tarih = new TNSDateTime(parcalar[24]);
                    //k.durum = OrtakFonksiyonlar.ConvertToInt(parcalar[25], 0);
                    k.islemTarih = new TNSDateTime(DateTime.Now.ToShortDateString());
                    k.siraNo = siraNo;
                    if (adet > 0)
                    {
                        if (k.tahsisTenkis == 0)
                        {
                            k.dolu = adet * -1;
                            k.bos = adet;
                            k.adet = adet * -1;
                        }
                        if (k.tahsisTenkis == 1)
                        {
                            k.dolu = adet;
                            k.bos = adet * -1;
                            k.adet = adet;
                        }
                    }

                    if (k.teskilat > 0 &&
                        k.ustBirim > 0 &&
                        k.sinif > 0 &&
                        k.unvan > 0 &&
                        k.kadro > 0)
                        klar.Ekle(k);

                    satir = sr.ReadLine();

                    if (klar.objeler.Count > 500 || satir == null)
                    {
                        if (ilkKezSilinecek)
                            servisPER.KadroSil(kullanan, k.vizeTarih);

                        ilkKezSilinecek = false;

                        Sonuc sonuc = servisPER.KadroKaydet(kullanan, klar);

                        if (!sonuc.islemSonuc)
                        {
                            GenelIslemler.HataYaz(this, sonuc.hataStr);
                            return;
                        }
                        else
                            GenelIslemler.BilgiYaz(this, siraNo + " adet işlem yapıldı." + sonuc.bilgiStr);

                        klar = new ObjectArray();
                    }
                }
            }
        }
    }
}