﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class Personel : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Personel Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            lblHata.Visible = false;

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            this.txtBankaSubeKodu.Attributes.Add("onblur", "kodAdGetir('21','lblBankaSubeAd',true,new Array('txtBankaSubeKodu','ddlBanka'),'KONTROLDENOKU');");
            this.txtUnvan.Attributes.Add("onblur", "kodAdGetir('22','lblUnvan',true,new Array('txtUnvan'),'KONTROLDENOKU');");
            this.txtMuhasebe.Attributes.Add("onblur", "kodAdGetir('11','lblMuhasebeAd',true,new Array('txtMuhasebe'),'KONTROLDENOKU');");
            this.txtBirim.Attributes.Add("onblur", "kodAdGetir('12','lblBirimAd',false,new Array('txtBirim','txtMuhasebe'),'KONTROLDENOKU');");
            this.txtEvrakBirimKod.Attributes.Add("onblur", "kodAdGetir('56','lblEvrakBirimKod',false,new Array('txtEvrakBirimKod'),'KONTROLDENOKU');");

          

            if (Request.Form["hdnTCKimlikNo"] + "" != "")
                Listele();

            if (!IsPostBack)
            {
                ddlIstihdamm.Items.Add(new ListItem("", ""));
                for (int i = 1; i <= TNS.PER.Arac.ISTIHDAMSEKLISAY; i++)
                {
                    ddlIstihdamm.Items.Add(new ListItem(TNS.PER.Arac.IstihdamSekliAd((ENUMPersonelIstihdamSekli)i), i.ToString()));
                }

                bool mernisKontrolYapma = TNS.KYM.Arac.Tanimla().MernisKontroluYapma();
                bool okuma = !mernisKontrolYapma;
                txtAd.ReadOnly = okuma;
                txtSoyad.ReadOnly = okuma;
                txtBaba.ReadOnly = okuma;
                txtAna.ReadOnly = okuma;
                txtDogumTarih.ReadOnly = okuma;

                YilAyDoldur();
                OgrenimDoldur();
                BankaDoldur();
                SinifDoldur();
                UstBirimDoldur();

                txtBirim.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "PERBIRIM");
                txtMuhasebe.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "PERMUHASEBE");
                GenelIslemler.MesajKutusu("Bilgi", "Personel Bilgileri üzerinde düzenleme yapmak için Personel Özlük Modülünü kullanınınız.");
            }
            ClientScript.RegisterStartupScript(this.GetType(), "Goster", "PanelGoster();", true);
            SozlukAciklamalariniGetir();
        }

        protected void btnKaydet_Click(object sender, EventArgs e)
        {
            GenelIslemler.MesajKutusu("Bilgi", "Personel Bilgileri üzerinde düzenleme yapmak için Personel Özlük Modülünü kullanınınız.");
            return;

            //lblHata.Visible = false;
            //string hata = "";

            //if (txtMernisNo.Text.Trim() == "")
            //    hata += "T.C Kimlik Numarası boş bırakılamaz";
            //if (txtSicilNo.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Sicil Numarası boş bırakılamaz";
            //}
            //if (txtAd.Text.Trim() == "" || txtSoyad.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Ad ve Soyadı boş bırakılamaz";
            //}
            //if (txtBaba.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Baba Adı boş bırakılamaz";
            //}
            //if (txtAna.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Ana Adı boş bırakılamaz";
            //}
            //if (txtDogumTarih.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Doğum Tarihi boş bırakılamaz";
            //}
            //if (ddlCinsiyet.SelectedValue == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Cinsiyeti boş bırakılamaz";
            //}
            //if (ddlTeskilat.SelectedValue == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Teşkilat Bilgisi boş bırakılamaz";
            //}
            //if (ddlUstBirim.SelectedValue == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Üst Birim Bilgisi boş bırakılamaz";
            //}
            //if (txtUnvan.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Unvan Kodu boş bırakılamaz";
            //}
            //if (txtMuhasebe.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Muhasebe Birim Kodu boş bırakılamaz";
            //}
            //if (txtBirim.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Birim Kodu boş bırakılamaz";
            //}
            //if (ddlIstihdamm.Value == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "İstihdam Şekli boş bırakılamaz";
            //}
            //if (ddlSinif.SelectedValue == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Sınıf Kodu bilgisi boş bırakılamaz";
            //}
            //if (txtKadroDerece.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Kadro Derece bilgisi boş bırakılamaz";
            //}
            //if (ddlBanka.SelectedValue == "" || txtBankaSubeKodu.Text.Trim() == "" || txtBankaHesapNo.Text.Trim() == "")
            //{
            //    if (hata != "") hata += "<br>";
            //    hata += "Banka Bilgileri boş bırakılamaz";
            //}
            //if (hata != "")
            //{
            //    GenelIslemler.HataYaz(this, hata);
            //    return;
            //}

            //DegiskenleriKaydet();

            //TNS.PER.Personel p = new TNS.PER.Personel();

            //EkrandanSinifa(ref p);

            //Sonuc sonuc = servisPER.PersonelKaydet(kullanan, p);

            //if (!sonuc.islemSonuc)
            //    GenelIslemler.HataYaz(this, sonuc.hataStr);
            //else
            //{
            //    if (p.istihdamSekli == 2) // Sözleşmeli
            //    {
            //        Sonuc sonucc = servisPER.SozlesmeliBordroTanimKaydet(kullanan, p.sozlesmeliBordroTanim);
            //        if (!sonucc.islemSonuc)
            //            GenelIslemler.HataYaz(this, sonucc.hataStr);
            //        else
            //            GenelIslemler.BilgiYaz(this, sonucc.bilgiStr);
            //    }
            //    else
            //        GenelIslemler.BilgiYaz(this, sonuc.bilgiStr);
            //}

        }

        protected void btnAra_Click(object sender, EventArgs e)
        {
            Listele();
        }

        protected void btnYazdir_Click(object sender, EventArgs e)
        {
            lblHata.Visible = false;
            string hata = "";

            if (txtMernisNo.Text.Trim() == "")
                hata = "T.C. Kimlik Numarası boş bırakılamaz<br>";

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            TNS.PER.Personel pL = new TNS.PER.Personel();

            pL.tcKimlikNo = txtMernisNo.Text;
            ObjectArray pVAN = new ObjectArray();
            pVAN = servisPER.PersonelListele(kullanan, pL);

            if (!pVAN.sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, pVAN.sonuc.hataStr);
            else
            {
                if (pVAN.objeler.Count == 0)
                {
                    if (pVAN.sonuc.bilgiStr != "")
                        GenelIslemler.BilgiYaz(this, pVAN.sonuc.bilgiStr);
                    else
                        GenelIslemler.BilgiYaz(this, "Verilen kriterlere uygun personel bulunamadı");
                }
                else
                {
                    Tablo XLS = GenelIslemler.NewTablo();
                    string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
                    string sablonAd = "";

                    sablonAd = "PER-PersonelDetay.xlt";
                    XLS.DosyaAc(System.Web.HttpContext.Current.Server.MapPath("~") + "/RaporSablon/PERv2/" + sablonAd, sonucDosyaAd);

                    foreach (TNS.PER.Personel p in pVAN.objeler)
                    {
                        string muhasebeAd = "";
                        string birimAd = "";
                        string unvanAd = "";
                        string bankaSubeAd = "";
                        if (p.muhasebeKodu.ToString() != "")
                            muhasebeAd = GenelIslemler.KodAd(11, p.muhasebeKodu.ToString(), true);

                        if (txtBirim.Text.Trim() != "")
                            birimAd = GenelIslemler.KodAd(12, p.birimKodu.ToString() + "-" + p.muhasebeKodu.ToString(), false);

                        if (p.unvanKodu > 0)
                            unvanAd = GenelIslemler.KodAd(22, p.unvanKodu.ToString(), true);

                        if (p.bankaSubeKodu != "")
                            bankaSubeAd = GenelIslemler.KodAd(21, p.bankaSubeKodu + "-" + p.bankaKodu, true);

                        XLS.HucreAdBulYaz("txtMuhasebeKodu", p.muhasebeKodu.ToString());
                        XLS.HucreAdBulYaz("txtBirimKodu", p.birimKodu.ToString());
                        XLS.HucreAdBulYaz("txtMuhasebeAdi", muhasebeAd);
                        XLS.HucreAdBulYaz("txtBirimAdi", birimAd);
                        XLS.HucreAdBulYaz("txtKimlikNo", p.tcKimlikNo);
                        XLS.HucreAdBulYaz("txtSicilNo", p.sicilNo);
                        XLS.HucreAdBulYaz("txtAdi", p.ad);
                        XLS.HucreAdBulYaz("txtSoyadi", p.soyad);
                        XLS.HucreAdBulYaz("txtBaba", p.babaAd);
                        XLS.HucreAdBulYaz("txtAna", p.anaAd);
                        XLS.HucreAdBulYaz("txtDogumTarih", p.dogumTarihi.ToString());
                        XLS.HucreAdBulYaz("txtKanGrubu", p.kanGrubu);
                        XLS.HucreAdBulYaz("txtIsTel", p.isTelefon);
                        XLS.HucreAdBulYaz("txtCepTel", p.cepTelefon);
                        XLS.HucreAdBulYaz("txtEvTel", p.evTelefon);
                        XLS.HucreAdBulYaz("txtFaks", p.faks);
                        XLS.HucreAdBulYaz("txtVergiDairesi", p.vergiDairesi);
                        XLS.HucreAdBulYaz("txtAdres", p.adres);
                        XLS.HucreAdBulYaz("txtePosta", p.eposta);
                        XLS.HucreAdBulYaz("txtEmekliSicilNo", p.emekliSicilNo);
                        XLS.HucreAdBulYaz("txtSaglikKarneNo", p.saglikKarneNo);

                        try { XLS.HucreAdBulYaz("txtCinsiyeti", ddlCinsiyet.Items.FindByValue(p.cinsiyet.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtMedenihali", ddlMedeniHali.Items.FindByValue(p.medeniHali.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtAskerlik", ddlAskerlik.Items.FindByValue(p.askerlikKodu.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtOgrenim", ddlOgrenim.Items.FindByValue(p.ogrenimKodu.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtEs", ddlEsDurum.Items.FindByValue(p.esDurumuKodu.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtDurum", ddlDurum.Items.FindByValue(p.durum.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtBanka", ddlBanka.Items.FindByValue(p.bankaKodu.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtUstBirimKodu", ddlUstBirim.Items.FindByValue(p.ustBirimKodu.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtTeskilatKodu", ddlTeskilat.Items.FindByValue(p.teskilatKodu.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtIstihdamSekli", ddlIstihdamm.Items.FindByValue(p.istihdamSekli.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtUstBirim", ddlUstBirim.Items.FindByValue(p.ustBirimKodu.ToString()).Text); }
                        catch { }
                        try { XLS.HucreAdBulYaz("txtSinif", ddlSinif.Items.FindByValue(p.sinifKodu.ToString()).Text); }
                        catch { }

                        XLS.HucreAdBulYaz("txtSubeKodu", p.bankaSubeKodu);
                        XLS.HucreAdBulYaz("txtSubeAdi", bankaSubeAd);
                        XLS.HucreAdBulYaz("txtHesapNo", p.bankaHesapNo);
                        XLS.HucreAdBulYaz("txtUnvan", unvanAd);
                        XLS.HucreAdBulYaz("txtMemurBasTarih", p.memurBaslamaTarihi.ToString());
                        XLS.HucreAdBulYaz("txtIseBasTarih", p.iseBaslamaTarihi.ToString());
                        XLS.HucreAdBulYaz("txtIstenCikisTarih", p.istenCikisTarihi.ToString());
                        XLS.HucreAdBulYaz("txtKidemAyYil", p.kidemAy + "/" + p.kidemYil);
                        XLS.HucreAdBulYaz("txtDerece1", p.kadroDerece.ToString());
                        XLS.HucreAdBulYaz("txtKadroTarih1", p.kadroTarih.ToString());

                        XLS.HucreAdBulYaz("txtDerece2", p.kazanilmisHakDerece.ToString());
                        XLS.HucreAdBulYaz("txtKademe2", p.kazanilmisHakKademe.ToString());
                        XLS.HucreAdBulYaz("txtKadroTarih2", p.kazanilmisHakTarih.ToString());

                        XLS.HucreAdBulYaz("txtDerece3", p.odemeEsasDerece.ToString());
                        XLS.HucreAdBulYaz("txtKademe3", p.odemeEsasKademe.ToString());
                        XLS.HucreAdBulYaz("txtKadroTarih3", p.odemeEsasTarih.ToString());
                        XLS.HucreAdBulYaz("txtEkGosterge3", p.odemeEsasGosterge.ToString());

                        XLS.HucreAdBulYaz("txtDerece4", p.emekliEsasDerece.ToString());
                        XLS.HucreAdBulYaz("txtKademe4", p.emekliEsasKademe.ToString());
                        XLS.HucreAdBulYaz("txtKadroTarih4", p.emekliEsasTarih.ToString());
                        XLS.HucreAdBulYaz("txtEkGosterge4", p.emekliEsasGosterge.ToString());
                    }
                    XLS.DosyaSaklaTamYol();
                    OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "Personel", true, GenelIslemler.ExcelTur());
                }
            }
        }

        void Listele()
        {
            lblHata.Visible = false;
            string hata = "";

            if (txtMernisNo.Text.Trim() == "")
            {
                if (txtMuhasebe.Text == "")
                    hata = "Muhasebe bilgisi boş bırakılamaz<br>";

                if (txtBirim.Text == "")
                    hata += "Muhasebe Birim bilgisi boş bırakılamaz";
            }

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            DegiskenleriKaydet();

            TNS.PER.Personel pL = new TNS.PER.Personel();

            if (hdnTCKimlikNo.Value == "")
                EkrandanSinifa(ref pL);
            else
            {
                pL.tcKimlikNo = hdnTCKimlikNo.Value;
                pL.muhasebeKodu = OrtakFonksiyonlar.ConvertToInt(txtMuhasebe.Text, 0);
                pL.birimKodu = txtBirim.Text;
                hdnTCKimlikNo.Value = "";
            }

            ObjectArray pVAN = new ObjectArray();

            pVAN = servisPER.PersonelListele(kullanan, pL);

            if (!pVAN.sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, pVAN.sonuc.hataStr);
            else
            {
                if (pVAN.objeler.Count == 0)
                {
                    if (pVAN.sonuc.bilgiStr != "")
                        GenelIslemler.BilgiYaz(this, pVAN.sonuc.bilgiStr);
                    else
                        GenelIslemler.BilgiYaz(this, "Verilen kriterlere uygun personel bulunamadı");
                }
                else
                {
                    if (pVAN.objeler.Count > 1)
                    {
                        OturumBilgisiIslem.BilgiYazDegisken("personelListe", pVAN);
                        ClientScript.RegisterStartupScript(this.GetType(), "Liste", "<script>personelListeGoster=true;</script>");
                    }
                    else
                    {
                        btnTemizle_Click(null, null);

                        foreach (TNS.PER.Personel p in pVAN.objeler)
                        {
                            txtMernisNo.Text = p.tcKimlikNo;
                            txtSicilNo.Text = p.sicilNo;
                            txtAd.Text = p.ad;
                            txtSoyad.Text = p.soyad;
                            txtBaba.Text = p.babaAd;
                            txtAna.Text = p.anaAd;
                            txtDogumTarih.Text = p.dogumTarihi.ToString();
                            //ddlCinsiyet.SelectedValue = p.cinsiyet.ToString();
                            ddlCinsiyet.SelectedIndex = ddlCinsiyet.Items.IndexOf(ddlCinsiyet.Items.FindByValue(p.cinsiyet.ToString()));

                            //ddlMedeniHali.SelectedValue = p.medeniHali.ToString();
                            ddlMedeniHali.SelectedIndex = ddlMedeniHali.Items.IndexOf(ddlMedeniHali.Items.FindByValue(p.medeniHali.ToString()));

                            //ddlKanGrubu.SelectedValue = p.kanGrubu;
                            ddlKanGrubu.SelectedIndex = ddlKanGrubu.Items.IndexOf(ddlKanGrubu.Items.FindByValue(p.kanGrubu.ToString()));

                            txtIsTel.Text = p.isTelefon;
                            txtCepTel.Text = p.cepTelefon;
                            txtFaks.Text = p.faks;
                            txtEPosta.Text = p.eposta;

                            txtEv.Text = p.evTelefon;
                            txtAdres.Text = p.adres;
                            txtVergiDairesi.Text = p.vergiDairesi;

                            //ddlAskerlik.SelectedValue = p.askerlikKodu.ToString();
                            ddlAskerlik.SelectedIndex = ddlAskerlik.Items.IndexOf(ddlAskerlik.Items.FindByValue(p.askerlikKodu.ToString()));

                            //ddlOgrenim.SelectedValue = p.ogrenimKodu.ToString();
                            ddlOgrenim.SelectedIndex = ddlOgrenim.Items.IndexOf(ddlOgrenim.Items.FindByValue(p.ogrenimKodu.ToString()));

                            //ddlEsDurum.SelectedValue = p.esDurumuKodu.ToString();
                            ddlEsDurum.SelectedIndex = ddlEsDurum.Items.IndexOf(ddlEsDurum.Items.FindByValue(p.esDurumuKodu.ToString()));

                            txtKarneNo.Text = p.saglikKarneNo;

                            //ddlDurum.SelectedValue = p.durum.ToString();
                            ddlDurum.SelectedIndex = ddlDurum.Items.IndexOf(ddlDurum.Items.FindByValue(p.durum.ToString()));

                            txtEmekliSicilNo.Text = p.emekliSicilNo;
                            lblGuncelleme.Text = "Bu personel en son <b>" + p.guncellenmeTarihi.ToLongString() + "</b> tarihinde <b>" + p.guncelleyenKisi + "</b> tarafından güncellenmiştir.";

                            //ddlBanka.SelectedValue = p.bankaKodu.ToString();
                            ddlBanka.SelectedIndex = ddlBanka.Items.IndexOf(ddlBanka.Items.FindByValue(p.bankaKodu.ToString()));

                            txtBankaSubeKodu.Text = p.bankaSubeKodu;
                            txtBankaHesapNo.Text = p.bankaHesapNo;

                            txtEvrakBirimKod.Text = p.evrakBirimKod;
                            //ddlTeskilat.SelectedValue = p.teskilatKodu.ToString();
                            ddlTeskilat.SelectedIndex = ddlTeskilat.Items.IndexOf(ddlTeskilat.Items.FindByValue(p.teskilatKodu.ToString()));

                            txtUnvan.Text = p.unvanKodu.ToString();
                            txtMuhasebe.Text = p.muhasebeKodu.ToString();
                            txtBirim.Text = p.birimKodu;
                            txtMemurBaslaTarih.Text = p.memurBaslamaTarihi.ToString();
                            txtIseGirisTarihi.Text = p.iseBaslamaTarihi.ToString();
                            txtIstenCikisTarihi.Text = p.istenCikisTarihi.ToString();

                            //ddlUstBirim.SelectedValue = p.ustBirimKodu.ToString();
                            ddlUstBirim.SelectedIndex = ddlUstBirim.Items.IndexOf(ddlUstBirim.Items.FindByValue(p.ustBirimKodu.ToString()));

                            //ddlSinif.SelectedValue = p.sinifKodu.ToString();
                            ddlSinif.SelectedIndex = ddlSinif.Items.IndexOf(ddlSinif.Items.FindByValue(p.sinifKodu.ToString()));

                            txtKidemAy.Text = p.kidemAy.ToString();
                            txtKidemYil.Text = p.kidemYil.ToString();
                            txtKadroDerece.Text = p.kadroDerece.ToString();
                            txtKadroDereceTarih.Text = p.kadroTarih.ToString();
                            txtOdeEsDerece.Text = p.odemeEsasDerece.ToString();
                            txtOdeEsKademe.Text = p.odemeEsasKademe.ToString();
                            txtOdeEsEkGosterge.Text = p.odemeEsasGosterge.ToString();
                            txtOdeEsTarih.Text = p.odemeEsasTarih.ToString();
                            txtEmEsDerece.Text = p.emekliEsasDerece.ToString();
                            txtEmEsKademe.Text = p.emekliEsasKademe.ToString();
                            txtEmEsEkGosterge.Text = p.emekliEsasGosterge.ToString();
                            txtEmEsTarih.Text = p.emekliEsasTarih.ToString();
                            txtKazHakDerece.Text = p.kazanilmisHakDerece.ToString();
                            txtKazHakKademe.Text = p.kazanilmisHakKademe.ToString();
                            txtKazHakTarih.Text = p.kazanilmisHakTarih.ToString();
                            ddlIstihdamm.Value = p.istihdamSekli.ToString();

                            if (p.istihdamSekli == 2) // Sözleşmeli
                            {
                                if (p.sozlesmeliBordroTanim.yil > 0)
                                    ddlYil.SelectedValue = p.sozlesmeliBordroTanim.yil.ToString();
                                if (p.sozlesmeliBordroTanim.ay > 0)
                                    ddlAy.SelectedValue = p.sozlesmeliBordroTanim.ay.ToString();
                                txtKumulatifToplam.Text = p.sozlesmeliBordroTanim.kumulatifVergiMatrahi.ToString("#,###.00");
                                lblSonKumulatifToplam.Text = " TL";
                            }

                            SozlukAciklamalariniGetir();
                        }
                    }
                }
            }
        }

        void EkrandanSinifa(ref TNS.PER.Personel p)
        {
            p.tcKimlikNo = txtMernisNo.Text;
            p.sicilNo = txtSicilNo.Text;
            p.ad = txtAd.Text;
            p.soyad = txtSoyad.Text;
            p.babaAd = txtBaba.Text;
            p.anaAd = txtAna.Text;
            p.dogumTarihi = new TNSDateTime(txtDogumTarih.Text);
            p.cinsiyet = OrtakFonksiyonlar.ConvertToInt(ddlCinsiyet.SelectedValue, 0);
            p.medeniHali = OrtakFonksiyonlar.ConvertToInt(ddlMedeniHali.SelectedValue, 0);
            p.kanGrubu = ddlKanGrubu.SelectedValue;
            p.isTelefon = txtIsTel.Text;
            p.cepTelefon = txtCepTel.Text;
            p.faks = txtFaks.Text;
            p.eposta = txtEPosta.Text;
            p.adres = txtAdres.Text;
            p.evTelefon = txtEv.Text;
            p.vergiDairesi = txtVergiDairesi.Text;
            p.askerlikKodu = OrtakFonksiyonlar.ConvertToInt(ddlAskerlik.SelectedValue, 0);
            p.ogrenimKodu = OrtakFonksiyonlar.ConvertToInt(ddlOgrenim.SelectedValue, 0);
            p.esDurumuKodu = OrtakFonksiyonlar.ConvertToInt(ddlEsDurum.SelectedValue, 0);
            p.saglikKarneNo = txtKarneNo.Text;
            p.durum = OrtakFonksiyonlar.ConvertToInt(ddlDurum.SelectedValue, 0);
            p.emekliSicilNo = txtEmekliSicilNo.Text;
            p.guncellenmeTarihi = new TNSDateTime(lblGuncelleme.Text);

            p.bankaKodu = ddlBanka.SelectedValue;
            p.bankaSubeKodu = txtBankaSubeKodu.Text;
            p.bankaHesapNo = txtBankaHesapNo.Text;

            p.evrakBirimKod = txtEvrakBirimKod.Text;
            p.teskilatKodu = OrtakFonksiyonlar.ConvertToInt(ddlTeskilat.SelectedValue, 0);
            p.unvanKodu = OrtakFonksiyonlar.ConvertToInt(txtUnvan.Text, 0);
            p.muhasebeKodu = OrtakFonksiyonlar.ConvertToInt(txtMuhasebe.Text, 0);
            p.birimKodu = txtBirim.Text.Trim();
            p.memurBaslamaTarihi = new TNSDateTime(txtMemurBaslaTarih.Text);
            p.iseBaslamaTarihi = new TNSDateTime(txtIseGirisTarihi.Text);
            p.istenCikisTarihi = new TNSDateTime(txtIstenCikisTarihi.Text);

            p.ustBirimKodu = OrtakFonksiyonlar.ConvertToInt(ddlUstBirim.SelectedValue, 0);
            p.sinifKodu = OrtakFonksiyonlar.ConvertToInt(ddlSinif.SelectedValue, 0);
            p.kidemAy = OrtakFonksiyonlar.ConvertToInt(txtKidemAy.Text, 0);
            p.kidemYil = OrtakFonksiyonlar.ConvertToInt(txtKidemYil.Text, 0);
            p.kadroDerece = OrtakFonksiyonlar.ConvertToInt(txtKadroDerece.Text, 0);
            p.kadroTarih = new TNSDateTime(txtKadroDereceTarih.Text);
            p.odemeEsasDerece = OrtakFonksiyonlar.ConvertToInt(txtOdeEsDerece.Text, 0);
            p.odemeEsasKademe = OrtakFonksiyonlar.ConvertToInt(txtOdeEsKademe.Text, 0);
            p.odemeEsasGosterge = OrtakFonksiyonlar.ConvertToInt(txtOdeEsEkGosterge.Text, 0);
            p.odemeEsasTarih = new TNSDateTime(txtOdeEsTarih.Text);
            p.emekliEsasDerece = OrtakFonksiyonlar.ConvertToInt(txtEmEsDerece.Text, 0);
            p.emekliEsasKademe = OrtakFonksiyonlar.ConvertToInt(txtEmEsKademe.Text, 0);
            p.emekliEsasGosterge = OrtakFonksiyonlar.ConvertToInt(txtEmEsEkGosterge.Text, 0);
            p.emekliEsasTarih = new TNSDateTime(txtEmEsTarih.Text);
            p.kazanilmisHakDerece = OrtakFonksiyonlar.ConvertToInt(txtKazHakDerece.Text, 0);
            p.kazanilmisHakKademe = OrtakFonksiyonlar.ConvertToInt(txtKazHakKademe.Text, 0);
            p.kazanilmisHakTarih = new TNSDateTime(txtKazHakTarih.Text);
            p.guncellenmeTarihi = new TNSDateTime(DateTime.Now);
            p.istihdamSekli = OrtakFonksiyonlar.ConvertToInt(ddlIstihdamm.Value, 0);

            if (p.istihdamSekli == 2) //Sözleşmeli
            {
                p.sozlesmeliBordroTanim.tcKimlikNo = txtMernisNo.Text;
                p.sozlesmeliBordroTanim.yil = OrtakFonksiyonlar.ConvertToInt(ddlYil.SelectedValue, 0);
                p.sozlesmeliBordroTanim.ay = OrtakFonksiyonlar.ConvertToInt(ddlAy.SelectedValue, 0);
                p.sozlesmeliBordroTanim.kumulatifVergiMatrahi = OrtakFonksiyonlar.ConvertToDecimal(txtKumulatifToplam.Text);
            }
        }

        protected void btnTemizle_Click(object sender, EventArgs e)
        {
            txtMernisNo.Text = "";
            txtSicilNo.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            txtBaba.Text = "";
            txtAna.Text = "";
            txtDogumTarih.Text = "";
            ddlCinsiyet.SelectedIndex = -1;
            ddlMedeniHali.SelectedIndex = -1;
            ddlKanGrubu.SelectedIndex = -1;
            txtIsTel.Text = "";
            txtCepTel.Text = "";
            txtFaks.Text = "";
            txtEPosta.Text = "";
            txtAdres.Text = "";
            txtEv.Text = "";
            txtVergiDairesi.Text = "";
            ddlAskerlik.SelectedIndex = -1;
            ddlOgrenim.SelectedIndex = -1;
            ddlEsDurum.SelectedIndex = -1;
            txtKarneNo.Text = "";
            ddlDurum.SelectedIndex = -1;
            txtEmekliSicilNo.Text = "";
            lblGuncelleme.Text = "";

            ddlBanka.SelectedIndex = -1;
            txtBankaSubeKodu.Text = "";
            txtBankaHesapNo.Text = "";

            txtEvrakBirimKod.Text = "";
            lblEvrakBirimKod.Text = "";

            ddlTeskilat.SelectedIndex = -1;
            txtUnvan.Text = "";
            txtMuhasebe.Text = "";
            txtBirim.Text = "";
            txtMemurBaslaTarih.Text = "";
            txtIseGirisTarihi.Text = "";
            txtIstenCikisTarihi.Text = "";

            ddlUstBirim.SelectedIndex = -1;
            ddlSinif.SelectedIndex = -1;
            txtKidemAy.Text = "";
            txtKidemYil.Text = "";
            txtKadroDerece.Text = "";
            txtKadroDereceTarih.Text = "";
            txtOdeEsDerece.Text = "";
            txtOdeEsKademe.Text = "";
            txtOdeEsEkGosterge.Text = "";
            txtOdeEsTarih.Text = "";
            txtEmEsDerece.Text = "";
            txtEmEsKademe.Text = "";
            txtEmEsEkGosterge.Text = "";
            txtEmEsTarih.Text = "";
            txtKazHakDerece.Text = "";
            txtKazHakKademe.Text = "";
            txtKazHakTarih.Text = "";
            lblGuncelleme.Text = "";
            ddlIstihdamm.SelectedIndex = -1;

            lblBankaSubeAd.Text = "";
            lblUnvan.Text = "";
            txtBirim.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "PERBIRIM");
            txtMuhasebe.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "PERMUHASEBE");
        }

        protected void imgKimlik_Click(object sender, System.EventArgs e)
        {
            KullaniciVAN kVAN = GenelIslemler.MernisOku(kullanan, txtMernisNo.Text, new TNSDateTime(txtDogumTarih.Text));
            if (kVAN.sonuc.islemSonuc)
            {
                lblMernisHata.Text = "";
                txtAd.Text = kVAN.kullanici.ad;
                txtSoyad.Text = kVAN.kullanici.soyad;
                txtDogumTarih.Text = kVAN.kullanici.dogumTarihi.ToString();
                txtAna.Text = kVAN.kullanici.anaAdi;
                txtBaba.Text = kVAN.kullanici.babaAdi;
                if (kVAN.kullanici.cinsiyet == "Erkek")
                    ddlCinsiyet.SelectedIndex = 1;
                else
                    ddlCinsiyet.SelectedIndex = 2;
            }
            else
            {
                txtAd.Text = "";
                txtSoyad.Text = "";
                lblMernisHata.Text = "<b>Hata : </b>Kimlik Doğrulama Servisi ile bağlantı kurulamıyor veya verilen kimlik numarası hatalı.";
            }
        }


        void YilAyDoldur()
        {
            GenelIslemler.YilDoldur(ddlYil, 2008, DateTime.Now.Year, DateTime.Now.Year);
            GenelIslemler.AyDoldur(ddlAy);
        }

        void OgrenimDoldur()
        {
            ObjectArray dler = new ObjectArray();
            dler = servisPER.OgrenimListele(new Ogrenim());
            ddlOgrenim.Items.Add(new ListItem("", "0"));

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    foreach (Ogrenim d in dler.objeler)
                        ddlOgrenim.Items.Add(new ListItem(d.ad, d.kod.ToString()));
                }
            }
        }

        void BankaDoldur()
        {
            ObjectArray dler = new ObjectArray();
            dler = servisPER.BankaListele(new Banka());
            ddlBanka.Items.Add(new ListItem("", ""));

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    foreach (Banka d in dler.objeler)
                        ddlBanka.Items.Add(new ListItem(d.ad, d.kod.ToString()));
                }
            }
        }

        void SinifDoldur()
        {
            ObjectArray dler = new ObjectArray();
            dler = servisPER.SinifListele(new Sinif());
            ddlSinif.Items.Add(new ListItem("", ""));

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    foreach (Sinif d in dler.objeler)
                        ddlSinif.Items.Add(new ListItem(d.ad, d.kod.ToString()));
                }
            }
        }

        void UstBirimDoldur()
        {
            ObjectArray dler = new ObjectArray();
            dler = servisPER.UstBirimListele(new UstBirim());
            ddlUstBirim.Items.Add(new ListItem("", ""));

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    foreach (UstBirim d in dler.objeler)
                        ddlUstBirim.Items.Add(new ListItem(d.ad, d.kod.ToString()));
                }
            }
        }

        void SozlukAciklamalariniGetir()
        {
            if (txtMuhasebe.Text.Trim() != "")
                lblMuhasebeAd.Text = GenelIslemler.KodAd(11, txtMuhasebe.Text.Trim(), true);

            if (txtBirim.Text.Trim() != "")
                lblBirimAd.Text = GenelIslemler.KodAd(12, txtBirim.Text.Trim() + "-" + txtMuhasebe.Text.Trim(), false);

            if (txtUnvan.Text.Trim() != "")
                lblUnvan.Text = GenelIslemler.KodAd(22, txtUnvan.Text.Trim(), true);

            if (txtBankaSubeKodu.Text.Trim() != "")
                lblBankaSubeAd.Text = GenelIslemler.KodAd(21, txtBankaSubeKodu.Text.Trim() + "-" + ddlBanka.SelectedValue, true);

            if (txtEvrakBirimKod.Text.Trim() != "")
                lblEvrakBirimKod.Text = GenelIslemler.KodAd(56, txtEvrakBirimKod.Text.Trim(), true);
        }

        void DegiskenleriKaydet()
        {
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "PERBIRIM", txtBirim.Text);
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "PERMUHASEBE", txtMuhasebe.Text);
        }
    }
}
