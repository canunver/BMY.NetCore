function MuhasebeGoster() {
    try { document.all.lblHata.innerHTML = ""; }
    catch (e) { }

    var yil = ""; //document.all.ddlYil.value;
    var kurum = ""; //document.all.txtKurum.value;

    showPopWin("../ButceMuhasebe/ListeMuhasebeBirim.aspx?yil=" + yil + "&kurum=" + kurum, 500, 300, true, null);
}

function MuhasebeBirimGoster() {
    try { document.all.lblHata.innerHTML = ""; }
    catch (e) { }

    var yil = ""; //document.all.ddlYil.value;
    var kurum = ""; //document.all.txtKurum.value;
    var muhasebe = document.all.txtMuhasebe.value;

    showPopWin("../ButceMuhasebe/ListeMuhasebeBirim.aspx?yil=" + yil + "&kurum=" + kurum + "&muhasebe=" + muhasebe, 500, 300, true, null);
}

var hesapPlaniPenceresi;
function EvrakBirimEkle() {
    if (hesapPlaniPenceresi != null)
        hesapPlaniPenceresi.focus();
    else {
        hesapPlaniPenceresi = window.open("../Evrak/ListeBirim.aspx", "hesapPlani", "resizable,status,width=500,height=350");
        hesapPlaniPenceresi.moveTo(screen.width - 525, 30);
        hesapPlaniPenceresi.focus();
    }
}

function BirimKodSecmeliBilgiKoy(kodlar, kodAdlar) {
    var hedefKontrol = "fpL";
    var tanim = kodlar.split('-');
    if (tanim.length > 0) {
        var satir = document.all.fpL.GetActiveRow();
        document.all.fpL.SetValue(satir, 2, tanim[0], true);
    }
    if (birimPenceresi != null)
        birimPenceresi.close();
}
