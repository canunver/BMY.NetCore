function EvrakIslemGoster() {
    showPopWin("../Personel/GorevlendirmeEvrak.aspx", 400, 250, true, null);
}

function BelgeAc(kod) {
    parent.frames["belge"].document.all.txtBelgeNo.value = kod;
    parent.document.getElementById('frameIslem').cols = '100%,0,0';
    document.scrolling = false;
    parent.frames["belge"].BelgeAcClick(event);
}

function BelgeAcClick(event) {
    document.all.btnBelgeListele.click();
}

function GorevYerTarihEkle() {
    showPopWin("../Personel/GorevlendirmeYerTarih.aspx", 400, 250, true, null);
}

function GorevPersonelEkle() {

    var birim = document.all.txtBirim.value;
    var muhasebe = document.all.txtMuhasebe.value;

    if (birim != "" && muhasebe != "") {
        showPopWin("../Personel/GorevlendirmePersonelListe.aspx?muhasebe=" + muhasebe + "&birim=" + birim, 600, 550, false, null);
    }
    else {
        alert("Muhasebe ve Harcama Birimi kodu giriniz.");
    }
}

function GorevlendirmeYerTarihKaydet() {
    parent.hidePopWin();
    parent.DoldurSessionGorevlendirmeYerTarih();
}

function GorevlendirmePersonelKaydet() {
    parent.hidePopWin();
    parent.DoldurSessionGorevlendirmePersonel();
}

function DoldurSessionGorevlendirmeYerTarih() {
    __doPostBack("DoldurSessionGorevlendirmeYerTarih", "");
}

function DoldurSessionGorevlendirmePersonel() {
    __doPostBack("DoldurSessionGorevlendirmePersonel", "");
}

function SelectAllCheckbox(e) {
    var frm = document.forms[0];
    for (i = 0; i < frm.elements.length; i++) {
        if (frm.elements[i].type == "checkbox") {
            frm.elements[i].checked = document.getElementById(e.id).checked;
        }
    }
}

function paramFonksiyonIlIlce() {
    var donenDeger = "";
    var random = Math.random();
    donenDeger += "&Random=" + random;
    return donenDeger;
}
