var OrgBirimDoldur = function (node) {
    var orgBirim = { personelMi: 1 };
    nodeLoadOrgBirimParam(node, orgBirim);
};

function VeriGosterBankaSube(ad, kod, banka) {
    if (banka != "")
        document.all.ddlBanka.value = banka;

    document.all.txtKod.value = kod;
    document.all.txtAd.value = ad;
}

function VeriGosterBanka(ad, kod) {
    document.all.txtKod.value = kod;
    document.all.txtAd.value = ad;
}

function VeriGosterDil(ad, kod) {
    document.all.txtKod.value = kod;
    document.all.txtAd.value = ad;
}

function VeriGosterKurs(ad, kod) {
    document.all.txtKod.value = kod;
    document.all.txtAd.value = ad;
}

function VeriGosterSinif(ad, kod) {
    document.all.txtKod.value = kod;
    document.all.txtAd.value = ad;
}

function VeriGosterUstBirim(ad, kod) {
    document.all.txtKod.value = kod;
    document.all.txtAd.value = ad;
}

function VeriGosterOgrenim(ad, kod) {
    document.all.txtKod.value = kod;
    document.all.txtAd.value = ad;
}

function VeriGosterUnvan(ad, adKisa,kod, sira, yonetici) {
    document.all.txtKod.value = kod;
    document.all.txtAd.value = ad;
    document.all.txtAdKisa.value = adKisa;
    document.all.txtSiraNo.value = sira;
    if (yonetici == "1")
        document.all.chkYonetici.checked = true;
    else
        document.all.chkYonetici.checked = false;
}

function VeriGosterPerDil(dil, puan, tarih) {
    document.all.ddlDil.value = dil;
    document.all.txtPuan.value = puan;
    document.all.txtTarih.value = tarih;
}

function VeriGosterPerKurs(kurs, puan, tarih) {
    document.all.ddlKurs.value = kurs;
    document.all.txtPuan.value = puan;
    document.all.txtTarih.value = tarih;
}

function VeriGosterPerAile(tcNo, ad, soyad, dtarih, cinsiyet, yakinlik, durum, karneNo, evlenmeTarihi, aileCuzdani, cocukYakinligi, anne, baba) {
    document.all.txtMernisNo.value = tcNo;
    document.all.txtAd.value = ad;
    document.all.txtSoyad.value = soyad;
    document.all.txtDogumTarih.value = dtarih;
    document.all.ddlCinsiyet.value = cinsiyet;
    document.all.ddlYakinlik.value = yakinlik;
    document.all.ddlDurum.value = durum;
    document.all.txtKarneNo.value = karneNo;
    document.all.txtEvlenmeTarihi.value = evlenmeTarihi;
    document.all.txtAileCüzdaniNo.value = aileCuzdani;
    document.all.ddlCocukYakinligi.value = cocukYakinligi;
    document.all.txtAnneAdi.value = anne;
    document.all.txtBabaAdi.value = baba;
    PanelGosterAile();
}

function SozlukAc(sayfa) {
    PopupWin(sayfa + "?menuYok=1", 580, 340, 'sozluk');
}

function UnvanEkle() {
    PopupWin("DegerSec.aspx?menuYok=1&girisListeAd=unvan&degerSayisi=1&degerAlanAd=lblUnvan&degerAlanDegerAlanAd=txtUnvan&yeniKayitURL=", 580, 340, 'degerSec');
}

function MuhasebeGoster() {
    try { document.all.lblHata.innerHTML = ""; }
    catch (e) { }

    var yil = ""; //document.all.ddlYil.value;
    var kurum = ""; //document.all.txtKurum.value;

    showPopWin("../ButceMuhasebe/ListeMuhasebeBirim.aspx?yil=" + yil + "&kurum=" + kurum, 500, 300, true, null);
}

function MuhasebeBirimGoster() {
    try { document.all.lblHata.innerHTML = ""; }
    catch (e) { }

    var yil = ""; //document.all.ddlYil.value;
    var kurum = ""; //document.all.txtKurum.value;
    var muhasebe = document.all.txtMuhasebe.value;

    showPopWin("../ButceMuhasebe/ListeMuhasebeBirim.aspx?yil=" + yil + "&kurum=" + kurum + "&muhasebe=" + muhasebe, 500, 300, true, null);
}

function BankaSubeEkle() {
    var banka = document.all.ddlBanka.value;

    if (banka == "" || banka == "0")
        alert("İlk önce personelin hesabının bulunduğu banka bilgisini seçin.");
    else
        PopupWin("DegerSec.aspx?menuYok=1&girisListeAd=bankasube&degerSayisi=1&degerAlanAd=lblBankaSubeAd&degerAlanDegerAlanAd=txtBankaSubeKodu&yeniKayitURL=&eksorgubilgi=" + banka, 580, 340, 'degerSec');
}

function EvrakBirimEkle() {
    var birimKod = "";
    try { birimKod = document.all.txtEvrakBirimKod.value; }
    catch (e) { }
    
    showPopWin("../Evrak/ListeBirim.aspx?birimKod=" + birimKod, 500, 350, true, null);
}

function PersonelDilAc() {
    try { document.all.lblHata.innerHTML = ""; }
    catch (e) { }
    showPopWin("../Personelv2/PersonelDil.aspx?menuYok=1&perno=" + document.all.txtMernisNo.value, 570, 470, true, null);
}

function PersonelKursAc() {
    try { document.all.lblHata.innerHTML = ""; }
    catch (e) { }
    showPopWin("../Personelv2/PersonelKurs.aspx?menuYok=1&perno=" + document.all.txtMernisNo.value, 570, 470, true, null);
}

function PersonelAileAc() {
    try { document.all.lblHata.innerHTML = ""; }
    catch (e) { }
    showPopWin("../Personelv2/PersonelAile.aspx?menuYok=1&perno=" + document.all.txtMernisNo.value, 670, 470, true, null);
}

function PanelGoster() {
    var ddl = document.getElementById("ddlIstihdamm");
    var panel = document.getElementById("fldPersonelKatsayi");
    if (ddl.value == "2" || ddl.value == "4") //Sözleşmeli, İşçi
        panel.style.display = "";
    else
        panel.style.display = "none";
}

function PanelGosterAile() {
    var ddl = document.getElementById("ddlYakinlik");
    var panel = document.getElementById("pnlEvlilik");
    var panel2 = document.getElementById("pnlCocukDurumu");
    if (ddl.value == "1") //Eşi
        panel.style.display = "";
    else
        panel.style.display = "none";

    if (ddl.value == "2") //Çocuğu
        panel2.style.display = "";
    else
        panel2.style.display = "none";
}

function NodeSecildiYerelPopUp(node) {
    var kod = node.Value;
    var ad = node.Text;
    tanim = ad.split('-');
    if (kod != "") {
        document.all.txtEvrakBirimKod.value = tanim[0];
        document.all.lblEvrakBirimKod.innerHTML = tanim[1];
    }
}
