﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using TNS;
using TNS.PER;
using TNS.KYM;
using OrtakClass;

namespace Personel
{
    public partial class DegerSec : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();

        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = "Değer Seçimi";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(false);

            btnTamam.Attributes.Add("onclick", "listeye_ekle_sayfa('lstDest','" + Request.QueryString["degerAlanAd"] + "','" + Request.QueryString["degerAlanDegerAlanAd"] + "');javascript:self.close();");
            Page.ClientScript.RegisterOnSubmitStatement(Page.GetType(), "OnSubmit", "hepsini_sec('lstDest')");

            if (!IsPostBack)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "onLoad", "<SCRIPT language=javascript>hedef_liste_olustur('lstSrc','lstDest','" + Request.QueryString["degerAlanDegerAlanAd"] + "');</SCRIPT>");

                hdngirisListeAd.Value = Request.QueryString["girisListeAd"];
                string listeDoldurma = Request.QueryString["girisListeDoldurma"] + "";
                string yeniKayitURL = Request.QueryString["yeniKayitURL"] + "";
                if (yeniKayitURL.Trim() != "")
                    lblYeniGiris.Text = "<a href=\"#\" onClick=\"SozlukAc('" + yeniKayitURL + "');\">Aradığınızı bulamadıysanız buraya tıklayarak yeni kayıt girebilirsiniz.</a>";

                //seçim tek veya çoklu olması
                txtSecimSayisi.Value = Request.QueryString["degerSayisi"];

                if (OrtakFonksiyonlar.ConvertToInt(listeDoldurma, 0) != 1)
                {
                    lstSrc.Items.Clear();

                    ListeDoldur(lstSrc);
                }
                txtArama.Focus();
            }
        }

        void ListeDoldur(HtmlSelect lstKontrol)
        {
            ObjectArray listeVAN = new ObjectArray();
            string girisListeAd = hdngirisListeAd.Value;
            
            lstKontrol.Items.Clear();

            if (girisListeAd.Trim().CompareTo("unvan") == 0)
            {
                Unvan unvan = new Unvan();
                if (txtArama.Text.Trim() != "")
                    unvan.ad = txtArama.Text;

                listeVAN = servisPER.UnvanListele(unvan);
                foreach (Unvan y in listeVAN.objeler)
                    lstKontrol.Items.Add(new ListItem(y.ad, y.kod.ToString()));
            }
            else if (girisListeAd.Trim().CompareTo("bankasube") == 0)
            {
                BankaSube bs = new BankaSube();
                bs.bankaKodu = Request.QueryString["eksorgubilgi"] + "";
                if (txtArama.Text.Trim() != "")
                    bs.ad = txtArama.Text;

                listeVAN = servisPER.BankaSubeListele(bs);
                foreach (BankaSube y in listeVAN.objeler)
                    lstKontrol.Items.Add(new ListItem(y.ad, y.kod));
            }
        }

        protected void btnAra_Click(object sender, EventArgs e)
        {
            ListeDoldur(lstSrc);
        }
    }
}
