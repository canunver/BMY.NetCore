﻿<%@ Page Language="C#" CodeBehind="DegerSec.aspx.cs" Inherits="Personel.DegerSec" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
	<title></title>
    <meta http-equiv="Pragma" content="no-cache">
	<link href="../App_themes/Form.css" type="text/css" rel="stylesheet"/>
	<script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
	<script language="JavaScript" type="text/javascript" src="../script/add_remove.js?mc=03022015"></script>
	<script language="JavaScript" type="text/javascript" src="../script/comboSelect.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>
</head>
<body style="margin:10px;text-align:left;">
    <script language="Javascript" type="text/javascript">window.focus();</script>
    <form id="aspnetForm" runat="server">
	    <asp:label id="lblHata" Runat="server" Visible="false"></asp:label>
        <input type="hidden" id="hdngirisListeAd" runat="server" />	    
	    <table cellspacing="2" cellpadding="2" border="0" class="form">
		    <tr>
			    <td>
			        <b>Kriter :</b>&nbsp;<asp:TextBox ID="txtArama" runat="server" Width="150" CssClass="veriAlanTD"></asp:TextBox>&nbsp;<asp:Button ID="btnAra" Width="30" Text="Bul" runat="server" CssClass="dugme" OnClick="btnAra_Click"/></td>
			    <td></td>
			    <td><asp:Label ID="lblYeniGiris" runat="server"></asp:Label></td>
		    </tr>
		    <tr>
			    <td><b>Bütün Değerler</b></td>
			    <td></td>
			    <td><b>Seçilmiş Değerler</b></td>
		    </tr>
	        <tr>
		        <td width="49%">
			        <select id="lstSrc" name="lstSrc" multiple runat="server" style="width: 100%; height: 150px" ondblclick="listeye_ekle('lstSrc','lstDest',document.all.txtSecimSayisi.value)" onkeypress="return shiftHighlight(event.keyCode, this);"></select>
		        </td>
		        <td align="center" width="2%">
			        <p>
				        <a href="Javascript:listeye_ekle('lstSrc','lstDest',document.all.txtSecimSayisi.value);"><img alt="Ekle" src="../App_themes/images/scroll_right.gif" border="0" /></a>
			            <br />
				        <br />
				        <a href="Javascript:listeden_cikart('lstSrc','lstDest');"><img alt="Çıkart" src="../App_themes/images/scroll_left.gif" border="0" /></a>
			        </p>
		        </td>
		        <td width="49%">
			        <select id="lstDest" name="lstDest" enableviewstate="false" multiple runat="server" style="width: 100%; height: 150px" ondblclick="listeden_cikart('lstSrc','lstDest')" onkeypress="return shiftHighlight(event.keyCode, this);"></select>
		        </td>
	        </tr>
        </table>

        <div class="row">
            <table width="100%" cellspacing="2" cellpadding="2" border="0">
	            <tr>
                    <td align="center">
			            <asp:button id="btnTamam" runat="server" CssClass="dugme" Text="Tamam" Width="100px"></asp:button>&nbsp;
			            <input type="button" id="btnKapat" class="dugme" value="İptal" style="WIDTH:100px" onclick="javascript:self.close();" />
		            </td>
	            </tr>
            </table>
        </div>
        <div class="bilgiKutusu">
		    Seçmek istediklerinizi "Bütün Değerler" listesinden 
		    seçiniz ve ortadaki sağ ok düğmesini kullanarak "Seçilmiş Değerler" listesine 
		    aktarın. Seçilmiş listesinden çıkartmak istediğiniz değerler için listeden 
		    istediğinizi seçip sol ok düğmesine basınız.
	    </div>

	<input type="hidden" id="txtSecimSayisi" runat="server" name="txtSecimSayisi" />
    </form>
</body>
</html>
