﻿<%@ Page Language="C#" CodeBehind="PersonelKisa.aspx.cs" Inherits="Personel.PersonelKisa"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
	<title></title>
	<link href="../App_themes/Form.css" type="text/css" rel="stylesheet"/>
	<link href="../App_themes/popupDialog.css" type="text/css" rel="stylesheet" />
	<script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
	<script language="JavaScript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>
	<script language="Javascript" type="text/javascript" src="../script/popupDialog.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript" src="../script/popupDialog2.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>
    <script language="Javascript" type="text/javascript">
        var personelListeGoster=false;
    </script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <asp:label id="lblHata" Visible="false" Runat="server"></asp:label>
    <input type="hidden" id="hdnTCKimlikNo" runat="server" />
    <div class="form">
        <div class="kolonArasi">
            <fieldset style="margin:0px;padding:5px;">
	            <table cellpadding="2" cellspacing="2" width="100%">
	                <tr>
	                    <td>
	                        <asp:Button runat="server" ID="btnKaydet" CssClass="dugme" Text="Kaydet" OnClick="btnKaydet_Click" Width="80" />
                            <asp:Button runat="server" ID="btnAra" CssClass="dugme" Text="Bul" OnClick="btnAra_Click" Width="80" />
                            <asp:Button runat="server" ID="btnTemizle" CssClass="dugme" Text="Temizle" OnClick="btnTemizle_Click" Width="80" />
                        </td>
	                </tr>
	            </table>
	        </fieldset>
            <asp:Label ID="lblGuncelleme" runat="server"></asp:Label>
            <fieldset class="row">
                <legend><img src="../App_Themes/images/masa.gif" alt="Birim Bilgileri" width="16" height="16" align="left" />Birim Bilgileri</legend>
                <div class="row">
                    <div class="yaziAlanK">Muhasebe Kodu</div>
		            <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:TextBox id="txtMuhasebe" runat="server" CssClass="veriAlan" MaxLength="5" Columns="7"></asp:TextBox></div>
                    <div class="veriAlan"><input type="image" alt="Muhasebe Listesi" style="height:14px;width:16px;" class="veriAlan" onclick="javascript:MuhasebeGoster();return false;" tabindex="100" src="../App_themes/images/bul1.gif" /></div>
			        <div class="kolonArasi"></div>
			        <div class="veriAlan"><asp:label id="lblMuhasebeAd" Width="100%" runat="server" CssClass="veriAlan"></asp:label></div>
                </div>
                <div class="row">
                    <div class="yaziAlanK">Birim Kodu</div>
		            <div class="ikiNokta">:</div>
                    <div class="veriAlan"><asp:TextBox id="txtBirim" runat="server" CssClass="veriAlan" MaxLength="3" Columns="7"></asp:TextBox></div>
                    <div class="veriAlan"><input type="image" alt="Muhasebe Birim Listesi" style="height:14px;width:16px;" class="veriAlan" onclick="javascript:MuhasebeBirimGoster();return false;" tabindex="100" src="../App_themes/images/bul1.gif" /></div>
			        <div class="kolonArasi"></div>
			        <div class="veriAlan"><asp:label id="lblBirimAd" Width="100%" runat="server" CssClass="veriAlan"></asp:label></div>
                </div>
	        </fieldset>
            <fieldset class="row">
                <legend><img src="../App_Themes/images/personel.gif" alt="Personel Bilgileri" width="16" height="16" align="left" />Personel Bilgileri</legend>
	            <div class="row">
		            <div class="yaziAlanK">T.C.Kimlik No&nbsp;<a href="http://tckimlik.nvi.gov.tr/Web/" target="_blank"><img alt="Kullanıcının T.C. Kimlik Numarası öğrenmek için lütfen tıklayın" src="../App_themes/images/dunya.gif" /></a></div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtMernisNo" runat="server" CssClass="veriAlan" Columns="20" MaxLength="11"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="veriAlan"><asp:ImageButton id="imgKimlik" tabIndex="100" runat="server" CssClass="veriAlan" Height="17" Width="22" OnClick="imgKimlik_Click" ImageUrl="../App_themes/images/kimlik4.gif" ToolTip="Verilen T.C.Kimlik Numarasından ad ve soyad bilgilerini getir"></asp:ImageButton></div>
		            <div class="kolonArasi"></div>
		            <div class="veriAlan"><asp:label id="lblMernisHata" runat="server" CssClass="veriAlan" Width="100%"></asp:label></div>
                </div>
	            <div class="row">
		            <div class="yaziAlanK">Sicil No</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox ID="txtSicilNo" runat="server" CssClass="veriAlan" Columns="20" MaxLength="10"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlanK">Adı</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtAd" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
		            <div class="kolonArasi"></div>
		            <div class="yaziAlanK">Soyadı</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan"><asp:TextBox id="txtSoyad" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
                </div>
	            <div class="row">
		            <div class="yaziAlan">İş Telefonu</div>
		            <div class="ikiNokta">:</div>
		            <div class="veriAlan" style="width:140px;"><asp:TextBox id="txtIsTel" runat="server" CssClass="veriAlan" Columns="20" MaxLength="25"></asp:TextBox></div>
                </div>
	        </fieldset>
        </div>
    </div>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
    <script language="Javascript" type="text/javascript">
        if (personelListeGoster)
            window.setTimeout("showPopWin('PersonelListe.aspx' , 600, 500, true, null);", 20);
    </script>
</body>
</html>
