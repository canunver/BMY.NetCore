﻿<%@ Page Language="C#" CodeBehind="TanimUstBirim.aspx.cs" Inherits="Personel.TanimUstBirim" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
	<title></title>
	<link href="../App_themes/Form.css" type="text/css" rel="stylesheet"/>
    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
	<asp:label id="lblHata" Runat="server" Visible="false"></asp:label>
    <div class="form">
	    <div class="row">
		    <div class="yaziAlanK">Kod</div>
		    <div class="ikiNokta">:</div>
		    <div class="veriAlan"><asp:TextBox ID="txtKod" runat="server" CssClass="veriAlan" Columns="10"></asp:TextBox></div>
        </div>
	    <div class="row">
		    <div class="yaziAlanK">Üst Birim Adı</div>
		    <div class="ikiNokta">:</div>
		    <div class="veriAlan"><asp:TextBox ID="txtAd" runat="server" CssClass="veriAlan" Columns="30"></asp:TextBox></div>
        </div>
        <div class="footer">&nbsp;</div>
    </div>
    <div class="row">
	    <table width="100%" cellpadding="2" cellspacing="2">
		    <tr>
			    <td align="center">
                    <asp:Button runat="server" ID="btnKaydet" CssClass="dugme" Text="Kaydet" OnClick="btnKaydet_Click" Width="70" />
                    <asp:Button runat="server" ID="btnSil" CssClass="dugme" Text="Sil" OnClick="btnSil_Click" Width="70" />
                    <asp:Button runat="server" ID="btnAra" CssClass="dugme" Text="Bul" OnClick="btnAra_Click" Width="70" />
                    <input type="button" id="btnTemizle" class="dugme" style="width:70px;" value="Temizle" onclick="VeriGosterUstBirim('','','');" />
			    </td>
		    </tr>
	    </table>
    </div>

    <div class="row">
        <div style="overflow: auto; height: 300px;">
            <asp:DataGrid ID="dgListe" runat="server" AllowCustomPaging="False" AllowSorting="False"
                AutoGenerateColumns="False" BorderWidth="0" CellPadding="3"
                Font-Bold="False" Font-Italic="False" Font-Names="Tahoma" Font-Overline="False"
                Font-Size="8pt" Font-Strikeout="False" Font-Underline="False" ForeColor="#333333"
                PageSize="1" Width="98%">
                <FooterStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
                <EditItemStyle BackColor="#999999" />
                <SelectedItemStyle BackColor="#E2DED6" Font-Bold="True" ForeColor="#333333" />
                <PagerStyle BackColor="#284775" ForeColor="White" HorizontalAlign="Center" Mode="NumericPages" />
                <AlternatingItemStyle BackColor="White" ForeColor="#284775" />
                <ItemStyle BackColor="#F7F6F3" ForeColor="#333333" />
                <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" Font-Italic="False" Font-Names="Tahoma"
                    Font-Overline="False" Font-Size="8pt" Font-Strikeout="False" Font-Underline="False"
                    ForeColor="White" HorizontalAlign="Center" VerticalAlign="Middle" />
                <Columns>
                    <asp:BoundColumn DataField="kod" HeaderText="Kod" ItemStyle-Width="50px"></asp:BoundColumn>
                    <asp:BoundColumn DataField="ad" HeaderText="Adı"></asp:BoundColumn>
                </Columns>
            </asp:DataGrid>
        </div>
    </div>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
