﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class PersonelListe : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();
        TNS.PER.Personel perKriter;

        protected void Page_Load(object sender, EventArgs e)
        {
            perKriter = new TNS.PER.Personel();
            perKriter.unvanKodu = OrtakFonksiyonlar.ConvertToInt(Request.QueryString["unvanKod"], 0);
            if (!IsPostBack)
            {
                
                Listele(perKriter);
            }
        }

        void Listele(TNS.PER.Personel p)
        {
            ObjectArray pVAN = servisPER.PersonelListele(kullanan, p);
            if (!pVAN.sonuc.islemSonuc)
            {
                GenelIslemler.HataYaz(this, pVAN.sonuc.hataStr);
                return;
            }
            if (pVAN.objeler.Count <= 0)
            {
                GenelIslemler.BilgiYaz(this, pVAN.sonuc.bilgiStr);
                return;
            }
            Listele(pVAN);
        }

        void Listele(ObjectArray pVAN)
        {
            if (pVAN == null)
                return;

            string jsFn = null;
            if (!string.IsNullOrEmpty(Request.QueryString["jsFn"]))
            {
                jsFn = Request.QueryString["jsFn"];

                if (pVAN.objeler.Count == 1)
                {
                    TNS.PER.Personel p = (TNS.PER.Personel)pVAN.objeler[0];
                    ClientScript.RegisterStartupScript(this.GetType(), "tekPersonel", JsFnCagriOl(jsFn, p.tcKimlikNo + " (" + p.ad + " " + p.soyad + ")"), true);
                    return;
                }
            }

            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("tcKimlik");
                dt.Columns.Add("sicilNo");
                dt.Columns.Add("ad");
                dt.Columns.Add("soyad");
                dt.Columns.Add("muhasebe");
                dt.Columns.Add("birim");

                foreach (TNS.PER.Personel p in pVAN.objeler)
                {
                    if (!string.IsNullOrEmpty(jsFn))
                        dt.Rows.Add("<a href='#' onclick=\"" + JsFnCagriOl(jsFn, p.tcKimlikNo + " (" + p.ad + " " + p.soyad + ")") + "\">" + p.tcKimlikNo + "</a>", p.sicilNo, p.ad, p.soyad, p.muhasebeKodu, p.birimKodu);
                    else
                        dt.Rows.Add("<a href='#' onclick=\"VeriGoster('" + p.tcKimlikNo + "');\">" + p.tcKimlikNo + "</a>", p.sicilNo, p.ad, p.soyad, p.muhasebeKodu, p.birimKodu);
                }

                dgListe.DataSource = dt;
                dgListe.DataBind();
            }
            catch
            {
            }
        }

        private string JsFnCagriOl(string jsFn, string kodAd)
        {
            return jsFn + "('" + kodAd + "','" + Request.QueryString["cagiran"] + "');";
        }

        protected void lnkYazdir_Click(object sender, EventArgs e)
        {
            ObjectArray pVAN = servisPER.PersonelListele(kullanan, perKriter);
            if (pVAN == null)
                GenelIslemler.HataYaz(this, "Kayıt bulunamadı!");
            else if(!pVAN.sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, pVAN.sonuc.hataStr);


            Tablo XLS = GenelIslemler.NewTablo();
            string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            string sablonAd = "";
            int satirD = 0;
            int sutunD = 0;

            sablonAd = "PER-PersonelListe.xlt";
            XLS.DosyaAc(System.Web.HttpContext.Current.Server.MapPath("~") + "/RaporSablon/PERv2/" + sablonAd, sonucDosyaAd);

            XLS.HucreAdAdresCoz("BaslaSatir", ref satirD, ref sutunD);
            int satir = satirD + 1;

            foreach (TNS.PER.Personel p in pVAN.objeler)
            {
                XLS.HucreKopyala(satirD, sutunD, satirD, sutunD + 20, satir, 0);
                string unvanAd = GenelIslemler.KodAd(22, p.unvanKodu.ToString(), true);

                XLS.HucreDegerYaz(satir, 0, p.tcKimlikNo);
                XLS.HucreDegerYaz(satir, 1, p.sicilNo);
                XLS.HucreDegerYaz(satir, 2, p.ad);
                XLS.HucreDegerYaz(satir, 3, p.soyad);
                XLS.HucreDegerYaz(satir, 4, unvanAd);

                satir++;
            }
            XLS.DosyaSaklaTamYol();
            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "Liste", true, GenelIslemler.ExcelTur());
        }
    }
}
