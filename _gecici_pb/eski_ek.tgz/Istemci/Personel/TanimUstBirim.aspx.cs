﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class TanimUstBirim : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Üst Birim Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            lblHata.Visible = false;

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                Listele(new UstBirim());
            }
        }

        public void Listele(UstBirim kriter)
        {
            lblHata.Visible = false;
            dgListe.DataBind();

            ObjectArray dler = new ObjectArray();
            dler = servisPER.UstBirimListele(kriter);

            if (dler.sonuc.islemSonuc)
            {
                if (dler.objeler.Count > 0)
                {
                    DataTable dt = new DataTable();
                    dt.Columns.Add("kod");
                    dt.Columns.Add("ad");
                    foreach (UstBirim d in dler.objeler)
                        dt.Rows.Add(d.kod, "<a href='#' onclick=\"VeriGosterUstBirim('" + d.ad + "','" + d.kod + "');return false;\">" + d.ad + "</a>");

                    dgListe.DataSource = dt;
                    dgListe.DataBind();
                }
                else
                    GenelIslemler.BilgiYaz(this, dler.sonuc.bilgiStr);
            }
            else
                GenelIslemler.HataYaz(this, dler.sonuc.hataStr);
        }

        protected void btnAra_Click(object sender, EventArgs e)
        {
            UstBirim d = new UstBirim();
            d.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text.Trim(), 0);
            d.ad = txtAd.Text.Trim();
            Listele(d);
        }

        protected void btnKaydet_Click(object sender, EventArgs e)
        {
            lblHata.Visible = false;
            string hata = "";

            if (OrtakFonksiyonlar.ConvertToInt(txtKod.Text.Trim(),0) == 0)
                hata = "Kod boş bırakılamaz";

            if (txtAd.Text.Trim() == "")
            {
                if (hata != "") hata += "<br>";
                hata += "Unvan bilgisi boş bırakılamaz";
            }

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            UstBirim d = new UstBirim();
            d.kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text.Trim(), 0);
            d.ad = txtAd.Text;

            Sonuc sonuc = servisPER.UstBirimKaydet(kullanan, d);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
            {
                txtKod.Text = "";
                txtAd.Text = "";
                Listele(new UstBirim());
                GenelIslemler.BilgiYaz(this, "Kayıt işlemi başarıyla gerçekleşti.");
            }
        }

        protected void btnSil_Click(object sender, EventArgs e)
        {
            lblHata.Visible = false;

            UstBirim d = new UstBirim();
            int kod = OrtakFonksiyonlar.ConvertToInt(txtKod.Text.Trim(), 0);

            if (kod > 0)
            {
                d.kod = kod;
                Sonuc sonuc = servisPER.UstBirimSil(kullanan, d);

                if (!sonuc.islemSonuc)
                    GenelIslemler.HataYaz(this, sonuc.hataStr);
                else
                {
                    txtKod.Text = "";
                    txtAd.Text = "";
                    Listele(new UstBirim());
                    GenelIslemler.BilgiYaz(this, "Silme işlemi başarıyla gerçekleşti.");
                }
            }
            else
                GenelIslemler.HataYaz(this, "Lütfen silmek istediğiniz ünvanı seçin.");
        }
    }
}
