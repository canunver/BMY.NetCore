﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class PersonelKisa : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Personel Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            lblHata.Visible = false;

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            this.txtMuhasebe.Attributes.Add("onblur", "kodAdGetir('11','lblMuhasebeAd',true,new Array('txtMuhasebe'),'KONTROLDENOKU');");
            this.txtBirim.Attributes.Add("onblur", "kodAdGetir('12','lblBirimAd',false,new Array('txtBirim','txtMuhasebe'),'KONTROLDENOKU');");

            if (Request.Form["hdnTCKimlikNo"] + "" != "")
                Listele();

            if (!IsPostBack)
            {
                txtBirim.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "PERBIRIM");
                txtMuhasebe.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "PERMUHASEBE");
            }

            SozlukAciklamalariniGetir();
        }

        protected void btnKaydet_Click(object sender, EventArgs e)
        {
            lblHata.Visible = false;
            string hata = "";

            if (txtMernisNo.Text.Trim() == "")
                hata += "T.C Kimlik Numarası boş bırakılamaz";
            if (txtSicilNo.Text.Trim() == "")
            {
                if (hata != "") hata += "<br>";
                hata += "Sicil Numarası boş bırakılamaz";
            }
            if (txtAd.Text.Trim() == "" || txtSoyad.Text.Trim() == "")
            {
                if (hata != "") hata += "<br>";
                hata += "Ad ve Soyadı boş bırakılamaz";
            }
            if (txtMuhasebe.Text.Trim() == "")
            {
                if (hata != "") hata += "<br>";
                hata += "Muhasebe Birim Kodu boş bırakılamaz";
            }
            if (txtBirim.Text.Trim() == "")
            {
                if (hata != "") hata += "<br>";
                hata += "Birim Kodu boş bırakılamaz";
            }
            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            DegiskenleriKaydet();

            TNS.PER.Personel p = new TNS.PER.Personel();

            EkrandanSinifa(ref p);

            Sonuc sonuc = servisPER.PersonelKaydet(kullanan, p);

            if (!sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, sonuc.hataStr);
            else
                GenelIslemler.BilgiYaz(this, sonuc.bilgiStr);
        }

        protected void btnAra_Click(object sender, EventArgs e)
        {
            Listele();
        }

        void Listele()
        {
            lblHata.Visible = false;
            string hata = "";

            if (txtMuhasebe.Text == "")
                hata = "Muhasebe bilgisi boş bırakılamaz<br>";

            if (txtBirim.Text == "")
                hata += "Muhasebe Birim bilgisi boş bırakılamaz";

            if (hata != "")
            {
                GenelIslemler.HataYaz(this, hata);
                return;
            }

            DegiskenleriKaydet();

            TNS.PER.Personel pL = new TNS.PER.Personel();

            if (hdnTCKimlikNo.Value == "")
                EkrandanSinifa(ref pL);
            else
            {
                pL.tcKimlikNo = hdnTCKimlikNo.Value;
                pL.muhasebeKodu = OrtakFonksiyonlar.ConvertToInt(txtMuhasebe.Text, 0);
                pL.birimKodu = txtBirim.Text;
                hdnTCKimlikNo.Value = "";
            }

            ObjectArray pVAN = new ObjectArray();

            pVAN = servisPER.PersonelListele(kullanan, pL);

            if (!pVAN.sonuc.islemSonuc)
                GenelIslemler.HataYaz(this, pVAN.sonuc.hataStr);
            else
            {
                if (pVAN.objeler.Count == 0)
                {
                    if (pVAN.sonuc.bilgiStr != "")
                        GenelIslemler.BilgiYaz(this, pVAN.sonuc.bilgiStr);
                    else
                        GenelIslemler.BilgiYaz(this, "Verilen kriterlere uygun personel bulunamadı");
                }
                else
                {
                    if (pVAN.objeler.Count > 1)
                    {
                        OturumBilgisiIslem.BilgiYazDegisken("personelListe", pVAN);
                        ClientScript.RegisterStartupScript(this.GetType(), "Liste", "<script>personelListeGoster=true;</script>");
                    }
                    else
                    {
                        btnTemizle_Click(null, null);

                        foreach (TNS.PER.Personel p in pVAN.objeler)
                        {
                            txtMernisNo.Text = p.tcKimlikNo;
                            txtSicilNo.Text = p.sicilNo;
                            txtAd.Text = p.ad;
                            txtSoyad.Text = p.soyad;
                            txtIsTel.Text = p.isTelefon;
                            lblGuncelleme.Text = "Bu personel en son <b>" + p.guncellenmeTarihi.ToLongString() + "</b> tarihinde <b>" + p.guncelleyenKisi + "</b> tarafından güncellenmiştir.";

                            txtMuhasebe.Text = p.muhasebeKodu.ToString();
                            txtBirim.Text = p.birimKodu;

                            SozlukAciklamalariniGetir();
                        }
                    }
                }
            }
        }

        void EkrandanSinifa(ref TNS.PER.Personel p)
        {
            p.tcKimlikNo = txtMernisNo.Text;
            p.sicilNo = txtSicilNo.Text;
            p.ad = txtAd.Text;
            p.soyad = txtSoyad.Text;
            p.isTelefon = txtIsTel.Text;

            p.muhasebeKodu = OrtakFonksiyonlar.ConvertToInt(txtMuhasebe.Text, 0);
            p.birimKodu = txtBirim.Text.Trim();
            p.guncellenmeTarihi = new TNSDateTime(DateTime.Now);
        }

        protected void btnTemizle_Click(object sender, EventArgs e)
        {
            txtMernisNo.Text = "";
            txtSicilNo.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            txtIsTel.Text = "";

            txtMuhasebe.Text = "";
            txtBirim.Text = "";
            lblGuncelleme.Text = "";

            txtBirim.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "PERBIRIM");
            txtMuhasebe.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "PERMUHASEBE");
        }

        protected void imgKimlik_Click(object sender, System.EventArgs e)
        {
            KullaniciVAN kVAN = GenelIslemler.MernisOku(kullanan, txtMernisNo.Text, new TNSDateTime());
            if (kVAN.sonuc.islemSonuc)
            {
                lblMernisHata.Text = "";
                txtAd.Text = kVAN.kullanici.ad;
                txtSoyad.Text = kVAN.kullanici.soyad;
            }
            else
            {
                txtAd.Text = "";
                txtSoyad.Text = "";
                lblMernisHata.Text = "<b>Hata : </b>Kimlik Doğrulama Servisi ile bağlantı kurulamıyor veya verilen kimlik numarası hatalı.";
            }
        }


        void SozlukAciklamalariniGetir()
        {
            if (txtMuhasebe.Text.Trim() != "")
                lblMuhasebeAd.Text = GenelIslemler.KodAd(11, txtMuhasebe.Text.Trim(), true);

            if (txtBirim.Text.Trim() != "")
                lblBirimAd.Text = GenelIslemler.KodAd(12, txtBirim.Text.Trim() + "-" + txtMuhasebe.Text.Trim(), false);
        }

        void DegiskenleriKaydet()
        {
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "PERBIRIM", txtBirim.Text);
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "PERMUHASEBE", txtMuhasebe.Text);
        }
    }
}
