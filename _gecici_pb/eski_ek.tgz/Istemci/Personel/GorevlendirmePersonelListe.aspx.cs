﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;

namespace Personel
{
    public partial class GorevlendirmePersonelListe : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();
        ObjectArray liste = new ObjectArray();
        public const string GorevlendirmePersonel = "GorevlendirmePersonel";
        public int gorevlendirmeNo = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Görevlendirme Yer Tarih Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);

            ViewState["muhasebe"] = Request.QueryString["muhasebe"] + "";
            ViewState["birim"] = Request.QueryString["birim"] + "";
            ViewState["gorevlendirmeNo"] = Request.QueryString["gorevlendirmeNo"] + "";
            gorevlendirmeNo = OrtakFonksiyonlar.ConvertToInt(ViewState["gorevlendirmeNo"].ToString(), 0);

            //Sayfaya giriş izni varmı?
            if (!TNS.PER.Yetki.YetkiVarMiOkumaya(kullanan))
                GenelIslemler.SayfayaGirmesin(true);

            if (!IsPostBack)
                Listele();
        }

        void Listele()
        {
            if (Session[GorevlendirmePersonel] != null)
                liste = (ObjectArray)Session[GorevlendirmePersonel];
            else if (gorevlendirmeNo > 0)
            {
                Session[GorevlendirmePersonel] = null;
                //Goreve ait personel listesini al. 
                //Global liste ObjectArray a ekle
            }

            if (liste.ObjeSayisi > 0)
            {
                pnlSecilenPersonelListeGoster.Visible = true;
                pnlPersonelListeEkle.Visible = false;
                ListeleSecilenPersonel(liste);
            }
            else
            {
                pnlSecilenPersonelListeGoster.Visible = false;
                pnlPersonelListeEkle.Visible = true;
            }
        }

        private void ListeleSecilenPersonel(ObjectArray liste)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("tckimlikno");
                dt.Columns.Add("ad");
                dt.Columns.Add("soyad");
                dt.Columns.Add("unvankod");
                dt.Columns.Add("unvan");
                dt.Columns.Add("muhasebe");
                dt.Columns.Add("birim");
                dt.Columns.Add("kadroderece");
                dt.Columns.Add("ekgosterge");

                foreach (TNS.PER.Personel p in liste.objeler)
                    dt.Rows.Add(p.tcKimlikNo, p.ad, p.soyad, p.unvanKodu, p.unvanAd, p.muhasebeKodu, p.birimKodu, p.kadroDerece, p.emekliEsasGosterge);

                dgSecilenPersonelListe.DataSource = dt;
                dgSecilenPersonelListe.DataBind();

                lbtListeToplam.Text = liste.ObjeSayisi.ToString();
                pnlPersonelListeEkle.Visible = false;
                pnlSecilenPersonelListeGoster.Visible = true;
            }
            catch
            {
            }
        }

        private void ListelePersonel(ObjectArray liste)
        {
            try
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("tckimlikno");
                dt.Columns.Add("ad");
                dt.Columns.Add("soyad");
                dt.Columns.Add("unvankod");
                dt.Columns.Add("unvan");
                dt.Columns.Add("muhasebe");
                dt.Columns.Add("birim");
                dt.Columns.Add("kadroderece");
                dt.Columns.Add("ekgosterge");

                foreach (TNS.PER.Personel p in liste.objeler)
                    dt.Rows.Add(p.tcKimlikNo, p.ad, p.soyad, p.unvanKodu, p.unvanAd, p.muhasebeKodu, p.birimKodu, p.kadroDerece, p.emekliEsasGosterge);

                dgPersonelListe.DataSource = dt;
                dgPersonelListe.DataBind();
            }
            catch
            {
            }
        }

        protected void btnBul_Click(object sender, EventArgs e)
        {
            TNS.PER.Personel p = new TNS.PER.Personel();
            p.tcKimlikNo = txtKimlikNo.Text.Trim();
            p.ad = txtAd.Text.Trim();
            p.soyad = txtSoyad.Text.Trim();

            p.birimKodu = "-1";
            p.muhasebeKodu = 0;

            int muhasebeKodu = OrtakFonksiyonlar.ConvertToInt(ViewState["muhasebe"].ToString(), 0);
            string birimKodu = ViewState["birim"].ToString();
            if (rdHarcama.Checked)
            {
                p.muhasebeKodu = muhasebeKodu;
                p.birimKodu = birimKodu;
            }
            if (rdMuhasebe.Checked)
            {
                p.muhasebeKodu = muhasebeKodu;
                p.birimKodu = "-1";
            }

            if (p.ad == "" && p.soyad == "" && p.tcKimlikNo == "" && rdTumPersonel.Checked)
            {
                GenelIslemler.MesajKutusu(this, "Tüm Personellerde arama yapabilmek için en az bir kriter belirtmelidir.");
                return;
            }

            ObjectArray personelListe = new ObjectArray();
            personelListe = servisPER.PersonelListele(kullanan, p);
            liste.objeler = personelListe.objeler;

            ListelePersonel(liste);

        }

        protected void lbtListeToplam_Click(object sender, EventArgs e)
        {
            if (lbtListeToplam.Text == "0")
            {
                GenelIslemler.MesajKutusu(this, "Seçili personel bilgisi bulunmamaktadır.");
                return;
            }
            pnlPersonelListeEkle.Visible = false;
            pnlSecilenPersonelListeGoster.Visible = true;
        }

        protected void lbtYeniPersonelEkle_Click(object sender, EventArgs e)
        {
            pnlPersonelListeEkle.Visible = true;
            pnlSecilenPersonelListeGoster.Visible = false;
        }

        protected void btnSeciliPersonelSil_Click(object sender, EventArgs e)
        {
            bool secili = false;
            string tcKimlikNo = string.Empty;
            int secilenPersonelSayi = 0;

            foreach (DataGridItem item in dgSecilenPersonelListe.Items)
            {
                secili = (item.FindControl("chkPersonel") as CheckBox).Checked;
                if (secili)
                {
                    secilenPersonelSayi++;
                    TNS.PER.Personel p = new TNS.PER.Personel();
                    PersonelNesneDoldur(item, p);

                    if (gorevlendirmeNo > 0)
                    {
                        //veritabanindan sil
                    }
                    else
                    {
                        if (Session[GorevlendirmePersonel] != null)
                        {
                            liste = (ObjectArray)Session[GorevlendirmePersonel];
                            ListedenKaldir(liste, p);

                        }
                        else
                            GenelIslemler.MesajKutusu(this, "Listede kayıtlı personel bulunmamaktadır.");
                    }
                }
            }
            if (secilenPersonelSayi > 0)
                ListeleSecilenPersonel(liste);
            else
                GenelIslemler.MesajKutusu(this, "Seçili Personel bulunmamaktadır.");
        }

        private void ListedenKaldir(ObjectArray liste, TNS.PER.Personel p)
        {
            string tckimlikno = "";
            for (int i = 0; i < liste.ObjeSayisi; i++)
            {
                tckimlikno = ((TNS.PER.Personel)liste.objeler[i]).tcKimlikNo;
                if (tckimlikno == p.tcKimlikNo)
                {
                    liste.objeler.RemoveAt(i);
                    Session[GorevlendirmePersonel] = liste;
                    break;
                }
            }
        }

        private static void PersonelNesneDoldur(DataGridItem item, TNS.PER.Personel p)
        {
            p.tcKimlikNo = (item.FindControl("lblTCKimlikNo") as Label).Text;
            p.ad = (item.FindControl("lblAd") as Label).Text;
            p.soyad = (item.FindControl("lblSoyad") as Label).Text;
            p.unvanKodu = OrtakFonksiyonlar.ConvertToInt((item.FindControl("lblUnvanKod") as Label).Text, 0);
            p.unvanAd = (item.FindControl("lblUnvan") as Label).Text;
            p.muhasebeKodu = OrtakFonksiyonlar.ConvertToInt((item.FindControl("lblMuhasebeKod") as Label).Text, 0);
            p.birimKodu = (item.FindControl("lblBirimKod") as Label).Text;
            p.kadroDerece = OrtakFonksiyonlar.ConvertToInt((item.FindControl("lblKadroDerece") as Label).Text, 0);
            p.emekliEsasGosterge = OrtakFonksiyonlar.ConvertToInt((item.FindControl("lblEkGosterge") as Label).Text, 0);
        }

        protected void btnListeyeEkle_Click(object sender, EventArgs e)
        {
            TNSCollection personelListe = new TNSCollection();
            bool secili = false;
            string tcKimlikNo = string.Empty;

            foreach (DataGridItem item in dgPersonelListe.Items)
            {
                secili = (item.FindControl("chkPersonel") as CheckBox).Checked;
                if (secili)
                {
                    TNS.PER.Personel p = new TNS.PER.Personel();
                    PersonelNesneDoldur(item, p);
                    personelListe.Add(p);
                }
            }

            if (personelListe.Count > 0)
            {
                //Kontrol : Personel daha önce listede var mı diye kontrol et.
                if (gorevlendirmeNo > 0)
                {
                    //Seçilenleri veritabanına kaydet
                }
                else
                {
                    if (Session[GorevlendirmePersonel] != null)
                    {
                        liste = (ObjectArray)Session[GorevlendirmePersonel];
                    }

                    foreach (TNS.PER.Personel p in personelListe)
                    {
                        liste.objeler.Add(p);
                    }
                    Session[GorevlendirmePersonel] = liste;
                }
                ListeleSecilenPersonel(liste);
            }
            else
            {
                //Uyarı: seçili personel yok
            }
        }

    }
}
