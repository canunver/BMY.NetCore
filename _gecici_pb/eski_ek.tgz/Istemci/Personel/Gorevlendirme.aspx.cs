﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using TNS;
using TNS.KYM;
using TNS.PER;
using OrtakClass;
using WebServisler.EvrakServis;

namespace Personel
{
    public partial class Gorevlendirme : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();
        public const string GorevlendirmeYerTarih = "GorevlendirmeYerTarih";
        public const string GorevlendirmePersonel = "GorevlendirmePersonel";

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Görevlendirme Bilgileri";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            lblHata.Visible = false;

            //Sayfaya giriş izni varmı?
            //GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            //Sayfaya giriş izni varmı?
            if (!TNS.PER.Yetki.YetkiVarMiOkumaya(kullanan))
                GenelIslemler.SayfayaGirmesin(true);

            this.txtMuhasebe.Attributes.Add("onblur", "kodAdGetir('11','lblMuhasebeAd',true,new Array('txtMuhasebe'),'KONTROLDENOKU');");
            this.txtBirim.Attributes.Add("onblur", "kodAdGetir('12','lblBirimAd',false,new Array('txtBirim','txtMuhasebe'),'KONTROLDENOKU');");

            if (Request.Form["__EVENTTARGET"] == "DoldurSessionGorevlendirmeYerTarih")
            {
                DoldurSessionGorevlendirmeYerTarih();
            }

            if (Request.Form["__EVENTTARGET"] == "DoldurSessionGorevlendirmePersonel")
            {
                DoldurSessionGorevlendirmePersonel();
            }

            if (!IsPostBack)
            {

            }
        }

        private void Listele(Gorev gorev)
        {
            ObjectArray liste = servisPER.GorevListele(kullanan, gorev);
            if (liste.ObjeSayisi > 0)
            {
                Session[GorevlendirmeYerTarih] = null;
                Session[GorevlendirmePersonel] = null;
                gorev = (Gorev)liste.objeler[0];
                ListeleGorevlendirme(gorev);
                ListeleGorevlendirmeYerTarih(gorev.gorevYerleri);
                ListeleGorevlendirmePersonel(gorev.gorevliPersoneller);
            }
            else
                GenelIslemler.MesajKutusu(this, "Listelenecek bilgi bulunmamaktadır.");
        }
        private void ListeleGorevlendirme(Gorev gorev)
        {
            if (!string.IsNullOrEmpty(gorev.evrEvrakNo) && !string.IsNullOrEmpty(gorev.prEvrakNo))
            {
                pnlEvrakNo.Visible = true;
                lblEvrEvrakNo.Text = gorev.evrEvrakNo;
                lblPrEvrakNo.Text = gorev.prEvrakNo;
            }
            else
            {
                pnlEvrakNo.Visible = false;
                lblEvrEvrakNo.Text = string.Empty;
                lblPrEvrakNo.Text = string.Empty;
            }

            int gorevKod = gorev.kod;
            if (gorevKod > 0)
                lbtEvrakIslemleri.Visible = true;
            else
                lbtEvrakIslemleri.Visible = false;

            txtBelgeNo.Text = gorevKod.ToString();
            hdnBelgeNo.Value = gorev.kod.ToString();
            txtMuhasebe.Text = gorev.muhasebeKod.ToString();
            txtBirim.Text = gorev.birimKod;
            txtAmaci.Text = gorev.amac;
            ddlTur.SelectedValue = gorev.tur.ToString();
        }
        private void ListeleGorevlendirmeYerTarih(ObjectArray gorevYerleri)
        {
            dgGorevYerTarih.Visible = true;
            lblGorevYerTarihUyari.Visible = false;

            DataTable dt = new DataTable();
            dt.Columns.Add("bulunduguYer");
            dt.Columns.Add("gidecegiYer");
            dt.Columns.Add("tarihBaslangic");
            dt.Columns.Add("tarihBitis");
            dt.Columns.Add("bulunduguIlKod");
            dt.Columns.Add("bulunduguIlceKod");
            dt.Columns.Add("gidecegiIlKod");
            dt.Columns.Add("gidecegiIlceKod");

            if (Session[GorevlendirmeYerTarih] != null)
            {
                DoldurSessionGorevlendirmeYerTarih();
            }
            else
            {
                DoldurGorevlendirmeYerTarih(dt, gorevYerleri);
            }
        }
        private void ListeleGorevlendirmePersonel(ObjectArray gorevliPersoneller)
        {
            dgPersonel.Visible = true;
            lblPersonelUyari.Visible = false;

            DataTable dt = new DataTable();
            dt.Columns.Add("tckimlikno");
            dt.Columns.Add("adsoyad");
            dt.Columns.Add("unvan");
            dt.Columns.Add("kadroDerece");
            dt.Columns.Add("ekGosterge");

            GorevPersonelPersonelDonustur(gorevliPersoneller);

            if (Session[GorevlendirmePersonel] != null)
            {
                DoldurSessionGorevlendirmePersonel();
            }
            else
            {
                DoldurGorevlendirmePersonel(dt, gorevliPersoneller);
            }
        }

        private void DoldurSessionGorevlendirmeYerTarih()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("bulunduguYer");
            dt.Columns.Add("gidecegiYer");
            dt.Columns.Add("tarihBaslangic");
            dt.Columns.Add("tarihBitis");
            dt.Columns.Add("bulunduguIlKod");
            dt.Columns.Add("bulunduguIlceKod");
            dt.Columns.Add("gidecegiIlKod");
            dt.Columns.Add("gidecegiIlceKod");

            ObjectArray liste = (ObjectArray)Session[GorevlendirmeYerTarih];
            if (liste.ObjeSayisi > 0)
            {
                dgGorevYerTarih.Visible = true;
                lblGorevYerTarihUyari.Visible = false;
                DoldurGorevlendirmeYerTarih(dt, liste);
            }
            else
            {
                dgGorevYerTarih.Visible = false;
                lblGorevYerTarihUyari.Visible = true;
            }
        }
        private void DoldurSessionGorevlendirmePersonel()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("tckimlikno");
            dt.Columns.Add("adsoyad");
            dt.Columns.Add("unvan");
            dt.Columns.Add("kadroDerece");
            dt.Columns.Add("ekGosterge");

            ObjectArray liste = (ObjectArray)Session[GorevlendirmePersonel];
            if (liste.ObjeSayisi > 0)
            {
                dgPersonel.Visible = true;
                lblPersonelUyari.Visible = false;
                DoldurGorevlendirmePersonel(dt, liste);
            }
            else
            {
                dgPersonel.Visible = false;
                lblPersonelUyari.Visible = true;
            }
        }

        private void DoldurGorevlendirmeYerTarih(DataTable dt, ObjectArray liste)
        {
            foreach (TNS.PER.GorevYerTarih yerTarih in liste.objeler)
            {
                dt.Rows.Add(yerTarih.bulunduguYer, yerTarih.gidecegiYer, yerTarih.baslangicTarihi.ToString(), yerTarih.bitisTarihi.ToString(), yerTarih.bulunduguIlKod, yerTarih.bulunduguIlceKod, yerTarih.gidecegiIlKod, yerTarih.gidecegiIlceKod);
            }

            dgGorevYerTarih.DataSource = dt;
            dgGorevYerTarih.DataBind();

            if (Session[GorevlendirmeYerTarih] == null)
                Session[GorevlendirmeYerTarih] = liste;
        }
        private void DoldurGorevlendirmePersonel(DataTable dt, ObjectArray liste)
        {
            foreach (TNS.PER.Personel p in liste.objeler)
            {
                dt.Rows.Add(p.tcKimlikNo, p.ad + " " + p.soyad, p.unvanAd, p.kadroDerece, p.emekliEsasGosterge);
            }

            dgPersonel.DataSource = dt;
            dgPersonel.DataBind();

            //GorevPersonelPersonelDonustur(liste);
        }

        private void GorevPersonelPersonelDonustur(ObjectArray liste)
        {
            if (Session[GorevlendirmePersonel] == null)
            {
                ObjectArray pListe = new ObjectArray();
                foreach (GorevPersonel gp in liste.objeler)
                {
                    TNS.PER.Personel p = new TNS.PER.Personel();
                    p.tcKimlikNo = gp.tckimlikno;
                    p.ad = gp.ad;
                    p.soyad = gp.soyad;
                    p.unvanAd = gp.unvan;
                    p.unvanKodu = gp.unvanKod;
                    p.kadroDerece = OrtakFonksiyonlar.ConvertToInt(gp.kadroDerece, 0);
                    p.emekliEsasGosterge = OrtakFonksiyonlar.ConvertToInt(gp.ekGosterge, 0);

                    pListe.objeler.Add(p);
                }

                Session[GorevlendirmePersonel] = pListe;
            }
        }

        protected void lbtGorevYerTarihSil_Click(object sender, EventArgs e)
        {
            string bulunduguYer = ((sender as LinkButton).FindControl("lblBulunduguYer") as Label).Text;
            string gidecegiYer = ((sender as LinkButton).FindControl("lblGidecegiYer") as Label).Text;

            if (Session[GorevlendirmeYerTarih] != null)
            {
                ObjectArray liste = (ObjectArray)Session[GorevlendirmeYerTarih];
                if (liste.ObjeSayisi > 0)
                {
                    TNS.PER.GorevYerTarih yerTarih = new TNS.PER.GorevYerTarih();
                    for (int i = 0; i < liste.ObjeSayisi; i++)
                    {
                        yerTarih = (TNS.PER.GorevYerTarih)liste.objeler[i];
                        if (yerTarih.bulunduguYer == bulunduguYer && yerTarih.gidecegiYer == gidecegiYer)
                        {
                            liste.objeler.RemoveAt(i);
                            break;
                        }
                    }
                    Session[GorevlendirmeYerTarih] = liste;
                    ListeleGorevlendirmeYerTarih(liste);
                }
                else
                {
                    lblGorevYerTarihUyari.Visible = true;
                    dgGorevYerTarih.Visible = false;
                    GenelIslemler.MesajKutusu(this, "Silinecek bilgi bulunmamaktadır.");
                }
            }
            else
            {
                GenelIslemler.MesajKutusu(this, "İşlem sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.");
            }
        }
        protected void lbtPersonelSil_Click(object sender, EventArgs e)
        {
            string tckimlikno = ((sender as LinkButton).FindControl("lblTCKimlikNo") as Label).Text;
            if (Session[GorevlendirmePersonel] != null)
            {
                ObjectArray liste = (ObjectArray)Session[GorevlendirmePersonel];
                if (liste.ObjeSayisi > 0)
                {
                    TNS.PER.Personel p = new TNS.PER.Personel();
                    for (int i = 0; i < liste.ObjeSayisi; i++)
                    {
                        p = (TNS.PER.Personel)liste.objeler[i];
                        if (p.tcKimlikNo == tckimlikno)
                        {
                            liste.objeler.RemoveAt(i);
                            break;
                        }
                    }
                    Session[GorevlendirmePersonel] = liste;
                    ListeleGorevlendirmePersonel(liste);
                }
                else
                {
                    dgPersonel.Visible = false;
                    lblPersonelUyari.Visible = true;
                    GenelIslemler.MesajKutusu(this, "Silinecek bilgi bulunmamaktadır.");
                }
            }
            else
            {
                GenelIslemler.MesajKutusu(this, "İşlem sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.");
            }
        }

        protected void btnBelgeListele_Click(object sender, EventArgs e)
        {
            int gorevKod = OrtakFonksiyonlar.ConvertToInt(txtBelgeNo.Text, 0);
            if (gorevKod > 0)
            {
                Gorev gorev = new Gorev();
                gorev.kod = gorevKod;
                Listele(gorev);
            }
        }
        protected void btnYeniKayit_Click(object sender, EventArgs e)
        {
            Temizle();
        }
        protected void btnKaydet_Click(object sender, EventArgs e)
        {
            //KmL
            //TODO: Görevin state bilgisine göre kaydetme veya kaydetmeme durumu belirlenecek.

            Gorev gorev = new Gorev();
            gorev.kod = OrtakFonksiyonlar.ConvertToInt(txtBelgeNo.Text, 0);
            gorev.muhasebeKod = OrtakFonksiyonlar.ConvertToInt(txtMuhasebe.Text, 0);
            gorev.birimKod = txtBirim.Text;
            gorev.amac = txtAmaci.Text;
            gorev.tur = OrtakFonksiyonlar.ConvertToInt(ddlTur.SelectedValue, 0);
            gorev.islemKod = OrtakFonksiyonlar.ConvertToInt(ddlIslemTur.SelectedValue, 0);
            gorev.evrEvrakNo = lblEvrEvrakNo.Text;
            gorev.prEvrakNo = lblPrEvrakNo.Text;
            gorev.gorevYerleri = GorevYerTarihBilgisiAl();
            gorev.gorevliPersoneller = GorevliPersonelBilgisiAl();

            TNS.Sonuc sonuc = servisPER.GorevKaydet(kullanan, gorev);

            if (sonuc.islemSonuc)
            {
                Temizle();
                gorev.kod = OrtakFonksiyonlar.ConvertToInt(sonuc.anahtar, 0);
                Listele(gorev);
                GenelIslemler.MesajKutusu(this, sonuc.bilgiStr);
            }
            else
            {
                GenelIslemler.MesajKutusu(this, sonuc.hataStr);
            }
        }

        protected void btnYazdir_Click(object sender, EventArgs e)
        {
            Session[GorevlendirmeYerTarih] = null;
            Session[GorevlendirmePersonel] = null;
        }

        private void Temizle()
        {
            Session[GorevlendirmeYerTarih] = null;
            Session[GorevlendirmePersonel] = null;

            dgGorevYerTarih.DataSource = null;
            dgGorevYerTarih.DataBind();

            dgPersonel.DataSource = null;
            dgPersonel.DataBind();

            txtBelgeNo.Text = string.Empty;
            txtAmaci.Text = string.Empty;
        }

        private ObjectArray GorevliPersonelBilgisiAl()
        {
            if (Session[GorevlendirmePersonel] != null)
            {
                ObjectArray liste = new ObjectArray();
                foreach (TNS.PER.Personel p in ((ObjectArray)Session[GorevlendirmePersonel]).objeler)
                {
                    GorevPersonel gp = new GorevPersonel();
                    gp.tckimlikno = p.tcKimlikNo;
                    gp.ad = p.ad;
                    gp.soyad = p.soyad;
                    gp.ekGosterge = p.emekliEsasGosterge;
                    gp.kadroDerece = p.kadroDerece;
                    gp.unvan = p.unvanAd;
                    gp.unvanKod = p.unvanKodu;
                    liste.objeler.Add(gp);
                }
                return liste;
            }
            return null;
        }
        private ObjectArray GorevYerTarihBilgisiAl()
        {
            if (Session[GorevlendirmeYerTarih] != null)
            {
                return (ObjectArray)Session[GorevlendirmeYerTarih];
            }
            return null;
        }
    }
}
