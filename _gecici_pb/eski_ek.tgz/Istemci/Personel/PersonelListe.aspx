﻿<%@ Page Language="C#" CodeBehind="PersonelListe.aspx.cs" Inherits="Personel.PersonelListe"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
	<title></title>
    <meta http-equiv="Pragma" content="no-cache" />
	<link href="../App_themes/Form.css" type="text/css" rel="stylesheet"/>
	<script language="Javascript" type="text/javascript">
	    function VeriGoster(kod)
	    {
	        parent.document.all.hdnTCKimlikNo.value=kod;
	        parent.document.forms[0].submit();
            parent.hidePopWin();
        }
	</script>
</head>
<body style="margin:10px;text-align:left;">
    <form id="aspnetForm" runat="server">
        <div class="form" style="width:99%;" align="center">
            <div class="row">
            <table width="98%"><tr><td width="98%" align="right">
            <asp:LinkButton ID="lnkYazdir" runat="server" Text="Yazdir" OnClick="lnkYazdir_Click"></asp:LinkButton>
            </td></tr></table>
            </div>
            <div class="kolonArasi">
                <div style="overflow: auto; height: 180px; width: 540px;" align="left">
                    <asp:DataGrid ID="dgListe" runat="server" Width="96%"
                        AutoGenerateColumns="False" BorderWidth="1px" BorderColor="Gray" CellPadding="3"
                        Font-Bold="False" Font-Italic="False" Font-Names="Tahoma" Font-Overline="False"
                        Font-Size="8pt" Font-Strikeout="False" Font-Underline="False" ForeColor="#333333"
                        PageSize="1">
                        <AlternatingItemStyle BackColor="White" ForeColor="#284775" />
                        <ItemStyle BackColor="#F7F6F3" ForeColor="#333333" />
                        <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" Font-Italic="False" Font-Names="Tahoma"
                            Font-Overline="False" Font-Size="8pt" Font-Strikeout="False" Font-Underline="False"
                            ForeColor="White" HorizontalAlign="Center" VerticalAlign="Middle" />
                        <Columns>
                            <asp:BoundColumn DataField="tckimlik" HeaderText="TC Kimlik No" ItemStyle-Width="100"></asp:BoundColumn>
                            <asp:BoundColumn DataField="sicilNo" HeaderText="Sicil No" ItemStyle-Width="60"></asp:BoundColumn>
                            <asp:BoundColumn DataField="ad" HeaderText="Adı" ItemStyle-Width="120"></asp:BoundColumn>
                            <asp:BoundColumn DataField="soyad" HeaderText="Soyadı" ItemStyle-Width="130"></asp:BoundColumn>
                            <asp:BoundColumn DataField="muhasebe" Visible="false"></asp:BoundColumn>
                            <asp:BoundColumn DataField="birim" Visible="false"></asp:BoundColumn>
                        </Columns>
                    </asp:DataGrid>
                </div>
                <br />
            </div>
        </div>
    </form>
</body>
</html>
