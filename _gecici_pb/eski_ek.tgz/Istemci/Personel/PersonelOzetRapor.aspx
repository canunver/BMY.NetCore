﻿<%@ Page Language="C#" CodeBehind="PersonelOzetRapor.aspx.cs" Inherits="Personel.PersonelOzetRapor" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <script type="text/javascript" language="javascript">
        var personelPenceresi = null;

        function PersonelAc(muhasebe, birim, unvan, sinif, ogrenim) {
            if (personelPenceresi == null || personelPenceresi.closed)
                personelPenceresi = window.open("../Personelv2/PersonelBilgi.aspx?menuYok=1" + "&muhasebe=" + muhasebe +
                            "&birim=" + birim + "&unvan=" + unvan + "&sinif=" + sinif + "&ogrenim=" + ogrenim, "", "", false);
            personelPenceresi.focus();
            personelPenceresi.moveTo(100, 30);
        }

        function PersonelKapat() {
            if (personelPenceresi != null)
                personelPenceresi.close();
        }
    </script>
</head>
<body onunload="PersonelKapat();">
    <form id="form1" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <ext:Store runat="server" ID="storeUnvanKadro">
        <Reader>
            <ext:JsonReader IDProperty="ID">
                <Fields>
                    <ext:RecordField Name="ID" />
                    <ext:RecordField Name="Unvan" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeUnvan">
        <Reader>
            <ext:JsonReader IDProperty="ID">
                <Fields>
                    <ext:RecordField Name="ID" />
                    <ext:RecordField Name="Unvan" />
                    <ext:RecordField Name="Sayi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeSinif">
        <Reader>
            <ext:JsonReader IDProperty="ID">
                <Fields>
                    <ext:RecordField Name="ID" />
                    <ext:RecordField Name="Sinif" />
                    <ext:RecordField Name="Sayi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Store runat="server" ID="storeOgrenim">
        <Reader>
            <ext:JsonReader IDProperty="ID">
                <Fields>
                    <ext:RecordField Name="ID" />
                    <ext:RecordField Name="Ogrenim" />
                    <ext:RecordField Name="Sayi" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center>
                    <ext:Panel runat="server" Border="false" StyleSpec="padding:5px 5px 5px 5px;">
                        <Items>
                            <ext:ColumnLayout runat="server">
                                <Columns>
                                    <ext:LayoutColumn ColumnWidth="0.7">
                                        <ext:Panel runat="server" StyleSpec="padding:0px 2px 0px 0px;" Title="Unvan ve Kadro Derece Bazında Personel Sayıları"
                                            Layout="FitLayout">
                                            <Items>
                                                <ext:GridPanel ID="grdUnvanKadro" runat="server" StoreID="storeUnvanKadro" StripeRows="true"
                                                    AutoExpandColumn="Unvan">
                                                    <ColumnModel>
                                                        <Columns>
                                                            <ext:Column DataIndex="ID" Hidden="true" ColumnID="ID">
                                                            </ext:Column>
                                                            <ext:Column Header="Unvan" DataIndex="Unvan" MenuDisabled="true" Align="Left" ColumnID="Unvan">
                                                            </ext:Column>
                                                        </Columns>
                                                    </ColumnModel>
                                                    <View>
                                                        <ext:GridView ForceFit="false" runat="server">
                                                        </ext:GridView>
                                                    </View>
                                                    <SelectionModel>
                                                        <ext:RowSelectionModel runat="server" SingleSelect="true">
                                                        </ext:RowSelectionModel>
                                                    </SelectionModel>
                                                </ext:GridPanel>
                                            </Items>
                                        </ext:Panel>
                                    </ext:LayoutColumn>
                                    <ext:LayoutColumn ColumnWidth="0.3">
                                        <ext:Panel runat="server" Border="false">
                                            <Items>
                                                <ext:RowLayout runat="server">
                                                    <Rows>
                                                        <ext:LayoutRow RowHeight="0.34">
                                                            <ext:Panel runat="server" StyleSpec="padding:0px 0px 2px 0px;" Title="Unvan Bazında Personel Sayıları"
                                                                Layout="FitLayout">
                                                                <Items>
                                                                    <ext:GridPanel ID="grdUnvan" runat="server" StoreID="storeUnvan" StripeRows="true"
                                                                        AutoExpandColumn="Unvan">
                                                                        <ColumnModel>
                                                                            <Columns>
                                                                                <ext:Column DataIndex="ID" Hidden="true" ColumnID="ID">
                                                                                </ext:Column>
                                                                                <ext:Column Header="Unvan" DataIndex="Unvan" MenuDisabled="true" Align="Left" ColumnID="Unvan">
                                                                                </ext:Column>
                                                                                <ext:Column Header="Sayı" Width="35" DataIndex="Sayi" MenuDisabled="true" Align="Right">
                                                                                </ext:Column>
                                                                            </Columns>
                                                                        </ColumnModel>
                                                                        <View>
                                                                            <ext:GridView ID="GridView1" ForceFit="false" runat="server">
                                                                            </ext:GridView>
                                                                        </View>
                                                                        <SelectionModel>
                                                                            <ext:RowSelectionModel runat="server" SingleSelect="true">
                                                                            </ext:RowSelectionModel>
                                                                        </SelectionModel>
                                                                    </ext:GridPanel>
                                                                </Items>
                                                            </ext:Panel>
                                                        </ext:LayoutRow>
                                                        <ext:LayoutRow RowHeight="0.33">
                                                            <ext:Panel runat="server" StyleSpec="padding:0px 0px 2px 0px;" Title="Sınıf Bazında Personel Sayıları"
                                                                Layout="FitLayout">
                                                                <Items>
                                                                    <ext:GridPanel ID="grdSinif" runat="server" StoreID="storeSinif" StripeRows="true"
                                                                        AutoExpandColumn="Sinif">
                                                                        <ColumnModel>
                                                                            <Columns>
                                                                                <ext:Column DataIndex="ID" Hidden="true" ColumnID="ID">
                                                                                </ext:Column>
                                                                                <ext:Column Header="Sınıf" DataIndex="Sinif" MenuDisabled="true" Align="Left" ColumnID="Sinif">
                                                                                </ext:Column>
                                                                                <ext:Column Header="Sayı" Width="35" DataIndex="Sayi" MenuDisabled="true" Align="Right">
                                                                                </ext:Column>
                                                                            </Columns>
                                                                        </ColumnModel>
                                                                        <View>
                                                                            <ext:GridView ID="GridView2" ForceFit="false" runat="server">
                                                                            </ext:GridView>
                                                                        </View>
                                                                        <SelectionModel>
                                                                            <ext:RowSelectionModel runat="server" SingleSelect="true">
                                                                            </ext:RowSelectionModel>
                                                                        </SelectionModel>
                                                                    </ext:GridPanel>
                                                                </Items>
                                                            </ext:Panel>
                                                        </ext:LayoutRow>
                                                        <ext:LayoutRow RowHeight="0.33">
                                                            <ext:Panel runat="server" StyleSpec="padding:0px 0px 0px 0px;" Title="Öğrenim Durumu Bazında Personel Sayıları"
                                                                Layout="FitLayout">
                                                                <Items>
                                                                    <ext:GridPanel ID="grdOgrenim" runat="server" StoreID="storeOgrenim" StripeRows="true"
                                                                        AutoExpandColumn="Ogrenim">
                                                                        <ColumnModel>
                                                                            <Columns>
                                                                                <ext:Column DataIndex="ID" Hidden="true" ColumnID="ID">
                                                                                </ext:Column>
                                                                                <ext:Column Header="Öğrenim Durumu" DataIndex="Ogrenim" MenuDisabled="true" Align="Left"
                                                                                    ColumnID="Ogrenim">
                                                                                </ext:Column>
                                                                                <ext:Column Header="Sayı" Width="35" DataIndex="Sayi" MenuDisabled="true" Align="Right">
                                                                                </ext:Column>
                                                                            </Columns>
                                                                        </ColumnModel>
                                                                        <View>
                                                                            <ext:GridView ID="GridView3" ForceFit="false" runat="server">
                                                                            </ext:GridView>
                                                                        </View>
                                                                        <SelectionModel>
                                                                            <ext:RowSelectionModel runat="server" SingleSelect="true">
                                                                            </ext:RowSelectionModel>
                                                                        </SelectionModel>
                                                                    </ext:GridPanel>
                                                                </Items>
                                                            </ext:Panel>
                                                        </ext:LayoutRow>
                                                    </Rows>
                                                </ext:RowLayout>
                                            </Items>
                                        </ext:Panel>
                                    </ext:LayoutColumn>
                                </Columns>
                            </ext:ColumnLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    </form>
</body>
</html>
