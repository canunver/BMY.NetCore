﻿<%@ Page Language="C#" CodeBehind="GorevlendirmeAna.aspx.cs" Inherits="Personel.GorevlendirmeAna" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<frameset id="frameIslem" cols="100%,0%" frameborder="no" framespacing="0">
      <frame name="belge" src="Gorevlendirme.aspx" frameborder="no" marginheight="0" marginwidth="0">
      <frame name="sorgu" src="GorevlendirmeSorgu.aspx" frameborder="no" marginheight="0" marginwidth="0">
      <noframes>
         <pre id="p2"></pre>
         <p id="p1">
            Bu uygulama frame içermektedir. Bu yüzden kullandığınız tarayıcının, en son 
            sürümünü bilgisayarınıza kurunuz.
         </p>
      </noframes>
   </frameset>
</html>
