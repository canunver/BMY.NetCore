﻿<%@ Page Language="C#" CodeBehind="GorevlendirmeYerTarih.aspx.cs" Inherits="Personel.GorevlendirmeYerTarih" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<%@ Register TagPrefix="TNS" Namespace="TNS.WebControls" Assembly="OrtakClass" %>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Görevlendirme Yer Tarih Bilgileri</title>
    <meta http-equiv="Pragma" content="no-cache" />
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <link href="../App_themes/TakvimYeni.css" type="text/css" rel="stylesheet" />

    <script language="javascript" type="text/javascript" src="../Script/TakvimYeni.js?mc=03022015"></script>

    <script language="JavaScript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>

    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="ModulScripts/Gorevlendirme.js?mc=03022015"></script>

</head>
<body>
    <form id="form" runat="server">
    <asp:Label ID="lblHata" runat="server" Visible="false"></asp:Label>
    <div class="form" style="height: 245px;">
        <div class="row">
            <div class="yaziAlanK">
                Görev Başlangıç Tarihi</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtGorevBaslangicTarihi" runat="server" CssClass="veriAlan" Columns="10"
                    MaxLength="10"></asp:TextBox>
                <img src="../App_themes/Images/takvim.gif" id="imgGorevBaslangicTarihi" alt="" style="cursor: pointer;"
                    onclick="JavaScript:displayDatePicker('txtGorevBaslangicTarihi', false, 'dmy', '.');" />
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Görev Bitiş Tarihi</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtGorevBitisTarihi" runat="server" CssClass="veriAlan" Columns="10"
                    MaxLength="10"></asp:TextBox>
                <img src="../App_themes/Images/takvim.gif" id="imgGorevBitisTarihi" alt="" style="cursor: pointer;"
                    onclick="JavaScript:displayDatePicker('txtGorevBitisTarihi', false, 'dmy', '.');" />
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Bulunduğu Yer</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <TNS:TNSOneri ID="txtBulunduguYer" runat="server" SonucGetirAdres="../Personel/ListeIlIlceOneriGetir.aspx"
                    SonucGetirAdresParametreler="paramFonksiyonIlIlce" Width="140" >
                </TNS:TNSOneri>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Gideceği Yer</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <TNS:TNSOneri ID="txtGidecegiYer" runat="server" SonucGetirAdres="../Personel/ListeIlIlceOneriGetir.aspx"
                    SonucGetirAdresParametreler="paramFonksiyonIlIlce" Width="140">
                </TNS:TNSOneri>
            </div>
        </div>
        <div class="footer">
            &nbsp;</div>
        <div class="row">
            <center>
                <asp:Button ID="btnKaydet" runat="server" Text="Kaydet" CssClass="dugme" OnClick="btnKaydet_Click" />
            </center>
        </div>
    </form>
</body>
</html>
