﻿<%@ Page Language="C#" CodeBehind="KadroRapor.aspx.cs" Inherits="Personel.KadroRapor"  %>
<%@ Register TagPrefix="Farpoint" Namespace="FarPoint.Web.Spread" Assembly="FarPoint.Web.Spread" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
	<title></title>
	<link href="../App_themes/Form.css" type="text/css" rel="stylesheet"/>
	<link href="../App_themes/popupDialog.css" type="text/css" rel="stylesheet" />
	<script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
	<script language="Javascript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>
	<script language="JavaScript" type="text/javascript" src="../script/popupDialog.js?mc=03022015"></script>
    <script language="JavaScript" type="text/javascript" src="../script/popupDialog2.js?mc=03022015"></script>
	<script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>
</head>
<body>
    <form id="form" runat="server">
    <asp:Literal id="ltlUstBolum" runat="server"></asp:Literal>
	<asp:label id="lblHata" Visible="false" Runat="server"></asp:label>
    <div class="form">
        <div class="row">
            <div class="yaziAlanK">Teşkilat Kodu</div>
            <div class="ikiNokta">:</div>
            <div class="veriAlan" style="width:140px;">
                <asp:DropDownList ID="ddlTeskilat" runat="server" CssClass="veriAlanDDL">
                    <asp:ListItem Text="" Value=""></asp:ListItem>
                    <asp:ListItem Text="1-Merkez" Value="1"></asp:ListItem>
                    <asp:ListItem Text="2-Taşra" Value="2"></asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">Üst Birim Kodu</div>
            <div class="ikiNokta">:</div>
            <div class="veriAlan"><asp:DropDownList ID="ddlUstBirim" runat="server" CssClass="veriAlanDDL"></asp:DropDownList></div>
        </div>
        <div class="row">
            <div class="yaziAlanK">Sınıf Kodu</div>
            <div class="ikiNokta">:</div>
            <div class="veriAlan"><asp:DropDownList ID="ddlSinif" runat="server" CssClass="veriAlanDDL"></asp:DropDownList></div>
        </div>
        <div class="row">
            <div class="yaziAlanK">Ünvan Kodu</div>
            <div class="ikiNokta">:</div>
            <div class="veriAlan"><asp:TextBox id="txtUnvan" runat="server" CssClass="veriAlan" MaxLength="5" Columns="7"></asp:TextBox></div>
            <div class="veriAlan"><input type="image" alt="Ünvan Listesi" class="veriAlan" onclick="javascript:UnvanEkle();return false;" tabindex="100" src="../App_themes/images/bul1.gif" /></div>
	        <div class="kolonArasi"></div>
            <div class="veriAlan"><asp:label id="lblUnvan" Width="100%" runat="server" CssClass="veriAlan"></asp:label></div>
        </div>
        <div class="row">
            <div class="yaziAlanK">Saymanlık İl/Tip/İlçe</div>
            <div class="ikiNokta">:</div>
            <div class="veriAlan"><asp:TextBox id="txtSayIl" runat="server" CssClass="veriAlan" MaxLength="5" Columns="5"></asp:TextBox></div>
            <div class="ikiNokta"></div>
            <div class="veriAlan"><asp:TextBox id="txtSayTip" runat="server" CssClass="veriAlan" MaxLength="5" Columns="5"></asp:TextBox></div>
            <div class="ikiNokta"></div>
            <div class="veriAlan"><asp:TextBox id="txtSayIlce" runat="server" CssClass="veriAlan" MaxLength="5" Columns="5"></asp:TextBox></div>
        </div>
        <div class="row">
            <div class="yaziAlanK">Kadro Derece</div>
            <div class="ikiNokta">:</div>
            <div class="veriAlan"><asp:TextBox id="txtKadro" runat="server" CssClass="veriAlan" MaxLength="5" Columns="7"></asp:TextBox></div>
        </div>
        <div class="row">
            <div class="yaziAlanK">Vize Tarihi</div>
            <div class="ikiNokta">:</div>
            <div class="veriAlan"><asp:DropDownList ID="ddlVizeTarihi" runat="server" CssClass="veriAlanDDL"></asp:DropDownList></div>
        </div>
        <div class="footer">&nbsp;</div>
    </div>
	<table cellspacing="2" cellpadding="2">
        <tr>
            <td>
                <asp:button id="btnListele" runat="server" Width="100" CssClass="dugme" Text="Listele" OnClick="btnListele_Click"></asp:button>&nbsp;
            </td>
        </tr>
    </table>
    <asp:Literal id="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
