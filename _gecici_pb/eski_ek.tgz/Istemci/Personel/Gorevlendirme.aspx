﻿<%@ Page Language="C#" CodeBehind="Gorevlendirme.aspx.cs" Inherits="Personel.Gorevlendirme" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<%@ Register TagPrefix="TNS" Namespace="TNS.WebControls" Assembly="OrtakClass" %>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <link href="../App_themes/popupDialog.css" type="text/css" rel="stylesheet" />

    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>

    <script language="JavaScript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="../script/popupDialog.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="../script/popupDialog2.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="ModulScripts/Ortak.js?mc=03022015"></script>

    <script language="Javascript" type="text/javascript" src="ModulScripts/Gorevlendirme.js?mc=03022015"></script>

</head>
<body>
    <form id="form" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <asp:Label ID="lblHata" Visible="false" runat="server"></asp:Label>
    <img src="../App_themes/images/belgeduzenleaktif.gif" alt="Belge Düzenleme" />
    <img src="../App_themes/images/belgearamapasif.gif" alt="Belge Arama" style="cursor: hand"
        onclick="parent.document.getElementById('frameIslem').cols='0,100%';document.scrolling=false;" />
    <div class="form" style="width: 100%; margin-top: -2px;">
        <input type="hidden" id="hdnTCKimlikNo" runat="server" />
        <div class="row">
            <div class="yaziAlan">
                Belge No
            </div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtBelgeNo" runat="server" CssClass="veriAlan" Width="50px"></asp:TextBox>
                <input type="hidden" id="hdnBelgeNo" runat="server" />
                <asp:ImageButton ID="btnBelgeListele" TabIndex="99" runat="server" Width="16" ImageUrl="../App_themes/images/bul.gif"
                    Height="16" AlternateText="Belgeyi Bul" OnClick="btnBelgeListele_Click"></asp:ImageButton>      
                &nbsp;
                <a id="lbtEvrakIslemleri" runat="server" style="cursor:hand;" visible="false" onclick="EvrakIslemGoster();">Evrak İşlemleri için tıklayınız.</a> 
            </div>
            
        </div>
        <div class="row" id="pnlEvrakNo" runat="server" visible="false">
            <div class="yaziAlan">
                Evrak No
            </div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:Label ID="lblPrEvrakNo" runat="server"></asp:Label>
                <asp:Label ID="lblEvrEvrakNo" runat="server"></asp:Label>
                <asp:LinkButton ID="lbtPrEvrakNo" runat="server" Text="-" ></asp:LinkButton>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Muhasebe Birimi Kodu</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtMuhasebe" runat="server" CssClass="veriAlan" MaxLength="5" Width="50px"></asp:TextBox>
            </div>
            <div class="veriAlan">
                <input type="image" id="imgMuhasebe" runat="server" alt="Muhasebe Listesi" style="height: 14px;
                    width: 16px;" class="veriAlan" onclick="javascript:MuhasebeGoster();return false;"
                    tabindex="100" src="../App_themes/images/bul1.gif" />
            </div>
            <div class="kolonArasi">
            </div>
            <div class="veriAlan" style="width: 575px">
                <asp:Label ID="lblMuhasebeAd" Width="100%" runat="server" CssClass="veriAlan"></asp:Label>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Harcama Birimi Kodu</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtBirim" runat="server" CssClass="veriAlan" MaxLength="15" Width="50px"></asp:TextBox>
            </div>
            <div class="veriAlan">
                <input type="image" id="imgBirim" runat="server" alt="Harcama Birim Listesi" style="height: 14px;
                    width: 16px;" class="veriAlan" onclick="javascript:MuhasebeBirimGoster();return false;"
                    tabindex="100" src="../App_themes/images/bul1.gif" />
            </div>
            <div class="kolonArasi">
            </div>
            <div class="veriAlan">
                <asp:Label ID="lblBirimAd" Width="100%" runat="server" CssClass="veriAlan"></asp:Label>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Amacı</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan" style="height: 55px;">
                <asp:TextBox ID="txtAmaci" runat="server" CssClass="veriAlan" 
                    TextMode="MultiLine" Rows="3" Width="300" Height="50" ></asp:TextBox>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                İşlem Türü</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:DropDownList ID="ddlIslemTur" runat="server" CssClass="veriAlanDDL">
                    <asp:ListItem Text="Yurtiçi Görev" Value="24"></asp:ListItem>
                    <asp:ListItem Text="Yurtdışı Görev" Value="25"></asp:ListItem>
                    <asp:ListItem Text="Denetim Görev" Value="26"></asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                Türü</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:DropDownList ID="ddlTur" runat="server" CssClass="veriAlanDDL">
                    <asp:ListItem Text="Eğitim" Value="1"></asp:ListItem>
                    <asp:ListItem Text="Sınav" Value="2"></asp:ListItem>
                    <asp:ListItem Text="Vekalet" Value="3"></asp:ListItem>
                    <asp:ListItem Text="Görev" Value="4"></asp:ListItem>
                    <asp:ListItem Text="Keşif" Value="5"></asp:ListItem>
                    <asp:ListItem Text="Denetim" Value="6"></asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                Görev Yeri</div>
            <div class="ikiNokta">
                :</div>
            <div class="yaziAlan">
                <asp:LinkButton ID="lbtGorevYerTarihEkle" runat="server" Text="Yeni Ekle" OnClientClick="javascript:GorevYerTarihEkle();return false;"></asp:LinkButton>
            </div>
        </div>
        <div class="footer">
            &nbsp;</div>
        <div class="row" style="margin-left: 158px;">
            <asp:Label ID="lblGorevYerTarihUyari" runat="server" Text="Kayıtlı Görev Yeri bilgisi bulunmamaktadır."
                Visible="true"></asp:Label>
            <asp:DataGrid ID="dgGorevYerTarih" runat="server" AutoGenerateColumns="False" CellPadding="2"
                Font-Bold="False" Font-Italic="False" Font-Names="Tahoma" Font-Overline="False"
                Font-Size="8pt" Font-Strikeout="False" Font-Underline="False" ForeColor="#333333"
                PageSize="1" Width="600px" BorderColor="gray" BorderStyle="solid" BorderWidth="1px">
                <ItemStyle />
                <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" HorizontalAlign="Center"
                    VerticalAlign="Middle" />
                <Columns>
                    <asp:TemplateColumn HeaderText="Bulunduğu Yer" ItemStyle-HorizontalAlign="Center">
                        <ItemTemplate>
                            <asp:Label ID="lblBulunduguYer" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "bulunduguYer")%>'></asp:Label>
                        </ItemTemplate>
                        <ItemStyle Width="25%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="Gideceği Yer" ItemStyle-HorizontalAlign="Center">
                        <ItemTemplate>
                            <asp:Label ID="lblGidecegiYer" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "gidecegiYer")%>'></asp:Label>
                        </ItemTemplate>
                        <ItemStyle Width="25%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="Tarih Başlangıç" ItemStyle-HorizontalAlign="Center">
                        <ItemTemplate>
                            <asp:Label ID="lblTarihBaslangic" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "tarihBaslangic")%>'></asp:Label>
                        </ItemTemplate>
                        <ItemStyle Width="20%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="Tarih Bitiş" ItemStyle-HorizontalAlign="Center">
                        <ItemTemplate>
                            <asp:Label ID="lblTarihBitis" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "tarihBitis")%>'></asp:Label>
                        </ItemTemplate>
                        <ItemStyle Width="20%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="">
                        <ItemStyle Width="10%" BorderColor="LightGray" HorizontalAlign="Center" />
                        <ItemTemplate>
                            <asp:LinkButton ID="lbtGorevYerTarihSil" runat="server" Text="Sil" OnClick="lbtGorevYerTarihSil_Click" />
                        </ItemTemplate>
                    </asp:TemplateColumn>
                </Columns>
            </asp:DataGrid>
        </div>
        <div class="row">
            <div class="yaziAlan">
                Görevli Personel</div>
            <div class="ikiNokta">
                :</div>
            <div class="yaziAlan">
                <asp:LinkButton ID="lbtPersonelEkle" runat="server" Text="Yeni Ekle" OnClientClick="javascript:GorevPersonelEkle();return false;"></asp:LinkButton>
            </div>
        </div>
        <div class="footer">
            &nbsp;</div>
        <div class="row" style="margin-left: 158px;">
            <asp:Label ID="lblPersonelUyari" runat="server" Text="Kayıtlı Personel bilgisi bulunmamaktadır."
                Visible="true"></asp:Label>
            <asp:DataGrid ID="dgPersonel" runat="server" AutoGenerateColumns="False" CellPadding="2"
                Font-Bold="False" Font-Italic="False" Font-Names="Tahoma" Font-Overline="False"
                Font-Size="8pt" Font-Strikeout="False" Font-Underline="False" ForeColor="#333333"
                PageSize="1" Width="600px" BorderColor="gray" BorderStyle="solid" BorderWidth="1px">
                <ItemStyle />
                <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" HorizontalAlign="Center"
                    VerticalAlign="Middle" />
                <Columns>
                    <asp:TemplateColumn HeaderText="TC Kimlik No" ItemStyle-HorizontalAlign="Center">
                        <ItemTemplate>
                            <asp:Label ID="lblTCKimlikNo" runat="server" Text='<%# DataBinder.Eval(Container.DataItem, "tckimlikno")%>'></asp:Label>
                        </ItemTemplate>
                        <ItemStyle Width="15%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:TemplateColumn>
                    <asp:BoundColumn DataField="adsoyad" HeaderText="Ad Soyad" ItemStyle-HorizontalAlign="Center">
                        <ItemStyle Width="30%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:BoundColumn>
                    <asp:BoundColumn DataField="unvan" HeaderText="Unvan" ItemStyle-HorizontalAlign="Center">
                        <ItemStyle Width="30%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:BoundColumn>
                    <asp:BoundColumn DataField="kadroDerece" HeaderText="Kadro Derece" ItemStyle-HorizontalAlign="Center">
                        <ItemStyle Width="10%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:BoundColumn>
                    <asp:BoundColumn DataField="ekGosterge" HeaderText="Ek Gösterge" ItemStyle-HorizontalAlign="Center">
                        <ItemStyle Width="10%" BorderColor="LightGray" HorizontalAlign="Center" />
                    </asp:BoundColumn>
                    <asp:TemplateColumn HeaderText="">
                        <ItemStyle Width="5%" BorderColor="LightGray" HorizontalAlign="Center" />
                        <ItemTemplate>
                            <asp:LinkButton ID="lbtPersonelSil" runat="server" Text="Sil" OnClick="lbtPersonelSil_Click"
                                CommandArgument='<%# DataBinder.Eval(Container.DataItem, "tckimlikno")%>' />
                        </ItemTemplate>
                    </asp:TemplateColumn>
                </Columns>
            </asp:DataGrid>
        </div>
        <div class="footer">
            &nbsp;</div>
        <div class="row">
            <center>
                <asp:Button ID="btnYeniKayit" runat="server" Text="Yeni Kayıt" CssClass="dugme" OnClick="btnYeniKayit_Click" />
                <asp:Button ID="btnKaydet" runat="server" Text="Kaydet" CssClass="dugme" OnClick="btnKaydet_Click" />
                <asp:Button ID="btnYazdir" runat="server" Text="Yazdır" CssClass="dugme" OnClick="btnYazdir_Click" />
            </center>
        </div>
        <div class="footer">
            &nbsp;</div>
    </div>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
