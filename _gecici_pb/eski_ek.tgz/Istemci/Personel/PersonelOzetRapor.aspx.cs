﻿using System;
using OrtakClass;
using TNS;
using TNS.PER;
using System.Collections.Generic;
using Ext1.Net;
using System.Data;

namespace Personel
{
    public partial class PersonelOzetRapor : istemciUzayi.GenelSayfa
    {
        IPERServis servisPER = TNS.PER.Arac.Tanimla();
        static int kadroDereceSayi = 15;
        DataTable dtUnvanKadro;

        protected void Page_Init(object sender, EventArgs e)
        {
            UnvanKadroKolonEkle();
        }

        private void UnvanKadroKolonEkle()
        {
            dtUnvanKadro = new DataTable();
            dtUnvanKadro.Columns.Add("ID");
            dtUnvanKadro.Columns.Add("Unvan");

            for (int i = 1; i <= kadroDereceSayi; i++)
            {
                storeUnvanKadro.Reader[0].Fields.Add(i.ToString());

                Column col = new Column();
                col.Header = i.ToString();
                col.DataIndex = i.ToString();
                col.MenuDisabled = true;
                col.Align = Alignment.Right;
                col.Width = new System.Web.UI.WebControls.Unit(35);

                grdUnvanKadro.ColumnModel.Columns.Add(col);

                dtUnvanKadro.Columns.Add(i.ToString());
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);

            //Sayfaya giriş izni varmı?
            if (!TNS.PER.Yetki.YetkiVarMiOkumaya(kullanan))
                GenelIslemler.SayfayaGirmesin(true);

            if (!IsPostBack)
            {
                PersonelOzetRaporu();
            }
        }

        private void PersonelOzetRaporu()
        {
            int muhasebe = OrtakFonksiyonlar.ConvertToInt(Request.QueryString["muhasebe"], 0);
            string birim = Request.QueryString["birim"] + string.Empty;
            string kurKod = Request.QueryString["kurKod"] + string.Empty;
            int orgBirimKod = OrtakFonksiyonlar.ConvertToInt(Request.QueryString["orgBirimKod"], 0);

            if (OgrenimBazliPersonelSayilariGoster(muhasebe, birim) == null)
                return;
            if (UnvanBazliPersonelSayilariGoster(muhasebe, birim) == null)
                return;
            if (SinifBazliPersonelSayilariGoster(muhasebe, birim) == null)
                return;
            if (UnvanVeKadroDereceBazliPersonelSayilariGoster(kurKod, muhasebe, birim, orgBirimKod) == null)
                return;
        }

        private string OgrenimBazliPersonelSayilariGoster(int muhasebe, string birim)
        {
            ObjectArray bilgi = servisPER.OgrenimBazliPersonelSayilariListele(muhasebe, birim);
            if (!bilgi.sonuc.islemSonuc)
            {
                GenelIslemler.HataYaz(this, bilgi.sonuc.hataStr);
                return null;
            }
            if (bilgi.objeler.Count <= 0)
                return string.Empty;

            List<object> liste = new List<object>();
            for (int i = 0; i < bilgi.objeler.Count; i++)
            {
                OgrenimBazliPersonelSayi perSayi = (OgrenimBazliPersonelSayi)bilgi.objeler[i];

                object degerler = new
                {
                    ID = perSayi.ogrenim.kod,
                    Ogrenim = perSayi.ogrenim.ad,
                    Sayi = perSayi.personelSayi.ToString("#,###")
                };

                liste.Add(degerler);
            }

            storeOgrenim.DataSource = liste;
            storeOgrenim.DataBind();

            ((RowSelectionModel)grdOgrenim.SelectionModel[0]).Listeners.RowSelect.Handler = "PersonelAc(" + muhasebe + ", " + birim + ", '', '', this.getSelected().id);";

            return string.Empty;
        }

        private string UnvanBazliPersonelSayilariGoster(int muhasebe, string birim)
        {
            ObjectArray bilgi = servisPER.UnvanBazliPersonelSayilariListele(muhasebe, birim);
            if (!bilgi.sonuc.islemSonuc)
            {
                GenelIslemler.HataYaz(this, bilgi.sonuc.hataStr);
                return null;
            }
            if (bilgi.objeler.Count <= 0)
                return string.Empty;

            List<object> liste = new List<object>();
            for (int i = 0; i < bilgi.objeler.Count; i++)
            {
                UnvanBazliPersonelSayi perSayi = (UnvanBazliPersonelSayi)bilgi.objeler[i];

                object degerler = new
                {
                    ID = perSayi.unvan.kod,
                    Unvan = perSayi.unvan.ad,
                    Sayi = perSayi.personelSayi.ToString("#,###")
                };

                liste.Add(degerler);
            }

            storeUnvan.DataSource = liste;
            storeUnvan.DataBind();

            ((RowSelectionModel)grdUnvan.SelectionModel[0]).Listeners.RowSelect.Handler = "PersonelAc(" + muhasebe + ", " + birim + ", this.getSelected().id, '', '');";

            return string.Empty;
        }

        private string SinifBazliPersonelSayilariGoster(int muhasebe, string birim)
        {
            ObjectArray bilgi = servisPER.SinifBazliPersonelSayilariListele(muhasebe, birim);
            if (!bilgi.sonuc.islemSonuc)
            {
                GenelIslemler.HataYaz(this, bilgi.sonuc.hataStr);
                return null;
            }
            if (bilgi.objeler.Count <= 0)
                return string.Empty;

            List<object> liste = new List<object>();
            for (int i = 0; i < bilgi.objeler.Count; i++)
            {
                SinifBazliPersonelSayi perSayi = (SinifBazliPersonelSayi)bilgi.objeler[i];

                object degerler = new
                {
                    ID = perSayi.sinif.kod,
                    Sinif = perSayi.sinif.ad,
                    Sayi = perSayi.personelSayi.ToString("#,###")
                };

                liste.Add(degerler);
            }

            storeSinif.DataSource = liste;
            storeSinif.DataBind();

            ((RowSelectionModel)grdSinif.SelectionModel[0]).Listeners.RowSelect.Handler = "PersonelAc(" + muhasebe + ", " + birim + ", '', this.getSelected().id, '');";

            return string.Empty;
        }

        private string UnvanVeKadroDereceBazliPersonelSayilariGoster(string kurKod, int muhasebe, string birim, int orgBirimKod)
        {
            TNS.PER.KadroKontenjan kk = new TNS.PER.KadroKontenjan();
            kk.orgBirimKod = orgBirimKod;
            kk.mb = new TNS.MUH.MuhasebeBirim();
            kk.mb.kurum = kurKod;
            kk.mb.muhasebe = muhasebe;
            kk.mb.birimKod = birim;

            ObjectArray bilgi = servisPER.UnvanVeKadroDereceBazliPersonelSayilariListele(kullanan, kk);
            if (!bilgi.sonuc.islemSonuc)
            {
                GenelIslemler.HataYaz(this, bilgi.sonuc.hataStr);
                return null;
            }
            if (bilgi.objeler.Count <= 0)
                return string.Empty;

            for (int i = 0; i < bilgi.objeler.Count; i++)
            {
                UnvanVeKadroDereceBazliPersonelSayi iPerSayi = (UnvanVeKadroDereceBazliPersonelSayi)bilgi.objeler[i];
                if (iPerSayi.unvan.kod <= 0 || iPerSayi.kadroDerece < 1 || iPerSayi.kadroDerece > 15)
                {
                    bilgi.objeler.RemoveAt(i);
                    i--;
                    continue;
                }

                int[,] personelSayilar = new int[kadroDereceSayi, 2];
                personelSayilar[iPerSayi.kadroDerece - 1, 0] = iPerSayi.personelSayi;
                personelSayilar[iPerSayi.kadroDerece - 1, 1] = iPerSayi.kontenjan;
                bilgi.objeler.RemoveAt(i);
                i--;

                for (int j = i + 1; j < bilgi.objeler.Count; j++)
                {
                    UnvanVeKadroDereceBazliPersonelSayi jPerSayi = (UnvanVeKadroDereceBazliPersonelSayi)bilgi.objeler[j];
                    if (jPerSayi.unvan.kod <= 0 || jPerSayi.kadroDerece < 1 || jPerSayi.kadroDerece > 15)
                    {
                        bilgi.objeler.RemoveAt(j);
                        j--;
                        continue;
                    }

                    if (iPerSayi.unvan.kod == jPerSayi.unvan.kod)
                    {
                        personelSayilar[jPerSayi.kadroDerece - 1, 0] = jPerSayi.personelSayi;
                        personelSayilar[jPerSayi.kadroDerece - 1, 1] = jPerSayi.kontenjan;
                        bilgi.objeler.RemoveAt(j);
                        j--;
                    }
                }

                DataRow dr = dtUnvanKadro.NewRow();
                dr.SetField<string>(0, iPerSayi.unvan.kod.ToString());
                dr.SetField<string>(1, iPerSayi.unvan.ad);
                for (int k = 0; k < personelSayilar.Length / 2; k++)
                    dr.SetField<string>(k + 2, personelSayilar[k, 0].ToString("#,###") + "/" + personelSayilar[k, 1].ToString("#,###"));
                dtUnvanKadro.Rows.Add(dr);
            }

            storeUnvanKadro.DataSource = dtUnvanKadro;
            storeUnvanKadro.DataBind();

            ((RowSelectionModel)grdUnvanKadro.SelectionModel[0]).Listeners.RowSelect.Handler = "PersonelAc(" + muhasebe + ", " + birim + ", this.getSelected().id, '', '');";

            return string.Empty;
        }
    }
}