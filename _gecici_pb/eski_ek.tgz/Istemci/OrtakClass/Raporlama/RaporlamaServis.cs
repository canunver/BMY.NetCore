﻿using System;
using System.Collections;
using TNS;
using TNS.KYM;
using OrtakClass;
using System.Configuration;
using System.Resources;
using System.IO;
using System.Threading;

namespace TNS.Raporlama
{
    public enum DEGISKENTIP : int
    {
        YIL, AY, ASAMA, KURUM, BIRIM, COMBO, YAZI, YAZIKURUMSAL, TEKLIFYIL, ASAMAUYGULAMA, COMBO_DINAMIK, COMBO_KODAD, TARIH, ILKTARIH, SONTARIH, SENARYO, CHECKBOX, EGITIMTIP
    }

    public enum RAPORTIP : int
    {
        EXCEL, METOD
    }

    public class RaporException : Exception
    {
        public RaporException(string message) : base(message) { }
    }

    public interface IRapor
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="kullanan">KYM.Kullanıcı tipinde bir nesne olmalı</param>
        /// <param name="servis">BHM.IBHMServis tipinde bir nesne olmalı</param>
        /// <param name="sablonAd"></param>
        /// <param name="sonucDosyaAd"></param>
        /// <param name="ciktiYeri"></param>
        /// <param name="raporParam"></param>
        /// <returns></returns>
        string RaporAl(object kullanan, object servis, string sablonAd, string sonucDosyaAd, string ciktiYeri, System.Collections.Hashtable raporParam, string ekBilgi);
    }

    public class KistasEkranAlan
    {
        public string Etiket(int rgNo)
        {
            return OrtakClass.OrtakClassRes.ResourceManager.GetString(RaporlamaServis.KistasAlanResAd(rgNo, this.degiskenAd));
        }

        public string degiskenAd;
        public string degiskenAciklama;
        public DEGISKENTIP degiskenTip;
        public bool gizli;
        public string liste;
        public string ilkDeger;
        public bool zorunlu;
        public string ekBilgi;
        public int[] gosterilecekRaporlar;
        public KistasEkranAlan(string p_degiskenAd, string p_degiskenAciklama, string p_degiskenTip, string p_liste, string p_gizli, string p_ilkDeger, string p_zorunlu, string ekBilgi, string gosterilecekRaporlar)
        {
            degiskenAd = p_degiskenAd;
            degiskenAciklama = p_degiskenAciklama;
            if (p_gizli == null)
                gizli = false;
            else if (p_gizli == "" || p_gizli == "0")
                gizli = false;
            else
                gizli = true;
            if (p_liste == null)
                liste = "";
            else
                liste = p_liste;
            if (p_ilkDeger == null)
                ilkDeger = "";
            else
                ilkDeger = p_ilkDeger;
            if (p_degiskenTip.ToUpper() == "YIL")
                degiskenTip = DEGISKENTIP.YIL;
            else if (p_degiskenTip.ToUpper() == "TEKLIFYIL")
                degiskenTip = DEGISKENTIP.TEKLIFYIL;
            else if (p_degiskenTip.ToUpper() == "ASAMA")
                degiskenTip = DEGISKENTIP.ASAMA;
            else if (p_degiskenTip.ToUpper() == "ASAMAUYGULAMA")
                degiskenTip = DEGISKENTIP.ASAMAUYGULAMA;
            else if (p_degiskenTip.ToUpper() == "AY")
                degiskenTip = DEGISKENTIP.AY;
            else if (p_degiskenTip.ToUpper() == "KURUM")
                degiskenTip = DEGISKENTIP.KURUM;
            else if (p_degiskenTip.ToUpper() == "BIRIM")
                degiskenTip = DEGISKENTIP.BIRIM;
            else if (p_degiskenTip.ToUpper() == "COMBO")
                degiskenTip = DEGISKENTIP.COMBO;
            else if (p_degiskenTip.ToUpper() == "COMBO_KODAD")
                degiskenTip = DEGISKENTIP.COMBO_KODAD;
            else if (p_degiskenTip.ToUpper() == "COMBO_DINAMIK")
                degiskenTip = DEGISKENTIP.COMBO_DINAMIK;
            else if (p_degiskenTip.ToUpper() == "YAZI")
                degiskenTip = DEGISKENTIP.YAZI;
            else if (p_degiskenTip.ToUpper() == "YAZIKURUMSAL")
                degiskenTip = DEGISKENTIP.YAZIKURUMSAL;
            else if (p_degiskenTip.ToUpper() == "TARIH")
                degiskenTip = DEGISKENTIP.TARIH;
            else if (p_degiskenTip.ToUpper() == "ILKTARIH")
                degiskenTip = DEGISKENTIP.ILKTARIH;
            else if (p_degiskenTip.ToUpper() == "SONTARIH")
                degiskenTip = DEGISKENTIP.SONTARIH;
            else if (p_degiskenTip.ToUpper() == "SENARYO")
                degiskenTip = DEGISKENTIP.SENARYO;
            else if (p_degiskenTip.ToUpper() == "CHECKBOX")
                degiskenTip = DEGISKENTIP.CHECKBOX;
            else
                throw new RaporException(String.Format(RaporlamaServis.str1, p_degiskenTip));

            if (p_zorunlu == null)
                zorunlu = false;
            else if (p_zorunlu == "")
                zorunlu = false;
            else
                zorunlu = true;
            if (string.IsNullOrWhiteSpace(gosterilecekRaporlar)) this.gosterilecekRaporlar = null;
            else
            {
                string[] tut = gosterilecekRaporlar.Split(',', ';');
                this.gosterilecekRaporlar = new int[tut.Length];
                for (int i = 0; i < tut.Length; i++)
                {
                    this.gosterilecekRaporlar[i] = OrtakFonksiyonlar.ConvertToInt(tut[i], 0);
                }
            }
            this.ekBilgi = ekBilgi;
        }
    }

    public class KistasEkran
    {
        private ArrayList alanlar;
        public string ekBilgi;
        public KistasEkran(string ekBilgi)
        {
            alanlar = new ArrayList();
            this.ekBilgi = ekBilgi;
        }

        public void Add(KistasEkranAlan kea)
        {
            alanlar.Add(kea);
        }

        public int AlanSayisi()
        {
            return alanlar.Count;
        }

        public string ZorunlulukKontrol(System.Collections.Hashtable ht, int rgNo)
        {
            string cevap = "";
            for (int i = 0; i < alanlar.Count; i++)
            {
                KistasEkranAlan kea = (KistasEkranAlan)alanlar[i];
                if (kea.zorunlu)
                {
                    if (ht[kea.degiskenAd] == null || (string)ht[kea.degiskenAd] == "")
                    {
                        if (cevap != "") cevap += "<br>";
                        cevap += String.Format(RaporlamaServis.str2, kea.Etiket(rgNo));
                    }
                }
            }
            return cevap;
        }

        public KistasEkranAlan Alan(int i)
        {
            if (i >= 0 && i < alanlar.Count)
                return (KistasEkranAlan)alanlar[i];
            else
                return null;
        }
    }

    public class RaporBolum
    {
        public int bolumNo;
        public string ekBilgi;

        public string RaporBolumAd(int rgNo)
        {
            return OrtakClass.OrtakClassRes.ResourceManager.GetString(RaporlamaServis.RaporBolumResAd(rgNo, bolumNo));
        }

        public RaporBolum(string p_bolumNo, string ekBilgi)
        {
            bolumNo = OrtakFonksiyonlar.ConvertToInt(p_bolumNo, -1);
            this.ekBilgi = ekBilgi;
            if (bolumNo <= 0)
                throw new RaporException(string.Format(RaporlamaServis.str3, bolumNo));
        }
    }

    public class Rapor
    {
        public static string raporSablonYol = System.Configuration.ConfigurationManager.AppSettings.Get("RaporSablonYol");
        private ArrayList yetkiTipIsimleri;
        public RAPORTIP raporTip;
        public string yolsuzSablonAd;

        public string sablonAd
        {
            get
            {
                if (string.IsNullOrWhiteSpace(yolsuzSablonAd)) return "";
                return RaporlamaServis.RaporSablonYolGetir(raporSablonYol) + yolsuzSablonAd;
            }
        }
        public string dllAd;
        public string nesneAd;
        public int raporNo;
        public int bolumNo;
        public string ekBilgi;
        public string raporCiktiTur;
        public bool ekOlarakGonder = true;

        internal string RaporAd(int rgNo)
        {
            return OrtakClass.OrtakClassRes.ResourceManager.GetString(RaporlamaServis.RaporResAd(rgNo, raporNo));
        }

        public bool GrafikMi()
        {
            if (raporCiktiTur != null && raporCiktiTur == "GRAFIK")
            {
                return true;
            }
            return false;
        }

        public Rapor(string p_raporNo, string p_yetkiTipleri, string p_raporTip, string p_sablonAd, string p_dllAd, string p_nesneAd, string p_bolumNo, string ekBilgi, string p_raporCiktiTur)
        {
            raporNo = OrtakFonksiyonlar.ConvertToInt(p_raporNo, -1);
            bolumNo = OrtakFonksiyonlar.ConvertToInt(p_bolumNo, -1);
            this.ekBilgi = ekBilgi;
            RaporlamaServis.YetkiStringParcala(p_yetkiTipleri, ref yetkiTipIsimleri);
            if (p_raporTip.ToUpper() == "EXCEL")
                raporTip = RAPORTIP.EXCEL;
            else if (p_raporTip.ToUpper() == "METOD")
                raporTip = RAPORTIP.METOD;
            else
                throw new RaporException(string.Format(RaporlamaServis.str4, p_raporTip));
            yolsuzSablonAd = p_sablonAd;
            nesneAd = p_nesneAd;
            dllAd = p_dllAd;
            raporCiktiTur = p_raporCiktiTur;
        }

        public int YetkiTipiSayisi()
        {
            return yetkiTipIsimleri.Count;
        }

        public string YetkiTipi(int i)
        {
            if (i >= 0 && i < YetkiTipiSayisi())
                return (string)yetkiTipIsimleri[i];
            else
                return "";
        }

        public string RaporHazirla(object kullanan, object servis, Hashtable ht, bool gonder, string sonucDosyaAd)
        {
            if (raporTip == RAPORTIP.EXCEL)
                return ExcelRaporHazirla(kullanan, servis, ht, gonder, sonucDosyaAd);
            else if (raporTip == RAPORTIP.METOD)
                return MetodRaporHazirla(kullanan, servis, ht, gonder, sonucDosyaAd);
            else
                throw new Exception(RaporlamaServis.str5);
        }

        public string RaporHazirla(object kullanan, object servis, Hashtable ht, bool gonder, bool kaydet, string filePath)
        {
            if (raporTip == RAPORTIP.EXCEL)
                return ExcelRaporHazirla(kullanan, servis, ht, gonder, true, filePath);
            else if (raporTip == RAPORTIP.METOD)
                return MetodRaporHazirla(kullanan, servis, ht, gonder, filePath);
            else
                throw new Exception(RaporlamaServis.str5);
        }

        private string ExcelRaporHazirla(object kullanan, object servis, System.Collections.Hashtable ht, bool gonder, string sonucDosyaAd)
        {
            string tempFileName = null;
            if (sonucDosyaAd == null || sonucDosyaAd == "")
            {
                tempFileName = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
                sonucDosyaAd = tempFileName;//System.IO.Path.GetFileNameWithoutExtension(tempFileName);
            }
            sonucDosyaAd = OrtakClass.ExcelRapor.ExcelRaporHesapla(kullanan, null, sablonAd, sonucDosyaAd, null, ht);
            if (tempFileName != null)
                System.IO.File.Delete(tempFileName);
            if (gonder)
                OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, System.IO.Path.GetFileNameWithoutExtension(sablonAd), true, (string)ht["CiktiYeri"], ekOlarakGonder);
            return sonucDosyaAd;
        }
        private string ExcelRaporHazirla(object kullanan, object servis, System.Collections.Hashtable ht, bool gonder, bool kaydet, string filePath)
        {
            string tempFileName = null;
            string sonucDosyaAd = filePath;
            sonucDosyaAd = OrtakClass.ExcelRapor.ExcelRaporHesapla(kullanan, null, sablonAd, sonucDosyaAd, null, ht);
            if (!kaydet)
                System.IO.File.Delete(tempFileName);
            if (gonder)
                OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, System.IO.Path.GetFileNameWithoutExtension(sablonAd), false, (string)ht["CiktiYeri"], ekOlarakGonder);
            return sonucDosyaAd;
        }

        private string MetodRaporHazirla(object kullanan, object servis, System.Collections.Hashtable ht, bool gonder, string sonucDosyaAd)
        {
            System.Runtime.Remoting.ObjectHandle oh = Activator.CreateInstance(dllAd, nesneAd);
            if (oh != null)
            {
                TNS.Raporlama.IRapor rr = (TNS.Raporlama.IRapor)oh.Unwrap();
                string tempFileName = null;
                if (sonucDosyaAd == null || sonucDosyaAd == "")
                {
                    tempFileName = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
                    sonucDosyaAd = tempFileName;//System.IO.Path.GetFileNameWithoutExtension(tempFileName);
                }

                sonucDosyaAd = rr.RaporAl(kullanan, servis, sablonAd, sonucDosyaAd, null, ht, ekBilgi);


                if (tempFileName != null)
                    System.IO.File.Delete(tempFileName);

                if (sonucDosyaAd.StartsWith("HATA") || sonucDosyaAd.StartsWith("BILGI"))
                {
                    return sonucDosyaAd;
                }
                else
                {
                    if (gonder)
                        if (sonucDosyaAd != "")
                        {
                            string gidecekAd = "";
                            //try
                            //{
                            //    gidecekAd = this.RaporAd(this.)
                            //}
                            //catch { }
                            if (string.IsNullOrEmpty(gidecekAd) && !string.IsNullOrEmpty(sablonAd))
                                gidecekAd = System.IO.Path.GetFileNameWithoutExtension(sablonAd) + "_" + DateTime.Now.Ticks.ToString();
                            if (string.IsNullOrEmpty(gidecekAd))
                                gidecekAd = System.IO.Path.GetFileNameWithoutExtension(sonucDosyaAd);
                            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, gidecekAd, true, (string)ht["CiktiYeri"], ekOlarakGonder);
                        }

                    return sonucDosyaAd;
                }
            }
            else
                throw new Exception(RaporlamaServis.str6);
        }
        private string MetodRaporHazirla(object kullanan, object servis, System.Collections.Hashtable ht, bool gonder, bool kaydet, string filePath)
        {
            System.Runtime.Remoting.ObjectHandle oh = Activator.CreateInstance(dllAd, nesneAd);
            if (oh != null)
            {
                TNS.Raporlama.IRapor rr = (TNS.Raporlama.IRapor)oh.Unwrap();
                string tempFileName = null;
                string sonucDosyaAd = filePath;
                if (sonucDosyaAd == null || sonucDosyaAd == "")
                {
                    tempFileName = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
                    sonucDosyaAd = tempFileName;//System.IO.Path.GetFileNameWithoutExtension(tempFileName);
                }

                sonucDosyaAd = rr.RaporAl(kullanan, servis, sablonAd, sonucDosyaAd, null, ht, ekBilgi);
                if (!kaydet)
                    System.IO.File.Delete(tempFileName);

                if (gonder)
                    if (sonucDosyaAd != "")
                        OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, System.IO.Path.GetFileNameWithoutExtension(sablonAd), true, (string)ht["CiktiYeri"]);

                return sonucDosyaAd;
            }
            else
                throw new Exception(RaporlamaServis.str6);
        }

        public bool YetkisiVarMi(TNS.KYM.Kullanici kullanan)
        {
            int tut = YetkiTipiSayisi();

            if (tut == 0)
                return true;
            else
            {
                if (kullanan == null)
                    return false;
                /*Melih ??? kısmı command li olduğu için uyarı veriyordu
                for (int j = 0; j < tut; j++)
                {
                    //???if( KYM.KullaniciTipi.KullaniciTipiAdi(kullanan.kullaniciTipi.kod) == KYM.KullaniciTipi.KullaniciTipiAdi(YetkiTipi(j)))
                    return true;
                }
                */
                return false;
            }
        }

    }

    public class RaporGrup
    {
        private ArrayList yetkiTipIsimleri;
        public KistasEkran kistasEkran = null;
        private ArrayList raporlar;
        private ArrayList bolumler;
        public int grupNo = -1;
        public bool yetkiKontrol;
        public string ekBilgi;
        public bool ekOlarakGonder = true;

        public string KistasEkranAd()
        {
            return OrtakClass.OrtakClassRes.ResourceManager.GetString(RaporlamaServis.KistasEkranResAd(grupNo));
        }

        public string RaporAd(int raporNo)
        {
            return OrtakClass.OrtakClassRes.ResourceManager.GetString(RaporlamaServis.RaporResAd(grupNo, raporNo));
        }

        public string EtiketAd(int alanSiraNo)
        {
            return OrtakClass.OrtakClassRes.ResourceManager.GetString(RaporlamaServis.KistasAlanResAd(grupNo, this.kistasEkran.Alan(alanSiraNo).degiskenAd));
        }

        public RaporGrup(string p_yetkiTipleri, string p_grupNo, string p_yetkiKontroluYapma, string ekBilgi)
        {
            grupNo = OrtakFonksiyonlar.ConvertToInt(p_grupNo, -1);
            this.ekBilgi = ekBilgi;
            raporlar = new ArrayList();
            bolumler = new ArrayList();
            RaporlamaServis.YetkiStringParcala(p_yetkiTipleri, ref yetkiTipIsimleri);
            if (p_yetkiKontroluYapma == null)
                yetkiKontrol = true;
            else if (p_yetkiKontroluYapma == "0")
                yetkiKontrol = true;
            else
                yetkiKontrol = false;
        }

        public void KistasEkranAta(KistasEkran p_kistasEkran)
        {
            kistasEkran = p_kistasEkran;
        }

        public void Add(Rapor r)
        {
            raporlar.Add(r);
        }

        public void BolumEkle(RaporBolum rb)
        {
            bolumler.Add(rb);
        }

        public int RaporSayisi()
        {
            return raporlar.Count;
        }

        public int BolumSayisi()
        {
            return bolumler.Count;
        }

        public Rapor Rapor(int rNo)
        {
            for (int i = 0; i < raporlar.Count; i++)
            {
                Rapor r = (Rapor)raporlar[i];
                if (r.raporNo == rNo)
                    return r;
            }
            return null;
        }

        public RaporBolum RaporBolum(int i)
        {
            if (i >= 0 && i < BolumSayisi())
                return (RaporBolum)bolumler[i];
            else
                return null;
        }

        public int YetkiTipiSayisi()
        {
            return yetkiTipIsimleri.Count;
        }

        public string YetkiTipi(int i)
        {
            if (i >= 0 && i < YetkiTipiSayisi())
                return (string)yetkiTipIsimleri[i];
            else
                return "";
        }

        public Rapor this[int i]
        {
            get
            {
                if (i >= 0 && i < raporlar.Count)
                    return (Rapor)raporlar[i];
                else
                    return null;
            }
        }

        private string KurumAsamaYetkisiVarMi(TNS.KYM.Kullanici kullanan, Hashtable ht)
        {
            int girdiKurum = 0;
            int yil = -1;
            for (int j = 0; j < kistasEkran.AlanSayisi(); j++)
            {
                if (kistasEkran.Alan(j).degiskenTip == DEGISKENTIP.KURUM)
                {
                    girdiKurum = 1;
                    string kurum = (string)ht[kistasEkran.Alan(j).degiskenAd];
                    string birim = "";
                    int girdiBirim = 0;
                    for (int jj = 0; jj < kistasEkran.AlanSayisi(); jj++)
                    {
                        if (kistasEkran.Alan(jj).degiskenTip == DEGISKENTIP.BIRIM)
                        {
                            girdiBirim = 1;
                            birim = (string)ht[kistasEkran.Alan(jj).degiskenAd];
                        }
                        if (kistasEkran.Alan(jj).degiskenTip == DEGISKENTIP.YIL)
                        {
                            yil = OrtakFonksiyonlar.ConvertToInt((string)ht[kistasEkran.Alan(jj).degiskenAd], -1);
                        }
                    }
                    if (girdiBirim == 0)
                        birim = kurum;
                    else if (birim == "" || birim == "00")
                        birim = kurum;

                    int girdiAsama = 0;
                    for (int jj = 0; jj < kistasEkran.AlanSayisi(); jj++)
                    {
                        if (kistasEkran.Alan(jj).degiskenTip == DEGISKENTIP.ASAMA)
                        {
                            girdiAsama = 1;
                            string asama = (string)ht[kistasEkran.Alan(jj).degiskenAd];
                            bool hakVar = OrtakClass.GenelIslemler.GormeYetkisiVarMi(kullanan, birim, Convert.ToInt16(asama));
                            if (!hakVar)
                                return string.Format(RaporlamaServis.str7, birim, Convert.ToInt16(asama));
                        }
                        else if (kistasEkran.Alan(jj).degiskenTip == DEGISKENTIP.ASAMAUYGULAMA)
                        {
                            girdiAsama = 1;
                            string asama = (string)ht[kistasEkran.Alan(jj).degiskenAd];
                            bool hakVar = OrtakClass.GenelIslemler.GormeYetkisiVarMiUygulama(yil, kullanan, birim, Convert.ToInt16(asama));
                            if (!hakVar)
                                return string.Format(RaporlamaServis.str7, birim, Convert.ToInt16(asama));
                        }
                    }

                    if (girdiAsama == 0)
                    {
                        bool hakVar = OrtakClass.GenelIslemler.GormeYetkisiVarMi(kullanan, birim, 0);
                        if (!hakVar)
                            return string.Format(RaporlamaServis.str8, birim);
                    }
                    else
                        return "";
                }
            }

            if (girdiKurum == 0)
            {
                int girdiAsama = 0;
                for (int jj = 0; jj < kistasEkran.AlanSayisi(); jj++)
                {
                    if (kistasEkran.Alan(jj).degiskenTip == DEGISKENTIP.ASAMA)
                    {
                        girdiAsama = 1;
                        string asama = (string)ht[kistasEkran.Alan(jj).degiskenAd];
                        bool hakVar = OrtakClass.GenelIslemler.GormeYetkisiVarMi(kullanan, "", Convert.ToInt16(asama));
                        if (!hakVar)
                            return string.Format(RaporlamaServis.str9, Convert.ToInt16(asama));
                    }
                    else if (kistasEkran.Alan(jj).degiskenTip == DEGISKENTIP.ASAMAUYGULAMA)
                    {
                        girdiAsama = 1;
                        string asama = (string)ht[kistasEkran.Alan(jj).degiskenAd];
                        bool hakVar = OrtakClass.GenelIslemler.GormeYetkisiVarMiUygulama(yil, kullanan, "", Convert.ToInt16(asama));
                        if (!hakVar)
                            return string.Format(RaporlamaServis.str9, Convert.ToInt16(asama));
                    }
                }

                if (girdiAsama == 0)
                {
                    bool hakVar = OrtakClass.GenelIslemler.GormeYetkisiVarMiUygulama(2006, kullanan, "", 2);
                    if (!hakVar)
                        return RaporlamaServis.str10;
                }
            }
            else
                return "";
            return "";
        }

        public bool YetkisiVarMi(TNS.KYM.Kullanici kullanan)
        {
            int tut = YetkiTipiSayisi();

            if (tut == 0)
                return true;
            else
            {
                if (kullanan == null)
                    return false;
                /*Melih ??? kısmı command li olduğu için uyarı veriyordu
                for (int j = 0; j < tut; j++)
                {
                    //???if( KYM.KullaniciTipi.KullaniciTipiAdi(kullanan.kullaniciTipi.kod) == KYM.KullaniciTipi.KullaniciTipiAdi(YetkiTipi(j)))
                    return true;
                }
                */
                return false;
            }
        }

        public string RaporAl(TNS.KYM.Kullanici kullanan, object servis, TNSCollection raporNolar, Hashtable ht, bool gonder, string sonucDosyaAd)
        {
            if (raporNolar.Count <= 0)
                throw new Exception(RaporlamaServis.str11);

            string hata = kistasEkran.ZorunlulukKontrol(ht, this.grupNo);
            if (hata != "")
            {
                throw new Exception(hata);
            }
            if (yetkiKontrol)
                hata = KurumAsamaYetkisiVarMi(kullanan, ht);
            if (hata != "")
            {
                throw new Exception(hata);
            }

            if (!YetkisiVarMi(kullanan))
            {
                throw new Exception(string.Format(RaporlamaServis.str12, RaporGrupAd()));
            }

            for (int rNo = 0; rNo < raporNolar.Count; rNo++)
            {
                Rapor r = Rapor((int)raporNolar[rNo]);
                if (r == null)
                    throw new Exception(RaporlamaServis.str13);
                if (!r.YetkisiVarMi(kullanan))
                {
                    throw new Exception(string.Format(RaporlamaServis.str14, r.sablonAd));
                }
            }
            if (raporNolar.Count == 1)
            {
                Rapor r = Rapor((int)raporNolar[0]);
                r.ekOlarakGonder = ekOlarakGonder;
                return r.RaporHazirla(kullanan, servis, ht, gonder, sonucDosyaAd);
            }
            else
            {
                //Birden fazla rapor dolayısıyle sıkıştırıp göndereceğizdir.
                string tempFileName = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
                string klasor = tempFileName + ".dir";
                System.IO.DirectoryInfo dri = System.IO.Directory.CreateDirectory(klasor);
                klasor += "\\";
                string ciktiYer = (string)ht["CiktiYeri"];
                if (ciktiYer == null || ciktiYer == "") ciktiYer = "PDF";
                else ciktiYer = ciktiYer.ToUpper();
                if (string.IsNullOrEmpty(ciktiYer) || ciktiYer == "XLS") ciktiYer = GenelIslemler.ExcelTur();
                for (int i = 0; i < raporNolar.Count; i++)
                {
                    Rapor r = Rapor((int)raporNolar[i]);
                    string cikanDosya = r.RaporHazirla(kullanan, servis, ht, false, klasor + System.IO.Path.GetFileNameWithoutExtension(r.sablonAd));
                    if (cikanDosya != "")
                    {
                        if (ciktiYer == "PDF")
                        {
                            string ext = System.IO.Path.GetExtension(cikanDosya).Replace(".", "");
                            string yeniDosya = "";

                            yeniDosya = OrtakClass.DosyaTipDegistir.Dosya2PDF(cikanDosya, true);
                            if (yeniDosya != "")
                            {
                                cikanDosya = yeniDosya;
                            }
                        }
                    }
                    else
                        throw new Exception(string.Format(RaporlamaServis.str15, r.sablonAd));
                }
                string[] dosyalar = { "" };
                if (sonucDosyaAd == null || sonucDosyaAd == "")
                {
                    sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
                    gonder = true;
                }
                OrtakClass.Zip.Ziple(dri.FullName, sonucDosyaAd, dosyalar);
                dri.Delete(true);
                System.IO.File.Delete(tempFileName);
                if (gonder)
                    OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "dosyalar.zip", gonder, "zip");
                return sonucDosyaAd;
            }
        }

        public string RaporAl(TNS.KYM.Kullanici kullanan, object servis, Rapor r, Hashtable ht, bool gonder, bool kaydet, string filePath)
        {
            string hata = kistasEkran.ZorunlulukKontrol(ht, this.grupNo);
            if (hata != "")
            {
                throw new Exception(hata);
            }
            if (yetkiKontrol)
                hata = KurumAsamaYetkisiVarMi(kullanan, ht);
            if (hata != "")
            {
                throw new Exception(hata);
            }

            if (!YetkisiVarMi(kullanan))
            {
                throw new Exception(string.Format(RaporlamaServis.str12, RaporGrupAd()));
            }

            if (r == null)
                throw new Exception(RaporlamaServis.str13);
            if (!r.YetkisiVarMi(kullanan))
            {
                throw new Exception(string.Format(RaporlamaServis.str14, r.sablonAd));
            }

            string cikanDosya = r.RaporHazirla(kullanan, servis, ht, false, true, filePath); //this.Server.MapPath("~")+"\\BHFormEx\\", 

            if (cikanDosya.StartsWith("HATA") || cikanDosya.StartsWith("BİLGİ"))
                return cikanDosya;

            string ciktiYer = (string)ht["CiktiYeri"];
            if (cikanDosya != "")
            {
                string ext = System.IO.Path.GetExtension(cikanDosya).Replace(".", "");
                if (ciktiYer == "PDF")
                {
                    string yeniDosya = "";

                    yeniDosya = OrtakClass.DosyaTipDegistir.Dosya2PDF(cikanDosya, true);
                    if (yeniDosya != "")
                    {
                        cikanDosya = yeniDosya;
                        ext = System.IO.Path.GetExtension(cikanDosya).Replace(".", "");
                    }
                }
                if (gonder)
                    OrtakClass.DosyaIslem.DosyaGonder(cikanDosya, System.IO.Path.GetFileNameWithoutExtension(cikanDosya), !kaydet, ext);
                return cikanDosya;
            }
            else
                throw new Exception(string.Format(RaporlamaServis.str15, r.sablonAd));
        }

        public string RaporGrupAd()
        {
            return OrtakClass.OrtakClassRes.ResourceManager.GetString(RaporlamaServis.RaporGrupResAd(this.grupNo));
        }

        public Hashtable VarsayilanDegiskenAta(Kullanici kullanan, out string kosullar)
        {
            int yil = 0;
            TNS.UZY.IUZYServis uzyServis = TNS.UZY.Arac.Tanimla();
            Hashtable ht = new Hashtable();
            kosullar = "";
            for (int i = 0; i < this.kistasEkran.AlanSayisi(); i++)
            {
                KistasEkranAlan alan = this.kistasEkran.Alan(i);
                string sakliAlan = "RAPOR_" + alan.degiskenAd;
                string kullaniciSakliKriter = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, sakliAlan);

                if (alan.degiskenTip == DEGISKENTIP.YIL)
                {
                    yil = DateTime.Now.Year;
                    if (!string.IsNullOrEmpty(alan.ekBilgi))
                        yil++;

                    if (kullaniciSakliKriter != "")//Kullanıcı kriter kayıtlı ise onu kullan
                        yil = OrtakFonksiyonlar.ConvertToInt(kullaniciSakliKriter, yil);

                    ht[alan.degiskenAd] = yil.ToString();
                    kosullar = StringeEkle(kosullar, "_", yil.ToString());
                }
                else if (alan.degiskenTip == DEGISKENTIP.ILKTARIH)
                {
                    string tarih = "01.01." + DateTime.Now.Year;

                    if (kullaniciSakliKriter != "")//Kullanıcı kriter kayıtlı ise onu kullan
                        tarih = kullaniciSakliKriter;

                    ht[alan.degiskenAd] = tarih;
                }
                else if (alan.degiskenTip == DEGISKENTIP.SONTARIH)
                {
                    string tarih = DateTime.Now.ToString();

                    if (kullaniciSakliKriter != "")//Kullanıcı kriter kayıtlı ise onu kullan
                        tarih = kullaniciSakliKriter;

                    ht[alan.degiskenAd] = tarih;
                }
                else if (alan.degiskenTip == DEGISKENTIP.SENARYO)
                {
                    if (kullaniciSakliKriter == "")//Kullanıcı kriter kayıtlı değilse 
                        kullaniciSakliKriter = "00.00";

                    ht[alan.degiskenAd] = kullaniciSakliKriter;
                    if (!string.IsNullOrEmpty(alan.degiskenAciklama))
                        ht[alan.degiskenAciklama] = RaporlamaServis.str16;
                    kosullar = StringeEkle(kosullar, "_", (string)ht[alan.degiskenAd]);
                }
                else if (alan.degiskenTip == DEGISKENTIP.BIRIM)
                {
                    string birimler = kullanan.YetkiTipiDegeriBul(RaporlamaServis.str17);

                    if (kullaniciSakliKriter != "")//Kullanıcı kriter kayıtlı ise onu kullan
                        birimler = kullaniciSakliKriter;

                    string[] birimlerDizi = birimler.Split(';');
                    if (birimlerDizi.Length > 0 && !string.IsNullOrEmpty(birimlerDizi[0]))
                        ht[alan.degiskenAd] = birimlerDizi[0];
                    //else
                    //{
                    //    ht[alan.degiskenAd] = GenelIslemlerI.VarsayilanKurumBul();
                    //}
                    kosullar = StringeEkle(kosullar, "_", (string)ht[alan.degiskenAd]);
                    if (!string.IsNullOrEmpty(alan.degiskenAciklama))
                        ht[alan.degiskenAciklama] = uzyServis.UzayDegeriStr(kullanan, "ABSKUR", yil + "-" + ht[alan.degiskenAd], true);
                }
                else
                {
                    if (kullaniciSakliKriter != "")
                        ht[alan.degiskenAd] = kullaniciSakliKriter;
                    else
                        ht[alan.degiskenAd] = alan.ilkDeger;
                }
            }

            return ht;
        }

        private string StringeEkle(string kosullar, string ek, string ekStr)
        {
            if (string.IsNullOrEmpty(kosullar)) return ekStr;
            else return kosullar + ek + ekStr;
        }
    }

    public class RaporGrupListesi
    {
        private ArrayList raporGruplari = new ArrayList();
        public string hata = "";

        public void Add(RaporGrup rg)
        {
            raporGruplari.Add(rg);
        }

        public int RaporGrupSayisi()
        {
            return raporGruplari.Count;
        }

        public RaporGrup RaporGrup(int i)
        {
            for (int j = 0; j < RaporGrupSayisi(); j++)
                if (((RaporGrup)raporGruplari[j]).grupNo == i)
                    return (RaporGrup)raporGruplari[j];
            return null;
        }

        public RaporGrup this[int i]
        {
            get
            {
                if (i >= 0 && i < raporGruplari.Count)
                    return (RaporGrup)raporGruplari[i];
                else
                    return null;

            }
        }
    }

    public class RaporlamaServis
    {
        public static string str1 = "Tanınmayan Değişken Tipi ({0}) geldi!";
        public static string str2 = "'{0}' alanını girmelisiniz!";
        public static string str3 = "{0} isimli bölümün bölüm numarası 0'a eşit veya küçük olamaz!";
        public static string str4 = "Tanınmayan Rapor Tipi ({0}) geldi!";
        public static string str5 = "Hatalı rapor türü!";
        public static string str6 = "Metod raporu hazırlanırken, belirtilen metoda erişilemedi!";
        public static string str7 = "{0} birimini veya {1}. aşamayı görme yetkiniz yok!";
        public static string str8 = "{0} birimini görme yetkiniz yok!";
        public static string str9 = "{0}. aşamayı görme yetkiniz yok!";
        public static string str10 = "Bu raporu görme yetkiniz yok!";
        public static string str11 = "Bir yada rapor numarası bildirmelisiniz";
        public static string str12 = "{0} grubundaki raporları görme yetkiniz yok!";
        public static string str13 = "Rapor bulunamadı";
        public static string str14 = "{0} raporunu görme yetkiniz yok.";
        public static string str15 = "{0} raporu üretilemedi!";
        public static string str16 = "Birim Teklifi";
        public static string str17 = "Bütçe Hazırlığı Yapacağı Birimler";
        public static string str18 = "Rapor XML dosyası \"RAPORLAR\" ile başlamalı";
        public static string str19 = "\"KISTAS\" bölümü başlamadan, \"KISTASALAN\" bölümü ile karşılaşıldı.";
        public static string str20 = "\"RAPORGRUP\" bölümü başlamadan \"RAPOR\" bölümü geldi!";
        public static string str21 = "\"RAPORGRUP\" bölümü başlamadan \"RAPORBOLUM\" bölümü geldi!";
        public static string str22 = "\"RAPORLAR\" bölümü başlamadan bitti!";
        public static string str23 = "\"RAPORGRUP\" bölümü başlamadan \"KISTAS\" bölümü geldi!";
        public static string str24 = "\"RAPORLAR\" kapanmadan XML dosyası bitti.";

        public static string RaporAd(int grupNo, int raporNo)
        {
            return OrtakClass.OrtakClassRes.ResourceManager.GetString(RaporlamaServis.RaporResAd(grupNo, raporNo));

        }

        internal static string RaporResAd(int grupNo, int raporNo)
        {
            return "REP_" + grupNo.ToString() + "_" + raporNo.ToString();
        }

        internal static string RaporBolumResAd(int grupNo, int bolumNo)
        {
            return "REP_B_" + grupNo.ToString() + "_" + bolumNo.ToString();
        }

        internal static string RaporGrupResAd(int grupNo)
        {
            return "REP_G_" + grupNo.ToString();
        }

        internal static string KistasAlanResAd(int grupNo, string degiskenAd)
        {
            return "REP_A_" + grupNo.ToString() + "_" + degiskenAd;
        }

        internal static string KistasEkranResAd(int grupNo)
        {
            return "REP_K_" + grupNo.ToString();
        }

        public static string RaporDosyaAdUret(int raporGrupNo, int raporNo, string anahtar, string kullaniciAd)
        {
            return kullaniciAd + "_" + raporGrupNo + "_" + raporNo + "_" + anahtar;
        }

        public static string RaporDosyaYolUret(string raporGrupNo, string raporNo, string dosyaAd, bool kutuphaneMi)
        {
            string dosyaYol = ConfigurationManager.AppSettings.Get("RaporDosyaYol");
            if (string.IsNullOrEmpty(dosyaYol))
                throw new Exception("'web.config' dosyasında 'RaporDosyaYol' değişkeni bulunamadı!");
            dosyaYol = dosyaYol.Trim();
            if (dosyaYol.EndsWith("\\"))
                dosyaYol = dosyaYol.TrimEnd('\\');
            if (dosyaYol.EndsWith("/"))
                dosyaYol = dosyaYol.TrimEnd('/');
            dosyaYol += "\\" + raporGrupNo;
            dosyaYol += "\\" + raporNo;
            if (kutuphaneMi)
                dosyaYol += "\\" + "kutuphane";
            if (!Directory.Exists(dosyaYol))
                Directory.CreateDirectory(dosyaYol);

            dosyaYol += "\\" + dosyaAd;

            return dosyaYol;
        }

        public static string TekRaporUret(int rapGrupNo, int rapNo, TNS.KYM.Kullanici kullanan, object servis, System.Collections.Hashtable raporParam)
        {
            return TekRaporAlIc(rapGrupNo, rapNo, kullanan, servis, raporParam, false, true);
        }

        public static void TekRaporAl(int rapGrupNo, int rapNo, TNS.KYM.Kullanici kullanan, object servis, System.Collections.Hashtable raporParam, bool ekOlarakGonder)
        {
            TekRaporAlIc(rapGrupNo, rapNo, kullanan, servis, raporParam, true, ekOlarakGonder);
        }

        public static void TekRaporAl(int rapGrupNo, int rapNo, TNS.KYM.Kullanici kullanan, object servis, System.Collections.Hashtable raporParam)
        {
            TekRaporAlIc(rapGrupNo, rapNo, kullanan, servis, raporParam, true, true);
        }

        private static string TekRaporAlIc(int rapGrupNo, int rapNo, TNS.KYM.Kullanici kullanan, object servis, System.Collections.Hashtable raporParam, bool gonder, bool ekOlarakGonder)
        {
            RaporGrupListesi rgl = RaporlamaServis.RaporListesiAl();
            RaporGrup rg = rgl.RaporGrup(rapGrupNo);
            if (rg == null)
            {
                RaporlamaServis.RaporListesiYenile();
                rg = rgl.RaporGrup(rapGrupNo);
            }
            if (rg == null)
                throw new Exception(rapGrupNo + " rapor bulunamadı");
            TNSCollection raporNolar = new TNSCollection();
            raporNolar.Add(rapNo);
            rg.ekOlarakGonder = ekOlarakGonder;
            return rg.RaporAl(kullanan, servis, raporNolar, raporParam, gonder, null);
        }
        public static string TekRaporAl(int rapGrupNo, int rapNo, TNS.KYM.Kullanici kullanan, object servis, System.Collections.Hashtable raporParam, bool gonder, bool kaydet, string yol)
        {
            return TekRaporAl(rapGrupNo, rapNo, kullanan, servis, raporParam, gonder, kaydet, yol, true);
        }

        public static string TekRaporAl(int rapGrupNo, int rapNo, TNS.KYM.Kullanici kullanan, object servis, System.Collections.Hashtable raporParam, bool gonder, bool kaydet, string yol, bool ekOlarakGonder)
        {
            RaporGrupListesi rgl = RaporlamaServis.RaporListesiAl();
            RaporGrup rg = rgl.RaporGrup(rapGrupNo);
            if (rg == null)
            {
                RaporlamaServis.RaporListesiYenile();
                rg = rgl.RaporGrup(rapGrupNo);
            }
            if (rg == null)
                throw new Exception(rapGrupNo + " rapor bulunamadı");
            TNSCollection raporNolar = new TNSCollection();
            raporNolar.Add(rapNo);
            return rg.RaporAl(kullanan, servis, rg.Rapor(rapNo), raporParam, gonder, kaydet, yol);
        }

        public static void YetkiStringParcala(string p_yetkiTipleri, ref ArrayList yetkiTipIsimleri)
        {
            string[] sa = p_yetkiTipleri.Split(',');
            yetkiTipIsimleri = new ArrayList();
            for (int i = 0; i < sa.Length; i++)
            {
                if (!String.IsNullOrEmpty(sa[i]))
                    yetkiTipIsimleri.Add(sa[i]);
            }
        }

        public static string RaporSablonYolGetir(string raporSablonYol)
        {
            if (raporSablonYol.EndsWith("\\") || raporSablonYol.EndsWith("/"))
                raporSablonYol = raporSablonYol.Substring(0, raporSablonYol.Length - 1);

            //29.11.2023 Melih Manas kullanıcılar en olarak yazılımı kullanıyor. Rapor alırken en klasöründe şablon olmayınca raporu alamıyorlar
            //string tut = Thread.CurrentThread.CurrentUICulture.Name;
            //if (!string.IsNullOrEmpty(tut) && tut.Length >= 2)
            //{
            //    tut = tut.Substring(0, 2);
            //    if (tut != "tr")
            //        raporSablonYol = Path.Combine(raporSablonYol, tut);
            //}

            raporSablonYol += "/";

            return raporSablonYol;
        }

        private static void RaporlariOku(string XMLDosyaAd, RaporGrupListesi raporlar)
        {
            string dosyaAd = System.Configuration.ConfigurationManager.AppSettings.Get(XMLDosyaAd);

            System.Xml.XmlTextReader x = null;
            RaporGrup rg = null;
            KistasEkran ke = null;
            bool devam = true;
            bool ilk = true;

            try
            {
                x = new System.Xml.XmlTextReader(dosyaAd);
            }
            catch (Exception e)
            {
                raporlar.hata = e.ToString();
            }

            try
            {
                while (x.Read() && devam)
                {
                    if (x.NodeType == System.Xml.XmlNodeType.Element)
                    {
                        if (ilk)
                        {
                            ilk = false;
                            if (x.Name.ToUpper() != "RAPORLAR")
                            {
                                throw new RaporException(str18);
                            }
                        }
                        if (x.Name.ToUpper() == "RAPORGRUP")
                        {
                            rg = new RaporGrup(x.GetAttribute("YETKI"), x.GetAttribute("GRUPNO"), x.GetAttribute("YETKIKONTROLUYAPMA"), x.GetAttribute("EKBILGI"));
                        }
                        else if (x.Name.ToUpper() == "KISTAS")
                        {
                            ke = new KistasEkran(x.GetAttribute("EKBILGI"));
                        }
                        else if (x.Name.ToUpper() == "KISTASALAN")
                        {
                            if (ke != null)
                                ke.Add(new KistasEkranAlan(x.GetAttribute("DEGISKEN"), x.GetAttribute("DEGISKENAD"), x.GetAttribute("TIP"), x.GetAttribute("LISTE"), x.GetAttribute("GIZLI"), x.GetAttribute("ILKDEGER"), x.GetAttribute("ZORUNLU"), x.GetAttribute("EKBILGI"), x.GetAttribute("GOSTERILECEKRAPOR")));
                            else
                                throw new RaporException(str19);
                        }
                        else if (x.Name.ToUpper() == "RAPOR")
                        {
                            if (rg != null)
                                rg.Add(new Rapor(x.GetAttribute("NO"), x.GetAttribute("YETKI"), x.GetAttribute("RAPORTIP"), x.GetAttribute("SABLON"), x.GetAttribute("DLL"), x.GetAttribute("NESNE"), x.GetAttribute("BOLUMNO"), x.GetAttribute("EKBILGI"), x.GetAttribute("RAPORCIKTITUR")));
                            else
                                throw new RaporException(str20);
                        }
                        else if (x.Name.ToUpper() == "RAPORBOLUM")
                        {
                            if (rg != null)
                                rg.BolumEkle(new RaporBolum(x.GetAttribute("NO"), x.GetAttribute("EKBILGI")));
                            else
                                throw new RaporException(str21);
                        }
                    }
                    else if (x.NodeType == System.Xml.XmlNodeType.EndElement)
                    {
                        if (x.Name.ToUpper() == "RAPORGRUP")
                        {
                            if (rg != null)
                            {
                                raporlar.Add(rg);
                                rg = null;
                            }
                            else
                                throw new RaporException(str22);
                        }
                        else if (x.Name.ToUpper() == "KISTAS")
                        {
                            if (rg != null)
                            {
                                rg.KistasEkranAta(ke);
                                ke = null;
                            }
                            else
                                throw new RaporException(str23);
                        }
                        else if (x.Name.ToUpper() == "RAPORLAR")
                        {
                            devam = false;
                        }
                    }
                }
            }
            catch (RaporException e)
            {
                raporlar.hata = e.Message;
            }
            catch (Exception e)
            {
                raporlar.hata = e.ToString();
            }
            if (x != null)
                x.Close();
            if (devam)
                raporlar.hata = str24;
        }

        private static RaporGrupListesi raporGrupListesi;

        static RaporlamaServis()
        {
            raporGrupListesi = new RaporGrupListesi();
            RaporlariOku("RaporlarDosyaAd", raporGrupListesi);
        }

        public static RaporGrupListesi RaporListesiAl()
        {
            return raporGrupListesi;
        }

        public static RaporGrupListesi RaporListesiYenile()
        {
            raporGrupListesi = new RaporGrupListesi();
            RaporlariOku("RaporlarDosyaAd", raporGrupListesi);
            return raporGrupListesi;
        }
    }
}
