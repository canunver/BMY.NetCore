﻿#if !MU
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Security.Permissions;
using OrtakClass;

namespace TNS.WebControls
{
    //[TypeConverter(typeof(ExpandableObjectConverter))]
    public class TNSTabParca
    {

        private bool tusYenileGorunur = false;
        public bool TusYenileGorunur
        {
            get { if (dinamikMi && tusYenileGorunur) return true; else return false; }
            set { tusYenileGorunur = value; }
        }

        private bool tusKapatGorunur = false;
        public bool TusKapatGorunur
        {
            get { return tusKapatGorunur; }
            set { tusKapatGorunur = value; }
        }

        private bool dinamikMi = false;
        public bool DinamikMi
        {
            get { return dinamikMi; }
            set { dinamikMi = value; }
        }

        private string paramEvalString = string.Empty;
        public string ParamEvalString
        {
            get { return paramEvalString; }
            set { paramEvalString = value; }
        }

        private string icerikYuklemeAdresi = string.Empty;
        public string IcerikYuklemeAdresi
        {
            get { return icerikYuklemeAdresi; }
            set { icerikYuklemeAdresi = value; }
        }

        private string m_OnSecParam = string.Empty;
        public string OnSecParam
        {
            get { return m_OnSecParam; }
            set { m_OnSecParam = value; }
        }

        private string m_OnSecEvent = string.Empty;
        public string OnSecEvent
        {
            get { return m_OnSecEvent; }
            set { m_OnSecEvent = value; }
        }

        private string m_IlgiliDivID = string.Empty;
        public string IlgiliDivID
        {
            get { return m_IlgiliDivID; }
            set { m_IlgiliDivID = value; }
        }

        private string m_Baslik = string.Empty;
        public string Baslik
        {
            get { return m_Baslik; }
            set { m_Baslik = value; }
        }

        private bool m_Engelli = false;
        public bool Engelli
        {
            get { return m_Engelli; }
            set { m_Engelli = value; }
        }

        private bool m_Gizli = false;
        public bool Gizli
        {
            get { return m_Gizli; }
            set { m_Gizli = value; }
        }

        public void RenderContents(TNSTab tab, int siraNo, HtmlTextWriter output, bool secili)
        {
            string classStr;
            string olay = string.Empty;
            string olayYenile = string.Empty;
            string olayKapat = string.Empty;

            bool pasif = false;

            if (secili)
            {
                pasif = false;
            }
            else
            {
                pasif = true;
            }

            if (!Engelli)
            {
                olay = "onclick='js_" + tab.Ad + ".TabSec(" + siraNo.ToString() + ");" + "'";
                olayYenile = "onclick='js_" + tab.Ad + ".TabSecResim(" + siraNo.ToString() + ");" + "'";
            }
            olayKapat = "onclick='js_" + tab.Ad + ".TabGizle(" + siraNo.ToString() + ");" + "'";


            string sagsonek;
            if (pasif)
            {
                classStr = "tab_pasif";
                sagsonek = "p";
            }
            else
            {
                classStr = "tab_aktif";
                sagsonek = "a";
            }

            sagsonek += tab.SonrakiTabItemSagEkBul(siraNo);

            string displayStr = "";
            //if (Gizli)
            //    displayStr = "display:none;";


            output.Write("<div"
                + GenelIslemler.TirnakliParam(false, true, "id", tab.Ad + siraNo + "_C")
                + GenelIslemler.TirnakliParam(false, true, "class", classStr)
                + GenelIslemler.TirnakliParam(false, true, "style", displayStr + "")
                + ">");

            if (Engelli)
                displayStr = "color:Gray;";

            output.Write("<div"
                + GenelIslemler.TirnakliParam(false, true, "id", tab.Ad + siraNo + "_I")
                + GenelIslemler.TirnakliParam(false, true, "class", classStr)
                + GenelIslemler.TirnakliParam(false, true, "style", "padding: 0px 10px 3px 10px;" + displayStr)
                + " " + olay
                + ">" + Baslik + "</div>");

            if (TusKapatGorunur || TusYenileGorunur)
            {
                output.Write("<div"
                + GenelIslemler.TirnakliParam(false, true, "id", tab.Ad + siraNo + "_R")
                + GenelIslemler.TirnakliParam(false, true, "class", classStr)
                + GenelIslemler.TirnakliParam(false, true, "style", "min-width:0px;width:9px;")
                    + ">");
                if (TusKapatGorunur)
                {
                    output.Write("<img"
                        + GenelIslemler.TirnakliParam(false, true, "src", "../App_Themes/Images/TNSTab_Tus_kapat.png")
                        + GenelIslemler.TirnakliParam(false, true, "class", "tab_ic_tus")
                        + " " + olayKapat + "/>");
                }
                if (TusYenileGorunur)
                {
                    output.Write("<img"
                        + GenelIslemler.TirnakliParam(false, true, "src", "../App_Themes/Images/TNSTab_Tus_yenile.png")
                        + GenelIslemler.TirnakliParam(false, true, "class", "tab_ic_tus")
                        + GenelIslemler.TirnakliParam(false, true, "style", "top:14px;")
                        + " " + olayYenile + "/>");
                }
                output.Write("</div>");
            }

            output.Write("<div"
                + GenelIslemler.TirnakliParam(false, true, "id", tab.Ad + siraNo + "_S")
                + GenelIslemler.TirnakliParam(false, true, "class", "tab_sag_" + sagsonek)
                + "></div>");
            output.WriteLine("</div>");

            GenelIslemler.DivisionGizleGoster(tab.Page, IlgiliDivID, secili);
        }

        internal string ParcaEkleParam(string metotAd)
        {
            return metotAd + "(" +
               GenelIslemler.Tirnakla(IlgiliDivID, 1, true) +
               GenelIslemler.Tirnakla(Engelli.ToString().ToLower(), 3, true) +
               GenelIslemler.Tirnakla(Gizli.ToString().ToLower(), 3, true) +
               GenelIslemler.Tirnakla(OnSecEvent, 1, true) +
               GenelIslemler.Tirnakla(OnSecParam, 1, true) +
               GenelIslemler.Tirnakla(DinamikMi.ToString().ToLower(), 3, true) +
               GenelIslemler.Tirnakla(icerikYuklemeAdresi, 1, true) +
               GenelIslemler.Tirnakla(paramEvalString, 1, true) +
               GenelIslemler.Tirnakla(this.TusKapatGorunur.ToString().ToLower(), 3, false) +
               ");";
        }

        internal string DinamikDivIc(int tabTur)
        {
            string htmlCode = "";
            if (DinamikMi)
            {
                htmlCode = "<div id='" + IlgiliDivID + "'>";
                if (tabTur == 1)
                    htmlCode += "<iframe id='" + IlgiliDivID + "_ifrm" + "' src='' style='width:100%;height:100%;background-color:transparent;' scrolling='auto' frameborder='0' allowtransparency='true' name='" + IlgiliDivID + "_ifrm" + "'></iframe>";
                htmlCode += "</div>";
            }
            return htmlCode;
        }
    }

    public class TNSTabParcaListesi : CollectionBase
    {
        // Gets and sets validator at the specified position
        public TNSTabParca this[int index]
        {
            get { return (TNSTabParca)InnerList[index]; }
            set { InnerList[index] = value; }
        }

        public void Add(TNSTabParca parca)
        {
            InnerList.Add(parca);
        }

        public void AddAt(int index, TNSTabParca parca)
        {
            InnerList.Insert(index, parca);
        }
    }

    [ParseChildren(true, "TABParcalar"),
    ToolboxData("<{0}:TNSTab runat=server></{0}:TNSTab>"),
    AspNetHostingPermission(SecurityAction.Demand,
        Level = AspNetHostingPermissionLevel.Minimal),
    AspNetHostingPermission(SecurityAction.InheritanceDemand,
        Level = AspNetHostingPermissionLevel.Minimal),
    ]
    public class TNSTab : WebControl, INamingContainer, IPostBackEventHandler
    {
        private string m_Ad;
        private TNSTabParcaListesi m_TABParcalar;
        private HiddenField hf = null;
        private HiddenField hfGizli = null;
        private int tabTur = 1; // 1 ise IFrame

        public TNSTab()
        {
            m_Ad = string.Empty;
            m_TABParcalar = new TNSTabParcaListesi();
        }

        private bool menuVisible = false;
        public bool MenuVisible
        {
            get { return menuVisible; }
            set { menuVisible = value; }
        }


        private string dinamikContainerDivID;
        public string DinamikContainerDivID
        {
            get { return dinamikContainerDivID; }
            set { dinamikContainerDivID = value; }
        }

        public int Secili
        {
            get
            {
                if (hf != null)
                    return OrtakFonksiyonlar.ConvertToInt(hf.Value, 0);
                else
                    return 0;
            }

            set
            {
                if (hf == null)
                    CreateChildControls();
                if (hf != null)
                    hf.Value = value.ToString();
            }
        }

        private string cssAd = "TNSTab";
        [DefaultValue("TNSTab")]
        public string CSSAd
        {
            get { return cssAd; }
            set { cssAd = value; }
        }

        public string Ad
        {
            get { return m_Ad; }
            set { m_Ad = value; }
        }

        public TNSTabParcaListesi TABParcalar
        {
            get { return m_TABParcalar; }
        }

        protected override void CreateChildControls()
        {
            if (hf == null)
            {
                hf = new HiddenField();
                hf.ID = "hdnFld";
                Controls.Add(hf);
            }
            if (hfGizli == null)
            {
                hfGizli = new HiddenField();
                hfGizli.ID = "hdnGizli";
                hfGizli.Load += new System.EventHandler(this.OnhfGizliLoad);
                Controls.Add(hfGizli);
            }
            base.CreateChildControls();
        }

        protected void OnhfGizliLoad(object o, EventArgs e)
        {
            if (this.Page.IsPostBack)
                VisibleAyarla();
        }

        protected override void OnLoad(EventArgs e)
        {
            System.Web.UI.ClientScriptManager csm;
            try
            {
                csm = this.Page.ClientScript;
                csm.RegisterClientScriptInclude("TNSTab", "../script/TNSTab.js?mc=03022015");
            }
            catch { }

            try
            {
                System.Web.UI.HtmlControls.HtmlHead h = this.Page.Header;
                System.Web.UI.HtmlControls.HtmlLink hl = new System.Web.UI.HtmlControls.HtmlLink();
                hl.Href = "../App_themes/" + CSSAd + ".css";
                hl.Attributes["type"] = "text/css";
                hl.Attributes["rel"] = "stylesheet";
                h.Controls.Add(hl);
            }
            catch { }
            base.OnLoad(e);
            //VisibleAyarla();
        }

        private void VisibleAyarla()
        {
            EnsureChildControls();
            if (hfGizli != null)
            {
                string[] gizliler = hfGizli.Value.Split(';');
                for (int i = 0; i < TABParcalar.Count; i++)
                {
                    TABParcalar[i].Gizli = false;
                }
                for (int i = 0; i < gizliler.Length; i++)
                {
                    if (!string.IsNullOrEmpty(gizliler[i]))
                    {
                        int yer = OrtakFonksiyonlar.ConvertToInt(gizliler[i], -1);
                        if (yer >= 0 && yer < TABParcalar.Count)
                            TABParcalar[yer].Gizli = true;
                    }
                }
            }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            if (Visible)
            {
                writer.WriteLine();
                string stlWidth = "";
                if (!Width.IsEmpty)
                    stlWidth = "width:" + Width.ToString() + ";";

                writer.WriteLine("<div" + GenelIslemler.TirnakliParam(false, true, "id", "tab" + Ad)
                    + GenelIslemler.TirnakliParam(false, true, "class", "tnstab")
                    + GenelIslemler.TirnakliParam(false, true, "style", stlWidth)
                    + ">");

                if (MenuVisible)
                    TabListeMenuTusYaz(writer);
                SolaKaydirTusYaz(writer);
                string maxWidth = "90%";
                if (!Width.IsEmpty)
                {
                    if (Width.Type == UnitType.Percentage)
                    {
                        if (Width.Value < 30)
                            maxWidth = "70%";
                        else if (Width.Value < 60)
                            maxWidth = "80%";
                    }
                    else if (Width.Type == UnitType.Pixel)
                    {
                        maxWidth = (Width.Value - 40) + "px";
                    }
                }
                writer.WriteLine("<div" + GenelIslemler.TirnakliParam(false, true, "id", "tab" + Ad + "Ic")
                    + GenelIslemler.TirnakliParam(false, true, "class", "tnstab")
                    + GenelIslemler.TirnakliParam(false, true, "style", "max-width:" + maxWidth + ";float:left;overflow:hidden;")
                    + ">");
                writer.WriteLine("<div" + GenelIslemler.TirnakliParam(false, true, "id", "tab" + Ad + "EnIc")
                    + GenelIslemler.TirnakliParam(false, true, "style", "position:relative;left:0px;top:0px;width:10000px;")
                    + ">");
            }
        }

        private void SagaKaydirTusYaz(HtmlTextWriter writer)
        {
            writer.WriteLine("<img"
                + GenelIslemler.TirnakliParam(false, true, "id", "tab" + Ad + "TusSag")
                + GenelIslemler.TirnakliParam(false, true, "src", "../App_themes/Images/" + cssAd + "_SagaKaydir.png")
                + GenelIslemler.TirnakliParam(false, true, "class", "tab_tus")
                + GenelIslemler.TirnakliParam(false, true, "style", "float:none;")
                + GenelIslemler.TirnakliParam(false, true, "onclick", "js_" + Ad + ".TabKaydir(1);")
                + "/>");
        }

        private void SolaKaydirTusYaz(HtmlTextWriter writer)
        {
            writer.WriteLine("<img"
                + GenelIslemler.TirnakliParam(false, true, "id", "tab" + Ad + "TusSol")
                + GenelIslemler.TirnakliParam(false, true, "src", "../App_themes/Images/" + cssAd + "_SolaKaydir.png")
                + GenelIslemler.TirnakliParam(false, true, "class", "tab_tus")
                + GenelIslemler.TirnakliParam(false, true, "onclick", "js_" + Ad + ".TabKaydir(0);")
                + "/>");
        }

        private void TabListeMenuTusYaz(HtmlTextWriter writer)
        {
            writer.WriteLine("<img"
                + GenelIslemler.TirnakliParam(false, true, "id", "tab" + Ad + "TusMenu")
                + GenelIslemler.TirnakliParam(false, true, "src", "../App_themes/Images/" + cssAd + "_MenuGoster.png")
                + GenelIslemler.TirnakliParam(false, true, "class", "tab_tus")
                + GenelIslemler.TirnakliParam(false, true, "onclick", "js_" + Ad + ".TabMenuGoster();")
                + GenelIslemler.TirnakliParam(false, true, "alt", "Sayfa seçeneklerini değiştirmek için tıklayınız..")
                + "/>");
        }

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            if (Visible)
            {
                writer.WriteLine("</div>");
                writer.WriteLine("</div>");
                SagaKaydirTusYaz(writer);
                writer.WriteLine("</div>");
            }
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            try
            {
                if (Visible)
                {
                    base.RenderContents(output);
                    string dinamikDivIc = "";

                    string sonEk = "p";
                    if (IlkGorunenSeciliMi(Secili)) sonEk = "a";
                    output.WriteLine("<div id='" + Ad + "_SOL' class='tab_sol_" + sonEk + "'></div>");


                    for (int i = 0; i < TABParcalar.Count; i++)
                    {
                        TABParcalar[i].RenderContents(this, i, output, i == Secili);
                        dinamikDivIc += TABParcalar[i].DinamikDivIc(tabTur);
                    }

                    if (!string.IsNullOrEmpty(dinamikDivIc))
                    {
                        object div = this.Page.FindControl(DinamikContainerDivID);
                        if (div != null && div.GetType() == typeof(System.Web.UI.HtmlControls.HtmlGenericControl))
                        {
                            System.Web.UI.HtmlControls.HtmlGenericControl gen = (System.Web.UI.HtmlControls.HtmlGenericControl)div;
                            gen.InnerHtml = dinamikDivIc;
                            gen.Style["display"] = "none";
                        }
                    }
                    StringBuilder sb = new StringBuilder();
                    string eventAd = "";
                    if (this.Click != null)
                        eventAd = Page.ClientScript.GetPostBackEventReference(this, string.Empty);
                    sb.AppendLine("   var js_" + Ad + " = new TnsTab(" + GenelIslemler.Tirnakla(Ad, 1, true) + GenelIslemler.Tirnakla(hf.ClientID, 1, true) + GenelIslemler.Tirnakla(hfGizli.ClientID, 1, true) + GenelIslemler.Tirnakla(tabTur.ToString(), 2, true) + GenelIslemler.Tirnakla(dinamikContainerDivID, 1, true) + GenelIslemler.Tirnakla(eventAd, 2, false) + ");");
                    for (int i = 0; i < TABParcalar.Count; i++)
                    {
                        sb.AppendLine(TABParcalar[i].ParcaEkleParam("   js_" + Ad + ".ParcaEkle")); ;
                    }
                    sb.AppendLine("   js_" + Ad + ".TabSecGiris(" + Secili + ");");
                    System.Web.UI.ClientScriptManager csm;
                    try
                    {
                        csm = this.Page.ClientScript;
                        csm.RegisterStartupScript(this.GetType(), "js_" + Ad, sb.ToString(), true);
                    }
                    catch { }
                }
            }
            catch (Exception ex)
            {
                output.Write(ex.StackTrace);
            }
        }

        private bool IlkGorunenSeciliMi(int Secili)
        {
            for (int i = 0; i < TABParcalar.Count; i++)
            {
                if (!TABParcalar[i].Gizli)
                {
                    if (i == Secili)
                        return true;
                    else
                        return false;
                }
            }
            return false;
        }

        internal string SonrakiTabItemSagEkBul(int siraNo)
        {
            for (int i = siraNo + 1; i < TABParcalar.Count; i++)
            {
                if (!TABParcalar[i].Gizli)
                {
                    if (i == Secili)
                        return "a";
                    else
                        return "p";
                }
            }
            return "";
        }

        #region IPostBackEventHandler Members
        public event EventHandler Click;
        public void RaisePostBackEvent(string eventArgument)
        {
            Click(this, EventArgs.Empty);
        }

        #endregion

    }
}
#endif