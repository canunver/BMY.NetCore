﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using static StrPoint.Web.Spread.StrSpread;
using TNS;
using System.Linq;

namespace StrPoint.Web.Spread
{
    public static class StrGrid
    {
        private const string AgBase = "../App_themes/AGGrid";

        public static void Init(Page page)
        {
            if (page == null) return;
            const string flag = "__StrGridInit";
            if (page.Items[flag] != null) return;

            // 1) JS
            AddScriptToHead(page, "ag-grid-core-js", AgBase + "/ag-grid-community.min.js");

            // 2) CSS
            AddCssToHead(page, "ag-grid-core-css", AgBase + "/ag-grid.min.css");
            AddCssToHead(page, "ag-grid-balham-css", AgBase + "/ag-theme-balham.min.css");

            page.Items[flag] = true;

            // --- helpers ---
            void AddCssToHead(Page p, string id, string href)
            {
                if (p.Header == null) return;
                if (p.Header.FindControl(id) != null) return;
                var link = new HtmlLink { ID = id, Href = href };
                link.Attributes["rel"] = "stylesheet";
                p.Header.Controls.Add(link);
            }

            void AddScriptToHead(Page p, string id, string src)
            {
                if (p.Header != null && p.Header.FindControl(id) == null)
                {
                    var script = new HtmlGenericControl("script");
                    script.ID = id;
                    script.Attributes["type"] = "text/javascript";
                    script.Attributes["src"] = src;
                    p.Header.Controls.Add(script);
                    return;
                }
                if (!p.ClientScript.IsClientScriptIncludeRegistered(id))
                    p.ClientScript.RegisterClientScriptInclude(id, src);
            }
        }
    }

    public enum TextAlign { Left, Center, Right }

    [DefaultProperty("ID")]
    [ToolboxData("<{0}:StrSpread runat=\"server\" Width=\"100%\" Height=\"300\"></{0}:StrSpread>")]
    public class StrSpread : WebControl, IPostBackDataHandler
    {
        // StrSpread sınıfının içine (diğer alanların yanına)
        private readonly PlaceHolder _toolbar = new PlaceHolder();

        /// <summary>Toolbar’a özel css class (varsayılan: strgrid-toolbar)</summary>
        public int ToolbarHeight { get; set; } = 40; // px
        public string ToolbarCssClass { get; set; } = "strgrid-toolbar";

        /// <summary>Toolbar boşsa render edilmesin (zorunlu: true davranışı)</summary>
        public bool SuppressEmptyToolbar { get; set; } = true;

        /// <summary>Toolbar’da herhangi bir denetim var mı?</summary>
        public bool HasToolbar => _toolbar.HasControls();

        public string OnClientCellChanged { get; set; } = null;

        // İstediğin herhangi bir server control ekle
        public void ToolbarAdd(Control ctrl)
        {
            if (ctrl == null) return;
            _toolbar.Controls.Add(ctrl);
        }

        public void ToolbarClear()
        {
            _toolbar.Controls.Clear();
        }
        // Pratik buton ekleyici (client-side click destekli)
        public void ToolbarAddButton(string text, string onClientClick = null, string cssClass = null)
        {
            var btn = new Button
            {
                Text = text ?? "Button",
                UseSubmitBehavior = false,
                CausesValidation = false
            };
            if (!string.IsNullOrWhiteSpace(cssClass))
                btn.CssClass = cssClass;

            if (!string.IsNullOrWhiteSpace(onClientClick))
                btn.OnClientClick = onClientClick;

            _toolbar.Controls.Add(btn);
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            // Toolbar’ı çocuklar arasına dahil edelim ki ViewState vs. korunsun
            if (!_toolbar.Parent?.Equals(this) ?? true)
                Controls.Add(_toolbar);
        }

        private readonly SortedList<int, object[]> _rows = new SortedList<int, object[]>();

        public bool RowNumbers { get; set; } = true;
        public int RowNumbersWidth { get; set; } = 40;
        public bool RenderCSSClass { get; set; } = true;
        public bool EditModeReplace { get; set; } = true;
        public bool EnableViewStateOnGrid { get; set; } = true;
        public string AgThemeCssClass { get; set; } = "ag-theme-balham";

        public ColumnHeaderView ColumnHeader { get; } = new ColumnHeaderView();
        public ColumnsView Columns { get; } = new ColumnsView();
        public RowsView Rows { get; }
        public CellIndex Cells { get; }

        public StrSpread()
        {
            Rows = new RowsView(this);
            Cells = new CellIndex(this);
        }

        public int RowCount
        {
            get => _rows.Count;
            set
            {
                while (_rows.Count < value)
                    _rows[_rows.Count] = new object[Math.Max(1, ColumnCount)];
                while (_rows.Count > value)
                    _rows.RemoveAt(_rows.Count - 1);
            }
        }

        private int ColumnCount => Math.Max(ColumnHeader.ColumnCount, Columns.Count);

        private void EnsureCell(int row, int col)
        {
            while (_rows.Count <= row)
                _rows[_rows.Count] = new object[Math.Max(1, ColumnCount)];
            var arr = _rows[row];
            if (arr.Length <= col)
            {
                var n = new object[col + 1];
                Array.Copy(arr, n, arr.Length);
                _rows[row] = n;
            }
            if (Columns.Count <= col) _ = Columns[col];
        }

        internal object GetCellValue(int r, int c) { EnsureCell(r, c); return _rows[r][c]; }
        internal void SetCellValue(int r, int c, object val) { EnsureCell(r, c); _rows[r][c] = val; }

        // --- Postback ---
        private string HiddenField => ClientID + "_data";

        public bool AllowPage { get; set; } = false;
        public int RowHeaderWidth { get; set; } = 25;
        public RowHeaderView RowHeader { get; } = new RowHeaderView();

        public bool LoadPostData(string postDataKey, System.Collections.Specialized.NameValueCollection postCollection)
        {
            var json = postCollection[postDataKey];
            if (string.IsNullOrEmpty(json)) return false;
            try
            {
                var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var list = ser.Deserialize<List<Dictionary<string, object>>>(json);
                _rows.Clear();
                for (int i = 0; i < list.Count; i++)
                {
                    var arr = new object[Math.Max(1, ColumnCount)];
                    for (int c = 0; c < arr.Length; c++)
                        list[i].TryGetValue("c" + c, out arr[c]);
                    _rows[i] = arr;
                }
            }
            catch { }
            return false;
        }

        // --- Render ---
        protected override void RenderContents(HtmlTextWriter w)
        {
            var formId = Page?.Form?.ClientID ?? "form";

            var hostId = this.ClientID + "_host";
            var gridPane = this.ClientID + "_gridpane";
            var gridId = this.ClientID + "_grid";      // AG-Grid buraya mount olur

            // --- HOST: Width/Height KONTROL’den gelir ---
            w.AddAttribute(HtmlTextWriterAttribute.Id, hostId);
            w.AddAttribute(HtmlTextWriterAttribute.Class, "strgrid-host");
            if (!Width.IsEmpty) w.AddStyleAttribute("width", Width.ToString());
            if (!Height.IsEmpty) w.AddStyleAttribute("height", Height.ToString());
            else w.AddStyleAttribute("height", "300px"); // varsayılan
            w.RenderBeginTag(HtmlTextWriterTag.Div); // <div id="..._host" class="strgrid-host">

            // --- GRID PANE: kalan tüm alan ---
            w.AddAttribute(HtmlTextWriterAttribute.Id, gridPane);
            w.AddAttribute(HtmlTextWriterAttribute.Class, "strgrid-gridpane " + AgThemeCssClass);
            w.RenderBeginTag(HtmlTextWriterTag.Div); // <div id="..._gridpane" class="...">

            // AG-Grid container (pane’i %100 doldurur)
            w.AddAttribute(HtmlTextWriterAttribute.Id, gridId);
            w.AddAttribute(HtmlTextWriterAttribute.Class, "strgrid-grid " + AgThemeCssClass);
            w.RenderBeginTag(HtmlTextWriterTag.Div); // <div id="..._grid" class="..."></div>
            w.RenderEndTag();

            // Hidden (postback)
            w.AddAttribute("type", "hidden");
            w.AddAttribute("id", HiddenField);
            w.AddAttribute("name", this.UniqueID);
            w.RenderBeginTag(HtmlTextWriterTag.Input);
            w.RenderEndTag();

            // JS: AG-Grid’i tekil gridId’ye mount et
            var gridVar = gridId + "Options";
            var apiVar = gridId + "Api";
            string cols = BuildColumnDefsJson();
            string rows = BuildRowDataJson();
            var onCellChanged = string.IsNullOrWhiteSpace(OnClientCellChanged) ? "" : $@"onCellValueChanged: function(params){{
                {OnClientCellChanged}(params);
            }},";


            w.Write($@"
<script>
(function(){{
  var gridDivId = '{gridId}';
  var formId    = '{formId}';
  var hiddenId  = '{HiddenField}';
  var mainId    = '{ClientID}';
  function createGridWhenReady(){{
    if (!window.agGrid || !agGrid.Grid) {{ setTimeout(createGridWhenReady, 25); return; }}
    var gridDiv = document.getElementById(gridDivId);
    if(!gridDiv) return;

    window['{gridVar}'] = {{
      columnDefs: {cols},
      rowData: {rows},
      {onCellChanged}
    
      defaultColDef: {{ editable:true, resizable:true,  wrapHeaderText: true, autoHeaderHeight: true}},
      suppressSizeToFit: true,
      rowSelection: 'single',
      animateRows: true,
      rowNumbers: {(this.RowNumbers ? "true" : "false")},
      rowNumbersWidth: {(this.RowNumbersWidth > 0 ? this.RowNumbersWidth : 30)},
      components: {{datePickerEditor: StrGrid.DatePickerEditor}},
      localeText: AGTurkceAyar,
      onGridReady: function(params){{
        window['{apiVar}'] = params.api;
         
        var gridDiv = document.getElementById(gridDivId);
        if(!gridDiv) return;

        gridDiv.setAttribute(""tabindex"",""0"");

        if(gridDiv.__clipInstalled) return;
        gridDiv.__clipInstalled = true;

        gridDiv.addEventListener(""keydown"", async function(e){{
           if(!(e.ctrlKey || e.metaKey)) return;
           if(e.key === ""c""){{
              e.preventDefault();
              await StrGrid.copyAll(params.api);
           }}
           if(e.key === ""v""){{
              e.preventDefault();
              await StrGrid.pasteAllFromClipboard(params.api);
           }}
        }}, true);

        // === FarPoint uyumlu API ===
        var host = document.getElementById(mainId);
        if (host) {{
          host.GetActiveRow = function() {{
            var node = params.api.getSelectedNodes()[0];
            return node ? node.rowIndex : -1;
          }};
          host.GetValue = function(r, c) {{
            var row = params.api.getDisplayedRowAtIndex(r);
            return row && row.data ? row.data['c' + c] : null;
          }};

          host.GetRowCount = function() {{
            return params.api.getDisplayedRowCount();
          }};

        }}

        StrGrid.attachSubmit(formId, hiddenId, function(){{
          var out = [];
          params.api.stopEditing();
          params.api.forEachNode(function(n){{ out.push(n.data); }});
          var h = document.getElementById(hiddenId);
          if(h) h.value = JSON.stringify(out);
        }});
      }}
    }};
    new agGrid.Grid(gridDiv, window['{gridVar}']);
  }}

  if (document.readyState === 'loading')
    document.addEventListener('DOMContentLoaded', createGridWhenReady);
  else
    createGridWhenReady();
}})();
</script>");

            w.RenderEndTag(); // </div> gridpane

            // --- TOOLBAR PANE: sadece doluysa render ---
            if (_toolbar.HasControls())
            {
                w.AddAttribute(HtmlTextWriterAttribute.Class, "strgrid-toolbarpane " + AgThemeCssClass);
                // Sabit 40px (özellikten)
                w.AddStyleAttribute("height", (ToolbarHeight > 0 ? ToolbarHeight : 40) + "px");
                w.AddStyleAttribute("flex", $"0 0 {(ToolbarHeight > 0 ? ToolbarHeight : 40)}px");
                w.RenderBeginTag(HtmlTextWriterTag.Div); // <div class="strgrid-toolbarpane ...">
                _toolbar.RenderControl(w);
                w.RenderEndTag();
            }

            w.RenderEndTag(); // </div> host
        }

        private string BuildColumnDefsJson()
        {
            int n = ColumnCount > 0 ? ColumnCount : 1;
            var sb = new StringBuilder("[");
            int outColIndex = 0;

            // RowNumbers kolonu (AG Grid header ile birlikte boş başlık)
            if (RowNumbers)
            {
                if (outColIndex++ > 0) sb.Append(",");
                sb.Append("{\"colId\":\"__rownum\"")
                  .AppendFormat(",\"width\":{0}", RowNumbersWidth)
                  .Append(",\"minWidth\":24,\"pinned\":\"left\",\"lockPinned\":true")
                  .Append(",\"resizable\":false,\"sortable\":false,\"filter\":false")
                  .Append(",\"suppressMenu\":true,\"suppressMovable\":true,\"suppressNavigable\":true")
                  .Append(",\"editable\":false")
                  .Append(",\"headerName\":\"\"")
                  .Append(",\"cellClass\":\"strgrid-rn-cell\"")
                  .Append(",\"valueGetter\":function(p){return (p&&p.node)?(p.node.rowIndex+1):'';}")
                  .Append("}");
            }

            for (int c = 0; c < n; c++)
            {
                if (outColIndex++ > 0) sb.Append(",");

                var col = Columns[c];
                int w = col.Width <= 0 ? 120 : col.Width;

                var props = new List<string>();
                var style = new Dictionary<string, string>();

                string headerText = ColumnHeader.GetHeader(c);

                props.Add($"\"field\":\"c{c}\"");
                props.Add($"\"colId\":\"c{c}\"");
                props.Add($"\"width\":{w}");
                props.Add($"\"headerName\":\"{Js(headerText)}\""); // ← başlık AG Grid header'ına
                props.Add("\"headerClass\":\"str-header-bottom\"");
                if (!col.Visible) props.Add("\"hide\":true");

                bool editable = col.Editable && !col.Locked;
                props.Add($"\"editable\":{editable.ToString().ToLowerInvariant()}");

                // HİZALAMA: AG Grid cellClass
                switch (col.Alignment)
                {
                    case TextAlign.Right:
                        props.Add("\"type\":\"numericColumn\"");
                        props.Add("\"cellClass\":\"ag-right-aligned-cell\"");
                        break;
                    case TextAlign.Center:
                        props.Add("\"cellClass\":\"ag-center-aligned-cell\"");
                        break;
                    default:
                        // Left: sınıf gerekmiyor
                        break;
                }

                // BackColor
                if (col.BackColor.HasValue)
                {
                    var html = System.Drawing.ColorTranslator.ToHtml(col.BackColor.Value);
                    style["backgroundColor"] = html;
                }

                // CellType özellikleri (editable/cellStyle yazmıyor)
                var ct = col.CellType?.ToAgGridJsProps();
                if (!string.IsNullOrWhiteSpace(ct))
                    props.Add(ct);

                sb.Append("{");
                sb.Append(string.Join(",", props));
                if (style.Count > 0)
                {
                    var stylePairs = style.Select(kv => $"\"{kv.Key}\":\"{kv.Value}\"");
                    sb.Append(",\"cellStyle\":{").Append(string.Join(",", stylePairs)).Append("}");
                }
                sb.Append("}");
            }

            sb.Append("]");
            return sb.ToString();
        }

        private string BuildRowDataJson()
        {
            var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var list = new List<Dictionary<string, object>>();
            foreach (var kv in _rows)
            {
                var dict = new Dictionary<string, object>();
                var arr = kv.Value ?? Array.Empty<object>();
                for (int c = 0; c < arr.Length; c++)
                    dict["c" + c] = arr[c];
                list.Add(dict);
            }
            return ser.Serialize(list);
        }

        private static string SerializeTag(object tag)
        {
            if (tag == null) return null;
            if (tag is string s) return "s:" + s; // saf string
            var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            try { return "j:" + ser.Serialize(tag); } // herhangi bir obje -> JSON
            catch { return "s:" + tag.ToString(); }
        }

        private static object DeserializeTag(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            if (s.StartsWith("s:")) return s.Substring(2);
            if (s.StartsWith("j:"))
            {
                var json = s.Substring(2);
                var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                // DeserializeObject => string, number, bool, Dictionary<string,object>, object[]
                return ser.DeserializeObject(json);
            }
            return s;
        }

        protected override object SaveViewState()
        {
            var baseState = base.SaveViewState();

            // Başlıklar (0. satır)
            var headers = new List<string>();
            for (int c = 0; c < ColumnHeader.ColumnCount; c++)
                headers.Add(ColumnHeader.GetHeader(c));

            // Genişlikler
            var widths = new List<int>();
            for (int c = 0; c < Columns.Count; c++)
                widths.Add(Columns[c].Width);

            var tags = new List<string>();
            for (int c = 0; c < Columns.Count; c++)
                tags.Add(SerializeTag(Columns[c].Tag));

            var simple = new object[]
            {   RowNumbers, RowNumbersWidth, RenderCSSClass, EditModeReplace, AgThemeCssClass };

            //                        0          1                2                 3      4
            return new object[] { baseState, headers.ToArray(), widths.ToArray(), simple, tags.ToArray() };
        }

        protected override void LoadViewState(object savedState)
        {
            if (savedState is object[] arr && arr.Length >= 4)
            {
                base.LoadViewState(arr[0]);

                var headers = (string[])arr[1];
                var widths = (int[])arr[2];
                var simple = (object[])arr[3];
                var tags = (arr.Length >= 5) ? (string[])arr[4] : null; // ✅ geriye dönük uyum

                // Başlıklar
                for (int i = 0; i < headers.Length; i++)
                    ColumnHeader.Cells[0, i].Value = headers[i];

                // Genişlikler
                for (int i = 0; i < widths.Length; i++)
                    Columns[i].Width = widths[i];

                // Basit alanlar
                RowNumbers = (bool)simple[0];
                RowNumbersWidth = (int)simple[1];
                RenderCSSClass = (bool)simple[2];
                EditModeReplace = (bool)simple[3];
                AgThemeCssClass = (string)simple[4];

                if (tags != null)
                {
                    // Kolon listesi yeterince büyüsün
                    for (int i = 0; i < tags.Length; i++)
                    {
                        Columns[i].Tag = DeserializeTag(tags[i]);
                    }
                }
            }
            else
            {
                base.LoadViewState(savedState);
            }
        }

        private static string Js(string s)
        {
            if (s == null) return "";
            return s
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r\n", "\\n")
                .Replace("\n", "\\n")
                .Replace("\r", "\\n");
        }
        public void Reset()
        {
            _rows.Clear();
            Columns.Clear();
            ColumnHeader.Clear();
            RowHeader.Rows.Clear();
        }

        public void Clear()
        {
            _rows.Clear();
        }

        public void RaisePostDataChangedEvent() { }

        // === Yardımcı sınıflar ===

        public class CellIndex
        {
            private readonly StrSpread _owner;
            public CellIndex(StrSpread owner) { _owner = owner; }
            public CellAccessor this[int row, int col] => new CellAccessor(_owner, row, col);
        }

        public class ColumnHeaderView
        {
            public sealed class HeaderCell
            {
                public string Value { get; set; } = "";
                public int ColumnSpan { get; set; } = 1;
                public int RowSpan { get; set; } = 1;
            }

            private readonly List<List<HeaderCell>> _rows = new List<List<HeaderCell>>();

            public ColumnHeaderView()
            {
                _rows.Add(new List<HeaderCell>()); // tek satır
                Cells = new CellIndex(this);
            }

            private int _rowCount = 1;
            public int RowCount
            {
                get => _rowCount;
                set
                {
                    if (value < 1) value = 1;
                    while (_rows.Count < value) _rows.Add(new List<HeaderCell>());
                    _rowCount = value;
                }
            }

            public int ColumnCount => _rows.Count == 0 ? 0 : _rows.Max(r => r.Count);

            public string GetHeader(int col)
            {
                var r0 = _rows[0];
                return (col >= 0 && col < r0.Count) ? (r0[col]?.Value ?? "") : "";
            }

            public CellIndex Cells { get; }

            private void EnsureCell(int row, int col)
            {
                if (row < 0 || col < 0) return;
                while (_rows.Count <= row) _rows.Add(new List<HeaderCell>());
                var r = _rows[row];
                while (r.Count <= col) r.Add(new HeaderCell());
                if (_rowCount < _rows.Count) _rowCount = _rows.Count;
            }

            internal HeaderCell GetCell(int row, int col)
            {
                EnsureCell(row, col);
                return _rows[row][col];
            }

            public class CellIndex
            {
                private readonly ColumnHeaderView _owner;
                public CellIndex(ColumnHeaderView owner) { _owner = owner; }
                public HeaderCellAccessor this[int row, int col] => new HeaderCellAccessor(_owner, row, col);
            }

            public sealed class HeaderCellAccessor
            {
                private readonly ColumnHeaderView _owner;
                private readonly int _row, _col;

                public HeaderCellAccessor(ColumnHeaderView owner, int row, int col)
                {
                    _owner = owner; _row = row; _col = col;
                    _owner.EnsureCell(row, col);
                }

                public object Value
                {
                    get => _owner.GetCell(_row, _col).Value;
                    set => _owner.GetCell(_row, _col).Value = value?.ToString() ?? "";
                }

                public int ColumnSpan { get => _owner.GetCell(_row, _col).ColumnSpan; set => _owner.GetCell(_row, _col).ColumnSpan = Math.Max(1, value); }
                public int RowSpan { get => _owner.GetCell(_row, _col).RowSpan; set => _owner.GetCell(_row, _col).RowSpan = Math.Max(1, value); }
            }

            public void Clear()
            {
                _rows.Clear();
                _rows.Add(new List<HeaderCell>());
                _rowCount = 1;
            }
        }

        public class ColumnsView
        {
            private readonly List<Column> _cols = new List<Column>();
            public Column this[int i] { get { while (_cols.Count <= i) _cols.Add(new Column()); return _cols[i]; } }
            public int Count => _cols.Count;

            public class Column
            {
                public object Tag { get; set; } = null;
                public int Width { get; set; } = 120;
                public bool Visible { get; set; } = true;
                public bool Locked { get; set; } = false;  // Locked -> editable=false
                public bool Editable { get; set; } = true;
                public TextAlign Alignment { get; set; } = TextAlign.Left;
                public System.Drawing.Color? BackColor { get; set; }
                public GeneralCellType CellType { get; set; }
            }

            public void Clear() => _cols.Clear();
        }

        public class RowsView { private readonly StrSpread _o; internal RowsView(StrSpread o) { _o = o; } public int Count => _o._rows.Count; }

        public class CellAccessor
        {
            private readonly StrSpread _o; private readonly int _r, _c;
            internal CellAccessor(StrSpread o, int r, int c) { _o = o; _r = r; _c = c; }
            public object Value { get => _o.GetCellValue(_r, _c); set => _o.SetCellValue(_r, _c, value); }
            public string Text { get => Convert.ToString(_o.GetCellValue(_r, _c)); set => _o.SetCellValue(_r, _c, value); }
        }

        public class RowHeaderView
        {
            public RowHeaderRows Rows { get; } = new RowHeaderRows();
            public void Clear() => Rows.Clear();
        }

        public class RowHeaderRows
        {
            private readonly RowHeaderRow _all = new RowHeaderRow();
            private readonly Dictionary<int, RowHeaderRow> _byIndex = new Dictionary<int, RowHeaderRow>();
            public RowHeaderRow this[int index] { get { if (index == -1) return _all; if (!_byIndex.TryGetValue(index, out var r)) { r = new RowHeaderRow(); _byIndex[index] = r; } return r; } }
            public void Clear() => _byIndex.Clear();
        }

        public class RowHeaderRow { public bool Resizable { get; set; } = true; }
    }

    [Serializable]
    public class GeneralCellType { public virtual string ToAgGridJsProps() => string.Empty; }

    [Serializable]
    public class MultiLineCellType : GeneralCellType
    {
        public int Rows { get; set; } = 6;
        public int Cols { get; set; } = 40;
        public int MaxLength { get; set; } = 4000;
        public bool AutoHeight { get; set; } = true;
        public bool Popup { get; set; } = true;

        public override string ToAgGridJsProps()
        {
            string editor;
            if (Popup)
                editor = "\"cellEditor\":\"agLargeTextCellEditor\"," +
    $"\"cellEditorPopup\":{Popup.ToString().ToLowerInvariant()}," +
    $"\"cellEditorParams\":{{\"rows\":{Rows},\"cols\":{Cols},\"maxLength\":{MaxLength}}},";
            else editor = "";


            return
                "\"editable\":true," +
                "\"wrapText\":true," +
                (AutoHeight ? "\"autoHeight\":true," : "") +
                editor +
                "\"cellStyle\":{\"whiteSpace\":\"normal\"}";
        }
    }

    [Serializable]
    public class NumericCellType : GeneralCellType
    {
        public NumericCellType() : this(2) { }
        public NumericCellType(int decimalDigits) { DecimalDigits = decimalDigits; }
        public int DecimalDigits { get; set; } = 2;
        public override string ToAgGridJsProps()
            => $"\"valueFormatter\":function(p){{return formatNumberTNS(p.value,{DecimalDigits});}}";
    }

    [Serializable]
    public class ComboBoxCellType : GeneralCellType
    {
        public string[] Items { get; set; }
        public string[] Values { get; set; }
        public ComboBoxCellType(string[] items, string[] values) { Items = items; Values = values; }

        public override string ToAgGridJsProps()
        {
            var items = Items ?? Array.Empty<string>();
            var values = Values ?? items;
            if (values.Length != items.Length)
            {
                var m = Math.Min(items.Length, values.Length);
                items = items.Take(m).ToArray();
                values = values.Take(m).ToArray();
            }
            string S(string s) => "\"" + (s ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
            string jsItems = "[" + string.Join(",", items.Select(S)) + "]";
            string mapV2T = "{" + string.Join(",", values.Select((v, i) => S(v) + ":" + S(items[i]))) + "}";
            string mapT2V = "{" + string.Join(",", items.Select((t, i) => S(t) + ":" + S(values[i]))) + "}";

            var sb = new StringBuilder();
            sb.Append("\"cellEditor\":\"agSelectCellEditor\"");
            sb.AppendFormat(",\"cellEditorParams\":{{\"values\":{0}}}", jsItems);
            sb.AppendFormat(",\"valueFormatter\":function(p){{var m={0};var v=p.value;return (v!=null&&m[v]!=null)?m[v]:v;}}", mapV2T);
            sb.AppendFormat(",\"valueParser\":function(p){{var m={0};var nv=p.newValue;return (nv!=null&&m[nv]!=null)?m[nv]:null;}}", mapT2V);
            sb.AppendFormat(",\"valueSetter\":function(p){{var m={0};var nv=p.newValue;var v=(nv!=null&&m[nv]!=null)?m[nv]:nv; p.data[p.colDef.field]=v; return true;}}", mapT2V);
            return sb.ToString();
        }
    }

    [Serializable]
    public class CheckBoxCellType : GeneralCellType
    {
        public static string CheckedValue { get; set; } = "true";
        public static string UncheckedValue { get; set; } = "false";
        public string TrueTooltip { get; set; }
        public string FalseTooltip { get; set; }
        public bool StopRowClick { get; set; } = true;

        public static int DegerAlInt(object value)
        {
            if (value == null) return 0;
            if (value.GetType() == typeof(int)) return (int)value;
            if (value.GetType() == typeof(bool))
            {
                return (bool)value ? 1 : 0;
            }
            if ((string)value == CheckedValue) return 1;
            return 0;
        }

        public static string DegerBul(int kazanan)
        {
            if (kazanan == 0) return UncheckedValue;
            return CheckedValue;
        }

        public override string ToAgGridJsProps()
        {
            string S(string s) => "\"" + (s ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
            var ttT = string.IsNullOrEmpty(TrueTooltip) ? "null" : S(TrueTooltip);
            var ttF = string.IsNullOrEmpty(FalseTooltip) ? "null" : S(FalseTooltip);

            var sb = new System.Text.StringBuilder();
            sb.Append(
                "\"cellRenderer\":function(p){"
              + "  var el=document.createElement('input');"
              + "  el.type='checkbox';"
              + "  el.className='strgrid-checkbox';"
              + "  var v=p.value;"
              + "  var isChecked=(v===1 ||v===true||v==='true' || v==='True');"
              + "  el.checked=isChecked;"

              + "  var ed=(p.colDef&&typeof p.colDef.editable!=='undefined')?"
              + "          (typeof p.colDef.editable==='function'? p.colDef.editable(p) : p.colDef.editable)"
              + "          : true;"
              + "  el.disabled = (ed===false);"
              + "  el.addEventListener('change',function(){"
              + "    var nv=el.checked?true:false;"
              + "    var fld=p.colDef&&p.colDef.field;"
              + "    console.log(fld);"
              + "    if(fld){ p.node.setDataValue(fld,nv); }"
              + "  });"
              + "  return el;"
              + "}"
            );
            sb.Append(
              ",\"valueParser\":function(p){"
            + "  var nv=p.newValue;"
            + "  if(nv===true||nv==='true'||nv===1) return true;"
            + "  return false;"
            + "}"
            );
            sb.Append(
              ",\"comparator\":function(a,b){"
            + "  var ta = (a===1||a===true||a==='true'||a==='True') ? 1 : 0;"
            + "  var tb = (b===1||b===true||b==='true'||b==='True') ? 1 : 0;"
            + "  return ta-tb;"
            + "}"
            );
            return sb.ToString();
        }
    }

    [Serializable]
    public class LinkButtonCellType : GeneralCellType
    {
        public string Text { get; set; }
        public string ImageUrl { get; set; }
        public string Tooltip { get; set; }
        public string OnClickJs { get; set; }
        public string ButtonCssClass { get; set; } = "str-small-btn";
        public bool UseAnchor { get; set; } = false;
        public bool StopRowClick { get; set; } = true;
        public string ConfirmText { get; set; }

        public override string ToAgGridJsProps()
        {
            string S(string s) => "\"" + (s ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";

            var jsText = string.IsNullOrEmpty(Text) ? "null" : S(Text);
            var jsImg = string.IsNullOrEmpty(ImageUrl) ? "null" : S(ImageUrl);
            var jsTitle = string.IsNullOrEmpty(Tooltip) ? "null" : S(Tooltip);
            var jsTpl = S(OnClickJs ?? string.Empty);
            var jsClass = S(ButtonCssClass ?? string.Empty);
            var tagName = UseAnchor ? "\"a\"" : "\"button\"";
            var confirmTx = string.IsNullOrEmpty(ConfirmText) ? "null" : S(ConfirmText);

            var editableJs = "true"; // Editable ? "true" : "false";
            //var align = "center"; // Alignment.ToString().ToLowerInvariant();

            var sb = new System.Text.StringBuilder();

            // Bu iki özellik cellRenderer'dan ÖNCE gelmeli ve aralarında virgül olmalı
            //sb.Append("\"editable\":").Append(editableJs).Append(",");
            //sb.Append("\"cellStyle\":{ \"textAlign\":\"").Append(align).Append("\" },");

            // Fonksiyonu açıyoruz: Bundan sonra gelen her şey fonksiyonun İÇİNDE olmalı
            sb.Append("\"cellRenderer\":function(p){");

            sb.Append("  var el=document.createElement(").Append(tagName).Append(");");
            sb.Append("  if(").Append(UseAnchor ? "true" : "false").Append("){ el.href='javascript:void(0)'; }");
            sb.Append("  el.className=").Append(jsClass).Append(";");
            sb.Append("  if(").Append(jsTitle).Append("){ el.title=").Append(jsTitle).Append("; }");
            sb.Append("  var configuredText=").Append(jsText).Append(";");
            sb.Append("  var cellText=(p.value==null?'':String(p.value));");
            sb.Append("  var displayText=configuredText||cellText||'Göster';");
            sb.Append("  var imgUrl=").Append(jsImg).Append(";");
            sb.Append("  if(imgUrl){ var im=document.createElement('img'); im.src=imgUrl; im.alt=displayText; im.style.borderWidth='0px'; el.appendChild(im); }");
            sb.Append("  else{ el.textContent=displayText; }");

            // Template doldurma ({value}, {c0}, {c1}...)
            sb.Append("  var tpl=").Append(jsTpl).Append(";");
            sb.Append("  function fmt(t){ if(!t) return ''; var s=String(t);");
            sb.Append("    s=s.replace(/\\{value\\}/g,(p.value==null?'':String(p.value)));");
            sb.Append("    s=s.replace(/\\{c(\\d+)\\}/g,function(_,i){ var k='c'+i; return (p.data&&p.data[k]!=null)? String(p.data[k]) : ''; });");
            sb.Append("    return s;");
            sb.Append("  }");

            // 🔒 Güvenli colId tespiti (p.column -> colId, yoksa p.colDef.colId/field)
            sb.Append("  var colId = (p && p.column && p.column.getColId ? p.column.getColId() : null) || ");
            sb.Append("               (p && p.colDef && (p.colDef.colId || p.colDef.field)) || null;");

            // Satırı/hücreyi aktive eden yordam
            sb.Append("  function activateCell(){");
            sb.Append("    var r = (typeof p.rowIndex==='number') ? p.rowIndex : (p.node ? p.node.rowIndex : null);");
            sb.Append("    if (r==null) return;");
            sb.Append("    if (p.api && p.api.ensureIndexVisible) p.api.ensureIndexVisible(r);");
            sb.Append("    if (p.api && p.api.ensureColumnVisible && colId) p.api.ensureColumnVisible(colId);");
            sb.Append("    if (p.node && p.node.setSelected) p.node.setSelected(true, true);"); // single-select
            sb.Append("    if (p.api && p.api.setFocusedCell && colId) p.api.setFocusedCell(r, colId);");
            sb.Append("  }");

            // Click: (opsiyonel) satır tıklamasını kes, aktive et, sonra OnClickJs'i çalıştır
            sb.Append("  el.addEventListener('click',function(e){");
            sb.Append("    if (").Append(StopRowClick ? "true" : "false").Append(") { e.preventDefault(); e.stopPropagation(); }");
            sb.Append("    if (").Append(editableJs).Append("===false) return;");
            sb.Append("    activateCell();");
            sb.Append("    var code=fmt(tpl); if(!code) return;");
            sb.Append("    var cx=").Append(confirmTx).Append("; if(cx && !window.confirm(cx)) return;");
            sb.Append("    try{ (new Function(code))(); } catch(ex){ try{ eval(code); } catch(ex2){ if(window.console&&console.error){ console.error('LinkButton exec error', ex2, code); } } }");
            sb.Append("  });");

            // Enter/Space ile tetikleme
            sb.Append("  el.addEventListener('keyup', function(e){ if(e.key==='Enter' || e.key===' '){ e.preventDefault(); el.click(); } });");

            sb.Append("  return el;");
            sb.Append("}"); // <-- cellRenderer fonksiyonunu KAPATMAYI unutma

            return sb.ToString();
        }
    }

    [Serializable]
    public class DateCellType : GeneralCellType
    {
        // Kullanıcıya görünen format
        public string DisplayFormat { get; set; } = "dd.MM.yyyy";

        // JSON'da tutulacak format
        public string DataFormat { get; set; } = "yyyy-MM-dd";

        public override string ToAgGridJsProps()
        {
            var sb = new StringBuilder();
            sb.Append("\"cellEditor\":\"datePickerEditor\",");

            // Görüntüleme: yyyy-MM-dd veya dd.MM.yyyy girilmiş olabilir
            sb.Append("\"valueFormatter\":function(p){");
            sb.Append(" var v=p.value;");
            sb.Append(" if(!v) return '';");
            sb.Append(" if(typeof v==='string'){v=v.trim();}");
            // yyyy-MM-dd => dd.MM.yyyy
            sb.Append(" var m1=(typeof v==='string')?v.match(/^(\\d{4})-(\\d{2})-(\\d{2})/):null;");
            sb.Append(" if(m1){return m1[3]+'.'+m1[2]+'.'+m1[1];}");
            // zaten dd.MM.yyyy ise dokunma
            sb.Append(" var m2=(typeof v==='string')?v.match(/^(\\d{2})\\.(\\d{2})\\.(\\d{4})$/):null;");
            sb.Append(" if(m2){return v;}");
            sb.Append(" return v;");
            sb.Append("},");

            // Kullanıcı girdisini normalize et: dd.MM.yyyy veya yyyy-MM-dd -> yyyy-MM-dd
            sb.Append("\"valueParser\":function(p){");
            sb.Append(" var v=p.newValue;");
            sb.Append(" if(!v) return null;");
            sb.Append(" if(typeof v==='string'){v=v.trim();}");
            sb.Append(" var m2=(typeof v==='string')?v.match(/^(\\d{2})\\.(\\d{2})\\.(\\d{4})$/):null;");
            sb.Append(" if(m2){return m2[3]+'-'+m2[2]+'-'+m2[1];}");
            sb.Append(" var m1=(typeof v==='string')?v.match(/^(\\d{4})-(\\d{2})-(\\d{2})/):null;");
            sb.Append(" if(m1){return m1[1]+'-'+m1[2]+'-'+m1[3];}");
            sb.Append(" return v;");
            sb.Append("}");

            return sb.ToString();
        }
    }
}
