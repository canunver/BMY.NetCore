﻿#if !MU
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Security.Permissions;

namespace TNS.WebControls
{
    [ToolboxData("<{0}:TNSAjaxDiv runat=server></{0}:TNSAjaxDiv>"),
    AspNetHostingPermission(SecurityAction.Demand,
        Level = AspNetHostingPermissionLevel.Minimal),
    AspNetHostingPermission(SecurityAction.InheritanceDemand,
        Level = AspNetHostingPermissionLevel.Minimal),
    ]
    public class TNSAjaxDiv : WebControl, INamingContainer
    {
        public TNSAjaxDiv()
        {
        }

        private string _style;
        public string style
        {
            get
            {
                return _style;
            }

            set
            {
                _style = value;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            System.Web.UI.ClientScriptManager csm = null;

            try { csm = this.Page.ClientScript; }
            catch { }

            if (csm != null)
            {
                try { csm.RegisterClientScriptInclude("TNSAjaxDiv", "/script/TNSAjaxDiv.js?mc=03022015"); }
                catch { }
                try { csm.RegisterClientScriptInclude("HTTPCagir", "/script/XmlHttp.js?mc=03022015"); }
                catch { }
            }
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            base.RenderContents(output);
            try
            {
                string ekStr = "";
                if (!string.IsNullOrEmpty(style))
                    ekStr = "style=\"" + style + "\"";
                if (!string.IsNullOrEmpty(this.CssClass))
                {
                    if (!string.IsNullOrEmpty(ekStr)) ekStr += " ";
                    ekStr = ekStr + "class=\"" + this.CssClass + "\"";
                }
                if (!string.IsNullOrEmpty(ekStr)) ekStr = " " + ekStr;
                output.Write("\r\n<div id=\"" + ID + "\"" + ekStr + ">Deneme</div>\r\n");

                StringBuilder sb = new StringBuilder();

                sb.Append("\r\n<script language='JavaScript' type='text/javascript'>");
//                sb.Append("var js_" + ID + " = new TnsAjaxDiv(" + "'" + ID + "'" + ", " + "'" + IcerikYuklemeAdresi + "'" + ", " + "'" + ParamEvalString + "'" + ");");
                sb.Append("</script>\r\n");

                output.Write(sb.ToString());

                //System.Web.UI.ClientScriptManager csm;
                //try
                //{
                //    csm = this.Page.ClientScript;
                //    csm.RegisterStartupScript(this.GetType(), "js_" + Ad, sb.ToString(), true);
                //}
                //catch { }
            }
            catch { }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            //return null;
        }

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            //return null;
        }

    }
}
#endif