﻿using System;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Reflection;
using System.Threading;

namespace OrtakClass
{
    public abstract class DosyadanPDFe
    {
        protected object missing = System.Reflection.Missing.Value; //System.Type.Missing;
        public abstract void Baslat();
        public abstract void DosyaAc(string dosyaAd);
        public abstract void DosyayaYazdir(string yaziciAd, string dosyaAd);
        public abstract void DosyaKapat();
        public abstract void Cik();

        private Exception sonException = null;

        protected static void NAR(ref object o)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(o);
            }
            catch { }
            finally
            {
                o = null;
            }
        }


        protected void SonExceptionAta(Exception e)
        {
            if (sonException == null)
                sonException = e;
        }

        public Exception SonException()
        {
            return sonException;
        }

    }

    public class ExceldenPDFe : DosyadanPDFe
    {
        Type excel;
        object excelObject = null;
        object oDocs = null;
        object oBook = null;

        public override void Baslat()
        {
            excel = Type.GetTypeFromProgID("Excel.Application");
            try
            {
                excelObject = Activator.CreateInstance(excel);
            }
            catch (Exception e)
            {
                SonExceptionAta(e);
            }
        }

        public override void DosyaAc(string dosyaAd)
        {
            try
            {
                oDocs = excel.InvokeMember("Workbooks", System.Reflection.BindingFlags.GetProperty, null, excelObject, null);
            }
            catch (Exception e)
            {
                oDocs = null;
                oBook = null;
                SonExceptionAta(e);
                return;
            }
            object[] oParams = new object[3];
            oParams[0] = dosyaAd;
            oParams[1] = missing;
            oParams[2] = true; //readonly
            //Microsoft.Office.Interop.Excel.Workbooks x;

            try
            {
                //oBook = excel.InvokeMember("Open", System.Reflection.BindingFlags.InvokeMethod, null, oDocs, oParams);
                oBook = oDocs.GetType().InvokeMember("Open", System.Reflection.BindingFlags.InvokeMethod, null, oDocs, oParams);
            }
            catch (Exception e)
            {
                oBook = null;
                SonExceptionAta(e);
            }
        }

        public override void DosyayaYazdir(string yaziciAd, string dosyaAd)
        {
            object yazici;
            if (string.IsNullOrEmpty(yaziciAd))
                yazici = missing;
            else
                yazici = yaziciAd;
            object[] oParams = { missing, missing, missing, missing, yazici, true, missing, dosyaAd };
            try
            {
                oBook.GetType().InvokeMember("PrintOut", System.Reflection.BindingFlags.InvokeMethod, null, oBook, oParams);
            }
            catch (Exception e)
            {
                SonExceptionAta(e);
            }
            //  objBook.PrintOut(System.Type.Missing, System.Type.Missing, System.Type.Missing, System.Type.Missing, "PDF995", true, System.Type.Missing, cikanPSAd);

        }

        public override void DosyaKapat()
        {
            if (oBook != null)
            {
                try
                {
                    object[] oParams = { false, "" };
                    oBook.GetType().InvokeMember("Close", System.Reflection.BindingFlags.InvokeMethod, null, oBook, oParams);
                }
                catch (Exception e)
                {
                    SonExceptionAta(e);
                }
                //oBook = null;
                //oDocs = null;
            }

            oBook = null;
            oDocs = null;
        }

        public override void Cik()
        {
            if (excelObject != null)
            {
                try
                {
                    excel.InvokeMember("Quit", System.Reflection.BindingFlags.InvokeMethod, null, excelObject, null);
                }
                catch (Exception e)
                {
                    SonExceptionAta(e);
                }
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excelObject);
                excelObject = null;
            }
            excel = null;
        }
    }

    public class WorddenPDFe : DosyadanPDFe
    {
        Type word = null;
        object wordObject = null;
        object oDoc = null;
        object oDocs = null;
        public override void Baslat()
        {
            try
            {
                word = Type.GetTypeFromProgID("Word.Application");
                wordObject = Activator.CreateInstance(word);
                //bool t = true;
                //word.InvokeMember("DisplayAlerts", System.Reflection.BindingFlags.SetProperty, null, wordObject, new object[] { Word.WdAlertLevel.wdAlertsNone });
                //word.InvokeMember("Visible", System.Reflection.BindingFlags.SetProperty, null, wordObject, new object[] { t });
                //Word.Application a;
            }
            catch (Exception e)
            {
                SonExceptionAta(e);
            }
        }

        public override void DosyaAc(string dosyaAd)
        {
            if (oDocs == null)
            {
                try
                {
                    oDocs = word.InvokeMember("Documents", System.Reflection.BindingFlags.GetProperty, null, wordObject, null);
                }
                catch (Exception e)
                {
                    SonExceptionAta(e);
                    oDoc = null;
                    return;
                }
            }

            try
            {
                bool f = false;
                bool t = true;
                object[] oParams = { dosyaAd, f, t, f, missing, missing, missing, missing, missing, missing };
                //Word.Documents objDoc = null;
                //objDoc.OpenOld(ref dosyaAd, f, t,f,missing,missing,missing,missing,missing,missing,) 
                oDoc = oDocs.GetType().InvokeMember("Open", System.Reflection.BindingFlags.InvokeMethod, null, oDocs, oParams);
            }
            catch (Exception e)
            {
                oDoc = null;
                SonExceptionAta(e);
            }
        }

        public override void DosyayaYazdir(string yaziciAd, string dosyaAd)
        {
            //Melih 06.11.2012 tarihinde kapattı. Microsoft.OfficeInterop.Word referansı hata veriyordu

            //object Range = Microsoft.Office.Interop.Word.WdPrintOutRange.wdPrintAllDocument;
            //object Item = Microsoft.Office.Interop.Word.WdPrintOutItem.wdPrintDocumentContent;
            //object Copies = 1;
            //object Pages = "";
            //object PageType = Microsoft.Office.Interop.Word.WdPrintOutPages.wdPrintAllPages;
            //object PrintToFile = true;
            //object Collate = true;
            //object ManualDuplexPrint = false;
            //if (!string.IsNullOrEmpty(yaziciAd))
            //    word.InvokeMember("ActivePrinter", System.Reflection.BindingFlags.SetProperty, null, wordObject, new object[] { yaziciAd });

            ////object[] oParams = {System.Type.Missing, System.Type.Missing, System.Type.Missing, System.Type.Missing, "PDF995", true, System.Type.Missing, cikanPSAd
            ////objApp.ActivePrinter = "PDF995";
            //object[] oParams = {missing,  missing,  Range,  dosyaAd,  missing,  missing,  Item,  Copies,  Pages,
            //     PageType,  PrintToFile,  Collate,  missing,  ManualDuplexPrint,  missing,
            //     missing,  missing,  missing};

            ////Word.Application objApp = new Word.Application();
            ////objApp.ActivePrinter = "PDF995";

            //try
            //{
            //    oDoc.GetType().InvokeMember("PrintOut", System.Reflection.BindingFlags.InvokeMethod, null, oDoc, oParams);
            //}
            //catch (Exception e)
            //{
            //    SonExceptionAta(e);
            //}
        }

        public override void DosyaKapat()
        {
            if (oDoc != null)
            {
                try
                {
                    object[] oParams = { false };
                    oDoc.GetType().InvokeMember("Close", System.Reflection.BindingFlags.InvokeMethod, null, oDoc, oParams);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDoc);
                }
                catch (Exception e)
                {
                    SonExceptionAta(e);
                }
            }
            oDoc = null;
            oDocs = null;
        }

        public override void Cik()
        {
            if (wordObject != null)
            {
                try
                {
                    object[] par = { missing, missing, missing };
                    object s = word.InvokeMember("Quit", BindingFlags.InvokeMethod, null, wordObject, par);
                }
                catch (Exception e)
                {
                    SonExceptionAta(e);
                }
                System.Runtime.InteropServices.Marshal.ReleaseComObject(wordObject);
                wordObject = null;
            }
            word = null;
        }
    }

    public class DosyaTipDegistir
    {
        static string DosyaCevirKullanici = null;
        static string DosyaCevirParola = null;
        static string DosyaCevirEtkiAlani = null;
        static string DosyaCevirPSYazici = null;
        static string DosyaCevirPDF995 = null;
        static string DosyaCevirCulture = null;

        static DosyaTipDegistir()
        {
            DosyaCevirCulture = GenelIslemler.WebConfigOku("DosyaCevirCulture", null);
            DosyaCevirKullanici = GenelIslemler.WebConfigOku("DosyaCevirKullanici", null);
            DosyaCevirParola = GenelIslemler.WebConfigOku("DosyaCevirParola", null);
            DosyaCevirEtkiAlani = GenelIslemler.WebConfigOku("DosyaCevirEtkiAlani", null);

            DosyaCevirPSYazici = GenelIslemler.WebConfigOku("DosyaCevirPSYazici", null);
            DosyaCevirPDF995 = GenelIslemler.WebConfigOku("DosyaCevirPDF995", @"c:\pdf995\res\convert");
        }

        public static string Dosya2PDF(string girenAd, bool kaynakSilinsin)
        {
            string cikanYol = System.IO.Path.GetDirectoryName(girenAd) + "\\";
            string cikanAd = cikanYol + System.IO.Path.GetFileNameWithoutExtension(girenAd) + ".pdf";
            string gelenExt = System.IO.Path.GetExtension(girenAd).ToLower();
            string cikanPSAd = cikanYol + System.IO.Path.GetFileNameWithoutExtension(girenAd) + ".ps";
            System.Security.Principal.WindowsImpersonationContext c = DosyaTipDegistir.ImpersonateValidUser(DosyaCevirKullanici, DosyaCevirEtkiAlani, DosyaCevirParola);

            System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            if (!string.IsNullOrEmpty(DosyaCevirCulture))
            {
                System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(DosyaCevirCulture);
            }

            DosyadanPDFe dPdf;
            if (gelenExt == ".xls" || gelenExt == ".xlt")
            {
                dPdf = new ExceldenPDFe();
            }
            else if (gelenExt == ".doc" || gelenExt == ".dot")
            {
                dPdf = new WorddenPDFe();
            }
            else
                dPdf = null;
            Exception e = null;
            if (dPdf != null)
            {
                dPdf.Baslat();

                dPdf.DosyaAc(girenAd);

                dPdf.DosyayaYazdir(DosyaCevirPSYazici, cikanPSAd);
                //Thread.Sleep(10000);

                dPdf.DosyaKapat();

                dPdf.Cik();
                e = dPdf.SonException();
                dPdf = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
                if (e == null)
                {
                    try
                    {
                        pstopdf(cikanPSAd, cikanAd, true);
                    }
                    catch (Exception ex)
                    {
                        e = ex;
                    }
                }
                if (kaynakSilinsin)
                    System.IO.File.Delete(girenAd);
            }
            else
                e = new Exception("Bilinmeyen kaynak türü");

            System.Threading.Thread.CurrentThread.CurrentCulture = oldCI;
            DosyaTipDegistir.UndoImpersonation(c);

            if (e != null) throw e;

            return cikanAd;
            //try
            //{
            //    Type type = Type.GetTypeFromProgID("easyPDF.Loader.6");
            //    Loader oLoader = (Loader)Activator.CreateInstance(type);
            //    Printer oPrinter = (Printer)oLoader.LoadObject("easyPDF.Printer.6");
            //    PrintJob oPrintJob = oPrinter.PrintJob;
            //    oPrintJob.PrintOut(girenAd, cikanAd);
            //}
            //catch { }
        }

        private static void pstopdf(string girenPSAd, string cikanPDFAd, bool psSil)
        {
            System.Diagnostics.Process p = new System.Diagnostics.Process();
            p.StartInfo.WorkingDirectory = DosyaCevirPDF995;
            p.StartInfo.FileName = p.StartInfo.WorkingDirectory + "\\gswin32c.exe";
            p.StartInfo.Arguments = "-sDEVICE=pdfwrite -q -dPDFSETTINGS=/prepress -dCompatibilityLevel=1.3 -dNOPAUSE -dBATCH -sOutputFile=\"" + cikanPDFAd + "\" -c save pop -f \"" + girenPSAd + "\"";
            try
            {
                p.Start();
                p.WaitForExit();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (psSil)
                System.IO.File.Delete(girenPSAd);
        }

        //public static string Excel2PDFx(string girenAd, bool kaynakSilinsin)
        //{
        //    //System.Security.Principal.WindowsImpersonationContext c = DosyaTipDegistir.ImpersonateValidUser("can", "", "busraemre");
        //    string sonuc = "";
        //    Exception eDis = null;
        //    //System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;
        //    //System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
        //    try
        //    {
        //        sonuc = Excel2PDFxx(girenAd, kaynakSilinsin);
        //    }
        //    catch (Exception e)
        //    {
        //        eDis = e;
        //    }

        //    //System.Threading.Thread.CurrentThread.CurrentCulture = oldCI;
        //    //DosyaTipDegistir.UndoImpersonation(c);
        //    if (eDis != null)
        //        throw eDis;
        //    return sonuc;
        //}

        //public static string Excel2PDFxx(string girenAd, bool kaynakSilinsin)
        //{

        //    string cikanYol = System.IO.Path.GetDirectoryName(girenAd) + "\\";
        //    string cikanAd = cikanYol + System.IO.Path.GetFileNameWithoutExtension(girenAd) + ".pdf";
        //    string cikanPSAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul() + ".ps";

        //    ExceldenPDFe ep = new ExceldenPDFe();


        //}

        // public static string Word2PDF(string girenAd, bool kaynakSilinsin)
        // {
        //     string cikanYol = System.IO.Path.GetDirectoryName(girenAd) + "\\";
        //     string cikanAd = cikanYol + System.IO.Path.GetFileNameWithoutExtension(girenAd) + ".pdf";
        //     string cikanPSAd = cikanYol + System.IO.Path.GetFileNameWithoutExtension(Tablo.DosyaAdUret()) + ".ps";

        //     Word.Application objApp = null;

        //     object FileName = girenAd;
        //     object OutputFileName = cikanPSAd;

        //     object missing = System.Type.Missing;
        //     object Background = true;
        //     object Append = false;
        //     object Range = Word.WdPrintOutRange.wdPrintAllDocument;
        //     object Item = Word.WdPrintOutItem.wdPrintDocumentContent;
        //     object Copies = 1;
        //     object Pages = "";
        //     object PageType = Word.WdPrintOutPages.wdPrintAllPages;
        //     object Collate = true;
        //     object ManualDuplexPrint = false;
        //     object PrintToFile = true;

        //     try
        //     {
        //         objApp = new Word.Application();
        //         Word.Document objDoc = objApp.Documents.Open(ref FileName, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref Background, ref missing, ref missing, ref missing, ref missing);
        //         //objApp.ActivePrinter = "PDF995";
        //         objDoc.PrintOut(ref missing, ref missing, ref Range, ref OutputFileName, ref missing, ref missing, ref Item, ref Copies, ref Pages,
        //             ref PageType, ref PrintToFile, ref Collate, ref missing, ref ManualDuplexPrint, ref missing,
        //             ref missing, ref missing, ref missing);

        //         System.Threading.Thread.Sleep(7000);

        //         objDoc.Close(ref Append, ref missing, ref missing);
        //         objApp.Quit(ref Append, ref missing, ref missing);
        //         objDoc = null;
        //         objApp = null;
        //     }
        //     catch (Exception ex)
        //     {
        //         if (objApp != null)
        //             objApp.Quit(ref missing, ref missing, ref missing);
        //         objApp = null;

        //         throw ex;
        //     }
        //}
        public const int LOGON32_LOGON_INTERACTIVE = 2;
        public const int LOGON32_PROVIDER_DEFAULT = 0;

        [DllImport("advapi32.dll")]
        static extern int LogonUserA(String lpszUserName,
            String lpszDomain,
            String lpszPassword,
            int dwLogonType,
            int dwLogonProvider,
            ref IntPtr phToken);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern int DuplicateToken(IntPtr hToken,
            int impersonationLevel,
            ref IntPtr hNewToken);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool RevertToSelf();

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        static extern bool CloseHandle(IntPtr handle);

        public static WindowsImpersonationContext ImpersonateValidUser(String userName, String domain, String password)
        {
            if (string.IsNullOrEmpty(userName)) return null;
            WindowsIdentity tempWindowsIdentity;
            IntPtr token = IntPtr.Zero;
            IntPtr tokenDuplicate = IntPtr.Zero;
            WindowsImpersonationContext impersonationContext = null;
            if (RevertToSelf())
            {
                if (LogonUserA(userName, domain, password, LOGON32_LOGON_INTERACTIVE,
                    LOGON32_PROVIDER_DEFAULT, ref token) != 0)
                {
                    if (DuplicateToken(token, 2, ref tokenDuplicate) != 0)
                    {
                        tempWindowsIdentity = new WindowsIdentity(tokenDuplicate);
                        impersonationContext = tempWindowsIdentity.Impersonate();
                        if (impersonationContext != null)
                        {
                            CloseHandle(token);
                            CloseHandle(tokenDuplicate);
                            return impersonationContext;
                        }
                    }
                }
            }
            if (token != IntPtr.Zero)
                CloseHandle(token);
            if (tokenDuplicate != IntPtr.Zero)
                CloseHandle(tokenDuplicate);
            return null;
        }

        public static void UndoImpersonation(WindowsImpersonationContext impersonationContext)
        {
            if (impersonationContext != null)
                impersonationContext.Undo();
        }


    }
}
