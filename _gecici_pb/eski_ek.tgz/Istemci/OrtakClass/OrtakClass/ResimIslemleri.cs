﻿using System;
using TNS;
using System.Net;
using System.IO;
using System.Drawing;

namespace OrtakClass
{
    public class ResimIslemleri
    {
        public static void ResimBoyutlari(string resimAdi, double maxG, double maxY, ref double genislik, ref double yukseklik)
        {
            try
            {
                System.Drawing.Image i;

                if (resimAdi.StartsWith("http"))
                    i = ResimIslemleri.LoadImageFromURL(resimAdi);
                else
                    i = System.Drawing.Image.FromFile(resimAdi);

                ResimBoyutlari(i, maxG, maxY, ref genislik, ref yukseklik);
            }
            catch
            {
            }

        }

        public static void ResimBoyutlari(System.Drawing.Image resim, double maxG, double maxY, ref double genislik, ref double yukseklik)
        {
            double imgGenislik = 0;
            double imgYukseklik = 0;
            try
            {
                System.Drawing.Image i = resim;

                imgGenislik = OrtakFonksiyonlar.ConvertToDbl(i.Width);
                imgYukseklik = OrtakFonksiyonlar.ConvertToDbl(i.Height);
            }
            catch
            {
                imgGenislik = maxG;
                imgYukseklik = maxY;
            }

            if (imgGenislik > maxG || imgYukseklik > maxY)
            {
                double oran;
                if (imgGenislik > imgYukseklik)
                    oran = maxG / imgGenislik;
                else
                    oran = maxY / imgYukseklik;

                genislik = (int)(imgGenislik * oran);
                yukseklik = (int)(imgYukseklik * oran);
            }
            else
            {
                genislik = imgGenislik;
                yukseklik = imgYukseklik;
            }
        }

        public static System.Drawing.Image LoadImageFromURL(string URL)
        {
            const int BYTESTOREAD = 10000;
            WebRequest myRequest = WebRequest.Create(URL);
            WebResponse myResponse = myRequest.GetResponse();
            Stream ReceiveStream = myResponse.GetResponseStream();
            BinaryReader br = new BinaryReader(ReceiveStream);
            MemoryStream memstream = new MemoryStream();
            byte[] bytebuffer = new byte[BYTESTOREAD];
            int BytesRead = br.Read(bytebuffer, 0, BYTESTOREAD);
            while (BytesRead > 0)
            {
                memstream.Write(bytebuffer, 0, BytesRead);
                BytesRead = br.Read(bytebuffer, 0, BYTESTOREAD);
            }

            System.Drawing.Image i = new Bitmap(1, 1);
            try
            {
                i = System.Drawing.Image.FromStream(memstream);
            }
            catch { }
            return i;
        }

        public static System.Drawing.Image LoadImageFromPath(string path)
        {
            System.Drawing.Image i = new Bitmap(1, 1);
            try
            {
                i = System.Drawing.Image.FromFile(path);
            }
            catch { }
            return i;
        }
    }
}
