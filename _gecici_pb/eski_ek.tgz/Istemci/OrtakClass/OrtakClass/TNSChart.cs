﻿#if !MU
using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Data;
using System.Collections;
using Ext1.Net;

namespace OrtakClass
{
    public class TNSLineStyle : EXTOrtak, IEquatable<EXTOrtak>
    {
        public string stroke = null;
        public string fillColor = null;
        public double opacity = 0;
        public double stroke_width = 1;

        public override string ToJSON()
        {
            string ozellik = "";
            if (!string.IsNullOrEmpty(stroke))
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke", stroke, true));
            if (!string.IsNullOrEmpty(fillColor))
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("fill", fillColor, true));
            if (opacity > 0)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("opacity", opacity, true));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke-width", stroke_width, true));
            return "{" + ozellik + "}";
        }
    }

    public delegate string ReturnName(DataRow dr, string callBackAddParam);

    public enum DataTableColumnType
    {
        INTEGER,
        STRING,
        FLOATING
    }

    public interface IChartGenerator
    {
        string Generate(TNS.KYM.Kullanici kullanan, string data, bool exportData);
    }

    public interface IExtGridGenerator
    {
        string Generate(TNS.KYM.Kullanici kullanan, System.Web.UI.Page page, Ext1.Net.GridPanel grd, string param);
    }

    public static class ChartTool
    {
        public class ExtCommand
        {
            public string komutAd;
            public Ext1.Net.Icon ikon;
        }

        public static Ext1.Net.Column GridStringAlanEkle(Ext1.Net.GridPanel grd, Ext1.Net.Store str, string alanAd, string baslik, bool gorunur, bool autoExpand, int? genislik = null, int? yanasik = null, string toolTipText = null, bool? editable = false, string css = null, bool? directEventCall = null, string rendererFunction = null)
        {
            if (!string.IsNullOrEmpty(alanAd))
            {
                if (directEventCall != null && directEventCall.Value)
                    str.AddField(new RecordField(alanAd, RecordFieldType.String));
                else
                    str.Reader[0].Fields.Add(new RecordField(alanAd, RecordFieldType.String));
            }

            Column.Config c = new Column.Config();
            //c.ColumnID = alanAd;
            //c.DataIndex = alanAd;
            //c.Header = baslik;
            //c.Sortable = true;
            //c.Hidden = !gorunur;
            //if (!string.IsNullOrEmpty(toolTipText))
            //    c.Tooltip = toolTipText;

            //if (genislik != null)
            //    c.Width = genislik.Value;
            //if (yanasik != null)
            //{
            //    if (yanasik == 1)
            //        c.Align = Ext1.Net.Alignment.Left;
            //    else if (yanasik == 2)
            //        c.Align = Ext1.Net.Alignment.Right;
            //    else
            //        c.Align = Ext1.Net.Alignment.Center;
            //}
            //if (!string.IsNullOrEmpty(css))
            //    c.Css = css;
            //if (!string.IsNullOrEmpty(rendererFunction))
            //{
            //    c.Renderer = new Renderer();
            //    c.Renderer.Fn = rendererFunction;
            //}

            Ext1.Net.Column col = new Ext1.Net.Column(c);
            col.ColumnID = alanAd;
            col.Header = baslik;
            col.DataIndex = alanAd;
            col.Sortable = true;
            col.Hidden = !gorunur;
            if (!string.IsNullOrEmpty(toolTipText))
                col.Tooltip = toolTipText;
            if (genislik != null)
                col.Width = genislik.Value;

            if (yanasik != null)
            {
                if (yanasik == 1)
                    col.Align = Ext1.Net.Alignment.Left;
                else if (yanasik == 2)
                    col.Align = Ext1.Net.Alignment.Right;
                else
                    col.Align = Ext1.Net.Alignment.Center;
            }

            if (!string.IsNullOrEmpty(css))
                col.Css = css;
            if (!string.IsNullOrEmpty(rendererFunction))
            {
                col.Renderer = new Renderer();
                col.Renderer.Fn = rendererFunction;
            }

            if (directEventCall != null && directEventCall.Value)
                grd.AddColumn(col);
            else
                grd.ColumnModel.Columns.Add(col);
            if (autoExpand)
                grd.AutoExpandColumn = alanAd;

            if (editable != null && editable.Value)
            {
                Ext1.Net.TextField tf = new Ext1.Net.TextField();
                tf.SelectOnFocus = true;
                col.Editor.Add(tf);
            }

            return col;
            //, int? yanasik = null)
        }

        public static Ext1.Net.DateColumn GridDateAlanEkle(Ext1.Net.GridPanel grd, Ext1.Net.Store str, string alanAd, string baslik, bool gorunur, bool autoExpand, int? genislik = null, int? yanasik = null, string toolTipText = null, bool? editable = false, string css = null, bool? directEventCall = null, string rendererFunction = null, string dateFormat = null)
        {
            if (!string.IsNullOrEmpty(alanAd))
            {
                if (directEventCall != null && directEventCall.Value)
                    str.AddField(new RecordField(alanAd, RecordFieldType.Date));
                else
                    str.Reader[0].Fields.Add(new RecordField(alanAd, RecordFieldType.Date));
            }

            DateColumn.Config c = new DateColumn.Config();
            Ext1.Net.DateColumn col = new Ext1.Net.DateColumn(c);
            col.ColumnID = alanAd;
            col.Header = baslik;
            col.DataIndex = alanAd;
            col.Sortable = true;
            col.Hidden = !gorunur;

            string fmt;
            if (string.IsNullOrEmpty(dateFormat)) fmt = "dd.MM.yyyy";
            else fmt = dateFormat;
            col.Format = fmt;


            if (!string.IsNullOrEmpty(toolTipText))
                col.Tooltip = toolTipText;
            if (genislik != null)
                col.Width = genislik.Value;

            if (yanasik != null)
            {
                if (yanasik == 1)
                    col.Align = Ext1.Net.Alignment.Left;
                else if (yanasik == 2)
                    col.Align = Ext1.Net.Alignment.Right;
                else
                    col.Align = Ext1.Net.Alignment.Center;
            }

            if (!string.IsNullOrEmpty(css))
                col.Css = css;
            if (!string.IsNullOrEmpty(rendererFunction))
            {
                col.Renderer = new Renderer();
                col.Renderer.Fn = rendererFunction;
            }

            if (directEventCall != null && directEventCall.Value)
                grd.AddColumn(col);
            else
                grd.ColumnModel.Columns.Add(col);
            if (autoExpand)
                grd.AutoExpandColumn = alanAd;

            if (editable != null && editable.Value)
            {
                Ext1.Net.DateField tf = new Ext1.Net.DateField();
                tf.SelectOnFocus = true;
                col.Editor.Add(tf);
            }

            return col;
            //, int? yanasik = null)
        }

        public static NumberColumn GridNumberAlanEkle(Ext1.Net.GridPanel grd, Ext1.Net.Store str, string alanAd, RecordFieldType alanTur, string baslik, bool gorunur, bool autoExpand, int kolSiraNo, string numberFormat = null, double? ortalama = null, int? genislik = null, string toolTipText = null, bool? editable = false, string css = null, bool? directEventCall = null, string rendererFunction = null)
        {
            if (!string.IsNullOrEmpty(alanAd))
            {
                if (directEventCall != null && directEventCall.Value)
                    str.AddField(new RecordField(alanAd, alanTur));
                else
                    str.Reader[0].Fields.Add(new RecordField(alanAd, alanTur));
            }
            Ext1.Net.NumberColumn.Config c = new Ext1.Net.NumberColumn.Config();
            //c.ColumnID = alanAd;
            //c.DataIndex = alanAd;
            //c.Header = baslik;
            //c.Sortable = true;
            //c.Align = Alignment.Right;
            //c.Hidden = !gorunur;
            //string fmt;
            //if (string.IsNullOrEmpty(numberFormat)) fmt = "0,000.00/i";
            //else fmt = numberFormat;
            //if (genislik != null)
            //    c.Width = genislik.Value;
            //if (!string.IsNullOrEmpty(toolTipText))
            //    c.Tooltip = toolTipText;

            //if (!string.IsNullOrEmpty(css))
            //    c.Css = css;

            NumberColumn col = new Ext1.Net.NumberColumn(c);
            col.ColumnID = alanAd;
            col.DataIndex = alanAd;
            col.Header = baslik;
            col.Sortable = true;
            col.Align = Alignment.Right;
            col.Hidden = !gorunur;
            if (genislik != null)
                col.Width = genislik.Value;
            if (!string.IsNullOrEmpty(toolTipText))
                col.Tooltip = toolTipText;

            if (!string.IsNullOrEmpty(css))
                col.Css = css;

            string fmt;
            if (string.IsNullOrEmpty(numberFormat)) fmt = "0.000,00/i";
            else fmt = numberFormat;
            col.Format = fmt;

            if (ortalama != null)
            {
                Renderer r = new Renderer("return OrtalamaStyleEkle(value, '" + fmt + "', " + ortalama.Value.ToString().Replace(",", ".") + ", metadata, record, rowIndex, colIndex, store);");
                grd.ColumnModel.SetRenderer(kolSiraNo, r);
            }
            else if (!string.IsNullOrEmpty(rendererFunction))
            {
                Renderer r = new Renderer();
                r.Fn = rendererFunction;
                grd.ColumnModel.SetRenderer(kolSiraNo, r);
            }

            if (editable != null && editable.Value)
            {
                Ext1.Net.NumberField nf = new Ext1.Net.NumberField();
                nf.DecimalPrecision = 6;
                nf.SelectOnFocus = true;
                col.Editor.Add(nf);
            }
            if (directEventCall != null && directEventCall.Value)
                grd.AddColumn(col);
            else
                grd.ColumnModel.Columns.Add(col);

            if (autoExpand)
                grd.AutoExpandColumn = alanAd;
            return col;
        }

        public static CheckColumn GridCheckEkle(Ext1.Net.GridPanel grd, Ext1.Net.Store str, string alanAd, string baslik, bool gorunur, bool autoExpand, int kolSiraNo, bool ikonDegistir = false, int? genislik = null, string toolTipText = null, bool editable = true)
        {
            str.Reader[0].Fields.Add(new RecordField(alanAd, RecordFieldType.Boolean));
            Ext1.Net.CheckColumn.Config c = new Ext1.Net.CheckColumn.Config();
            //c.ColumnID = alanAd;
            //c.DataIndex = alanAd;
            //c.Header = baslik;
            //c.Sortable = true;
            //c.Align = Alignment.Center;
            //c.Hidden = !gorunur;

            //if (genislik != null)
            //    c.Width = genislik.Value;
            //if (!string.IsNullOrEmpty(toolTipText))
            //    c.Tooltip = toolTipText;
            CheckColumn col = new Ext1.Net.CheckColumn(c);
            col.Editable = editable;
            col.ColumnID = alanAd;
            col.DataIndex = alanAd;
            col.Header = baslik;
            col.Sortable = true;
            col.Align = Alignment.Center;
            col.Hidden = !gorunur;

            if (genislik != null)
                col.Width = genislik.Value;
            if (!string.IsNullOrEmpty(toolTipText))
                col.Tooltip = toolTipText;
            if (ikonDegistir)
            {
                Renderer r = new Renderer("return IkonDegistir(value, metadata, record, rowIndex, colIndex, store);");
                grd.ColumnModel.SetRenderer(kolSiraNo, r);
            }

            grd.ColumnModel.Columns.Add(col);
            //grd.AddColumn(col);

            if (autoExpand)
                grd.AutoExpandColumn = alanAd;
            return col;
        }

        public static Ext1.Net.CommandColumn GridKomutSutunuEkle(Ext1.Net.GridPanel grd, string baslik, ExtCommand[] komutlar, string komutFonksiyonAd, int? genislik = null, string toolTipText = null, string css = null)
        {
            grd.Listeners.Command.Fn = komutFonksiyonAd;
            Ext1.Net.CommandColumn.Config c = new Ext1.Net.CommandColumn.Config();
            //c.Header = baslik;
            //if (genislik != null)
            //    c.Width = genislik.Value;
            //if (!string.IsNullOrEmpty(toolTipText))
            //    c.Tooltip = toolTipText;
            //if (!string.IsNullOrEmpty(css))
            //    c.Css = css;

            Ext1.Net.CommandColumn col = new Ext1.Net.CommandColumn(c);
            col.Header = baslik;
            if (genislik != null)
                col.Width = genislik.Value;
            if (!string.IsNullOrEmpty(toolTipText))
                col.Tooltip = toolTipText;
            if (!string.IsNullOrEmpty(css))
                col.Css = css;

            if (komutlar != null)
            {
                for (int i = 0; i < komutlar.Length; i++)
                {
                    GridCommand gc = new GridCommand();
                    gc.Icon = komutlar[i].ikon;
                    gc.CommandName = komutlar[i].komutAd;
                    col.Commands.Add(gc);
                }
            }
            //if (ortalama != null)
            //{
            //    Renderer r = new Renderer("return OrtalamaStyleEkle(value, '" + fmt + "', " + ortalama.Value.ToString().Replace(",", ".") + ", metadata, record, rowIndex, colIndex, store);");
            //    grd.ColumnModel.SetRenderer(kolSiraNo, r);
            //}

            grd.ColumnModel.Columns.Add(col);
            //grd.AddColumn(col);

            return col;
        }

        private static DataRow FindDataRow(DataTable dt, object key)
        {
            foreach (DataRow item in dt.Rows)
            {
                if (item[0].Equals(key))
                    return item;
            }
            return null;
        }

        public static DataTable DataTableCevir(DataTable dt, int seriesColumnNo, int labelsColumnNo, int valuesColumnNo, ReturnName callBack, string callBackAddParam, string kodAd, string aciklamaAlanAd, double? divideCoef)
        {
            ArrayList al_S = new ArrayList();
            ArrayList al_L = new ArrayList();
            bool ilk = true;
            Type degerTip = typeof(double);
            foreach (DataRow row in dt.Rows)
            {
                object s;
                if (ilk)
                {
                    s = row[valuesColumnNo];
                    degerTip = s.GetType();
                    ilk = false;
                }
                string seri = row[seriesColumnNo].ToString();
                if (!al_S.Contains(seri))
                {
                    al_S.Add(seri);
                }
                object l = row[labelsColumnNo];
                if (!al_L.Contains(l)) al_L.Add(l);
            }
            if (al_S.Count == 0 || al_L.Count == 0) return null;
            DataTable dtSeries = new DataTable();
            dtSeries.Columns.Add(kodAd, al_L[0].GetType());
            dtSeries.Columns.Add(aciklamaAlanAd, typeof(string));

            for (int i = 0; i < al_S.Count; i++)
            {
                dtSeries.Columns.Add((string)al_S[i], degerTip);
            }

            foreach (DataRow row in dt.Rows)
            {
                object s = row[seriesColumnNo];
                object l = row[labelsColumnNo];

                DataRow serieRow = FindDataRow(dtSeries, l);
                if (serieRow == null)
                {
                    serieRow = dtSeries.NewRow();
                    serieRow[0] = l;
                    string aciklama;
                    if (callBack != null)
                        aciklama = callBack(row, callBackAddParam);
                    else
                        aciklama = l.ToString();
                    serieRow[1] = aciklama;
                    dtSeries.Rows.Add(serieRow);
                }

                int seriePos = al_S.IndexOf(s.ToString());
                if (seriePos >= 0)
                {
                    object o = row[valuesColumnNo];
                    if (divideCoef != null && divideCoef.Value != 0 && divideCoef.Value != 1)
                    {
                        if (o.GetType() == typeof(double))
                        {
                            double d = (double)o;
                            o = (double)(d / divideCoef.Value);
                        }
                        else if (o.GetType() == typeof(decimal))
                        {
                            decimal d = (decimal)o;
                            o = (decimal)(d / (decimal)divideCoef.Value);
                        }
                        else if (o.GetType() == typeof(int))
                        {
                            int d = (int)o;
                            o = (int)(d / divideCoef.Value);
                        }
                    }
                    serieRow[seriePos + 2] = o;
                }
            }
            return dtSeries;
        }

        public static TNSChart GenerateFromTable(string chartName, string chartStyle, string x_legendLabel, string y_legendLabel, string xy_legendStyle, DataTable dt, int labelsColumnNo, AxisType axisType, int valuesFirstColumnNo, ExtCollection seriesInfo, ReturnName callBack, string onClickEvent, string callBackAddParam, double? minV, double? maxV, int? steps, int? labelRotate, TIMEInterval timeInterval, bool devrik = false, int decimals = 2)
        {
            TNSChartGrid a_grid = new TNSChartGrid();
            a_grid.odd = new TNSChartGridOzellik();
            a_grid.odd.opacity = 1;
            a_grid.odd.fill = "#ddd";
            a_grid.odd.stroke = "#bbb";
            a_grid.odd.stroke_width = 0.5;

            //ChartElementType chartType
            TNSChart gr = new TNSChart();
            gr.setTitle(chartName, 30, null, chartStyle);
            gr.animate = true;
            gr.shadow = true;
            gr.style = "background:#fff";

            TNSAxis a1 = new TNSAxis();
            TNSAxis a2 = new TNSAxis();
            if (axisType == AxisType.Gauge)
            {
                a1.type = AxisType.Gauge;
                a1.position = Position.gauge;
                gr.axes.Add(a1);
            }
            else if (axisType != AxisType.Pie)
            {
                a1.position = Position.left;

                if (devrik)
                {
                    a1.type = axisType;
                    a1.timeInterval = timeInterval;
                    a1.title = x_legendLabel;
                    a1.rotate_degrees = labelRotate;
                }
                else
                {
                    a1.type = AxisType.Numeric;
                    //a1.gridNesne = a_grid;
                    a1.gridVar = true;
                    a1.decimals = decimals;
                    a1.title = y_legendLabel;
                    if (minV != null) a1.minimum = (int)minV.Value;
                    if (maxV != null) a1.maximum = (int)maxV.Value;
                }
                //a1.title = dt.Columns[valuesFirstColumnNo].ColumnName;
                //a1.MinorTickSteps = 1;
                gr.axes.Add(a1);


                a2.position = Position.bottom;
                if (devrik)
                {
                    a2.type = AxisType.Numeric;
                    a2.decimals = decimals;
                    //a2.gridNesne = a_grid;
                    a2.gridVar = true;
                    a2.title = y_legendLabel;
                    if (minV != null) a2.minimum = (int)minV.Value;
                    if (maxV != null) a2.maximum = (int)maxV.Value;
                }
                else
                {
                    a2.type = axisType;
                    a2.timeInterval = timeInterval;
                    a2.title = x_legendLabel;
                    a2.rotate_degrees = labelRotate;

                }
                //a2.title = dt.Columns[labelsColumnNo].ColumnName;
                //a2.minimum = 0;
                //a2.maximum = 5;
                //a2.majorTickSteps = 4;
                gr.axes.Add(a2);
            }

            bool legendVar = false;
            if (seriesInfo.Count > 1 || axisType == AxisType.Pie)
            {
                legendVar = true;
            }
            else
            {
                TNSSerie s = (TNSSerie)seriesInfo[0];
                if (s.xField != null && s.xField.Length > 1)
                    legendVar = true;
                if (s.yField != null && s.yField.Length > 1)
                    legendVar = true;
            }

            if (legendVar)
            {
                gr.legend = new TNSLegend();
                gr.legend.position = Position.right;
            }
            ArrayList alxField = new ArrayList();
            ArrayList alyField = new ArrayList();
            for (int i = 0; i < seriesInfo.Count; i++)
            {
                TNSSerie s = (TNSSerie)seriesInfo[i];
                StringDiziEkle(s.xField, alxField);
                StringDiziEkle(s.yField, alyField);
                gr.series.Add(s);
            }
            if (axisType != AxisType.Pie && axisType != AxisType.Gauge)
            {
                if (devrik)
                {
                    a1.fields = (string[])alxField.ToArray(typeof(string));
                    a2.fields = (string[])alyField.ToArray(typeof(string));
                }
                else
                {
                    a2.fields = (string[])alxField.ToArray(typeof(string));
                    a1.fields = (string[])alyField.ToArray(typeof(string));
                }
            }
            gr.dataTable = dt;
            if (axisType == AxisType.Pie)
            {
                TNSSerie s = (TNSSerie)seriesInfo[0];
                s.tips = new ChartTip("function(storeItem, item) { this.setTitle(storeItem.raw[0]+\": \"+storeItem.raw[1]); }");
            }
            return gr;
        }

        private static void StringDiziEkle(string[] dizi, ArrayList alField)
        {
            if (dizi == null) return;
            for (int i = 0; i < dizi.Length; i++)
            {
                if (!alField.Contains(dizi[i])) alField.Add(dizi[i]);
            }
        }

        static Color[] colorArray = { Color.FromArgb(79, 129, 189), Color.FromArgb(192, 80, 77), Color.FromArgb(155, 187, 89), Color.FromArgb(128, 100, 162), Color.Aqua, Color.ForestGreen, Color.BlueViolet, Color.Tomato, Color.DarkBlue, Color.Cyan, Color.DarkKhaki, Color.DarkOrchid, Color.AliceBlue };
        public static string GetColour(int i)
        {
            int indis = i % colorArray.Length;
            return ChartTool.ColorToRGB(colorArray[indis]);
        }

        //private static double? TuneMaxMin(double? val, bool maxMi)
        //{
        //    if (val == null) return null;
        //    if (val == 0) return val;
        //    double carpan;
        //    if (val < 0) carpan = -1;
        //    else carpan = 1;

        //    double bol = Math.Pow(10, Math.Ceiling(Math.Log10(carpan * val.Value)) - 1);
        //    return Math.Ceiling(val.Value / bol) * bol;
        //}

        public static string makeProperty(string ozellikAd, string ozellik, bool adTirnakli = false)
        {
            if (!string.IsNullOrEmpty(ozellik))
            {
                if (adTirnakli)
                    return Tirnakli(ozellikAd) + ":" + Tirnakli(ozellik);
                else
                    return ozellikAd + ":" + Tirnakli(ozellik);
            }
            else
                return "";
        }

        //public static string makeArrayProperty(string ozellikAd, string ozellik)
        //{
        //    if (!string.IsNullOrEmpty(ozellik))
        //        return ozellikAd + ":" + "[" + ozellik + "]";
        //    else
        //        return "";
        //}

        //internal static string makeNesneProperty(string ozellikAd, string ozellik)
        //{
        //    if (!string.IsNullOrEmpty(ozellik))
        //        return ozellikAd + ":" + ozellik;
        //    else
        //        return "";
        //}

        public static string makeClass(string nesneAd, string jasonStr)
        {
            if (!string.IsNullOrEmpty(jasonStr))
                return nesneAd + ":" + jasonStr;
            else
                return "";
        }

        public static string makeClass(string nesneAd, bool jasonStr)
        {
            return nesneAd + ":" + jasonStr.ToString().ToLower();
        }

        public static string makeProperty(string ozellikAd, int? ozellik)
        {
            if (ozellik != null)
                return ozellikAd + ":" + ozellik.ToString();
            else
                return "";
        }

        public static string makeProperty(string ozellikAd, bool? ozellik)
        {
            if (ozellik != null)
                return ozellikAd + ":" + ozellik.ToString().ToLower();
            else
                return "";
        }


        internal static string makeProperty(string ozellikAd, DateTime? dtNullable)
        {
            if (dtNullable != null)
            {
                DateTime dt = dtNullable.Value;
                return ozellikAd + ":" + string.Format("new Date({0},{1},{2},{3},{4},{5})", dt.Year, dt.Month - 1, dt.Day, dt.Hour, dt.Minute, dt.Second);
            }
            else
                return "";
        }

        public static string makeProperty(string ozellikAd, double? ozellik, bool adTirnakli = false)
        {
            if (ozellik != null)
            {
                if (adTirnakli)
                    return Tirnakli(ozellikAd) + ":" + ozellik.ToString().Replace(",", ".");
                return ozellikAd + ":" + ozellik.ToString().Replace(",", ".");
            }
            else
                return "";
        }

        internal static string makeArray(string[] Fields)
        {
            string ozellik = "";
            for (int i = 0; i < Fields.Length; i++)
            {
                string tut;
                if (Fields[i] == null) tut = "null";
                else tut = "'" + Fields[i] + "'";
                if (!string.IsNullOrEmpty(ozellik))
                    ozellik += ",";
                ozellik += tut;
            }
            return "[" + ozellik + "]";
        }

        internal static string makeProperty(string ozellikAd, string[] Fields, bool herZamanDizi = false)
        {
            if (Fields == null || Fields.Length == 0) return null;
            if (Fields.Length == 1 && !herZamanDizi)
                return makeProperty(ozellikAd, Fields[0]);
            return makeClass(ozellikAd, makeArray(Fields));
        }

        public static string Tirnakli(string nesneAd)
        {
            return "\"" + nesneAd + "\"";
        }

        public static string AddProperty(string ozellik, string ayrac, string deger)
        {
            if (!string.IsNullOrEmpty(deger))
            {
                if (!string.IsNullOrEmpty(ozellik))
                    ozellik += ayrac + deger;
                else
                    ozellik = deger;
            }
            return ozellik;
        }

        public static string ColorToRGB(Color color)
        {
            return "#" + color.R.ToString("X").PadLeft(2, '0') + color.G.ToString("X").PadLeft(2, '0') + color.B.ToString("X").PadLeft(2, '0');
        }

        public static string MakeValue(double? value)
        {
            if (value == null) return null;
            return value.ToString().Replace(",", ".");
        }

        public static string ExportDataTable(string header, DataTable dt)
        {
            return "";
        }
    }

    public enum AxisType
    {
        Time, Radial, Numeric, Gauge, Category, Pie
    }

    public enum Position
    {
        left, bottom, right, top, none, gauge
    }

    //public enum ChartMask
    //{
    //    Horizontal,
    //    Vertical,
    //    Box,
    //    None
    //}

    public abstract class EXTOrtak : IEquatable<EXTOrtak>
    {
        public string name = null;
        public abstract string ToJSON();

        public virtual bool Equals(EXTOrtak other)
        {
            throw new NotImplementedException();
        }
    }

    public class EXTSinif : EXTOrtak
    {
        public override string ToJSON() { return null; }
    }

    public enum UzunlukBirim
    {
        pixel = 1,
        yuzde = 2,
    }

    public class TNSChart : EXTOrtak
    {
        /// <summary>
        /// True for the default animation (easing: 'ease' and duration: 500) or a standard animation config object to be used for default chart animations. Defaults to false.
        /// </summary>

        public bool? animate = null;

        public string style = null;

        public ExtCollection axes = new ExtCollection();

        public EXTSinif background = null;

        public ExtCollection gradients = null;

        /// <summary>
        /// The amount of inset padding in pixels for the chart. Defaults to 10.
        /// </summary>
        public int? insetPadding = null;

        /// <summary>
        /// True for the default legend display or a legend config object. Defaults to false.
        /// </summary>
        public TNSLegend legend = null;

        public ExtCollection series = new ExtCollection();

        /// <summary>
        /// The name of the theme to be used. 
        /// A theme defines the colors and other visual displays of tick marks on 
        /// axis, text, title text, line colors, marker colors and styles, etc.
        /// 'Base', 'Green', 'Sky', 'Red', 'Purple', 'Blue', 'Yellow' and also six category themes 'Category1' to 'Category6'. 
        /// Default value is 'Base'
        /// </summary>
        public string theme = "Base";

        public string XType = "chart";
        public string InstanceOf = "Ext.chart.Chart";
        public DataTable dataTable = null;


        public bool? shadow = null;

        private int width = 100;
        private UzunlukBirim widthBirim = UzunlukBirim.yuzde;
        private int height = 100;
        private UzunlukBirim heightBirim = UzunlukBirim.yuzde;

        private string title = null;
        private int titleHeightinPixel = 30;
        private string titleStyle = null;
        private string titleCSS = null;

        public void setTitle(string title, int titleHeightinPixel, string titleCSS, string titleStyle)
        {
            this.title = title;
            this.titleHeightinPixel = titleHeightinPixel;
            this.titleStyle = titleStyle;
            this.titleCSS = titleCSS;
        }

        public void setWidthHeight(int? width, UzunlukBirim? widthBirim, int? height, UzunlukBirim? heightBirim)
        {
            if (width != null && widthBirim != null)
            {
                this.width = width.Value;
                this.widthBirim = widthBirim.Value;
            }
            if (height != null && heightBirim != null)
            {
                this.height = height.Value;
                this.heightBirim = heightBirim.Value;
            }
        }

        public override string ToJSON()
        {
            string ozellik = "";

            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("animate", animate));
            if (axes != null && axes.Count > 0)
            {
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("axes", axes.ToJSON()));
            }
            if (background != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("background", background.ToJSON()));

            if (gradients != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("gradients", gradients.ToJSON()));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("insetPadding", insetPadding));

            if (legend != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("legend", legend.ToJSON()));

            if (series != null)
            {
                if (axes.Count == 2)
                {
                    for (int i = 0; i < series.Count; i++)
                    {
                        TNSSerie s = (TNSSerie)series[i];
                        if (s.tips == null)
                        {
                            string[] p = new string[2];
                            bool devrik = false;
                            if (s.type == SerieType.bar)
                                devrik = true;
                            for (int j = 0; j < 2; j++)
                            {
                                TNSAxis a1 = (TNSAxis)axes[j];
                                int yer = j;
                                if (!devrik)
                                {
                                    if (j == 0) yer = 1;
                                    else yer = 0;
                                }

                                p[j] = "item.value[" + yer.ToString() + "]";
                                if (a1.dateFormat != null)
                                {
                                    p[j] = "Ext.Date.format(" + p[j] + ",'" + a1.dateFormat + "')";
                                }
                                else if (a1.type == AxisType.Numeric)
                                {
                                    string formatStr;
                                    if (a1.decimals == 0)
                                        formatStr = "0,000";
                                    else
                                        formatStr = "0,000.00";
                                    p[j] = "Ext.util.Format.number(" + p[j] + ",'" + formatStr + "')";
                                }
                            }
                            if (devrik)
                            {
                                string tut = p[0];
                                p[0] = p[1];
                                p[1] = tut;
                            }

                            s.tips = new ChartTip("\r\nfunction(storeItem, item) {\r\nthis.setTitle(" + p[1] + " + '<br />' + " + p[0] + ");\r\n}");

                        }
                    }
                }
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("series", series.ToJSON()));
            }

            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("theme", theme));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("xtype", XType));
            //ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("animate", true));
            //ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("shadow", true));


            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("style", style));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("shadow", shadow));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("store", "store1"));

            string chartClass = "\r\nvar chart1 = {" + ozellik + "};";

            ozellik = "";
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("layout", "{type: 'table', columns: 1}"));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("autoScroll", true));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("defaults", "{frame:false, border:false}"));
            ozellik += ", items:[{";
            if (!string.IsNullOrEmpty(title))
            {
                ozellik = ChartTool.AddProperty(ozellik, "", ChartTool.makeProperty("html", title));
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("bodyCls", titleCSS));
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("bodyStyle", titleStyle));
            }
            else
                this.titleHeightinPixel = 0;

            ozellik += "}, {";
            ozellik = ChartTool.AddProperty(ozellik, "", ChartTool.makeProperty("layout", "fit"));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("width", 100));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("height", 100));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("items", "[chart1]"));
            ozellik += "}]";

            string resizeStr = ((int)widthBirim).ToString() + ",";
            resizeStr += (width).ToString() + ",";
            resizeStr += ((int)heightBirim).ToString() + ",";
            resizeStr += (height).ToString() + ",";
            resizeStr += (titleHeightinPixel).ToString();

            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("listeners", "{resize: function(){ YenidenBoyutla(this, " + resizeStr + ");}}"));


            //ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("title", title));
            //ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("renderTo", "Ext.getBody()"));
            //ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("layout", "fit"));
            //ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("items", "[{xtype: 'widget.header', html:'can', height:30}, chart1]"));//

            string storeStr = "\r\nvar store1 = Ext.create('Ext.data.ArrayStore', {" +
            "fields: " + DataTableKolonlari() + "," +
            "data: [" + DataTableDegerleri() + "]});";
            string js = "Ext.onReady(function () {";
            js += storeStr;
            js += chartClass;
            js += "\r\nvar panel1 = Ext.create('Ext.Viewport', {" + ozellik + "});";
            js += "});";
            return js;
        }

        private string DataTableDegerleri()
        {
            if (dataTable == null) return null;
            string degerler = "";
            for (int r = 0; r < dataTable.Rows.Count; r++)
            {
                string satir = "[";
                DataRow row = dataTable.Rows[r];
                for (int i = 0; i < dataTable.Columns.Count; i++)
                {
                    if (i != 0) satir += ", ";
                    if (row[i].GetType() == typeof(System.DBNull))
                    {
                        if (dataTable.Columns[i].DataType == typeof(string))
                            satir += ChartTool.Tirnakli("");
                        else if (dataTable.Columns[i].DataType == typeof(DateTime))
                        {
                            satir += "new Date()";
                        }
                        else
                        {
                            satir += "0";

                        }
                    }
                    else
                    {
                        if (dataTable.Columns[i].DataType == typeof(string))
                            satir += ChartTool.Tirnakli((string)row[i]);
                        else if (dataTable.Columns[i].DataType == typeof(DateTime))
                        {
                            DateTime dt = (DateTime)row[i];
                            satir += string.Format("new Date({0},{1},{2},{3},{4},{5})", dt.Year, dt.Month - 1, dt.Day, dt.Hour, dt.Minute, dt.Second);
                        }
                        else
                        {
                            satir += row[i].ToString().Replace(',', '.');
                        }
                    }

                }
                satir += "]";
                if (r > 0) degerler += ",";
                degerler += satir;
            }

            return degerler;
        }

        private string DataTableKolonlari()
        {
            if (dataTable == null) return null;
            string kolonlar = "";
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                if (i > 0) kolonlar += ", ";
                kolonlar += "'" + dataTable.Columns[i].ColumnName + "'";
            }
            return "[" + kolonlar + "]";
        }


    }

    public class TNSLegend : EXTOrtak
    {
        public Position position = Position.none;
        public override string ToJSON()
        {
            string ozellik = "";

            if (position != Position.none)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("position", position.ToString()));
            if (string.IsNullOrEmpty(ozellik)) return null;
            return "{" + ozellik + "}";
        }
    }

    public enum SerieType
    {
        line, pie, bar, column, area, gauge, radar, scatter
    }

    public class TNSSerieHighlight : EXTOrtak
    {
        public int? size = null;
        public int? radius = null;
        public int? segment_margin = null;
        //: {
        //            margin: 20
        //          }
        public override string ToJSON()
        {
            string ozellik = "";

            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("size", size));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("radius", radius));
            if (segment_margin != null)
            {
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("segment", "{margin:" + segment_margin.Value.ToString() + "}"));
            }
            if (string.IsNullOrEmpty(ozellik)) return null;
            return "{" + ozellik + "}";
        }
    }

    public class MarkerConfig : EXTOrtak
    {
        public string type = null;
        public int? size = null;
        public int? radius = null;
        public double? stroke_width = null;
        public string fillColor = null;
        public string strokeColor = null;

        public override string ToJSON()
        {
            string ozellik = "";
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("type", type));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("size", size));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("radius", radius));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke-width", stroke_width, true));
            if (!string.IsNullOrEmpty(fillColor))
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("fill", fillColor, true));
            if (!string.IsNullOrEmpty(strokeColor))
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke", strokeColor, true));
            if (string.IsNullOrEmpty(ozellik)) return null;
            return "{" + ozellik + "}";
        }
    }

    public class ChartTip : EXTOrtak
    {
        public bool? trackMouse = true;
        public int? width = 200;
        public int? height = 38;
        public string rendererFunction = null;

        public ChartTip(string rendererFunction)
        {
            this.rendererFunction = rendererFunction;
        }

        public override string ToJSON()
        {
            string ozellik = "";
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("trackMouse", trackMouse));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("width", width));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("height", height));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("layout", "'fit'"));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("renderer", rendererFunction));

            if (string.IsNullOrEmpty(ozellik)) return null;
            return "{" + ozellik + "}";
        }
    }

    public class TNSSerie : EXTOrtak, IEquatable<EXTOrtak>
    {

        public TNSSerie()
        {
        }

        public TNSSerie(SerieType type, string name)
        {
            this.type = type;
            this.name = name;
        }

        public TNSLineStyle style = null;

        public bool? itemmouseup = null;
        /*
        public string SeriesID;

        /// <summary>
        /// If true, the area below the line will be filled in using the eefill and opacity config properties. Defaults to false.
        /// </summary>
        public bool Fill = false;

        /// <summary>
        /// <summary>
        /// The offset distance from the cursor position to the line series to trigger events (then used for highlighting series, etc). Defaults to: 20
        /// </summary>
        public int SelectionTolerance = 20;

        
        /// <summary>
        /// The store record field name to be used for the pie angles. The values bound to this field name must be positive real numbers.
        /// </summary>
        public string AngleField;

        /// <summary>
        /// The duration for the pie slice highlight effect. Defaults to: 150
        /// </summary>
        public int HighlightDuration = 150;

        /// <summary>
        /// 
        /// </summary>
        public int? HighlightSegmentMargin = null;

        public string HighlightSegmentMarginProxy;

        /// <summary>
        /// The store record field name to be used for the pie slice lengths. The values bound to this field name must be positive real numbers.
        /// </summary>
        public string LengthField;

        /// <summary>
        /// Whether to set the visualization as column chart or horizontal bar chart.
        /// </summary>
        public bool Column = false;


        /// <summary>
        /// The gutter space between groups of bars, as a percentage of the bar width. Defaults to: 38.2
        /// </summary>
        public double GroupGutter = 38.2;

        /// <summary>
        /// The gutter space between single bars, as a percentage of the bar width. Defaults to: 38.2
        /// </summary>
        public double Gutter = 38.2;

        /// <summary>
        /// Padding between the left/right axes and the bars. Defaults to: 0
        /// </summary>
        public int XPadding = 0;

        /// <summary>
        /// Padding between the top/bottom axes and the bars. Defaults to: 10
        /// </summary>
        public int YPadding = 10;

        /// <summary>
        /// Use the Gauge Series as an area series or add a needle to it. Default's false.
        /// </summary>
        public bool Needle;

        public string rendererFunction;

        /// <summary>
        /// Whether to show this series in the legend. Defaults to: true
        /// </summary>
        public bool ShowInLegend = true;

        /// <summary>
        /// The human-readable name of the series.
        /// </summary>
        public string Title;

       
        
        //private SeriesLabel label;

        */
        public SerieType type;
        /// <summary>
        /// If set to true it will highlight the markers or the series when hovering with the mouse. This parameter can also be an object with the same style properties you would apply to a Ext.draw.Sprite to apply custom styles to markers and series.
        /// </summary>
        public TNSSerieHighlight highlight = null;
        public Position[] axis;
        /// <summary>
        /// The field used to access the x axis value from the items from the data source.
        /// </summary>
        public string[] xField;

        /// <summary>
        /// The field used to access the y axis value from the items from the data source.
        /// </summary>
        public string[] yField;
        /// <summary>
        /// If set to a non-zero number, the line will be smoothed/rounded around its points; otherwise straight line segments will be drawn.
        /// </summary>
        public bool? smooth = null;
        public MarkerConfig markerConfig = null;
        public ChartTip tips = null;
        public bool? stacked = null;

        /// <summary>
        /// An array of color values which will be used, in order, as the gauge slice fill colors.
        /// </summary>
        public string[] colorSet = null;

        /// <summary>
        /// Whether to set the pie chart as donut chart. Default's false. Can be set to a particular percentage to set the radius of the donut chart.
        /// </summary>
        public int? donut = null;

        public string labelField = null;

        public override string ToJSON()
        {
            string ozellik = "";

            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("type", type.ToString()));
            if (highlight != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("highlight", highlight.ToJSON()));
            string[] axisStr = StryeCevir(axis);
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("axis", axisStr));

            if (type == SerieType.gauge)
            {
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("field", yField[0]));
                if (donut == null) donut = 70;
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("donut", donut));
                if (colorSet == null)
                    colorSet = new string[] { "#F49D10", "#ddd" };
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("colorSet", colorSet));
            }
            else if (type != SerieType.pie)
            {
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("xField", xField));
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("yField", yField));
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("smooth", smooth));
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stacked", stacked));
            }
            else
            {
                if (type == SerieType.pie)
                {
                    if (colorSet != null)
                    {
                        ozellik = ChartTool.AddProperty(ozellik, ",", "getLegendColor:function(index) {return " + ChartTool.makeArray(colorSet) + "[index%" + colorSet.Length + "];}");
                        ozellik = ChartTool.AddProperty(ozellik, ",", "renderer:function(sprite, record, attr, index, store) { return Ext.apply(attr, {fill: " + ChartTool.makeArray(colorSet) + "[index%" + colorSet.Length + "]});}");
                    }
                    if ((donut != null) && (donut > 0))
                    {
                        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("donut", donut));
                    }
                }
                string labelStr = "{field: '" + (string.IsNullOrWhiteSpace(labelField) ? xField[0] : labelField) + "', display: 'rotate', contrast: true";
                //labelStr += ", renderer: function(v){return v+'x';}";
                labelStr += "}";
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("field", yField[0]));
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("label", labelStr));

                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("showInLegend", true));
                //ChartTip ct = new ChartTip("function(storeItem, item) { this.setTitle(storeItem.get('" + xField[0] + "') + ': ' + storeItem.get('" + yField[0] + "') );}");

                //ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("tips", ct.ToJSON()));
            }
            if (markerConfig != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("markerConfig", markerConfig.ToJSON()));
            if (tips != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("tips", tips.ToJSON()));
            itemmouseup = true;
            if (itemmouseup != null && itemmouseup.Value)
            {
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("listeners", "{itemmouseup: function(o){itemmouseup(o, '" + this.name + "');}}"));
            }

            if (this.style != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("style", style.ToJSON()));

            if (string.IsNullOrEmpty(ozellik)) return null;
            return "{" + ozellik + "}";
        }

        private string[] StryeCevir(Position[] axis)
        {
            if (axis == null || axis.Length == 0) return null;
            string[] donus = new string[axis.Length];
            for (int i = 0; i < donus.Length; i++)
            {
                donus[i] = axis[i].ToString();
            }
            return donus;
        }

        public override bool Equals(EXTOrtak other)
        {
            if (other.name == name) return true;
            return false;
        }
    }

    public class TNSChartGridOzellik : EXTOrtak
    {
        public int? opacity = null;
        public string fill = null;
        public string stroke = null;
        public double? stroke_width = null;

        public override string ToJSON()
        {
            string ozellik = "";

            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("opacity", opacity));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("fill", fill));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke", stroke));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke-width", stroke_width, true));

            if (string.IsNullOrEmpty(ozellik)) return null;
            return "{" + ozellik + "}";
        }
    }

    public class TNSChartGrid : EXTOrtak
    {
        public TNSChartGridOzellik odd = null;
        public TNSChartGridOzellik even = null;

        public override string ToJSON()
        {
            string ozellik = "";

            if (odd != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("odd", odd.ToJSON()));
            if (even != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("even", even.ToJSON()));

            if (string.IsNullOrEmpty(ozellik)) return null;
            return "{" + ozellik + "}";
        }
    }

    public enum ENUMTime
    {
        Dakika,
        Saat,
        Gun,
        Ay,
        Yil
    }
    public class TIMEInterval
    {
        public DateTime? fromDate = null;
        public DateTime? toDate = null;
        public ENUMTime? timeInt = null;
        public int? step = null;

        internal void AdjustDates()
        {
            if (fromDate != null && toDate != null)
            {
                if (timeInt == ENUMTime.Gun && step > 1)
                {
                    TimeSpan ts = toDate.Value.Subtract(fromDate.Value);
                    int yuvarlama = (ts.Days / step.Value) * step.Value;
                    yuvarlama = ts.Days - yuvarlama;
                    if (yuvarlama == 0) yuvarlama = step.Value;

                    toDate = toDate.Value.AddDays(yuvarlama);

                }
            }
        }
    }

    public class TNSAxis : EXTOrtak
    {
        /*
                public bool? RoundToDecimal = true;

                /// <summary>
                /// Indicates the format the date will be rendered on. For example: 'MMM dd' will render the dates as 'Jan 30', etc.
                /// </summary>
                public string DateFormat;
                public string AxisID;

                /// <summary>
                /// The starting date for the time axis.
                /// </summary>
                public DateTime? FromDate;

                /// <summary>
                /// The ending date for the time axis.
                /// </summary>
                public DateTime? ToDate;

                public int? Step;

                /// <summary>
                /// The minimum value of the interval to be displayed in the axis (REQUIRED).
                /// </summary>
                public int? Steps;

                public DateUnit? StepUnit;

                //private SpriteAttributes labelTitle;

                /// <summary>
                /// The offset positioning of the tick marks and labels in pixels. Defaults to: 10
                /// </summary>
                public int? Margin;

                public bool? Hidden = false;

                /// <summary>
                /// The size of the dash marker. Default's 3.
                /// </summary>
                public int? DashSize = 3;

                /// <summary>
                /// Offset axis position. Default's 0.
                /// </summary>
                public int? Length = 0;

                /// <summary>
                /// Offset axis width. Default's 0.
                /// </summary>
                public int? Width;

                public AxisLabel Label = null;
                */

        /*   ***/
        public AxisType type;
        /// <summary>
        /// The number of decimals to round the value to. Default's 2.
        /// </summary>
        public int? decimals = null;
        /// <summary>
        /// The maximum value drawn by the axis. If not set explicitly, the axis maximum will be calculated automatically.
        /// </summary>
        public int? maximum;

        /// <summary>
        /// The minimum value drawn by the axis. If not set explicitly, the axis minimum will be calculated automatically.
        /// </summary>
        public int? minimum;

        public Position position;

        /// <summary>
        /// The title for the Axis
        /// </summary>
        public string title;

        public string[] fields = null;

        /// <summary>
        /// If minimum and maximum are specified it forces the number of major ticks to the specified value.
        /// </summary>
        public int? majorTickSteps = null;

        /// <summary>
        /// The number of small ticks between two major ticks. Default is zero.
        /// </summary>
        public int? minorTickSteps = null;

        /// <summary>
        /// The grid configuration enables you to set a background grid for an axis. 
        /// If set to true on a vertical axis, vertical lines will be drawn. 
        /// If set to true on a horizontal axis, horizontal lines will be drawn. 
        /// If both are set, a proper grid with horizontal and vertical lines will be drawn.
        /// </summary>
        public TNSChartGrid gridNesne = null;
        public bool? gridVar = null;

        public string dateFormat = null;
        public TIMEInterval timeInterval = null;
        /// <summary>
        /// Indicates whether to extend maximum beyond data's maximum to the nearest majorUnit. Defaults to: false
        /// </summary>
        public bool? adjustMaximumByMajorUnit = null;

        /// <summary>
        /// Indicates whether to extend the minimum beyond data's minimum to the nearest majorUnit. Defaults to: false
        /// </summary>
        public bool? adjustMinimumByMajorUnit = null;

        /// <summary>
        /// If true, the values of the chart will be rendered only if they belong between the fromDate and toDate. If false, the time axis will adapt to the new values by adding/removing steps. Defaults to: false
        /// </summary>
        public bool? constrain = null;
        public int? rotate_degrees = null;
        public override string ToJSON()
        {
            string ozellik = "";
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("type", type.ToString()));

            if (type == AxisType.Time)
            {
                string step;
                dateFormat = "d.m.Y";
                step = "[Ext.Date.DAY, " + "7" + "]";
                if (timeInterval != null)
                {
                    int adim = 1;
                    if (timeInterval.timeInt != null)
                    {
                        if (timeInterval.timeInt == ENUMTime.Yil)
                        {
                            dateFormat = "Y";
                            step = "Ext.Date.YEAR";
                        }
                        else if (timeInterval.timeInt == ENUMTime.Ay)
                        {
                            dateFormat = "m.Y";
                            step = "Ext.Date.MONTH";
                        }
                        else if (timeInterval.timeInt == ENUMTime.Dakika)
                        {
                            dateFormat = "j H:i";
                            step = "Ext.Date.MINUTE";
                        }
                        else if (timeInterval.timeInt == ENUMTime.Saat)
                        {
                            dateFormat = "m.d h";
                            step = "Ext.Date.HOUR";
                        }
                        else
                        {
                            step = "Ext.Date.DAY";
                        }
                        if (timeInterval.step != null)
                            adim = timeInterval.step.Value;
                    }
                    step = "[" + step + ", " + adim.ToString() + "]";
                    timeInterval.AdjustDates();
                    ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("fromDate", timeInterval.fromDate));
                    ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("toDate", timeInterval.toDate));
                }


                constrain = true;
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("dateFormat", dateFormat));
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("step", step));
                adjustMaximumByMajorUnit = true;
                adjustMinimumByMajorUnit = true;
            }

            string labelClass = "";

            if (rotate_degrees != null)
                labelClass = ChartTool.AddProperty(labelClass, ",", ChartTool.makeClass("rotate", "{ degrees: " + rotate_degrees.ToString() + " }"));
            if (type == AxisType.Numeric)
            {
                string fmt = "";
                if (decimals == 0)
                {
                    fmt = "0,000";
                }
                else
                {
                    fmt = "0,000.";
                    for (int i = 0; i < decimals; i++)
                    {
                        fmt += "0";
                    }
                }
                string renderer = "Ext.util.Format.numberRenderer('" + fmt + "')";

                labelClass = ChartTool.AddProperty(labelClass, ",", ChartTool.makeClass("renderer", renderer));
            }
            //else
            //{
            //    if (this.dateFormat != "")
            //    {
            //        string renderer = "Ext.util.Format.dateRenderer('" + dateFormat + "')";
            //        labelClass = ChartTool.AddProperty(labelClass, ",", ChartTool.makeClass("renderer", renderer));
            //    }
            //}
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("label", "{" + labelClass + "}"));

            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("adjustMaximumByMajorUnit", adjustMaximumByMajorUnit));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("adjustMinimumByMajorUnit", adjustMinimumByMajorUnit));
            if (this.type == AxisType.Gauge)
            {
                if ((maximum == null || maximum.Value == 0))
                    maximum = 100;
                if ((minimum == null || minimum.Value == 0))
                    minimum = 0;
                position = Position.gauge;
            }

            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("maximum", maximum));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("minimum", minimum));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("decimals", decimals));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("position", position.ToString()));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("fields", fields, true));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("title", title));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("minorTickSteps", minorTickSteps));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("majorTickSteps", majorTickSteps));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("constrain", constrain));
            if (gridNesne != null)
                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("grid", gridNesne.ToJSON()));
            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("grid", gridVar));

            if (string.IsNullOrEmpty(ozellik)) return null;
            return "{" + ozellik + "}";
        }
    }

    public class ExtCollection : System.Collections.Generic.List<EXTOrtak>
    {
        internal string ToJSON()
        {
            string ozellik = "";
            for (int i = 0; i < this.Count; i++)
            {
                string tut = this[i].ToJSON();
                if (tut != null)
                {
                    if (!string.IsNullOrEmpty(ozellik))
                        ozellik += ",";
                    ozellik += tut;
                }
            }
            if (string.IsNullOrEmpty(ozellik))
                return null;
            return "[" + ozellik + "]";
        }
    }
}


//bool RoundToDecimal = true;
//bool Constrain;
//string DateFormat;
//string AxisID;
//DateTime FromDate;
//DateTime ToDate;
//int Step;
//int? Steps;
//DateUnit StepUnit;
//bool AdjustMaximumByMajorUnit = false;
//int Decimals = 2;
//bool AdjustMinimumByMajorUnit;
//int Margin;
//bool Hidden = false;
//int DashSize = 3;
//int Length = 0;
//int Width;
//AxisLabel Label;

//public class AxisLabel
//{
//    private string rendererFunction = null;
//    public int? Padding = null;
//}

//public class SeriesLabel
//{
//    /// <summary>
//    /// The color of the label text. Default value: '#000' (black)."
//    /// </summary>
//    public string Color = "#000";

//    /// <summary>
//    /// True to render the label in contrasting color with the backround. Default value: false.
//    /// </summary>
//    public bool Contrast = false;
//    //public virtual SeriesLabelDisplay Display

//    /// <summary>
//    /// The name of the field to be displayed in the label. Default value: 'name'.
//    /// </summary>
//    public string Field;

//    /// <summary>
//    /// Specifies the minimum distance from a label to the origin of the visualization. This parameter is useful when using PieSeries width variable pie slice lengths. Default value: 50.
//    /// </summary>
//    public int MinMargin = 50;

//    /// <summary>
//    /// Either \"horizontal\" or \"vertical\". Dafault value: \"horizontal\"."
//    /// </summary>
//    public Orientation orientation;

//    /// <summary>
//    /// Optional function for formatting the label into a displayable value. Default value: function(value) { return value; }"
//    /// </summary>
//    public string rendererFunction;
//}

//public enum Orientation
//{
//    horizontal, vertical
//}


//public enum ChartElementType
//{
//    Line,
//    Bar,
//    Bar_3d,
//    bar_cylinder,
//    bar_cylinder_outline,
//    bar_round_glass,
//    bar_round,
//    bar_dome,
//    bar_round3d,
//    bar_filled,
//    bar_glass,
//    bar_sketch,
//    bar_stack,
//    //bar_fade,
//    Pie,

//}

//public class SerieInfo : IEquatable<SerieInfo>
//{
//    public ChartElementType chartType;
//    public string name;
//    public Color? c = null;
//    public string tip = null; //"#val#/#total#";

//    public SerieInfo(ChartElementType chartType, string name)
//    {
//        this.chartType = chartType;
//        this.name = name;
//    }

//    public SerieInfo(ChartElementType chartType, string name, Color c)
//    {
//        this.chartType = chartType;
//        this.name = name;
//        this.c = c;
//    }

//    internal string GetColour(int i)
//    {
//        if (c == null)
//            return ChartTool.GetColour(i);
//        else
//            return ChartTool.ColorToRGB(c.Value);
//    }

//    public bool Equals(SerieInfo other)
//    {
//        if (other.name == name) return true;
//        return false;
//    }
//}

//public static string ElementTypename(ChartElementType type)
//{

//    if (type == ChartElementType.Bar) return "bar";
//    else if (type == ChartElementType.Bar_3d) return "bar_3d";
//    else if (type == ChartElementType.bar_stack) return "bar_stack";
//    else if (type == ChartElementType.bar_cylinder) return "bar_cylinder";
//    else if (type == ChartElementType.bar_cylinder_outline) return "bar_cylinder_outline";
//    else if (type == ChartElementType.bar_round_glass) return "bar_round_glass";
//    else if (type == ChartElementType.bar_round) return "bar_round";
//    else if (type == ChartElementType.bar_dome) return "bar_dome";
//    else if (type == ChartElementType.bar_round3d) return "bar_round3d";
//    else if (type == ChartElementType.bar_filled) return "bar_filled";
//    else if (type == ChartElementType.bar_glass) return "bar_glass";
//    else if (type == ChartElementType.bar_sketch) return "bar_sketch";
//    //else if (type == ChartElementType.bar_fade) return "bar_fade";

//    else if (type == ChartElementType.Pie) return "pie";
//    else return "line";
//}

//public static string ValueName(ChartElementType type)
//{
//    if (type == ChartElementType.Bar_3d ||
//        type == ChartElementType.bar_cylinder ||
//        type == ChartElementType.bar_cylinder_outline ||
//        type == ChartElementType.bar_round_glass ||
//        type == ChartElementType.bar_round ||
//        type == ChartElementType.bar_dome ||
//        type == ChartElementType.bar_round3d ||
//        type == ChartElementType.bar_filled ||
//        type == ChartElementType.bar_glass ||
//        type == ChartElementType.bar_sketch ||
//        //type == ChartElementType.bar_fade ||
//        type == ChartElementType.Bar) return "top";
//    else if (type == ChartElementType.bar_stack) return "val";
//    return "value";
//}

//public static string ChartShowName(ChartShowType type)
//{
//    if (type == ChartShowType.grow_up) return "grow_up";
//    if (type == ChartShowType.drop) return "drop";
//    return "pop";
//}

//public static string PositionToStr(LegendPosition position)
//{
//    if (position == LegendPosition.right) return "right";
//    return "top";
//}

//internal static bool IsGroupedType(ChartElementType chartElementType)
//{
//    if (chartElementType == ChartElementType.bar_stack)
//        return true;
//    return false;
//}

//public class ChartValue
//{
//    double? value = null;
//    public double? value_low = null;

//    string label = null;
//    string text = null;

//    public string colour = null;
//    public string outline_colour = null;

//    /// <summary>
//    /// Function or URL to invoke when the point is clicked on
//    /// </summary>
//    public string on_click = null;

//    /// <summary>
//    /// Specifies the text to display in the pop up tool tip.
//    ///* Default is “[#x#,#y#] #size#” which displays the X, Y and dot-size values.
//    /// </summary>
//    public string tip = null;

//    public ChartValue(double? value)
//    {
//        this.value = value;
//    }

//    public ChartValue(double? value, string label, string text)
//    {
//        this.value = value;
//        this.label = label;
//        this.text = text;
//    }

//    bool AllOtherFieldsEmpty()
//    {
//        if (value_low == null && string.IsNullOrEmpty(label) && string.IsNullOrEmpty(text) && string.IsNullOrEmpty(colour) && string.IsNullOrEmpty(outline_colour) && string.IsNullOrEmpty(on_click))
//            return true;
//        return false;
//    }


//    public string ToJSON(ChartElementType type)
//    {
//        if (AllOtherFieldsEmpty())
//        {
//            return ChartTool.MakeValue(value);
//        }
//        else
//        {
//            string ozellik = "";
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty(ChartTool.ValueName(type), value));
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("bottom", value_low));
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("label", label));
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("text", text));
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("colour", colour));
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("outline-colour", outline_colour));
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("on-click", on_click));
//            ozellik = "{" + ozellik + "}";
//            return ozellik;
//        }
//    }
//}

//public enum ChartShowType
//{
//    grow_up,
//    drop,
//    pop
//}

//public class ChartShow
//{
//    ChartShowType type = ChartShowType.grow_up;
//    public double? cascade = null;
//    public double? delay = null;

//    public ChartShow(ChartShowType type, double? cascade, double? delay)
//    {
//        this.type = type;
//        this.cascade = cascade;
//        this.delay = delay;
//    }

//    public string ToJSON()
//    {
//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("type", ChartTool.ChartShowName(type)));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("cascade", cascade));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("delay", delay));
//        if (!string.IsNullOrEmpty(ozellik))
//            ozellik = "{" + ozellik + "}";
//        return ozellik;
//    }

//}

//public class ChartElement
//{
//    public ChartElementType type;
//    public string text;
//    public string tip; //":"#label# $#val#<br>#percent#", 
//    public ChartShow on_show = null;
//    public string on_click = null;
//    public int? radius;
//    public string highlight;
//    public bool? animate;
//    public bool? gradient_fill;
//    public double? alpha;
//    public bool? no_labels;
//    public string colour = null;
//    public IList<string> colours = new List<string>(); //":["#ff0000","#00aa00","#0000ff","#ff9900","#ff00ff"]
//    public IList<ChartValue> values = new List<ChartValue>(); //":["#ff0000","#00aa00","#0000ff","#ff9900","#ff00ff"]

//    public ChartElement(ChartElementType type, string text)
//    {
//        this.text = text;
//        this.type = type;
//    }

//    public string ToJSON()
//    {
//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("type", ChartTool.ElementTypename(type)));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("text", text));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("tip", tip));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("radius", radius));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("highlight", highlight));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("animate", animate));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("gradient-fill", gradient_fill));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("alpha", alpha));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("colour", colour));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("no-labels", no_labels));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("on-click", on_click));
//        if (on_show != null)
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("on-show", on_show.ToJSON()));

//        if (colours != null && colours.Count > 0)
//        {
//            string diziStr = "";
//            foreach (string color in colours)
//            {
//                diziStr = ChartTool.AddProperty(diziStr, ",", "\"" + color + "\"");
//            }
//            diziStr = "[" + diziStr + "]";
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("colours", diziStr));
//        }

//        if (values != null && values.Count > 0)
//        {
//            string diziStr = "";
//            foreach (ChartValue value in values)
//            {
//                if (value != null)
//                    diziStr = ChartTool.AddProperty(diziStr, ",", value.ToJSON(type));
//                else
//                    diziStr = ChartTool.AddProperty(diziStr, ",", "null");
//            }
//            diziStr = "[" + diziStr + "]";
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("values", diziStr));
//        }

//        if (!string.IsNullOrEmpty(ozellik))
//            ozellik = "{" + ozellik + "}";
//        return ozellik;
//    }

//    public void AddValue(ChartValue chartValue)
//    {
//        values.Add(chartValue);
//    }

//    public void AddValue(double? val)
//    {
//        ChartValue chartValue = new ChartValue(val);

//        values.Add(chartValue);
//    }

//    internal int ValueCount()
//    {
//        if (values == null) return 0;
//        return values.Count;
//    }

//    internal ChartValue GetValueAt(int i)
//    {
//        if (i < ValueCount())
//            return values[i];
//        return null;
//    }
//}

//public class ChartYAxis
//{
//    /// <summary>
//    /// The X value at the point where the X Axis meets the Y axis in the lower left corner
//    /// </summary>
//    public double? min = null;

//    /// <summary>
//    /// Any value	undefined	If “max” is not specified then it will be automatically determined by the data being plotted.
//    /// </summary>
//    public double? max = null;

//    /// <summary>
//    /// Width in pixels of the axis line. Zero (0) is a hairline.
//    /// </summary>
//    public int? stroke = null;

//    /// <summary>
//    /// Specifies the length of the tick marks in pixels. Zero (0) means do not draw the tick mark. If set to zero allows the grid line to be drawn without the tick mark.
//    /// </summary>
//    public int? tick_length = null;

//    /// <summary>
//    /// “#RRGGBB” hex string	“#784016”	Colour for the axis line. Default is a brownish.
//    /// </summary>
//    public string colour = null;

//    /// <summary>
//    /// “#RRGGBB” hex string	“#F5E1AA”	Colour for the background of the chart area. Default is a beige (?).
//    /// </summary>
//    public string grid_colour = null;

//    /// <summary>
//    /// Not used.
//    /// </summary>
//    public int? width_3d = null;

//    /// <summary>
//    /// Specifies how many steps between grid lines. One (1) means a grid line at every value. Two (2) means a grid line at every other value. Etc.
//    /// </summary>
//    public int? steps = null;

//    /// <summary>
//    /// true or false. defaulut=true. Specifies whether or not there should be a small gap between the Y-Axis and the minimum X point.
//    /// </summary>
//    public bool? offset = null;

//    /// <summary>
//    /// Object describing the text labels	{...}	Specifies the attributes for the labels associated with the grid lines.
//    /// </summary>
//    public IList<ChartLabelGroup> labels = new System.Collections.Generic.List<ChartLabelGroup>();

//    public string ToJSON()
//    {
//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("min", min));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("max", max));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke", stroke));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("tick-height", tick_length));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("colour", colour));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("grid-colour", grid_colour));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("3d", width_3d));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("steps", steps));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("offset", offset));
//        if (labels != null && labels.Count > 0)
//        {
//            if (labels.Count > 1)
//            {
//                string diziStr = "";
//                foreach (ChartLabelGroup label in labels)
//                {
//                    diziStr = ChartTool.AddProperty(diziStr, ",", label.ToJSON());
//                }
//                diziStr = "[" + diziStr + "]";
//                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("labels", diziStr));
//            }
//            else
//            {
//                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("labels", labels[0].ToJSON()));
//            }
//        }
//        if (!string.IsNullOrEmpty(ozellik))
//            ozellik = "{" + ozellik + "}";
//        return ozellik;
//    }

//    public void AddLabel(ChartLabelGroup grafikLabel)
//    {
//        labels.Add(grafikLabel);
//    }
//}

//public class ChartLabel
//{
//    /// <summary>
//    /// user defined text	undefined	Specifies the default label text for the X axis labels and should include magic values otherwise all labels will be the same.*
//    ///  The magic value #val# will be replaced with the Y value.
//    ///  Four magic values are available for use with unix timestamps: #date#, #date:___#, #gmdate# and #gmdate:___#.**
//    ///  See the date formatting section below
//    /// </summary>
//    public string text = null;

//    public string on_click = null;

//    public ChartLabel(string text)
//    {
//        this.text = text;
//    }

//    //public ChartLabel(string text, string on_click)
//    //{
//    //    this.text = text;
//    //    this.on_click = on_click;
//    //}

//    public string ToJSON()
//    {
//        if (on_click == null)
//            return "\"" + text + "\"";
//        else
//        {
//            string ozellik = "";
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("text", text));
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("on-click", on_click));
//            return "{" + ozellik + "}";
//        }
//    }
//}

//public class ChartLabelGroup
//{
//    /// <summary>
//    /// “#RRGGBB” hex string	Defines the color of the label text. Default is black.
//    /// </summary>
//    public string colour = null;

//    /// <summary>
//    /// Defines the font size of the label
//    /// </summary>
//    public int? size = null;

//    /// <summary>
//    /// Defines number of steps between the labels to be created. 
//    /// * If you need the labels for use in tooltips with the #x_label# magic value then always use a value of 1. To only display some of them use the “visible-steps” variable.
//    /// * This value could be specified before the patch but I believe it was always overridden by the “steps” defined at the “x_axis” level.
//    /// </summary>
//    public int? steps = null;

//    /// <summary>
//    /// Specifies if the label should be rotated.
//    /// “diagonal” - labels are displayed at an angle. Forces the “rotate” value to -45 degrees.
//    /// “vertical” - labels are displayed vertically. Forces the “rotate” value to 270 (same as -90) degrees.
//    /// A number – the number of degrees to rotate the label
//    /// 0 – labels are displayed horizontally. This can be overridden by specifying a “rotate” value.
//    /// </summary>
//    public int? rotate = null;

//    /// <summary>
//    /// “auto” - rotated labels are moved so that the high point label is pointing to the tick mark.
//    /// “center” - rotated labels are moved so that the label is centered under the tick mark.
//    /// </summary>
//    public string align = null;

//    /// <summary>
//    /// Values: “left”,“center”,“right”
//    /// Specifies how to justify multi-line labels.
//    /// </summary>
//    public string justify = null;

//    public IList<ChartLabel> labels = new List<ChartLabel>();

//    public string ToJSON()
//    {
//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("colour", colour));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("size", size));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("steps", steps));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("rotate", rotate));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("align", align));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("justify", justify));

//        //                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("text", text));

//        if (labels != null && labels.Count > 0)
//        {
//            string diziStr = "";
//            foreach (ChartLabel label in labels)
//            {
//                diziStr = ChartTool.AddProperty(diziStr, ",", label.ToJSON());
//            }
//            diziStr = "[" + diziStr + "]";
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("labels", diziStr));
//        }

//        if (!string.IsNullOrEmpty(ozellik))
//            ozellik = "{" + ozellik + "}";
//        return ozellik;
//    }

//    public void AddLabel(ChartLabel chartLabel)
//    {
//        labels.Add(chartLabel);
//    }
//}

//public class ChartXAxis
//{
//    /// <summary>
//    /// The X value at the point where the X Axis meets the Y axis in the lower left corner
//    /// </summary>
//    public double? min = null;

//    /// <summary>
//    /// Any value	undefined	If “max” is not specified then it will be automatically determined by the data being plotted.
//    /// </summary>
//    public double? max = null;

//    /// <summary>
//    /// Width in pixels of the axis line. Zero (0) is a hairline.
//    /// </summary>
//    public int? stroke = null;

//    /// <summary>
//    /// Specifies the length of the tick marks in pixels. Zero (0) means do not draw the tick mark. If set to zero allows the grid line to be drawn without the tick mark.
//    /// </summary>
//    public int? tick_height = null;

//    /// <summary>
//    /// “#RRGGBB” hex string	“#784016”	Colour for the axis line. Default is a brownish.
//    /// </summary>
//    public string colour = null;

//    /// <summary>
//    /// “#RRGGBB” hex string	“#F5E1AA”	Colour for the background of the chart area. Default is a beige (?).
//    /// </summary>
//    public string grid_colour = null;

//    /// <summary>
//    /// Specifies the height of the axis rectangle for a 3D rendering. 0 indicates that it is not in 3D.
//    /// </summary>
//    public int? height_3d = null;

//    /// <summary>
//    /// Specifies how many steps between grid lines. One (1) means a grid line at every value. Two (2) means a grid line at every other value. Etc.
//    /// </summary>
//    public int? steps = null;

//    /// <summary>
//    /// true or false. defaulut=true. Specifies whether or not there should be a small gap between the Y-Axis and the minimum X point.
//    /// </summary>
//    public bool? offset = null;

//    /// <summary>
//    /// Object describing the text labels	{...}	Specifies the attributes for the labels associated with the grid lines.
//    /// </summary>
//    public IList<ChartLabelGroup> labels = new System.Collections.Generic.List<ChartLabelGroup>();

//    public string ToJSON()
//    {
//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("min", min));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("max", max));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke", stroke));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("tick-height", tick_height));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("colour", colour));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("grid-colour", grid_colour));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("3d", height_3d));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("steps", steps));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("offset", offset));
//        if (labels != null && labels.Count > 0)
//        {
//            if (labels.Count > 1)
//            {
//                string diziStr = "";
//                foreach (ChartLabelGroup label in labels)
//                {
//                    diziStr = ChartTool.AddProperty(diziStr, ",", label.ToJSON());
//                }
//                diziStr = "[" + diziStr + "]";
//                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("labels", diziStr));
//            }
//            else
//            {
//                ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("labels", labels[0].ToJSON()));
//            }
//        }
//        if (!string.IsNullOrEmpty(ozellik))
//            ozellik = "{" + ozellik + "}";
//        return ozellik;
//    }

//    public void AddLabel(ChartLabelGroup grafikLabel)
//    {
//        labels.Add(grafikLabel);
//    }
//}

//public enum LegendPosition
//{
//    top, right
//}

///// <summary>
///// This class defines attributes for legend object
///// </summary>
//public class ChartLegend
//{
//    /// <summary>
//    /// Defines the location of the keys legend. If undefined or any value other than “right” then it will be the stand OFC2 legend at the top of the chart.
//    /// “right” - the legend will be placed at the right side of the chart.
//    /// </summary>
//    public LegendPosition position = LegendPosition.top;

//    /// <summary>
//    /// Defines whether or not to draw a line around the right side legend.
//    /// * Has no effect on a “top” legend
//    /// </summary>
//    public bool? border = null;

//    /// <summary>
//    /// Defines the size of the border line around the right side legend.
//    /// * Has no effect on a “top” legend
//    /// </summary>
//    public int? stroke = null;

//    /// <summary>
//    /// Defines whether or not to add a shadow effect to the right side legend.
//    /// * Has no effect on a “top” legend
//    /// </summary>
//    public bool? shadow = null;

//    /// <summary>
//    /// Defines the colour of the line drawn around the right side legend.
//    /// * Has no effect on a “top” legend
//    /// </summary>
//    public string border_colour = null;

//    /// <summary>
//    /// Defines the background colour of the right side legend.
//    /// * Has no effect on a “top” legend
//    /// </summary>
//    public string bg_colour = null;

//    /// <summary>
//    /// Specifies the alpha value for the right side legend. 
//    /// 0 is invisible to 1 is opaque
//    /// * Has no effect on a “top” legend
//    /// </summary>
//    public double? alpha = null;

//    /// <summary>
//    /// Specifies the number of pixel spacing to allow around the outside of the right side legend.
//    /// * Has no effect on a “top” legend
//    /// </summary>
//    public int? margin = null;

//    /// <summary>
//    /// Specifies the number of pixel spacing to allow between the labels and the inside of the right side legend.
//    /// * Has no effect on a “top” legend
//    /// </summary>
//    public int? padding = null;

//    public string ToJSON()
//    {
//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("position", ChartTool.PositionToStr(position)));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("border", border));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("stroke", stroke));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("shadow", shadow));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("border_colour", border_colour));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("bg_colour", bg_colour));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("alpha", alpha));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("margin", margin));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("padding", padding));
//        if (!string.IsNullOrEmpty(ozellik))
//            ozellik = "{" + ozellik + "}";
//        return ozellik;
//    }
//}

//public class OpenFlashStyledText
//{
//    string text;
//    string style;

//    /// <summary>
//    /// 
//    /// </summary>
//    /// <param name="text"></param>
//    /// <param name="style">	 * A css string. Can optionally contain:
//    ///      * - font-size
//    ///      * - font-family
//    ///      * - font-weight
//    ///      * - color
//    ///      * - background-color
//    ///      * - text-align
//    ///      * - margin
//    ///      * - margin-left
//    ///      * - margin-right
//    ///      * - margin-top
//    ///      * - margin-bottom
//    ///      * - padding
//    ///      * - padding-left
//    ///      * - padding-right
//    ///      * - padding-top
//    ///      * - padding-bottom
//    /// </param>
//    public OpenFlashStyledText(string text, string style)
//    {
//        this.text = text;
//        this.style = style;
//    }

//    public string ToJSON()
//    {
//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("text", text));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("style", style));
//        return "{" + ozellik + "}";
//    }

//}

//public class OpenFlashChart
//{
//    string bg_colour = "";

//    public OpenFlashStyledText title;
//    public OpenFlashStyledText x_Legend;
//    public OpenFlashStyledText y_Legend;
//    public ChartXAxis xAxis = null;
//    public ChartYAxis yAxis = null;

//    /// <summary>
//    /// Attributes for legend object
//    /// </summary>
//    public ChartLegend legend = null;

//    IList<ChartElement> elements = new System.Collections.Generic.List<ChartElement>();

//    public OpenFlashChart(string text, string style)
//    {
//        this.title = new OpenFlashStyledText(text, style);
//    }

//    public Color BG_Colour
//    {
//        set
//        {
//            bg_colour = ChartTool.ColorToRGB(value);
//        }
//    }

//    public void SeriEkle(ChartElement seri)
//    {
//        elements.Add(seri);
//    }

//    public string ToJSON()
//    {
//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("title", title.ToJSON()));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("bg_colour", bg_colour));

//        ArrayList renderedGroupList = new ArrayList();
//        if (elements != null && elements.Count > 0)
//        {
//            string diziStr = "";
//            for (int i = 0; i < elements.Count; i++)
//            {
//                ChartElement element = elements[i];
//                if (ChartTool.IsGroupedType(element.type))
//                {
//                    if (!GroupIsRendered(element.type, renderedGroupList))
//                    {
//                        renderedGroupList.Add(element.type);
//                        diziStr = ChartTool.AddProperty(diziStr, ",", MakeGroupJSON(element.type));
//                    }
//                }
//                else
//                    diziStr = ChartTool.AddProperty(diziStr, ",", element.ToJSON());
//            }
//            diziStr = "[" + diziStr + "]";
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("elements", diziStr));
//        }
//        if (xAxis != null)
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("x_axis", xAxis.ToJSON()));
//        if (yAxis != null)
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("y_axis", yAxis.ToJSON()));
//        if (legend != null)
//            ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("legend", legend.ToJSON()));
//        if (renderedGroupList.Count == 0)
//        {
//            //if (x_Legend != null)
//            //    ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("x_legend", x_Legend.ToJSON()));
//            //if (y_Legend != null)
//            //    ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeClass("y_legend", y_Legend.ToJSON()));
//        }

//        return "{" + ozellik + "}";
//    }

//    private bool GroupIsRendered(ChartElementType chartElementType, ArrayList groupRendered)
//    {
//        foreach (ChartElementType cet in groupRendered)
//        {
//            if (cet == chartElementType) return true;
//        }
//        return false;
//    }

//    private string MakeGroupJSON(ChartElementType chartElementType)
//    {
//        ArrayList sameCharts = new ArrayList();
//        int pointCount = 0;
//        foreach (ChartElement element in elements)
//        {
//            if (element.type == chartElementType)
//            {
//                sameCharts.Add(element);
//                pointCount = Math.Max(pointCount, element.ValueCount());
//            }
//        }

//        string ozellik = "";
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("type", ChartTool.ElementTypename(chartElementType)));

//        string valuesStr = "";
//        for (int i = 0; i < pointCount; i++)
//        {
//            string icStr = "";
//            foreach (ChartElement element in sameCharts)
//            {
//                ChartValue cv = element.GetValueAt(i);
//                if (cv == null)
//                    icStr = ChartTool.AddProperty(icStr, ",", "0");
//                else
//                    icStr = ChartTool.AddProperty(icStr, ",", cv.ToJSON(chartElementType));
//            }
//            valuesStr = ChartTool.AddProperty(valuesStr, ",", "[" + icStr + "]");
//        }

//        string colorsStr = "";
//        string keysStr = "";
//        string tip = null;
//        foreach (ChartElement element in sameCharts)
//        {
//            colorsStr = ChartTool.AddProperty(colorsStr, ",", ChartTool.Tirnakli(element.colour));
//            string innerKeyStr = "";
//            innerKeyStr = ChartTool.AddProperty(innerKeyStr, ",", ChartTool.makeProperty("colour", element.colour));
//            innerKeyStr = ChartTool.AddProperty(innerKeyStr, ",", ChartTool.makeProperty("text", element.text));
//            innerKeyStr = ChartTool.AddProperty(innerKeyStr, ",", ChartTool.makeProperty("font-size", 13));
//            keysStr = ChartTool.AddProperty(keysStr, ",", "{" + innerKeyStr + "}");
//            if (tip == null && element.tip != null) tip = element.tip;
//        }


//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeArrayProperty("values", valuesStr));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeArrayProperty("colours", colorsStr));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeArrayProperty("keys", keysStr));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeArrayProperty("keys", keysStr));
//        ozellik = ChartTool.AddProperty(ozellik, ",", ChartTool.makeProperty("tip", tip));
//        return "{" + ozellik + "}";
//    }
//}
#endif