﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.IO;

namespace OrtakClass
{

    public enum RTF_DUSEY_HIZALAMA
    {
        SOLA, SAGA, ORTALI, DENGELI, TANIMSIZ
    }

    public enum RTF_YATAY_HIZALAMA
    {
        USTE, ORTALI, ALTA, DENGELI, TANIMSIZ
    }

    public enum RTF_YAZI_YON
    {
        SOLDANSAGA, ASAGIDANYUKARI, YUKARIDANASAGI, TANIMSIZ
    }

    public enum RTF_ALTCIZGI
    {
        Devamli, Noktali, Cizgili, NoktaCizgili, NoktaNoktaCizgili, Cift, TANIMSIZ
    }

    public enum RTFCizgiStil
    {

        /*   
         * 
         * 
         * 
\brdrdashsm Dash border (small). 
\brdrtnthsg Thick thin border (small). 
\brdrthtnsg Thin thick border (small). 
\brdrtnthtnsg Thin thick thin border (small). 
\brdrtnthmg Thick thin border (medium). 
\brdrthtnmg Thin thick border (medium). 
\brdrtnthtnmg Thin thick thin border (medium). 
\brdrtnthlg Thick thin border (large). 
\brdrthtnlg Thin thick border (large). 
\brdrtnthtnlg Thin thick thin border (large). 
\brdrwavy Wavy border. 
\brdrwavydb Double wavy border. 
\brdrdashdotstr Striped border. 
\brdremboss Emboss border. 
\brdrengrave Engrave border 
         * 
         * 
         * */

        Single_thickness, Double_thickness, Shadowed, Double, Dotted, Dashed, Dot_Dash, Dot_Dot_Dash, Hairline, TANIMSIZ//, KESIK, NOKTA, CIFT
    }

    public enum RTFKenarYer
    {
        SOL = 0, SAG = 1, UST = 2, ALT = 3, YATAY = 4, DUSEY = 5
    }

    public enum RTFParagrafYer
    {
        DOKUMAN, SATIR, HUCREYAZI, HUCREFORMAT
    }

    public class RTFKenar
    {
        public RTFKenarYer kenarYer;
        public RTFCizgiStil cizgiStil = RTFCizgiStil.TANIMSIZ;
        /// <summary>
        /// 75'i geçemiyor
        /// </summary>
        public int cizgiKalinlik = 0;
        public int renk = 0;
        public int yaziAraligi = 0;


        public RTFKenar()
        {
        }

        public RTFKenar(RTFKenar kaynak)
        {
            kenarYer = kaynak.kenarYer;
            cizgiStil = kaynak.cizgiStil;
            cizgiKalinlik = kaynak.cizgiKalinlik;
            renk = kaynak.renk;
            yaziAraligi = kaynak.yaziAraligi;
        }

        public RTFKenar(RTFKenarYer kenarYer, RTFCizgiStil cizgiStil, int cizgiKalinlik)
        {
            this.kenarYer = kenarYer;
            this.cizgiStil = cizgiStil;
            this.cizgiKalinlik = cizgiKalinlik;
        }

        private string KenarharfBul()
        {
            if (kenarYer == RTFKenarYer.ALT) return "b";
            if (kenarYer == RTFKenarYer.SAG) return "r";
            if (kenarYer == RTFKenarYer.SOL) return "l";
            if (kenarYer == RTFKenarYer.UST) return "t";
            if (kenarYer == RTFKenarYer.YATAY) return "h";
            if (kenarYer == RTFKenarYer.DUSEY) return "v";
            return "t";
        }

        public void SaveAsCell(TextWriter tw)
        {
            Save(tw, "cl");
        }

        public void SaveAsRow(TextWriter tw)
        {
            Save(tw, "tr");
        }

        public void Save(TextWriter tw)
        {
            Save(tw, "");
        }

        private void Save(TextWriter tw, string onEk)
        {
            if (cizgiStil != RTFCizgiStil.TANIMSIZ || cizgiKalinlik != 0)
            {
                tw.Write("\\" + onEk + "brdr" + KenarharfBul());
                if (cizgiStil != RTFCizgiStil.TANIMSIZ)
                    tw.Write("\\brdr" + CizgiStilHarfBul());
                RTFDocument.SayisalPropYaz(tw, "brdrw", cizgiKalinlik, 0, true);
                RTFDocument.SayisalPropYaz(tw, "brdrcf", renk, 0, true);
                RTFDocument.SayisalPropYaz(tw, "brsp", yaziAraligi, 0, true);
            }
        }

        internal void Birlestir(RTFKenar bKenar)
        {
            BirlestirAta(bKenar, false);
        }

        internal void BirlestirAta(RTFKenar bKenar, bool ata)
        {
            if (kenarYer != bKenar.kenarYer)
                return;
            if (cizgiStil == RTFCizgiStil.TANIMSIZ || ata) cizgiStil = bKenar.cizgiStil;
            if (cizgiKalinlik == 0 || ata) cizgiKalinlik = bKenar.cizgiKalinlik;
        }

        private string CizgiStilHarfBul()
        {
            if (cizgiStil == RTFCizgiStil.Single_thickness)
                return "s";
            else if (cizgiStil == RTFCizgiStil.Double_thickness)
                return "th";
            else if (cizgiStil == RTFCizgiStil.Shadowed)
                return "sh";
            else if (cizgiStil == RTFCizgiStil.Double)
                return "db";
            else if (cizgiStil == RTFCizgiStil.Dotted)
                return "dot";
            else if (cizgiStil == RTFCizgiStil.Dashed)
                return "dash";
            else if (cizgiStil == RTFCizgiStil.Hairline)
                return "hair";
            else if (cizgiStil == RTFCizgiStil.Dot_Dash)
                return "dashd";
            else if (cizgiStil == RTFCizgiStil.Dot_Dot_Dash)
                return "dashdd";
            return "s";
        }
    }

    public class RTFKenarlik
    {
        private ArrayList kenarlar = new ArrayList();

        public RTFKenar KenarEkle(RTFKenar kenar, bool ata)
        {
            RTFKenar bulunan = Bul(kenar.kenarYer);
            if (bulunan == null)
                kenarlar.Add(kenar);
            else
                bulunan.BirlestirAta(kenar, ata);

            return kenar;
        }

        public RTFKenar KenarEkle(RTFKenar kenar)
        {
            return KenarEkle(kenar, true);
        }

        public void SaveAsCell(TextWriter tw)
        {
            for (int i = 0; i < kenarlar.Count; i++)
            {
                ((RTFKenar)kenarlar[i]).SaveAsCell(tw);
            }
        }

        public void SaveAsRow(TextWriter tw)
        {
            for (int i = 0; i < kenarlar.Count; i++)
            {
                ((RTFKenar)kenarlar[i]).SaveAsRow(tw);
            }
        }

        internal void Save(TextWriter tw)
        {
            for (int i = 0; i < kenarlar.Count; i++)
            {
                ((RTFKenar)kenarlar[i]).Save(tw);
            }
        }

        internal void Birlestir(RTFKenarlik bKenarlik)
        {
            if (bKenarlik == null)
                return;
            for (int i = 0; i < bKenarlik.kenarlar.Count; i++)
            {
                KenarEkle(new RTFKenar((RTFKenar)bKenarlik.kenarlar[i]), false);
            }
        }

        private RTFKenar Bul(RTFKenarYer rTFKenarYer)
        {
            for (int i = 0; i < kenarlar.Count; i++)
            {
                RTFKenar bKenar = (RTFKenar)kenarlar[i];
                if (bKenar.kenarYer == rTFKenarYer)
                    return bKenar;
            }
            return null;
        }
    }

    public class RTFParagrafFormat
    {
        private RTF_DUSEY_HIZALAMA duseyHizalama = RTF_DUSEY_HIZALAMA.TANIMSIZ;
        public RTF_DUSEY_HIZALAMA DuseyHizalama
        {
            get { return duseyHizalama; }
            set { duseyHizalama = value; }
        }

        private RTF_YATAY_HIZALAMA yatayHizalama = RTF_YATAY_HIZALAMA.TANIMSIZ;
        public RTF_YATAY_HIZALAMA YatayHizalama
        {
            get { return yatayHizalama; }
            set { yatayHizalama = value; }
        }

        private RTFKenarlik kenarlik = null;
        public RTFKenarlik Kenarlik
        {
            get { return kenarlik; }
            set { kenarlik = value; }
        }

        public RTF_YAZI_YON yaziYon = RTF_YAZI_YON.TANIMSIZ;

        public int solGirinti = 0;
        public int sagGirinti = 0;
        public int ilkGirinti = 0;

        public int onceBosluk = 0;
        public int sonraBosluk = 0;
        public int satirAralik = 0;

        public int stilNo = 0;

        public RTFParagrafFormat()
        {
        }
        public RTFParagrafFormat(RTFParagrafFormat kaynak)
        {
            Birlestir(kaynak);
        }

        public void Birlestir(RTFParagrafFormat eklenecek)
        {
            if (eklenecek == null) return;
            if (duseyHizalama == RTF_DUSEY_HIZALAMA.TANIMSIZ) duseyHizalama = eklenecek.DuseyHizalama;
            if (yatayHizalama == RTF_YATAY_HIZALAMA.TANIMSIZ) yatayHizalama = eklenecek.YatayHizalama;
            if (kenarlik == null) kenarlik = new RTFKenarlik();
            kenarlik.Birlestir(eklenecek.Kenarlik);

            if (solGirinti == 0) solGirinti = eklenecek.solGirinti;
            if (sagGirinti == 0) sagGirinti = eklenecek.sagGirinti;
            if (ilkGirinti == 0) ilkGirinti = eklenecek.ilkGirinti;

            if (onceBosluk == 0) onceBosluk = eklenecek.onceBosluk;
            if (sonraBosluk == 0) sonraBosluk = eklenecek.sonraBosluk;
            if (satirAralik == 0) satirAralik = eklenecek.satirAralik;
            if (yaziYon == RTF_YAZI_YON.TANIMSIZ) yaziYon = eklenecek.yaziYon;
            if (stilNo == 0) stilNo = eklenecek.stilNo;
        }

        public void Save(TextWriter tw, RTFParagrafYer pYer)
        {
            bool boslukYaz = false;
            string inTableOnEk;
            if (pYer == RTFParagrafYer.HUCREFORMAT)
                inTableOnEk = "cl";
            else if (pYer == RTFParagrafYer.SATIR)
                inTableOnEk = "tr";
            else
                inTableOnEk = "";

            if (pYer == RTFParagrafYer.HUCREYAZI)
            {
                if (duseyHizalama != RTF_DUSEY_HIZALAMA.TANIMSIZ)
                {
                    boslukYaz = true;
                    tw.Write("\\q" + HarfBulDuseyHizalama(duseyHizalama));
                }
            }
            if (pYer != RTFParagrafYer.HUCREYAZI)
            {
                if (kenarlik != null)
                {
                    if (pYer == RTFParagrafYer.HUCREFORMAT)
                        kenarlik.SaveAsCell(tw);
                    else if (pYer == RTFParagrafYer.SATIR)
                        kenarlik.SaveAsRow(tw);
                    else
                        kenarlik.Save(tw);
                }

                if (pYer == RTFParagrafYer.HUCREFORMAT)
                {
                    if (yaziYon == RTF_YAZI_YON.ASAGIDANYUKARI)
                    {
                        boslukYaz = true;
                        tw.Write("\\cltxbtlr");
                    }
                    else if (yaziYon == RTF_YAZI_YON.YUKARIDANASAGI)
                    {
                        boslukYaz = true;
                        tw.Write("\\cltxtbrl");
                    }
                }
                if (yatayHizalama != RTF_YATAY_HIZALAMA.TANIMSIZ)
                {
                    boslukYaz = true;
                    tw.Write("\\" + inTableOnEk + "vertal" + HarfBulYatayHizalama(yatayHizalama));
                }
                if (stilNo > 0)
                {
                    boslukYaz = true;
                    tw.Write("\\s" + stilNo);
                }

                boslukYaz = RTFDocument.SayisalPropYaz(tw, "fi", ilkGirinti, 0, boslukYaz);
                boslukYaz = RTFDocument.SayisalPropYaz(tw, "li", solGirinti, 0, boslukYaz);
                boslukYaz = RTFDocument.SayisalPropYaz(tw, "ri", sagGirinti, 0, boslukYaz);
                boslukYaz = RTFDocument.SayisalPropYaz(tw, "sb", onceBosluk, 0, boslukYaz);
                boslukYaz = RTFDocument.SayisalPropYaz(tw, "sa", sonraBosluk, 0, boslukYaz);
                boslukYaz = RTFDocument.SayisalPropYaz(tw, "sl", satirAralik, 0, boslukYaz);
            }

            if (boslukYaz)
                tw.Write(" ");
        }

        private string HarfBulYatayHizalama(RTF_YATAY_HIZALAMA yatayHizalama)
        {
            if (yatayHizalama == RTF_YATAY_HIZALAMA.ALTA)
                return "b";
            else if (yatayHizalama == RTF_YATAY_HIZALAMA.DENGELI)
                return "j";
            else if (yatayHizalama == RTF_YATAY_HIZALAMA.ORTALI)
                return "c";
            else
                return "t";
        }

        private string HarfBulDuseyHizalama(RTF_DUSEY_HIZALAMA duseyHizalama)
        {
            if (duseyHizalama == RTF_DUSEY_HIZALAMA.DENGELI)
                return "j";
            else if (duseyHizalama == RTF_DUSEY_HIZALAMA.SAGA)
                return "r";
            else if (duseyHizalama == RTF_DUSEY_HIZALAMA.ORTALI)
                return "c";
            else
                return "l";

        }

        internal static RTFParagrafFormat Birlestir(params RTFParagrafFormat[] rTFParagrafFormat)
        {
            RTFParagrafFormat format = new RTFParagrafFormat();
            for (int i = 0; i < rTFParagrafFormat.Length; i++)
            {
                format.Birlestir(rTFParagrafFormat[i]);
            }
            return format;
        }

    }

    public class RTFYaziFormat
    {
        private int fontSize = 0;

        public int FontSize
        {
            get { return fontSize; }
            set { fontSize = value; }
        }

        private bool bold = false;
        public bool Bold
        {
            get { return bold; }
            set { bold = value; }
        }

        private bool italik = false;
        public bool Italik
        {
            get { return italik; }
            set { italik = value; }
        }

        private int fontNumber = 0;
        public int FontNumber
        {
            get { return fontNumber; }
            set { fontNumber = value; }
        }


        private RTF_ALTCIZGI altCizgi = RTF_ALTCIZGI.TANIMSIZ;
        public RTF_ALTCIZGI AltCizgi
        {
            get { return altCizgi; }
            set { altCizgi = value; }
        }

        int yaziRengi = 0;
        public int YaziRengi
        {
            get { return yaziRengi; }
            set { yaziRengi = value; }
        }

        int arkaPlanRengi = 0;
        public int ArkaPlanRengi
        {
            get { return arkaPlanRengi; }
            set { arkaPlanRengi = value; }
        }

        public RTFYaziFormat(int fontNumber, int fontSize, bool bold)
        {
            FontNumber = fontNumber;
            FontSize = fontSize;
            Bold = bold;
        }

        public void Save(TextWriter tw)
        {
            tw.Write("\\plain");
            if (bold)
                tw.Write("\\b");
            if (italik)
                tw.Write("\\i");
            RTFDocument.SayisalPropYaz(tw, "f", FontNumber, 0, true);
            RTFDocument.SayisalPropYaz(tw, "fs", FontSize, 0, true);
            //BARIS: RTFDocument.SayisalPropYaz(tw, "cb", arkaPlanRengi, 0, true);
            RTFDocument.SayisalPropYaz(tw, "chcbpat", arkaPlanRengi, 0, true);//BARIS
            RTFDocument.SayisalPropYaz(tw, "cf", yaziRengi, 0, true);
            if (AltCizgi != RTF_ALTCIZGI.TANIMSIZ)
                tw.Write("\\ul" + AltCizgiHarfBul(AltCizgi));
            tw.Write(" ");
        }

        private string AltCizgiHarfBul(RTF_ALTCIZGI AltCizgi)
        {
            if (AltCizgi == RTF_ALTCIZGI.Noktali) return "d";
            else if (AltCizgi == RTF_ALTCIZGI.Cizgili) return "dash";
            else if (AltCizgi == RTF_ALTCIZGI.NoktaCizgili) return "dashd";
            else if (AltCizgi == RTF_ALTCIZGI.NoktaNoktaCizgili) return "dashdd";
            else if (AltCizgi == RTF_ALTCIZGI.Cift) return "db";
            return "";
        }
    }


    public abstract class RTFDokumanParca
    {
        protected ArrayList parcalar;
        protected Hashtable ozellikler;

        public virtual RTFDokumanParca ParcaEkle(RTFDokumanParca parca)
        {
            parcalar.Add(parca);
            return parca;
        }

        public virtual void OzellikEkle(string ozellikAd, object ozellik)
        {
            ozellikler[ozellikAd] = ozellik;
        }

        public RTFDokumanParca()
        {
            parcalar = new ArrayList();
            ozellikler = new Hashtable();
        }


        public virtual RTFDokumanParca this[int index]
        {
            get { return (RTFDokumanParca)parcalar[index]; }
            set { parcalar[index] = value; }
        }

        public virtual void Save(System.IO.TextWriter tw)
        {
            ParcaYazBasla(tw);
            if (parcalar != null)
            {
                for (int i = 0; i < parcalar.Count; i++)
                {
                    RTFDokumanParca p = (RTFDokumanParca)parcalar[i];
                    p.Save(tw);
                }
            }
            ParcaYazBitir(tw);
        }

        public virtual void ParcaYazBitir(System.IO.TextWriter tw)
        {
        }

        public virtual void ParcaYazBasla(System.IO.TextWriter tw)
        {
        }
    }

    public class RTFDocument : RTFDokumanParca
    {
        public override void ParcaYazBasla(TextWriter tw)
        {
            tw.Write("{\\rtf1 ");
        }

        public override void ParcaYazBitir(TextWriter tw)
        {
            tw.Write("}");
        }

        public static int CMtoTwips(double cm)
        {
            return (int)(cm * 566.929133858268);
        }

        internal static bool SayisalPropYaz(TextWriter tw, string tag, int deger, int yazmaDeger, bool yazildiMi)
        {
            if (deger != yazmaDeger)
            {
                tw.Write("\\" + tag + deger);
                return true;
            }
            else
                return yazildiMi;
        }
    }

    public abstract class RTFHucre : RTFDokumanParca
    {
        internal static void SaveBosFormat(TextWriter tw, RTFParagrafFormat format, int sagKenarPos)
        {
            if (format != null)
                format.Save(tw, RTFParagrafYer.HUCREFORMAT);
            tw.Write("\\cellx" + sagKenarPos.ToString() + " ");
        }

        internal static void BosHucreYaz(TextWriter tw)
        {
            tw.Write("\\cell");
        }
        public abstract void SaveFormat(TextWriter tw, int sagKenarPos);

    }

    public class RTFHucreBirlesmis : RTFHucre
    {
        public bool Satirda;
        public bool Sutunda;
        RTFHucreVeri KaynakHucre;

        public RTFHucreBirlesmis(RTFHucreVeri kaynakHucre, bool satirda, bool sutunda)
        {
            Satirda = satirda;
            Sutunda = sutunda;
            KaynakHucre = kaynakHucre;
        }

        public override void SaveFormat(TextWriter tw, int sagKenarPos)
        {
            if (KaynakHucre != null && KaynakHucre.ParagrafFormat != null)
                KaynakHucre.ParagrafFormat.Save(tw, RTFParagrafYer.HUCREFORMAT);

            if (Satirda)
                tw.Write("\\clmrg");
            if (Sutunda)
                tw.Write("\\clvmrg");
            tw.Write("\\cellx" + sagKenarPos.ToString() + " ");
        }

        public override void Save(TextWriter tw)
        {
            RTFHucre.BosHucreYaz(tw);
        }
    }

    public class RTFHucreVeri : RTFHucre
    {
        private bool satirBirlesikAna = false;

        public bool SatirBirlesikAna
        {
            get { return satirBirlesikAna; }
            set { satirBirlesikAna = value; }
        }

        private bool sutunBirlesikAna = false;
        public bool SutunBirlesikAna
        {
            get { return sutunBirlesikAna; }
            set { sutunBirlesikAna = value; }
        }

        private RTFParagrafFormat paragrafFormat = new RTFParagrafFormat();
        public RTFParagrafFormat ParagrafFormat
        {
            get { return paragrafFormat; }
            set { paragrafFormat = value; }
        }

        public override void SaveFormat(TextWriter tw, int sagKenarPos)
        {
            if (ParagrafFormat != null)
                ParagrafFormat.Save(tw, RTFParagrafYer.HUCREFORMAT);

            if (SatirBirlesikAna)
                tw.Write("\\clmgf");
            if (SutunBirlesikAna)
                tw.Write("\\clvmgf");

            tw.Write("\\cellx" + sagKenarPos.ToString() + " ");
        }

        public override void ParcaYazBasla(System.IO.TextWriter tw)
        {
            tw.Write("\\intbl\\pard");
            if (ParagrafFormat != null)
                ParagrafFormat.Save(tw, RTFParagrafYer.HUCREYAZI);
        }

        public override void ParcaYazBitir(System.IO.TextWriter tw)
        {
            tw.Write("\\cell");
        }
    }

    public class RTFSatir : RTFDokumanParca
    {
        private RTFParagrafFormat satirFormat;

        public RTFParagrafFormat SatirFormat
        {
            get { return satirFormat; }
            set { satirFormat = value; }
        }

        private int yukseklik;
        public int Yukseklik
        {
            get { return yukseklik; }
            set { yukseklik = value; }
        }

        public RTFSatir(int yukseklik)
        {
            Yukseklik = yukseklik;
        }

        public RTFSatir()
        {
            yukseklik = 0;
        }

        ArrayList hucreler = new ArrayList();
        public new RTFHucre this[int index]
        {
            get
            {
                if (index < hucreler.Count)
                    return (RTFHucre)hucreler[index];
                return null;
            }
            set
            {
                if (index < hucreler.Count)
                    hucreler[index] = value;
                else
                {
                    for (int i = 0; hucreler.Count < index; i++)
                    {
                        hucreler.Add(null);
                    }
                    hucreler.Add(value);
                }
            }
        }

        public override void ParcaYazBasla(TextWriter tw)
        {
            tw.Write("{\\trowd");
            if (Yukseklik != 0)
                tw.Write("\\trrh" + Yukseklik);
            if (satirFormat != null)
                satirFormat.Save(tw, RTFParagrafYer.SATIR);
            tw.Write(" ");
        }

        public override void ParcaYazBitir(TextWriter tw)
        {
            tw.Write("\\row}");
        }

        public void Save(TextWriter tw, RTFTable rtfTable)
        {
            int sagKenarYeri = 0;
            ParcaYazBasla(tw);
            for (int j = 0; j < rtfTable.SutunSay; j++)
            {
                sagKenarYeri += rtfTable.Genislik(j);
                if (this[j] != null)
                {
                    this[j].SaveFormat(tw, sagKenarYeri);
                }
                else
                {
                    RTFHucre.SaveBosFormat(tw, rtfTable.DefHucreFormat, sagKenarYeri);
                }
            }
            for (int j = 0; j < rtfTable.SutunSay; j++)
            {
                if (this[j] != null)
                {
                    this[j].Save(tw);
                }
                else
                    RTFHucre.BosHucreYaz(tw);
            }
            ParcaYazBitir(tw);
        }
    }

    public class RTFSutun : RTFDokumanParca
    {
        private int genislik;

        public int Genislik
        {
            get { return genislik; }
            set { genislik = value; }
        }

        public RTFSutun(int genislik)
        {
            Genislik = genislik;
        }

        public RTFSutun()
        {
            Genislik = 0;
        }
    }

    public class RTFTable : RTFDokumanParca
    {
        ArrayList satirlar = new ArrayList();
        ArrayList sutunlar = new ArrayList();
        //
        private RTFParagrafFormat defHucreFormat;

        public RTFParagrafFormat DefHucreFormat
        {
            get { return defHucreFormat; }
            set { defHucreFormat = value; }
        }

        private int defYukseklik;
        public int DefYukseklik
        {
            get { return defYukseklik; }
            set { defYukseklik = value; }
        }

        private int defGenislik;
        public int DefGenislik
        {
            get { return defGenislik; }
            set { defGenislik = value; }
        }

        public int Genislik(int sut)
        {
            if (sutunlar[sut] == null)
                return defGenislik;
            int tut = ((RTFSutun)sutunlar[sut]).Genislik;
            if (tut == 0)
                return defGenislik;
            return tut;
        }

        public override RTFDokumanParca ParcaEkle(RTFDokumanParca parca)
        {
            if (parca.GetType() == typeof(RTFSatir))
                satirlar.Add(parca);
            else if (parca.GetType() == typeof(RTFSutun))
                sutunlar.Add(parca);
            else
                throw new Exception("Satır gelmeli!");
            return parca;
        }

        public RTFSatir SatirEkle(RTFSatir satir)
        {
            satirlar.Add(satir);
            if (satir.Yukseklik == 0)
                satir.Yukseklik = DefYukseklik;
            return satir;
        }

        public RTFSatir Satir(int satNo)
        {
            if (satNo < satirlar.Count)
                return (RTFSatir)satirlar[satNo];
            else
                return null;
        }

        public RTFSutun SutunEkle(RTFSutun sutun)
        {
            sutunlar.Add(sutun);
            if (sutun.Genislik == 0)
                sutun.Genislik = DefGenislik;
            return sutun;
        }

        public RTFSutun Sutun(int sutNo)
        {
            if (sutNo < sutunlar.Count)
                return (RTFSutun)sutunlar[sutNo];
            else
                return null;
        }


        public RTFHucre this[int sat, int sut]
        {
            get
            {
                if (satirlar.Count > sat)
                {
                    return ((RTFSatir)satirlar[sat])[sut];
                }
                else
                    return null;
            }

            set
            {
                if (value.GetType() == typeof(RTFHucreVeri))
                {
                    RTFHucreVeri icHucre = (RTFHucreVeri)value;
                    if (icHucre.ParagrafFormat == null)
                        icHucre.ParagrafFormat = new RTFParagrafFormat(DefHucreFormat);
                    else
                        icHucre.ParagrafFormat = RTFParagrafFormat.Birlestir(icHucre.ParagrafFormat, DefHucreFormat);
                }
                ((RTFSatir)satirlar[sat])[sut] = value;
            }
        }

        public int SatirSay
        {
            get { return satirlar.Count; }
            set
            {
                if (satirlar.Count < value)
                {
                    for (int i = 0; satirlar.Count < value; i++)
                    {
                        SatirEkle(new RTFSatir());
                    }
                }
                else if (satirlar.Count > value)
                {
                    satirlar.RemoveRange(value, satirlar.Count - value);
                }
            }
        }

        public int SutunSay
        {
            get { return sutunlar.Count; }
            set
            {
                if (sutunlar.Count < value)
                {
                    for (int i = 0; sutunlar.Count < value; i++)
                    {
                        SutunEkle(new RTFSutun());
                    }
                }
                else if (sutunlar.Count > value)
                {
                    sutunlar.RemoveRange(value, sutunlar.Count - value);
                }
            }
        }

        public RTFTable()
        {
            DefYukseklik = 0;
            DefGenislik = RTFDocument.CMtoTwips(2.5);
        }

        public override void Save(System.IO.TextWriter tw)
        {
            for (int i = 0; i < SatirSay; i++)
            {
                ((RTFSatir)satirlar[i]).Save(tw, this);
            }
        }

        public void DuseyHizala(int baslaSut, int say, RTF_DUSEY_HIZALAMA duseyHiza)
        {
            for (int i = 0; i < SatirSay; i++)
            {
                for (int j = 0; j < say; j++)
                {
                    RTFHucre hcr = this[i, j + baslaSut];
                    if (hcr.GetType() == typeof(RTFHucreVeri))
                    {
                        RTFHucreVeri icHcr = (RTFHucreVeri)hcr;
                        if (icHcr.ParagrafFormat == null)
                            icHcr.ParagrafFormat = new RTFParagrafFormat();
                        icHcr.ParagrafFormat.DuseyHizalama = duseyHiza;

                    }
                }

            }
        }

        public void HucreBirlestir(int baslaSat, int baslaSut, int satSay, int sutSay)
        {
            if ((baslaSat >= 0) && (baslaSut >= 0) && (satSay > 0) && (sutSay > 0) && (baslaSat + satSay <= SatirSay) && (baslaSut + sutSay <= SutunSay))
            {
                RTFHucre hucre = this[baslaSat, baslaSut];
                if (hucre == null)
                {
                    hucre = new RTFHucreVeri();
                    this[baslaSat, baslaSut] = hucre;
                }
                else if (hucre.GetType() != typeof(RTFHucreVeri))
                    return;
                RTFHucreVeri icHucre = (RTFHucreVeri)hucre;
                if (satSay > 1)
                {
                    icHucre.SutunBirlesikAna = true;
                }
                if (sutSay > 1)
                {
                    icHucre.SatirBirlesikAna = true;
                }
                for (int i = 0; i < satSay; i++)
                {
                    for (int j = 0; j < sutSay; j++)
                    {
                        if (i > 0 || j > 0)
                        {
                            this[baslaSat + i, baslaSut + j] = new RTFHucreBirlesmis(icHucre, icHucre.SatirBirlesikAna, icHucre.SutunBirlesikAna);
                        }
                    }
                }
            }
        }

        private void KenarAta(int sat, int sut, RTFKenar rtfKenar)
        {
            if (rtfKenar == null)
                return;
            RTFHucreVeri hucre;
            if (this[sat, sut] == null)
            {
                hucre = new RTFHucreVeri();
                this[sat, sut] = hucre;
            }
            else if (this[sat, sut].GetType() == typeof(RTFHucreVeri))
            {
                hucre = (RTFHucreVeri)this[sat, sut];
            }
            else
                return;
            if (hucre.ParagrafFormat == null)
                hucre.ParagrafFormat = new RTFParagrafFormat(DefHucreFormat);
            if (hucre.ParagrafFormat.Kenarlik == null)
                hucre.ParagrafFormat.Kenarlik = new RTFKenarlik();
            hucre.ParagrafFormat.Kenarlik.KenarEkle(rtfKenar);
        }


        public void KenarCizSatir(int sat, int sut1, int sut2, RTFKenar rtfKenar)
        {
            for (int i = sut1; i <= sut2; i++)
            {
                KenarAta(sat, i, rtfKenar);
            }
        }

        public void KenarCizSutun(int sut, int sat1, int sat2, RTFKenar rtfKenar)
        {
            for (int j = sat1; j <= sat2; j++)
            {
                KenarAta(j, sut, rtfKenar);
            }
        }
    }

    public class RTFParagraf : RTFDokumanParca
    {
        private RTFParagrafFormat paragrafFormat;

        public RTFParagrafFormat ParagrafFormat
        {
            get { return paragrafFormat; }
            set { paragrafFormat = value; }
        }
    }

    public class RTFFormatliYazi : RTFDokumanParca
    {
        private RTFYaziFormat format;

        public RTFYaziFormat Format
        {
            get { return format; }
            set { format = value; }
        }

        string text;
        public RTFFormatliYazi(string text, RTFYaziFormat format)
        {
            this.text = text;
            this.format = format;
        }

        public RTFFormatliYazi(string text)
        {
            this.text = text;
            this.format = null;
        }

        public override RTFDokumanParca ParcaEkle(RTFDokumanParca parca)
        {
            return null;
        }

        public override void OzellikEkle(string ozellikAd, object ozellik)
        {
        }

        public override void ParcaYazBasla(System.IO.TextWriter tw)
        {
            if (format != null)
                format.Save(tw);
            else
                tw.Write("\\plain ");
            tw.Write(text);
        }
    }

    public class RTFDeneme
    {
    }
}
