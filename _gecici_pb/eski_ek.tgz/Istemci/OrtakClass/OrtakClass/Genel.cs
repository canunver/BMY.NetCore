﻿using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS;
using TNS.BKD;
using TNS.DEG;
using TNS.KYM;
using System.Xml;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web;
using FarPoint.Win.Ribbon.Properties;

namespace OrtakClass
{
    public class sizma : System.Web.IHttpHandler
    {
        /// <summary>
        /// Reusable durumunu döndüren özellik
        /// </summary>
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public void ProcessRequest(HttpContext context)
        {
            GenelIslemler.SizmaBilgiOl(context.Request);
            context.Response.ContentType = "text/plain";
            context.Response.Write("Beklenmeyen bir hata oluştu.");
        }
    }

    public class FarPointCellTypes
    {
        public static FarPoint.Web.Spread.GeneralCellType customCurrencyType;
        public static FarPoint.Web.Spread.GeneralCellType customCurrencyType2;
        public static FarPoint.Web.Spread.GeneralCellType kesirli4;
        public static FarPoint.Web.Spread.TextCellType customCokSatirli;
        public static FarPoint.Web.Spread.TextCellType customTekSatirli;
        static FarPointCellTypes()
        {
            customCurrencyType = new FarPoint.Web.Spread.GeneralCellType();
            System.Globalization.NumberFormatInfo ninfo = new System.Globalization.NumberFormatInfo();
            ninfo.NumberGroupSeparator = ".";
            ninfo.NumberDecimalSeparator = ",";
            ninfo.NumberDecimalDigits = 0;
            customCurrencyType.FormatString = "#,###";
            customCurrencyType.NumberFormat = ninfo;
            customCurrencyType.AllowWrap = false;


            customCurrencyType2 = new FarPoint.Web.Spread.GeneralCellType();
            System.Globalization.NumberFormatInfo ninfo2 = new System.Globalization.NumberFormatInfo();
            ninfo2.NumberGroupSeparator = ".";
            ninfo2.NumberDecimalSeparator = ",";
            ninfo2.NumberDecimalDigits = 2;
            customCurrencyType2.FormatString = "#,##0.00";
            customCurrencyType2.NumberFormat = ninfo2;
            customCurrencyType2.AllowWrap = false;

            kesirli4 = new FarPoint.Web.Spread.GeneralCellType();
            System.Globalization.NumberFormatInfo ninfo4 = new System.Globalization.NumberFormatInfo();
            ninfo4.NumberGroupSeparator = ".";
            ninfo4.NumberDecimalSeparator = ",";
            ninfo4.NumberDecimalDigits = 4;
            kesirli4.FormatString = "#,##0.00";
            kesirli4.NumberFormat = ninfo4;
            kesirli4.AllowWrap = false;

            customCokSatirli = new FarPoint.Web.Spread.TextCellType();
            customCokSatirli.Multiline = true;
            customCokSatirli.AllowWrap = true;

            customTekSatirli = new FarPoint.Web.Spread.TextCellType();
            customTekSatirli.Multiline = false;
            customTekSatirli.AllowWrap = false;

        }
    }

    public enum ENUMSatirIslemTur
    {
        Tanimsiz = 0,
        ArayaEkle = 1,
        SonaEkle = 2,
        SatirSil = 3,
    }

    public class GenelIslemlerIstemci
    {
        public static string EvrakXMLOlustur(string evrakBirimKodu, string prEvrakNo, string konu, int gelenGiden, string gidecegiYer, string dosyaKodu, string aciklama, string ekAd, string ekIcerik)
        {
            string[,] ekler = new string[1, 2];
            ekler[0, 0] = ekAd;
            ekler[0, 1] = ekIcerik;

            return EvrakXMLOlustur(evrakBirimKodu, prEvrakNo, konu, gelenGiden, gidecegiYer, dosyaKodu, aciklama, ekler);
        }

        public static string EvrakXMLOlustur(string evrakBirimKodu, string prEvrakNo, string konu, int gelenGiden, string gidecegiYer, string dosyaKodu, string aciklama, string[,] ekler)
        {
            string xml =
               "<EVRAK>" +
               "<BILGI>" +
               "<PREVRAKNO>" + prEvrakNo + "</PREVRAKNO>" +
               "<EVRAKBIRIMKODU>" + evrakBirimKodu + "</EVRAKBIRIMKODU>" +//birim kodunu bulmak lazım-muhasebebirim kodunu ver evrak birimkodunu al
               "<KONU>" + konu + "</KONU>" +
               "<EVRAKTURU>" + gelenGiden + "</EVRAKTURU>" +
               "<GIDECEGIYER>" + gidecegiYer + "</GIDECEGIYER>" +
               "<DOSYAKODU>" + dosyaKodu + "</DOSYAKODU>" +
               "<IMZAYOLU></IMZAYOLU>" +
               "<GIZLILIK></GIZLILIK>" +
               "<YAZIDURUM></YAZIDURUM>" +
               "<ACIKLAMA>" + aciklama + "</ACIKLAMA>" +
               "<DOSYANO></DOSYANO>" +
               "<EK></EK>" +
               "<DAGITIMLAR>" +
                      "<DAGITIM>" +
                             "<KOD></KOD>" +
                             "<AD></AD>" +
                      "</DAGITIM>" +
               "</DAGITIMLAR>" +
               "<EVRAKILGILER>" +
                      "<EVRAKILGI>" +
                           "<TARIH></TARIH>" +
                           "<AD></AD>" +
                      "</EVRAKILGI>" +
               "</EVRAKILGILER>" +
               "<ANTET></ANTET>" +
               "<ICERIK></ICERIK>" +
               "<EKYAZIALAN></EKYAZIALAN>" +
               "<PARAF></PARAF>" +
               "<ALTBILGI></ALTBILGI>" +
               "<IMZA1></IMZA1>" +
               "<IMZA2></IMZA2>" +
               "<IMZA3></IMZA3>" +
               "<EKLER>";

            for (int i = 0; i <= ekler.GetUpperBound(0); i++)
            {
                xml += "<EK AD='" + ekler[i, 0] + "'>" + ekler[i, 1] + "</EK>";
            }

            xml += "</EKLER>" +
                   "</BILGI>" +
                   "</EVRAK>";// method olarak yaz

            return xml;
        }



        public static int HashIntAl(Hashtable raporParam, string key, int defValue)
        {
            try
            {
                string deger = (string)raporParam[key];
                return OrtakFonksiyonlar.ConvertToInt(deger, defValue);
            }
            catch { return defValue; }
        }

        public static string HashStrAl(Hashtable raporParam, string key, string defValue)
        {
            try
            {
                return (string)raporParam[key];
            }
            catch { return defValue; }
        }

        public static bool SifresizBolumYok()
        {
            return true;

            string sifresizBolumYok = TNS.DEG.Arac.DegiskenDegerBul(DateTime.Now.Year, "SIFRESIZBOLUMYOK");//DEgisken.xml
            int sifresiBolumYok = OrtakFonksiyonlar.ConvertToInt(GenelIslemler.WebConfigOku("SifresizBolumYok", "0"), 0);//web.config
            if ((!string.IsNullOrEmpty(sifresizBolumYok) && sifresizBolumYok == "1") || sifresiBolumYok > 0)
                return true;
            else
                return false;
        }

        public static object[] Iller = null;

        /// <summary>
        /// İl bilgisini listeyen fonksiyon.
        /// </summary>
        /// <returns></returns>
        public static object[] IlYukle()
        {
            if (Iller == null)
            {
                DropDownList ddlIltmp = new DropDownList();
                GenelIslemlerIstemci.DDLKodDoldur(ddlIltmp, 0, "20", "", 3, true, true);

                ArrayList al = new ArrayList();
                foreach (System.Web.UI.WebControls.ListItem item in ddlIltmp.Items)
                    al.Add(new object[] { item.Value.Replace(".", "").Trim(), item.Text.Trim() });

                Iller = (object[])al.ToArray(typeof(object[]));
            }
            return Iller;

        }

        public static string IlAdGetir(string ilKod)
        {
            DropDownList ddlIltmp = new DropDownList();
            GenelIslemlerIstemci.DDLKodDoldur(ddlIltmp, 0, "20", ilKod, 3, true, true);

            if (ddlIltmp.Items.Count > 0)
                return ddlIltmp.Items[0].Text;
            else
                return "TANIMSIZ";
        }

        public static string IlceAdGetir(string ilceKod)
        {
            ArrayList al = new ArrayList();

            DropDownList ddlIlcetmp = new DropDownList();
            GenelIslemlerIstemci.DDLKodDoldur(ddlIlcetmp, 0, "20", ilceKod.Trim(), 4, true, true);
            if (ddlIlcetmp.Items.Count > 0)
                return ddlIlcetmp.Items[0].Text;
            else
                return "TANIMSIZ";
        }

        /// <summary>
        /// İlçe bilgisini listeyen fonksiyon.
        /// </summary>
        /// <param name="ilKod">İl kodu</param>
        /// <returns></returns>
        public static object[] IlceYukle(string ilKod = "")
        {
            ArrayList al = new ArrayList();

            DropDownList ddlIlcetmp = new DropDownList();
            GenelIslemlerIstemci.DDLKodDoldur(ddlIlcetmp, 0, "20", ilKod.Trim(), 4, true, true);
            foreach (System.Web.UI.WebControls.ListItem item in ddlIlcetmp.Items)
                al.Add(new object[] { item.Value.Replace(".", "").Trim(), item.Text.Trim() });

            return (object[])al.ToArray(typeof(object[]));
        }

        public static void AsposeBuilderaDocEkle(Aspose.Words.DocumentBuilder builder, string dosyaAd)
        {
            Aspose.Words.Document srcDoc = new Aspose.Words.Document(dosyaAd);

            Aspose.Words.Node insertAfterNode = builder.CurrentParagraph;
            // We will be inserting into the parent of the destination paragraph.
            Aspose.Words.CompositeNode dstStory = insertAfterNode.ParentNode;

            // This object will be translating styles and lists during the import.
            Aspose.Words.NodeImporter importer = new Aspose.Words.NodeImporter(srcDoc, insertAfterNode.Document, Aspose.Words.ImportFormatMode.KeepSourceFormatting);
            // Loop through all sections in the source document.
            foreach (Aspose.Words.Section srcSection in srcDoc.Sections)
            {
                // Loop through all block level nodes (paragraphs and tables) in the body of the section.
                foreach (Aspose.Words.Node srcNode in srcSection.Body)
                {
                    // Let's skip the node if it is a last empty paragraph in a section.
                    if (srcNode.NodeType.Equals(Aspose.Words.NodeType.Paragraph))
                    {
                        Aspose.Words.Paragraph para = (Aspose.Words.Paragraph)srcNode;
                        if (para.IsEndOfSection && !para.HasChildNodes)
                            continue;
                    }

                    // This creates a clone of the node, suitable for insertion into the destination document.
                    Aspose.Words.Node newNode = importer.ImportNode(srcNode, true);

                    // Insert new node after the reference node.
                    dstStory.InsertAfter(newNode, insertAfterNode);
                    insertAfterNode = newNode;
                }
            }
        }

        public static void AsposeAlanaDocEkle(Aspose.Words.DocumentBuilder builder, string alanAd, string dosyaAd)
        {
            if (builder.MoveToMergeField(alanAd))
            {
                AsposeBuilderaDocEkle(builder, dosyaAd);
                // The paragraph that contained the merge field might be empty now and you probably want to delete it.
                if (!builder.CurrentParagraph.HasChildNodes)
                    builder.CurrentParagraph.Remove();
            }
        }

        public static void AsposeAlanaResimEkle(Aspose.Words.DocumentBuilder builder, string alanAd, System.IO.Stream resim, Aspose.Words.Drawing.RelativeHorizontalPosition horPos, double sol, Aspose.Words.Drawing.RelativeVerticalPosition verPos, double ust, Aspose.Words.Drawing.WrapType bolunme, double w, double h)
        {
            System.Drawing.Image image = System.Drawing.Image.FromStream(resim);
            double aspectRatioW = w / image.Width;
            double aspectRatioH = h / image.Height;
            double aspectRatio = Math.Min(aspectRatioW, aspectRatioH);
            if (aspectRatio > 0)
            {
                w = image.Width * aspectRatio;
                h = image.Height * aspectRatio;
            }

            while (builder.MoveToMergeField(alanAd))
            {
                Aspose.Words.Drawing.Shape eklenenResim = builder.InsertImage(image, horPos, sol, verPos, ust, w, h, bolunme);
            }
        }

        public static void AsposeAlanaResimEkle(Aspose.Words.DocumentBuilder builder, string alanAd, byte[] resim, Aspose.Words.Drawing.RelativeHorizontalPosition horPos, double sol, Aspose.Words.Drawing.RelativeVerticalPosition verPos, double ust, Aspose.Words.Drawing.WrapType bolunme, double w, double h)
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream(resim);
            AsposeAlanaResimEkle(builder, alanAd, ms, horPos, sol, verPos, ust, bolunme, w, h);
        }

        public static void AsposeAlanaResimEkle(Aspose.Words.DocumentBuilder builder, string alanAd, string resimDosyaAdi, Aspose.Words.Drawing.RelativeHorizontalPosition horPos, double sol, Aspose.Words.Drawing.RelativeVerticalPosition verPos, double ust, Aspose.Words.Drawing.WrapType bolunme, double w, double h)
        {
            System.IO.FileStream ms = new System.IO.FileStream(resimDosyaAdi, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            AsposeAlanaResimEkle(builder, alanAd, ms, horPos, sol, verPos, ust, bolunme, w, h);
        }

        public static void AsposeAlanaYaz(Aspose.Words.DocumentBuilder builder, string alanAd, string deger)
        {
            if (deger == null) deger = "";
            while (builder.MoveToMergeField(alanAd))
                builder.Write(deger);
        }

        public static void AsposeAlanaYazHtml(Aspose.Words.DocumentBuilder builder, string alanAd, string deger)
        {
            if (deger == null) deger = "";
            while (builder.MoveToMergeField(alanAd))
            {
                //builder.Font.ClearFormatting();
                builder.InsertHtml(deger);
            }
        }

        public static void ExtGridKolonGizleGoster(Ext1.Net.GridPanel grid, string colId, bool gizle)
        {
            int colNo = GenelIslemlerIstemci.ExtGridKolonSiraBul(grid, colId);
            if (colNo >= 0)
            {
                grid.ColumnModel.SetHidden(colNo, gizle);
                Ext1.Net.Column tut = (Ext1.Net.Column)grid.ColumnModel.Columns[colNo];
                if (tut.Commands != null && tut.Commands.Count > 0)
                    tut.Commands[0].Hidden = true;
            }
        }

        public static Ext1.Net.ColumnBase ExtGridKolonBul(Ext1.Net.GridPanel grid, string kolId)
        {
            foreach (Ext1.Net.ColumnBase col in grid.ColumnModel.Columns)
            {
                if (col.ColumnID.Equals(kolId))
                {
                    return col;
                }
            }
            return null;
        }

        public static int ExtGridKolonSiraBul(Ext1.Net.GridPanel grid, string kolId)
        {
            int say = -1;
            foreach (Ext1.Net.ColumnBase col in grid.ColumnModel.Columns)
            {
                say++;
                if (col.ColumnID.Equals(kolId))
                {
                    return say;
                }
            }
            return -1;
        }

        public static void SayfaDebugYaz(Kullanici kullanan, string sayfaAd, string olayAd)
        {
            //string kulKod = "";
            //if (kullanan != null && kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI))
            //{
            //    kulKod = kullanan.kullaniciKodu;
            //    OrtakFonksiyonlar.HataStrYaz(kulKod + "\t" + sayfaAd + "\t" + olayAd + "\t" + DateTime.Now.ToShortDateString() + "\t" + DateTime.Now.ToLongTimeString());
            //}
        }

        public static int OrgSemaDegerBul()
        {
            return OrtakFonksiyonlar.ConvertToInt(TNS.DEG.Arac.DegiskenDegerBul(0, "/OrgSema"), 0);
        }

        public static bool OrgSemaKullaniyorMu()
        {
            return OrgSemaDegerBul() == 1 ? true : false;
        }

        public static bool OrgSemaPersonelKullaniyorMu()
        {
            return OrtakFonksiyonlar.ConvertToInt(TNS.DEG.Arac.DegiskenDegerBul(0, "/OrgSemaPersonel"), 0) > 0 ? true : false;
        }

        public static bool OrgSemaEvrakKullaniyorMu()
        {
            return OrtakFonksiyonlar.ConvertToInt(TNS.DEG.Arac.DegiskenDegerBul(0, "/OrgSemaEvrak"), 0) > 0 ? true : false;
        }

        public static XmlNode MenuNodeBul(Kullanici kullanan, string menuID, bool yetkiliMenu)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(MenuXmlPathBul());

            XmlNode menuNode = MenuNodeBul(doc.GetElementsByTagName("Nodes").Item(0), menuID);

            if (yetkiliMenu && menuNode != null)
            {
                string[] kullaniciYetki;
                HashTableArrayList kullaniciDamga = kullanan.yetkiTipiDegerleri;

                if (kullanan.kullaniciTipi != null)
                {
                    kullaniciYetki = new string[kullanan.kullaniciTipi.Length];
                    for (int i = 0; i < kullanan.kullaniciTipi.Length; i++)
                        kullaniciYetki[i] = ((int)kullanan.kullaniciTipi[i]).ToString();
                }
                else
                    return null;

                menuNode = YetkiliMenuNodeBul(menuNode, kullaniciYetki, kullaniciDamga);
            }

            return menuNode;
        }

        private static XmlNode MenuNodeBul(XmlNode anaNode, string menuID)
        {
            if (string.IsNullOrEmpty(menuID))
                return anaNode;

            if (anaNode == null || !anaNode.HasChildNodes)
                return null;

            foreach (XmlNode node in anaNode.ChildNodes)
            {
                if (!string.IsNullOrEmpty(OzellikVer(node, "Gizli")))
                    continue;

                if (OzellikVer(node, "ID") == menuID)
                    return node;
                else
                {
                    XmlNode bulunanNode = MenuNodeBul(node, menuID);
                    if (bulunanNode != null)
                        return bulunanNode;
                }
            }

            return null;
        }

        private static XmlNode YetkiliMenuNodeBul(XmlNode anaNode, string[] kullaniciYetki, HashTableArrayList kullaniciDamga)
        {
            XmlNode yetkiliNode = null;

            if (anaNode == null || !anaNode.HasChildNodes)
                return yetkiliNode;

            foreach (XmlNode node in anaNode.ChildNodes)
            {
                if (!string.IsNullOrEmpty(OzellikVer(node, "Gizli")))
                    continue;

                XmlNode yeniNode = null;
                if (!node.HasChildNodes)
                {
                    //**ht
                    if (MenuGorunsunmu(OzellikVer(node, "Modul")) && MenuyeYetkiliMi(kullaniciYetki, OzellikVer(node, "Yetki"), kullaniciDamga))
                        yeniNode = node.CloneNode(false);
                }
                else
                {
                    //**ht
                    if (MenuGorunsunmu(OzellikVer(node, "Modul")))
                    {
                        XmlNode yetkiliAltNode = YetkiliMenuNodeBul(node, kullaniciYetki, kullaniciDamga);
                        if (yetkiliAltNode != null)
                            yeniNode = yetkiliAltNode.Clone();
                    }
                }

                if (yeniNode != null)
                {
                    if (yetkiliNode == null)
                        yetkiliNode = anaNode.CloneNode(false);

                    yetkiliNode.AppendChild(yeniNode);
                }
            }

            //if (anaNodeEkle)
            //{
            //    XmlNode anaEkli = anaNode.CloneNode(false);
            //    anaEkli.AppendChild(yetkiliNode);
            //    yetkiliNode = anaEkli;
            //}

            return yetkiliNode;
        }

        public static string OzellikVer(XmlNode node, string ozellikAd)
        {
            try
            {
                var attr = node.Attributes[ozellikAd];
                if (attr != null)
                    return attr.Value;
            }
            catch { }
            return string.Empty;
        }

        public static bool MenuGorunsunmu(string modulStr)
        {
            bool modulGorunsun = false;
            string[] moduller;
            string modulDurum;
            //0:kullanım dışı 1:kullanımda 2:test amaçlı
            if (!string.IsNullOrEmpty(modulStr))
            {
                moduller = modulStr.Split(',');
                foreach (string modul in moduller)
                {
                    if (modul.Trim() == "")
                        continue;

                    modulDurum = TNS.DEG.Arac.DegiskenDegerBul(0, "/MODUL/" + modul);
                    if (!string.IsNullOrEmpty(modulDurum) && (modulDurum.Trim() == "1" || modulDurum.Trim() == "2"))
                    {
                        modulGorunsun = true;
                        break;
                    }
                }
            }
            else
            {
                modulGorunsun = true;
            }
            return modulGorunsun;
        }

        public static bool MenuyeYetkiliMi(string[] kullaniciYetki, string menuYetki, HashTableArrayList kullaniciDamga)
        {
            if (string.IsNullOrEmpty(menuYetki))
                return true;

            string[] y = menuYetki.Split(',');
            for (int i = 0; i < y.Length; i++)
            {
                for (int j = 0; j < kullaniciYetki.Length; j++)
                {
                    if (kullaniciYetki[j] == y[i])
                        return true;
                }

                if (y[i].StartsWith("YT"))
                {
                    string[] damgaBilgi = y[i].Split('|');
                    if (damgaBilgi.Length < 3) return false;

                    foreach (DictionaryEntry de in kullaniciDamga)
                    {
                        string deger = kullaniciDamga[damgaBilgi[1]];
                        if (string.IsNullOrEmpty(deger))//YETKİDEN DEGER NULL DÖNDÜĞÜ İÇİN 
                            continue;

                        string[] degerler = deger.Split(';');
                        for (int k = 0; k < degerler.Length; k++)
                        {
                            if (degerler[k].Trim() == damgaBilgi[2])
                                return true;
                        }
                    }
                }
            }


            return false;
        }

        public static string MenuXmlPathBul()
        {
            return System.Configuration.ConfigurationManager.AppSettings.Get("MenuXML");
        }

        //public static string YazilimUrlBul()
        //{
        //    return System.Configuration.ConfigurationManager.AppSettings.Get("yazilimURL");
        //}

        public static void JSResourceEkle(System.Resources.ResourceManager ResourceManager, Page p, string kaynakAnahtar, params string[] kaynak)
        {
            string kaynakJS = string.Empty;
            foreach (string k in kaynak)
                kaynakJS += "var res_" + k + " = \"" + ResourceManager.GetString(k) + "\";";
            p.ClientScript.RegisterClientScriptBlock(p.GetType(), kaynakAnahtar, kaynakJS, true);
        }

        public static void GenelJSResourceEkle(Page p)
        {
            JSResourceEkle(OrtakClassRes.ResourceManager, p, "GenelJS", "JSGEN001", "JSGEN002", "JSGEN003",
                "JSGEN004", "JSGEN005", "JSGEN006", "JSGEN007", "JSGEN008", "JSGEN009", "JSGEN010", "JSGEN011",
                "JSGEN012", "JSGEN013", "JSGEN014", "JSGEN015", "JSGEN016", "JSGEN017", "JSGEN018", "JSGEN019",
                "JSGEN020", "JSGEN021", "JSGEN022", "JSGEN023", "JSGEN024", "JSGEN025", "JSGEN026", "JSGEN027",
                "JSGEN028", "JSGEN029", "JSGEN030", "JSGEN031", "JSGEN032", "JSGEN033", "JSGEN034", "JSGEN035",
                "JSGEN036", "JSGEN037", "JSGEN038", "JSGEN039", "JSGEN040", "JSGEN041", "JSGEN042", "JSGEN043",
                "JSGEN044", "JSGEN045", "JSGEN046", "JSGEN047");
        }

        public static void FarPointFonksiyonuEkle(FarPoint.Web.Spread.FpSpread fpKontrol, int satirIslemTur)
        {
            Control updateBtn = fpKontrol.FindControl("Paste");
            if (updateBtn != null)
            {
                TableCell tc = (TableCell)updateBtn.Parent;
                TableRow tr = (TableRow)tc.Parent;

                TableCell tc1 = new TableCell();
                tr.Cells.Add(tc1);

                Image img = new Image();
                switch (satirIslemTur)
                {
                    case (int)ENUMSatirIslemTur.SonaEkle:

                        img.ImageUrl = "../App_themes/images/insertLastRow.gif";
                        img.AlternateText = "Resources.ButceHazirlikv2.BHM003";
                        img.Attributes.Add("style", "border-color:buttonface;border-width:1px;border-style:Solid;");
                        img.Attributes.Add("width", "22");
                        img.Attributes.Add("height", "22");
                        img.Attributes.Add("onclick", "BosSatirEkle('" + fpKontrol.ID + "'); return false;");
                        tc1.Controls.Add(new LiteralControl("&nbsp;"));
                        tc1.Controls.Add(img);
                        break;

                    case (int)ENUMSatirIslemTur.ArayaEkle:

                        img.ImageUrl = "../App_themes/images/insertRow.gif";
                        img.AlternateText = "Resources.ButceHazirlikv2.BHM004";
                        img.Attributes.Add("style", "border-color:buttonface;border-width:1px;border-style:Solid;");
                        img.Attributes.Add("width", "22");
                        img.Attributes.Add("height", "22");
                        img.Attributes.Add("onclick", "ArayaSatirEkle('" + fpKontrol.ID + "'); return false;");
                        tc1.Controls.Add(new LiteralControl("&nbsp;"));
                        tc1.Controls.Add(img);
                        break;

                    case (int)ENUMSatirIslemTur.SatirSil:
                        img = new Image();
                        img.ImageUrl = "../App_themes/images/DeleteRow.gif";
                        img.AlternateText = "Resources.ButceHazirlikv2.BHM005";
                        img.Attributes.Add("style", "border-color:buttonface;border-width:1px;border-style:Solid;");
                        img.Attributes.Add("width", "22");
                        img.Attributes.Add("height", "22");
                        img.Attributes.Add("onclick", "SatirSil('" + fpKontrol.ID + "'); return false;");
                        tc1.Controls.Add(new LiteralControl("&nbsp;"));
                        tc1.Controls.Add(img);
                        break;
                }
            }
        }

        public static void FarPointSatirEkle(FarPoint.Web.Spread.FpSpread fpL)
        {
            try
            {
                fpL.ActiveSheetView.RowCount += 1;
            }
            catch { }
        }

        public static void FarPointArayaSatirEkle(FarPoint.Web.Spread.FpSpread fpL)
        {
            try
            {
                int aktifSatir = fpL.ActiveSheetView.ActiveRow;
                int acSatir = Math.Abs(aktifSatir - fpL.ActiveSheetView.SelectionModel.LeadRow) + 1;
                fpL.ActiveSheetView.AddRows(aktifSatir, acSatir);

            }
            catch { }

        }

        public static void FarPointSatirSil(FarPoint.Web.Spread.FpSpread fpL)
        {
            try
            {
                int aktifSatir = fpL.ActiveSheetView.ActiveRow;
                int acSatir = Math.Abs(aktifSatir - fpL.ActiveSheetView.SelectionModel.LeadRow) + 1;
                fpL.ActiveSheetView.RemoveRows(aktifSatir, acSatir);
            }
            catch { }

        }

        public static void fpL_ButtonCommand(FarPoint.Web.Spread.FpSpread fpL, string par)
        {
            string[] parList = par.Split('.');
            string farPointId = parList[0];
            string tur = parList[1];

            if (farPointId != "" && tur != "")
            {
                if (fpL != null)
                {
                    if (tur == "arayasatirekle")
                    {
                        try
                        {
                            FarPointArayaSatirEkle(fpL);
                        }
                        catch { }
                    }
                    else if (tur == "bossatirekle")
                    {
                        try
                        {
                            FarPointSatirEkle(fpL);
                        }
                        catch { }
                    }
                    else if (tur == "satirsil")
                    {
                        try
                        {
                            FarPointSatirSil(fpL);
                        }
                        catch { }
                    }
                    else if (tur.StartsWith("satirsil_"))
                    {
                        try
                        {
                            fpL.CancelEdit();
                            tur = tur.Replace("satirsil_", "");
                            tur = tur.TrimEnd('_');
                            string[] deleteIndexList = tur.Split('_');
                            int silSayac = 0;
                            foreach (string index in deleteIndexList)
                            {
                                int row = OrtakFonksiyonlar.ConvertToInt(index, -1);
                                row = row - silSayac;
                                if (row > -1)
                                {
                                    fpL.ActiveSheetView.Rows.Remove(row, 1);
                                    silSayac++;
                                }
                            }
                        }
                        catch { }
                    }
                    fpL.SaveChanges();
                }
            }
        }

        public static string RequestBul(Page sayfa, string reqAd, string defDeger)
        {
            string tut = sayfa.Request[reqAd] + "";
            if (string.IsNullOrEmpty(tut))
                return defDeger;
            else
                return tut;
        }

        public static int RequestBul(Page sayfa, string reqAd, int defDeger)
        {
            string tut = sayfa.Request[reqAd] + "";
            if (string.IsNullOrEmpty(tut))
                return defDeger;
            else
                return OrtakFonksiyonlar.ConvertToInt(tut, defDeger);
        }


        public static string CollectionDegerAl(TNSCollection coll, int indis)
        {
            if (coll == null || indis >= coll.Count) return "";
            return coll[indis].ToString();
        }

        public static void RakamAlanFormatla(FarPoint.Web.Spread.FpSpread kontrol, int kolon1, int kolon2, int virgulSonrasi)
        {
            FarPoint.Web.Spread.GeneralCellType customCurrencyType = new FarPoint.Web.Spread.GeneralCellType();
            System.Globalization.NumberFormatInfo ninfo = new System.Globalization.NumberFormatInfo();
            ninfo.NumberGroupSeparator = ".";
            ninfo.NumberDecimalSeparator = ",";
            ninfo.NumberDecimalDigits = virgulSonrasi;
            customCurrencyType.NumberFormat = ninfo;
            kontrol.Sheets[0].Columns[kolon1, kolon2].CellType = customCurrencyType;
        }

        //public static string ListeBaslikBul(int deger)
        //{
        //    return ListeBaslikBul(DateTime.Now.Year + 1, deger);
        //}

        //public static string ListeBaslikBul(int yil, int deger)
        //{
        //    IBHMServis servisBHM = TNS.BHM.Arac.Tanimla();
        //    return servisBHM.EkBilgiAciklamaBul(yil, deger);
        //}

        public static void FinansmanKodDoldur(int yil, DropDownList kontrol)
        {
            IBKDServis servisBKD = TNS.BKD.Arac.Tanimla();
            ABSKodlarVAN asamav = servisBKD.KodListele(yil, "6", "");
            Kullanici kullanan = OturumBilgisiIslem.KullaniciBilgiOku(false);

            if (asamav.sonuc.islemSonuc)
            {
                foreach (ABSKod kod in asamav.absKodlar)
                    kontrol.Items.Add(new ListItem(kod.Ad(kullanan.aktifKultur), kod.kod));
            }
            kontrol.SelectedIndex = 0;
        }

        public static void DDLKodDoldur(DropDownList kontrol, int yil, string tur, string ustKod, int seviye, bool sadeceDetay)
        {
            DDLKodDoldur(kontrol, yil, tur, ustKod, seviye, sadeceDetay, false);
        }

        public static void DDLKodDoldur(DropDownList kontrol, int yil, string tur, string ustKod, int seviye, bool sadeceDetay, bool sadeceAd)
        {
            IBKDServis servisBKD = TNS.BKD.Arac.Tanimla();
            ABSKodlarVAN asamav = servisBKD.KodListeleSeviye(yil, tur, ustKod, seviye, sadeceDetay);
            Kullanici kullanan = OturumBilgisiIslem.KullaniciBilgiOku(false);

            if (asamav.sonuc.islemSonuc)
            {
                if (sadeceAd)
                    asamav.absKodlar.Sort();

                foreach (ABSKod kod in asamav.absKodlar)
                {
                    if (string.IsNullOrEmpty(kullanan.aktifKultur))
                        kullanan.aktifKultur = "tr";

                    string ad = kod.kod + " / " + kod.Ad(kullanan.aktifKultur);
                    if (sadeceAd)
                        ad = kod.Ad(kullanan.aktifKultur);
                    kontrol.Items.Add(new ListItem(ad, kod.kod));
                }
            }
            if (kontrol.Items.Count > 0)
                kontrol.SelectedIndex = 0;
        }

        public static void DDLBirimDoldur(DropDownList kontrol, Kullanici kullanan, int yil, string kurum, bool altDuzey)
        {
            IBKDServis servisBKD = TNS.BKD.Arac.Tanimla();
            ABSKodlarVAN birimVan = servisBKD.BirimListele(kullanan, yil, kurum, altDuzey);

            if (birimVan.sonuc.islemSonuc)
            {
                kontrol.Items.Clear();
                kontrol.Items.Add(new ListItem("", ""));
                foreach (ABSKod kod in birimVan.absKodlar)
                    kontrol.Items.Add(new ListItem(kod.kod + " / " + kod.Ad(kullanan.aktifKultur), kod.kod));
            }
            if (kontrol.Items.Count > 0)
                kontrol.SelectedIndex = 0;
        }

        public static void DDLBirimDoldur(DropDownList ddlKur, IBKDServis bkdServis, int yil, Kullanici kullanan, string YetkiAdi, bool kurumEkle)
        {
            if (bkdServis == null)
                bkdServis = TNS.BKD.Arac.Tanimla();
            ABSKodlarVAN akv = bkdServis.BirimListele(kullanan, yil, GenelIslemlerIstemci.VarsayilanKurumBul(), true);
            if (akv.sonuc.islemSonuc)
            {
                foreach (ABSKod ak in akv.absKodlar)
                {
                    bool ekle = false;
                    if (kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI))
                        ekle = true;
                    else
                    {
                        string birimlerStr = kullanan.YetkiTipiDegeriBul(YetkiAdi);
                        string[] birimler = birimlerStr.Split(';');
                        for (int i = 0; i < birimler.Length && !ekle; i++)
                        {
                            if (!string.IsNullOrEmpty(birimler[i]))
                                if (ak.kod.StartsWith(birimler[i]))
                                    ekle = true;
                        }
                    }
                    if (ekle)
                        ddlKur.Items.Add(new System.Web.UI.WebControls.ListItem(ak.kod + " / " + ak.Ad(kullanan.aktifKultur), ak.kod));
                }
                if (kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI) && kurumEkle)
                    ddlKur.Items.Add(new System.Web.UI.WebControls.ListItem(GenelIslemlerIstemci.VarsayilanKurumBulAd(), GenelIslemlerIstemci.VarsayilanKurumBul()));
                if (string.IsNullOrEmpty(ddlKur.SelectedValue)) ddlKur.SelectedIndex = 0;
                if (ddlKur.Items.Count > 0 && ddlKur.SelectedIndex < 0)
                    ddlKur.SelectedIndex = 0;
            }
        }

        public static string TiredenKodAl(string kodAd, char tire = '-')
        {
            try
            {
                string[] tutParca = kodAd.Split(tire);
                return tutParca[0];
            }
            catch { return ""; }
        }

        public static string ExtTiredenKodAl(Ext1.Net.ComboBox cbEko)
        {
            try
            {
                string tut = cbEko.SelectedItem.Value;
                if (string.IsNullOrWhiteSpace(tut)) return tut;
                return TiredenKodAl(tut);
            }
            catch { return ""; }
        }

        public static string MultiComboValue(Ext1.Net.MultiCombo mc)
        {
            string val = "";
            for (int i = 0; i < mc.SelectedItems.Count; i++)
            {
                if (val != "") val += ", ";
                val += mc.SelectedItems[i].Value;
            }
            return val;
        }

        public static string[] MultiComboValueArray(Ext1.Net.MultiCombo mc)
        {
            string val = "";
            for (int i = 0; i < mc.SelectedItems.Count; i++)
            {
                if (val != "") val += ",";
                val += mc.SelectedItems[i].Value;
            }
            return val.Split(',');
        }

        public static void ExtBaslikAyarla(Ext1.Net.GridPanel grid, int satir, int sutun, double miktar, int baslikSatir, Ext1.Net.Js js)
        {
            ExtBaslikAyarla(grid, satir, sutun, miktar.ToString("#,##0"), baslikSatir, js);
        }

        public static string ABSKodDoldur(int yil, string kodTur, string ustKod, int seviye, Ext1.Net.Store sto, bool bosBasaEkle, string bosKod, string bosAd, bool sadeceDetay, bool hiyerarsik)
        {
            TNS.BKD.IBKDServis servis = TNS.BKD.Arac.Tanimla();
            TNS.BKD.ABSKodlarVAN v = servis.KodListeleSeviye(yil, kodTur, ustKod, seviye, sadeceDetay, false, "", "", "", hiyerarsik);

            if (bosKod != null)
            {
                TNS.BKD.ABSKod kod = new TNS.BKD.ABSKod(bosKod);
                kod.AdAta(bosAd);
                if (bosBasaEkle)
                    v.absKodlar.Insert(0, kod);
                else
                    v.absKodlar.Add(kod);
            }
            sto.DataSource = v.absKodlar;
            sto.DataBind();
            if (v.absKodlar.Count > 0)
            {
                TNS.BKD.ABSKod kod = (TNS.BKD.ABSKod)v.absKodlar[0];
                return kod.kod;
            }
            return null;
        }

        public static void ExtBaslikAyarla(Ext1.Net.GridPanel grid, int satir, int sutun, string miktar, int baslikSatir, Ext1.Net.Js js)
        {
            if (satir == baslikSatir)
            {
                grid.ColumnModel.SetColumnHeader(sutun, miktar);
            }
            else
            {
                js.AddScript("HeaderAyarla({0}, {1}, {2}, '{3}');", grid.ID, satir, sutun, miktar);
            }
        }

        public static void DDLBirimDoldur(Ext1.Net.Store store, IBKDServis bkdServis, int yil, Kullanici kullanan, Ext1.Net.ComboBox cmbKur, string YetkiAdi = null, bool kurumEkle = false, bool kodAddaGorunsun = false, string seciliKur = null)
        {
            if (bkdServis == null)
                bkdServis = TNS.BKD.Arac.Tanimla();
            ABSKodlarVAN akv = bkdServis.BirimListele(kullanan, yil, GenelIslemlerIstemci.VarsayilanKurumBul(), true);
            if (akv.sonuc.islemSonuc)
            {
                System.Collections.Generic.List<object> kurlar = new System.Collections.Generic.List<object>();

                string ilkKod = null;
                if (kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI) && kurumEkle)
                {
                    string ad = GenelIslemlerIstemci.VarsayilanKurumBulAd();
                    string kod = GenelIslemlerIstemci.VarsayilanKurumBul();
                    if (kodAddaGorunsun) ad = kod + " / " + ad;
                    kurlar.Add(new { kod = kod, ad = ad });
                    if (ilkKod == null) ilkKod = kod;
                }

                foreach (ABSKod ak in akv.absKodlar)
                {
                    bool ekle = false;
                    if (kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI) || string.IsNullOrEmpty(YetkiAdi))
                        ekle = true;
                    else
                    {
                        string birimlerStr = kullanan.YetkiTipiDegeriBul(YetkiAdi);
                        string[] birimler = birimlerStr.Split(';');
                        for (int i = 0; i < birimler.Length && !ekle; i++)
                        {
                            if (!string.IsNullOrEmpty(birimler[i]))
                                if (ak.kod.StartsWith(birimler[i]))
                                    ekle = true;
                        }
                    }
                    if (ekle)
                    {
                        string ad = ak.Ad(kullanan.aktifKultur);
                        if (kodAddaGorunsun) ad = ak.kod + " / " + ad;
                        kurlar.Add(new { kod = ak.kod, ad = ad });
                        if (ilkKod == null) ilkKod = ak.kod;
                    }
                }


                store.DataSource = kurlar;
                store.DataBind();
                if (string.IsNullOrEmpty(seciliKur) && kurlar.Count > 0)
                    seciliKur = ilkKod;
                if (cmbKur != null)
                {
                    cmbKur.SetValueAndFireSelect(seciliKur);
                    cmbKur.Value = seciliKur;
                    cmbKur.Text = seciliKur;
                }
                //if (string.IsNullOrEmpty(ddlKur.SelectedValue)) ddlKur.SelectedIndex = 0;
                //if (ddlKur.Items.Count > 0 && ddlKur.SelectedIndex < 0)
                //    ddlKur.SelectedIndex = 0;
            }
        }

        public static void EkonomikKodDoldur(DropDownList kontrol, int yil)
        {
            DDLKodDoldur(kontrol, yil, "5", "", 4, false);
        }

        //private static void KullaniciKurumListesiDoldurOzelGenel(DropDownList kontrol, int yil, Kullanici kullanan, bool ozelMi)
        //{
        //    string kurKod, kurAd;
        //    kontrol.Items.Clear();
        //    VarsayilanKurumBul(out kurKod, out kurAd);
        //    if (!String.IsNullOrEmpty(kurKod))
        //        kontrol.Items.Add(new ListItem(kurKod + " - " + kurAd, kurKod));
        //    else
        //    {
        //        IBKDServis servisBKD = TNS.BKD.Arac.Tanimla();

        //        kontrol.Items.Clear();
        //        ABSKodlarVAN kurumListe = servisBKD.KurumListesiKullanici(kullanan, Convert.ToInt16(yil), true);

        //        if (kurumListe.sonuc.islemSonuc)
        //        {
        //            if (kurumListe != null)
        //            {
        //                kontrol.Items.Add(new ListItem("", ""));
        //                foreach (ABSKod kod in kurumListe.absKodlar)
        //                    kontrol.Items.Add(new ListItem(kod.Ad(kullanan.aktifKultur), kod.kod));
        //            }
        //        }
        //    }
        //}

        //public static void KullaniciKurumListesiDoldur(DropDownList kontrol, int yil, Kullanici kullanan)
        //{
        //    KullaniciKurumListesiDoldurOzelGenel(kontrol, yil, kullanan, false);
        //}

        //public static void KullaniciOzelKurumListesiDoldur(DropDownList kontrol, int yil, Kullanici kullanan)
        //{
        //    KullaniciKurumListesiDoldurOzelGenel(kontrol, yil, kullanan, true);
        //}


        //public static void KurumListesiDoldur(IKYMServis servis, DropDownList c, string tur, string kurumKodu)
        //{
        //    ArrayList bilgiListesi = new ArrayList();

        //    bilgiListesi = KurumListesiDoldur(servis, tur, kurumKodu);

        //    foreach (ListItem listeSatir in bilgiListesi)
        //        if (listeSatir.Value == "")
        //            c.Items.Add(new ListItem(Resources.Istemci.IST015, listeSatir.Value));
        //        else
        //            c.Items.Add(new ListItem(listeSatir.Value + " - " + listeSatir.Text, listeSatir.Value));
        //}

        //public static ArrayList KurumListesiDoldur(IKYMServis servis, string tur, string kurumKodu)
        //{
        //    ListeVAN liste = null;
        //    ArrayList bilgiListesi = new ArrayList();

        //    if (servis == null)
        //        servis = TNS.KYM.Arac.Tanimla();

        //    //Kurum Listelerini yükler
        //    bilgiListesi.Add(new ListItem("", ""));

        //    //if (tur == "bütün")
        //    //    bilgiListesi.Add(new ListItem("Merkez", "M01"));

        //    if (tur == "bütün" || tur == "çalıştığı" || tur == "kullaniciYoneticisi")
        //    {
        //        liste = servis.KurumListesi(Convert.ToInt16(GenelIslemlerIstemci.HazirlikYiliBul(null)));
        //        foreach (ListeSatir listeSatir in liste.satirlar)
        //        {
        //            if (tur == "bütün" ||
        //                (tur == "kullaniciYoneticisi" && (kurumKodu.EndsWith("00") || kurumKodu.EndsWith("50")) && kurumKodu.Substring(0, 2) == listeSatir.kod.Substring(0, 2)) ||
        //                ((tur == "çalıştığı" || tur == "kullaniciYoneticisi") && kurumKodu == listeSatir.kod.ToString()))//İldeki kullanıcı yöneticisi ise
        //                bilgiListesi.Add(new ListItem(listeSatir.ad, listeSatir.kod.ToString()));
        //        }
        //    }

        //    return bilgiListesi;
        //}

        public static void YilDoldur(DropDownList kontrol, bool hazirlikYilMi)
        {
            int hYil, simdYil;
            simdYil = DateTime.Now.Year;
            if (hazirlikYilMi)
            {
                hYil = simdYil++; ;
            }
            else
            {
                hYil = simdYil;
            }
            //hYil = OrtakFonksiyonlar.ConvertToInt(servis.DegiskenDegerBul(0, degiskenAd), simdYil);
            GenelIslemler.YilDoldur(kontrol, 2005, hYil, hYil);
        }

        //public static void AsamaDoldur(DropDownList kontrol, bool ucYil, Kullanici kullanan)
        //{
        //    ABSKodlarVAN asamav = Asamalar.OdenekAsamalariBul(false);

        //    if (asamav.sonuc.islemSonuc)
        //    {
        //        foreach (ABSKodTekDil kod in asamav.absKodlar)
        //            if (kullanan != null || kod.kod.CompareTo("3") >= 0)
        //                kontrol.Items.Add(new ListItem(kod.ad, kod.kod));
        //        if (ucYil)
        //        {
        //            foreach (ABSKodTekDil kod in asamav.absKodlar)
        //                if (kullanan != null || kod.kod.CompareTo("3") >= 0)
        //                    kontrol.Items.Add(new ListItem(kod.ad + "(+1)", (OrtakFonksiyonlar.ConvertToInt(kod.kod, 0) + 10).ToString()));
        //            foreach (ABSKodTekDil kod in asamav.absKodlar)
        //                if (kullanan != null || kod.kod.CompareTo("3") >= 0)
        //                    kontrol.Items.Add(new ListItem(kod.ad + "(+2)", (OrtakFonksiyonlar.ConvertToInt(kod.kod, 0) + 20).ToString()));
        //        }
        //    }

        //    if (kullanan != null)
        //    {
        //        string kDeg = kullanan.DegiskenDegerBul("ASAMA");
        //        if (String.IsNullOrEmpty(kDeg))
        //            kontrol.SelectedIndex = 1;
        //        else
        //            kontrol.SelectedIndex = OrtakFonksiyonlar.ConvertToInt(kDeg, 0);
        //    }
        //}

        public static void AsamaDoldur(DropDownList kontrol)
        {
            kontrol.Items.Clear();
            kontrol.Items.Add(new ListItem("Birim Teklifi", "0"));
            kontrol.Items.Add(new ListItem("SGB Görüşü", "1"));
            kontrol.Items.Add(new ListItem("Bakanlık Teklifi", "2"));
            kontrol.Items.Add(new ListItem("Tasarı", "3"));
            kontrol.Items.Add(new ListItem("Plan Bütçe Komisyonu", "4"));
            kontrol.Items.Add(new ListItem("Kanun", "5"));
            kontrol.Items.Add(new ListItem("KBÖ", "6"));
        }

        public static void VarsayilanKurumBul(out string kurKod, out string kurAd)
        {
            kurKod = TNS.DEG.Arac.DegiskenDegerBul(0, "/KURUMKOD");
            kurAd = TNS.DEG.Arac.DegiskenDegerBul(0, "/KURUMAD");
        }

        public static string VarsayilanKurumBul()
        {
            return TNS.DEG.Arac.DegiskenDegerBul(0, "/KURUMKOD");
        }

        public static string VarsayilanKurumBulAd()
        {
            return TNS.DEG.Arac.DegiskenDegerBul(0, "/KURUMAD");
        }

        public static int HazirlikYiliBul()
        {
            int simdYil = DateTime.Now.Year;
            simdYil++;
            int hYil = OrtakFonksiyonlar.ConvertToInt(TNS.DEG.Arac.DegiskenDegerBulCache(0, "/BUTCEHAZIRLIK"), simdYil);
            return hYil;
        }

        public static int YatirimEntegreYilBul()
        {
            return OrtakFonksiyonlar.ConvertToInt(TNS.DEG.Arac.DegiskenDegerBul(0, "/YATIRIMENTEGREYIL"), 0);
        }

        public static string HesapPlaniKurum(string kurum)
        {
            string rKurum;

            if (kurum.Replace(".", "").Substring(0, 2) == "38")
                rKurum = "38";
            else if (OrtakFonksiyonlar.ConvertToInt(kurum.Replace(".", "").Substring(0, 2), 0) >= 40 && OrtakFonksiyonlar.ConvertToInt(kurum.Replace(".", "").Substring(0, 2), 0) < 46)
                rKurum = kurum.Replace(".", "").Substring(0, 4);
            else if (kurum.Replace(".", "").Substring(0, 2) == "46")
                rKurum = kurum.Replace(".", "").Substring(0, 6);
            else
                rKurum = "12";

            return rKurum;
        }
        //public static string ListeOranDegerBul(int i, int baslaSutun, string[,] listeDegisken, TNSCollection ekBilgi, int yil, int asama, int sayac, Kullanici kullanan, IBHMServis servis, string kurum)
        //{
        //    string oranDeger = listeDegisken[i + baslaSutun, 1];
        //    string[] degerler = oranDeger.Split(';');
        //    int kirilimSay = degerler.Length;
        //    if (kirilimSay > 3)
        //    {
        //        string oranTur = degerler[0];
        //        string alanX = degerler[2];
        //        string alanY = degerler[3];
        //        char alanXSutun = 'A';
        //        char alanYSutun = 'A';

        //        for (int k = 0; k < ekBilgi.Count; k++)
        //        {
        //            if (alanX == "7") alanXSutun = Convert.ToChar(2 + 64);
        //            if (alanY == "7") alanYSutun = Convert.ToChar(2 + 64);
        //            if (alanX == "17") alanXSutun = Convert.ToChar(3 + 64);
        //            if (alanY == "17") alanYSutun = Convert.ToChar(3 + 64);
        //            if (alanX == "27") alanXSutun = Convert.ToChar(4 + 64);
        //            if (alanY == "27") alanYSutun = Convert.ToChar(4 + 64);

        //            if (ekBilgi[k].ToString() == alanX)
        //                alanXSutun = Convert.ToChar(2 + k + 64);
        //            if (ekBilgi[k].ToString() == alanY)
        //                alanYSutun = Convert.ToChar(2 + k + 64);
        //        }

        //        if (oranTur == "1")
        //        {
        //            if (alanX == "7" || alanX == "17" || alanX == "27")
        //                alanX = (Convert.ToInt16(alanX) - 7 + asama).ToString();

        //            string[] t_kodlar = new string[1];
        //            t_kodlar[0] = Tertip.KurumsaldanKuruma(kurum).Replace(".", "");

        //            double toplamX = servis.EkDegerBul(kullanan, yil, Convert.ToInt16(alanX), t_kodlar, "");
        //            //double toplamX = 0;
        //            return "(" + alanXSutun + (sayac + 1).ToString() + "/" + Convert.ToUInt64(toplamX) + ")*100";
        //        }
        //        else if (oranTur == "2")
        //            return "((" + alanYSutun + (sayac + 1).ToString() + "-" + alanXSutun + (sayac + 1).ToString() + ")/" + alanXSutun + (sayac + 1).ToString() + ")*100";
        //        else if (oranTur == "3")
        //            return "(" + alanXSutun + (sayac + 1).ToString() + "/" + alanYSutun + (sayac + 1).ToString() + ")*100";
        //    }
        //    return "";
        //}

        public static void HarcamaAyiBul(string configAd, out int harcamaAy, out string harcamaAyAd, int hataAy)
        {
            harcamaAy = OrtakFonksiyonlar.ConvertToInt(GenelIslemler.WebConfigOku(configAd, hataAy.ToString()), hataAy);
            harcamaAyAd = GenelIslemler.AyAdDondur(harcamaAy);
        }


        public static void HarcamaTasariAyiBul(out int harcamaAy, out string harcamaAyAd)
        {
            HarcamaAyiBul("HarcamaTasariAyi", out harcamaAy, out harcamaAyAd, 8);
        }

        public static void HarcamaTeklifAyiBul(out int harcamaAy, out string harcamaAyAd)
        {
            HarcamaAyiBul("HarcamaTeklifAyi", out harcamaAy, out harcamaAyAd, 6);
        }

        /*
        public static void LisansliMi()
        {
            Sonuc sonuc = (Sonuc)OturumBilgisiIslem.BilgiOkuDegisken("lisans", false);

            if (sonuc == null)
            {
                sonuc = TNS.TMM.Lisans.LisansKontrol();
                OturumBilgisiIslem.BilgiYazDegisken("lisans", sonuc);
            }

            if (!sonuc.islemSonuc)
                GenelIslemler.SayfayaGirmesin(false, sonuc.hataStr);
        }
        */

        public static void GridPagerEkle(object o, int elemanSayisi)
        {
            if (o.GetType() == typeof(DataGrid))
                DataGridPagerEkle((DataGrid)o, elemanSayisi);
            else if (o.GetType() == typeof(FarPoint.Web.Spread.FpSpread))
                FarPointPagerEkle((FarPoint.Web.Spread.FpSpread)o, elemanSayisi);
            else if (o.GetType() == typeof(GridView))
                GridViewPagerEkle((GridView)o, elemanSayisi);
        }

        private static void GridViewPagerEkle(GridView gv, int elemanSayisi)
        {
            if (elemanSayisi > 0)
            {
                gv.AllowPaging = true;
                gv.PageSize = elemanSayisi;
                gv.AutoGenerateColumns = false;
                gv.PagerSettings.Position = PagerPosition.Bottom;
                gv.PagerSettings.Mode = PagerButtons.NextPrevious;
                gv.PagerStyle.HorizontalAlign = HorizontalAlign.Center;
                gv.PagerStyle.Font.Bold = true;
                gv.PagerSettings.PreviousPageText = OrtakClassRes.IST021 + "|";
                gv.PagerSettings.NextPageText = "|" + OrtakClassRes.IST022;
            }
            else
            {
                gv.AllowPaging = false;
            }
        }

        private static void DataGridPagerEkle(DataGrid dg, int elemanSayisi)
        {
            dg.AllowPaging = true;
            dg.PageSize = elemanSayisi;
            dg.AutoGenerateColumns = false;
            dg.PagerStyle.Position = PagerPosition.Bottom;
            dg.PagerStyle.Mode = PagerMode.NextPrev;
            dg.PagerStyle.HorizontalAlign = HorizontalAlign.Center;
            dg.PagerStyle.Font.Bold = true;
            dg.PagerStyle.PrevPageText = OrtakClassRes.IST021 + "|";
            dg.PagerStyle.NextPageText = "|" + OrtakClassRes.IST022;
        }

        private static void FarPointPagerEkle(FarPoint.Web.Spread.FpSpread fpL, int pageSize)
        {
            fpL.CommandBar.Visible = false;
            if (pageSize > 0)
            {
                fpL.Sheets[0].AllowPage = true;
                fpL.Sheets[0].PageSize = pageSize;
                fpL.Pager.PageCount = 4;
                fpL.Pager.Position = FarPoint.Web.Spread.PagerPosition.Bottom;
                fpL.Pager.Mode = FarPoint.Web.Spread.PagerMode.Both;
                fpL.Pager.Align = HorizontalAlign.Left;
                fpL.Pager.Font.Bold = true;
            }
            else
            {
                fpL.Sheets[0].AllowPage = false;
            }
        }

        public static MyGridColorStyle GridColorStyle(object o, Kullanici kullanan)
        {
            return GridColorStyle(o, kullanan, true);
        }

        public static MyGridColorStyle GridColorStyle(object o, Kullanici kullanan, bool satirMode)
        {
            MyGridColorStyle colorStyle = new MyGridColorStyle(kullanan);
            colorStyle.Load();

            if (o.GetType() == typeof(DataGrid))
                DataGridColorStyle(colorStyle, (DataGrid)o);
            else if (o.GetType() == typeof(FarPoint.Web.Spread.FpSpread))
                FarPointColorStyle(colorStyle, (FarPoint.Web.Spread.FpSpread)o, satirMode);
            else if (o.GetType() == typeof(GridView))
                GridViewColorStyle(colorStyle, (GridView)o);

            return colorStyle;
        }

        private static void GridViewColorStyle(MyGridColorStyle colorStyle, GridView gv)
        {
            gv.HeaderStyle.BackColor = colorStyle.HeaderBackColor;
            gv.HeaderStyle.ForeColor = colorStyle.HeaderForeColor;
            gv.PagerStyle.BackColor = colorStyle.HeaderBackColor;
            gv.PagerStyle.ForeColor = colorStyle.HeaderForeColor;
            gv.RowStyle.BackColor = colorStyle.lockBackColor;
            gv.RowStyle.ForeColor = colorStyle.lockForeColor;
            gv.BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
            gv.BorderWidth = 1;
        }

        private static void DataGridColorStyle(MyGridColorStyle colorStyle, DataGrid dg)
        {
            dg.HeaderStyle.BackColor = colorStyle.HeaderBackColor;
            dg.HeaderStyle.ForeColor = colorStyle.HeaderForeColor;
            dg.PagerStyle.BackColor = colorStyle.HeaderBackColor;
            dg.PagerStyle.ForeColor = colorStyle.HeaderForeColor;
            dg.ItemStyle.BackColor = colorStyle.lockBackColor;
            dg.ItemStyle.ForeColor = colorStyle.lockForeColor;
            dg.BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
            dg.BorderWidth = 1;
        }

        public static string UTF8HtmlKodDoustur(string value)
        {
            value = value.Replace("Ğ", "Ä");
            value = value.Replace("Ü", "Ãœ");
            value = value.Replace("Ş", "Å");
            value = value.Replace("İ", "Ä°");
            value = value.Replace("Ö", "Ã–");
            value = value.Replace("Ç", "Ã‡");
            value = value.Replace("ğ", "ÄŸ");
            value = value.Replace("ü", "Ã¼");
            value = value.Replace("ş", "ÅŸ");
            value = value.Replace("ı", "Ä±");
            value = value.Replace("ö", "Ã¶");
            value = value.Replace("ç", "Ã§");

            return value;
        }


        private static void FarPointColorStyle(MyGridColorStyle colorStyle, FarPoint.Web.Spread.FpSpread fpL, bool satirMode)
        {
            if (fpL.Sheets.Count == 0) { fpL.Sheets.Count = 1; }
            FarPoint.Web.Spread.SheetView sheet = fpL.Sheets[0];

            sheet.ColumnHeader.DefaultStyle.Font.Size = FontUnit.Point(8);
            sheet.ColumnHeader.DefaultStyle.Font.Bold = true;
            sheet.ColumnHeader.DefaultStyle.BackColor = colorStyle.HeaderBackColor;
            sheet.ColumnHeader.DefaultStyle.ForeColor = colorStyle.HeaderForeColor;

            sheet.RowHeader.DefaultStyle.Font.Size = FontUnit.Point(8);
            sheet.RowHeader.DefaultStyle.Font.Bold = true;
            sheet.RowHeader.DefaultStyle.BackColor = colorStyle.HeaderBackColor;
            sheet.RowHeader.DefaultStyle.ForeColor = colorStyle.HeaderForeColor;

            for (int i = 0; i < sheet.ColumnHeader.Rows.Count; i++)
            {
                sheet.ColumnHeader.Rows[i].Border.BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                sheet.ColumnHeader.Rows[i].Border.BorderSize = 1;
                sheet.ColumnHeader.Rows[i].Border.BorderStyle = BorderStyle.Solid;
            }

            for (int i = 0; i < sheet.Rows.Count; i++)
            {
                sheet.RowHeader.Rows[i].Border.BorderColor = System.Drawing.Color.FromArgb(211, 211, 211);
                sheet.RowHeader.Rows[i].Border.BorderSize = 1;
                sheet.RowHeader.Rows[i].Border.BorderStyle = BorderStyle.Solid;
            }

            sheet.HeaderGrayAreaColor = System.Drawing.Color.FromArgb(252, 252, 252);
            sheet.SelectionBackColor = colorStyle.SelectionBackColor;
            if (satirMode)
                sheet.OperationMode = FarPoint.Web.Spread.OperationMode.RowMode;

            if (sheet.RowCount == 0) { sheet.RowCount = 1; }
            sheet.Rows[0].Border.BorderStyleTop = BorderStyle.None;
            sheet.Rows.Default.VerticalAlign = VerticalAlign.Middle;
            sheet.Rows.Default.Margin.Left = 10;
            sheet.Rows.Default.Margin.Right = 10;
            sheet.Rows.Default.Height = 19;
            sheet.Rows.Default.Font.Size = FontUnit.Point(8);

            foreach (FarPoint.Web.Spread.Column col in sheet.Columns)
                if (col.Locked) { col.BackColor = colorStyle.lockBackColor; col.ForeColor = colorStyle.lockForeColor; }
        }

        #region "Farpoint CellType - Hüseyin"

        public static class FarpointMyCellType
        {
            [Serializable()]
            public class MyLinkType : FarPoint.Web.Spread.HyperLinkCellType
            {
                public MyLinkType() { }

                public MyLinkType(System.String url) : base(url) { }

                public override System.Web.UI.Control PaintCell(System.String id, System.Web.UI.WebControls.TableCell parent, FarPoint.Web.Spread.Appearance style, FarPoint.Web.Spread.Inset margin, System.Object value, System.Boolean upperLevel)
                {
                    Control link = base.PaintCell(id, parent, style, margin, value, upperLevel);
                    ((WebControl)link).Attributes.Add("onclick", this.NavigateUrl + "; return false;");

                    return link;
                }
            }

            /// <summary>
            /// Grid içerisinde bulunan bir bağı, mouse üzerine gelince alt çizgili, mouse çıkınca normal gösterecek şekilde formatlayan sınıf.
            /// </summary>
            //[Serializable()]
            //public class MyLinkType_Color : FarPoint.Web.Spread.HyperLinkCellType
            //{
            //    /// <summary>
            //    /// Grid içerisinde bulunan bir bağı oluşturan oluşturucu (constructor) yordam
            //    /// </summary>
            //    /// <param name="url">Bağ adresi, adresin sonunda ! işareti ile ayrılmış renk kodu bulunur</param>
            //    public MyLinkType_Color() { }

            //    public MyLinkType_Color(System.String url) : base(url) { }

            //    /// <summary>
            //    /// Nesne formatanırken, renk ve mouse girdi çıktı formatlamaları yapılır.
            //    /// </summary>
            //    /// <param name="id">Nesnenin id kodu</param>
            //    /// <param name="parent">Nesneye sahip olan tableCell nesnesi</param>
            //    /// <param name="style">Nesnenin stil bilgileri</param>
            //    /// <param name="margin">Nesnenin boşluk bilgileri</param>
            //    /// <param name="value">Nesnenin değeri</param>
            //    /// <param name="upperLevel">Upper Level mı?</param>
            //    /// <returns></returns>
            //    public override System.Web.UI.Control PaintCell(System.String id, System.Web.UI.WebControls.TableCell parent, FarPoint.Web.Spread.Appearance style, FarPoint.Web.Spread.Inset margin, System.Object value, System.Boolean upperLevel)
            //    {
            //        Control link = base.PaintCell(id, parent, style, margin, value, upperLevel);
            //        string[] str = this.NavigateUrl.Split('!');
            //        ((HyperLink)link).NavigateUrl = str[0];

            //        ((WebControl)link).Attributes.Add("onclick", str[0] + "; return false;");
            //        if (str.Length > 1)
            //        {
            //            str[1] = "color: " + str[1] + "; text-decoration: none;";
            //            ((WebControl)link).Attributes.Add("style", str[1]);
            //            ((WebControl)link).Attributes.Add("onmouseover", "this.style.textDecoration='underline'");
            //            ((WebControl)link).Attributes.Add("onmouseout", "this.style.textDecoration='none'");
            //        }
            //        return link;
            //    }
            //}

            [Serializable()]
            public class MyCheckBoxType_ChkSum : FarPoint.Web.Spread.CheckBoxCellType
            {
                public MyCheckBoxType_ChkSum() { }

                public override System.Web.UI.Control PaintCell(System.String id, System.Web.UI.WebControls.TableCell parent, FarPoint.Web.Spread.Appearance style, FarPoint.Web.Spread.Inset margin, System.Object value, System.Boolean upperLevel)
                {
                    CheckBox chk = (CheckBox)base.PaintCell(id, parent, style, margin, value, upperLevel).Controls[0];
                    chk.Attributes.Add("onclick", "FpLCheckBoxSelectTopla(this);");
                    return chk;
                }
            }
            [Serializable()]
            public class MyCheckBoxType : FarPoint.Web.Spread.CheckBoxCellType
            {
                public MyCheckBoxType() { }

                public override System.Web.UI.Control PaintCell(System.String id, System.Web.UI.WebControls.TableCell parent, FarPoint.Web.Spread.Appearance style, FarPoint.Web.Spread.Inset margin, System.Object value, System.Boolean upperLevel)
                {
                    CheckBox chk = (CheckBox)base.PaintCell(id, parent, style, margin, value, upperLevel).Controls[0];
                    return chk;
                }
            }
        }

        #endregion

        #region "Farpoint Toplam - Hüseyin"

        public static void FpLToplamSatirOlustur(FarPoint.Web.Spread.FpSpread fpL)
        {
            FarPoint.Web.Spread.FpSpread kontrol = fpL;
            FarPoint.Web.Spread.SheetView s = kontrol.Sheets[0];
            int rowCount = s.ColumnHeader.RowCount;
            s.ColumnHeader.RowCount += 2;
            s.ColumnHeader.Cells[0, 0].RowSpan += 2;

            int i = 0;
            for (i = rowCount; i < rowCount + 2; i++)
            {
                for (int j = 1; j < s.ColumnCount; j++)
                {
                    s.ColumnHeader.Cells[i, j].HorizontalAlign = HorizontalAlign.Right;
                    s.ColumnHeader.Cells[i, j].Margin.Right = 10;
                }
            }

            s.ColumnHeader.Cells[rowCount, 1].Value = OrtakClassRes.IST013;
            s.ColumnHeader.Cells[rowCount + 1, 1].Value = OrtakClassRes.IST014;
        }

        public static void FpLToplamSatirDoldur(FarPoint.Web.Spread.FpSpread fpL)
        {
            FarPoint.Web.Spread.FpSpread kontrol = fpL;
            FarPoint.Web.Spread.SheetView s = kontrol.Sheets[0];
            int colStart = 2;
            int columnCount = s.ColumnCount - colStart;

            double[] colGenelToplam = new double[columnCount];
            string colDeger = "";

            int i = 0;
            for (i = 0; i < columnCount; i++)
            {
                for (int j = 0; j < s.RowCount; j++)
                {
                    colDeger = ParaDegerDuzenle(s.Cells[j, i + colStart].Value);
                    colGenelToplam[i] += OrtakFonksiyonlar.ConvertToDbl(colDeger);
                }
            }

            int rowIndexGenelTop = s.ColumnHeader.RowCount - 1; //Genel Toplam

            for (i = 0; i < columnCount; i++)
            {
                s.ColumnHeader.Cells[rowIndexGenelTop, i + colStart].Value = ParaDegerDuzenle(colGenelToplam[i]);
            }
        }

        private static string ParaDegerDuzenle(object p1)
        {
            string deger = string.Empty;
            double v1 = 0.0;
            if (p1 != null)
            {
                v1 = OrtakFonksiyonlar.ConvertToDbl(p1);
                deger = v1.ToString("#,###");
            }
            return deger;
        }

        #endregion

        [Serializable()]
        public class MyGridColorStyle : Theme
        {
            private TNS.KYM.Kullanici _kullanici;
            private static string _degiskenAd = "MyGridColorStyle";
            private string _themeName;

            public MyGridColorStyle(TNS.KYM.Kullanici kullanici)
            {
                _kullanici = kullanici;
            }

            public void Load()
            {
                _themeName = GenelIslemler.KullaniciDegiskenGetir(_kullanici.kullaniciKodu, _degiskenAd);
                LoadTheme();
            }

            public static void Save(TNS.KYM.Kullanici kullanici, string themeName)
            {
                GenelIslemler.KullaniciDegiskenSakla(kullanici, _degiskenAd, themeName);
            }

            private void LoadTheme()
            {
                switch (_themeName)
                {
                    case "Theme1": //Mavi
                        {
                            ThemeDefault();
                            break;
                        }
                    case "Theme2": //Turuncu
                        {
                            base.HeaderBackColor = System.Drawing.Color.FromArgb(250, 227, 177);
                            base.HeaderForeColor = System.Drawing.Color.FromArgb(190, 100, 2);
                            base.lockBackColor = System.Drawing.Color.FromArgb(255, 246, 229);
                            base.lockForeColor = System.Drawing.Color.FromArgb(230, 128, 20);
                            base.SelectionBackColor = System.Drawing.Color.FromArgb(250, 227, 177);
                            break;
                        }
                    case "Theme3": //Pembe
                        {
                            base.HeaderBackColor = System.Drawing.Color.FromArgb(255, 197, 187);
                            base.HeaderForeColor = System.Drawing.Color.FromArgb(140, 12, 12);
                            base.lockBackColor = System.Drawing.Color.FromArgb(255, 240, 240);
                            base.lockForeColor = System.Drawing.Color.FromArgb(255, 144, 144);
                            base.SelectionBackColor = System.Drawing.Color.FromArgb(255, 197, 187);
                            break;
                        }
                    case "Theme4": //Menekşe
                        {
                            base.HeaderBackColor = System.Drawing.Color.FromArgb(232, 210, 240);
                            base.HeaderForeColor = System.Drawing.Color.FromArgb(97, 0, 180);
                            base.lockBackColor = System.Drawing.Color.FromArgb(246, 235, 255);
                            base.lockForeColor = System.Drawing.Color.FromArgb(115, 56, 166);
                            base.SelectionBackColor = System.Drawing.Color.FromArgb(232, 210, 240);
                            break;
                        }
                    default: { ThemeDefault(); break; }
                }
            }

            private void ThemeDefault()
            {
                base.HeaderBackColor = System.Drawing.Color.FromArgb(230, 240, 254);
                base.HeaderForeColor = System.Drawing.Color.FromArgb(0, 0, 128);
                base.lockBackColor = System.Drawing.Color.FromArgb(246, 246, 255);
                base.lockForeColor = System.Drawing.Color.FromArgb(30, 144, 255);
                base.SelectionBackColor = System.Drawing.Color.FromArgb(230, 240, 254);
            }
        }


        public class Theme
        {
            public System.Drawing.Color HeaderBackColor;
            public System.Drawing.Color HeaderForeColor;
            public System.Drawing.Color lockBackColor;
            public System.Drawing.Color lockForeColor;
            public System.Drawing.Color SelectionBackColor;
        }
    }
}

namespace OrtakClass
{
    using System;
    using System.IO;
    using System.Security.Permissions;
    using System.Web;
    using System.Web.UI;

    //
    // The StreamPageStatePersister is an example view state
    // persistence mechanism that persists view and control
    // state on the Web server.
    //
    [AspNetHostingPermission(SecurityAction.Demand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class StreamPageStatePersister : PageStatePersister
    {

        public StreamPageStatePersister(Page page)
            : base(page)
        {
        }
        //
        // Load ViewState and ControlState.
        //
        public override void Load()
        {
            Stream stateStream = GetSecureStream();

            // Read the state string, using the StateFormatter.
            StreamReader reader = new StreamReader(stateStream);

            IStateFormatter formatter = this.StateFormatter;
            string fileContents = reader.ReadToEnd();

            // Deserilize returns the Pair object that is serialized in
            // the Save method.
            Pair statePair = (Pair)formatter.Deserialize(fileContents);

            ViewState = statePair.First;
            ControlState = statePair.Second;
            reader.Close();
            stateStream.Close();
        }
        //
        // Persist any ViewState and ControlState.
        //
        public override void Save()
        {

            if (ViewState != null || ControlState != null)
            {
                if (Page.Session != null)
                {
                    Stream stateStream = GetSecureStream();

                    StreamWriter writer = new StreamWriter(stateStream);

                    IStateFormatter formatter = this.StateFormatter;
                    Pair statePair = new Pair(ViewState, ControlState);

                    // Serialize the statePair object to a string.
                    string serializedState = formatter.Serialize(statePair);

                    writer.Write(serializedState);
                    writer.Close();
                    stateStream.Close();
                }
                else
                    throw new InvalidOperationException("Session needed for StreamPageStatePersister.");
            }
        }
        // Return a secure Stream for your environment.
        private Stream GetSecureStream()
        {
            // You must provide the implementation to build
            // a secure Stream for your environment.
            return null;
        }
    }

    /// <summary>
    /// Sertifika Politikası Sınıfı
    /// </summary>
    public class CertificatePolicy : System.Net.ICertificatePolicy
    {
        /// <summary>
        /// Servis Noktası, Sertifika bilgileri, İstek, Problem koduna göre Doğrulama sonucunu döndüren fonksiyon
        /// </summary>
        /// <param name="servicepoint">Servis noktası bilgisini tutan, System.Net.ServicePoint tipinde sınıf</param>
        /// <param name="certificate">Sertifika bilgisini tutan, X509 Sertifika tipinde sınıf</param>
        /// <param name="request">İstek bilgilerini tutan, System.Net.WebRequest tipinde sınıf </param>
        /// <param name="problem">Problem kodunu tutan, Int tipinde sınıf</param>
        /// <returns>Bool tipinde sınıf döndürür</returns>
        public bool CheckValidationResult(System.Net.ServicePoint servicepoint, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Net.WebRequest request, int problem)
        {
            return true;
        }
    }
}

