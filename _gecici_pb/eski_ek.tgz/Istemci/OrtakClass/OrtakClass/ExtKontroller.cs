﻿using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS;
using TNS.BKD;
using TNS.DEG;
using TNS.KYM;
using System.Xml;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Ext1.Net
{
    public class ExtYilDonem : Ext1.Net.TextField
    {
        private Ext1.Net.Spinner sp = new Spinner();

        public int Tur
        {
            get
            {
                return -1;
            }
            set
            {
                //this.Attributes.Add("Tur", value.ToString());
                this.CustomConfig.Add(new ConfigItem("tur", value.ToString()));
            }
        }

        public int Yil
        {
            get
            {
                return OrtakFonksiyonlar.ConvertToInt(this.Attributes["Yil"], 1);
            }
            set
            {
                this.Attributes.Add("Yil", value.ToString());
                sp.Value = value;
            }
        }

        public int YilMaks
        {
            get
            {
                return sp.MaxValue;
            }
            set
            {
                sp.MaxValue = value;
            }
        }

        public int YilMin
        {
            get
            {
                return sp.MinValue;
            }
            set
            {
                sp.MinValue = value;
            }
        }

        public ExtYilDonem()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            sp.ID = SpinnerID(this.ClientID);
            //Ext1.net.DirectMethod.request('IzinDonemBul', {url:'../InsanKaynaklari/TanimIzinTur.aspx', specifier:'static', params:{yil:this.value}, success:function(r){\r\n" + this.ClientID + ".yil=" + sp.ID + ".value;" + this.ClientID + ".setValue(r);" + this.ClientID + ".fireEvent('change');\r\n}});
            sp.Listeners.Spin.Handler = $"if (this.field.initialConfig.tur == \"2\") tut = this.value + \"-\" + (this.value + 1); else tut = this.value; this.field.setValue(tut);\r\n";
            this.Plugins.Add(sp);
            this.ReadOnly = true;
        }

        private string SpinnerID(string dllId)
        {
            return dllId + "_spin";
        }
    }


    public class ExtOrgSecim : Ext1.Net.DropDownField
    {
        TNS.KYM.Kullanici kullanan;
        private string kullanicininBirimleri = "";
        public string KullanicininBirimleri
        {
            get
            {
                return kullanicininBirimleri;
            }
            set
            {
                kullanicininBirimleri = value;
            }
        }

        private int agacTur = 1;
        public int AgacTur
        {
            get
            {
                return agacTur;
            }
            set
            {
                agacTur = value;
            }
        }

        private string kodNo = "1";
        public string KodNo { get { return kodNo; } set { kodNo = value; } }

        private int yil = 0;
        public int Yil { get { return yil; } set { yil = value; } }

        private bool kodAd = false;
        public bool KodAd { get { return kodAd; } set { kodAd = value; } }

        private bool checkli = false;
        public bool Checkli { get { return checkli; } set { checkli = value; } }

        private bool ikonVar = false;
        public bool IkonVar { get { return ikonVar; } set { ikonVar = value; } }

        private int yetkiKodu = 0;
        public int YetkiKodu { get { return yetkiKodu; } set { yetkiKodu = value; } }

        private bool showMask = false;
        public bool ShowMask { get { return showMask; } set { showMask = value; } }

        private string nodeID = "0";
        public string NodeID { get { return nodeID; } set { nodeID = value; } }

        private int yukseklik = 250;
        public int Yukseklik { get { return yukseklik; } set { yukseklik = value; } }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            Editable = true;
            EnableKeyEvents = true;
            TriggerIcon = TriggerIcon.Ellipsis;
            Mode = DropDownMode.ValueText;
            SelectOnFocus = true;
            kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false, true);
            FieldTrigger ft = new FieldTrigger();
            ft.Icon = Net.TriggerIcon.Clear;
            Triggers.Add(ft);
            Listeners.Blur.Fn = CikdimId(this.ClientID);
            Listeners.KeyPress.Fn = TusaBasildiID(this.ClientID);
            Listeners.TriggerClick.Handler = "if (index == 0) { this.clearValue();  " + TreePanelID(this.ClientID) + ".root.reload();}";
            Component.Add(TreePanelOl(this.ClientID));
            this.ResourceManager.AddScript(" var " + ArananId(this.ClientID) + "='';" + AgacDoldurFunction(this.ClientID) + GosterFunction(this.ClientID) + ZamanFunctionlar(this.ClientID));
        }

        private string ZamanFunctionlar(string ddlId)
        {
            return "\r\nvar " + AcTimeOutID(ddlId) + " = null; \r\nfunction " + TusaBasildiID(ddlId) + "(el, event) { " + CikdimId(ddlId) + "(); " + AcTimeOutID(ddlId) + " = setTimeout(function () { " + GosterID(ddlId) + "(); }, 800); }\r\nfunction " + CikdimId(ddlId) + "() { if (" + AcTimeOutID(ddlId) + " != null) { clearTimeout(" + AcTimeOutID(ddlId) + "); " + AcTimeOutID(ddlId) + " = null; } }";
        }

        private string CikdimId(string ddlId)
        {
            return ddlId + "_Cikdim";
        }

        private string TusaBasildiID(string ddlId)
        {
            return ddlId + "_TusaBasildi";
        }

        private string AcTimeOutID(string ddlId)
        {
            return ddlId + "_AcTimeOut";
        }

        private string GosterFunction(string ddlId)
        {
            return "\r\nfunction " + GosterID(ddlId) + "() { " + ArananId(this.ClientID) + " = " + ddlId + ".getText(); " + TreePanelID(ddlId) + ".root.reload(); if (!" + ddlId + ".isExpanded()) " + ddlId + ".onTriggerClick(); }";
        }

        private string GosterID(string ddlId)
        {
            return ddlId + "_Goster";
        }

        private string TreePanelID(string ddlId)
        {
            return ddlId + "_trpBirim";
        }

        private string PanelID(string ddlId)
        {
            return ddlId + "_pnlBirim";
        }

        private Panel TreePanelOl(string ddlId)
        {
            Panel p = new Panel();
            p.ID = PanelID(ddlId);
            p.Width = Width;
            p.Items.Add(TreePanelYap(ddlId));
            return p;
        }

        private TreePanel TreePanelYap(string ddlId)
        {
            TreePanel tp = new TreePanel();
            tp.ClientIDMode = System.Web.UI.ClientIDMode.Static;
            tp.ID = TreePanelID(ddlId);
            tp.Height = Yukseklik == 0 ? 250 : Yukseklik;
            tp.AutoWidth = true;
            tp.AutoScroll = true;
            tp.Border = false;
            tp.RootVisible = false;
            AsyncTreeNode atn = new AsyncTreeNode();
            atn.NodeID = NodeID;
            atn.Expanded = true;
            atn.Icon = Net.Icon.Note;
            tp.Root.Add(atn);
            tp.Listeners.BeforeLoad.Fn = AgacDoldurAd(ddlId);
            tp.Listeners.Click.Handler = ddlId + ".setValue(node.id, node.text, false); " + ddlId + ".collapse();";
            return tp;
        }

        private string ArananId(string ddlId)
        {
            return ddlId + "_Aranan";
        }

        private string AgacDoldurAd(string ddlId)
        {
            return ddlId + "_OrgBirimDoldur";
        }

        private string AgacDoldurFunction(string ddlId)
        {
            string orgBirim = string.Format("ozellikAra: false, yetkiliOlduguMuhasebeBirim: '{0}', adi: {1}, kodNo:'{2}', yil:{3}, kodAd:{4}, checkli:{5}, ikonVar:{6}, yetkiKodu:{7}, showMask: {8}", KullanicininBirimleri, ArananId(ddlId), KodNo, Yil, KodAd.ToString().ToLower(), Checkli.ToString().ToLower(), IkonVar.ToString().ToLower(), YetkiKodu, ShowMask.ToString().ToLower());
            return "\r\nfunction " + AgacDoldurAd(ddlId) + "(node) {Ext1.WindowMgr.bringToFront(" + PanelID(ddlId) + ");var orgBirim = { " + orgBirim + " }; " + ArananId(ddlId) + " = ''; " + AgacDoldurJSFonksiyonAd() + "(node, orgBirim); }";
        }

        private string AgacDoldurJSFonksiyonAd()
        {
            if (AgacTur == 3)
                return "nodeLoadButceKod";
            else if (AgacTur == 2)
                return "nodeLoadOdaParam";
            else
                return "nodeLoadOrgBirimParam";
        }
    }

    public class ExtMuhSecim : Ext1.Net.ComboBox
    {
        TNS.KYM.Kullanici kullanan = null;
        Ext1.Net.Store icStore;
        private bool kullanicininBirimleri = true;

        public bool KullanicininBirimleri
        {
            get
            {
                //if (ViewState["KullanicininBirimleri"] != null)
                //{
                //    kullanicininBirimleri = bool.Parse(ViewState["KullanicininBirimleri"].ToString());
                //}
                return kullanicininBirimleri;
            }
            set
            {
                kullanicininBirimleri = value;
                //ViewState["KullanicininBirimleri"] = value;
            }
        }

        protected override void OnInit(EventArgs e)
        {
            icStore = new Ext1.Net.Store();
            icStore.Proxy.Add(new PageProxy());
            icStore.RefreshData += MuhasebeStore_OnRefreshData;
            kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false, true);
            //.OnRefreshData. 

            this.DisplayField = "MUHASEBEKODAD";
            this.ValueField = "MUHASEBEKODAD";
            //Create the store
            JsonReader _jsonReader = new JsonReader();
            _jsonReader.Fields.Add("MUHASEBEKODAD");
            icStore.Reader.Add(_jsonReader);

            this.Store.Add(icStore);
            base.OnInit(e);
        }

        //public override string Text
        //{
        //    get
        //    {
        //        return base.Text.ToUpper();
        //    }
        //    set
        //    {
        //        base.Text = value.ToUpper();

        //    }
        //}

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }

        protected override void OnDataBinding(EventArgs e)
        {
            base.OnDataBinding(e);
        }

        private string MuhasebeBirimListesiDoldur(string kurum, string kistas, bool bosEkle)
        {
            string ilkMuhasebe = "";
            if (!string.IsNullOrWhiteSpace(kistas))
            {
                icStore.DataSource = TNS.MUH.Arac.MuhasebeListesiDoldur(kullanan, kurum, kistas, bosEkle, out ilkMuhasebe, kullanicininBirimleri);
                icStore.DataBind();
            }
            return ilkMuhasebe;
        }

        public void MuhasebeStore_OnRefreshData(object o, StoreRefreshDataEventArgs args)
        {
            //MuhasebeBirimListesiDoldur("", args.Parameters["query"], true);
            MuhasebeBirimListesiDoldur(OrtakClass.GenelIslemlerIstemci.VarsayilanKurumBul(), args.Parameters["query"], true);
        }
    }

    public class ExtCokluSecim : Ext1.Net.DropDownField
    {
        TNS.KYM.Kullanici kullanan = null;
        Ext1.Net.Store icStore;
        Ext1.Net.GridPanel gp;
        Ext1.Net.CheckboxSelectionModel csm;

        public string KodAlan { get; set; }
        public int KodAlanTur { get; set; }
        public string AdAlan { get; set; }


        public bool SingleSelect
        {
            get
            {
                return csm.SingleSelect;
            }
            set
            {
                csm.SingleSelect = value;
            }
        }

        public ExtCokluSecim()
        {
            kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false, true);
            csm = new CheckboxSelectionModel();
            csm.SingleSelect = false;
        }

        protected override void OnInit(EventArgs e)
        {
            Mode = DropDownMode.ValueText;
            base.OnInit(e);
            this.Component.Add(GridPanelOl());
            this.ResourceManager.AddScript(PersonelTipDegerOku() + PersonelTipKodOku() + PersonelTipDegerSec());
            this.Editable = false;
        }

        private Ext1.Net.GridPanel GridPanelOl()
        {
            icStore = new Ext1.Net.Store();
            icStore.ID = StoreID();
            JsonReader.Config cnf = new JsonReader.Config();
            cnf.IDProperty = KodAlanBul;

            JsonReader _jsonReader = new JsonReader(cnf);
            _jsonReader.Fields.Add(KodAlanBul, KodAlanTurBul);
            _jsonReader.Fields.Add(AdAlanBul, RecordFieldType.String);
            icStore.Reader.Add(_jsonReader);

            gp = new GridPanel();
            gp.ID = GridPanelID();
            gp.AutoExpandColumn = AdAlanBul;
            gp.Height = new Unit("350");
            gp.Listeners.BeforeShow.Handler = "setTimeout( function(){ " + MetotOnAdOl() + "DegerSec(" + this.ID + "," + this.KodAlanTur + ");}, 10)";
            gp.Store.Add(icStore);
            gp.ColumnModel.Columns.Add(AdKolonuOl());
            gp.SelectionModel.Add(SelModelOl());
            return gp;
        }

        private string PersonelTipDegerSec()
        {
            string tut = "\r\nfunction "+ MetotOnAdOl() + "DegerCevir(deger, tur) {\r\n" +
                "if(tur == 2) return deger;\r\n" +
                "else return parseInt(deger);\r\n" +
                "}\r\n";
            tut += "\r\nfunction " + MetotOnAdOl() + "DegerSec(dd, tur) {\r\n" +
            "var veriler = dd.underlyingValueField.value.split(';');\r\n" +
            "var sm = dd.component.getSelectionModel();\r\n" +
            "sm.clearSelections();\r\n" +
            "for (var i = 0; i < veriler.length; i++) {\r\n" +
            "    sm.selectById("+ MetotOnAdOl() + "DegerCevir(veriler[i], tur), true);\r\n" +
            "}}\r\n";
            return tut;
        }

        private string PersonelTipKodOku()
        {
            string tut = "\r\nfunction " + MetotOnAdOl() + "KodOku(csm) {\r\n" + "var retVal = '';\r\n" +
                "for (var i = 0; i < csm.selections.length; i++) {\r\n" +
                "    if (retVal != '') retVal += ';';\r\n" +
                "    retVal += csm.selections.items[i].data." + KodAlanBul + ";\r\n" +
                "}\r\n" +
                "return retVal;\r\n" +
                " }\r\n";
            return tut;
        }

        private string PersonelTipDegerOku()
        {
            string tut = "\r\nfunction " + MetotOnAdOl() + "DegerOku(csm) {\r\n" + "var retVal = '';\r\n" +
                "for (var i = 0; i < csm.selections.length; i++) {\r\n" +
                "    if (retVal != '') retVal += ',';\r\n" +
                "    retVal += csm.selections.items[i].data." + AdAlanBul + ";\r\n" +
                "}\r\n" +
                "if (csm.selections.length > 1)\r\n" +
                "    retVal = '[' + retVal + ']';\r\n" +
                "return retVal;\r\n" +
                "}\r\n";
            return tut;
        }

        private CheckboxSelectionModel SelModelOl()
        {
            csm.ID = SelModelID();
            csm.Listeners.SelectionChange.Handler = this.ID + ".setValue(" + MetotOnAdOl() + "KodOku(" + csm.ID + "), " + MetotOnAdOl() + "DegerOku(" + csm.ID + "), false);";

            return csm;
        }

        private string SelModelID()
        {
            return this.ID + "_sm";
        }

        private ColumnBase AdKolonuOl()
        {
            Ext1.Net.Column col = new Column();
            col.Header = this.FieldLabel;
            col.DataIndex = AdAlanBul;
            col.ColumnID = AdAlanBul;
            return col;
        }

        private string StoreID()
        {
            return this.ID + "_sto";
        }

        private string MetotOnAdOl()
        {
            return this.ID;
        }

        private string GridPanelID()
        {
            return this.ID + "_gp";
        }

        public void ListeDoldur(TNSCollection col)
        {
            icStore.DataSource = col;
            icStore.DataBind();
        }

        public void ListeSec(List<StrKodStrAd> col)
        {
            string kod = "";
            string ad = "";
            foreach (StrKodStrAd s in col)
            {
                if (kod != "")
                {
                    kod += ",";
                    ad += ",";
                }
                kod += s.kod;
                ad += s.ad;
            }
            if (col.Count > 1)
                ad = "[" + ad + "]";
            this.SetValue(kod, ad);
            //this.ResourceManager.AddScript("+MetotOnAdOl()+"DegerSec(" + csm.ID + ", '" + kod + "');");
        }

        private string KodAlanBul
        {
            get
            {
                string tut = KodAlan;
                if (string.IsNullOrWhiteSpace(tut)) return "kod";
                return tut;
            }
        }

        private string AdAlanBul
        {
            get
            {
                string tut = AdAlan;
                if (string.IsNullOrWhiteSpace(tut)) return "ad";
                return tut;
            }
        }

        private RecordFieldType KodAlanTurBul
        {
            get
            {
                if (KodAlanTur == 2) return RecordFieldType.String;
                return RecordFieldType.Int;
            }
        }
    }
}
