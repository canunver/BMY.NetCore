﻿#if !MU
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Security.Permissions;
using System.Web;
using System.Collections;
using System.ComponentModel;

namespace TNS.WebControls
{
    public enum ENUMTNSDalCocukTur
    {
        CocukYok = 0, CocukOku = 1, CocukVarAcik = 2, CocukVarKapali = 3
    }

    [ParseChildren(true, "Dallar")]
    public class TNSDal
    {
        private string m_Deger = string.Empty;
        private string m_Baslik = string.Empty;
        private bool m_Gizli = false;
        private TNSDalListesi m_Dallar;
        private ENUMTNSDalCocukTur m_cocukTur = ENUMTNSDalCocukTur.CocukOku;
        private int m_SoldanPay = 16;

        public TNSDal()
        {
            m_Dallar = new TNSDalListesi();
        }

        public TNSDal(string pDeger, string pBaslik, bool pGizli, ENUMTNSDalCocukTur pCocukTur)
        {
            m_Dallar = new TNSDalListesi();
            Deger = pDeger;
            Baslik = pBaslik;
            Gizli = pGizli;
            CocukTur = pCocukTur;
        }


        public int SoldanPay
        {
            get
            {
                return m_SoldanPay;
            }
            set
            {
                m_SoldanPay = value;
            }
        }

        public ENUMTNSDalCocukTur CocukTur
        {
            get
            {
                return m_cocukTur;
            }
            set
            {
                m_cocukTur = value;
            }
        }

        public string Deger
        {
            get
            {
                return m_Deger;
            }
            set
            {
                m_Deger = value;
            }
        }

        public string Baslik
        {
            get
            {
                return m_Baslik;
            }
            set
            {
                m_Baslik = value;
            }
        }

        public bool Gizli
        {
            get
            {
                return m_Gizli;
            }
            set
            {
                m_Gizli = value;
            }
        }

        [PersistenceMode(PersistenceMode.InnerProperty),]
        public TNSDalListesi Dallar
        {
            get
            {
                return m_Dallar;
            }
        }

        public void RenderContents(TNSAgac agac, int siraNo, HtmlTextWriter output, int seviye)
        {
            if (!Gizli)
            {
                string icDivID = "IC" + agac.ID + "_" + Deger;
                string resimID = "RES" + agac.ID + "_" + Deger;

                string onClickStr = "";
                if (!String.IsNullOrEmpty(agac.OnClientClick))
                    onClickStr = "onclick=\"" + agac.OnClientClick + "('" + Deger + "', '" + Baslik.Replace("'", "\\'") + "');\"";

                string onDblClickStr = "";
                if (!String.IsNullOrEmpty(agac.OnClientDblClick))
                    onDblClickStr = "ondblclick=\"" + agac.OnClientDblClick + "('" + Deger + "', '" + Baslik.Replace("'", "\\'") + "');\"";

                bool divAcik = false;
                string resimAdresStr = "";
                string resimHREFStr = "onclick=\"javascript:AcKapaDiv('" + agac.ID + "', '" + icDivID + "', '" + resimID + "', '" + Deger + "');\"";

                if (CocukTur == ENUMTNSDalCocukTur.CocukOku)
                {
                    resimAdresStr = agac.KapaliResim;
                }
                else if (CocukTur == ENUMTNSDalCocukTur.CocukYok)
                {
                    resimHREFStr = "";
                    resimAdresStr = agac.CocuksuzSatirGif;
                }
                else if (CocukTur == ENUMTNSDalCocukTur.CocukVarKapali)
                {
                    resimAdresStr = agac.KapaliResim;
                }
                else
                {
                    resimAdresStr = agac.AcikResim;
                    divAcik = true;
                }


                string displayStr;
                if (divAcik)
                    displayStr = "display: block;";
                else
                    displayStr = "display: none;";

//                output.Write("<table><tr><td><a id='" + resimID + "' href=\"" + resimHREFStr + "\"><img src='" + resimAdresStr + "' class='" + agac.ClassResim + "'></a></td><td " + onClickStr + " " + onDblClickStr + " class='" + agac.ClassYazi + "'>" + Baslik + "</td></tr></table>");
                output.Write("<span style='white-space: nowrap;' " + onClickStr + " " + onDblClickStr + " class='" + agac.ClassYazi + "'>\r\n<img id='" + resimID + "' src='" + resimAdresStr + "' class='" + agac.ClassResim + "' " + resimHREFStr + "/>" + Baslik + "</span><br>\r\n");
//                output.Write("<a id='" + resimID + "' href=\"" + resimHREFStr + "\"><img src='" + resimAdresStr + "' class='" + agac.ClassResim + "'></a>" + Baslik + "");

                output.Write("<div id='" + icDivID + "'" + " style='" + displayStr + "position: relative; user-select: none;-moz-user-select: none; overflow: inherit; left:" + SoldanPay + "px'" + " COCUKTUR='" + ((int)CocukTur).ToString() + "'" + " >\r\n");
                Dallar.RenderContents(agac, output, seviye + 1);
                output.Write("</div>\r\n");
            }
        }

    }


    public class TNSDalListesi : CollectionBase
    {
        // Gets and sets validator at the specified position
        public TNSDal this[int index]
        {
            get
            {
                return (TNSDal)InnerList[index];
            }
            set
            {
                InnerList[index] = value;
            }
        }

        public void Add(TNSDal parca)
        {
            InnerList.Add(parca);
        }


        public void AddAt(int index, TNSDal parca)
        {
            InnerList.Insert(index, parca);
        }

        public void RenderContents(TNSAgac agac, HtmlTextWriter output, int seviye)
        {
            for (int i = 0; i < InnerList.Count; i++)
            {
                ((TNSDal)InnerList[i]).RenderContents(agac, i, output, seviye);
            }
        }
    }


    [ParseChildren(true, "Dallar"),
    ToolboxData("<{0}:TNSAgac runat=server></{0}:TNSAgac>"),
    AspNetHostingPermission(SecurityAction.Demand,
        Level = AspNetHostingPermissionLevel.Minimal),
    AspNetHostingPermission(SecurityAction.InheritanceDemand,
        Level = AspNetHostingPermissionLevel.Minimal),
    ]
    public class TNSAgac : WebControl, INamingContainer
    {
        private TNSDalListesi m_Dallar;


        private string m_OnClientClick;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("")]
        public string OnClientClick
        {
            get
            {
                return m_OnClientClick;
            }
            set
            {
                m_OnClientClick = value;
            }
        }

        private string m_OnClientDblClick;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("")]
        public string OnClientDblClick
        {
            get
            {
                return m_OnClientDblClick;
            }
            set
            {
                m_OnClientDblClick = value;
            }
        }

        private string m_AcikResim;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("../App_themes/Images/Minus.gif")]
        public string AcikResim
        {
            get
            {
                return m_AcikResim;
            }
            set
            {
                m_AcikResim = value;
            }
        }

        private string m_KapaliResim;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("../App_themes/Images/Plus.gif")]
        public string KapaliResim
        {
            get
            {
                return m_KapaliResim;
            }
            set
            {
                m_KapaliResim = value;
            }
        }

        private string m_CocuksuzSatirGif;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("../App_themes/Images/Arrows.gif")]
        public string CocuksuzSatirGif
        {
            get
            {
                return m_CocuksuzSatirGif;
            }
            set
            {
                m_CocuksuzSatirGif = value;
            }
        }

        private string m_ClassResim;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("")]
        public string ClassResim
        {
            get
            {
                return m_ClassResim;
            }
            set
            {
                m_ClassResim = value;
            }
        }

        private string m_ClassYazi;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("")]
        public string ClassYazi
        {
            get
            {
                return m_ClassYazi;
            }
            set
            {
                m_ClassYazi = value;
            }
        }

        private string m_JavaScriptLink;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("../script/TNSAgac.js?mc=03022015")]
        public string JavaScriptLink
        {
            get
            {
                return m_JavaScriptLink;
            }
            set
            {
                m_JavaScriptLink = value;
            }
        }

        private string m_CSSLink;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("../App_themes/TNSTab.css")]
        public string CSSLink
        {
            get
            {
                return m_CSSLink;
            }
            set
            {
                m_CSSLink = value;
            }
        }

        private string m_YukleAdres;
        [PersistenceMode(PersistenceMode.InnerProperty), DefaultValue("SayfaYukle.aspx?SecKod=")]
        public string YukleAdres
        {
            get
            {
                return m_YukleAdres;
            }
            set
            {
                m_YukleAdres = value;
            }
        }

        public TNSAgac()
        {
            m_Dallar = new TNSDalListesi();
        }

        [PersistenceMode(PersistenceMode.InnerProperty),]
        public TNSDalListesi Dallar
        {
            get
            {
                return m_Dallar;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            if (!string.IsNullOrEmpty(JavaScriptLink))
            {
                System.Web.UI.ClientScriptManager csm;
                try
                {
                    csm = this.Page.ClientScript;
                    csm.RegisterClientScriptInclude("TNSAgac", JavaScriptLink);
                }
                catch { }
            }

            if (!string.IsNullOrEmpty(CSSLink))
            {
                try
                {

                    System.Web.UI.HtmlControls.HtmlHead h = this.Page.Header;
                    System.Web.UI.HtmlControls.HtmlLink hl = new System.Web.UI.HtmlControls.HtmlLink();
                    hl.Href = CSSLink;
                    hl.Attributes["type"] = "text/css";
                    hl.Attributes["rel"] = "stylesheet";
                    h.Controls.Add(hl);
                }
                catch { }
            }
            base.OnLoad(e);
        }

        protected override HtmlTextWriterTag TagKey
        {
            get
            {
                return HtmlTextWriterTag.Div;
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            this.Attributes["AcikResim"] = this.AcikResim;
            this.Attributes["KapaliResim"] = this.KapaliResim;
            this.Attributes["ClassResim"] = this.ClassResim;
            this.Attributes["YukleAdres"] = this.YukleAdres;
            base.OnPreRender(e);
            
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            try
            {
                if (Visible)
                {
                    Dallar.RenderContents(this, output, 0);
                }
            }
            catch (Exception ex)
            {
                output.Write(ex.StackTrace);
            }
        }

    }
}
#endif