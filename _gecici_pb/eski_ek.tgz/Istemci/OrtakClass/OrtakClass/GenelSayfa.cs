using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml;
using Newtonsoft.Json.Linq;
using OrtakClass;
using TNS;
using TNS.KYM;

namespace istemciUzayi
{
    public class GenelGiris : System.Web.UI.Page
    {
        protected IKYMServis servisKym = TNS.KYM.Arac.Tanimla();
        static string anaSayfa = "GirisBilgi" + istemciUzayi.GenelSayfa.menuTur + ".aspx";

        protected string aktifDil = "";

        public string sistemUyarisi { get; private set; } = null;
        public string ikiAsamaliGiris { get; private set; } = null;

        protected string DilDegistir(string dil)
        {
            if (!string.IsNullOrEmpty(dil))
            {
                HttpCookie cookDil = new HttpCookie("KulDil");
                cookDil.Value = dil;
                cookDil.Expires = DateTime.Now.AddYears(1);
                cookDil.HttpOnly = true;
                cookDil.Secure = true;
                Response.Cookies.Add(cookDil);
            }
            else
            {
                HttpCookie cookDil = Request.Cookies["KulDil"];
                if (cookDil != null)
                {
                    System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(cookDil.Value);
                    dil = cookDil.Value;
                }

                if (string.IsNullOrEmpty(dil))
                {
                    if (string.IsNullOrEmpty(dil))
                        dil = TNS.BKD.Arac.DefaultDil;

                    if (string.IsNullOrEmpty(dil))//Değişken xml de dil bölümü boş ise
                        dil = "tr";

                    //Merkez bankasında herkes ing dilinde görmeye başlayınca aşağıya indirildi - Melih 05.04.2021
                    if (string.IsNullOrEmpty(dil))
                    {
                        if (Request.UserLanguages != null && Request.UserLanguages.Length > 0)
                        {
                            string tDil = Request.UserLanguages[0].Substring(0, 2);

                            for (int dilNo = 0; dilNo < TNS.BKD.Arac.DillerLength; dilNo++)
                            {
                                string d = TNS.BKD.Arac.Diller(dilNo);
                                if (tDil == d)
                                {
                                    dil = d;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(dil);
            return dil;
        }

        protected override void InitializeCulture()
        {
            aktifDil = DilDegistir(Request.QueryString["dil"]);
        }

        protected void Yonlendir(KullaniciVAN kullanici, bool sessiondan, bool SSOGirisMi, bool anaKlasorden = false)
        {
            //if (SessionIdDegistir(kullanici.kullanici.kullaniciKodu, GenelIslemler.GetIPAddress()))
            //{
            //}
            //else
            {
                OturumBilgisiIslem a = new OturumBilgisiIslem();
                kullanici.kullanici.aktifKultur = System.Threading.Thread.CurrentThread.CurrentUICulture.Name;
                kullanici.kullanici.telefon = GenelIslemler.GetIPAddress();
                kullanici.kullanici.ipAddress = GenelIslemler.GetIPAddress();
                a.KullaniciBilgiYaz(kullanici.kullanici);
            }
            bool parolaDegistir = false;
            if (!(sessiondan || SSOGirisMi))
                parolaDegistir = GenelIslemler.ParolaSuresiKontrol(kullanici.kullanici, true, anaKlasorden);

            //Parametrik modül yönlendirme
            if (!string.IsNullOrEmpty(Request.QueryString["modul"]) && !string.IsNullOrEmpty(Request.QueryString["sayfa"]))
            {
                string modul = Request.QueryString["modul"] == null ? string.Empty : Request.QueryString["modul"];
                string sayfa = Request.QueryString["sayfa"] == null ? string.Empty : Request.QueryString["sayfa"]; ;
                string parametre = Request.QueryString["parametre"] == null ? string.Empty : Request.QueryString["parametre"];

                string adres = "";
                if (!string.IsNullOrEmpty(modul))
                    adres = modul + "/";
                adres += sayfa;

                string[] pArray = { "" };
                char[] pChar = { '-' };

                if (!string.IsNullOrEmpty(parametre))
                {
                    pArray = parametre.Split(pChar);
                }

                if (pArray.Length > 0 && pArray.Length % 2 == 0)
                {
                    adres += "?";

                    for (int i = 0; i < pArray.Length; i += 2)
                    {
                        adres += pArray[i] + "=" + pArray[i + 1];
                        if (i < pArray.Length - 2)
                            adres += "&";
                    }
                }

                Response.Redirect(adres);
                return;
            }
            //Parametrik modül yönlendirme bitti

            HttpContext.Current.Response.Write("<script>");
            string url = "";
            try
            {
                url = OrtakFonksiyonlar.ConvertToStr(OturumBilgisiIslem.BilgiOkuDegisken("url", false)) + "";
            }
            catch (Exception)
            { }

            if (sessiondan)
            {
                if (OrtakFonksiyonlar.ConvertToInt(GenelIslemler.WebConfigOku("Entegrasyon", "0"), 0) == 0)
                {
                    if (!string.IsNullOrEmpty(url) && (url.IndexOf("Giris.aspx") < 1 && url.IndexOf("giris.aspx") < 1))
                        HttpContext.Current.Response.Write("parent.location.href='" + url + "';");
                    else
                        HttpContext.Current.Response.Write("parent.frmSgb.location.href='" + YonlenecekSayfaBul(kullanici.kullanici) + "';");
                }
                else
                {
                    if ((!string.IsNullOrEmpty(url) && (url.IndexOf("SGBNet/SGBGiris.aspx") < 1 && url.IndexOf("SGBNet/sgbgiris.aspx") < 1))
                        && (!string.IsNullOrEmpty(url) && (url.IndexOf("Giris.aspx") < 1 && url.IndexOf("giris.aspx") < 1)))
                        HttpContext.Current.Response.Write("parent.frmSgb.location.href='" + url + "';");
                    else
                    {
                        HttpContext.Current.Response.Write("parent.frmSgb.location.href='" + YonlenecekSayfaBul(kullanici.kullanici) + "';");
                    }
                }
            }
            else
            {
                if (OrtakFonksiyonlar.ConvertToInt(GenelIslemler.WebConfigOku("Entegrasyon", "0"), 0) == 0)
                {
                    if (!string.IsNullOrEmpty(url) && (url.IndexOf("Giris.aspx") < 1 && url.IndexOf("giris.aspx") < 1))
                        HttpContext.Current.Response.Write("parent.location.href='" + url + "';");
                    else
                        HttpContext.Current.Response.Write("parent.location.href='" + YonlenecekSayfaBul(kullanici.kullanici) + "';");
                }
                else
                    HttpContext.Current.Response.Write("parent.frmSgb.location.href='" + YonlenecekSayfaBul(kullanici.kullanici) + "';");
            }
            HttpContext.Current.Response.Write("</script>");
            HttpContext.Current.Response.End();
        }

        private bool SessionIdDegistir(string kullaniciKodu, string ipAdres)
        {
            return false;
            //// 1) Yeni Session ID ürettin:
            //var manager = new SessionIDManager();
            //string yeniSessionId = manager.CreateSessionID(HttpContext.Current);

            //string currentUrl = Request.Url.AbsolutePath;
            //string dir = VirtualPathUtility.GetDirectory(currentUrl);

            //// relative path
            //string relativeInitUrl = VirtualPathUtility.Combine(dir, "OrtakSayfa/GirisSon.aspx");

            //// tam URL üretelim
            //string initUrl = $"{Request.Url.Scheme}://{Request.Url.Authority}{relativeInitUrl}";

            //string postData = "kullaniciKodu=" + Uri.EscapeDataString(kullaniciKodu) + "&ipAdres=" + Uri.EscapeDataString(ipAdres);
            //string cookieHeader = "ASP.NET_SessionId=" + yeniSessionId;

            //// Sadece sunucu içi çağrıda, koddan:
            //try
            //{
            //    yeniSessionId = OrtakFonksiyonlar.WebdenOku(
            //        initUrl,
            //        postData,                        // POST => null değil
            //        cookieHeader,                    // session id
            //        "BURAYA_COK_GIZLI_BIR_DEGER"     // çok gizli anahtar
            //    );
            //}
            //catch (Exception ex)
            //{
            //    yeniSessionId = null;
            //    OrtakFonksiyonlar.HataDosyaYaz("DBGSession.txt", initUrl + "\r\n" + ex.Message, true);
            //    return false;
            //}
            //if (string.IsNullOrWhiteSpace(yeniSessionId) || yeniSessionId.Length > 20)
            //{
            //    OrtakFonksiyonlar.HataDosyaYaz("DBGSession.txt", initUrl + "\r\n" + yeniSessionId, true);
            //    return false;
            //}
            //else
            //{
            //    var cookie = new HttpCookie("ASP.NET_SessionId", yeniSessionId);
            //    cookie.HttpOnly = true;
            //    Response.Cookies.Add(cookie);
            //    return true;
            //}
        }

        protected string YonlenecekSayfaBul(Kullanici kullanan)
        {
            try
            {
                string odemeEmriMifYetkisi = kullanan.YetkiTipiDegeriBul(21);
                if (!string.IsNullOrWhiteSpace(odemeEmriMifYetkisi))
                {
                    string[] birimler = odemeEmriMifYetkisi.Split(';', ',');
                    if (birimler.Length > 0 && !string.IsNullOrWhiteSpace(birimler[0]))
                    {
                        string[] sayBirim = birimler[0].Split('-');
                        if (sayBirim.Length == 2 && !string.IsNullOrWhiteSpace(sayBirim[0]) && !string.IsNullOrWhiteSpace(sayBirim[1]) && sayBirim[0] != "*" && sayBirim[1].Length == 3)
                        {
                            BirimMesaj form = new BirimMesaj();
                            form.saymanlikKod = OrtakFonksiyonlar.ConvertToInt(sayBirim[0], -1);
                            form.birimKod = sayBirim[1];
                            form.kurKod = GenelIslemlerIstemci.VarsayilanKurumBul();
                            form.durumlar = ((int)BirimMesaj.MesajDurum.Yayinda).ToString();
                            int mesajSay = servisKym.BirimMesajiSayisiBul(kullanan, form);

                            if (mesajSay > 0)
                            {
                                return "Duyuru/BirimMesajlariGoster.aspx?say=" + sayBirim[0] + "&bir=" + sayBirim[1];
                            }
                        }
                    }
                }
            }
            catch { }
            string adres = "";
            if (IsTabletOrMobile(this.Request))
            {
                adres = IlkSayfaBul(kullanan, "AcilisTab");
            }
            else
            {
                adres = IlkSayfaBul(kullanan, "AcilisMasa");
            }
            if (string.IsNullOrWhiteSpace(adres))
            {
                adres = "ortakSayfa/" + anaSayfa;
            }
            return adres;
        }

        public static bool IsTabletOrMobile(HttpRequest httpRequest)
        {
            try
            {
                if (httpRequest.Browser.IsMobileDevice)
                {
                    return true;
                }

                //int wight = httpRequest.Browser.ScreenPixelsWidth;
                //int height = httpRequest.Browser.ScreenPixelsHeight;
                //if (wight < 720 && height < 1280) return true;
                System.Text.RegularExpressions.Regex r = new System.Text.RegularExpressions.Regex("Windows NT", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                if (r.IsMatch(httpRequest.UserAgent)) return false;

                r = new System.Text.RegularExpressions.Regex("Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune|Tablet|iPad|PlayBook|BB10|Z30|Nexus 10|Nexus 7|GT-P|SCH-I800|Xoom|Silk|KFAPWI", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return r.IsMatch(httpRequest.UserAgent);
            }
            catch
            {
                return false;
            }
        }

        private string IlkSayfaBul(Kullanici kullanan, string damga)
        {
            string tut = kullanan.yetkiTipiDegerleri[damga];
            if (string.IsNullOrWhiteSpace(tut)) return "";
            return tut.Split(';', ',')[0];
        }

        protected void PageLoad(GenelGiris giris)
        {
            KullaniciVAN kv = SSO1Giris();
            string yazilimAd = System.Configuration.ConfigurationManager.AppSettings.Get("yazilimAd");

            this.sistemUyarisi = System.Configuration.ConfigurationManager.AppSettings.Get("sistemUyarisi");
            this.ikiAsamaliGiris = System.Configuration.ConfigurationManager.AppSettings.Get("ikiAsamaliGiris");

            if (string.IsNullOrEmpty(yazilimAd)) yazilimAd = "SGB.net";

            this.Title = OrtakClassRes.IST023;
            if (this.Title.StartsWith("SGB.net"))
                this.Title = yazilimAd;

            if (kv != null)
            {
                Yonlendir(kv, false, true, false);
            }
        }

        protected TNS.KYM.KullaniciVAN SSO1Giris()
        {
            string ssoLink = TNS.DEG.Arac.DegiskenDegerBul(0, "/SSO1");
            //ssoLink = "UATNG,UATNG.Giris,txtKKod,txtParola,r";
            if (string.IsNullOrEmpty(ssoLink)) return null;
            string[] ssoParca = ssoLink.Split(',');
            if (ssoParca.Length < 4) return null;

            string dllAd = ssoParca[0];
            string nesneAd = ssoParca[1];
            string queryUser = ssoParca[2];
            string queryPass = ssoParca[3];
            string[] ekBilgiler = null;

            if (ssoParca.Length > 4)
            {
                ekBilgiler = new string[ssoParca.Length - 4];
                for (int i = 4; i < ssoParca.Length; i++)
                {
                    ekBilgiler[i - 4] = this.Request[ssoParca[i]];
                }
            }

            try
            {
                System.Runtime.Remoting.ObjectHandle oh = Activator.CreateInstance(dllAd, nesneAd);
                if (oh != null)
                {
                    TNS.KYM.ITekNoktadanGiris ob = (TNS.KYM.ITekNoktadanGiris)oh.Unwrap();
                    return ob.GirisYap(this.Request[queryUser], this.Request[queryPass], ekBilgiler);
                }
            }
            catch
            {
            }
            return null;
        }

        public virtual bool UyumlulukModuVar()
        {
            return false;
        }

        private string UyumlulukModu()
        {
            if (UyumlulukModuVar()) return "IE=EmulateIE7"; else return "IE=edge,chrome=1";
        }

        protected override void OnPreRender(EventArgs e)
        {
            if (!UyumlulukModuVar())
                this.Response.AddHeader("X-UA-Compatible", UyumlulukModu());
            base.OnPreRender(e);
            this.Page.Response.Expires = 0;

            //string analytics = System.Configuration.ConfigurationManager.AppSettings.Get("analytics") + "";
            //HtmlGenericControl incGog = new HtmlGenericControl("script");
            //incGog.Attributes.Add("type", "text/javascript");
            //incGog.InnerHtml = "try{var _gaq = _gaq || [];_gaq.push(['_setAccount', '" + analytics + "']);_gaq.push(['_trackPageview']);(function() {var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);})();}catch(e){}";
            //if (!string.IsNullOrEmpty(analytics))
            //    this.Page.Header.Controls.AddAt(2, incGog);
        }
    }

    public class GenelSayfaV3 : GenelSayfa
    {
        public GenelSayfaV3()
            : base("3")
        {

        }
    }

    public class GenelSayfaV2 : GenelSayfa
    {
        public GenelSayfaV2()
            : base("2")
        {

        }
    }

    public class GenelSayfa : System.Web.UI.Page
    {
        string surum = "";
        public GenelSayfa(string pSurum)
        {
            surum = pSurum;
        }
        public GenelSayfa() { surum = "1"; }

        public static string KaynakOkuIstemci(string anahtar)
        {
            return OrtakClass.GenelIslemler.KaynakOku(OrtakClassRes.ResourceManager, anahtar);
        }

        protected override void InitializeCulture()
        {
            string yazilimAd = System.Configuration.ConfigurationManager.AppSettings.Get("yazilimAd");
            bool okuma = true;
            if (yazilimAd == "HibeDestek") okuma = false;

            if (kullanan == null)
                kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(okuma);
            if (kullanan != null)
            {
                string dil = kullanan.aktifKultur;
                if (!string.IsNullOrEmpty(dil))
                {
                    Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(dil);
                    Thread.CurrentThread.CurrentUICulture = new CultureInfo(dil);
                }
            }
        }

        protected TNS.KYM.Kullanici kullanan = null;
        public string formAdi = "";
        public string yardimBag = "";
        public string yardimYol = "";//System.Configuration.ConfigurationManager.AppSettings.Get("YardimYol");


        private string _raporSablonYol = System.Configuration.ConfigurationManager.AppSettings.Get("RaporSablonYol") + "";
        public string raporSablonYol
        {
            get
            {
                return TNS.Raporlama.RaporlamaServis.RaporSablonYolGetir(_raporSablonYol);
            }
        }

        public static string RaporSablonYol()
        {
            return TNS.Raporlama.RaporlamaServis.RaporSablonYolGetir(System.Configuration.ConfigurationManager.AppSettings.Get("RaporSablonYol") + "");
        }

        public static string menuTur = System.Configuration.ConfigurationManager.AppSettings.Get("MenuTur") + "";
        public string gecerliTema = "";

        public String StyleSheetThemeAdi
        {
            get
            {
                string yazilimAd = System.Configuration.ConfigurationManager.AppSettings.Get("yazilimAd");
                bool okuma = true;
                if (yazilimAd == "HibeDestek") okuma = false;

                if (this.Page.Request.QueryString["menuYok"] + "" != "")
                    this.ClientScript.RegisterClientScriptBlock(this.GetType(), "bodyResimYok", "<style type='text/css'>body{background-image: none;overflow: hidden;}html{overflow: auto;}</style>");

                string theme = "";

                if (kullanan == null)
                    kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(okuma);
                if (kullanan != null)
                {
                    gecerliTema = (string)OturumBilgisiIslem.BilgiOkuDegisken("Theme", false);
                    if (string.IsNullOrEmpty(gecerliTema))
                    {
                        gecerliTema = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "TEMA");
                        OturumBilgisiIslem.BilgiYazDegisken("Theme", gecerliTema);
                    }
                }
                if (string.IsNullOrEmpty(gecerliTema))
                    gecerliTema = System.Configuration.ConfigurationManager.AppSettings.Get("Theme") + "";
                if (string.IsNullOrEmpty(gecerliTema))
                    gecerliTema = "Theme1";

                theme = gecerliTema;

                return theme;
            }
        }

        public virtual bool UyumlulukModuVar()
        {
            return surum == "1";
        }

        //private Control MetaCompatible()
        //{
        //    HtmlGenericControl c = new HtmlGenericControl("meta");
        //    c.Attributes.Add("http-equiv", "X-UA-Compatible");
        //    c.Attributes.Add("content", UyumlulukModu());
        //    return c;
        //}

        private string UyumlulukModu()
        {
            if (UyumlulukModuVar()) return "IE=EmulateIE7"; else return "IE=edge,chrome=1";
        }

        protected override void OnPreRender(EventArgs e)
        {
            if (!UyumlulukModuVar())
                this.Response.AddHeader("X-UA-Compatible", UyumlulukModu());
            base.OnPreRender(e);
            this.Page.Response.Expires = 0;

            //Sayfalar için gerekli olan js dosyalarını include etmek için
            //***************************************************************
            string ustYol = "../";
            if (Path.GetFileName(Request.Path) == "Giris")
                ustYol = "";
            string token = (string)Session["CSRF_TOKEN"];
            ClientScript.RegisterHiddenField("genelSayfaFormId", token);
            var meta = new HtmlMeta();
            meta.Name = "genelSayfaFormId";
            meta.Content = token;
            this.Page.Header.Controls.Add(meta);
            string tut = StyleSheetThemeAdi;
            this.Page.Header.Controls.AddAt(1, HtmlLinkOl(ustYol + "App_Themes/" + tut + "/" + tut + ".css?v=1", "text/css", "stylesheet"));

            string genelJs = "Script/genel.js?v=202604121500";

            string[] jQueryJS = new string[] { "Script/jquery/jquery-latest.min.js?v=03022017", "Script/jQuery/ui/jquery-ui-custom-latest.min.js?v=1", "Script/jQuery/dialog/modalPopUp.js?v=2", genelJs };
            for (int i = jQueryJS.Length - 1; i >= 0; i--)
            {
                HtmlGenericControl incJQ = new HtmlGenericControl("script");
                incJQ.Attributes.Add("type", "text/javascript");
                incJQ.Attributes.Add("language", "javascript");
                incJQ.Attributes.Add("src", ustYol + jQueryJS[i]);
                this.Page.Header.Controls.AddAt(1, incJQ);
            }
            //***************************************************************

            this.Page.Header.Controls.AddAt(1, HtmlLinkOl(ustYol + "Script/css/jquery-ui-custom-latest.css", "text/css", "stylesheet"));
            this.Page.Header.Controls.AddAt(1, HtmlLinkOl(ustYol + "App_Themes/Menu.css", "text/css", "stylesheet"));
            //***************************************************************

            JSResourceEkle(genelJs);
            ExtResourceManagerEkle();

            //Yavaşlamaya neden oluyor. Olmasına gerek yok
            //string analytics = System.Configuration.ConfigurationManager.AppSettings.Get("analytics") + "";
            //HtmlGenericControl incGog = new HtmlGenericControl("script");
            //incGog.Attributes.Add("type", "text/javascript");
            //incGog.InnerHtml = "try{var _gaq = _gaq || [];_gaq.push(['_setAccount', '" + analytics + "']);_gaq.push(['_trackPageview']);(function() {var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);})();}catch(e){}";
            //if (!string.IsNullOrEmpty(analytics))
            //    this.Page.Header.Controls.AddAt(2, incGog);

            //this.Page.Header.Controls.AddAt(0, MetaCompatible());
        }

        public static HtmlLink HtmlLinkOl(string href, string type, string rel)
        {
            HtmlLink link = new HtmlLink();
            link.Attributes.Add("href", href);
            link.Attributes.Add("type", type);
            link.Attributes.Add("rel", rel);
            return link;
        }

        private void ExtResourceManagerEkle()
        {
            if (surum != "1") return;

            if (this.Page == null)
                return;

            foreach (Control c in this.Page.Controls)
            {
                if (c.GetType() == typeof(Ext1.Net.ResourceManager))
                    return;
            }

            try
            {
                Ext1.Net.ResourceManager rm = new Ext1.Net.ResourceManager();
                rm.ID = "extResourceManager";
                this.Page.Controls.Add(rm);
            }
            catch { }
        }

        private void JSResourceEkle(string arananJS)
        {
            foreach (Control c in this.Page.Header.Controls)
            {
                if (c.GetType() == typeof(HtmlGenericControl))
                {
                    HtmlGenericControl hgc = (HtmlGenericControl)c;
                    if (hgc.TagName.ToLower() == "script"
                        && hgc.Attributes["src"].Contains(arananJS)
                        && !this.ClientScript.IsClientScriptBlockRegistered("GenelJS"))
                    {
                        GenelIslemlerIstemci.GenelJSResourceEkle(this);
                        break;
                    }
                }
                else if (c.GetType().ToString() == "System.Web.UI.ResourceBasedLiteralControl")
                {
                    LiteralControl hgc = (LiteralControl)c;
                    if (hgc.Text.Contains(arananJS)
                        && !this.ClientScript.IsClientScriptBlockRegistered("GenelJS"))
                    {
                        GenelIslemlerIstemci.GenelJSResourceEkle(this);
                        break;
                    }
                }
            }
        }

        private void MarjinAyarla(ControlCollection kontroller)
        {
            if (surum != "1") return;

            if (kontroller == null || kontroller.Count <= 0)
                return;

            foreach (Control c in kontroller)
            {
                if (c.GetType() == typeof(Ext1.Net.Viewport))
                    MarjinAyarla(c.Controls);
                else if (c.GetType() == typeof(Ext1.Net.BorderLayout))
                {
                    Ext1.Net.BorderLayout bl = (Ext1.Net.BorderLayout)c;
                    MarjinYukseklikAyarla(bl.Center);
                    MarjinYukseklikAyarla(bl.East);
                    MarjinYukseklikAyarla(bl.North);
                    MarjinYukseklikAyarla(bl.South);
                    MarjinYukseklikAyarla(bl.West);
                }
            }
        }

        private void MarjinYukseklikAyarla(Ext1.Net.BorderLayoutRegion blr)
        {
            if (blr != null && !string.IsNullOrEmpty(blr.MarginsSummary))
                blr.MarginsSummary = ""; //"2 " + blr.MarginsSummary.Substring(blr.MarginsSummary.IndexOf(" "));
        }

        public virtual void SayfaUstAltBolumYaz(Page p)
        {
            if (OrtakFonksiyonlar.WebConfigOku("SureUzatKapali", "0") == "1" && p.AppRelativeVirtualPath.IndexOf("/KYM/ParolaDegistir.aspx") < 1)
            {
                //LDAP değilse parola süre kontrolü yapılsın
                string ldapAdres = TNS.DEG.Arac.DegiskenDegerBul(0, "LDAP");
                if (string.IsNullOrWhiteSpace(ldapAdres))
                {
                    bool kontrol = GenelIslemler.ParolaSuresiKontrol(null, true, false);
                }
            }
            if (!string.IsNullOrEmpty(formAdi))
            {
                if (menuTur.Equals("Akordiyon") && surum == "1")
                    Ext1.Net.X.AddScript("try{window.top.SayfaBaslikAta('" + formAdi + "');}catch(e){}");
                else
                    p.Title = formAdi;
            }

            if (menuTur.Equals("Akordiyon") && surum == "1")
                Ext1.Net.X.AddScript("try{window.top.MevzuatUrlAta('" + MevzuatSayfaUrlGetir() + "');window.top.MevzuatUrlAta('" + YardimSayfaUrlGetir() + "');}catch(e){}");

            string veriGuncelleme = VeriTabaniGuncelleme();
            if (!string.IsNullOrEmpty(veriGuncelleme))
            {
                string veriGuncellemeHata = "<div>";
                veriGuncellemeHata += "<b>Veri tabanı bakımı yapılmaktadır.</b><br>Lütfen, bir süre sonra tekrar deneyiniz.";
                veriGuncellemeHata += "</div>";

                bool yoneticiMi = (bool)OturumBilgisiIslem.BilgiOkuDegisken("YoneticiMi", false);
                if (yoneticiMi)
                {
                    veriGuncellemeHata = "<div>";
                    veriGuncellemeHata += "<b>Veri tabanı bakımı yapılmaktadır.</b><br>Lütfen, bir süre sonra tekrar deneyiniz. Eğer uzun süre bu mesaj veriliyorsa güncelleme yarım kalmış olabilir. Veri tabanı güncellemesini tekrar yapın.(" + veriGuncelleme + ")";
                    veriGuncellemeHata += "</div>";
                    Response.Write(veriGuncellemeHata);
                }
                else
                {
                    System.Web.HttpContext.Current.Session.Abandon();
                    Response.Write(veriGuncellemeHata);
                    Response.End();
                    return;
                }
            }

            if (p.StyleSheetTheme == "")
                return;
            if (p.Request.QueryString["menuYok"] + "" != "")
            {
                if (menuTur.Equals("Akordiyon"))
                    MarjinAyarla(p.Form.Controls);
                return;
            }
            if (p.IsPostBack)
                return;
            Literal lKontrolUst = (Literal)p.FindControl("ltlUstBolum");
            if (lKontrolUst == null) return;
            Literal lKontrolAlt = (Literal)p.FindControl("ltlAltBolum");
            if (lKontrolAlt == null) return;

            if (kullanan == null)
                kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(true);

            //Postback öncesinde seçilen tabı tekrar göstermek için
            string aktifMenu = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "AKTIFMENU");
            if (aktifMenu == "") aktifMenu = "1";

            if (!menuTur.Equals("Akordiyon"))
            {
                //Eğer sessiona kayıt edilmiş ise onu oku 
                string ustMenu = (string)OrtakClass.OturumBilgisiIslem.BilgiOkuDegisken("UstMenu", false);
                string altMenu = (string)OrtakClass.OturumBilgisiIslem.BilgiOkuDegisken("AltMenu", false);
                if (!string.IsNullOrEmpty(ustMenu) && !string.IsNullOrEmpty(altMenu))
                {
                    ustMenu = ustMenu.Replace("!formAdi!", formAdi).ToString();
                    ustMenu = ustMenu.Replace("!aktifMenu!", aktifMenu).ToString();

                    //Mevzuat Kod Link Değiştirme İşlemi
                    int mevzuatKonum = ustMenu.IndexOf("id=\"aMevzuat\"");
                    if (mevzuatKonum > -1)
                    {
                        string endStr = "</a>";
                        string tmpStr = ustMenu.Substring(mevzuatKonum - 3);
                        ustMenu = ustMenu.Replace(tmpStr.Substring(0, tmpStr.IndexOf(endStr)) + endStr, MevzuatSayfaKodLinkGetir());
                    }

                    //Yardım Kod Link Değiştirme İşlemi
                    mevzuatKonum = ustMenu.IndexOf("id=\"aYardim\"");
                    if (mevzuatKonum > -1)
                    {
                        string endStr = "</a>";
                        string tmpStr = ustMenu.Substring(mevzuatKonum - 3);
                        ustMenu = ustMenu.Replace(tmpStr.Substring(0, tmpStr.IndexOf(endStr)) + endStr, YardimSayfaKodLinkGetir());
                    }
                    //**********************************

                    lKontrolUst.Text = ustMenu;
                    lKontrolAlt.Text = altMenu;
                    return;
                }
            }

            string yazilimUrl = GenelIslemler.YazilimURLBul(this.Request, false);

            StringBuilder strUst = new StringBuilder();
            //Sayfa üst bölgesi
            strUst.Append("<div id='wrapper'>");
            strUst.Append("<div id='header'>");
            if (!menuTur.Equals("Akordiyon"))
            {
                strUst.Append("<div class='logo'><a href='../OrtakSayfa/GirisBilgi.aspx' alt='sgb.net' target='_top'>sgb.net</a></div>");
                strUst.Append(MenuHazirla(p, kullanan));
            }
            else
                strUst.Append("<div class='kurumBanner'></div>");
            strUst.Append("</div>");//header

            string kullananBilgi = "";
            if (kullanan.ad != "")
                kullananBilgi = TNS.OrtakFonksiyonlar.IlkHarflerBuyuk(kullanan.ad + " " + kullanan.soyad) + " | ";

            //SİTE HARİTASI
            StringBuilder htmlSiteHaritasi = new StringBuilder();
            if (!menuTur.Equals("Akordiyon") && !string.IsNullOrEmpty(kullanan.ad))
            {
                htmlSiteHaritasi.Append("<a href='&#35;null' onclick=\"SHGG('../KYM/MenuSikKullanilan.aspx?menuYok=1&tur=harita');return false;\">" + OrtakClassRes.IST010 + "&nbsp;<span id='_SHY'>&#9660;</span></a> | ");
                htmlSiteHaritasi.Append("<div id='_menuSiteHaritasi' style='display:none'>");
                htmlSiteHaritasi.Append("<iframe id='ifrmSH' src='' width='280px' height='355px' frameborder='0' scrolling='no'></iframe>");
                htmlSiteHaritasi.Append("</div>");
                htmlSiteHaritasi.Append("<script language=\"Javascript\" type=\"text/javascript\">");
                htmlSiteHaritasi.Append("function SHGG(adres) {var menu = document.getElementById('_menuSiteHaritasi'); if (menu.style.display == 'none') { menu.style.display = 'block'; _SHY.innerHTML='&#9650;' ;var frm = document.getElementById('ifrmSH'); if(adres!='' && adres!=frm.src) {frm.src = adres;}else {}}else { menu.style.display = 'none'; _SHY.innerHTML='&#9660;';}; } ");
                htmlSiteHaritasi.Append("</script>");
            }
            //***************

            string bayrakBilgi = "<a tabindex=\"0\" href=\"?dil=tg\"><img src=\"..\\app_themes\\images\\bayrak\\tg.png\" alt=\"tg\" /></a>&nbsp; " +
                                 "<a tabindex=\"1\" href=\"?dil=ru\"><img src=\"..\\app_themes\\images\\bayrak\\ru.png\" alt=\"ru\" /></a>&nbsp; " +
                                 "<a tabindex=\"2\" href=\"?dil=en\"><img src=\"..\\app_themes\\images\\bayrak\\en.png\" alt=\"en\" /></a>&nbsp; " +
                                 "<a tabindex=\"3\" href=\"?dil=tr\"><img src=\"..\\app_themes\\images\\bayrak\\tr.png\" alt=\"tr\" /></a>&nbsp; | ";

            string cikisSayfa = yazilimUrl.Replace("giris.aspx", "");
            if (!cikisSayfa.Trim().EndsWith("/")) cikisSayfa += "/";
            cikisSayfa += "OrtakSayfa/Cikis.aspx";

            string sagBilgi = kullananBilgi + "<a href='../OrtakSayfa/GirisBilgi" + menuTur + ".aspx' alt='sgb.net' target='_top'>" + OrtakClassRes.IST009 + "</a>&nbsp; | " +
                              htmlSiteHaritasi.ToString() +
                               //"<a href='http://uygulama.sgb.gov.tr/ortakSayfa/Forum.aspx?user=" + OrtakFonksiyonlar.Sifrele(Server.UrlEncode(kullanan.kullaniciKodu)) + "&hash=" + kullanan.parola + "&url=" + HttpContext.Current.Request.Url.Scheme + "://" + HttpContext.Current.Request.Url.Host + HttpContext.Current.Request.ApplicationPath + "' target='_blank'>" +
                               //Resources.Istemci.IST011 + "</a> | " + MevzuatSayfaKodLinkGetir() + " | " 
                               YardimSayfaKodLinkGetir() + " | " +
                               "<a href='" + cikisSayfa + "' target='_top'>" + OrtakClassRes.IST012 + "</a>";

            string showFlag = System.Configuration.ConfigurationManager.AppSettings.Get("showFlag") + "";
            if (showFlag != "")
                sagBilgi = bayrakBilgi + sagBilgi;

            strUst.Append("<div class='box-wrapper-l'>&nbsp;</div>");
            strUst.Append("<div class='box-wrapper'><div class='box-sol'>!formAdi!</div><div class='box-sag'>" + sagBilgi + "</div></div>");
            strUst.Append("<div id='main'>");
            strUst.Append("<div id='content'>");

            StringBuilder strAlt = new StringBuilder();
            strAlt.Append("</div>");//content
            strAlt.Append("</div>");//main
            strAlt.Append("</div>");//wrapper
            if (OrtakFonksiyonlar.WebConfigOku("SureUzatKapali", "0") == "0")
                strAlt.Append("<iframe src='../ortakSayfa/SureUzat.aspx' width='0px' height='0px' frameborder='0' scrolling='no'></iframe>");

            lKontrolUst.Text = strUst.ToString();
            lKontrolAlt.Text = strAlt.ToString();

            OrtakClass.OturumBilgisiIslem.BilgiYazDegisken("UstMenu", lKontrolUst.Text);
            OrtakClass.OturumBilgisiIslem.BilgiYazDegisken("AltMenu", lKontrolAlt.Text);

            //sayfa başlığı değişken olduğu için sessionda değişiklik yapılması
            lKontrolUst.Text = lKontrolUst.Text.Replace("!formAdi!", formAdi).ToString();

            //Aktif tab değişken olduğu için sessionda değişiklik yapılması
            lKontrolUst.Text = lKontrolUst.Text.Replace("!aktifMenu!", aktifMenu).ToString();
        }

        string MevzuatSayfaKodLinkGetir()
        {
            string url = MevzuatSayfaUrlGetir();
            if (menuTur.Equals("Akordiyon"))
                url = "MevzuatAc();return false;";
            else
                url = string.Format("showPopWin('{0}', 835, 400, true, null);return false;", url);
            return string.Format("<a id=\"aMevzuat\" href=\"#\" onclick=\"{0}\" target=\"_blank\">{1}</a>", url, OrtakClassRes.IST047);
        }

        string MevzuatSayfaUrlGetir()
        {
            return "../KYM/MevzuatSayfa.aspx?menuYok=1&mevzuatSayfaKod=" + HttpContext.Current.Request.Url.LocalPath;
        }

        string YardimSayfaKodLinkGetir()
        {
            string url = YardimSayfaUrlGetir();
            if (menuTur.Equals("Akordiyon"))
                url = "YardimAc();return false;";
            else
                url = string.Format("showPopWin('{0}', 1000, 600, true, null);return false;", url);
            return string.Format("<a id=\"aYardim\" href=\"#\" onclick=\"{0}\" target=\"_blank\">{1}</a>", url, OrtakClassRes.IST054);
        }

        string YardimSayfaUrlGetir()
        {
            string yardimAdres = "../KYM/YardimSayfa.aspx?menuYok=1&sayfaKod=";
            string yol = HttpContext.Current.Request.Url.AbsolutePath;
            if (string.IsNullOrEmpty(yol)) return yardimAdres + "Belirsiz";
            string[] yolParcalar = yol.Split('/');
            if (yolParcalar == null) return yardimAdres + "Belirsiz";

            int boy = yolParcalar.Length;
            if (boy >= 2)
            {
                yol = yolParcalar[boy - 2] + "/" + yolParcalar[boy - 1];
            }
            else
                yol = HttpContext.Current.Request.Url.AbsolutePath;
            if (yol.Length > 5)
                yol = yol.Substring(0, yol.Length - 5);
            return yardimAdres + yol;
        }

        static string MenuHazirla(Page p, TNS.KYM.Kullanici kullanan)
        {
            List<string> gruplar = new List<string>();
            //Kullanan kişinin tiplerini bul
            string[] kullaniciYetki;
            HashTableArrayList kullaniciDamga = kullanan.yetkiTipiDegerleri;

            if (kullanan.kullaniciTipi != null && kullanan.kullaniciTipi.Length > 0)
            {
                kullaniciYetki = new string[kullanan.kullaniciTipi.Length];

                for (int i = 0; i < kullanan.kullaniciTipi.Length; i++)
                    kullaniciYetki[i] = ((int)kullanan.kullaniciTipi[i]).ToString();
            }
            else
                kullaniciYetki = new string[1];

            if (string.IsNullOrEmpty(kullaniciYetki[0]))  //|| kullaniciYetki[0] == "0"
                return "";

            StringBuilder s = new StringBuilder();
            string menuIcerigi = XMLMenuOku(kullaniciYetki, ref gruplar, kullaniciDamga);

            //EASY TABS 1.2 - MENU SETTINGS
            string menuAyar = "var tablink_idname = new Array('tablink');";
            menuAyar += "var tabcontent_idname = new Array('tabcontent');";
            menuAyar += "var tabcount = new Array('" + gruplar.Count.ToString() + "');";
            menuAyar += "var loadtabs = new Array('1');";
            menuAyar += "var activetab = !aktifMenu!;";
            menuAyar += "var autochangemenu = 0;";
            menuAyar += "var changespeed = 1;";
            menuAyar += "var stoponhover = 1;";
            s.Append("<script type='text/javascript'>" + menuAyar + "</script>");
            s.Append("<script src='../Script/jquery/menu/menu.js' type='text/javascript'></script>");

            //Üst menü oluşturma
            s.Append("<div class='nav-wrapper'>");
            s.Append("<div class='nav-wrapper-b'>");
            s.Append("<div class='nav-wrapper-t'></div>");
            s.Append("<div class='nav-wrapper-c'>");
            s.Append("<ul class='topnav'>");

            int grupNo = 0;
            foreach (string grupAd in gruplar)
            {
                grupNo++;
                s.Append("<li><a href='#' onclick=\"easytabs('1', '" + grupNo + "');return false;\" title='' id='tablink" + grupNo + "'><strong>" + grupAd + "</strong><span></span></a></li>");
            }
            s.Append("</ul>");//topnav ul
            s.Append("</div>");//nav-wrapper-c
            s.Append("</div>");//nav-wrapper-b
            s.Append("</div>");//nav-wrapper
            s.Append("<div style='clear: both'></div>");

            //Alt menü oluşturma
            s.Append("<div class='nav-wrapper-alt'>");
            s.Append("<ul id='hunt3'>");
            s.Append(menuIcerigi);
            s.Append("</ul>");//hunt3
            s.Append("</div>");//nav-wrapper

            return s.ToString();
        }

        static string XMLMenuOku(string[] kullaniciYetki, ref List<string> gruplar, HashTableArrayList kullaniciDamga)
        {
            string menuDosyaYolu = GenelIslemlerIstemci.MenuXmlPathBul();

            XmlDocument doc = new XmlDocument();
            doc.Load(menuDosyaYolu);
            XmlNodeList elemanlar = doc.GetElementsByTagName("Nodes");
            XmlNodeList menuler = elemanlar.Item(0).ChildNodes;

            StringBuilder s = new StringBuilder();
            int kolonNo = 1;
            s.Append(XMLMenuHazirla(kullaniciYetki, menuler, "", ref kolonNo, 0, ref gruplar, kullaniciDamga));

            return s.ToString();
        }

        public static string MenuAd(XmlNode eleman, string id)
        {
            string text = GenelIslemlerIstemci.OzellikVer(eleman, "Text");
            string resText = OrtakClassRes.ResourceManager.GetString(id);
            if (string.IsNullOrEmpty(resText))
                resText = id + "-" + text;
            text = resText;
            return text;
        }

        static string XMLMenuHazirla(string[] kullaniciYetki, XmlNodeList elemanlar, string yukseklik, ref int kolonNo, int solGirinti, ref List<string> gruplar, HashTableArrayList kullaniciDamga)
        {
            StringBuilder s = new StringBuilder();
            int grupSayac = 0;

            foreach (XmlNode eleman in elemanlar)
            {
                if (!string.IsNullOrEmpty(GenelIslemlerIstemci.OzellikVer(eleman, "Gizli")))
                    continue;

                string id = GenelIslemlerIstemci.OzellikVer(eleman, "ID");
                string tip = GenelIslemlerIstemci.OzellikVer(eleman, "Tip");
                string url = GenelIslemlerIstemci.OzellikVer(eleman, "URL");
                string yetki = GenelIslemlerIstemci.OzellikVer(eleman, "Yetki");
                string sayfaMenuID = GenelIslemlerIstemci.OzellikVer(eleman, "SayfadaGoster");
                string modulStr = GenelIslemlerIstemci.OzellikVer(eleman, "Modul") + "";

                bool altMenuEkle = string.IsNullOrEmpty(sayfaMenuID) ? true : false;
                string genislik = "";

                if (url == "") url = "#";
                string text = MenuAd(eleman, id);
                bool menuGorunsun = GenelIslemlerIstemci.MenuGorunsunmu(modulStr);

                //İşlem yapılacak menğye kullanıcı yetkilimi?
                if (menuGorunsun)
                    if (!GenelIslemlerIstemci.MenuyeYetkiliMi(kullaniciYetki, yetki, kullaniciDamga))
                        menuGorunsun = false;

                if (tip == "UstMenu")
                {
                    //ht:Eğer modül belirtilmiş ise ve görünmemesi gerekiyorsa 
                    //üst menü eklenmesin
                    if (!menuGorunsun) continue;
                    genislik = GenelIslemlerIstemci.OzellikVer(eleman, "Genislik");
                    yukseklik = GenelIslemlerIstemci.OzellikVer(eleman, "Yukseklik");
                }

                //Alt menulerin oluşturulması
                StringBuilder altMenu = new StringBuilder();
                if (altMenuEkle && eleman.ChildNodes.Count > 0)
                {
                    //ht:Eğer modül belirtilmiş ise ve görünmesi gerekiyorsa 
                    //alt menüler yüklensin
                    XmlNodeList menuler = eleman.ChildNodes;
                    if (menuGorunsun)
                        altMenu.Append(XMLMenuHazirla(kullaniciYetki, menuler, yukseklik, ref kolonNo, solGirinti, ref gruplar, kullaniciDamga));
                }

                //Alt Menu dolu ise üst bölümünü oluştur
                if (menuGorunsun && ((altMenuEkle && !string.IsNullOrEmpty(altMenu.ToString())) || (tip == "UstMenu" && eleman.ChildNodes.Count == 0)))//Sadece altmenüleri olmayan üstmenü
                {
                    if (tip == "Grup")
                    {
                        grupSayac++;
                        s.Append("<div id='tabcontent" + grupSayac + "'>");

                        gruplar.Add(text);
                    }
                    else if (tip == "UstMenu")
                    {
                        string referans = "";
                        if (url != "#")
                            referans = "href='" + url + "' target='_top'";
                        s.Append("<li><a class='catList' style='width: " + genislik + "px;' " + referans + "><strong>" + text + "</strong></a>");
                    }
                    else if (tip == "Kolon")
                        s.Append("<ul class='col" + kolonNo + "' style='height: " + yukseklik + "px;left:" + "solGirinti" + "px;'>");
                    else if (tip == "AltBolum")
                        s.Append("<li class='subTitle'>" + text + "</li>");

                    s.Append(altMenu);
                }
                else if (!altMenuEkle)
                {
                    string sayfaMenuUrl = "../OrtakSayfa/SayfaMenu.aspx?menuID=";
                    sayfaMenuUrl += sayfaMenuID.StartsWith("Menu") ? sayfaMenuID : id;
                    if (tip == "UstMenu")
                        s.Append("<li><a class='catList' style='width: " + genislik + "px;' href='" + sayfaMenuUrl + "' alt='" + text + "' target='_top'><strong>" + text + "</strong></a></li>");
                    else if (tip == "AltBolum")
                        s.Append("<li class='subTitle'><a href='" + sayfaMenuUrl + "' alt='" + text + "' target='_top'>" + text + "</a></li>");
                }

                //Menu elemanı ekleme işlemi
                if (string.IsNullOrEmpty(tip) && !string.IsNullOrEmpty(url))
                {
                    //ht:Modul var ise görünüp görünmeyeceği kontrol ediliyor
                    if (menuGorunsun)
                        s.Append("<li><a href='" + url + "' target='_top'>" + text + "</a></li>");
                }

                //Alt Menu dolu ise üst bölümünün kapatması
                if (altMenuEkle && !string.IsNullOrEmpty(altMenu.ToString()))
                {
                    if (tip == "Grup")
                    {
                        s.Append("</div>");
                        solGirinti = 1;
                    }
                    else if (tip == "UstMenu")
                    {
                        int menuGenislik = 800;//Üst menü için ayrılmış olan genişlik
                        int altMenuKolonGenislik = 280;//Üst menü için ayrılmış olan genişlik

                        s.Append("</li>");
                        int girinti = solGirinti;//Kendisi hariç toplam genişlik
                        int toplamKolon = kolonNo - 1;
                        if (toplamKolon == 1)//kolon numarası bir fazla gelir
                            girinti = 40;

                        int altMenuGenislik = toplamKolon * altMenuKolonGenislik;
                        //alt menü ortalı gösterilsin
                        girinti = (altMenuGenislik - Convert.ToInt32(genislik)) / 2;

                        //alt menü sınır dışında kalısa sağ taraf sınıra eşitlensin
                        if (solGirinti + (altMenuGenislik - girinti) > menuGenislik)
                            girinti = girinti + ((solGirinti + (altMenuGenislik - girinti)) - menuGenislik);

                        s.Replace("solGirinti", (girinti * -1).ToString());
                        kolonNo = 1;
                        solGirinti += Convert.ToInt32(genislik);
                    }
                    else if (tip == "Kolon")
                    {
                        s.Append("</ul>");
                        kolonNo++;
                    }
                }
            }

            return s.ToString();
        }

        static string VeriTabaniGuncelleme()
        {
            string degisken = "VERITABANIGUNCELLE";
            return GenelIslemler.KullaniciDegiskenGetir("stratek", degisken);
        }

        protected override void SavePageStateToPersistenceMedium(object state)
        {
            LosFormatter formatter = new LosFormatter();
            StringWriter writer = new StringWriter();
            formatter.Serialize(writer, state);
            string viewState = writer.ToString();
            byte[] data = Convert.FromBase64String(viewState);
            byte[] compressedData = GenelIslemler.Compress(data);
            string str = Convert.ToBase64String(compressedData);
            ClientScript.RegisterHiddenField("__CompressedVIEWSTATE", str);
        }

        protected override object LoadPageStateFromPersistenceMedium()
        {
            try
            {
                string viewstate = Request.Form["__CompressedVIEWSTATE"];
                byte[] data = Convert.FromBase64String(viewstate);
                byte[] uncompressedData = GenelIslemler.Decompress(data);
                string str = Convert.ToBase64String(uncompressedData);
                LosFormatter formatter = new LosFormatter();
                return formatter.Deserialize(str);
            }
            catch { }
            return null;
        }
    }
}
