﻿#if !MU
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web;
using System.Security.Permissions;
using System.Collections;
using OrtakClass;
using TNS.KYM;

namespace TNS.WebControls
{
    public enum ENUMFiltreAlanYerlesim
    {
        OnceSag, OnceAlt
    }

    public enum ENUMAlanEtiketYer
    {
        Ic, Sol, Ust
    }

    public class TNSFiltreAlanListesi : CollectionBase
    {
        // Gets and sets validator at the specified position
        public WebControl this[int index]
        {
            get { return (WebControl)InnerList[index]; }
            set { InnerList[index] = value; }
        }

        public void Add(WebControl parca)
        {
            InnerList.Add(parca);
        }

        public void AddAt(int index, WebControl parca)
        {
            InnerList.Insert(index, parca);
        }
    }


    [ParseChildren(true, "FiltreAlanlar"),
    ToolboxData("<{0}:TNSFiltre runat=server></{0}:TNSFiltre>"),
    AspNetHostingPermission(SecurityAction.Demand,
        Level = AspNetHostingPermissionLevel.Minimal),
    AspNetHostingPermission(SecurityAction.InheritanceDemand,
        Level = AspNetHostingPermissionLevel.Minimal),
    ]
    public class TNSFiltre : WebControl, INamingContainer, IPostBackEventHandler
    {
        private TNSFiltreAlanListesi _FiltreAlanlar = new TNSFiltreAlanListesi();
        public TNSFiltreAlanListesi FiltreAlanlar
        {
            get { return _FiltreAlanlar; }
        }

        //private int _SutunSay = 1;
        //public int SutunSay { get { return _SutunSay; } set { _SutunSay = value; } }

        //private ENUMFiltreAlanYerlesim _AlanYerlesim = ENUMFiltreAlanYerlesim.OnceSag;
        //public ENUMFiltreAlanYerlesim AlanYerlesim { get { return _AlanYerlesim; } set { _AlanYerlesim = value; } }

        //private int _SutunGenislik = 80;
        //public int SutunGenislik { get { return _SutunGenislik; } set { _SutunGenislik = value; } }

        private ENUMAlanEtiketYer _EtiketYer = ENUMAlanEtiketYer.Ic;
        public ENUMAlanEtiketYer EtiketYer { get { return _EtiketYer; } set { _EtiketYer = value; } }

        private string _JavaScript = null;
        public string JavaScript { get { return _JavaScript; } set { _JavaScript = value; } }

        private Unit _ListeUzunluk = new Unit("");
        public Unit ListeUzunluk { get { return _ListeUzunluk; } set { _ListeUzunluk = value; } }

        private string _FiltreVTAd = null;
        public string FiltreVTAd { get { return _FiltreVTAd; } set { _FiltreVTAd = value; } }

        private string _SessionAd = null;

        /// <summary>
        /// Bu alana değer atanmışsa, filtre alanlarındaki Value değerleri, FiltreAlandaki AlanVTAd özelliğini kullanılarak, HashTable'e çevrilir ve bu HashTable bu isimli Session'a yüklenir. 
        /// PageLoad olayında da bu Session değişkeninden alınan HashTable'daki değerler, Value alanlarına atanır.
        /// </summary>
        public string SessionAd { get { return _SessionAd; } set { _SessionAd = value; } }

        TextBox txtAd = null;
        Button btnKaydet = null;
        public WebControl this[int index]
        {
            get { return FiltreAlanlar[index]; }
        }

        protected override void CreateChildControls()
        {
            if (txtAd == null)
            {
                foreach (WebControl alan in FiltreAlanlar)
                {
                    Controls.Add(alan);
                }
                txtAd = new TextBox();
                txtAd.ID = "Ad";
                txtAd.CssClass = "veriAlan";
                Controls.Add(txtAd);
            }
            if (btnKaydet == null)
            {
                btnKaydet = new Button();
                btnKaydet.ID = "Kaydet";
                btnKaydet.OnClientClick = "javascript:if(AdGecerliMi(" + txtAd.ClientID + ")) " + Page.ClientScript.GetPostBackEventReference(this, "2") + ";return false;";
                btnKaydet.CssClass = "dugme";
                Controls.Add(btnKaydet);
            }
            base.CreateChildControls();
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            CreateChildControls();
            if (!this.Page.IsPostBack)
                IlkDegerleriAta();
        }

        protected override void OnLoad(EventArgs e)
        {
            System.Web.UI.ClientScriptManager csm;
            try
            {
                csm = this.Page.ClientScript;
                csm.RegisterClientScriptInclude("TNSFiltre", "../script/TNSFiltre.js?mc=03022015");
                csm.RegisterClientScriptInclude("HttpCagir", "../script/XmlHttp.js?mc=03022015");

                csm.RegisterClientScriptBlock(typeof(int), "FiltreMesaj", string.Format("var fiMesaj1 = \"{0}\";\r\nvar fiMesaj2 = \"{1}\";\r\nvar fiMesaj3 = \"{2}\";", "Seçilen filtre silinecektir. Onaylıyor musunuz?", "Seçilen filtrenin içeriği değiştirilecektir. Onaylıyor musunuz?", "Lütfen, filtre için bir ad giriniz!"), true);
            }
            catch { }

            try
            {
                //System.Web.UI.HtmlControls.HtmlHead h = this.Page.Header;
                //System.Web.UI.HtmlControls.HtmlLink hl = new System.Web.UI.HtmlControls.HtmlLink();
                //hl.Href = "../App_themes/" + CSSAd + ".css";
                //hl.Attributes["type"] = "text/css";
                //hl.Attributes["rel"] = "stylesheet";
                //h.Controls.Add(hl);
            }
            catch { }
            base.OnLoad(e);
        }

        private Hashtable SessionHt()
        {
            Hashtable ht = null;
            try
            {
                if (!string.IsNullOrEmpty(SessionAd))
                    ht = (Hashtable)this.Page.Session[SessionAd];
            }
            catch { return null; }
            return ht;

        }

        private void IlkDegerleriAta()
        {
            Hashtable ht = SessionHt();
            if (ht == null) return;

            for (int i = 0; i < FiltreAlanlar.Count; i++)
            {
                string vtAd = FiltreAlanlar[i].Attributes["AlanVTAd"];
                if (!string.IsNullOrEmpty(vtAd))
                {
                    try
                    {
                        ListeSatir ls = (ListeSatir)ht[vtAd];
                        this.Value(FiltreAlanlar[i], ls);
                    }
                    catch { }
                }
            }
        }

        public void Value(WebControl webControl, ListeSatir value)
        {
            if (value == null) return;
            if (webControl.GetType() == typeof(TNSOneri))
            {
                TNSOneri to = (TNSOneri)webControl;
                to.Value = value.kod;
                to.Text = value.ad;
            }
            else if (webControl.GetType() == typeof(DropDownList))
            {
                DropDownList dl = (DropDownList)webControl;
                try
                {
                    dl.SelectedValue = value.kod;
                }
                catch { }
            }
        }

        public ListeSatir Value(WebControl webControl)
        {
            if (webControl.GetType() == typeof(TNSOneri))
            {
                TNSOneri to = (TNSOneri)webControl;
                string deger = to.Text;
                if (deger == webControl.Attributes["Etiket"]) deger = "";
                ListeSatir ls = new ListeSatir(to.Value, deger);
                return ls;
            }
            else if (webControl.GetType() == typeof(DropDownList))
            {
                DropDownList dl = (DropDownList)webControl;
                ListItem deger = dl.SelectedItem;
                if (deger == null) return null;
                return new ListeSatir(deger.Value, deger.Text);
            }
            return null;
        }

        public string ValueOrText(WebControl webControl)
        {
            ListeSatir ls = Value(webControl);
            if (ls == null) return null;
            if (!string.IsNullOrEmpty(ls.kod)) return ls.kod;
            if (ls.ad != webControl.Attributes["Etiket"]) return ls.ad;
            return "";
        }

        public string ValueOrText(string vtAd)
        {
            for (int i = 0; i < FiltreAlanlar.Count; i++)
            {
                if (FiltreAlanlar[i].Attributes["AlanVTAd"].CompareTo(vtAd) == 0)
                {
                    return ValueOrText(FiltreAlanlar[i]);
                }
            }
            return null;
        }

        protected void RenderIcKontrol(HtmlTextWriter output, WebControl alan)
        {
            //    if (this.EtiketYer == ENUMAlanEtiketYer.Ust)
            //    {
            //        output.WriteLine("<div class=\"row1\" style=\"padding:0px;margin:0px;\">");
            //    }
            //output.WriteLine("<div class=\"row2\" style=\"height:22px;padding:0px;margin:0px;\">");


            //if (this.EtiketYer != ENUMAlanEtiketYer.Ic)
            //{
            //    output.WriteLine("<div class=\"yaziAlan\" style=\"padding:0px;margin:0px;\">" + alan.Attributes["Etiket"] + "</div><div class=\"ikiNokta\">:</div>");
            //}

            //if (this.EtiketYer == ENUMAlanEtiketYer.Ust)
            //{
            //    output.WriteLine("</div>");
            //    output.WriteLine("<div class=\"row3\" style=\"height:22px\">");
            //}

            output.WriteLine("<div class=\"filtreAlan\" id='div" + alan.ClientID + "' style=\"" + alan.Attributes["style"] + "\">");
            alan.RenderControl(output);
            output.WriteLine("</div>");

            //if (this.EtiketYer == ENUMAlanEtiketYer.Ust)
            //    output.WriteLine("</div>");
            //output.WriteLine("</div>");
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            try
            {
                if (Visible)
                {
                    string h = ListeUzunluk.ToString();
                    output.WriteLine("<div id=\"" + GirisAlanDivAd() + "\" "
                        + GenelIslemler.TirnakliParam(true, true, "class", "form")
                        + GenelIslemler.TirnakliParam(true, true, "style", "padding:2px 9px 2px 2px;margin:0px;")
                        + ">"); //div Form
                    int ekAlanSay = 0;
                    for (int i = 0; i < FiltreAlanlar.Count; i++)
                    {
                        if (string.IsNullOrEmpty(FiltreAlanlar[i].Attributes["EkAlan"]))
                            RenderIcKontrol(output, FiltreAlanlar[i]);
                        else
                            ekAlanSay++;
                    }
                    if (ekAlanSay > 0)
                    {
                        output.WriteLine("<div class=\"row\" style=\"height:15px;overflow:hidden;padding:0px;margin:0px;\">"); //div Filtre Ek Alan Göster Üst
                        output.WriteLine("<div class=\"yaziAlan\" style=\"overflow:hidden;min-width:0px;margin:3px 0px;text-align:left;\">");//div Filtre Ek Alan Göster
                        output.WriteLine("<a href=\"#\" onclick=\"javascript:DivGosterKapat('" + EkAlanDivAd() + "', " + (ekAlanSay * 26).ToString() + ")\">Ek Alanlar</a>");
                        output.WriteLine("</div>");//div Filtre Ek Alan Göster
                        output.WriteLine("</div>");//div Filtre Ek Alan Göster Üst
                        output.WriteLine("<div id=\"" + EkAlanDivAd() + "\" style=\"height:0px;width:100%;overflow:hidden;padding:0px;margin:0px;\">");//div Filtre Ek Alan Üst
                        for (int i = 0; i < FiltreAlanlar.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(FiltreAlanlar[i].Attributes["EkAlan"]))
                                RenderIcKontrol(output, FiltreAlanlar[i]);
                        }
                        output.WriteLine("</div>");////div Filtre Ek Alan Üst
                    }
                    output.WriteLine("</div>");//divForm

                    output.WriteLine("<div class=\"row\" style=\"height:22px;overflow:hidden;white-space:nowrap;font-size:x-small\">"); //Link Button Üst Div
                    if (string.IsNullOrEmpty(JavaScript))
                        output.WriteLine("<a href=\"#\" onclick=\"javascript:" + Page.ClientScript.GetPostBackEventReference(this, "1") + "\">Filtrele</a>&nbsp;&nbsp;&nbsp;");
                    else
                        output.WriteLine("<a href=\"#\" onclick=\"javascript:" + JavaScript + "\">Filtrele</a>&nbsp;&nbsp;&nbsp;");
                    output.WriteLine("<a href=\"#\" onclick=\"javascript:FiltreTemizle(" + GirisAlanDivAd() + ")\">Temizle</a>&nbsp;&nbsp;&nbsp;");
                    if (!string.IsNullOrEmpty(h))
                    {
                        output.WriteLine("<a href=\"#\" onclick=\"javascript:DivGosterKapat('" + AdAlanDivAd() + "', 45)\">Kaydet</a>");
                    }
                    output.WriteLine("</div>");////Link Button Üst Div

                    if (!string.IsNullOrEmpty(h))
                    {
                        //output.WriteLine("<div id='" + AdAlanDivAd() + "' class=\"row\" style=\"width:" + this.Width.ToString() + ";overflow:hidden;\">");//Ad Giriş Üst Div
                        //output.WriteLine("<div class=\"row\">");//Ad Giriş Text Üst Div

                        output.WriteLine("<div id='" + AdAlanDivAd() + "' class=\"row\" style=\"height:0px;width:165px;overflow:hidden;\">");//row1
                        output.WriteLine("<div class=\"row\">");//row2

                        output.WriteLine("<div class=\"yaziAlan\" style=\"width:20px;min-width:0px;margin:4px 0px;float:left\">");//yaziAlan
                        output.WriteLine("Ad&nbsp;:&nbsp;");
                        output.WriteLine("</div>");//YaziAlan

                        output.WriteLine("<div class=\"veriAlan\" style=\"width:80px;min-width:0px;margin:4px 0px;float:left\">");//Text veriAlan
                        txtAd.Height = new Unit("14px");
                        txtAd.Width = new Unit("70px");
                        txtAd.RenderControl(output);
                        output.WriteLine("</div>");//Text veriAlan

                        output.WriteLine("<div class=\"veriAlan\" style=\"width:50px;min-width:0px;margin:2px 0px;float:left\">");//button veriAlan
                        btnKaydet.Width = new Unit("50px");
                        btnKaydet.Height = new Unit("18px");
                        btnKaydet.Text = "Kaydet";
                        btnKaydet.RenderControl(output);
                        output.WriteLine("</div>");//button veriAlan

                        output.WriteLine("</div>");//row2
                        output.WriteLine("</div>");//row1

                        try
                        {
                            ListeSatir[] satirlar = KaydedilmisleriBul();
                            output.WriteLine("<div id='divTnsFiltreSakli' class='modul' "
                                + GenelIslemler.TirnakliParam(true, true, "row", "")
                                + GenelIslemler.TirnakliParam(true, true, "style", "height:" + h + ";width:" + this.Width.ToString() + ";overflow:auto;position:relative;")
                                + ">"); //Kayıtlı filtreler div
                            output.WriteLine("<div class='modulBaslik'>Saklı Filtreler</div>");
                            if (satirlar != null)
                                for (int i = 0; i < satirlar.Length; i++)
                                {
                                    SatirGoster(output, satirlar[i]);
                                }
                            output.WriteLine("</div>");//Kayıtlı filtreler div
                        }
                        catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                output.Write(ex.StackTrace);
            }
        }

        private string GirisAlanDivAd()
        {
            return this.ClientID + "Alanlar";
        }

        private void SatirGoster(HtmlTextWriter output, ListeSatir listeSatir)
        {
            output.WriteLine("<div class=\"row\" style=\"position:relative;height:22px;width:90%;overflow:hidden;margin:0px 0px;padding:0px 0px\">"); //Filtre Alan Üst Div
            output.WriteLine("<div class=\"yaziAlan\" style=\"position:absolute; left:0px;top:0px;width:16px; overflow:hidden;min-width:0px;margin:0px 0px;\">"); //Sil Tuş Div
            output.WriteLine("<a href=\"#\" onclick=\"javascript:if(fiDogrula(1))" + Page.ClientScript.GetPostBackEventReference(this, "3-" + listeSatir.kod) + "\"><img src='../app_themes/images/silx7.png' alt='Sil' style='margin:0px 3px 0px 3px;'></a>");
            output.WriteLine("</div>"); //Sil Tuş Div
            output.WriteLine("<div class=\"yaziAlan\" style=\"position:absolute; left:16px;top:0px;width:16px; overflow:hidden;min-width:0px;margin:0px 0px;\">"); //Değiştir Tuş Div
            output.WriteLine("<a href=\"#\" onclick=\"javascript:if(fiDogrula(2))" + Page.ClientScript.GetPostBackEventReference(this, "4-" + listeSatir.kod) + "\"><img src='../app_themes/images/eklex7.png' alt='Değiştir'></a>");
            output.WriteLine("</div>"); //Değiştir Tuş Div
            output.WriteLine("<div class=\"yaziAlan\" style=\"position:absolute; left:32px;top:0px;min-width:0px;margin:0px 0px;\">"); //Ad Alan Div
            output.WriteLine("<a href=\"#\" style=\"display:inline-block;white-space:nowrap;\" onclick=\"javascript:" + Page.ClientScript.GetPostBackEventReference(this, "5-" + listeSatir.kod) + "\">" + listeSatir.ad + "</a>");
            output.WriteLine("</div>"); //Ad Alan Div
            output.WriteLine("</div>"); //Filtre Alan Üst Div
        }

        private Filtre[] FiltreleriBul(int siraNo)
        {
            Filtre[] fLer = null;
            try
            {
                TNS.KYM.IKYMServis srv = TNS.KYM.Arac.Tanimla();
                fLer = srv.FiltreListele(OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false), this.FiltreVTAd, siraNo);
            }
            catch { }
            return fLer;
        }

        private ListeSatir[] KaydedilmisleriBul()
        {
            Filtre[] fLer = FiltreleriBul(0);
            if (fLer == null || fLer.Length == 0) return null;
            ListeSatir[] l = new ListeSatir[fLer.Length];
            for (int i = 0; i < l.Length; i++)
            {
                l[i] = new ListeSatir(fLer[i].siraNo.ToString(), fLer[i].ad);
            }
            return l;
        }

        private string EkAlanDivAd()
        {
            return ID + "EkDiv";
        }

        private string AdAlanDivAd()
        {
            return ID + "AdDiv";
        }

        #region IPostBackEventHandler Members
        public event EventHandler Filtrele;
        public void RaisePostBackEvent(string eventArgument)
        {
            if (eventArgument.Equals("1") || eventArgument.StartsWith("5"))
            {
                if (eventArgument.StartsWith("5"))
                {
                    Filtre[] fLer = FiltreleriBul(OrtakFonksiyonlar.ConvertToInt(eventArgument.Substring(2), -1));
                    if (fLer != null && fLer.Length == 1)
                        FiltreKayitliDegerleriAta(fLer[0].kriter);
                    else
                        return;
                }
                AlanDegerleriniSessionaAt();
                Filtrele(this, EventArgs.Empty);
            }
            else if (eventArgument.Equals("2"))
            {
                VeriTabaninaKaydet(0);
            }
            else if (eventArgument.StartsWith("3"))
            {
                VeriTabanindanSil(OrtakFonksiyonlar.ConvertToInt(eventArgument.Substring(2), -1));
            }
            else if (eventArgument.StartsWith("4"))
            {
                VeriTabaninaKaydet(OrtakFonksiyonlar.ConvertToInt(eventArgument.Substring(2), -1));
            }
        }

        /// <summary>
        /// XML formatındaki alanın değeri döndürülür. Verilen içerikten xml ayraçları temizlenir ve içerik bulunur.
        /// </summary>
        /// <param name="etiket">xml alanın başlangıç ve bitiş etikeri</param>
        /// <param name="icerik">etilet aranacak xml veri</param>
        /// <returns>XML veri içerisinde etiket değişkeni ile ayrılmış olan alanın değeri döndürülür.</returns>
        public static string KriterDegerVer(string etiket, string icerik)
        {
            string deger = "";
            int uzEtiket = etiket.Length;
            int res1 = icerik.IndexOf("<" + etiket + ">") + uzEtiket + 2;
            int res2 = icerik.IndexOf("</" + etiket + ">");
            if (res1 > -1 && res2 > -1)
                deger = icerik.Substring(res1, res2 - res1);

            return deger;
        }

        private void FiltreKayitliDegerleriAta(string kriter)
        {
            for (int i = 0; i < FiltreAlanlar.Count; i++)
            {
                string vtAd = FiltreAlanlar[i].Attributes["AlanVTAd"];
                if (!string.IsNullOrEmpty(vtAd))
                {
                    string kriterDeger = KriterDegerVer(vtAd, kriter);
                    Value(FiltreAlanlar[i], new ListeSatir(kriterDeger, kriterDeger));
                }
            }
        }

        private void VeriTabanindanSil(int siraNo)
        {
            Filtre f = new Filtre();
            f.kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false);
            f.grup = this.FiltreVTAd;
            f.siraNo = siraNo;

            Sonuc s = new Sonuc();
            s.DegerAta(f.KontrolEt(true));
            if (s.islemSonuc)
            {
                TNS.KYM.IKYMServis srv = TNS.KYM.Arac.Tanimla();
                s = srv.FiltreSil(f);
            }
        }

        private void VeriTabaninaKaydet(int siraNo)
        {
            Filtre f = new Filtre();
            f.kullanan = OrtakClass.OturumBilgisiIslem.KullaniciBilgiOku(false);
            f.grup = this.FiltreVTAd;
            if (siraNo == 0)
            {
                f.ad = txtAd.Text.Trim();
                txtAd.Text = "";
                if (f.ad.Length > 20) f.ad = f.ad.Substring(0, 20);
            }
            else
                f.ad = "x";

            f.siraNo = siraNo;

            f.kriter = XMLKriterOl();
            Sonuc s = new Sonuc();
            s.DegerAta(f.KontrolEt(false));
            if (s.islemSonuc)
            {
                TNS.KYM.IKYMServis srv = TNS.KYM.Arac.Tanimla();
                s = srv.FiltreKaydet(f);
            }
        }

        private string XMLKriterOl()
        {
            string kriter = "";
            for (int i = 0; i < FiltreAlanlar.Count; i++)
            {
                string s = ValueOrText(FiltreAlanlar[i]);
                if (!string.IsNullOrEmpty(s))
                {
                    string vtAd = FiltreAlanlar[i].Attributes["AlanVTAd"];
                    if (!string.IsNullOrEmpty(vtAd))
                        kriter += string.Format("<{0}>{1}</{0}>", vtAd, s);
                }
            }
            return kriter;
        }

        private void AlanDegerleriniSessionaAt()
        {
            if (string.IsNullOrEmpty(SessionAd)) return;
            Hashtable ht = SessionHt();
            if (ht == null) ht = new Hashtable();
            for (int i = 0; i < FiltreAlanlar.Count; i++)
            {
                string vtAd = FiltreAlanlar[i].Attributes["AlanVTAd"];
                if (!string.IsNullOrEmpty(vtAd))
                {
                    ht[vtAd] = Value(FiltreAlanlar[i]);
                }
            }
            this.Page.Session[SessionAd] = ht;
        }

        #endregion
    }
}
#endif