using System;
using jxl;
using jxl.format;
using jxl.read;
using jxl.read.biff;
using jxl.write;
using jxl.write.biff;
using System.Drawing.Imaging;
using System.IO;

namespace OrtakClass
{
    //BARIS: build seçeneğindeki bu satırı
    //copy "$(TargetPath)" "$(SolutionDir)\OrtakDll\$(TargetName)$(TargetExt)"
    //BARIS: aşağıdaki ile değiştirdim
    //copy "$(TargetPath)" "$(SolutionDir)OrtakDll$(TargetName)$(TargetExt)"

    public class TabloJ : Tablo
    {
        private WritableWorkbook XLS;
        //java.io.FileOutputStream tmpFileStream;
        System.IO.Stream tmpFileStream;
        private string tmpFile;
        int aktifSheet;
        private string encoding;
        bool okuModu = false;

        public void SheetToResim(int horRes, int verRes, string dosyaAd, int tur)
        {

        }

        private WritableFont WritableFontBul(string fontAd)
        {
            WritableFont.FontName fontName;
            if (fontAd.Equals("TAHOMA")) fontName = WritableFont.TAHOMA;
            else fontName = WritableFont.COURIER;

            return new WritableFont(fontName);
        }

        private jxl.format.Colour RenkBul(TabloRenk renk)
        {
            if (renk == TabloRenk.AQUA) return jxl.format.Colour.AQUA;
            if (renk == TabloRenk.BLACK) return jxl.format.Colour.BLACK;
            if (renk == TabloRenk.CORAL) return jxl.format.Colour.CORAL;
            if (renk == TabloRenk.GRAY_25) return jxl.format.Colour.GRAY_25;
            if (renk == TabloRenk.ICE_BLUE) return jxl.format.Colour.ICE_BLUE;
            if (renk == TabloRenk.IVORY) return jxl.format.Colour.IVORY;
            if (renk == TabloRenk.LIGHT_TURQUOISE2) return jxl.format.Colour.LIGHT_BLUE;
            if (renk == TabloRenk.ORANGE) return jxl.format.Colour.ORANGE;
            if (renk == TabloRenk.PALE_BLUE) return jxl.format.Colour.PALE_BLUE;
            if (renk == TabloRenk.PERIWINKLE) return jxl.format.Colour.PERIWINKLE;
            if (renk == TabloRenk.PINK2) return jxl.format.Colour.PINK2;
            if (renk == TabloRenk.RED) return jxl.format.Colour.RED;
            if (renk == TabloRenk.ROSE) return jxl.format.Colour.ROSE;
            if (renk == TabloRenk.VERY_LIGHT_YELLOW) return jxl.format.Colour.VERY_LIGHT_YELLOW;
            if (renk == TabloRenk.YELLOW2) return jxl.format.Colour.YELLOW2;
            return jxl.format.Colour.BLACK;
        }

        private jxl.format.BorderLineStyle BorderStilBul(LineStyle stil)
        {
            if (stil == LineStyle.DOUBLE) return jxl.format.BorderLineStyle.DOUBLE;
            if (stil == LineStyle.MEDIUM) return jxl.format.BorderLineStyle.MEDIUM;
            if (stil == LineStyle.THIN) return jxl.format.BorderLineStyle.THIN;

            return jxl.format.BorderLineStyle.NONE;
        }

        public TabloJ()
        {
            aktifSheet = 0;
            encoding = "ISO-8859-9";
        }

        public int SheetSayisi()
        {
            return 0;
        }

        public int SatirSayisi()
        {
            return XLS.getSheet(aktifSheet).getRows();
        }

        public int SutunSayisi()
        {
            return XLS.getSheet(aktifSheet).getColumns();
        }


        public void YeniSheetEkle(string dosyaYol, string dosyaAd, int index)
        {
            jxl.WorkbookSettings wbs = new WorkbookSettings();
            wbs.setEncoding(encoding);
            Workbook inputWorkBook = jxl.Workbook.getWorkbook(System.IO.File.OpenRead(dosyaYol), wbs); //Xls dosyasını açma/workbooku oluşturma
            try
            {
                this.XLS.importSheet(dosyaAd, index, inputWorkBook.getSheet(0));
            }
            catch { }
        }

        public string SonucDosyaAd()
        {
            return tmpFile;
        }

        public void SatirAcKontrolsuz(int sheetNo, int satir, int acilacakSatirSayisi)
        {
            for (int i = 0; i < acilacakSatirSayisi; i++)
                XLS.getSheet(sheetNo).insertRow(satir);
        }

        public void SatirAc(int sheetNo, int satir, int acilacakSatirSayisi)
        {
            SatirAcKontrolsuz(sheetNo, satir, acilacakSatirSayisi);
        }

        public void SatirAc(int satir, int acilacakSatirSayisi)
        {
            SatirAcKontrolsuz(aktifSheet, satir, acilacakSatirSayisi);
        }

        public void SutunAcKontrolsuz(int sheetNo, int sutun, int acilacakSutunSayisi)
        {
            for (int i = 0; i < acilacakSutunSayisi; i++)
                XLS.getSheet(sheetNo).insertColumn(sutun);
        }

        public void SutunAc(int sheetNo, int sutun, int acilacakSutunSayisi)
        {
            SutunAcKontrolsuz(sheetNo, sutun, acilacakSutunSayisi);
        }

        public void SutunAc(int sutun, int acilacakSutunSayisi)
        {
            SutunAcKontrolsuz(aktifSheet, sutun, acilacakSutunSayisi);
        }

        private void SatirKontroluYap(int sheetNo, int satir)
        {
            int rowSay = XLS.getSheet(sheetNo).getRows();
            if (rowSay <= satir)
                SatirAcKontrolsuz(sheetNo, rowSay, satir - rowSay);
        }

        private void SutunKontroluYap(int sheetNo, int sutun)
        {
            int sutSay = XLS.getSheet(sheetNo).getColumns();
            if (sutSay <= sutun)
                SutunAcKontrolsuz(sheetNo, sutSay, sutun - sutSay);
        }

        public void HucreIcerikAraYaz(string bulDeger, string yazDeger)
        {

        }
        public void HucreIcerikAraYaz(string bulDeger, double yazDeger)
        {

        }

        public void HucreAdBulYaz(string hucreAd, double deger, string paraIsareti, int kurusHane = 2)
        {

        }

        public void HucreDegerYaz(int satir, int sutun, double deger, string paraIsareti, int kurusHane = 2)
        {
        }

        public void HucreAdBulYaz(string hucreAd, string deger)
        {
            HucreAdBulYaz(hucreAd, jxl.CellType.LABEL, deger);
        }

        public void HucreAdBulYaz(string hucreAd, double deger)
        {
            HucreAdBulYaz(hucreAd, jxl.CellType.NUMBER, deger);
        }

        public void HucreAdBulYaz(string hucreAd, jxl.CellType tip, object deger)
        {
            Range[] r = XLS.findByName(hucreAd);
            if (r != null && r.Length > 0)
            {
                try
                {
                    HucreDegerYaz(r[0].getFirstSheetIndex(), r[0].getTopLeft().getRow(), r[0].getTopLeft().getColumn(), tip, deger);
                }
                catch (Exception) { }
            }
        }

        public void HucreDegerHtmlYaz(int sheetNo, int satir, int sutun, string HtmlString)
        {
            HucreDegerYaz(sheetNo, satir, sutun, jxl.CellType.LABEL, HtmlString);
        }

        private void HucreDegerYaz(int sheetNo, int satir, int sutun, jxl.CellType tip, object deger)
        {
            try
            {
                bool bosalt;
                WritableSheet sheet = XLS.getSheet(sheetNo);
                WritableCell c = sheet.getWritableCell(sutun, satir);
                if (deger == null)
                    bosalt = true;
                else
                    bosalt = false;

                if (!bosalt)
                {
                    if (tip == CellType.LABEL && c.getType() == CellType.LABEL)
                    {
                        ((jxl.write.Label)c).setString((string)deger);
                    }
                    else if (tip == CellType.NUMBER && c.getType() == CellType.NUMBER)
                    {
                        ((jxl.write.Number)c).setValue((double)deger);
                    }
                    else
                    {
                        jxl.format.CellFormat cf = c.getCellFormat();
                        if (tip == CellType.LABEL)
                        {
                            c = new jxl.write.Label(sutun, satir, (string)deger);
                        }
                        else if (tip == CellType.NUMBER)
                        {
                            c = new jxl.write.Number(sutun, satir, (double)deger);
                        }
                        else
                            return;
                        if (cf != null)
                        {
                            c.setCellFormat(cf);
                        }
                        sheet.addCell(c);
                    }
                }
                else if (c.getType() != CellType.EMPTY)
                {
                    sheet.addCell(new Blank(sutun, satir, c.getCellFormat()));
                }
            }
            catch { }
        }

        public void HucreDegerYaz(int satir, int sutun, string deger)
        {
            HucreDegerYaz(aktifSheet, satir, sutun, jxl.CellType.LABEL, deger);
        }

        public void HucreDegerYaz(int satir, int sutun, double deger)
        {
            HucreDegerYaz(aktifSheet, satir, sutun, jxl.CellType.NUMBER, deger);
        }

        public void HucreDegerYaz(int satir, int sutun, decimal deger)
        {
            HucreDegerYaz(aktifSheet, satir, sutun, jxl.CellType.NUMBER, Convert.ToDouble(deger));
        }

        public void HucreDegerYaz(int satir, int sutun, int deger)
        {
            HucreDegerYaz(aktifSheet, satir, sutun, jxl.CellType.NUMBER, Convert.ToDouble(deger));
        }

        public void HucreDegerYaz(int satir, int sutun, System.DateTime deger)
        {
            HucreDegerYaz(aktifSheet, satir, sutun, jxl.CellType.DATE, deger);
        }

        public double HucreDegerAlDbl(int sheetNo, int satir, int sutun)
        {
            WritableSheet sheet = XLS.getSheet(sheetNo);
            Cell cell = sheet.getWritableCell(sutun, satir);
            double deger = 0;
            if (cell.getType() == CellType.NUMBER || cell.getType() == CellType.NUMBER_FORMULA)
            {
                if (cell.getType() == CellType.NUMBER)
                    deger = ((jxl.write.Number)cell).getValue();
            }
            return deger;
        }

        public double HucreDegerAlDbl(int satir, int sutun)
        {
            return HucreDegerAlDbl(aktifSheet, satir, sutun);
        }

        public string HucreDegerAl(int sheetNo, int satir, int sutun, int noktaSay)
        {
            WritableSheet sheet = XLS.getSheet(sheetNo);
            Cell cell = sheet.getWritableCell(sutun, satir);
            if (cell.getType() == CellType.NUMBER || cell.getType() == CellType.NUMBER_FORMULA)
            {
                double deger;
                if (cell.getType() == CellType.NUMBER)
                    deger = ((jxl.write.Number)cell).getValue();
                else
                    return cell.getContents();
                if (deger == 0)
                    return (0).ToString();
                string frmt = "#.";
                frmt = frmt.PadRight(2 + noktaSay, '#');
                return deger.ToString(frmt);
            }
            else
                return cell.getContents();
        }

        public string HucreDegerAl(int satir, int sutun)
        {
            return HucreDegerAl(aktifSheet, satir, sutun, 0);
        }

        public string HucreAdDegerAl(string hucreAd)
        {
            Range[] r = XLS.findByName(hucreAd);
            if (r != null && r.Length > 0)
                return HucreDegerAl(r[0].getFirstSheetIndex(), r[0].getTopLeft().getRow(), r[0].getTopLeft().getColumn(), 0);
            else
                return "";
        }

        public string HucreFormulAl(int satir, int sutun)
        {
            WritableSheet sheet = XLS.getSheet(aktifSheet);
            Cell cell = sheet.getWritableCell(sutun, satir);
            jxl.CellType ct = cell.getType();
            if (ct == jxl.CellType.NUMBER_FORMULA || ct == jxl.CellType.STRING_FORMULA)
                return ((FormulaCell)cell).getFormula();
            return "";

        }

        public void HucreFormulYaz(int satir, int sutun, string formul)
        {
        }

        public void KorumayaAl()
        {
            KorumayaAl("01020304");
        }

        public void KorumayaAl(string sifre)
        {
            //XLS.BookProtected=true;
            WritableSheet sheet = XLS.getSheet(aktifSheet);
            //            sheet.setProtected(true);
        }

        public void HucreAdAdresCoz(string hucreAd, ref int satir, ref int sutun)
        {
            //CellNET.TCell hucre=XLS.get_NameAsCell(hucreAd);
            sutun = -1;
            satir = -1;
            try
            {
                Cell c = XLS.findCellByName(hucreAd);
                if (c != null)
                {
                    sutun = c.getColumn();
                    satir = c.getRow();
                }
            }
            catch { }
        }

        public void HucreAdAdresCoz(string bolgeAd, ref int sheetNo, ref int satir1, ref int sutun1, ref int satir2, ref int sutun2)
        {
            sheetNo = -1;
            sutun1 = -1;
            satir1 = -1;
            sutun2 = -1;
            satir2 = -1;
            try
            {
                jxl.Range[] r = XLS.findByName(bolgeAd);
                if (r != null && r.Length > 0)
                {
                    sheetNo = r[0].getFirstSheetIndex();
                    satir1 = r[0].getTopLeft().getRow();
                    sutun1 = r[0].getTopLeft().getColumn();
                    satir2 = r[0].getBottomRight().getRow();
                    sutun2 = r[0].getBottomRight().getColumn();
                }
                /*
                if(yer>-1)
                {
                    satir1=XLS.InternalNames[yer].Row1;
                    satir2=XLS.InternalNames[yer].Row2;
                    sutun1=XLS.InternalNames[yer].Col1;
                    sutun2=XLS.InternalNames[yer].Col2;
                }*/
            }
            catch (Exception)
            {
                sheetNo = -1;
                sutun1 = -1;
                satir1 = -1;
                sutun2 = -1;
                satir2 = -1;
            }
        }

        public void SatirKopyalaAc(int kaynakSheet, int satir, int kopyalanacakSatirSayisi, int hedefSheet, int hedefSatir)
        {
            SatirAc(hedefSheet, hedefSatir, kopyalanacakSatirSayisi);
            SatirKopyala(kaynakSheet, satir, kopyalanacakSatirSayisi, hedefSheet, hedefSatir);
        }

        public void SatirKopyalaAc(int satir, int kopyalanacakSatirSayisi, int hedefSatir)
        {
            SatirKopyalaAc(aktifSheet, satir, kopyalanacakSatirSayisi, aktifSheet, hedefSatir);
        }

        /// <summary>
        /// Bu method duzgun calismiyor, HucreKopyala kullaniniz.
        /// </summary>
        /// <param name="satir"></param>
        /// <param name="kopyalanacakSatirSayisi"></param>
        /// <param name="hedefSatir"></param>
        [Obsolete("Bu method duzgun calismiyor, HucreKopyala kullaniniz.")]
        public void SatirKopyala(int kaynakSheet, int satir, int kopyalanacakSatirSayisi, int hedefSheet, int hedefSatir)
        {
            WritableSheet sheet = XLS.getSheet(kaynakSheet);
            HucreKopyala(kaynakSheet, satir, 0, satir + kopyalanacakSatirSayisi, sheet.getRow(satir).Length, hedefSheet, hedefSatir, 0);
        }

        /// <summary>
        /// Bu method duzgun calismiyor, HucreKopyala kullaniniz.
        /// </summary>
        /// <param name="satir"></param>
        /// <param name="kopyalanacakSatirSayisi"></param>
        /// <param name="hedefSatir"></param>
        [Obsolete("Bu method duzgun calismiyor, HucreKopyala kullaniniz.")]
        public void SatirKopyala(int satir, int kopyalanacakSatirSayisi, int hedefSatir)
        {
            SatirKopyala(aktifSheet, satir, kopyalanacakSatirSayisi, aktifSheet, hedefSatir);
        }

        public void SutunKopyalaAc(int kaynakSheet, int sutun, int kopyalanacakSutunSayisi, int hedefSheet, int hedefSutun)
        {
            SutunAc(hedefSheet, hedefSutun, kopyalanacakSutunSayisi);
            SutunKopyala(kaynakSheet, sutun, kopyalanacakSutunSayisi, hedefSheet, hedefSutun);
        }

        public void SutunKopyalaAc(int sutun, int kopyalanacakSutunSayisi, int hedefSutun)
        {
            SutunKopyalaAc(aktifSheet, sutun, kopyalanacakSutunSayisi, aktifSheet, hedefSutun);
        }

        /// <summary>
        /// Bu method duzgun calismiyor, HucreKopyala kullaniniz.
        /// </summary>
        /// <param name="sutun"></param>
        /// <param name="kopyalanacakSutunSayisi"></param>
        /// <param name="hedefSutun"></param>
        [Obsolete("Bu method duzgun calismiyor, HucreKopyala kullaniniz.")]
        public void SutunKopyala(int kaynakSheet, int sutun, int kopyalanacakSutunSayisi, int hedefSheet, int hedefSutun)
        {
            WritableSheet sheet = XLS.getSheet(kaynakSheet);
            HucreKopyala(kaynakSheet, 0, sutun, sheet.getColumn(sutun).Length, sutun + kopyalanacakSutunSayisi, hedefSheet, hedefSutun, 0);
        }

        /// <summary>
        /// Bu method duzgun calismiyor, HucreKopyala kullaniniz.
        /// </summary>
        /// <param name="sutun"></param>
        /// <param name="kopyalanacakSutunSayisi"></param>
        /// <param name="hedefSutun"></param>
        [Obsolete("Bu method duzgun calismiyor, HucreKopyala kullaniniz.")]
        public void SutunKopyala(int sutun, int kopyalanacakSutunSayisi, int hedefSutun)
        {
            SutunKopyala(aktifSheet, sutun, kopyalanacakSutunSayisi, aktifSheet, hedefSutun);
        }

        public void HucreKopyala(int kaynakSheet, int satir1, int sutun1, int satir2, int sutun2, int hedefSheet, int hedefSatir, int hedefSutun)
        {
            int satirSay = 0;
            if (satir2 >= satir1)
                satirSay = satir2 - satir1;
            else
                satirSay = satir1 - satir2;
            SatirKontroluYap(hedefSheet, hedefSatir + satirSay);

            WritableSheet sheetK = XLS.getSheet(kaynakSheet);
            WritableSheet sheetH = XLS.getSheet(hedefSheet);
            //string tut="";
            for (int i = satir1; i <= satir2; i++)
            {
                for (int j = sutun1; j <= sutun2; j++)
                {
                    WritableCell c = sheetK.getWritableCell(j, i);
                    if (c.GetType() != typeof(jxl.biff.EmptyCell))
                    {
                        try
                        {

                            c = c.copyTo(hedefSutun + j - sutun1, hedefSatir + i - satir1);
                            //CellFormat cf = XLS.getSheet(kaynakSheet).getColumnView(sutun1).getFormat();
                            //XLS.getSheet(hedefSheet).getColumnView(hedefSutun).setFormat(cf);
                            sheetH.addCell(c);
                        }
                        catch (Exception)
                        {
                            //                            tut=c.getType().ToString();
                            //                            tut+="(" + c.getRow() +"-"+c.getColumn()+")";
                            //                            tut+=e.ToString();
                            //                            tut+=";";
                        }
                    }
                }

            }
        }

        public void HucreKopyala(int satir1, int sutun1, int satir2, int sutun2, int hedefSatir, int hedefSutun)
        {
            HucreKopyala(aktifSheet, satir1, sutun1, satir2, sutun2, aktifSheet, hedefSatir, hedefSutun);
        }

        public void HucreBirlestir(int satir1, int sutun1, int satir2, int sutun2)
        {
            XLS.getSheet(aktifSheet).mergeCells(sutun1, satir1, sutun2, satir2);
        }

        public void HucreBirlestirme(int satir1, int sutun1, int satir2, int sutun2)
        {
            for (int i = satir1; i <= satir2; i++)
            {
                for (int j = sutun1; j <= sutun2; j++)
                    HucreBirlestirme(i, j);
            }
        }

        public void HucreBirlestirme(int satir, int sutun)
        {
            Range[] rler = XLS.getSheet(aktifSheet).getMergedCells();
            for (int i = 0; i < rler.Length; i++)
            {
                Range r = rler[i];
                Cell c = r.getTopLeft();
                if (c.getRow() == satir && c.getColumn() == sutun)
                {
                    XLS.getSheet(aktifSheet).unmergeCells(r);
                    return;
                }
            }
        }

        public void OtomatikYukseklik(int sheetNo, int satir, int sutun1, int sutun2)
        {
        }

        public void SatirYukseklikAyarla(int satir1, int satir2, int yukseklik)
        {
            SatirKontroluYap(aktifSheet, satir2);
            for (int sat = satir1; sat <= satir2; sat++)
            {
                XLS.getSheet(aktifSheet).setRowView(sat, yukseklik);
            }
        }

        public void SatirGercekYukseklikAyarla(int satir1, int satir2, double yukseklik)
        {
        }
        public double SatirGercekYukseklikAl(int satir)
        {
            return 0;
        }

        public int SatirYukseklikAl(int sheetNo, int satir)
        {
            return XLS.getSheet(sheetNo).getRowView(satir).getSize();
        }

        public int SatirYukseklikAl(int satir)
        {
            return SatirYukseklikAl(aktifSheet, satir);
        }

        public void SutunGenislikAyarla(int sutun1, int sutun2, int genislik)
        {
            SutunKontroluYap(aktifSheet, sutun2);
            for (int sut = sutun1; sut <= sutun2; sut++)
                XLS.getSheet(aktifSheet).setColumnView(sut, genislik);
        }

        public void SutunGenislikAyarlaPixel(int sutun1, int sutun2, int genislik)
        {
            SutunGenislikAyarla(sutun1, sutun2, genislik);
        }

        public void SutunGenislikAyarla(int sutun1, int sutun2, int genislik, int ekle, int minGenislik)
        {
            SutunGenislikAyarla(aktifSheet, sutun1, sutun2, genislik, ekle, minGenislik);
        }

        public void SutunGenislikAyarla(int sheetNo, int sutun1, int sutun2, int genislik, int ekle, int minGenislik)
        {
            SutunGenislikAyarla(sutun1, sutun2, genislik == -1 ? minGenislik + ekle : genislik + ekle);
        }

        public void SutunGizle(int sutun1, int sutun2, bool gizle)
        {
            CellView cView = new CellView();
            cView.setHidden(gizle);

            SutunKontroluYap(aktifSheet, sutun2);
            for (int sut = sutun1; sut <= sutun2; sut++)
                XLS.getSheet(aktifSheet).setColumnView(sut, cView);
        }

        public void SatirGizle(int satir1, int satir2, bool gizle)
        {
            SatirKontroluYap(aktifSheet, satir2);
            for (int sat = satir1; sat <= satir2; sat++)
                XLS.getSheet(aktifSheet).setRowView(sat, gizle);
        }

        public void SatirSil(int satir1, int satir2)
        {
            SatirKontroluYap(aktifSheet, satir2);
            for (int sat = satir1; sat <= satir2; sat++)
                XLS.getSheet(aktifSheet).removeRow(sat);
        }

        public void SutunSil(int sutun1, int sutun2)
        {
            SutunKontroluYap(aktifSheet, sutun2);
            for (int sut = sutun1; sut <= sutun2; sut++)
                XLS.getSheet(aktifSheet).removeColumn(sut);
        }

        public int SutunGenislikAl(int sheetNo, int sutun)
        {
            return XLS.getSheet(sheetNo).getColumnView(sutun).getSize();
        }

        public int SutunGenislikAl(int sutun)
        {
            return SutunGenislikAl(aktifSheet, sutun);
        }


        //		public void DuseyHizala(int satir, int sutun, int deger)
        //		{
        //			//0-sol
        //			//1-sağ
        //			//2-orta
        //			//3-iki yana yasla
        //			CellFormatsNET.TCellHorizAlignment hiza=CellFormatsNET.TCellHorizAlignment.chaLeft;
        //
        //			if (deger==2)
        //				hiza=CellFormatsNET.TCellHorizAlignment.chaCenter;
        //
        //			XLS.Sheets[0].GetCell(sutun,satir).SetHorizAlignment(hiza);
        //		}

        public void HucreFormatla(int satir, int sutun, string deger)
        {
            jxl.write.WritableCellFormat wcf = null;
            WritableSheet sheet = XLS.getSheet(aktifSheet);
            WritableCell wc = null;

            wc = sheet.getWritableCell(sutun, satir);
            if (wc == null || wc.getType() == CellType.EMPTY)
            {
                sheet.addCell(new jxl.write.Label(sutun, satir, ""));
                wc = sheet.getWritableCell(sutun, satir);
            }
            wcf = new WritableCellFormat(wc.getCellFormat());

            WritableCellFormat cf = new WritableCellFormat(new NumberFormat(deger));

            wc.setCellFormat(cf);

            //wcf.setFormatIndex(deger);
            //wc.setCellFormat(wcf);
        }

        public void HucreFormatla(int satir1, int sutun1, int satir2, int sutun2, string deger)
        {
            for (int i = satir1; i <= satir2; i++)
                for (int j = sutun1; j <= sutun2; j++)
                    HucreFormatla(i, j, deger);
        }

        public void DuseyCizgiCiz(int satir1, int satir2, int sutun, OrtakClass.LineStyle stil, TabloRenk renk, bool solMu)
        {
            WritableSheet sheet = XLS.getSheet(aktifSheet);

            jxl.format.Border b;

            if (solMu)
                b = jxl.format.Border.LEFT;
            else
                b = jxl.format.Border.RIGHT;

            jxl.format.CellFormat cf = null;
            WritableCellFormat wcf = null;
            WritableCell wc = null;

            for (int i = satir1; i <= satir2; i++)
            {
                wc = sheet.getWritableCell(sutun, i);
                if (wc == null || wc.getType() == CellType.EMPTY)
                {
                    sheet.addCell(new jxl.write.Label(sutun, i, ""));
                    wc = sheet.getWritableCell(sutun, i);
                }
                cf = wc.getCellFormat();
                if (cf == null)
                    wcf = new WritableCellFormat();
                else
                    wcf = new WritableCellFormat(cf);
                wcf.setBorder(b, BorderStilBul(stil), RenkBul(renk));
                wc.setCellFormat(wcf);
            }
        }

        public void DuseyCizgiCiz(int satir1, int satir2, int sutun, OrtakClass.LineStyle stil, TabloRenk renk)
        {
            DuseyCizgiCiz(satir1, satir2, sutun, stil, renk, true);
        }


        public void YatayCizgiCiz(int satir, int sutun1, int sutun2, OrtakClass.LineStyle stil, TabloRenk renk, bool ustMu)
        {
            WritableSheet sheet = XLS.getSheet(aktifSheet);

            jxl.format.Border b;

            if (ustMu)
                b = jxl.format.Border.TOP;
            else
                b = jxl.format.Border.BOTTOM;

            jxl.format.CellFormat cf = null;
            WritableCellFormat wcf = null;
            WritableCell wc = null;

            for (int i = sutun1; i <= sutun2; i++)
            {
                wc = sheet.getWritableCell(i, satir);
                if (wc == null || wc.getType() == CellType.EMPTY)
                {
                    sheet.addCell(new jxl.write.Label(i, satir, ""));
                    wc = sheet.getWritableCell(i, satir);
                }
                cf = wc.getCellFormat();
                if (cf == null)
                    wcf = new WritableCellFormat();
                else
                    wcf = new WritableCellFormat(cf);
                wcf.setBorder(b, BorderStilBul(stil), RenkBul(renk));
                wc.setCellFormat(wcf);
            }
        }

        public void YatayCizgiCiz(int satir, int sutun1, int sutun2, OrtakClass.LineStyle stil, TabloRenk renk)
        {
            YatayCizgiCiz(satir, sutun1, sutun2, stil, renk, true);
        }


        public void CerceveCizgiCiz(int satir1, int satir2, int sutun1, int sutun2, OrtakClass.LineStyle stil, TabloRenk renk)
        {
            //			for (int i=satir1;i<=satir2+1;i++)
            //				if (i==satir2+1)
            //					YatayCizgiCiz(i-1, sutun1, sutun2, stil, renk, false);
            //				else
            //					YatayCizgiCiz(i, sutun1, sutun2, stil, renk, true);
            //
            //			for (int i=sutun1;i<=sutun2+1;i++)
            //				if (i==sutun2+1)
            //					DuseyCizgiCiz(satir1, satir2, i-1, stil, renk, false);
            //				else
            //					DuseyCizgiCiz(satir1, satir2, i, stil, renk, true);

            for (int i = satir1; i <= satir2 + 1; i++)
                YatayCizgiCiz(i, sutun1, sutun2, stil, renk, true);

            for (int i = sutun1; i <= sutun2 + 1; i++)
                DuseyCizgiCiz(satir1, satir2, i, stil, renk, true);
        }

        public void CerceveCiz(int satir1, int satir2, int sutun1, int sutun2, OrtakClass.LineStyle stil, TabloRenk renk)
        {
            DuseyCizgiCiz(satir1, satir2 - 1, sutun1, stil, renk);
            DuseyCizgiCiz(satir1, satir2 - 1, sutun2, stil, renk);
            YatayCizgiCiz(satir1, sutun1, sutun2 - 1, stil, renk);
            YatayCizgiCiz(satir2, sutun1, sutun2 - 1, stil, renk);
        }


        public void ZoomSheet(int zf)
        {
            XLS.getSheet(aktifSheet).getSettings().setZoomFactor(zf);
        }

        public void ZoomYazici(int zf)
        {
            XLS.getSheet(aktifSheet).getSettings().setScaleFactor(zf);
        }

        public void HucreMetniKaydir(int satir1, int sutun1, int satir2, int sutun2, bool deger)
        {
            for (int i = satir1; i <= satir2; i++)
            {
                for (int j = sutun1; j <= sutun2; j++)
                    HucreMetniKaydir(i, j, deger);
            }
        }

        public void HucreMetniKaydir(int satir, int sutun, bool deger)
        {
            try
            {
                WritableSheet sheet = XLS.getSheet(aktifSheet);
                WritableCell wc = sheet.getWritableCell(sutun, satir);
                WritableCellFormat cf = new WritableCellFormat(wc.getCellFormat());
                if (cf == null)
                {
                    cf = new WritableCellFormat(new WritableFont(jxl.write.WritableFont.ARIAL));
                }
                cf.setWrap(deger);
                wc.setCellFormat(cf);
            }
            catch
            {
            }
        }

        public void KoyuYap(int satir1, int sutun1, int satir2, int sutun2, bool deger)
        {
            for (int i = satir1; i <= satir2; i++)
            {
                for (int j = sutun1; j <= sutun2; j++)
                    KoyuYap(i, j, deger);
            }
        }

        public void KoyuYap(int satir, int sutun, bool deger)
        {
            try
            {
                WritableSheet sheet = XLS.getSheet(aktifSheet);
                WritableCell wc = null;
                wc = sheet.getWritableCell(sutun, satir);
                WritableCellFormat cf = new WritableCellFormat(wc.getCellFormat());
                if (cf == null)
                {
                    cf = new WritableCellFormat(new WritableFont(jxl.write.WritableFont.ARIAL));
                }

                WritableFont fnt = new WritableFont(cf.getFont());
                if (deger)
                    fnt.setBoldStyle(WritableFont.BOLD);
                else
                    fnt.setBoldStyle(WritableFont.NO_BOLD);
                cf.setFont(fnt);
                wc.setCellFormat(cf);
            }
            catch
            {
            }
        }

        private void YaziTipiAta(WritableSheet sheet, int satir, int sutun, string fontAd)
        {
            try
            {
                WritableCell wc = null;
                wc = sheet.getWritableCell(sutun, satir);
                WritableCellFormat cf = new WritableCellFormat(wc.getCellFormat());
                if (cf == null)
                {
                    cf = new WritableCellFormat(WritableFontBul(fontAd));
                }
                cf.setFont(WritableFontBul(fontAd));

                wc.setCellFormat(cf);
            }
            catch { }
        }

        public void YaziTipiAta(int satir1, int sutun1, int satir2, int sutun2, string fontAd)
        {
            WritableSheet sheet = XLS.getSheet(aktifSheet);
            for (int sat = satir1; sat <= satir2; sat++)
                for (int sut = sutun1; sut <= sutun2; sut++)
                {
                    YaziTipiAta(sheet, sat, sut, fontAd);
                }
        }

        public void YaziTipBuyuklugu(int satir, int sutun, int deger)
        {
            try
            {
                WritableSheet sheet = XLS.getSheet(aktifSheet);
                WritableCell wc = null;
                wc = sheet.getWritableCell(sutun, satir);
                WritableCellFormat cf = new WritableCellFormat(wc.getCellFormat());
                if (cf == null)
                {
                    cf = new WritableCellFormat(new WritableFont(jxl.write.WritableFont.ARIAL));
                }
                WritableFont fnt = new WritableFont(cf.getFont());
                fnt.setPointSize(deger);
                cf.setFont(fnt);

                wc.setCellFormat(cf);
            }
            catch { }
        }

        public void YaziTipBuyuklugu(int satir1, int sutun1, int satir2, int sutun2, int deger)
        {
            for (int sat = satir1; sat <= satir2; sat++)
                for (int sut = sutun1; sut <= sutun2; sut++)
                {
                    YaziTipBuyuklugu(sat, sut, deger);
                }
        }

        public void DuseyHizala(int satir1, int sutun1, int satir2, int sutun2, int deger)
        {
            for (int i = satir1; i <= satir2; i++)
            {
                for (int j = sutun1; j <= sutun2; j++)
                    DuseyHizala(i, j, deger);
            }
        }

        public void DuseyHizala(int satir, int sutun, int deger)
        {
            //0-sol
            //1-sağ
            //2-orta
            //3-iki yana yasla
            WritableSheet sheet = XLS.getSheet(aktifSheet);
            WritableCell wc = null;
            try
            {
                wc = sheet.getWritableCell(sutun, satir);
                WritableCellFormat wcf;
                if (wc.getCellFormat() != null)
                    wcf = new WritableCellFormat(wc.getCellFormat());
                else
                    wcf = new WritableCellFormat();
                switch (deger)
                {
                    case 1: // sağ           
                        wcf.setAlignment(jxl.format.Alignment.RIGHT);
                        break;
                    case 2: // orta            
                        wcf.setAlignment(jxl.format.Alignment.CENTRE);
                        break;
                    case 3: // iki yana yasla           
                        wcf.setAlignment(jxl.format.Alignment.FILL);
                        break;
                    case 0: // sol   
                    default:
                        wcf.setAlignment(jxl.format.Alignment.LEFT);
                        break;
                }

                wc.setCellFormat(wcf);
            }
            catch (Exception) { }
        }

        public void YatayHizala(int satir1, int sutun1, int satir2, int sutun2, int deger)
        {
            for (int i = satir1; i <= satir2; i++)
            {
                for (int j = sutun1; j <= sutun2; j++)
                    YatayHizala(i, j, deger);
            }
        }

        public void YatayHizala(int satir, int sutun, int deger)
        {
            //0-alt
            //1-üst
            //2-orta
            //3-iki yana yasla
            WritableSheet sheet = XLS.getSheet(aktifSheet);
            WritableCell wc = null;
            try
            {
                wc = sheet.getWritableCell(sutun, satir);
                WritableCellFormat wcf;
                if (wc.getCellFormat() != null)
                    wcf = new WritableCellFormat(wc.getCellFormat());
                else
                    wcf = new WritableCellFormat();
                switch (deger)
                {
                    case 1: // üst
                        wcf.setVerticalAlignment(jxl.format.VerticalAlignment.TOP);
                        break;
                    case 2: // orta            
                        wcf.setVerticalAlignment(jxl.format.VerticalAlignment.CENTRE);
                        break;
                    case 3: // iki yana yasla           
                        wcf.setVerticalAlignment(jxl.format.VerticalAlignment.JUSTIFY);
                        break;
                    case 0: // sol   
                    default:
                        wcf.setVerticalAlignment(jxl.format.VerticalAlignment.BOTTOM);
                        break;
                }

                wc.setCellFormat(wcf);
            }
            catch (Exception) { }
        }

        public void ArkaPlanRenk(int satir1, int sutun1, int satir2, int sutun2, System.Drawing.Color renk)
        {
        }

        public void ArkaPlanRenk(int satir, int sutun, System.Drawing.Color renk)
        {
        }

        public void ArkaPlanRenk(int satir1, int sutun1, int satir2, int sutun2, TabloRenk renk)
        {
            for (int i = satir1; i <= satir2; i++)
                for (int j = sutun1; j <= sutun2; j++)
                    ArkaPlanRenk(i, j, renk);
        }

        public void ArkaPlanRenk(int satir, int sutun, TabloRenk renk)
        {
            WritableSheet sheet = XLS.getSheet(aktifSheet);
            WritableCell wc = null;
            try
            {
                wc = sheet.getWritableCell(sutun, satir);
                WritableCellFormat wcf;
                if (wc.getCellFormat() != null)
                    wcf = new WritableCellFormat(wc.getCellFormat());
                else
                    wcf = new WritableCellFormat();

                wcf.setBackground(RenkBul(renk));

                wc.setCellFormat(wcf);
            }
            catch (Exception) { }
        }

        public void YaziRenk(int satir1, int sutun1, int satir2, int sutun2, TabloRenk renk)
        {
            for (int i = satir1; i <= satir2; i++)
                for (int j = sutun1; j <= sutun2; j++)
                    YaziRenk(i, j, renk);
        }

        public void YaziRenk(int satir, int sutun, TabloRenk renk)
        {
        }

        public void YaziRenk(int satir1, int sutun1, int satir2, int sutun2, System.Drawing.Color renk)
        {
        }

        public void YaziRenk(int satir, int sutun, System.Drawing.Color renk)
        {
        }

        public void CokluSatirdaYaz(int satir, int sutun, bool deger)
        {
            WritableSheet sheet = XLS.getSheet(aktifSheet);
            WritableCell wc = null;
            try
            {
                wc = sheet.getWritableCell(sutun, satir);
                WritableCellFormat wcf;
                if (wc.getCellFormat() != null)
                    wcf = new WritableCellFormat(wc.getCellFormat());
                else
                    wcf = new WritableCellFormat();

                wcf.setWrap(deger);

                wc.setCellFormat(wcf);
            }
            catch (Exception) { }
        }

        public void AktifSheetDegistir(int sheetNo)
        {
            aktifSheet = sheetNo;
        }

        public int AktifSheet()
        {
            return aktifSheet;
        }

        public int YeniSheetEkle()
        {
            int tut = aktifSheet;
            aktifSheet = XLS.getNumberOfSheets();
            XLS.createSheet("Sheet " + (aktifSheet + 1).ToString(), aktifSheet);
            return tut;
        }

        public int YeniSheetEkle(int kaynakSheetNo)
        {
            int tut = aktifSheet;
            aktifSheet = XLS.getNumberOfSheets();
            XLS.copySheet(kaynakSheetNo, "Sheet " + (aktifSheet + 1).ToString(), aktifSheet);
            return tut;
        }

        public void SheetSil(int sheetNo)
        {
            XLS.removeSheet(sheetNo);
        }

        public void SheetAdiVer(int sheetNo, string adi)
        {

        }

        public string SheetAdiAl()
        {
            return "";
        }

        public string SheetAdiAl(int sheetNo)
        {
            return "";
        }


        public void SheetBilgileriKopyalax(int sheetNo, int hedefSheet)
        {
            jxl.SheetSettings ss = XLS.getSheet(sheetNo).getSettings();
            jxl.SheetSettings hss = XLS.getSheet(hedefSheet).getSettings();
            hss = ss;
            //XLS.CopySheet(sheetNo, hedefSheet);
        }


        public void SayfaSonuKoy(int satir)
        {
            XLS.getSheet(aktifSheet).addRowPageBreak(satir);
        }

        public void SayfaSonuKoyHucresel(int satir)
        {
            XLS.getSheet(aktifSheet).addRowPageBreak(satir);
        }

        public void SayfaSonuKoySutun(int sutun)
        {
            //XLS.getSheet(aktifSheet).addCo(sutun);
        }

        public void AdTanimla(string ad, int sheetNo, int sol, int ust, int sag, int alt)
        {
            XLS.addNameArea(ad, XLS.getSheet(sheetNo), sol, ust, sag, alt);
        }


        ///////////////////////////// DOSYA İŞLEMLERİ
        ///

        public void BosDosyaAc(string sonucDosya)
        {
            jxl.WorkbookSettings wbs = new WorkbookSettings();
            wbs.setFormulaAdjust(false);
            wbs.setEncoding(encoding);
            //tmpFileStream = new java.io.FileOutputStream(sonucDosya);
            tmpFile = sonucDosya;

            tmpFileStream = System.IO.File.Create(sonucDosya);
            XLS = Workbook.createWorkbook(tmpFileStream, wbs);
            XLS.createSheet("Rapor", 0);
            aktifSheet = 0;
        }

        public void DosyaOkuAc(string dosyaAd)
        {
            DosyaAc(dosyaAd);
            okuModu = true;
            //jxl.WorkbookSettings wbs = new WorkbookSettings();
            ////wbs.setFormulaAdjust(false);
            //wbs.setEncoding(encoding);
            ////Workbook inputWorkBook = jxl.Workbook.getWorkbook(new java.io.File(dosyaAd)); //Xls dosyasını açma/workbooku oluşturma
            //Workbook inputWorkBook = jxl.Workbook.getWorkbook(System.IO.File.Open(dosyaAd, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite), wbs);//Xls dosyasını açma/workbooku oluşturma
            ////XLS = Workbook.createWorkbook(new java.io.File(dosyaAd), inputWorkBook, wbs);
            //XLS = Workbook.createWorkbook(System.IO.File.Open(dosyaAd, System.IO.FileMode.Open, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite), inputWorkBook, wbs);
        }

        public void DosyaAc(string dosyaAd, string sonucDosya)
        {
            jxl.WorkbookSettings wbs = new WorkbookSettings();
            //wbs.setFormulaAdjust(false);
            //wbs.setExcelRegionalSettings("tr-TR");
            wbs.setEncoding(encoding);
            //Workbook inputWorkBook = jxl.Workbook.getWorkbook(new java.io.File(dosyaAd)); //Xls dosyasını açma/workbooku oluşturma

            System.IO.FileStream f = System.IO.File.Open(dosyaAd, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite);
            Workbook inputWorkBook = jxl.Workbook.getWorkbook(f, wbs); //Xls dosyasını açma/workbooku oluşturma
            f.Close();

            tmpFile = sonucDosya;
            //tmpFileStream = new java.io.FileOutputStream(tmpFile);
            tmpFileStream = System.IO.File.Create(tmpFile);
            XLS = Workbook.createWorkbook(tmpFileStream, inputWorkBook, wbs);
        }

        public void DosyaAc(string dosyaAd)
        {
            DosyaAc(dosyaAd, DosyaIslem.DosyaAdUret());
        }

        public void DosyaSaklaTamYol()
        {
            XLS.write();     // Yapılan değişiklikleri yeni workbook ve dolayısıyla dosyaya yazma
            XLS.close();     // Workbook'u kapatma
            tmpFileStream.Flush();
            tmpFileStream.Close();
        }
#if !MU
        public void DosyaGonder(string dosyaAd)
        {
            DosyaSaklaTamYol();
            DosyaGonder(tmpFile, dosyaAd, true, "xls");
        }

        public void DosyaGonder(string dosyaAd, string dosyaTuru)
        {
            DosyaSaklaTamYol();
            DosyaGonder(tmpFile, dosyaAd, true, dosyaTuru);
        }

        public static void DosyaGonder(string dosyaAd, string gidenAd, bool dosyaSil, string dosyaTuru)
        {
            string ext = System.IO.Path.GetExtension(dosyaAd).Replace(".", "");
            dosyaTuru = dosyaTuru.Replace(".", "");
            if (ext == "tmp") ext = "xls";
            if (dosyaTuru == null)
                dosyaTuru = "XLS";
            if (dosyaTuru.ToUpper() == "PDF")
                DosyaGonderPDF(dosyaAd, gidenAd, dosyaSil, true);
            else if (dosyaTuru.ToUpper() == "DOC")
                DosyaGonderX(dosyaAd, gidenAd, dosyaSil, "doc");
            else if (dosyaTuru.ToUpper() == "ZIP" || dosyaTuru.ToLower() == "zip")
                DosyaGonderX(dosyaAd, gidenAd, dosyaSil, "zip");
            else
                DosyaGonderX(dosyaAd, gidenAd, dosyaSil, "xls");
        }

        public static void DosyaGonderX(string dosyaAd, string gidenAd, bool dosyaSil, string ext)
        {
            DosyaGonderX(dosyaAd, gidenAd, dosyaSil, ext, true);
        }

        public static void DosyaGonderX(string dosyaAd, string gidenAd, bool dosyaSil, string ext, bool ekOlarakGonder)
        {
            OrtakClass.GenelIslemler.ResponseBasla(gidenAd, ext, ekOlarakGonder);

            //System.Web.HttpContext.Current.Response.WriteFile(dosyaAd);
            System.Web.HttpContext.Current.Response.TransmitFile(dosyaAd);
            System.Web.HttpContext.Current.Response.Flush();
            if (dosyaSil)
                System.IO.File.Delete(dosyaAd);

            System.Web.HttpContext.Current.Response.End();
        }

        public static void DosyaGonderPDF(string dosyaAd, string gidenAd, bool dosyaSil, bool ekOlarakGonder)
        {
            string cikanDosya = "";
            try
            {
                cikanDosya = DosyaTipDegistir.Dosya2PDF(dosyaAd, dosyaSil);

                gidenAd = System.IO.Path.GetFileNameWithoutExtension(gidenAd) + ".pdf";

                if (cikanDosya != "Hata")
                {
                    DosyaGonderX(cikanDosya, gidenAd, dosyaSil, "pdf", ekOlarakGonder);

                    if (dosyaSil)
                        System.IO.File.Delete(cikanDosya);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string DosyaAdUret()
        {
            return DosyaAdUret("", "");
        }

        public static string DosyaAdUret(string dosyaAdOnEk, string dosyaAdArkaEk)
        {
            return TNS.OrtakFonksiyonlar.GeciciYolBul() + dosyaAdOnEk + DosyaAdUretSade() + dosyaAdArkaEk + ".xls";
        }

        public static string DosyaAdUretSade()
        {
            string dosyaAd = System.DateTime.Now.ToString() + System.DateTime.Now.Millisecond.ToString();
            dosyaAd = dosyaAd.Replace("/", "");
            dosyaAd = dosyaAd.Replace(".", "");
            dosyaAd = dosyaAd.Replace("-", "");
            dosyaAd = dosyaAd.Replace(":", "");
            dosyaAd = dosyaAd.Replace(" ", "");
            return dosyaAd;
        }
#endif
        public void IlkSayfaNumarasi(int sayfaNo)
        {
            XLS.getSheet(aktifSheet).getSettings().setPageStart(sayfaNo);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="yer">1 ise alt, değil ise üst</param>
        /// <param name="yanasik">1 ise sol, 2 ise sağ, değil ise orta</param>
        /// <param name="deger"></param>
        public void HFDegerAta(int yer, int yanasik, string deger)
        {
            HeaderFooter hf = null;
            if (yer == 1)
                hf = XLS.getSheet(aktifSheet).getSettings().getFooter();
            else
                hf = XLS.getSheet(aktifSheet).getSettings().getHeader();
            if (hf != null)
            {
                jxl.HeaderFooter.Contents c = null;
                if (yanasik == 1)
                    c = hf.getLeft();
                else if (yanasik == 2)
                    c = hf.getRight();
                else
                    c = hf.getCentre();
                if (c != null)
                {
                    c.clear();
                    c.append(deger);
                    if (yer == 1)
                        XLS.getSheet(aktifSheet).getSettings().setFooter(hf);
                    else
                        XLS.getSheet(aktifSheet).getSettings().setHeader(hf);
                }
            }
        }

        public void SelectSheet(int sheetNo)
        {
            XLS.getSheet(sheetNo).getSettings().setSelected(true);
        }

        public void SelectSheet()
        {
            SelectSheet(aktifSheet);
        }

        public void ResimEkle(double x, double y, double width, double height, string dosya)
        {
            System.Drawing.Image image = null;
            try
            {
                image = System.Drawing.Image.FromFile(dosya);
            }
            catch { return; }

            System.IO.MemoryStream stream = new System.IO.MemoryStream();

            try
            {
                image.Save(stream, ImageFormat.Jpeg);
                stream.Seek(0, System.IO.SeekOrigin.Begin);
            }
            catch { return; }

            long buyukluk = stream.Length;
            sbyte[] imageInSBytes = new sbyte[buyukluk];
            for (long i = 0; i < buyukluk; i++)
            {
                int oku = stream.ReadByte();
                if (oku != -1)
                {
                    imageInSBytes[i] = (sbyte)oku;
                }
                else
                {
                    buyukluk = i;
                }
            }

            WritableSheet sheet = XLS.getSheet(aktifSheet);
            sheet.addImage(new WritableImage(x, y, width, height, imageInSBytes));
            stream.Dispose();
        }

        public void ResimEkle(double x, double y, double width, double height, Stream stream)
        {
        }

        public object ResimEkle(double x, double y, double width, double height, Stream stream, double left, double top, int enBoyOran, int yanasiklik)
        {
            return null;
        }

        public void DosyaKapat()
        {
            XLS.close();     // Workbook'u kapatma
            tmpFileStream.Close();
            if (okuModu)
            {
                try
                {
                    System.IO.File.Delete(tmpFile);
                }
                catch
                {

                }
            }
        }

        public string UzantiBul()
        {
            return "xls";
        }

        public void YazdirmaYineleme(int sheetNo, string yineleSatir, string yineleSutun)
        {
        }

        public void DosyaSaklamaFormatAta(string uzanti)
        {
        }

        public void CalculateFormula()
        {
        }

        public void HucreAdAdresOl(string bolgeAd, int sheetNo, int satir1, int sutun1, int satir2, int sutun2)
        {
            throw new NotImplementedException();
        }

        public void DosyaOkuAc(Stream dosyaStream)
        {
            throw new NotImplementedException();
        }

        public string CellIndexToName(int row, int column)
        {
            throw new NotImplementedException();
        }

        public void CellNameToIndex(string name, out int row, out int column)
        {
            throw new NotImplementedException();
        }

        public void HucreMetniSigdir(int satir1, int sutun1, int satir2, int sutun2, bool deger)
        {
            throw new NotImplementedException();
        }

        public void HucreMetniSigdir(int satir, int sutun, bool deger)
        {
            throw new NotImplementedException();
        }


        public void SayfaYonuAta(SayfaYonu sayfaYonu)
        {
            throw new NotImplementedException();
        }

        public void TekrarlanacakSatirlar(int satir1, int satir2)
        {
            throw new NotImplementedException();
        }

        public void TekrarlanacakSutunlar(int sutun1, int sutun2)
        {
            throw new NotImplementedException();
        }

        public void AltaltaSayfaSayisi(int sayfaSayisi)
        {
            throw new NotImplementedException();
        }

        public void YanyanaSayfaSayisi(int sayfaSayisi)
        {
            throw new NotImplementedException();
        }

        public void SatirYukseklikAyarla(int satir1, int satir2, int yukseklik, int ekle, int minYuks)
        {
            SatirYukseklikAyarla(satir1, satir2, yukseklik, 0, 0);
        }

        public void FormulleriSil()
        {
            return;
        }
        public void Sirala(int order1, int key1, int satir1, int sutun1, int satir2, int sutun2)
        {
            return;
        }
    }
}
