﻿using System;
using System.Collections.Generic;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace OrtakClass
{
    /// <summary>
    /// Summary description for Zip.
    /// </summary>
    public class Zip
    {
        public static void Ziple(string zipKlasor, string sonucDosyaAd, string[] dosyalar)
        {
            string releativePath = "";
            string[] dizinler = new string[1];

            //Ziplenecek dosya ad gönderilmedi ise
            if (dosyalar[0] == "")
            {
                dosyalar = Directory.GetFiles(zipKlasor, "*", SearchOption.AllDirectories);
                dizinler = Directory.GetDirectories(zipKlasor, "*", SearchOption.AllDirectories);
            }

            ZipOutputStream geciciDosya = new ZipOutputStream(new System.IO.FileStream(sonucDosyaAd, System.IO.FileMode.Create));

            foreach (string file in dosyalar)
            {
                releativePath = Path.GetFileName(file);

                ZipEntry zipGiris = new ZipEntry(releativePath);
                geciciDosya.PutNextEntry(zipGiris);
                byte[] buffer = File.ReadAllBytes(file);
                geciciDosya.Write(buffer, 0, buffer.Length);
                geciciDosya.CloseEntry();
            }

            //Boş klasörleri almak için
            foreach (string dir in dizinler)
            {
                if (string.IsNullOrWhiteSpace(dir)) continue;

                releativePath = Path.GetDirectoryName(dir);

                ZipEntry zipGiris = new ZipEntry(releativePath + "/");
                geciciDosya.PutNextEntry(zipGiris);
                geciciDosya.CloseEntry();
            }


            geciciDosya.Finish();
            geciciDosya.Close();
        }

        //public static List<ZipEntry> GetZipFiles(java.util.zip.ZipFile zipfil)
        //{
        //    List<ZipEntry> lstZip = new List<ZipEntry>();
        //    Enumeration zipEnum = zipfil.entries();
        //    while (zipEnum.hasMoreElements())
        //    {
        //        ZipEntry zip = (ZipEntry)zipEnum.nextElement();
        //        lstZip.Add(zip);
        //    }
        //    return lstZip;
        //}

        //public static List<string> GetZipFilesName(string zipFileName)
        //{
        //    java.util.zip.ZipFile zipfil = new java.util.zip.ZipFile(zipFileName);
        //    List<string> lstZip = new List<string>();
        //    Enumeration zipEnum = zipfil.entries();
        //    while (zipEnum.hasMoreElements())
        //    {
        //        ZipEntry zip = (ZipEntry)zipEnum.nextElement();
        //        lstZip.Add(zip.getName());
        //    }
        //    return lstZip;
        //}

        //public static void ZipAc(string zipFileName, string destinationPath)
        //{
        //    java.util.zip.ZipFile zipfile = new java.util.zip.ZipFile(zipFileName);
        //    List<ZipEntry> zipFiles = GetZipFiles(zipfile);

        //    foreach (ZipEntry zipFile in zipFiles)
        //    {
        //        if (!zipFile.isDirectory())
        //        {
        //            InputStream s = zipfile.getInputStream(zipFile);
        //            try
        //            {
        //                Directory.CreateDirectory(destinationPath + "\\" +
        //                  Path.GetDirectoryName(zipFile.getName()));
        //                FileOutputStream dest = new FileOutputStream(Path.Combine
        //                  (destinationPath + "\\" + Path.GetDirectoryName(zipFile.getName()),
        //                  Path.GetFileName(zipFile.getName())));
        //                try
        //                {
        //                    int len = 0;
        //                    sbyte[] buffer = new sbyte[7168];
        //                    while ((len = s.read(buffer)) >= 0)
        //                    {
        //                        dest.write(buffer, 0, len);
        //                    }
        //                }
        //                finally
        //                {
        //                    dest.close();
        //                }
        //            }
        //            finally
        //            {
        //                s.close();
        //            }
        //        }
        //    }
        //}


    }
}
