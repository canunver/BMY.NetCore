﻿#if !MU
using System;
using System.Collections.Generic;
using System.Security.Permissions;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace TNS.WebControls
{

    public enum ENUMKodGiris
    {
        Normal,
        NormalOlaysiz,
        Gizli,
        Engelli
    }

    public enum ENUMListeTur
    {
        YardimSayfasi,
        KodAdGetir,
        Gizli,
    }

    public enum ENUMKodAdTur
    {
        Normal,
        Gizli,
    }

    [ToolboxData("<{0}:TNSKodGiris runat=server></{0}:TNSKodGiris>"),
    AspNetHostingPermission(SecurityAction.Demand,
        Level = AspNetHostingPermissionLevel.Minimal),
    AspNetHostingPermission(SecurityAction.InheritanceDemand,
        Level = AspNetHostingPermissionLevel.Minimal),
    ]
    [DefaultProperty("Value")]
    public class TNSKodGiris : WebControl, INamingContainer
    {
        private TextBox kod = null;
        private Label kodAd = null;
        private bool m_divisionda = true;

        [DefaultValue(true),]
        public bool divisionda { get { return m_divisionda; } set { m_divisionda = value; } }

        private string m_ListeSayfa;
        public string ListeSayfa { get { return m_ListeSayfa; } set { m_ListeSayfa = value; } }

        private int m_Genislik = 500;
        public int ListeSayfaGenislik { get { return m_Genislik; } set { m_Genislik = value; } }

        private int m_Yukseklik = 500;
        public int ListeSayfaYukseklik { get { return m_Yukseklik; } set { m_Yukseklik = value; } }

        private int m_KodWidth = 70;
        public int KodWidth { get { return m_KodWidth; } set { m_KodWidth = value; } }

        private int m_KodAdWidth = 200;
        public int KodAdWidth { get { return m_KodAdWidth; } set { m_KodAdWidth = value; } }

        private string m_EkParamEval;
        public string EkParamEval { get { return m_EkParamEval; } set { m_EkParamEval = value; } }

        private string m_CikisJS;
        public string CikisJS { get { return m_CikisJS; } set { m_CikisJS = value; } }

        private string m_DogrulaEval;
        public string DogrulaEval { get { return m_DogrulaEval; } set { m_DogrulaEval = value; } }

        private string m_KodDivClass = "veriAlan";
        public string KodDivClass { get { return m_KodDivClass; } set { m_KodDivClass = value; } }

        private string m_KodDivStyle;
        public string KodDivStyle { get { return m_KodDivStyle; } set { m_KodDivStyle = value; } }

        private string m_KodClass;
        public string KodClass { get { return m_KodClass; } set { m_KodClass = value; } }

        //private string m_KodStyle;
        //public string KodStyle { get { return m_KodStyle; } set { m_KodStyle = value; } }

        private string m_KodAdDivClass = "yaziAlan";
        public string KodAdDivClass { get { return m_KodAdDivClass; } set { m_KodAdDivClass = value; } }

        private string m_KodAdDivStyle;
        public string KodAdDivStyle { get { return m_KodAdDivStyle; } set { m_KodAdDivStyle = value; } }

        private string m_KodAdClass;
        public string KodAdClass { get { return m_KodAdClass; } set { m_KodAdClass = value; } }

        private string m_ImgDivClass = "veriAlan";
        public string ImgDivClass { get { return m_ImgDivClass; } set { m_ImgDivClass = value; } }

        private string m_ImgDivStyle;
        public string ImgDivStyle { get { return m_ImgDivStyle; } set { m_ImgDivStyle = value; } }

        private string m_ImgClass;
        public string ImgClass { get { return m_ImgClass; } set { m_ImgClass = value; } }

        private string m_ImgStyle;
        public string ImgStyle { get { return m_ImgStyle; } set { m_ImgStyle = value; } }

        private string m_ImgAlt;
        public string ImgAlt { get { return m_ImgAlt; } set { m_ImgAlt = value; } }

        private string m_ImgSrc = "../App_themes/images/bul1.gif";
        public string ImgSrc { get { return m_ImgSrc; } set { m_ImgSrc = value; } }

        private ENUMKodGiris m_KodGirisTur = ENUMKodGiris.Normal;
        public ENUMKodGiris KodGirisTur { get { return m_KodGirisTur; } set { m_KodGirisTur = value; } }

        private ENUMListeTur m_ListeTur = ENUMListeTur.YardimSayfasi;
        public ENUMListeTur ListeTur { get { return m_ListeTur; } set { m_ListeTur = value; } }

        private ENUMKodAdTur m_KodAdTur = ENUMKodAdTur.Normal;
        public ENUMKodAdTur KodAdTur { get { return m_KodAdTur; } set { m_KodAdTur = value; } }

        public string Value
        {
            get
            {
                EnsureChildControls();
                return kod.Text;
            }
            set
            {
                EnsureChildControls();
                kod.Text = value;
            }
        }

        public string Text
        {
            get
            {
                EnsureChildControls();
                return kodAd.Text;
            }
            set
            {
                EnsureChildControls();
                kodAd.Text = value;
            }
        }

        protected override void CreateChildControls()
        {
            kod = new TextBox();
            kod.ID = "kod";
            Controls.Add(kod);

            kodAd = new Label();
            kodAd.ID = "kodAd";
            Controls.Add(kodAd);

            base.CreateChildControls();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            System.Web.UI.ClientScriptManager csm;
            try
            {
                csm = this.Page.ClientScript;
                csm.RegisterClientScriptInclude("TNSOneri", "../script/TNSKodGiris.js?mc=03022015");
            }
            catch { }
        }

        protected override void Render(HtmlTextWriter output)
        {
            try
            {
                if (Visible)
                {
                    output.WriteLine();
                    if (divisionda)
                    {
                        output.WriteLine(DivStrOl(KodDivClass, KodDivStyle, KodGirisTur == ENUMKodGiris.Gizli));
                    }
                    if (KodWidth >= 0)
                        kod.Width = KodWidth;
                    if (KodGirisTur == ENUMKodGiris.Gizli)
                        kod.Width = 0;
                    if (KodGirisTur == ENUMKodGiris.Engelli)
                        kod.ReadOnly = true;

                    if (KodGirisTur == ENUMKodGiris.Normal && !string.IsNullOrEmpty(CikisJS))
                        kod.Attributes.Add("onblur", CikisJS);
                    kod.CssClass = KodClass;
                    kod.EnableViewState = true;
                    kod.RenderControl(output);
                    if (divisionda)
                    {
                        output.WriteLine(DivKapat());
                    }
                    output.WriteLine();
                    if (ListeTur != ENUMListeTur.Gizli)
                    {
                        if (divisionda)
                        {
                            output.WriteLine(DivStrOl(ImgDivClass, ImgDivStyle, false));
                        }

                        string clickEventStr = "";
                        if (ListeTur == ENUMListeTur.YardimSayfasi)
                            clickEventStr = JavaScriptClickOl(true, ListeSayfa, kod.ID, kodAd.ID, EkParamEval, DogrulaEval, ListeSayfaGenislik, ListeSayfaYukseklik);
                        else
                            clickEventStr = CikisJS;

                        output.WriteLine("<input type=\"image\""
                            + OrtakClass.GenelIslemler.TirnakliParam(true, true, "id", "img" + ID)
                            + OrtakClass.GenelIslemler.TirnakliParam(true, true, "class", ImgClass)
                            + OrtakClass.GenelIslemler.TirnakliParam(true, true, "style", ImgStyle)
                            + OrtakClass.GenelIslemler.TirnakliParam(true, true, "alt", ImgAlt)
                            + OrtakClass.GenelIslemler.TirnakliParam(true, true, "onclick", clickEventStr)
                            + OrtakClass.GenelIslemler.TirnakliParam(true, true, "src", ImgSrc)
                            + OrtakClass.GenelIslemler.TirnakliParam(true, true, "TabIndex", "-1")
                            + "/>");

                        if (divisionda)
                        {
                            output.WriteLine(DivKapat());
                        }
                    }

                    output.WriteLine();
                    if (divisionda)
                    {
                        output.WriteLine(DivStrOl(KodAdDivClass, KodAdDivStyle, KodAdTur == ENUMKodAdTur.Gizli));
                    }
                    kodAd.CssClass = KodAdClass;
                    if (KodAdWidth >= 0)
                        kodAd.Width = KodAdWidth;
                    if (KodAdTur == ENUMKodAdTur.Gizli)
                        kodAd.Width = 0;
                    kodAd.Style.Add(HtmlTextWriterStyle.WhiteSpace, "nowrap");
                    kodAd.RenderControl(output);
                    if (divisionda)
                    {
                        output.WriteLine(DivKapat());
                    }
                    output.WriteLine();
                }
            }
            catch (Exception ex)
            {
                output.Write(ex.StackTrace);
            }
        }

        private string JavaScriptClickOl(bool tekTirnak, string listeSayfa, string kodId, string kodAdId, string ekParamEval, string DogrulaEval, int genislik, int uzunluk)
        {
            if (string.IsNullOrEmpty(listeSayfa)) return "";
            return "javascript:KodGirisSecimAc(" + TirnakliDeger(tekTirnak, listeSayfa) + "," + TirnakliDeger(tekTirnak, kodId) + "," + TirnakliDeger(tekTirnak, kodAdId) + "," + TirnakliDeger(tekTirnak, ekParamEval) + "," + TirnakliDeger(tekTirnak, DogrulaEval) + "," + genislik.ToString() + "," + uzunluk.ToString() + ");return false;";

        }

        private object TirnakliDeger(bool tekTirnak, string deger)
        {
            char tirnak;
            if (tekTirnak)
                tirnak = '\'';
            else
                tirnak = '"';
            return tirnak + deger + tirnak;
        }

        private string DivKapat()
        {
            return "</div>";
        }

        private string DivStrOl(string kodClass, string kodStyle, bool gizli)
        {
            string ekStr = "";
            if (gizli)
                ekStr = "visibility:hidden;";
            return "<div" + OrtakClass.GenelIslemler.TirnakliParam(true, true, "class", kodClass) + OrtakClass.GenelIslemler.TirnakliParam(true, true, "style", ekStr + kodStyle) + ">";
        }

    }
}
#endif