﻿#if !MU
using System;
using System.Web;
using TNS.KYM;

namespace OrtakClass
{
    /// <summary>
    /// Modülü kullanan kullanıcının bilgilerini session bilgisinde
    /// saklayıp tekrar geri çağırmak için kullanılır
    /// </summary>
    public class OturumBilgisiIslem
    {
        /// <summary>
        /// Sisteme giriş yapmış kullanıcıya ait bilgileri, session bilgisinde saklamak için kullanılır
        /// </summary>
        /// <param name="p"></param>
        /// <param name="kullanan"></param>
        public void KullaniciBilgiYaz(Kullanici kullanan)
        {
            HttpContext.Current.Session.Timeout = 40;
            HttpContext.Current.Session["kullanan"] = kullanan;
            HttpContext.Current.Session["YoneticiMi"] = TNS.KYM.Yetki.YoneticiMi(kullanan).islemSonuc;
            HttpContext.Current.Session["KullaniciYoneticisiMi"] = TNS.KYM.Yetki.SistemveyaKullaniciYoneticisiMi(kullanan);

            KullaniciVeriTabaninaYaz(kullanan);
        }

        public void KullaniciBilgiYazVTSiz(Kullanici kullanan)
        {
            HttpContext.Current.Session.Timeout = 40;
            HttpContext.Current.Session["kullanan"] = kullanan;
            HttpContext.Current.Session["YoneticiMi"] = TNS.KYM.Yetki.YoneticiMi(kullanan).islemSonuc;
            HttpContext.Current.Session["KullaniciYoneticisiMi"] = TNS.KYM.Yetki.SistemveyaKullaniciYoneticisiMi(kullanan);
        }

        /// <summary>
        /// Verilen değişken ve değeri Oturum bilgisi olarak saklamak için
        /// </summary>
        /// <param name="p"></param>
        /// <param name="degisken"></param>
        /// <param name="deger"></param>
        public static void BilgiYazDegisken(string degisken, object deger)
        {
            if (HttpContext.Current.Session != null)
                HttpContext.Current.Session[degisken] = deger;
        }

        /// <summary>
        /// Sisteme giriş yapmış kullanıcının Session bilgisine ulaşmak için kullanılır
        /// </summary>
        /// <param name="p"></param>
        /// <returns>TNS.KYM.Kullanici</returns>
        public static Kullanici KullaniciBilgiOku(bool anaSayfayaGit)
        {
            return KullaniciBilgiOku(anaSayfayaGit, false);
        }

        /// <summary>
        /// Sisteme giriş yapmış kullanıcının Session bilgisine ulaşmak için kullanılır
        /// </summary>
        /// <param name="p"></param>
        /// <returns>TNS.KYM.Kullanici</returns>
        public static Kullanici KullaniciBilgiOku(bool anaSayfayaGit, bool loglama)
        {
            try
            {
                HttpContext.Current.Session.Timeout = 40;
            }
            catch
            {
            }

            Kullanici kullanan;
            try
            {
                kullanan = (Kullanici)HttpContext.Current.Session["kullanan"];
            }
            catch { kullanan = null; }

            if (kullanan == null && anaSayfayaGit)
            {
                try { OturumBilgisiIslem.BilgiYazDegisken("url", HttpContext.Current.Request.Url); } catch { }

                string yonlen = System.Configuration.ConfigurationManager.AppSettings.Get("GirisSayfasi");
                HttpContext.Current.Response.Redirect(yonlen);
            }
            else
            {
                if (kullanan == null)
                {
                    kullanan = new Kullanici();
                    kullanan.kullaniciTipi = new ENUMKullaniciTipi[1];
                    kullanan.kullaniciTipi[0] = ENUMKullaniciTipi.MISAFIR;
                }
                else
                {
                    if (HttpContext.Current.Handler is System.Web.UI.Page && !loglama)
                    {
                        System.Web.UI.Page p = HttpContext.Current.Handler as System.Web.UI.Page;
                        if (!Ext1.Net.X.IsAjaxRequest)
                            KullaniciVeriTabaninaYaz(kullanan);
                    }
                }
            }
            return kullanan;
        }

        public static Kullanici KullaniciBilgiOkuVTsiz(bool anaSayfayaGit)
        {
            try
            {
                HttpContext.Current.Session.Timeout = 40;
            }
            catch
            {
            }

            Kullanici kullanan = (Kullanici)HttpContext.Current.Session["kullanan"];

            if (kullanan == null && anaSayfayaGit)
                HttpContext.Current.Response.Redirect(System.Configuration.ConfigurationManager.AppSettings.Get("GirisSayfasi"));
            else
            {
                if (kullanan == null)
                {
                    kullanan = new Kullanici();
                    kullanan.kullaniciTipi = new ENUMKullaniciTipi[0];
                    kullanan.kullaniciTipi[0] = ENUMKullaniciTipi.MISAFIR;
                }
            }
            return kullanan;
        }

        /// <summary>
        /// İstenilen değişken adının değerini session bilgisinden okumak için
        /// </summary>
        /// <param name="p"></param>
        /// <param name="degisken"></param>
        public static object BilgiOkuDegisken(string degisken, bool cikisYap)
        {
            object obj = null;

            try
            {
                obj = (object)HttpContext.Current.Session[degisken];

                if (cikisYap && obj == null)
                    HttpContext.Current.Response.Redirect(System.Configuration.ConfigurationManager.AppSettings.Get("GirisSayfasi"));
            }
            catch
            {
            }

            return obj;
        }

        /// <summary>
        /// İstenilen değişken adının değerini session bilgisinden okumak için
        /// </summary>
        /// <param name="p"></param>
        /// <param name="degisken"></param>
        public static object BilgiOkuDegisken(string degisken, bool cikisYap, object hataDeger)
        {
            object obj = BilgiOkuDegisken(degisken, cikisYap);
            if (obj == null)
                return hataDeger;
            else
                return obj;
        }


        public static void KullaniciVeriTabaninaYaz(Kullanici kullanan)
        {
            IKYMServis servisYetki = TNS.KYM.Arac.Tanimla();
            string hostName = GenelIslemler.GetIPAddress();
            string sayfaAd = HttpContext.Current.Request.Url.AbsolutePath;
            TNS.TNSDateTime tarih = new TNS.TNSDateTime(DateTime.Now);
            string p1 = kullanan.ad + " " + kullanan.soyad;
            string p2 = "";// kullanan.telefon;
            string p3 = "";
            string p4 = "";
            string p5 = "";

            servisYetki.KullaniciSessionAta(kullanan.kullaniciKodu, tarih, hostName, sayfaAd, p1, p2, p3, p4, p5);
        }
    }
}
#endif