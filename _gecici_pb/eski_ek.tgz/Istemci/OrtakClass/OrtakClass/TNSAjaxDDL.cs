#if !MU
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace TNS.WebControls
{

    public class TNSAjaxDDLItem
    {
        private string value;
        private string text;
        //public TNSAjaxDDLItem()
        //{
        //    this.value = value;
        //    this.text = text;
        //}
        //public TNSAjaxDDLItem(string text, string value)
        //{
        //    this.value = value;
        //    this.text = text;
        //}

        [
        Category("Behavior"),
        DefaultValue(""),
        Description("Text"),
        NotifyParentProperty(true),
        ]
        public String Text
        {
            get
            {
                return text;
            }
            set
            {
                text = value;
            }
        }

        [
        Category("Behavior"),
        DefaultValue(""),
        Description("Value"),
        NotifyParentProperty(true),
        ]
        public String Value
        {
            get
            {
                return this.value;
            }
            set
            {
                this.value = value;
            }
        }

    }

    [DefaultProperty("Text")]
    [ParseChildren(true, "Items")]
    [ToolboxData("<{0}:TNSAjaxDDL runat=server></{0}:TNSAjaxDDL>")]
    public class TNSAjaxDDL : WebControl, INamingContainer
    {
        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("")]
        [Localizable(true)]

        //private DropDownList ddl = null;
        private ArrayList ddlItems = new ArrayList();
        private HiddenField hfText = null;
        private HiddenField hfValue = null;

        [
         Category("Behavior"),
         Description("The contacts collection"),
         PersistenceMode(PersistenceMode.InnerDefaultProperty)
         ]
        public ArrayList Items
        {
            get
            {
                if (ddlItems == null)
                {
                    ddlItems = new ArrayList();
                }
                return ddlItems;
            }
        }

        public string Text
        {
            get
            {
                EnsureChildControls();
                return hfText.Value;
            }

            set
            {
                EnsureChildControls();
                hfText.Value = value;
            }
        }

        public string Value
        {
            get
            {
                EnsureChildControls();
                return hfValue.Value;
            }

            set
            {
                EnsureChildControls();
                hfValue.Value = value;
            }
        }

        protected override void CreateChildControls()
        {
            hfValue = new HiddenField();
            hfText = new HiddenField();
            Controls.Add(hfValue);
            Controls.Add(hfText);

            //foreach (ListItem item in Items)
            //{
            //    ddlItems.Add(new ListItem(item.Text, item.Value));
            //}
            base.CreateChildControls();
        }


        public string TxtIDBul()
        {
            EnsureChildControls();
            return hfValue.UniqueID;
        }
        public void Add(ListItem item)
        {
            EnsureChildControls();
            ddlItems.Add(item);
        }

        private string tnsAjaxDDLJSPath;
        public string TNSAjaxDDLJSPath
        {
            get
            {
                return tnsAjaxDDLJSPath;
            }

            set
            {
                tnsAjaxDDLJSPath = value;
            }
        }

        private string httpCagirJSPath;
        public string HTTPCagirJSPath
        {
            get
            {
                return httpCagirJSPath;
            }

            set
            {
                httpCagirJSPath = value;
            }
        }


        private string icerikYuklemeAdresi;
        public string IcerikYuklemeAdresi
        {
            get
            {
                return icerikYuklemeAdresi;
            }

            set
            {
                icerikYuklemeAdresi = value;
            }
        }

        private string _style;
        public string style
        {
            get
            {
                return _style;
            }

            set
            {
                _style = value;
            }
        }

        private string tnsDegistiJS;
        public string TNSDegistiJS
        {
            get
            {
                return tnsDegistiJS;
            }

            set
            {
                tnsDegistiJS = value;
            }
        }


        public string DegistiJS(string jsValueString)
        {
            return "js_" + ID + ".Reload(" + jsValueString + ");";
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            System.Web.UI.ClientScriptManager csm = null;
            try
            {
                csm = this.Page.ClientScript;
            }
            catch { }

            if (csm != null)
            {
                try
                {
                    csm.RegisterClientScriptInclude("TNSAjaxDDL", TNSAjaxDDLJSPath);
                }
                catch { }

                try
                {
                    csm.RegisterClientScriptInclude("HTTPCagir", HTTPCagirJSPath);
                }
                catch { }
            }


            //try
            //{

            //    System.Web.UI.HtmlControls.HtmlHead h = this.Page.Header;
            //    System.Web.UI.HtmlControls.HtmlLink hl = new System.Web.UI.HtmlControls.HtmlLink();
            //    hl.Href = "../App_themes/TNSTab.css";
            //    hl.Attributes["type"] = "text/css";
            //    hl.Attributes["rel"] = "stylesheet";
            //    h.Controls.Add(hl);
            //}
            //catch { }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            //return null;
        }

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            //return null;
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            base.RenderContents(output);
            try
            {
                if (Visible)
                {
                    string ekStr="";
                    if (!string.IsNullOrEmpty(style))
                        ekStr = "style=\"" + style + "\"";
                    if (!string.IsNullOrEmpty(this.CssClass))
                    {
                        if (!string.IsNullOrEmpty(ekStr)) ekStr += " ";
                        ekStr = ekStr + "class=\"" + this.CssClass + "\"";
                    }
                    if (!string.IsNullOrEmpty(ekStr)) ekStr = " " + ekStr;
                    output.Write("\r\n<select name=\"" + ID + "\" style=\"\"" + "onchange=\"" + "javascript:{js_" + ID + ".ItemChange();" + TNSDegistiJS + "}\"" + ekStr + ">\r\n");
                    foreach (ListItem li in ddlItems)
                    {
                        string s;
                        if (Value == li.Value)
                            s = "SELECTED";
                        else
                            s = "";

                        output.Write("<option " + s + " value=\"" + li.Value + "\">" + li.Text + "</option>\r\n");
                    }
                    output.Write("</select>\r\n");

                    output.Write("\r\n<script language='JavaScript' type='text/javascript'>");
                    output.Write("var js_" + ID + "= new TnsAjaxDDL('" + ID + "', '" + hfText.UniqueID + "', '" + hfValue.UniqueID + "', '" + IcerikYuklemeAdresi + "');");
                    output.Write("</script>\r\n");
                }
            }
            catch (Exception ex)
            {
                output.Write(ex.Message);
            }
        }
    }
}
#endif