﻿#if !MU
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Security.Permissions;
using OrtakClass;
using System.Web.UI.HtmlControls;

namespace TNS.WebControls
{

    [ToolboxData("<{0}:TNSOneri runat=server></{0}:TNSOneri>"),
    AspNetHostingPermission(SecurityAction.Demand,
        Level = AspNetHostingPermissionLevel.Minimal),
    AspNetHostingPermission(SecurityAction.InheritanceDemand,
        Level = AspNetHostingPermissionLevel.Minimal),
    ]
    public class TNSOneri : WebControl, INamingContainer, IPostBackEventHandler
    {
        //KmL
        //(OK) TODO:öneri listesinden seçilen bir text silinirse ya da değiştirilirse value değerininde silinmesi gerekir.
        //(OK) TODO:m_ValueControlID eklenecek
        //TODO:m_SonucGetirAdresParametreler boş gelirse hata döndürmesin 
        //TODO:m_CssClass, m_cssAd çalışıp çalışmadığı kontrol edilecek. width çalışıyor.
        //TODO:servis kodunda query string ile alınan "girdi" ifadasi parametrik yapılabilir.

        private string m_LoadingImagePath = "../App_themes/Images/loading2.gif";
        private string m_CssClass = "veriAlan";
        private string m_SonucGetirAdres;
        private string m_SonucGetirAdresParametreler;
        private bool m_TumVeriGoster;
        private HiddenField hf = null;
        private TextBox txt = null;
        private Image img = null;
        private bool m_TarihAlani;


        public TNSOneri()
        {
        }

        [DefaultValue(false)]
        public bool TumVeriGoster
        {
            get { return m_TumVeriGoster; }
            set { m_TumVeriGoster = value; }
        }

        [DefaultValue(false)]
        public bool TarihAlani
        {
            get { return m_TarihAlani; }
            set { m_TarihAlani = value; }
        }

        public string Text
        {
            get
            {
                if (txt != null)
                {
                    string v = txt.Text;
                    if (v == this.Attributes["Etiket"]) v = "";
                    return v;
                }
                else
                    return "";
            }
            set
            {
                if (txt == null)
                    CreateChildControls();
                if (txt != null)
                    txt.Text = value.ToString();
            }
        }

        public string ValueOrText
        {
            get
            {
                string v = "";
                if (hf != null)
                    v = hf.Value;
                if (string.IsNullOrEmpty(v))
                {
                    return Text;
                }
                return v;
            }
        }


        public string Value
        {
            get
            {
                if (hf != null)
                    return hf.Value;
                else
                    return "";
            }
            set
            {
                if (hf == null)
                    CreateChildControls();
                if (hf != null)
                    hf.Value = value.ToString();
            }
        }

        public string SonucGetirAdres
        {
            get { return m_SonucGetirAdres; }
            set { m_SonucGetirAdres = value; }
        }

        public string SonucGetirAdresParametreler
        {
            get { return m_SonucGetirAdresParametreler; }
            set { m_SonucGetirAdresParametreler = value; }
        }

        [DefaultValue("../App_themes/Images/loading2.gif")]
        public string LoadingImagePath
        {
            get { return m_LoadingImagePath; }
            set { m_LoadingImagePath = value; }
        }

        [DefaultValue("veriAlan ")]
        public override string CssClass
        {
            get { return m_CssClass; }
            set { m_CssClass = value; }
        }

        private void TxtDegerAta()
        {
            CreateChildControls();
            txt.Width = Width;
            txt.CssClass = m_CssClass;
        }

        protected override void CreateChildControls()
        {
            if (hf == null)
            {
                hf = new HiddenField();
                hf.ID = "hf";
                Controls.Add(hf);
            }

            if (txt == null)
            {
                txt = new TextBox();
                txt.ID = "txt";
                txt.AutoCompleteType = AutoCompleteType.Disabled;
                Controls.Add(txt);
            }

            if (img == null && m_TarihAlani)
            {
                img = new Image();
                img.ImageUrl = "../App_themes/Images/takvim.gif";
                img.Width = Unit.Pixel(16);
                img.Height = Unit.Pixel(16);
                img.Attributes.Add("onclick", "JavaScript:displayDatePicker('" + txt.ClientID + "',false, 'dmy', '.');return false;");
                img.Style.Add("cursor", "pointer");
                Controls.Add(img);
            }

            base.CreateChildControls();
        }

        private void HTMLBaslikEkle()
        {
            System.Web.UI.ClientScriptManager csm;
            try
            {
                csm = this.Page.ClientScript;
                csm.RegisterClientScriptInclude("TNSOneri", "../script/TNSOneri.js?mc=03022015");
            }
            catch { }

            try
            {
                System.Web.UI.HtmlControls.HtmlHead h = this.Page.Header;
                System.Web.UI.HtmlControls.HtmlLink hl = new System.Web.UI.HtmlControls.HtmlLink();
                hl.Href = "../App_themes/" + "form" + ".css";
                hl.Attributes["type"] = "text/css";
                hl.Attributes["rel"] = "stylesheet";
                h.Controls.Add(hl);
            }
            catch { }
        }

        protected override void OnLoad(EventArgs e)
        {
            CreateChildControls();
            HTMLBaslikEkle();
            base.OnLoad(e);
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            TxtDegerAta();
            try
            {
                if (Visible)
                {
                    base.RenderContents(output);
                    output.WriteLine();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("var js_" + ClientID + " = new TnsOneri(");
                    sb.Append(GenelIslemler.Tirnakla("js_" + ClientID, 1, true));
                    sb.Append(GenelIslemler.Tirnakla(txt.ClientID, 1, true));
                    sb.Append(GenelIslemler.Tirnakla(hf.ClientID, 1, true));
                    sb.Append(GenelIslemler.Tirnakla(m_SonucGetirAdres, 1, true));
                    sb.Append(GenelIslemler.Tirnakla(m_SonucGetirAdresParametreler, 1, true));
                    sb.Append(GenelIslemler.Tirnakla(m_LoadingImagePath, 1, true));
                    sb.Append(GenelIslemler.Tirnakla(m_TumVeriGoster.ToString(), 1, true));
                    sb.Append(GenelIslemler.Tirnakla(this.Attributes["Etiket"], 1, false));
                    sb.AppendLine(");");
                    System.Web.UI.ClientScriptManager csm = this.Page.ClientScript;
                    csm.RegisterStartupScript(typeof(int), txt.ClientID, sb.ToString(), true);

                    //sb.AppendLine("<div style=\"position:relative;z-index: 100;margin:0px;padding:0px;\"> ");
                    //sb.AppendLine("<div> ");
                    //sb.AppendLine("<img id=\"" + htmlimgid + "\" src=\"" + m_LoadingImagePath + "\" style=\"position:absolute;display: none; z-index: 100; left: " + Width.ToString() + "; top: 5px; width: 16px; height: 16px;margin:0px -16px\" />");
                    //sb.AppendLine("</div> ");
                    ////sb.AppendLine("</div>");

                    ////sb.AppendLine("<div style=\"position:relative;z-index: 100;margin:0px;padding:0px;\"> ");
                    //sb.AppendLine("<div id=\"" + divId + "\" onfocus=\"divGoster('" + divId + "');\" style=\"position:absolute;clear:both; cursor: pointer; ");
                    //sb.AppendLine(" background-color: White; overflow: auto; border: solid 1px gray; z-index: 100; ");
                    //sb.AppendLine(" visibility: hidden; width: " + Width.ToString() + ";height:0px;top: 22px\" >");
                    //sb.AppendLine("</div>");

                    //sb.AppendLine("</div>");

                    //output.Write(sb.ToString());
                }
            }
            catch (Exception ex)
            {
                output.Write(ex.StackTrace);
            }
        }

        #region IPostBackEventHandler Members
        public event EventHandler Click;
        public void RaisePostBackEvent(string eventArgument)
        {
            Click(this, EventArgs.Empty);
        }

        #endregion
    }
}
#endif