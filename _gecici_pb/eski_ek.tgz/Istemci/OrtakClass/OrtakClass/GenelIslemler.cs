using System;
using System.Collections;
using System.Web;
using TNS;
using TNS.KYM;
using TNS.UZY;
using TNS.DEG;
using System.Xml;
using System.IO.Compression;
using System.IO;
using System.Web.UI;
using System.Resources;
using System.Diagnostics.Eventing.Reader;

#if !MU
using System.Web.UI.WebControls;
#endif

namespace OrtakClass
{
    public enum LineStyle
    {
        DOUBLE,
        NONE,
        THIN,
        MEDIUM,
        HAIR,
        MEDIUM_DASHED
    }

    public enum TabloRenk
    {
        BLACK,
        GRAY_25,
        RED,
        ROSE,
        LIGHT_TURQUOISE2,
        ICE_BLUE,
        CORAL,
        VERY_LIGHT_YELLOW,
        PALE_BLUE,
        IVORY,
        YELLOW2,
        AQUA,
        ORANGE,
        PERIWINKLE,
        PINK2,
        ALICEBLUE,
        BLUE,
        GREEN,
        LAVENDER,
        DARKBLUE,
        DARKGREEN,
        DARKORANGE,
        DARKRED,
        DARKSALMON,
        DEEPPINK,
        DEEPSKYBLUE,
        DODGERBLUE,
        FIREBRICK,
        FORESTGREEN,
        GOLD,
        OLIVE,
        ORANGERED,
        WHITE
    }

    public enum SayfaYonu
    {
        YATAY, DUSEY
    }

    public interface Tablo
    {
        //tur=1 TIFF, 0/Diğer=JPEG
        void SheetToResim(int horRes, int verRes, string dosyaAd, int tur);
        void YeniSheetEkle(string dosyaYol, string dosyaAd, int index);

        int SheetSayisi();

        int SatirSayisi();

        int SutunSayisi();

        string SonucDosyaAd();

        void OtomatikYukseklik(int sheetNo, int satir, int sutun1, int sutun2);

        void SutunAcKontrolsuz(int sheetNo, int sutun, int acilacakSutunSayisi);

        void SatirAcKontrolsuz(int sheetNo, int satir, int acilacakSatirSayisi);

        void SatirAc(int sheetNo, int satir, int acilacakSatirSayisi);

        void SatirAc(int satir, int acilacakSatirSayisi);

        void SutunAc(int sheetNo, int sutun, int acilacakSutunSayisi);

        void SutunAc(int sutun, int acilacakSutunSayisi);

        void HucreIcerikAraYaz(string bulDeger, string yazDeger);
        void HucreIcerikAraYaz(string bulDeger, double yazDeger);

        void HucreAdBulYaz(string hucreAd, string deger);

        void HucreAdBulYaz(string hucreAd, double deger);

        void HucreAdBulYaz(string hucreAd, double deger, string paraIsareti, int kurusHane = 2);

        void HucreDegerHtmlYaz(int sheetNo, int satir, int sutun, string HtmlString);

        void HucreDegerYaz(int satir, int sutun, string deger);

        void HucreDegerYaz(int satir, int sutun, double deger);

        void HucreDegerYaz(int satir, int sutun, decimal deger);

        void HucreDegerYaz(int satir, int sutun, int deger);

        void HucreDegerYaz(int satir, int sutun, DateTime deger);

        void HucreDegerYaz(int satir, int sutun, double deger, string paraIsareti, int kurusHane = 2);

        double HucreDegerAlDbl(int sheetNo, int satir, int sutun);

        double HucreDegerAlDbl(int satir, int sutun);

        string HucreDegerAl(int sheetNo, int satir, int sutun, int noktaSay);

        string HucreDegerAl(int satir, int sutun);

        string HucreAdDegerAl(string hucreAd);

        string HucreFormulAl(int satir, int sutun);

        void HucreFormulYaz(int satir, int sutun, string formul);

        void KorumayaAl();

        void KorumayaAl(string sifre);

        void HucreAdAdresCoz(string hucreAd, ref int satir, ref int sutun);

        void HucreAdAdresCoz(string bolgeAd, ref int sheetNo, ref int satir1, ref int sutun1, ref int satir2, ref int sutun2);

        void HucreAdAdresOl(string bolgeAd, int sheetNo, int satir1, int sutun1, int satir2, int sutun2);

        void SatirKopyalaAc(int kaynakSheet, int satir, int kopyalanacakSatirSayisi, int hedefSheet, int hedefSatir);

        void SatirKopyalaAc(int satir, int kopyalanacakSatirSayisi, int hedefSatir);

        void SatirKopyala(int kaynakSheet, int satir, int kopyalanacakSatirSayisi, int hedefSheet, int hedefSatir);

        void SutunKopyalaAc(int kaynakSheet, int sutun, int kopyalanacakSutunSayisi, int hedefSheet, int hedefSutun);

        void SutunKopyalaAc(int sutun, int kopyalanacakSutunSayisi, int hedefSutun);

        void SutunKopyala(int kaynakSheet, int sutun, int kopyalanacakSutunSayisi, int hedefSheet, int hedefSutun);

        void HucreKopyala(int kaynakSheet, int satir1, int sutun1, int satir2, int sutun2, int hedefSheet, int hedefSatir, int hedefSutun);

        void HucreKopyala(int satir1, int sutun1, int satir2, int sutun2, int hedefSatir, int hedefSutun);

        void HucreBirlestir(int satir1, int sutun1, int satir2, int sutun2);

        void HucreBirlestirme(int satir1, int sutun1, int satir2, int sutun2);

        void HucreBirlestirme(int satir, int sutun);

        void SatirYukseklikAyarla(int satir1, int satir2, int yukseklik);

        void SatirYukseklikAyarla(int satir1, int satir2, int yukseklik, int ekle, int minYuks);

        void SatirGercekYukseklikAyarla(int satir1, int satir2, double yukseklik);

        double SatirGercekYukseklikAl(int satir);

        int SatirYukseklikAl(int sheetNo, int satir);

        int SatirYukseklikAl(int satir);

        void SutunGizle(int sutun1, int sutun2, bool gizle);

        void SatirGizle(int satir1, int satir2, bool gizle);

        void SatirSil(int satir1, int satir2);

        void SutunSil(int sutun1, int sutun2);

        void SutunGenislikAyarlaPixel(int sutun1, int sutun2, int genislik);
        void SutunGenislikAyarla(int sutun1, int sutun2, int genislik);

        void SutunGenislikAyarla(int sutun1, int sutun2, int genislik, int ekle, int minGenislik);

        void SutunGenislikAyarla(int sheetNo, int sutun1, int sutun2, int genislik, int ekle, int minGenislik);

        int SutunGenislikAl(int sheetNo, int sutun);

        int SutunGenislikAl(int sutun);

        void DuseyCizgiCiz(int satir1, int satir2, int sutun, LineStyle stil, TabloRenk renk, bool solMu);

        void DuseyCizgiCiz(int satir1, int satir2, int sutun, LineStyle stil, TabloRenk renk);

        void YatayCizgiCiz(int satir, int sutun1, int sutun2, LineStyle stil, TabloRenk renk, bool ustMu);

        void YatayCizgiCiz(int satir, int sutun1, int sutun2, LineStyle stil, TabloRenk renk);

        void CerceveCizgiCiz(int satir1, int satir2, int sutun1, int sutun2, LineStyle stil, TabloRenk renk);

        void CerceveCiz(int satir1, int satir2, int sutun1, int sutun2, LineStyle stil, TabloRenk renk);

        void ZoomSheet(int zf);

        void ZoomYazici(int zf);

        void HucreMetniKaydir(int satir1, int sutun1, int satir2, int sutun2, bool deger);

        void HucreMetniKaydir(int satir, int sutun, bool deger);

        void KoyuYap(int satir1, int sutun1, int satir2, int sutun2, bool deger);

        void KoyuYap(int satir, int sutun, bool deger);

        void YaziTipiAta(int satir1, int sutun1, int satir2, int sutun2, string fontAd);

        void YaziTipBuyuklugu(int satir, int sutun, int deger);

        void YaziTipBuyuklugu(int satir1, int sutun1, int satir2, int sutun2, int deger);

        void DuseyHizala(int satir1, int sutun1, int satir2, int sutun2, int deger);

        void DuseyHizala(int satir, int sutun, int deger);

        void YatayHizala(int satir1, int sutun1, int satir2, int sutun2, int deger);

        void YatayHizala(int satir, int sutun, int deger);

        void ArkaPlanRenk(int satir1, int sutun1, int satir2, int sutun2, System.Drawing.Color renk);

        void ArkaPlanRenk(int satir, int sutun, System.Drawing.Color renk);

        void ArkaPlanRenk(int satir1, int sutun1, int satir2, int sutun2, TabloRenk renk);

        void ArkaPlanRenk(int satir, int sutun, TabloRenk renk);

        void YaziRenk(int satir1, int sutun1, int satir2, int sutun2, TabloRenk renk);

        void YaziRenk(int satir, int sutun, TabloRenk renk);

        void YaziRenk(int satir1, int sutun1, int satir2, int sutun2, System.Drawing.Color renk);

        void YaziRenk(int satir, int sutun, System.Drawing.Color renk);

        void CokluSatirdaYaz(int satir, int sutun, bool deger);

        void AktifSheetDegistir(int sheetNo);

        int AktifSheet();

        int YeniSheetEkle();

        int YeniSheetEkle(int kaynakSheetNo);

        void SheetSil(int sheetNo);

        void SheetAdiVer(int sheetNo, string adi);

        string SheetAdiAl();
        string SheetAdiAl(int sheetNo);

        string CellIndexToName(int row, int column);

        void CellNameToIndex(string name, out int row, out int column);

        void SayfaSonuKoySutun(int sutun);

        void SayfaSonuKoy(int satir);

        void SayfaSonuKoyHucresel(int satir);

        void IlkSayfaNumarasi(int sayfaNo);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="yer">1 ise alt, değil ise üst</param>
        /// <param name="yanasik">1 ise sol, 2 ise sağ, değil ise orta</param>
        /// <param name="deger"></param>
        void HFDegerAta(int yer, int yanasik, string deger);

        void SelectSheet(int sheetNo);

        void SelectSheet();

        void ResimEkle(double x, double y, double width, double height, string dosya);

        void ResimEkle(double x, double y, double width, double height, Stream stream);

        object ResimEkle(double x, double y, double width, double height, Stream stream, double left, double top, int enBoyOran, int yanasiklik);

        void DosyaAc(string dosyaAd, string sonucDosya);

        void DosyaAc(string dosyaAd);

        void BosDosyaAc(string sonucDosya);

        void DosyaOkuAc(string dosyaAd);

        void DosyaOkuAc(System.IO.Stream dosyaStream);

        void DosyaSaklaTamYol();

        void DosyaKapat();

        string UzantiBul();

        void YazdirmaYineleme(int sheetNo, string yineleSatir, string yineleSutun);

        void DosyaSaklamaFormatAta(string uzanti);

        void CalculateFormula();

        void HucreFormatla(int satir1, int sutun1, int satir2, int sutun2, string deger);

        void HucreMetniSigdir(int satir1, int sutun1, int satir2, int sutun2, bool deger);

        void HucreMetniSigdir(int satir, int sutun, bool deger);

        void SayfaYonuAta(SayfaYonu sayfaYonu);

        void TekrarlanacakSatirlar(int satir1, int satir2);

        void TekrarlanacakSutunlar(int sutun1, int sutun2);

        void AltaltaSayfaSayisi(int sayfaSayisi);

        void YanyanaSayfaSayisi(int sayfaSayisi);

        void FormulleriSil();

        void Sirala(int order1, int key1, int satir1, int sutun1, int satir2, int sutun2);
    }

    public class HtmlBaglamaSinifi
    {
        string alanAd;
        string format;

        public HtmlBaglamaSinifi(string alanAd, string format)
        {
            this.alanAd = alanAd;
            this.format = format;
        }

        internal string DegerYapObject(object val)
        {
            try
            {
                if (val == null) return "";
                if (val.GetType() == typeof(int))
                {
                    return ((int)val).ToString(format);
                }
                else if (val.GetType() == typeof(double))
                {
                    return ((double)val).ToString(format);
                }
                else if (val.GetType() == typeof(decimal))
                {
                    return ((decimal)val).ToString(format);
                }
                else if (val.GetType() == typeof(TNSDateTime))
                {
                    TNSDateTime dt = (TNSDateTime)val;
                    if (dt.isNull) return "";
                    return dt.Oku().ToString(format);
                }
                else if (val.GetType() == typeof(DateTime))
                {
                    DateTime dt = (DateTime)val;
                    if (dt == DateTime.MinValue) return "";
                    return dt.ToString(format);
                }
                return val.ToString();
            }
            catch { return ""; }
        }

        internal string DegerYapProp(object o)
        {
            try
            {
                if (o == null) return "";
                object val = o.GetType().GetProperty(alanAd).GetValue(o, null);
                return DegerYapObject(val);
            }
            catch { return ""; }
        }

        internal string DegerDegistirProp(string html, object o)
        {
            return html.Replace("{" + alanAd + "}", DegerYapProp(o));
        }

        internal string DegerDegistirObje(string html, object o)
        {
            return html.Replace("{" + alanAd + "}", DegerYapObject(o));
        }

        public static string HTMLBind(string html, TNSCollection objeler, HtmlBaglamaSinifi[] htmlBaglama)
        {
            string sonuc = "";
            if (string.IsNullOrWhiteSpace(html) || objeler == null || htmlBaglama == null) return "";
            foreach (object item in objeler)
            {
                sonuc += HTMLBindProp(html, item, htmlBaglama);
            }
            return sonuc;
        }

        public static string HTMLBindCollectionTablo(string html, ICollection tablo, HtmlBaglamaSinifi[] htmlBaglama)
        {
            string sonuc = "";
            if (string.IsNullOrWhiteSpace(html) || tablo == null || htmlBaglama == null) return "";
            foreach (ICollection item in tablo)
            {
                sonuc += HTMLBindCollectionSatir(html, item, htmlBaglama);
            }
            return sonuc;
        }

        public static string HTMLBindCollectionSatir(string html, ICollection satir, HtmlBaglamaSinifi[] htmlBaglama)
        {
            if (string.IsNullOrWhiteSpace(html) || satir == null || htmlBaglama == null) return "";
            int say = 0;
            foreach (object item in satir)
            {
                html = htmlBaglama[say++].DegerDegistirObje(html, item);
            }
            return html;
        }

        public static string HTMLBindProp(string html, object o, HtmlBaglamaSinifi[] htmlBaglama)
        {
            if (string.IsNullOrWhiteSpace(html) || o == null || htmlBaglama == null) return "";
            for (int i = 0; i < htmlBaglama.Length; i++)
            {
                html = htmlBaglama[i].DegerDegistirProp(html, o);
            }
            return html;
        }
    }

    public class ToplamAl
    {
        int sat;
        int sut;
        public double[,] toplam;

        public string ToplamStr(int sat, int sut, int noktaSay)
        {
            string ek;
            if (noktaSay > 0)
                ek = "." + "00";
            else
                ek = "";
            return toplam[sat, sut].ToString("#,##0" + ek);
        }

        public ToplamAl(int sat, int sut)
        {
            this.sat = sat;
            this.sut = sut;
            toplam = new double[sat, sut];
            HepsiniSifirla();
        }

        public void HepsiniSifirla()
        {
            for (int i = 0; i < sat; i++)
            {
                SatirSifirla(i);
            }
        }

        public void SatirSifirla(int sifirSatir)
        {
            for (int i = 0; i < sut; i++)
            {
                toplam[sifirSatir, i] = 0;
            }
        }

        public void ToplamEkle(int hedefSat, int kaynakSat)
        {
            for (int i = 0; i < sut; i++)
            {
                toplam[hedefSat, i] += toplam[kaynakSat, i];
            }
        }

        public void DegerAta(int sat, int sut, double deger)
        {
            toplam[sat, sut] = deger;
        }

        public void DegerArttir(int sat, int sut, double deger)
        {
            toplam[sat, sut] += deger;
        }

        public int SutunSay()
        {
            return sut;
        }

        public double SatToplamAl(int sat, int basSut, int bitSut)
        {
            double tut = 0;
            for (int i = basSut; i <= bitSut; i++)
            {
                tut += toplam[sat, i];
            }
            return tut;
        }
    }

    public enum EvrakBelgeTur
    {
        //Yeni_Dis_Yazi,
        //Yeni_Ic_Yazi,
        //Yeni_Baskanlik_Onayi,
        //Genelge_Ic,
        //Malzeme_Talep_Fisi,
        //Yaklasik_Maliyet_Hesap_Cetveli,
        //Harcama_Talimati,
        //Ihale_Onay_Belgesi
        SatinAlmaTalepFormu,
        YurtIciGeciciGorevOnayi,
        YurtDisiGeciciGorevOnayi,
        OdemeEmri,
        OdemeEmriOMK,
        MuhasebeIslemFisi,
        BankaOdemeListesi,
        OnMaliKontrolOdeme,
        GeciciGorevBildirimi,
        CesitliOdemeler,
        Tanimsiz
    }

    public class EvrakAktarimNesnesi
    {
        public string DOSYA_ACIKLAMA = ""; //Belge Açıkalama alanı
        public string B_ACIKLAMA = ""; //Belge Açıkalama alanı
        public string B_ANAHTARKELIME = ""; //Belge Anahtarkelimeler alanı
        public string BelgeTur = EvrakBelgeTur.Tanimsiz.ToString();
        public string Belge_Konusu = "";

        public Hashtable BelgeVeri = new Hashtable();

        //string B_Cinsi = "RESMİ YAZI"; //Belge Cinsi alanı
        // oTaslakBelge.B_BGK_AD = "NORMAL"; //Belge Güvenlik Kodu alanı     NORMAL,HİZMETE ÖZEL,ÖZEL,GİZLİ,ÇOK GİZLİ,KİŞİYE ÖZEL
        // oTaslakBelge.B_BI_AD = "NORMAL"; //Belge İvedilik Alanı     NORMAL,ACELE,GÜNLÜDÜR
        //string DosyaPlanKodu = "010.01.00.00"; //Belge Dosya Plan kodu
        // oTaslakBelge.B_HZ_KOD = "GENEL01"; //Belge Hizmet kodu

        // oTaslakBelge.B_TAHMINIBITISTARIHI = DateTime.Now; //Belge süreli ise Tahmini Bitiş tarihi tarih yoksa null değer verilir ya da atama yapılmaz.
        // oTaslakBelge.B_TASLAKADI = "Servisten gelen taslak"; //Taslak olarak kaydedilecekse taslak adı
        // oTaslakBelge.LIST_DOSYA = lsDosyaBilgi;
        // string strKKKs = ""; //Dağıtım olarak eklenecek birim ya da kurumların tekil Kurum Kimlik Numaralarının virgüllü olarak yazılmış durumu. Örnek: 12345678,23456789

        // bool blTaslak = rbtnTaslak.Checked; //Taslak olarak kaydedilecekse true olacak ve kullanıcı taslak belgelerinden erişecektir. False olursa belge bekleyen işlerde iade olarak görünecektir.

        // string pDosyaUzanti = "";
        // if (fuYukle.HasFile)
        // {
        //     FileInfo fi = new FileInfo(fuYukle.FileName);
        //     pDosyaUzanti = fi.Extension;
        // }


        // List<string> lsTNA_IDs = new List<string>();//Form NesneID si
        // List<string> lsTNA_VERIs = new List<string>();//Grilecek Değer

        // //**********Form Verileri*********   oTaslakBelge.B_BT_ID = için hazırlnamış olan form verilerinin ID ve değerleri girilir.
        // //Form verileri yok ise aşağısı kaldırılmalıdır.
        // lsTNA_IDs.Add("389"); //İzin ID - sizin sistemde bize takip için göndereceğiniz ID dir
        // lsTNA_VERIs.Add("1");

        // lsTNA_IDs.Add("364"); //Adı Soyadı
        // lsTNA_VERIs.Add("Murat Kaya");

        // lsTNA_IDs.Add("366"); //Unvan
        // lsTNA_VERIs.Add("Uzm. Yazılımcı");

        // lsTNA_IDs.Add("368"); //Sicil
        // lsTNA_VERIs.Add("32653045");

        // lsTNA_IDs.Add("370"); //Birimi
        // lsTNA_VERIs.Add("Yazılım Birimi");

        // lsTNA_IDs.Add("372"); //İzin Başlama Tarihi
        // lsTNA_VERIs.Add("2015-8-5-00-00-00");

        // lsTNA_IDs.Add("374"); //İzin Bitiş Tarihi
        // lsTNA_VERIs.Add("2015-8-25-00-00-00");

        // lsTNA_IDs.Add("376"); //İletişim Telefonu
        // lsTNA_VERIs.Add("3124963444");

        // lsTNA_IDs.Add("378"); //İznin Geçirileceği Adres(ler)
        // lsTNA_VERIs.Add("Bandırma/Balıkesir");

        // lsTNA_IDs.Add("380"); //Geçerlilik Tarihi
        // lsTNA_VERIs.Add("2015-8-25-00-00-00");

        // lsTNA_IDs.Add("388"); //Geçerlilik Yılı
        // lsTNA_VERIs.Add("2014-2015");

        // lsTNA_IDs.Add("385"); //Geçerli Gün
        // lsTNA_VERIs.Add("18");

        // lsTNA_IDs.Add("387"); //Kullanabileceği İzin Açıklaması
        // lsTNA_VERIs.Add("Kullanabileceği izin süresi 22 gündür. \nYıl içinde Kullandığı İzinler: \nYıllık:3 kez 1 gün \nSağlık Raporları: 2 kez 2 gün \nKayıtlarımıza uygun olup, izin kartına işlenmiştir.");
        //**********Form Verileri*********
    }

    public interface EvrakAktarim
    {
        Sonuc EvrakaDosyaGonder(Kullanici kullanan, string dosyaYolu, EvrakAktarimNesnesi evrakAlanlar);
    }

    public class GenelIslemler
    {
        public static void DosyaGonder(Kullanici kullanan, HttpResponse resp, string modulKod, string formKod, int dosyaNo, bool ekOlarakGonder)
        {
            EkliDosyalar form = new EkliDosyalar();
            form.modul = modulKod;
            form.form = formKod;
            form.dosyaNo = dosyaNo;
            ObjectVAN ed = TNS.KYM.Arac.Tanimla().OkuEkliDosyaIcerik(kullanan, form);
            if (ed.sonuc.islemSonuc && ed.o != null)
            {
                form = (EkliDosyalar)ed.o;

                resp.Clear();

                OrtakClass.GenelIslemler.ResponseBasla(form.dosyaAdi, form.uzanti, ekOlarakGonder);
                //page.Response.AddHeader("Content-Length", form.buyukluk.ToString());
                resp.Flush();
                resp.BinaryWrite(form.ekliDosyaIcerik);
                resp.End();
            }
        }

        public static string YazilimURLBul(HttpRequest req, bool sadeceYol)
        {
            string yazilimURL = OrtakFonksiyonlar.WebConfigOku("yazilimURL", "/");
            if (req != null)
            {
                if (req.IsSecureConnection && yazilimURL.StartsWith("http:")) yazilimURL = yazilimURL.Replace("http:", "https:");
                if (!req.IsSecureConnection && yazilimURL.StartsWith("https:")) yazilimURL = yazilimURL.Replace("https:", "http:");
            }
            if (sadeceYol)
            {
                int length = yazilimURL.LastIndexOf("/");
                if (length > 0) yazilimURL = yazilimURL.Substring(0, length);
            }
            return yazilimURL;
        }

        public static void SizmaBilgiOl(HttpRequest req)
        {
            Kullanici kullanan = OturumBilgisiIslem.KullaniciBilgiOku(false);
            string kulAd;
            if (kullanan != null)
                kulAd = kullanan.kullaniciKodu;
            else
                kulAd = "";
            string metin = String.Format("Tarih:{0}, kulAd:{1}, UserHostAddress:{2}, UserAgent:{3}, UserHostName:{4}, RawUrl:{5}",
                TarihYap(DateTime.Now), kulAd, req.UserHostAddress, req.UserAgent, req.UserHostName, req.RawUrl);
            OrtakFonksiyonlar.HataDosyaYaz("sizma.txt", metin, false);
            OrtakFonksiyonlar.MailAt("", "bilgi@stratek.com.tr", "sizma", metin);
        }

        private static object TarihYap(DateTime now)
        {
            return string.Format("{0:0000}-{1:00}-{2:00} {3:00}:{4:00}:{5:00}.{6:000}", now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second, now.Millisecond);
        }

        static System.Xml.XmlDocument xmlMenu;
        static System.Xml.XmlDocument xmlResmiTatil;
        static System.Xml.XmlElement menuSecenekleri;
        static System.Xml.XmlElement resmiTatiller;

        public static string ExcelAdres(int sutun, int satir)
        {
            return jxl.CellReferenceHelper.getCellReference(sutun, satir);
            //return Aspose.Cells.CellsHelper.CellIndexToName(sutun, satir);
        }

        public static string CollectionDegerAl(TNSCollection col, int indis, string varsayilan)
        {
            if (indis < col.Count)
            {
                object o = col[indis];
                if (o.GetType() == typeof(string)) return (string)o;
                else return o.ToString();
            }
            return varsayilan;
        }

        public static int JexcelBirimtoExcelBirimCol(int uzunluk)
        {
            if (ExcelTur() == "xlsx")
                return uzunluk * 900;
            else
                return uzunluk;
        }

        public static int JexcelBirimtoExcelBirim(int uzunluk)
        {
            if (ExcelTur() == "xlsx")
                return uzunluk * 53;
            else
                return uzunluk;
        }

        public static string ExcelTur()
        {
            return "xlsx";
        }

        public static Tablo NewTablo()
        {
            if (ExcelTur() == "xlsx")
                return new TabloAspose();
            else
                return new TabloJ();
        }

        public static EvrakAktarim EvrakAktarimOl()
        {
            // create an instance of the object
            System.Runtime.Remoting.ObjectHandle oh = Activator.CreateInstance("UAEvrakAktar", "TNS.EvrakAktar");
            if (oh != null)
            {
                return (EvrakAktarim)oh.Unwrap();
            }
            throw new Exception("UAEvrakAktar dosyası bulunamadı!");
        }

        static GenelIslemler()
        {
            xmlMenu = new XmlDocument();
            string xmlYolDosya = System.Configuration.ConfigurationManager.AppSettings.Get("MenuXML");
            if (!string.IsNullOrEmpty(xmlYolDosya))
            {
                xmlMenu.Load(xmlYolDosya);
                menuSecenekleri = xmlMenu["Nodes"];
            }
            else
                menuSecenekleri = null;
        }

        public static TNSDateTime IlkCalismaGununuVer(TNSDateTime tarih, bool kontrolYap = true)
        {
            return TNS.ResmiTatil.IlkCalismaGununuVer(tarih, kontrolYap);
        }

        public static bool ResmiTatilMi(TNSDateTime tarih, bool haftaSonunuResmiTatilKabulEt = true)
        {
            return TNS.ResmiTatil.ResmiTatilMi(tarih, haftaSonunuResmiTatilKabulEt ? 0 : 1);
        }

        /// <summary>
        /// Verilen yeni ve eski değerlere göre değişim oranını bulan yordam.
        /// </summary>
        /// <param name="yeni">Değişim oranı bulunacak iki değerden yenisi</param>
        /// <param name="eski">Değişim oranı bulunacak iki değerden eskisi(bölen)</param>
        /// <returns>Değişim oranı dizgi olarak döndürülür.</returns>
        public static string DegisimOranBulStr(double yeni, double eski)
        {
            return YuzdeBulStr(yeni - eski, eski);
        }

        /// <summary>
        /// Verilen yeni ve eski değerlere göre değişim oranını bulan yordam.
        /// </summary>
        /// <param name="yeni">Değişim oranı bulunacak iki değerden yenisi</param>
        /// <param name="eski">Değişim oranı bulunacak iki değerden eskisi(bölen)</param>
        /// <returns>Değişim oranı döndürülür.</returns>
        public static double DegisimOranBul(double yeni, double eski)
        {
            return YuzdeBul(yeni - eski, eski);
        }

        /// <summary>
        /// Tüm içerisindeki miktarın yüzde oranını bulan yordam.
        /// </summary>
        /// <param name="miktar">Yüzdesi bulanacak miktar</param>
        /// <param name="tum">Yüzdesi bulanacak miktarın, bulunduğu kümenin tümünün miktarı (bölen)</param>
        /// <returns>Yüzde oranı dizgi olarak döndürülür.</returns>
        public static string YuzdeBulStr(double miktar, double tum)
        {
            if (tum == 0) return "-";
            else return ((miktar / tum) * 100).ToString("#,##0.00");
        }

        /// <summary>
        /// Tüm içerisindeki miktarın yüzde oranını bulan yordam.
        /// </summary>
        /// <param name="miktar">Yüzdesi bulanacak miktar</param>
        /// <param name="tum">Yüzdesi bulanacak miktarın, bulunduğu kümenin tümünün miktarı (bölen)</param>
        /// <returns>Hesaplanan oran döndürülür.</returns>
        public static double YuzdeBul(double miktar, double tum)
        {
            if (tum == 0) return -1;
            else return ((miktar / tum) * 100);
        }

        public static string KaynakOku(System.Resources.ResourceManager rm, string anahtar)
        {
            string tut = rm.GetString(anahtar);
            if (string.IsNullOrEmpty(tut))
                return "KAYNAK:" + anahtar;
            else
                return tut;
        }

        public static string AyAdDondur(int ay)
        {
            if (ay < 1 || ay > 12)
                return "";
            else

                return OrtakClassRes.ResourceManager.GetString("ORTAY" + ay.ToString("00"));
        }

        public static string GunAdDondur(int gun)
        {
            if (gun < 0 || gun > 6)
                return "";
            else

                return OrtakClassRes.ResourceManager.GetString("ORTGUN" + gun.ToString("00"));
        }

        public static Sonuc DosyaSil(string kayitYol, string dosyaAd)
        {
            Sonuc sonuc = new Sonuc();
            if (!string.IsNullOrEmpty(dosyaAd))
            {
                try
                {
                    System.IO.File.Delete(kayitYol + dosyaAd);
                }
                catch (Exception err)
                {
                    sonuc.islemSonuc = false;
                    sonuc.hataStr = err.Message;
                    return sonuc;
                }
            }
            return sonuc;
        }

        public static string HataBilgisiniDuzYaziYap(string hataStr)
        {
            string mesajHata = "";

            if (hataStr.Trim().StartsWith("<br>"))
                hataStr = hataStr.Substring(4, hataStr.Length - 4);

            string[] mesajHataStr;
            hataStr = hataStr.Replace("\r", "");
            hataStr = hataStr.Replace("\n", "");
            hataStr = hataStr.Replace("<br>", "|");
            mesajHataStr = hataStr.Split('|');
            for (int i = 0; i < mesajHataStr.Length; i++)
                if (mesajHataStr[i].Trim() != "")
                    mesajHata += "* " + mesajHataStr[i] + "\\r\\n";

            mesajHata = mesajHata.Replace("<b>", "");
            mesajHata = mesajHata.Replace("</b>", "");
            mesajHata = mesajHata.Replace("<li>", "\\r\\n  # ");
            mesajHata = mesajHata.Replace("</li>", "");
            mesajHata = mesajHata.Replace("'", "");

            return mesajHata;
        }

        public static string HataBilgisiniHMTLYap(string hataStr)
        {
            hataStr = hataStr.Replace("'", "");
            hataStr = hataStr.Replace("\r\n", "<br>");
            hataStr = hataStr.Replace("\n", "<br>");
            hataStr = hataStr.Replace("<br/>", "<br>");
            hataStr = hataStr.Replace("<br />", "<br>");

            return hataStr;
        }

        public static string TurkcedenHTML(string deger)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder("");
            foreach (char item in deger)
            {
                sb.Append(TurkcedenHTMLChar(item));
            }
            return sb.ToString();
        }

        public static string TurkcedenHTMLChar(char gelen)
        {
            if (gelen == 'İ') return "&#304;";
            if (gelen == 'ı') return "&#305;";
            if (gelen == 'Ö') return "&#214;";
            if (gelen == 'ö') return "&#246;";
            if (gelen == 'Ü') return "&#220;";
            if (gelen == 'ü') return "&#252;";
            if (gelen == 'Ç') return "&#199;";
            if (gelen == 'ç') return "&#231;";
            if (gelen == 'Ğ') return "&#286;";
            if (gelen == 'ğ') return "&#287;";
            if (gelen == 'Ş') return "&#350;";
            if (gelen == 'ş') return "&#351;";
            if (gelen == '₤') return "&#8356;";
            if (gelen == (char)0xA0) return "&nbsp;";
            if (gelen == '…') return "&#x2026;";

            return gelen.ToString();
        }


        public static string TurkceleUTF8(string deger)
        {
            deger = deger.Replace("Ä", "Ğ");
            deger = deger.Replace("Ãœ", "Ü");
            deger = deger.Replace("Å", "Ş");
            deger = deger.Replace("Ä°", "İ");
            deger = deger.Replace("Ã–", "Ö");
            deger = deger.Replace("Ã‡", "Ç");
            deger = deger.Replace("ÄŸ", "ğ");
            deger = deger.Replace("Ã¼", "ü");
            deger = deger.Replace("ÅŸ", "ş");
            deger = deger.Replace("Ä±", "ı");
            deger = deger.Replace("Ã¶", "ö");
            deger = deger.Replace("Ã§", "ç");

            return deger;
        }

        public static string TurkceleRTF(string deger)
        {
            deger = deger.Replace(@"\'d0", "Ğ");
            deger = deger.Replace(@"\'dc", "Ü");
            deger = deger.Replace(@"\'de", "Ş");
            deger = deger.Replace(@"\'dd", "İ");
            deger = deger.Replace(@"\'d6", "Ö");
            deger = deger.Replace(@"\'c7", "Ç");
            deger = deger.Replace(@"\'f0", "ğ");
            deger = deger.Replace(@"\'fc", "ü");
            deger = deger.Replace(@"\'fe", "ş");
            deger = deger.Replace(@"\'fd", "ı");
            deger = deger.Replace(@"\'f6", "ö");
            deger = deger.Replace(@"\'e7", "ç");

            return deger;
        }

        public static string RTFKodla(string deger)
        {
            if (deger == null) return deger;

            deger = deger.Replace("Ğ", @"\'d0");
            deger = deger.Replace("Ü", @"\'dc");
            deger = deger.Replace("Ş", @"\'de");
            deger = deger.Replace("İ", @"\'dd");
            deger = deger.Replace("Ö", @"\'d6");
            deger = deger.Replace("Ç", @"\'c7");
            deger = deger.Replace("ğ", @"\'f0");
            deger = deger.Replace("ü", @"\'fc");
            deger = deger.Replace("ş", @"\'fe");
            deger = deger.Replace("ı", @"\'fd");
            deger = deger.Replace("ö", @"\'f6");
            deger = deger.Replace("ç", @"\'e7");

            return deger;
        }

        public static string TurkceYok(string deger)
        {
            deger = deger.Replace("Ğ", "\\'d0");
            deger = deger.Replace("Ü", "\\'dc");
            deger = deger.Replace("Ş", "\\'de");
            deger = deger.Replace("İ", "\\'dd");
            deger = deger.Replace("Ö", "\\'d6");
            deger = deger.Replace("Ç", "\\'c7");
            deger = deger.Replace("ğ", "\\'f0");
            deger = deger.Replace("ü", "\\'fc");
            deger = deger.Replace("ş", "\\'fe");
            deger = deger.Replace("ö", "\\'f6");
            deger = deger.Replace("ç", "\\'e7");
            deger = deger.Replace("ı", "\\'fd");

            return deger;
        }

        public static string TurkceleAJAX(string deger)
        {
            deger = deger.Replace("C|", "Ç");
            deger = deger.Replace("U|", "Ü");
            deger = deger.Replace("O|", "Ö");
            deger = deger.Replace("c|", "ç");
            deger = deger.Replace("u|", "ü");
            deger = deger.Replace("o|", "ö");

            return deger;
        }

        public static KullaniciVAN MernisOku(Kullanici kullanan, string tcKimlikNo, TNSDateTime dogumTarih)
        {
            return TNS.KYM.Arac.Tanimla().MernisBilgiOku(kullanan, tcKimlikNo, dogumTarih);
        }

        public static string UzayKosulOl(params string[] args)
        {
            string donusDeger = "";
            for (int i = 0; i < args.Length; i++)
            {
                if (i != 0)
                    donusDeger += "-";
                donusDeger += args[i];
            }
            return donusDeger;
        }

        public static void KullaniciAsamaSakla(Kullanici kullanici, string asama)
        {
            KullaniciDegiskenSakla(kullanici, "ASAMA", asama);
        }

        public static void KullaniciDegiskenSakla(Kullanici kullanici, string degiskenAd, TNSCollection degListesi)
        {
            if (kullanici != null)
            {
                IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();
                Sonuc sonuc = kullanici.DegiskenleriSakla(servisKYM, degiskenAd, degListesi);
                //if (sonuc.islemSonuc)
                //    OturumBilgisiIslem.BilgiYazDegisken("kullanan", kullanici);
            }
        }

        public static void KullaniciDegiskenSakla(Kullanici kullanici, string degiskenAd, string degisken)
        {
            TNSCollection degListesi = new TNSCollection();
            degListesi.Add(degisken);
            KullaniciDegiskenSakla(kullanici, degiskenAd, degListesi);
        }

        public static string KullaniciDegiskenGetir(string kullanici, string degiskenAd)
        {
            TNSCollection kDeg = null;
            IKYMServis servisKYM = null;
            if (!string.IsNullOrEmpty(kullanici))
            {
                try
                {
                    servisKYM = TNS.KYM.Arac.Tanimla();
                }
                catch
                {
                    return "";
                }

                if (kullanici.Length == 11 && OrtakFonksiyonlar.ConvertToLong(kullanici) > 0)
                {
                    Kullanici tmpKullanici = new Kullanici();
                    tmpKullanici.kullaniciTipi = new ENUMKullaniciTipi[1];
                    tmpKullanici.kullaniciTipi[0] = ENUMKullaniciTipi.SISTEMYONETICISI;

                    KullaniciVAN kVAN = servisKYM.KullaniciOku(tmpKullanici, kullanici);
                    if (kVAN.sonuc.islemSonuc && kVAN.kullanici != null)
                    {
                        if (kVAN.kullanici.kullaniciKodu != "") kullanici = kVAN.kullanici.kullaniciKodu;
                    }
                }

                kDeg = servisKYM.DegiskenleriListele(kullanici, degiskenAd);
            }
            if (kDeg != null && kDeg.Count > 0)
                return kDeg[0].ToString();
            else
                return "";
        }

        public static TNSCollection KullaniciDegiskenleriGetir(string kullanici, string degisken)
        {
            if (!string.IsNullOrEmpty(kullanici))
            {
                IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();

                return servisKYM.DegiskenleriListele(kullanici, degisken);
            }
            return new TNSCollection();
        }

        //public static Hashtable KullaniciDegiskenleriGetir(string kullanici, string degisken)
        //{
        //    Hashtable degListesi = new Hashtable();

        //    if (!string.IsNullOrEmpty(kullanici))
        //    {
        //        IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();
        //        degListesi = servisKYM.DegiskenleriListele(kullanici, degisken);
        //    }
        //    return degListesi;
        //}

        public static string KodAd(int kodTur, string kosul, bool esitle)
        {
            TNS.KYM.Kullanici kullanan = new TNS.KYM.Kullanici();
            IUZYServis servisUZY = TNS.UZY.Arac.Tanimla();

            string ad = "";
            string uzayAd = "";
            string uzayAlan = null;

            string uzayAd2 = null;
            string uzayAlan2 = null;
            string kosul2 = null;

            if (kodTur == 1)
                uzayAd = "ABSKUR";
            else if (kodTur == 2)
                uzayAd = "ABSFON";
            else if (kodTur == 3)
                uzayAd = "ABSFIN";
            else if (kodTur == 4)
                uzayAd = "ABSEKO";
            else if (kodTur == 5)
                uzayAd = "ABSGELIRKOD";
            else if (kodTur == 6)
                uzayAd = "ABSFINANSMANKOD";
            else if (kodTur == 11)
            {
                uzayAd = "MUHMUHASEBE";
                uzayAlan = "MUHASEBEAD";
            }
            else if (kodTur == 12)
            {
                uzayAd = "MUHMUHASEBEBIRIM";
                uzayAlan = "BIRIMAD";
            }
            else if (kodTur == 13)
            {
                uzayAd = "MUHHESAPPLANI";
                uzayAlan = "ACIKLAMA";
            }
            else if (kodTur == 14)
            {
                uzayAd = "KTPYAYINLAYAN";
                uzayAlan = "AD";
            }
            else if (kodTur == 15)
            {
                uzayAd = "KTPKONU";
                uzayAlan = "AD";
            }
            else if (kodTur == 16)
            {
                uzayAd = "PERPERSONEL";
                uzayAlan = "AD+' '+SOYAD";
            }
            else if (kodTur == 17)
            {
                uzayAd = "KTPYAZAR";
                uzayAlan = "AD";
            }
            else if (kodTur == 18)
            {
                uzayAd = "KTPUYE";
                uzayAlan = "AD+' '+SOYAD";
            }
            else if (kodTur == 19)
                uzayAd = "YATPROJETUR";
            else if (kodTur == 20)
                uzayAd = "YATSEKTOR";
            else if (kodTur == 21)
                uzayAd = "PERBANKASUBE";
            else if (kodTur == 22)
                uzayAd = "PERUNVAN";
            else if (kodTur == 23)
                uzayAd = "YATPROJE";
            else if (kodTur == 24)
                uzayAd = "YATIL";
            else if (kodTur == 25)
                uzayAd = "YATILCE";
            else if (kodTur == 26)
                uzayAd = "KTPYAYIN";
            else if (kodTur == 27)
                uzayAd = "YATBUTCEKAYNAK";
            else if (kodTur == 28)
                uzayAd = "ATMFAIZTUR";
            else if (kodTur == 29)
                uzayAd = "YATALTPROJE";
            else if (kodTur == 30)
                uzayAd = "TASHESAPPLAN";
            else if (kodTur == 31)
                uzayAd = "TASMUHASEBE";
            else if (kodTur == 32)
                uzayAd = "TASHARCAMABIRIM";
            else if (kodTur == 33)
                uzayAd = "TASAMBAR";
            else if (kodTur == 34)
                uzayAd = "TASOLCUBIRIMAD";
            else if (kodTur == 35)
                uzayAd = "TASODA";
            else if (kodTur == 36)
                uzayAd = "TASPERSONEL";
            else if (kodTur == 37)
                uzayAd = "TASMARKA";
            else if (kodTur == 38)
                uzayAd = "TASMODEL";
            else if (kodTur == 39)
                uzayAd = "PERADSOYADUNVAN";
            else if (kodTur == 40)
                uzayAd = "STRYAZI";
            else if (kodTur == 41)
                uzayAd = "PEBPERHEDEF";
            else if (kodTur == 42)
                uzayAd = "PEBFAALIYETPROJE";
            else if (kodTur == 43)
                uzayAd = "STRHEDEFAMACKOD";
            else if (kodTur == 44)
                uzayAd = "TASBOLGE";
            else if (kodTur == 45)
                uzayAd = "PEBGOSTERGE";
            else if (kodTur == 46)
                uzayAd = "PEBGOSTERGEOLCU";
            else if (kodTur == 47)
                uzayAd = "HRCIS";
            else if (kodTur == 48)
                uzayAd = "PEBALTFAALIYET";
            else if (kodTur == 49)
                uzayAd = "HRCIL";
            else if (kodTur == 50)
                uzayAd = "PEBSABITMALIYET";
            else if (kodTur == 51)
                uzayAd = "HRCPARCA";
            else if (kodTur == 52)
                uzayAd = "BHMKURUMSALYAPI";
            else if (kodTur == 53)
            {
                string[] kosulList = kosul.Split('.');
                uzayAd = "BHMKURUMSALYAPI";
                if (kosulList.Length == 4)
                    return servisUZY.UzayDegeriStr(kullanan, uzayAd, kosul, esitle, uzayAlan) + "(" + servisUZY.UzayDegeriStr(kullanan, uzayAd, kosulList[0] + "." + kosulList[1] + "." + kosulList[2], esitle, uzayAlan) + ")";
                else
                    return servisUZY.UzayDegeriStr(kullanan, uzayAd, kosul, esitle, uzayAlan);
                //kosul = "";
                //for (int i = 0; i < kosulList.Length; i++)
                //{
                //    kosul += kosulList[i];
                //    if (i != kosulList.Length - 1)
                //    {
                //        ad += servisUZY.UzayDegeriStr(kullanan, uzayAd, kosul, esitle, uzayAlan);
                //        if (i != kosulList.Length - 2)
                //            ad += " - ";
                //    }
                //    else
                //    {
                //        if (!string.IsNullOrEmpty(ad))
                //            ad = " (" + ad + ")";
                //        ad = servisUZY.UzayDegeriStr(kullanan, uzayAd, kosul, esitle, uzayAlan) + ad;
                //    }
                //}
                //return ad;
            }
            else if (kodTur == 56)
            {
                bool orgSemaEvrakKullaniyorMu = OrtakFonksiyonlar.ConvertToInt(TNS.DEG.Arac.DegiskenDegerBulCache(0, "/OrgSemaEvrak"), 0) > 0 ? true : false;
                uzayAd = (orgSemaEvrakKullaniyorMu) ? "ORGEVRAKBIRIM" : "EVRBIRIM";
            }
            else if (kodTur == 57)
            {
                uzayAd = "EVRDOSYAPLANI";
                kosul = kosul.Replace("-", "");
            }
            else if (kodTur == 58)
            {
                uzayAd = "ABSPEBKOD";
            }
            else if (kodTur == 59)
            {
                uzayAd = "HRCFIRMABILGISI";
                uzayAd2 = "PERPERSONEL";
                uzayAlan2 = "AD+' '+SOYAD";
                kosul2 = OrtakFonksiyonlar.DiziElemanAl(kosul.Split('-'), 0, kosul);
            }
            else if (kodTur == 60)
            {
                string[] kosullar = kosul.Split('-');
                if (kosullar.Length != 4)
                    return "";
                if (string.IsNullOrEmpty(kosullar[0]) || string.IsNullOrEmpty(kosullar[1]) || string.IsNullOrEmpty(kosullar[2]) || string.IsNullOrEmpty(kosullar[3]))
                    return "";
                kosul = kosullar[0] + "-" + kosullar[1] + "-" + kosullar[3];
                if (kosullar[2].Equals("S", StringComparison.CurrentCultureIgnoreCase))
                    uzayAd = "PEBSABITMALIYET";
                else if (kosullar[2].Equals("F", StringComparison.CurrentCultureIgnoreCase))
                    uzayAd = "PEBFAALIYETPROJE";
                else
                    return "";
            }
            else if (kodTur == 61)
            {
                uzayAd = "YATBUTCEKAYNAK";
                uzayAlan = "STR(KAYNAKTUR) + '-' + KAYNAKAD";
            }

            ad = servisUZY.UzayDegeriStr(kullanan, uzayAd, kosul, esitle, uzayAlan);

            if (string.IsNullOrWhiteSpace(ad) && !string.IsNullOrWhiteSpace(uzayAd2))
            {
                ad = servisUZY.UzayDegeriStr(kullanan, uzayAd2, kosul2, esitle, uzayAlan2);
            }
            return ad.Replace(",", " ");
        }

        public static int KurusBul(double para)
        {
            return (int)(((long)Math.Round(para * 100)) % 100);
        }

        public static void HTMLWordLandScapeSytle(TextWriter o_s)
        {
            //System.IO.Stream s=null;
            //s.Write 
            //
            //
            //System.Web.HttpContext.Current.Response
            //if (o_s.GetType() == typeof(TextWriter))
            //{
            TextWriter s = (TextWriter)o_s;
            s.Write("\r\n<style>\r\n");
            s.Write("<!--\r\n");
            s.Write("p.MsoNormal, li.MsoNormal, div.MsoNormal\r\n");
            s.Write("{mso-style-parent:'';\r\n");
            s.Write("margin:0cm;\r\n");
            s.Write("margin-bottom:.0001pt;\r\n");
            s.Write("mso-pagination:widow-orphan;\r\n");
            s.Write("font-size:12.0pt;\r\n");
            s.Write("font-family:'Times New Roman';\r\n");
            s.Write("mso-fareast-font-family:'Times New Roman';}\r\n");
            s.Write("@page Section1\r\n");
            s.Write("{size:841.9pt 595.3pt;\r\n");
            s.Write("mso-page-orientation:landscape;\r\n");
            s.Write("margin:70.9pt 70.9pt 70.9pt 70.9pt;\r\n");
            s.Write("mso-header-margin:35.45pt;\r\n");
            s.Write("mso-footer-margin:35.45pt;\r\n");
            s.Write("mso-paper-source:0;}\r\n");
            s.Write("div.Section1\r\n");
            s.Write("{page:Section1;}\r\n");
            s.Write("-->\r\n");
            s.Write("</style>\r\n");
            //}
            //else
            //{
            //    System.IO.StreamWriter s = (System.IO.StreamWriter)o_s;
            //    s.Write("\r\n<style>\r\n");
            //    s.Write("<!--\r\n");
            //    s.Write("p.MsoNormal, li.MsoNormal, div.MsoNormal\r\n");
            //    s.Write("{mso-style-parent:'';\r\n");
            //    s.Write("margin:0cm;\r\n");
            //    s.Write("margin-bottom:.0001pt;\r\n");
            //    s.Write("mso-pagination:widow-orphan;\r\n");
            //    s.Write("font-size:12.0pt;\r\n");
            //    s.Write("font-family:'Times New Roman';\r\n");
            //    s.Write("mso-fareast-font-family:'Times New Roman';}\r\n");
            //    s.Write("@page Section1\r\n");
            //    s.Write("{size:841.9pt 595.3pt;\r\n");
            //    s.Write("mso-page-orientation:landscape;\r\n");
            //    s.Write("margin:70.9pt 70.9pt 70.9pt 70.9pt;\r\n");
            //    s.Write("mso-header-margin:35.45pt;\r\n");
            //    s.Write("mso-footer-margin:35.45pt;\r\n");
            //    s.Write("mso-paper-source:0;}\r\n");
            //    s.Write("div.Section1\r\n");
            //    s.Write("{page:Section1;}\r\n");
            //    s.Write("-->\r\n");
            //    s.Write("</style>\r\n");
            //}
        }

        public static byte[] Compress(byte[] data)
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            DeflateStream stream = new DeflateStream(ms, CompressionMode.Compress);
            stream.Write(data, 0, data.Length);
            stream.Close();
            return ms.ToArray();
        }

        public static byte[] Decompress(byte[] data)
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            ms.Write(data, 0, data.Length);
            ms.Position = 0;
            DeflateStream stream = new DeflateStream(ms, CompressionMode.Decompress);
            System.IO.MemoryStream temp = new System.IO.MemoryStream();
            byte[] buffer = new byte[1024];

            while (true)
            {
                int read = stream.Read(buffer, 0, buffer.Length);
                if (read <= 0)
                {
                    break;
                }
                else
                {
                    temp.Write(buffer, 0, buffer.Length);
                }
            }
            stream.Close();
            return temp.ToArray();
        }

        public static string TirnakliParam(bool ciftTirnak, bool onceBosluk, string param, string deger)
        {
            if (string.IsNullOrEmpty(deger)) return "";
            if (string.IsNullOrEmpty(param)) return "";
            string bosluk;
            string tirnak;
            if (onceBosluk) bosluk = " ";
            else bosluk = "";

            if (ciftTirnak) tirnak = "\"";
            else tirnak = "'";

            return bosluk + param + "=" + tirnak + deger + tirnak;

        }

        public static string Tirnakla(string param, int tekCiftYokTirnak, bool virgulle)
        {
            string tirnak, retVal;
            if (tekCiftYokTirnak == 1) tirnak = "'";
            else if (tekCiftYokTirnak == 2) tirnak = "\"";
            else tirnak = "";

            retVal = tirnak + param + tirnak;
            if (virgulle)
                retVal += ", ";
            return retVal;
        }

        public static Kullanici SabitKullanici(string kullaniciKod, ENUMKullaniciTipi kulTip)
        {
            Kullanici kullanici = new Kullanici();
            kullanici.ad = kullaniciKod;
            kullanici.aktifMi = TNS.KYM.ENUMAktiflik.AKTIF;
            kullanici.anaAdi = "anaAdi";
            kullanici.aramadaGosterme = 0;
            kullanici.babaAdi = "babaAdi";
            kullanici.calistigiBirim = "calistigiBirim";
            kullanici.calistigiKurum = "calistigiKurum";
            kullanici.cinsiyet = "E";
            kullanici.dogumTarihi = new TNS.TNSDateTime("19.06.1967");
            kullanici.emailAdresi = "deneme@manav.com";
            kullanici.kullaniciKodu = kullaniciKod;
            kullanici.kullaniciTipi = new ENUMKullaniciTipi[1];
            kullanici.kullaniciTipi[0] = kulTip;
            kullanici.mernis = "11111111111";
            kullanici.parola = "parola";
            kullanici.parolaBitisTarihi = new TNS.TNSDateTime("19.06." + (DateTime.Now.Year + 1).ToString());
            kullanici.sicilNo = "sicilNo";
            kullanici.sonGirisTarihi = new TNS.TNSDateTime(DateTime.Now);
            kullanici.soyad = "soyad";
            kullanici.telefon = "41";
            kullanici.unvan = "unvan";
            // kullanici.yetkiTipiDegerleri = new System.Collections.Hashtable();
            return kullanici;
        }

        public static bool GormeYetkisiVarMi(Kullanici kullanan, string birim, int asama)
        {
            //IBHMServis servisBHM = ServisFabrikasi.TanimlaBHM();

            //return servisBHM.GormeYetkisiVarMi(kullanan, asama, birim).islemSonuc;
            return true;
        }

        public static bool GormeYetkisiVarMi(Kullanici kullanan, string birim, string senaryo)
        {
            //IBHMServis servisBHM = ServisFabrikasi.TanimlaBHM();

            //return servisBHM.GormeYetkisiVarMi(kullanan, asama, birim).islemSonuc;
            return true;
        }

        public static bool GormeYetkisiVarMiUygulama(int yil, Kullanici kullanan, string birim, int asama)
        {
            //IBUMServis servisBUM = ServisFabrikasi.TanimlaBUM();

            //return servisBUM.GormeYetkisiVarMi(kullanan, yil, birim, asama);
            return true;
        }

        public static string WebConfigOku(string anahtar, string bulunamadiDeger)
        {
            string deger = "";
            try
            {
                deger = System.Configuration.ConfigurationManager.AppSettings.Get(anahtar);
                if (String.IsNullOrEmpty(deger))
                    deger = bulunamadiDeger;

            }
            catch (Exception e)
            {
                TNS.OrtakFonksiyonlar.HataStrYaz("Anahtar:" + anahtar + " - GenelIslemler.WebConfigOku hata verdi" + e.StackTrace);
            }
            return deger;
        }

#if !MU
        public static Sonuc DosyaKaydet(FileUpload kontrol, string kayitYol, bool ustuneYaz)
        {
            Sonuc sonuc = new Sonuc();
            if (kontrol.HasFile)
            {
                try
                {
                    if (!ustuneYaz)
                    {
                        if (System.IO.File.Exists(kayitYol + kontrol.FileName))
                        {
                            sonuc.hataStr = OrtakClassRes.ORT001;
                            sonuc.islemSonuc = false;
                            return sonuc;
                        }
                    }

                    System.IO.Directory.CreateDirectory(kayitYol);
                    kontrol.PostedFile.SaveAs(kayitYol + kontrol.FileName);
                }
                catch (Exception err)
                {
                    sonuc.islemSonuc = false;
                    sonuc.hataStr = err.Message;
                    return sonuc;
                }
            }
            return sonuc;
        }

        public static Sonuc DosyaKaydet(FileUpload kontrol, string kayitYol, string eskiDosya)
        {
            Sonuc sonuc = new Sonuc();
            if (kontrol.HasFile)
            {
                try
                {
                    System.IO.Directory.CreateDirectory(kayitYol);
                    kontrol.PostedFile.SaveAs(kayitYol + kontrol.FileName);
                }
                catch (Exception err)
                {
                    sonuc.islemSonuc = false;
                    sonuc.hataStr = err.Message;
                    return sonuc;
                }

                if (!string.IsNullOrEmpty(eskiDosya) && eskiDosya != kontrol.FileName)
                {
                    try
                    {
                        System.IO.File.Delete(kayitYol + eskiDosya);
                    }
                    catch (Exception err)
                    {
                        sonuc.islemSonuc = false;
                        sonuc.hataStr = err.Message;
                        return sonuc;
                    }
                }
            }
            return sonuc;
        }

        public static void HataYaz(System.Web.UI.Page p, string hataStr)
        {
            //HataYaz(p, hataStr, false);
            MesajKutusu(p, hataStr);
        }

        public static void HataYaz(System.Web.UI.Page p, string hataStr, bool vtHatasi)
        {
            //p.ClientScript.RegisterStartupScript(p.GetType(), "hataYaz", "hataYaz('" + HataBilgisiniDuzYaziYap(hataStr) + "');", true);

            //Hatayı mesaj kutusu olarak göstermek için
            //*********************************************
            string mesajHata = OrtakClassRes.ORT002 + "\\r\\n\\r\\n";

            mesajHata = mesajHata + HataBilgisiniDuzYaziYap(hataStr);

            if (vtHatasi)
                GenelIslemler.MesajKutusu(p, OrtakClassRes.ORT003);

            //*********************************************

            if (vtHatasi)
                hataStr = "<a href='#' onclick=\"JavaScript:if(document.getElementById('divGizliHata').style.display=='none') {document.getElementById('divGizliHata').style.display = 'block';} else {document.getElementById('divGizliHata').style.display = 'none';}return false;\"><img src='../app_themes/images/infohata.gif'>&nbsp;Oluşan hatanın detayını görmek için buraya tıklayın.</a><div id='divGizliHata' style='display:none'>" + hataStr + "</div>";
            HttpContext.Current.Session["BilgiSatiri"] = hataStr;

            Label ctl2 = (Label)p.FindControl("lblHata");
            if (ctl2 != null)
            {
                ctl2.Visible = true;
                System.IO.StringWriter sw = new System.IO.StringWriter();
                bool sayfaYok = false;
                try
                {
                    p.Server.Execute("../OrtakSayfa/Hata.aspx", sw);
                }
                catch
                {
                    try
                    {
                        p.Server.Execute("~/OrtakSayfa/Hata.aspx", sw);
                    }
                    catch
                    {
                        sayfaYok = true;
                    }
                }
                sw.Close();
                string yazStr;
                if (sayfaYok)
                    yazStr = "[HATA] " + hataStr;
                else
                    yazStr = sw.ToString();
                ctl2.Text = yazStr;
            }
            HttpContext.Current.Session["BilgiSatiri"] = "";
        }

        public static void BilgiYaz(System.Web.UI.Page p, string hataStr)
        {
            //p.ClientScript.RegisterStartupScript(p.GetType(), "bilgiYaz", "bilgiYaz('" + HataBilgisiniDuzYaziYap(hataStr) + "');", true);
            MesajKutusu(p, hataStr);

            //HttpContext.Current.Session["BilgiSatiri"] = hataStr;

            //foreach (System.Web.UI.Control ctl in p.Controls)
            //{
            //    foreach (System.Web.UI.Control ctl2 in ctl.Controls)
            //    {
            //        if (ctl2.ID == "lblHata")
            //        {
            //            ((Label)ctl2).Visible = true;
            //            System.IO.StringWriter sw = new System.IO.StringWriter();
            //            bool sayfaYok = false;
            //            try
            //            {
            //                p.Server.Execute("../OrtakSayfa/Hata.aspx?bilgi=1", sw);
            //            }
            //            catch (Exception)
            //            {
            //                sayfaYok = true;
            //            }
            //            sw.Close();
            //            string yazStr;
            //            if (sayfaYok)
            //                yazStr = "[BİLGİ] " + hataStr;
            //            else
            //                yazStr = sw.ToString();
            //            ((Label)ctl2).Text = yazStr;
            //            ((Label)ctl2).Visible = true;
            //            break;
            //        }
            //    }
            //}
        }

        public static void MesajKutusuEski(System.Web.UI.Page p, string mesaj)
        {
            p.ClientScript.RegisterStartupScript(p.GetType(), "mesajKutusu", "$(document).ready(function () {mesajKutusu('" + HataBilgisiniHMTLYap(mesaj) + "');});", true);
        }

        public static void MesajKutusu(System.Web.UI.Page p, string mesaj)
        {
            MesajKutusu(p.Title, mesaj);
        }

        public static void MesajKutusu(string baslik, string mesaj)
        {
            //Ext1.Net.X.MessageBox.Alert(baslik, mesaj).Show();
            Ext1.Net.X.AddScript("window.top.Ext1.Msg.alert('" + baslik + "','" + HataBilgisiniHMTLYap(mesaj) + "');");
        }

        public static void ExtNotification(string msg, string title, Ext1.Net.Icon icon, bool top = false)
        {
            if (icon == Ext1.Net.Icon.Error)
                msg = "<font color='red'>" + msg + "</font>";
            if (top)
                Ext1.Net.X.AddScript("window.top.Ext1.net.Notification.show({iconCls : 'icon-information',hideDelay : 4000,pinEvent  : 'click',html      : '" + msg + "',title     : '" + title + "'});");
            else
                Ext1.Net.Notification.Show(new Ext1.Net.NotificationConfig() { Icon = icon, HideDelay = 4000, PinEvent = "click", Html = msg, Title = title });
        }

        public static void ExtNotificationV3(string msg, string title, Ext.Net.Icon icon, bool top = false)
        {
            if (icon == Ext.Net.Icon.Error)
                msg = "<font color='red'>" + msg + "</font>";
            if (top)
                Ext.Net.X.AddScript("window.top.Ext.net.Notification.show({iconCls : 'icon-information',hideDelay : 4000,pinEvent  : 'click',html      : '" + msg + "',title     : '" + title + "'});");
            else
                Ext.Net.Notification.Show(new Ext.Net.NotificationConfig() { Icon = icon, HideDelay = 4000, PinEvent = "click", Html = msg, Title = title });
        }

        public static void MesajKutusuV3(string baslik, string mesaj)
        {
            Ext.Net.X.AddScript("window.top.Ext.Msg.alert('" + baslik + "','" + HataBilgisiniHMTLYap(mesaj) + "');");
        }

        public static void SetFocus(System.Web.UI.Page p, System.Web.UI.Control control)
        {
            string script = "";
            script = "<SCRIPT languange='JavaScript'>";
            script += "document.getElementById('";
            script += control.ID + "').focus();";
            script += "</SCRIPT>";

            p.ClientScript.RegisterStartupScript(p.GetType(), "sample_focus", script);
        }

        public static void SayfayaGirisYapabilirMi(Kullanici kullanan, System.Web.UI.Page sayfa)
        {
            SayfayaGirisYapabilirMi(kullanan, sayfa, true);
        }

        public static void SayfayaGirisYapabilirMi(Kullanici kullanan, System.Web.UI.Page sayfa, bool parolaKontrol)
        {
            bool yetkiVar = true;
            //string sayfaAd = "/" + System.IO.Path.GetFileName(sayfa.Request.FilePath);
            string sayfaAd = ".." + sayfa.Request.AppRelativeCurrentExecutionFilePath.Replace("~", "");
            string sayfaQueryStr = sayfa.ClientQueryString;
            if (kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI)) return;
            XmlNode bulunan = SayfayiMenudenBul(menuSecenekleri.ChildNodes, sayfaAd, parolaKontrol, sayfaQueryStr);
            if (bulunan != null)
                yetkiVar = YetkiKontrol(kullanan, bulunan);
            //else
            //    yetkiVar = false;//Menude olmayan iç sayfalarda bu kontrol olursa yetki sorunu oluşuyor

            if (kullanan == null || kullanan.kullaniciKodu == "")
                yetkiVar = false;

            if (!yetkiVar)
                SayfayaGirmesin(false);
        }

        public static bool ParolaSuresiKontrol(Kullanici kul, bool ParolaSayfasinaGit, bool anaKlasorden = false)
        {
            DateTime pt;

            if (OrtakFonksiyonlar.ConvertToInt(GenelIslemler.WebConfigOku("Entegrasyon", "0"), 0) > 0)//entegrasyon yok
                return false;

            if (!string.IsNullOrEmpty(TNS.DEG.Arac.DegiskenDegerBul(0, "SSO1")))
                return false;
            if (!string.IsNullOrEmpty(TNS.DEG.Arac.DegiskenDegerBul(0, "SSO2")))
                return false;

            if (kul == null)
                kul = OturumBilgisiIslem.KullaniciBilgiOku(true);

            if (kul.kullaniciKodu != "" && kul.kullaniciKodu != null)
            {
                if (kul.parolaBitisTarihi.isNull)//Kullanıcı ilk giriş yaptığında parola null
                    pt = DateTime.Today.AddDays(-1);
                else
                    pt = Convert.ToDateTime(kul.parolaBitisTarihi.ToString()).AddDays(-1);

                DateTime dt = DateTime.Today;

                if (DateTime.Compare(dt, pt) > 0)
                {
                    if (ParolaSayfasinaGit)
                    {
                        HttpContext.Current.Session["BilgiSatiri"] = "UyariGoster";
                        HttpContext.Current.Response.Redirect((anaKlasorden ? "" : "..") + "/KYM/ParolaDegistir.aspx");
                    }
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        private static bool YetkiKontrol(Kullanici kullanan, XmlNode bulunan)
        {
            if (kullanan == null)
                return false;

            XmlAttribute yetkiAttr = bulunan.Attributes["Yetki"];
            if (yetkiAttr == null || string.IsNullOrEmpty(yetkiAttr.Value))
                return true;
            else
            {
                string[] yetkiler = yetkiAttr.Value.Split(',');
                foreach (string yetki in yetkiler)
                {
                    if (!string.IsNullOrEmpty(yetki) && kullanan.KullaniciTipiIceriyorMu(OrtakFonksiyonlar.ConvertToInt(yetki, 0)))
                        return true;

                    if (yetki.StartsWith("YT"))
                    {
                        string[] damgaBilgi = yetki.Split('|');
                        if (damgaBilgi.Length < 3) return false;

                        foreach (DictionaryEntry de in kullanan.yetkiTipiDegerleri)
                        {
                            string deger = kullanan.yetkiTipiDegerleri[damgaBilgi[1]];
                            string[] degerler = deger.Split(';');
                            for (int k = 0; k < degerler.Length; k++)
                            {
                                if (degerler[k].Trim() == damgaBilgi[2])
                                    return true;
                            }
                        }
                    }

                }
            }
            return false;
        }

        public static void SayfayaGirisYapabilirMi(Kullanici kullanan, string sayfaAd)
        {
            SayfayaGirisYapabilirMi(kullanan, sayfaAd, false);
        }

        public static void SayfayaGirisYapabilirMi(Kullanici kullanan, string sayfaAd, bool parolaKontrol)
        {
            bool yetkiVar = false;

            if (kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI)) return;

            XmlNode bulunan = SayfayiMenudenBul(menuSecenekleri.ChildNodes, sayfaAd);
            if (bulunan != null)
                yetkiVar = YetkiKontrol(kullanan, bulunan);

            if (!yetkiVar)
                SayfayaGirmesin(true);
        }

        private static void SayfayaGirmesinKontrol(bool menuGosterme, bool geriDugmeGoster, string uyari)
        {
            string bilgiStr = "";
            bilgiStr = "<center><font color=red><img src='../App_themes/images/stop.gif'>&nbsp;<b>" + uyari + "</b></font></center><br><br>";
            if (geriDugmeGoster)
                bilgiStr += "<li>&nbsp;&nbsp;<a href='javascript:history.back()'>Geri</a></li>";
            HttpContext.Current.Session["BilgiSatiri"] = bilgiStr;
            string hedefParam = "";
            if (menuGosterme)
                hedefParam = "?menuYok=1";

            HttpContext.Current.Response.Redirect("../OrtakSayfa/Bilgilendirme.aspx" + hedefParam);
        }

        public static void SayfayaGirmesin(bool menuGosterme, bool geriDugmeGoster, string uyari)
        {
            SayfayaGirmesinKontrol(menuGosterme, geriDugmeGoster, uyari);
        }

        public static void SayfayaGirmesin(bool menuGosterme, string uyari)
        {
            SayfayaGirmesinKontrol(menuGosterme, false, uyari);
        }

        public static void SayfayaGirmesin(bool menuGosterme)
        {
            SayfayaGirmesinKontrol(menuGosterme, false, string.Empty);
        }

        public static string SayfaMenuIdBul(Page sayfa)
        {
            string _sayfa = ".." + sayfa.Request.AppRelativeCurrentExecutionFilePath.Replace("~", "");
            if (!string.IsNullOrEmpty(sayfa.ClientQueryString))
                _sayfa += "?" + sayfa.ClientQueryString;
            string menuID = SayfaMenuIdBul(_sayfa);

            if (string.IsNullOrEmpty(menuID))
                menuID = SayfaMenuIdBul(_sayfa.Split('?')[0]);

            return menuID;
        }

        private static string SayfaMenuIdBul(string sayfaAd)
        {
            XmlNode node = SayfayiMenudenBul(menuSecenekleri.ChildNodes, sayfaAd, true, "");
            if (node != null)
                return node.Attributes["ID"].Value;
            return string.Empty;
        }

        private static string SayfaModulBul(XmlNodeList girisNokta, string sayfaAd, string modulKod)
        {
            for (int i = 0; i < girisNokta.Count; i++)
            {
                XmlAttribute urlAttr = null;
                XmlAttribute mdlAttr = null;

                try
                {
                    urlAttr = girisNokta[i].Attributes["URL"];
                    mdlAttr = girisNokta[i].Attributes["Modul"];
                    if (mdlAttr != null) modulKod = mdlAttr.Value;
                }
                catch { }
                if (urlAttr != null && UrlSayfaAdIceriyorMu(urlAttr.Value, sayfaAd))
                    return modulKod;

                if (girisNokta[i].HasChildNodes)
                {
                    string bulunan = SayfaModulBul(girisNokta[i].ChildNodes, sayfaAd, modulKod);
                    if (bulunan != null)
                        return bulunan;
                }
            }
            return null;
        }

        public static string SayfaModulBul(string sayfaAd)
        {
            return SayfaModulBul(menuSecenekleri.ChildNodes, sayfaAd, "");
        }

        private static XmlNode SayfayiMenudenBul(XmlNodeList girisNokta, string sayfaAd, bool detayOncelikli, string sayfaQueryStr)
        {
            if (girisNokta == null) return null;
            XmlNode donusDeger = null;
            for (int i = 0; i < girisNokta.Count; i++)
            {
                if (girisNokta[i] == null) continue;
                try
                {
                    XmlAttribute urlAttr = girisNokta[i].Attributes["URL"];

                    if (urlAttr != null && UrlSayfaAdEsitMi(urlAttr.Value, sayfaAd, sayfaQueryStr))
                    {
                        if (!detayOncelikli || !girisNokta[i].HasChildNodes)
                            return girisNokta[i];
                        else
                            donusDeger = girisNokta[i];
                    }

                    if (girisNokta[i].HasChildNodes)
                    {
                        XmlNode bulunan = SayfayiMenudenBul(girisNokta[i].ChildNodes, sayfaAd, detayOncelikli, sayfaQueryStr);
                        if (bulunan != null)
                            return bulunan;
                    }
                }
                catch
                {
                    OrtakFonksiyonlar.HataDosyaYaz("MenuHata.txt", $"{i}. döngüde hata:{girisNokta[i].InnerText}", false);
                }
            }
            return donusDeger;
        }

        private static XmlNode SayfayiMenudenBul(XmlNodeList girisNokta, string sayfaAd)
        {
            for (int i = 0; i < girisNokta.Count; i++)
            {
                XmlAttribute urlAttr = null;

                try
                {
                    urlAttr = girisNokta[i].Attributes["URL"];
                }
                catch { }
                if (urlAttr != null && UrlSayfaAdIceriyorMu(urlAttr.Value, sayfaAd))
                    return girisNokta[i];

                if (girisNokta[i].HasChildNodes)
                {
                    XmlNode bulunan = SayfayiMenudenBul(girisNokta[i].ChildNodes, sayfaAd);
                    if (bulunan != null)
                        return bulunan;
                }
            }

            return null;
        }

        private static bool UrlSayfaAdEsitMi(string url, string sayfaAd, string sayfaQueryStr)
        {
            if (!string.IsNullOrEmpty(sayfaQueryStr))
                sayfaAd += "?" + sayfaQueryStr;

            return url == sayfaAd;
        }

        private static bool UrlSayfaAdIceriyorMu(string url, string sayfaAd)
        {
            System.Globalization.CultureInfo culc = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
            return url.ToLower(culc).IndexOf(sayfaAd.ToLower(culc)) >= 0;
        }

        public static void SayfayaGirisYapabilirMi(Kullanici kullanan, ObjectArray yetki, bool parolaKontrol)
        {
            bool kontrol;
            if (parolaKontrol)
                kontrol = ParolaSuresiKontrol(null, true);
            else
                kontrol = true;

            bool yetkiVar = false;

            for (int i = 0; i < yetki.objeler.Count; i++)
            {
                if (kullanan.KullaniciTipiIceriyorMu((int)yetki[i]))
                {
                    yetkiVar = true;
                    break;
                }
            }

            if (kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI))
                yetkiVar = true;

            if (!yetkiVar)
            {
                string bilgiStr = "";
                bilgiStr = "<center><font color=red><img src='../App_themes/images/stop.gif'>&nbsp;<b>" + OrtakClassRes.ORT004 + "</b></font></center><br><br>";
                bilgiStr += "<li>&nbsp;&nbsp;<a href='javascript:history.back()'>Geri</a></li>";
                HttpContext.Current.Session["BilgiSatiri"] = bilgiStr;
                HttpContext.Current.Response.Redirect("../OrtakSayfa/Bilgilendirme.aspx");
            }
        }

        public static void AyDoldur(DropDownList kontrol)
        {
            for (int i = 1; i < 13; i++)
                kontrol.Items.Add(new ListItem(AyAdDondur(i), i.ToString()));

            kontrol.SelectedIndex = DateTime.Now.Month - 1;
        }

        public static void AyDoldur(DropDownList kontrol, bool donem)
        {
            if (donem)
            {
                for (int i = 1; i <= 4; i++)
                    kontrol.Items.Add(new ListItem(i.ToString() + ". " + OrtakClassRes.ORT006, (i * 3).ToString()));
            }
            else
                AyDoldur(kontrol);
        }

        public static void AyDoldur(Ext1.Net.ComboBox cb, bool donem, bool fireSelect, int selectedValue = -1)
        {
            if (donem)
            {
                for (int i = 1; i <= 4; i++)
                    cb.Items.Add(new Ext1.Net.ListItem(i.ToString() + ". " + OrtakClassRes.ORT006, (i * 3).ToString()));

                if (fireSelect)
                {
                    if (selectedValue == -1) selectedValue = (((DateTime.Now.Month - 1) / 3) + 1) * 3;
                    cb.SetValueAndFireSelect(selectedValue);
                }
            }
            else
                AyDoldur(cb, fireSelect, selectedValue);
        }

        public static void AyDoldur(Ext1.Net.ComboBox cb, bool fireSelect = false, int selectedValue = -1)
        {
            for (int i = 1; i < 13; i++)
                cb.Items.Add(new Ext1.Net.ListItem(AyAdDondur(i), i.ToString()));

            if (cb != null)
            {
                if (fireSelect)
                {
                    if (selectedValue == -1) selectedValue = DateTime.Now.Month;
                    cb.SetValueAndFireSelect(selectedValue);
                }
                else
                {
                    cb.Value = DateTime.Now.Month;
                }
            }
        }

        public static void YilDoldur(DropDownList kontrol, int baslaYil, int bitisYil, int secYil)
        {
            for (int i = bitisYil ; i >= baslaYil; i--)
                kontrol.Items.Add(new ListItem(i.ToString()));
            kontrol.SelectedIndex = kontrol.Items.IndexOf(kontrol.Items.FindByValue(secYil.ToString()));
        }

        public static void YilDoldur(DropDownList kontrol, int baslaYil)
        {
            YilDoldur(kontrol, 2005, baslaYil + 1, baslaYil);
        }

        public static string SecilenleriBul(Ext1.Net.MultiCombo mcFisTur)
        {
            string tut = "";
            for (int i = 0; i < mcFisTur.SelectedItems.Count; i++)
            {
                if (tut != "") tut += ",";
                tut += mcFisTur.SelectedItems[i].Value;
            }
            return tut;
        }

        /// <summary>
        /// Ext store'a belirtilen aralıktaki yılları doldurur. Eğer doldurulacak kontrol ComboBox ise seçimli parametreler kullanılarak başlagıçta seçili gelecek yıl da aynı zamanda ayarlanabilir.
        /// </summary>
        /// <param name="store">Ext store. Yılların doldurulacağı store nesnesi</param>
        /// <param name="baslangicYil">Yıl aralığının başlangıcı</param>
        /// <param name="bitisYil">Yıl aralığının bitişi</param>
        /// <param name="cb">Seçimli parametre. Store eğer combobox'a atanacak ise, combobox'ı belirtmek için kullanılır.</param>
        /// <param name="seciliYil">Seçimli parametre. Combobox'ta başlangıçta seçili gelecek yılı ayarlar. Parametre verilmezse bulunulan yıl seçilir.</param>
        public static void YilDoldur(Ext1.Net.Store store, int baslangicYil, int bitisYil, Ext1.Net.ComboBox cb = null, int seciliYil = -1)
        {
            System.Collections.Generic.List<object> yillar = new System.Collections.Generic.List<object>();
            for (int i = baslangicYil; i <= bitisYil; i++)
                yillar.Add(new { yil = i });
            store.DataSource = yillar;
            store.DataBind();

            if (seciliYil == -1 && seciliYil >= baslangicYil && seciliYil <= bitisYil)
                seciliYil = DateTime.Now.Year;

            if (cb != null && seciliYil > 0)
            {
                cb.Value = seciliYil;
                cb.SetValueAndFireSelect(seciliYil);
            }
        }

        /// <summary>
        /// Ext ComboBox'a belirtilen aralıktaki yılları doldurur. Başlagıçta seçili gelecek yıl seciliYil parametresiyle ayarlanabilir.
        /// </summary>
        /// <param name="baslangicYil">Yıl aralığının başlangıcı</param>
        /// <param name="bitisYil">Yıl aralığının bitişi. Default değer(DateTime.Now.Year)</param>
        /// <param name="seciliYil">Combobox'ta başlangıçta seçili gelecek yılı ayarlar. (DateTime.Now.Year).</param>
        public static void YilDoldur(Ext1.Net.ComboBox cb, int baslangicYil, int bitisYil = -1, int seciliYil = -1)
        {
            if (bitisYil == -1)
                bitisYil = DateTime.Now.Year;
            for (int i = baslangicYil; i <= bitisYil; i++)
                cb.Items.Add(new Ext1.Net.ListItem(i.ToString(), i.ToString()));
            if (seciliYil == -1 && seciliYil >= baslangicYil && seciliYil <= bitisYil)
                seciliYil = DateTime.Now.Year;
            if (cb != null && seciliYil > 0)
                cb.SetValueAndFireSelect(seciliYil);
        }

        public static void CiktiYeriDoldur(DropDownList kontrol)
        {
            kontrol.Items.Add(new ListItem("EXCEL", "EXCEL"));
            kontrol.Items.Add(new ListItem("PDF", "PDF"));
            //kontrol.Items.Add(new ListItem("HTML4.0","HTML4.0"));
            //kontrol.Items.Add(new ListItem("XML","XML"));
            //kontrol.Items.Add(new ListItem("CSV","CSV"));
            //kontrol.Items.Add(new ListItem("MHTML","MHTML"));
        }


        public static void ResponseBasla(string dosyaAd, string ext, bool ekOlarakGonder)
        {
            ResponseBasla(dosyaAd, ext, "utf-8", ekOlarakGonder);
        }

        public static void ResponseBasla(string dosyaAd, string ext)
        {
            ResponseBasla(dosyaAd, ext, "utf-8", true);
        }

        public static void ResponseBasla(string dosyaAd, string ext, string charSet, bool ekOlarakGonder)
        {
            string tip = "";
            ext = ext.ToUpper();
            if (ext == "ZİP") ext = "ZIP";
            dosyaAd = System.IO.Path.GetFileNameWithoutExtension(dosyaAd) + "." + ext;

            if (ext == "XLS" || ext == "XLSX" || ext == "XLT" || ext == "XLTX")
                tip = "application/vnd.ms-excel";
            else if (ext == "DOC" || ext == "DOCX" || ext == "DOT" || ext == "DOTX")
                tip = "application/msword";
            else if (ext == "PDF")
                tip = "application/pdf";
            else if (ext == "ZIP")
                tip = "application/zip";
            else if (ext.StartsWith("HTM"))
                tip = "text/html";
            else if (ext.StartsWith("TXT") || ext.StartsWith("CSV"))
                tip = "text/text";
            else if (ext.StartsWith("XML"))
                tip = "text/xml";
            else if (ext == "MP4")
                tip = "video/mp4";
            else if (ext == "WEBM")
                tip = "video/webm";
            else if (ext == "OGV" || ext == "OGG")
                tip = "video/ogg";
            else
                tip = ext;

            System.Web.HttpContext.Current.Response.Clear();
            System.Web.HttpContext.Current.Response.Buffer = true;
            System.Web.HttpContext.Current.Response.HeaderEncoding = System.Text.Encoding.Default;
            System.Web.HttpContext.Current.Response.AppendHeader("Content-Disposition", (ekOlarakGonder ? "attachment" : "inline") + ";filename=\"" + dosyaAd + "\"");


            System.Web.HttpContext.Current.Response.ContentType = tip + "; charset=" + charSet;
            System.Web.HttpContext.Current.Response.Charset = charSet;
        }

        public static void ResponseBitir()
        {
            System.Web.HttpContext.Current.Response.Flush();
            System.Web.HttpContext.Current.Response.End();
        }

        public static void ListeYazdirDugmeGizle(System.Web.UI.Control dugme)
        {
            if (dugme != null)
            {
                TableCell tc = (TableCell)dugme.Parent;
                TableRow tr = (TableRow)tc.Parent;
                tr.Cells.Remove(tc);
            }
        }

        public static void DivisionGizleGoster(Page page, string divID, bool goster)
        {
            object div = page.FindControl(divID);
            if (div != null && div.GetType() == typeof(System.Web.UI.HtmlControls.HtmlGenericControl))
            {
                System.Web.UI.HtmlControls.HtmlGenericControl gen = (System.Web.UI.HtmlControls.HtmlGenericControl)div;

                if (goster)
                    gen.Style["display"] = "";
                else
                    gen.Style["display"] = "none";
            }
        }

        public static string GetIPAddress()
        {
            System.Web.HttpContext context = System.Web.HttpContext.Current;

            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] + "";

            if (!string.IsNullOrWhiteSpace(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    ipAddress = addresses[0];
                }
                else
                    ipAddress = "";
            }
            if (string.IsNullOrWhiteSpace(ipAddress) || ipAddress.Trim().Length < 3)
                ipAddress = context.Request.ServerVariables["REMOTE_ADDR"] + "";
            return ipAddress;
        }

        public static string RemoveHTML(string text, bool yeniSatirTemizle = true)
        {
            string cleanString;

            System.Web.UI.HtmlControls.HtmlGenericControl htmlDiv = new System.Web.UI.HtmlControls.HtmlGenericControl("div");
            htmlDiv.InnerHtml = text;
            cleanString = htmlDiv.InnerText;

            try
            {
                //Tek satırda temizleme işlemi
                cleanString = System.Text.RegularExpressions.Regex.Replace(cleanString, @"<(.|\n)*?>", string.Empty);

                cleanString = cleanString.Replace("&nbsp;", " ");
                cleanString = cleanString.Replace(";nbsp;", "; ");
                cleanString = cleanString.Replace(";amp;", ";");
                cleanString = cleanString.Replace(" amp;", "");
                cleanString = cleanString.Replace("&amp;", "&");

                int sayac = 0;
                while (cleanString.Contains("<") && cleanString.Contains(">"))
                {
                    int openIndx = cleanString.IndexOf('<');
                    int closeIndx = cleanString.IndexOf('>');
                    cleanString = cleanString.Insert(openIndx, "^");
                    cleanString = cleanString.Insert(closeIndx + 2, "~");
                    openIndx = cleanString.IndexOf('^');
                    closeIndx = cleanString.IndexOf('~');
                    cleanString = cleanString.Remove(openIndx, closeIndx - openIndx + 1);
                    cleanString = cleanString.Replace("^~", " ");
                    sayac++;
                    if (sayac > 100) break;
                }

                sayac = 0;
                while (cleanString.Contains("&lt;") && cleanString.Contains("&gt;"))
                {
                    int openIndx = cleanString.IndexOf("&lt;");
                    int closeIndx = cleanString.IndexOf("&gt;");
                    cleanString = cleanString.Insert(openIndx, "^");
                    cleanString = cleanString.Insert(closeIndx + 5, "~");
                    openIndx = cleanString.IndexOf('^');
                    closeIndx = cleanString.IndexOf('~');
                    cleanString = cleanString.Remove(openIndx, closeIndx - openIndx + 1);
                    cleanString = cleanString.Replace("^~", " ");
                    sayac++;
                    if (sayac > 100) break;
                }

                if (yeniSatirTemizle)
                {
                    //cleanString = cleanString.Replace("\r", " ");
                    cleanString = cleanString.Replace("\n", " ");
                }

                cleanString = cleanString.TrimStart().TrimEnd();

            }
            catch
            {
                return "";
            }


            return cleanString;
        }

#endif

    }

    /// <summary>
    /// ht:hem taşınır hem harcama süreçleri için ortak olarak 
    /// belirtilen tarihlerde uyarı gösterilmesi için eklendi
    /// </summary>
    public class Uyari
    {
        public static string TasinirUyarisiGoster()
        {
            string mesaj = "";
            try
            {

                if (DateTime.Now.Month % 3 == 0)
                {
                    //** Her yılın 3.,6.,9.,12. aylarının
                    //** tüketim malzemelerinin muhasebe birimine gönderilmesinde , 
                    //** zimmete verilmeyen dayanıklı taşınırlar için
                    if (DateTime.Now.Day >= 25 && DateTime.Now.Day <= 30)//25-30 tarihleri arasında uyarı göster
                    {
                        mesaj = OrtakClassRes.ORT007 + "\r\n \r\n";
                        mesaj += OrtakClassRes.ORT008 + "\r\n \r\n";
                    }

                    // her yılın 12. ayı
                    if (DateTime.Now.Month == 12)
                    {
                        //**sayım işlemleri için
                        if (DateTime.Now.Day >= 20 && DateTime.Now.Day <= 25)// her yılın 12. ayının 20-25 arasında uyarı göster
                        {
                            mesaj += OrtakClassRes.ORT009 + "\r\n";
                        }
                    }
                }
            }
            catch
            {

            }
            return mesaj;
        }
    }
}
