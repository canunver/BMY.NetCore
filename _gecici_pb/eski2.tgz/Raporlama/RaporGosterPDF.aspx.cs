﻿using System;
using System.IO;

namespace TNS.Raporlama
{
    public partial class RaporGosterPDF : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string tur = Request.QueryString["tur"] + "";
            string dosyaAdGelen = Request.QueryString["dosyaAd"] + "";
            bool kutuphane = OrtakFonksiyonlar.ConvertToInt(Request.QueryString["kutuphane"] + "", 0) > 0;
            string raporGrupNo = Request.QueryString["raporGrupNo"] + "";
            string raporNo = Request.QueryString["raporNo"] + "";
            string dosyaYol = "";

            if (!IsPostBack)
            {
                if (tur == "XLS" || tur == "DOC")
                {
                    dosyaYol = RaporlamaServis.RaporDosyaYolUret(raporGrupNo, raporNo, dosyaAdGelen, kutuphane);
                    if (File.Exists(dosyaYol))
                    {
                        OrtakClass.DosyaIslem.DosyaGonderX(dosyaYol, dosyaAdGelen, false, tur, true);
                        return;
                    }
                }

                if (tur == "PDF")
                {
                    string dosyaAd = Path.GetFileNameWithoutExtension(dosyaAdGelen); //RaporlamaServis.RaporDosyaAdUret(raporGrupNo, raporNo, anahtar, kullanan.kullaniciKodu);
                    dosyaAd += ".pdf";
                    string dosyaYolPDF = RaporlamaServis.RaporDosyaYolUret(raporGrupNo, raporNo, dosyaAd, kutuphane);
                    if (File.Exists(dosyaYolPDF))
                    {
                        OrtakClass.DosyaIslem.DosyaGonderX(dosyaYolPDF, dosyaAd, false, "pdf", false);
                    }
                    else
                    {
                        dosyaYol = RaporlamaServis.RaporDosyaYolUret(raporGrupNo, raporNo, dosyaAdGelen, kutuphane);
                        string yeniDosyaAdPDF = OrtakClass.DosyaTipDegistir.Dosya2PDF(dosyaYol, false);
                        OrtakClass.DosyaIslem.DosyaGonderX(yeniDosyaAdPDF, dosyaAd, false, "pdf", false);
                    }
                }
            }
        }
    }
}
