﻿using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;
using OrtakClass;
using TNS.BKD;
using TNS.UZY;

namespace TNS.Raporlama
{
    public partial class RaporKistasSayfa : istemciUzayi.GenelSayfa
    {
        IUZYServis servis = TNS.UZY.Arac.Tanimla();
        IBKDServis servisBKD = TNS.BKD.Arac.Tanimla();

        int rgNo = -1;
        int rNo = -1;
        int aktifYil;
        protected RaporGrupListesi rgl;

        override protected void OnInit(EventArgs e)
        {
            rgl = RaporlamaServis.RaporListesiAl();
            if (rgl != null)
            {
                rgNo = Convert.ToInt32(Request["raporGrupNo"]);
                rNo = Convert.ToInt32(Request["raporNo"]);
                RaporGrup rg = rgl.RaporGrup(rgNo);
                kullanan = OturumBilgisiIslem.KullaniciBilgiOku(false);
                if (rg != null)
                {
                    lblRaporAd.Text = rg.RaporAd(rNo);
                    KontrolleriOlustur(rg, true, rNo);
                }
            }
            base.OnInit(e);
        }

        protected void Page_Load(object sender, System.EventArgs e)
        {
            formAdi = Resources.Istemci.REP006;
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(false);

            string raporGrupNo = Request["raporGrupNo"] + "";
            string raporNo = Request["raporNo"] + "";
            ClientScript.RegisterStartupScript(this.GetType(), "DosyaGoster", "RaporGoster(" + raporGrupNo + "," + raporNo + ");", true);

            if (!IsPostBack)
            {
                RaporGrup rg = rgl.RaporGrup(rgNo);
                if (rg == null)
                {
                    TNS.Raporlama.RaporlamaServis.RaporListesiYenile();
                    rg = rgl.RaporGrup(rgNo);
                }
                if (rg != null)
                {
                    try
                    {
                        for (int j = 0; j < rg.kistasEkran.AlanSayisi(); j++)
                        {
                            KistasEkranAlan kea = rg.kistasEkran.Alan(j);
                            if (kea.degiskenTip == DEGISKENTIP.YIL)
                            {
                                DropDownList ddlYil = (DropDownList)FindControl(kea.degiskenAd);
                                if (OrtakFonksiyonlar.ConvertToInt(kea.ilkDeger, 0) > 0)
                                    YilDoldur(ddlYil, OrtakFonksiyonlar.ConvertToInt(kea.ilkDeger, 0));
                                else
                                    YilDoldur(ddlYil, true, kea.ekBilgi);
                                KullaniciDegiskenGetir(ddlYil);
                                ddlYil_SelectedIndexChanged(ddlYil, null);

                            }
                            else if (kea.degiskenTip == DEGISKENTIP.ASAMA)
                            {
                                DropDownList ddlAsama = (DropDownList)FindControl(kea.degiskenAd);
                                AsamaDoldur(ddlAsama, true);
                                KullaniciDegiskenGetir(ddlAsama);
                            }
                            else if (kea.degiskenTip == DEGISKENTIP.SENARYO)
                            {
                                DropDownList ddlSenaryo = (DropDownList)FindControl(kea.degiskenAd);
                                SenaryoDoldur(ddlSenaryo, true, "");
                                KullaniciDegiskenGetir(ddlSenaryo);
                            }
                            else if (kea.degiskenTip == DEGISKENTIP.ASAMAUYGULAMA)
                            {
                                DropDownList ddlAsama = (DropDownList)FindControl(kea.degiskenAd);
                                AsamaUygulamaDoldur(ddlAsama, true);
                                KullaniciDegiskenGetir(ddlAsama);
                            }
                            else if (kea.degiskenTip == DEGISKENTIP.AY)
                            {
                                DropDownList ddlAy = (DropDownList)FindControl(kea.degiskenAd);
                                if (OrtakFonksiyonlar.ConvertToInt(kea.ilkDeger, 0) > 0)
                                    AyDoldur(ddlAy, OrtakFonksiyonlar.ConvertToInt(kea.ilkDeger, 0));
                                else
                                    AyDoldur(ddlAy, true);
                                KullaniciDegiskenGetir(ddlAy);
                            }
                            else if (kea.degiskenTip == DEGISKENTIP.EGITIMTIP)
                            {
                                DropDownList ddlEgitim = (DropDownList)FindControl(kea.degiskenAd);
                                SenaryoDoldur(ddlEgitim, true, "");
                                //EgitimDoldur(ddlEgitim, true, "");
                                KullaniciDegiskenGetir(ddlEgitim);
                            }

                            else
                            {
                                Control c = FindControl(kea.degiskenAd);
                                if (c.GetType() == typeof(TextBox))
                                    KullaniciDegiskenGetir((TextBox)c);
                                else if (c.GetType() == typeof(DropDownList))
                                    KullaniciDegiskenGetir((DropDownList)c);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        string hataStr = "";
                        if (rgl == null)
                            hataStr = Resources.Istemci.REP003;
                        else
                            hataStr = string.Format(Resources.Istemci.REP004, rgNo, ex.ToString());

                    }
                    if (!rg.YetkisiVarMi(kullanan))
                    {
                        GenelIslemler.MesajKutusu(this, Resources.Istemci.REP007);
                    }
                }
                else
                    GenelIslemler.MesajKutusu(this, Resources.Istemci.REP008);
            }
        }

        private void YilDoldur(DropDownList c, bool ilkMi, string ekBilgi)
        {
            OrtakClass.GenelIslemlerIstemci.YilDoldur(c, !String.IsNullOrEmpty(ekBilgi));
        }

        private void YilDoldur(DropDownList c, int secili)
        {
            GenelIslemler.YilDoldur(c, 2002, DateTime.Now.Year, secili);
        }

        private void AyDoldur(DropDownList c, bool ilkMi)
        {
            OrtakClass.GenelIslemler.AyDoldur(c);
        }

        private void AyDoldur(DropDownList c, int secili)
        {
            OrtakClass.GenelIslemler.AyDoldur(c);
            try
            {
                c.SelectedIndex = c.Items.IndexOf(c.Items.FindByValue(secili.ToString()));
            }
            catch { }
        }

        private void AsamaDoldur(DropDownList c, bool ilkMi)
        {
            OrtakClass.GenelIslemlerIstemci.AsamaDoldur(c);
        }

        private void AsamaUygulamaDoldur(DropDownList c, bool ilkMi)
        {
            //GenelIslemlerIstemci.AsamaUygulamaDoldur(c);
        }

        private void KurumDoldur(int yil, DropDownList c, bool ilkMi, string ekBilgi)
        {
            c.Items.Clear();
            c.Items.Insert(0, new ListItem(GenelIslemlerIstemci.VarsayilanKurumBulAd(), GenelIslemlerIstemci.VarsayilanKurumBul()));
        }

        private void SenaryoDoldur(DropDownList c, bool ilkMi, string ekBilgi)
        {
            //KmL
            //Senaryo listesi doldur fonksiyonu eklenebilir mi?
            //GenelIslemlerIstemci.KullaniciKurumListesiDoldur(c, yil, kullanan);

            c.Items.Clear();
            BHMv2.ButceSenaryo bs = new BHMv2.ButceSenaryo();

            BHMv2.ButceSenaryo[] bsler = TNS.BHMv2.Arac.Tanimla().ButceSenaryoListele(kullanan, bs);
            for (int i = 0; i < bsler.Length; i++)
            {
                c.Items.Add(new ListItem(bsler[i].kod + "-" + bsler[i].ad, bsler[i].kod));
            }
            //c.Items.Insert(0, new ListItem(Resources.Istemci.REP009, "00.00"));
            //c.Items.Insert(1, new ListItem(Resources.Istemci.REP010, "01.00"));
            //c.Items.Insert(2, new ListItem(Resources.Istemci.REP011, "02.00"));
            //c.Items.Insert(3, new ListItem(Resources.Istemci.REP012, "03.00"));
            //c.Items.Insert(4, new ListItem(Resources.Istemci.REP013, "04.00"));
            //c.Items.Insert(5, new ListItem(Resources.Istemci.REP014, "05.00"));
            //c.Items.Insert(6, new ListItem(Resources.Istemci.REP015, "06.00"));

            if (!string.IsNullOrEmpty(ekBilgi))
            {
                c.SelectedValue = ekBilgi;
            }
        }

        private void BirimDoldur(int yil, DropDownList ddlBirim, bool ilkMi)
        {
            ddlBirim.Items.Clear();

            ABSKodlarVAN br = servisBKD.BirimListele(kullanan, yil, GenelIslemlerIstemci.VarsayilanKurumBul(), true);

            if (br.sonuc.islemSonuc)
            {
                ddlBirim.Items.Add(new ListItem(GenelIslemlerIstemci.VarsayilanKurumBulAd(), GenelIslemlerIstemci.VarsayilanKurumBul()));
                ddlBirim.Items.Add(new ListItem(Resources.Istemci.REP016, "00"));
                foreach (ABSKod ak in br.absKodlar)
                    ddlBirim.Items.Add(new ListItem(ak.kod + " - " + ak.Ad(kullanan.aktifKultur), ak.kod));
            }
            else
                throw new Exception(br.sonuc.hataStr);
            if (ilkMi)
                ddlBirim.SelectedIndex = 0;
        }

        private void KontrolleriOlustur(RaporGrup rg, bool ilkMi, int raporNo)
        {
            for (int i = 0; i < rg.kistasEkran.AlanSayisi(); i++)
            {
                TableRow row = new TableRow();

                TableCell cell = new TableCell();
                Literal literal = new Literal();
                literal.Text = rg.EtiketAd(i);
                cell.CssClass = "yaziAlanZorunluK";
                cell.Controls.Add(literal);
                cell.BorderWidth = 0;
                cell.Width = System.Web.UI.WebControls.Unit.Percentage(20);
                cell.BorderColor = System.Drawing.Color.LightGray;
                row.Cells.Add(cell);

                cell = new TableCell();
                literal = new Literal();
                literal.Text = ":";
                cell.CssClass = "yaziAlanZorunluK";
                cell.Controls.Add(literal);
                cell.BorderWidth = 0;
                cell.Width = System.Web.UI.WebControls.Unit.Percentage(1);
                cell.BorderColor = System.Drawing.Color.LightGray;
                row.Cells.Add(cell);

                cell = new TableCell();
                Control c;
                KistasEkranAlan kea = rg.kistasEkran.Alan(i);
                if (kea.degiskenTip == DEGISKENTIP.YIL)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                }
                else if (kea.degiskenTip == DEGISKENTIP.TEKLIFYIL)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";

                    for (int j = 0; j < i; j++)
                    {
                        if (rg.kistasEkran.Alan(j).degiskenTip == DEGISKENTIP.YIL)
                        {
                            DropDownList ddlYil = (DropDownList)FindControl(rg.kistasEkran.Alan(j).degiskenAd);
                            if (ddlYil != null)
                            {
                                ddlYil.AutoPostBack = true;
                                ddlYil.SelectedIndexChanged += new EventHandler(ddlYil_SelectedIndexChanged);
                                break;
                            }
                        }
                    }
                }
                else if (kea.degiskenTip == DEGISKENTIP.AY)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                    KullaniciDegiskenGetir((DropDownList)c);
                }
                else if (kea.degiskenTip == DEGISKENTIP.ASAMA)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                }
                else if (kea.degiskenTip == DEGISKENTIP.SENARYO)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                }
                else if (kea.degiskenTip == DEGISKENTIP.ASAMAUYGULAMA)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                }
                else if (kea.degiskenTip == DEGISKENTIP.COMBO)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                    string[] sa = kea.liste.Split(';');
                    int say = sa.Length;
                    int yer = -1;
                    for (int ic = 0; ic < say; ic++)
                    {
                        if (!String.IsNullOrEmpty(sa[ic]))
                        {
                            ((DropDownList)c).Items.Add((string)sa[ic]);
                            if ((string)sa[ic] == kea.ilkDeger)
                                yer = ic;
                        }
                    }
                    if (yer != -1)
                        ((DropDownList)c).SelectedIndex = yer;

                }
                else if (kea.degiskenTip == DEGISKENTIP.COMBO_KODAD)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                    string[] sa = kea.liste.Split(';');
                    int say = sa.Length;
                    int yer = -1;
                    for (int ic = 0; ic < say; ic++)
                    {
                        if (!String.IsNullOrEmpty(sa[ic]))
                        {
                            string[] saKodAd = sa[ic].Split('-');
                            string kod = "";
                            string ad = "";
                            if (saKodAd.Length == 2)
                            {
                                kod = saKodAd[0];
                                ad = saKodAd[1];
                            }
                            else
                            {
                                kod = ic.ToString();
                                ad = sa[ic];
                            }
                            ((DropDownList)c).Items.Add(new ListItem(ad, kod));
                            if (kod == kea.ilkDeger)
                                yer = ic;
                        }
                    }
                    if (yer != -1)
                        ((DropDownList)c).SelectedIndex = yer;
                }
                else if (kea.degiskenTip == DEGISKENTIP.COMBO_DINAMIK)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).Items.Add(new ListItem("Hepsi", ""));

                    ListeSatir[] bListe = null;
                    TNS.KYM.YetkiTipi yt = TNS.KYM.Arac.YetkiTipiBul(kea.liste);
                    if (yt == null)
                    {
                        int ytKod = OrtakFonksiyonlar.ConvertToInt(kea.liste, -1);
                        if (ytKod > 0)
                            yt = TNS.KYM.Arac.YetkiTipiBul(ytKod);

                    }
                    if (yt != null)
                        bListe = TNS.KYM.Arac.Tanimla().YetkiTipiGirisListesi(kullanan, yt, DateTime.Now.Year, "");

                    if (bListe != null)
                    {

                        ((DropDownList)c).CssClass = "veriAlanDDL";
                        int yer = -1;
                        for (int ic = 0; ic < bListe.Length; ic++)
                        {
                            string kod = bListe[ic].kod;
                            string ad = bListe[ic].ad;
                            ((DropDownList)c).Items.Add(new ListItem(ad, kod));
                            if (kod == kea.ilkDeger)
                                yer = ic;
                        }
                        if (yer != -1)
                            ((DropDownList)c).SelectedIndex = yer;
                    }
                }
                else if (kea.degiskenTip == DEGISKENTIP.YAZI)
                {
                    c = new TextBox();
                    c.ID = kea.degiskenAd;
                    ((TextBox)c).CssClass = "veriAlan";
                    if (ilkMi)
                        ((TextBox)c).Text = kea.ilkDeger;
                }
                else if (kea.degiskenTip == DEGISKENTIP.YAZIKURUMSAL)
                {
                    c = new TextBox();
                    c.ID = kea.degiskenAd;
                    ((TextBox)c).CssClass = "veriAlan";
                    ((TextBox)c).Text = OrtakClass.GenelIslemlerIstemci.VarsayilanKurumBul();//kea.ilkDeger;
                }
                else if (kea.degiskenTip == DEGISKENTIP.TARIH ||
                    kea.degiskenTip == DEGISKENTIP.ILKTARIH ||
                    kea.degiskenTip == DEGISKENTIP.SONTARIH)
                {
                    c = new TextBox();
                    c.ID = kea.degiskenAd;
                    ((TextBox)c).CssClass = "veriAlan";

                    if (kea.degiskenTip == DEGISKENTIP.ILKTARIH)
                        ((TextBox)c).Text = "01.01." + DateTime.Now.Year.ToString();
                    else if (kea.degiskenTip == DEGISKENTIP.SONTARIH)
                        ((TextBox)c).Text = DateTime.Now.ToShortDateString();
                }
                else if (kea.degiskenTip == DEGISKENTIP.KURUM)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                    for (int j = 0; j < i; j++)
                    {
                        if (rg.kistasEkran.Alan(j).degiskenTip == DEGISKENTIP.YIL)
                        {
                            DropDownList ddlYil = (DropDownList)FindControl(rg.kistasEkran.Alan(j).degiskenAd);
                            if (ddlYil != null)
                            {
                                ddlYil.AutoPostBack = true;
                                ddlYil.SelectedIndexChanged += new EventHandler(ddlYil_SelectedIndexChanged);
                                break;
                            }
                        }
                    }
                }
                else if (kea.degiskenTip == DEGISKENTIP.BIRIM)
                {
                    c = new DropDownList();
                    c.ID = kea.degiskenAd;
                    ((DropDownList)c).CssClass = "veriAlanDDL";
                }
                else if (kea.degiskenTip == DEGISKENTIP.CHECKBOX)
                {
                    c = new CheckBox();
                    c.ID = kea.degiskenAd;
                    ((CheckBox)c).CssClass = "veriAlan";
                    if (ilkMi)
                        ((CheckBox)c).Checked = OrtakFonksiyonlar.ConvertToInt(kea.ilkDeger, 0) > 0;
                }
                else
                    c = null;

                if (c != null)
                {
                    if (GizliMi(kea, raporNo))
                    {
                        c.Visible = false;
                        row.Visible = false;
                    }
                    cell.BorderWidth = 0;
                    cell.Width = System.Web.UI.WebControls.Unit.Percentage(80);
                    cell.BorderColor = System.Drawing.Color.LightGray;

                    cell.Controls.Add(c);
                    row.Cells.Add(cell);

                    tblKistas.Rows.Add(row);
                }
            }
            tblKistas.CellPadding = 2;
            tblKistas.CellSpacing = 0;
        }

        private bool GizliMi(KistasEkranAlan kea, int raporNo)
        {
            if (kea.gizli) return true;
            if (kea.gosterilecekRaporlar == null || kea.gosterilecekRaporlar.Length == 0) return false;
            for (int i = 0; i < kea.gosterilecekRaporlar.Length; i++)
            {
                if (kea.gosterilecekRaporlar[i] == raporNo) return false;
            }
            return true;
        }

        private void KullaniciDegiskenGetir(DropDownList c)
        {
            string kullaniciDegisken = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "RAPOR_" + c.ID);

            if (!string.IsNullOrEmpty(kullaniciDegisken))
            {
                try
                {
                    c.SelectedValue = kullaniciDegisken;
                }
                catch { }
            }
        }

        private void KullaniciDegiskenGetir(TextBox c)
        {
            string kullaniciDegisken = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "RAPOR_" + c.ID);

            if (!string.IsNullOrEmpty(kullaniciDegisken))
            {
                c.Text = kullaniciDegisken;
            }
        }

        protected void btnRaporHazirla_Click(object sender, System.EventArgs e)
        {
            Hashtable ht = new Hashtable();
            RaporGrup rg = rgl.RaporGrup(rgNo);
            string anahtar;
            KistasDegerleriBul(rg, ht, out anahtar);

            string dosyaAd = RaporlamaServis.RaporDosyaAdUret(rgNo, rNo, anahtar, kullanan.kullaniciKodu);
            dosyaAd += "_" + DateTime.Now.ToString().Replace(":", "").Replace(" ", "").Replace("/", "").Replace(".", "");
            string dosyaYol = RaporlamaServis.RaporDosyaYolUret(rgNo.ToString(), rNo.ToString(), dosyaAd, false);

            try
            {
                Rapor r = rg.Rapor(rNo);

                string uretilenDosya = rg.RaporAl(kullanan, servis, r, ht, false, true, dosyaYol);

                if (uretilenDosya.StartsWith("BİLGİ") || uretilenDosya.StartsWith("HATA"))
                {
                    GenelIslemler.MesajKutusu(this, uretilenDosya);
                    return;
                }
                //PDF Üretimi
                //string yeniDosyaAdPDF = OrtakClass.DosyaTipDegistir.Dosya2PDF(uretilenDosya, false);

                string gidenAd = System.IO.Path.GetFileName(uretilenDosya); //System.IO.Path.GetFileNameWithoutExtension(uretilenDosya);
                string gidenAdExt = System.IO.Path.GetExtension(uretilenDosya).Replace(".", "");
                OrtakClass.DosyaIslem.DosyaGonder(uretilenDosya, gidenAd, false, gidenAdExt);
            }
            catch (System.Threading.ThreadAbortException ex)
            {
                GenelIslemler.MesajKutusu(this, ex.Message);
            }
            catch (Exception ex)
            {
                OrtakClass.GenelIslemler.MesajKutusu(this, ex.Message);
            }
        }

        protected void ddlYil_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (sender.GetType() == typeof(DropDownList))
            {
                DropDownList ddlYil = (DropDownList)sender;
                aktifYil = Convert.ToInt32(ddlYil.SelectedValue);
                RaporGrup rg = rgl.RaporGrup(rgNo);
                for (int j = 0; j < rg.kistasEkran.AlanSayisi(); j++)
                {
                    if (rg.kistasEkran.Alan(j).degiskenTip == DEGISKENTIP.TEKLIFYIL)
                    {
                        DropDownList ddlTeklifYil = (DropDownList)FindControl(rg.kistasEkran.Alan(j).degiskenAd);

                        ddlTeklifYil.Items.Clear();
                        ddlTeklifYil.Items.Add(aktifYil.ToString());
                        ddlTeklifYil.Items.Add((aktifYil + 1).ToString());
                        ddlTeklifYil.Items.Add((aktifYil + 2).ToString());
                    }
                    else if (rg.kistasEkran.Alan(j).degiskenTip == DEGISKENTIP.BIRIM)
                    {
                        DropDownList c = (DropDownList)FindControl(rg.kistasEkran.Alan(j).degiskenAd);
                        BirimDoldur(aktifYil, c, false);
                        KullaniciDegiskenGetir((DropDownList)c);
                    }
                }
            }
        }

        private void DegerleriAta(Hashtable ht, string id, string deger, bool tireYokEt)
        {
            if (!string.IsNullOrEmpty(id))
            {
                if (tireYokEt)
                {
                    int tireYer = deger.IndexOf(" - ");
                    if (tireYer >= 0)
                        deger = deger.Remove(0, tireYer + 3);
                }
                ht.Add(id, deger);
                string degiskenAd = rgNo.ToString() + "_" + rNo.ToString() + "_" + id;
                GenelIslemler.KullaniciDegiskenSakla(kullanan, degiskenAd, deger);
            }
        }

        enum ALANTIP : int
        {
            ALAN_TEXT, ALAN_COMBOTEXT, ALAN_COMBOLISTITEM, ALAN_CKECKBOX
        }

        private ALANTIP TipBul(KistasEkranAlan a)
        {
            if (a.degiskenTip == DEGISKENTIP.YIL || a.degiskenTip == DEGISKENTIP.TEKLIFYIL || a.degiskenTip == DEGISKENTIP.COMBO)
                return ALANTIP.ALAN_COMBOTEXT;
            else if (a.degiskenTip == DEGISKENTIP.COMBO_KODAD || a.degiskenTip == DEGISKENTIP.COMBO_DINAMIK || a.degiskenTip == DEGISKENTIP.KURUM || a.degiskenTip == DEGISKENTIP.BIRIM || a.degiskenTip == DEGISKENTIP.ASAMA || a.degiskenTip == DEGISKENTIP.SENARYO || a.degiskenTip == DEGISKENTIP.ASAMAUYGULAMA || a.degiskenTip == DEGISKENTIP.AY)
                return ALANTIP.ALAN_COMBOLISTITEM;
            else if (a.degiskenTip == DEGISKENTIP.CHECKBOX)
                return ALANTIP.ALAN_CKECKBOX;
            else
                return ALANTIP.ALAN_TEXT;
        }

        private void KistasDegerleriBul(RaporGrup rg, Hashtable ht, out string anahtar)
        {
            anahtar = "";
            for (int i = 0; i < rg.kistasEkran.AlanSayisi(); i++)
            {
                KistasEkranAlan alan = rg.kistasEkran.Alan(i);
                ALANTIP alanTip = TipBul(alan);
                Control c = this.FindControl(alan.degiskenAd);
                if (c != null)
                {
                    string deger = "";
                    string id = "";
                    if (alanTip == ALANTIP.ALAN_TEXT)
                    {
                        id = ((System.Web.UI.WebControls.TextBox)c).ID;
                        deger = ((System.Web.UI.WebControls.TextBox)c).Text;
                        DegerleriAta(ht, id, deger, false);
                        if (alan.zorunlu)
                        {
                            if (!(alan.degiskenTip == DEGISKENTIP.TARIH ||
                                alan.degiskenTip == DEGISKENTIP.ILKTARIH ||
                                alan.degiskenTip == DEGISKENTIP.SONTARIH))
                                anahtar = AnahtarOl(anahtar, "_", deger);
                        }
                    }
                    else if (alanTip == ALANTIP.ALAN_CKECKBOX)
                    {
                        id = ((System.Web.UI.WebControls.CheckBox)c).ID;
                        deger = OrtakFonksiyonlar.ConvertToInt(((System.Web.UI.WebControls.CheckBox)c).Checked, 0).ToString();
                        DegerleriAta(ht, id, deger, false);
                        if (alan.zorunlu) anahtar = AnahtarOl(anahtar, "_", deger);
                    }
                    else if (alanTip == ALANTIP.ALAN_COMBOTEXT)
                    {
                        id = ((System.Web.UI.WebControls.DropDownList)c).ID;
                        int selectedNo = ((System.Web.UI.WebControls.DropDownList)c).SelectedIndex;
                        if (selectedNo >= 0)
                        {
                            deger = ((System.Web.UI.WebControls.DropDownList)c).SelectedValue;
                            DegerleriAta(ht, id, deger, false);
                            if (alan.zorunlu) anahtar = AnahtarOl(anahtar, "_", deger);
                        }
                    }
                    else if (alanTip == ALANTIP.ALAN_COMBOLISTITEM)
                    {
                        id = ((System.Web.UI.WebControls.DropDownList)c).ID;
                        int selectedNo = ((System.Web.UI.WebControls.DropDownList)c).SelectedIndex;
                        if (selectedNo >= 0)
                        {
                            ListItem li = ((System.Web.UI.WebControls.DropDownList)c).SelectedItem;
                            deger = li.Value;
                            DegerleriAta(ht, id, deger, false);
                            if (alan.zorunlu) anahtar = AnahtarOl(anahtar, "_", deger);
                            if (!string.IsNullOrEmpty(alan.degiskenAciklama))
                            {
                                DegerleriAta(ht, alan.degiskenAciklama, li.Text, alan.degiskenTip == DEGISKENTIP.KURUM || alan.degiskenTip == DEGISKENTIP.BIRIM);
                            }
                        }
                    }

                    //if (deger != "")
                    //{
                    string degAlan = "RAPOR_" + id;
                    GenelIslemler.KullaniciDegiskenSakla(kullanan, degAlan, deger);
                    //}
                }
            }
            if (ht["TeklifYil"] + "" != "" && ht["Asama"] + "" != "" && ht["ButceYil"] + "" != "")
            {
                int by = OrtakFonksiyonlar.ConvertToInt(ht["ButceYil"], 0);
                int ty = OrtakFonksiyonlar.ConvertToInt(ht["TeklifYil"], 0);
                int aa = (ty - by) * 10;
                ht["Asama"] = (OrtakFonksiyonlar.ConvertToInt(ht["Asama"], 0) + aa).ToString();
            }
        }

        private string AnahtarOl(string anahtar, string ek, string deger)
        {
            if (string.IsNullOrEmpty(anahtar)) return deger;
            else return anahtar + ek + deger;
        }
    }
}