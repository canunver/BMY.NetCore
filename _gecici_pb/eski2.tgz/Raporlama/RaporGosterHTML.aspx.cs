﻿using System;
using System.IO;
using System.Collections;
using System.Resources;

namespace TNS.Raporlama
{
    public partial class RaporGosterHTML : istemciUzayi.GenelSayfa
    {
        private string[] zorunluParam = { "raporGrupNo", "raporNo", "seriNo" };
        private int raporGrupNo, raporNo;
        private string seriNo;
        private Hashtable raporParam = new Hashtable();
        private Hashtable param = new Hashtable();
        private string hataMesaj = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ParamsDoldur();
                if (hataMesaj != "") return;

                if (Kontrol())
                    RaporUret();
            }
        }

        private void ParamsDoldur()
        {
            foreach (string key in Request.QueryString.AllKeys)
                if (!param.ContainsKey(key))
                    param.Add(key, Request.QueryString[key]);

            raporParam = (Hashtable)param.Clone();
            foreach (string str in zorunluParam)
                raporParam.Remove(str);

            raporGrupNo = OrtakFonksiyonlar.ConvertToInt(param[zorunluParam[0]], 0);
            raporNo = OrtakFonksiyonlar.ConvertToInt(param[zorunluParam[1]], 0);
            seriNo = OrtakFonksiyonlar.ConvertToStr(param[zorunluParam[2]]);
            if (raporGrupNo == 0 || raporNo == 0 || seriNo == "")
                hataMesaj = "Eksik parametre hatası...";
        }

        private bool Kontrol()
        {
            string key = "";
            //foreach (DictionaryEntry de in param) { if ((string)de.Key == zorunluParam[2]) continue; key += de.Key + "=" + de.Value + "&"; }
            foreach (string tmpKey in Request.QueryString.AllKeys) { if (tmpKey == zorunluParam[2]) continue; key += tmpKey + "=" + (string)param[tmpKey] + "&"; }
            key = key.GetHashCode().ToString();

            if (seriNo == key)
                return true;
            return false;
        }

        private void RaporUret()
        {
            KYM.Kullanici kullanici = new KYM.Kullanici();
            string yol = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            string raporDosyaAd = RaporlamaServis.TekRaporAl(raporGrupNo, raporNo, kullanici, null, raporParam, false, true, yol);
            FileInfo fi = new FileInfo(raporDosyaAd);
            if (fi.Exists)
            {
                if (fi.Extension.ToLower() == ".html")
                    ResponseWriteHtml(raporDosyaAd);
                else
                    OrtakClass.DosyaIslem.DosyaGonderX(raporDosyaAd, "Rapor" + fi.Extension, true, fi.Extension.Replace(".", ""), true);
            }

        }

        private void ResponseWriteHtml(string dosyaAd)
        {
            StreamReader sr = new StreamReader(dosyaAd);
            string htmlText = sr.ReadToEnd(); sr.Close();

            System.Web.HttpContext.Current.Response.Clear();
            System.Web.HttpContext.Current.Response.Buffer = false;
            System.Web.HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;
            System.Web.HttpContext.Current.Response.Charset = "utf-8";
            System.Web.HttpContext.Current.Response.ContentType = "text/html";
            System.Web.HttpContext.Current.Response.Output.Write(htmlText);
            System.Web.HttpContext.Current.Response.Flush();
            try { System.IO.File.Delete(dosyaAd); }
            catch (Exception) { }
            System.Web.HttpContext.Current.Response.End();
        }

    }
}
