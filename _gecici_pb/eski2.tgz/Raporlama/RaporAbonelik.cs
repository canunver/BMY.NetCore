﻿using System;
using System.Collections.Generic;
using System.Web;
using TNS.KYM;
using System.Collections;
using System.Resources;
using System.IO;
using TNS.Raporlama;
using TNS;

namespace Istemci.Raporlama
{
    public class RaporAbonelik
    {
        private static string yazilimMailAdresi = TNS.OrtakFonksiyonlar.WebConfigOku("yazilimMailAdresi", "");
        private static string mailKonu = "Haftalık Ödenek Durumu";
        private static IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();

        public static void AbonelikRaporlariOlustur()
        {
            Hashtable liste = servisKYM.RaporListele();
            foreach (DictionaryEntry de in liste)
                MailMetinOlustur(de);
        }

        private static void MailMetinOlustur(DictionaryEntry de)
        {
            string mailList = "";
            string[] raporBilgiler = ((string)de.Key).Split('-');
            Kullanici kul = new Kullanici();
            string raporDosyaAd = RaporlamaServis.TekRaporAl(Convert.ToInt32(raporBilgiler[0]), Convert.ToInt32(raporBilgiler[1]), kul, null, new Hashtable(), false, true, null);
            StreamReader sr = new StreamReader(raporDosyaAd);
            string mailMetin = sr.ReadToEnd();
            sr.Close();

            foreach (object[] bilgi in (ArrayList)de.Value) mailList += bilgi[4] + ";";
            mailList = mailList.TrimEnd(';');

            MailGonder(mailList, mailMetin);
        }

        private static void MailGonder(string mailList, string mailMetin)
        {
            OrtakFonksiyonlar.MailAt(yazilimMailAdresi, mailList, mailKonu, mailMetin, true, false, null);
            //servisKYM.EPostaGonder(yazilimMailAdresi, mailList, mailKonu, mailMetin, true, false, null);
        }

    }
}