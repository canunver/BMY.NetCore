﻿using System;
using System.IO;
using System.Text;

namespace TNS.Raporlama
{
    public partial class RaporDosya : istemciUzayi.GenelSayfa
    {
        protected void Page_Load(object sender, System.EventArgs e)
        {
            if (!IsPostBack)
            {
                hdnRaporGrupNo.Value = Request.QueryString["raporGrupNo"] + "";
                hdnRaporNo.Value = Request.QueryString["raporNo"] + "";

                DosyaListele();
            }
        }


        void DosyaListele()
        {
            StringBuilder liste = new StringBuilder();
            //Ana tablo
            liste.Append("<table>");

            //Rapor dosyaları tablosu
            string[,] dosyalar = DosyalariVer(false);
            bool eklendi = false;
            if (dosyalar != null)
            {
                liste.Append("<tr><td valign=top width=300px><table>"); //Sol Tablo
                liste.Append("<tr><td colspan=3><b>Daha önce hazırlanmış raporlar</b></td></tr>");
                for (int i = 0; i < dosyalar.GetUpperBound(0) + 1; i++)
                {
                    string dosyaAd = dosyalar[i, 0];
                    string dosyaTarih = dosyalar[i, 1];
                    string ico = "";
                    string aciklama = "";
                    if (!string.IsNullOrEmpty(dosyaAd))
                    {
                        eklendi = true;
                        string uzanti = Path.GetExtension(dosyaAd).ToUpper().Replace(".", "");
                        if (uzanti == "XLS") { ico = "excel.png"; aciklama = "EXCEL"; }
                        else if (uzanti == "DOC") { ico = "word.png"; aciklama = "WORD"; }

                        liste.Append("<tr><td><a href='' onclick=\"KutuphaneyeEkle('" + dosyaAd + "');return false;\"><img src='../app_Themes/images/ekle3.gif' alt='Kütüphaneye Ekle'/></a></td><td><a href='' onclick='RaporPDFGoster(\"" + dosyaAd + "\",\"PDF\",\"\");return false;'><img src='../app_Themes/images/pdf.png' alt='PDF'/></a><a href='' onclick='RaporPDFGoster(\"" + dosyaAd + "\",\"" + uzanti + "\",\"\");return false;'><img src='../app_Themes/images/" + ico + "' alt='" + aciklama + "'/></a></td><td>" + dosyaTarih + "</td></tr>");
                    }
                }
                if (!eklendi)
                    liste.Append("<tr><td colspan=3>Henüz rapor hazırlanmamış.</td></tr>");

                liste.Append("</table></td><td valign=top><table>");

                //Kütüphane dosyaları tablosu
                dosyalar = DosyalariVer(true);
                liste.Append("<tr><td colspan=3><b>Kütüphaneye eklenmiş raporlar</b></td></tr>");
                eklendi = false;
                if (dosyalar != null)
                {
                    for (int i = 0; i < dosyalar.GetUpperBound(0) + 1; i++)
                    {
                        string dosyaAd = dosyalar[i, 0];
                        string dosyaTarih = dosyalar[i, 1];
                        string ico = "";
                        string aciklama = "";
                        if (!string.IsNullOrEmpty(dosyaAd))
                        {
                            eklendi = true;
                            string uzanti = Path.GetExtension(dosyaAd).ToUpper().Replace(".", "");
                            if (uzanti == "XLS") { ico = "excel.png"; aciklama = "EXCEL"; }
                            else if (uzanti == "DOC") { ico = "word.png"; aciklama = "WORD"; }

                            string silHucre = "";
                            if (dosyaAd.StartsWith(kullanan.kullaniciKodu + "_"))
                                silHucre = "<a href='' onclick=\"KutuphanedenSil('" + dosyaAd + "');return false;\"><img src='../app_Themes/images/cikart3.png' alt='Kütüphaneden Sil'/></a>";
                            else
                                silHucre = "&nbsp;";
                            liste.Append("<tr><td>" + silHucre + "</td><td><a href='' onclick='RaporPDFGoster(\"" + dosyaAd + "\",\"PDF\",\"1\");return false;'><img src='../app_Themes/images/pdf.png' alt='PDF'/></a><a href='' onclick='RaporPDFGoster(\"" + dosyaAd + "\",\"" + uzanti + "\",\"1\");return false;'><img src='../app_Themes/images/" + ico + "' alt='" + aciklama + "'/></a></td><td>" + dosyaTarih + "</td></tr>");
                        }
                    }
                }
                if (!eklendi)
                    liste.Append("<tr><td colspan=3>Kütüphanede rapor bulunmamaktadır.</td></tr>");
                liste.Append("</table></td></tr>");
            }
            else
                liste.Append("<tr><td>web.config dosyasında RaporDosyaYol değişkeni bulunamadı!</td></tr>");

            //Ana tablo kapat
            liste.Append("</table>");

            ltlDosyaListe.Text = liste.ToString();
        }

        string[,] DosyalariVer(bool kutuphane)
        {
            string raporGrupNo = hdnRaporGrupNo.Value;
            string raporNo = hdnRaporNo.Value;
            string dosyaYol = null;
            try
            {
                dosyaYol = RaporlamaServis.RaporDosyaYolUret(raporGrupNo, raporNo, "", kutuphane);
            }
            catch { return null; }
            string kriter = "";

            if (kutuphane)
                kriter += "*";
            else
                kriter += kullanan.kullaniciKodu;

            kriter += "_" + raporGrupNo + "_" + raporNo + "_";

            DirectoryInfo klasor = new DirectoryInfo(dosyaYol);
            FileInfo[] dosyalar = klasor.GetFiles(kriter + "*.*");
            string[,] donenDeger = new string[3, 2];
            if (kutuphane)
                donenDeger = new string[dosyalar.Length, 2];

            //Listelenen dosyaları tarihe göre sıralanması
            Array.Sort(dosyalar, delegate (FileInfo f1, FileInfo f2)
            {
                return f2.CreationTime.CompareTo(f1.CreationTime);
            });

            int sayac = 0;
            for (int i = 0; i < dosyalar.Length; i++)
            {
                if (Path.GetExtension(dosyalar[i].Name).ToLower().StartsWith(".xls") || Path.GetExtension(dosyalar[i].Name).ToLower().StartsWith(".doc") || Path.GetExtension(dosyalar[i].Name).ToLower().StartsWith(".pdf"))
                {
                    //Rapor klasöründe kullanıya ait 3 den fazla rapor dosyası var ise fazla olanlar silinsin
                    if (sayac > 2 && !kutuphane)
                    {
                        DosyaSil(dosyalar[i].Name, raporGrupNo, raporNo, false);
                    }
                    else
                    {
                        donenDeger[sayac, 0] = dosyalar[i].Name;
                        donenDeger[sayac, 1] = dosyalar[i].CreationTime.ToString();
                    }
                    sayac++;
                }
            }

            return donenDeger;
        }

        protected void btnKutuphaneEkle_Click(object sender, System.EventArgs e)
        {
            string dosya = hdnDosyaAd.Value;
            string raporGrupNo = hdnRaporGrupNo.Value;
            string raporNo = hdnRaporNo.Value;

            string dosyaYol = RaporlamaServis.RaporDosyaYolUret(raporGrupNo, raporNo, "", false);
            string kriter = Path.GetFileNameWithoutExtension(dosya);

            DirectoryInfo klasor = new DirectoryInfo(dosyaYol);
            FileInfo[] dosyalar = klasor.GetFiles(kriter + "*.*");
            for (int i = 0; i < dosyalar.Length; i++)
            {
                try
                {
                    string dosyaYolKutuphane = RaporlamaServis.RaporDosyaYolUret(raporGrupNo, raporNo, dosyalar[i].Name, true);
                    dosyalar[i].MoveTo(dosyaYolKutuphane);
                }
                catch { }
            }
            DosyaListele();
        }

        protected void btnKutuphaneSil_Click(object sender, System.EventArgs e)
        {
            string dosya = hdnDosyaAd.Value;
            string raporGrupNo = hdnRaporGrupNo.Value;
            string raporNo = hdnRaporNo.Value;

            DosyaSil(dosya, raporGrupNo, raporNo, true);

            DosyaListele();
        }

        void DosyaSil(string dosya, string raporGrupNo, string raporNo, bool kutuphane)
        {
            string dosyaYol = RaporlamaServis.RaporDosyaYolUret(raporGrupNo, raporNo, "", kutuphane);
            string kriter = Path.GetFileNameWithoutExtension(dosya);

            DirectoryInfo klasor = new DirectoryInfo(dosyaYol);
            FileInfo[] dosyalar = klasor.GetFiles(kriter + "*.*");
            for (int i = 0; i < dosyalar.Length; i++)
            {
                try
                {
                    dosyalar[i].Delete();
                }
                catch { }
            }
        }
    }
}