﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OrtakClass;
using TNS.Raporlama;
using TNS.UZY;
using TNS.BKD;
using System.Collections;
using Ext1.Net;

namespace TNS.Raporlama
{
    public partial class RaporGrupListe : istemciUzayi.GenelSayfa
    {
        IUZYServis servis = TNS.UZY.Arac.Tanimla();
        IBKDServis servisBKD = TNS.BKD.Arac.Tanimla();
        //private GenelIslemlerIstemci.MyGridColorStyle colorStyle;

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = Resources.Istemci.REP019;
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(false);
            SayfaUstAltBolumYaz(this);

            if (!IsPostBack)
            {
                string rgNolar = Request["raporGrup"] + "";
                string[] rgNoStr = rgNolar.Split('-');
                if (!string.IsNullOrEmpty(rgNolar) && rgNoStr.Length > 0)
                {
                    ArrayList al = new ArrayList();
                    RaporGrupListesi rgl = RaporlamaServis.RaporListesiAl();
                    string raporBaslik = "";
                    for (int i = 0; i < rgNoStr.Length; i++)
                    {
                        int rgNo = OrtakFonksiyonlar.ConvertToInt(rgNoStr[i], -1);
                        RaporGrup rg = null;
                        if (rgl != null)
                            rg = rgl.RaporGrup(rgNo);

                        if (rg != null)
                        {
                            try
                            {
                                string icBaslik = rg.RaporGrupAd();
                                if (string.IsNullOrEmpty(raporBaslik))
                                    raporBaslik = icBaslik;
                                else
                                    raporBaslik += "-" + icBaslik;

                                Listele(rg, al);
                            }
                            catch (Exception ex)
                            {
                                string hataStr = "";
                                if (rgl == null)
                                    hataStr = Resources.Istemci.REP003;
                                else
                                    hataStr = string.Format(Resources.Istemci.REP004, rgNo, ex.ToString());

                                GenelIslemler.MesajKutusu(this, hataStr);
                            }
                        }
                    }

                    reportsStore.DataSource = al;
                    reportsStore.DataBind();
                    grdReports.ColumnModel.Columns[0].Header = raporBaslik;

                    if (al.Count > 0)
                    {
                        object[] ilkler = (object[])al[0];
                        RowSelectionModel sm = (RowSelectionModel)this.grdReports.SelectionModel.Primary;
                        sm.SelectedRows.Add(new SelectedRow(0));
                        X.AddScript(string.Format("SelectRow('{0}');", (string)ilkler[0]));
                        //Page.ClientScript.RegisterStartupScript(this.GetType(), "rowClick", string.Format("SelectRow('{0}');", (string)ilkler[0]), true);
                    }
                }
            }
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");
        }

        private void Listele(RaporGrup rg, ArrayList al)
        {
            string raporGrupNo = rg.grupNo.ToString();

            for (int i = 0; i < rg.RaporSayisi(); i++)
            {
                TNS.Raporlama.Rapor r = rg[i];
                string repNo = raporGrupNo + "-" + r.raporNo.ToString();
                string tut = rg.RaporAd(r.raporNo);
                if (string.IsNullOrEmpty(tut))
                {
                    tut = string.Format(Resources.Istemci.REP020, repNo);
                }
                al.Add(new object[] { repNo, tut });
            }
        }
    }
}
