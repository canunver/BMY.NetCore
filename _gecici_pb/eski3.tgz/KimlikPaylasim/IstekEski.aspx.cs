﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using TNS;
using OrtakClass;
using TNS.KYM;
using TNS.KPM;
using EkRtfReport;

namespace KimlikPaylasim
{
    public partial class IstekEski : istemciUzayi.GenelSayfa
    {
        IKPMServis servisKPM = TNS.KPM.Arac.Tanimla();
        IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Kimlik Paylaşım";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            this.txtTCKimlikNo.Attributes.Add("onblur", "AdSil();");

            rblIstekTur.Items[0].Value = ((int)ENUMIstekTur.IKAMETGAH).ToString();
            rblIstekTur.Items[0].Text = TNS.KPM.Istek.IstekTurAdiDondur((int)ENUMIstekTur.IKAMETGAH);

            rblIstekTur.Items[1].Value = ((int)ENUMIstekTur.NUFUSCUZDANORNEK).ToString();
            rblIstekTur.Items[1].Text = TNS.KPM.Istek.IstekTurAdiDondur((int)ENUMIstekTur.NUFUSCUZDANORNEK);

            rblIstekTur.Items[2].Value = ((int)ENUMIstekTur.VUKUATLINUFUSKAYITORNEK).ToString();
            rblIstekTur.Items[2].Text = TNS.KPM.Istek.IstekTurAdiDondur((int)ENUMIstekTur.VUKUATLINUFUSKAYITORNEK);

            //rblIstekTur.Items[2].Enabled = false;

            if (!IsPostBack)
            {
                txtDuzenleyenAdSoyad.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKDUZENLEYENAD");
                txtDuzenleyenUnvan.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKDUZENLEYENUNVAN");
                txtOnaylayanAdSoyad.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKONAYLAYANAD");
                txtOnaylayanUnvan.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKONAYLAYANUNVAN");
            }

            if (string.IsNullOrEmpty(txtTCKimlikNo.Text.Trim()))
                lblMernisAd.Text = "";
        }

        protected void btnYazdir_Click(object sender, EventArgs e)
        {
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "KIMLIKDUZENLEYENAD", txtDuzenleyenAdSoyad.Text.Trim());
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "KIMLIKDUZENLEYENUNVAN", txtDuzenleyenUnvan.Text.Trim());
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "KIMLIKONAYLAYANAD", txtOnaylayanAdSoyad.Text.Trim());
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "KIMLIKONAYLAYANUNVAN", txtOnaylayanUnvan.Text.Trim());

            TNS.KPM.Istek istek = new TNS.KPM.Istek();
            istek.istekTur = OrtakFonksiyonlar.ConvertToInt(rblIstekTur.SelectedValue.Trim(), 0);
            istek.tcKimlikNo = txtTCKimlikNo.Text.Trim();
            istek.adSoyad = AdSoyadGetir(istek.tcKimlikNo);
            istek.islemYapan = kullanan.kullaniciKodu;
            istek.islemTarih.Yaz(DateTime.Now);

            if (istek.istekTur == (int)ENUMIstekTur.IKAMETGAH)
                IkametgahIlmuhaberiYazdir(istek);
            else if (istek.istekTur == (int)ENUMIstekTur.NUFUSCUZDANORNEK)
                NufusKayitYazdir(istek);
            else if (istek.istekTur == (int)ENUMIstekTur.VUKUATLINUFUSKAYITORNEK)
                VukuatliNufusKayitYazdir(istek);
        }

        //Nufus Kayit Ornegi Yazdirma
        private void NufusKayitYazdir(TNS.KPM.Istek istek)
        {
            ObjectArray nufusList = servisKPM.NufusKayitOrnekRaporla(kullanan, istek);

            TNS.KPM.Kisi nufusOrnek = new TNS.KPM.Kisi();

            if (!nufusList.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, nufusList.sonuc.hataStr);
                return;
            }
            else if (nufusList.ObjeSayisi > 0)
                nufusOrnek = (TNS.KPM.Kisi)nufusList.objeler[0];
            else
            {
                GenelIslemler.MesajKutusu(this, nufusList.sonuc.bilgiStr);
                return;
            }

            EkRtf ekRtf1 = new EkRtf();
            ekRtf1.InFile = Server.MapPath("~") + "\\RaporSablon\\KPM\\NufusCuzdanOrnegi.rtf";
            ekRtf1.CreateVar("SERI", nufusOrnek.nufusCuzdani.nufusCuzdanSeri);
            ekRtf1.CreateVar("NUMARA", nufusOrnek.nufusCuzdani.nufusCuzdanNo);
            ekRtf1.CreateVar("TCKIMLIKNO", istek.tcKimlikNo);
            ekRtf1.CreateVar("CINSIYET", nufusOrnek.cinsiyetAciklama);
            ekRtf1.CreateVar("SOYADI", nufusOrnek.soyad);
            ekRtf1.CreateVar("ADI", nufusOrnek.ad);
            ekRtf1.CreateVar("BABAADI", nufusOrnek.babaAd);
            ekRtf1.CreateVar("ANAADI", nufusOrnek.anaAd);
            ekRtf1.CreateVar("DOGUMYERI", nufusOrnek.dogumYeri);
            ekRtf1.CreateVar("DOGUMTARIHI", nufusOrnek.dogumTarihi.Oku(), true);
            ekRtf1.CreateVar("MEDENIHALI", nufusOrnek.medeniHalAciklama);
            ekRtf1.CreateVar("DINI", "");
            ekRtf1.CreateVar("KANGRUBU", nufusOrnek.kanGrubu);
            ekRtf1.CreateVar("KIZLIKSOYADI", nufusOrnek.kizlikSoyad);
            ekRtf1.CreateVar("IL", nufusOrnek.kayitliOlduguYer.ilce.il.ad);
            ekRtf1.CreateVar("ILCE", nufusOrnek.kayitliOlduguYer.ilce.ad);
            ekRtf1.CreateVar("MAHALLEKOY", nufusOrnek.kayitliOlduguYer.mahalleKoy);
            ekRtf1.CreateVar("CILTNO", nufusOrnek.kayitliOlduguYer.ciltNo.ToString().PadLeft(4, '0'));
            ekRtf1.CreateVar("AILESIRA", nufusOrnek.kayitliOlduguYer.aileSiraNo.ToString().PadLeft(5, '0'));
            ekRtf1.CreateVar("BIREYSIRA", nufusOrnek.kayitliOlduguYer.bireySiraNo.ToString().PadLeft(4, '0'));
            ekRtf1.CreateVar("VERILDIGIYER", nufusOrnek.nufusCuzdani.verildigiYer);
            ekRtf1.CreateVar("VERILISNEDENI", nufusOrnek.nufusCuzdani.verilisNedeniAciklama);
            ekRtf1.CreateVar("KAYITNO", nufusOrnek.nufusCuzdani.kayitNo);
            ekRtf1.CreateVar("VERILISTARIHI", nufusOrnek.nufusCuzdani.verilisTarihi.Oku(), true);

            ekRtf1.CreateVar("DUZENLEYENAD", txtDuzenleyenAdSoyad.Text.Trim());
            ekRtf1.CreateVar("DUZENLEYENUNVAN", txtDuzenleyenUnvan.Text.Trim());
            ekRtf1.CreateVar("ONAYLAYANAD", txtOnaylayanAdSoyad.Text.Trim());
            ekRtf1.CreateVar("ONAYLAYANUNVAN", txtOnaylayanUnvan.Text.Trim());

            string sonucDosyaAd = ekRtf1.CreateTmpFileName();

            ekRtf1.OutFile = sonucDosyaAd;
            ekRtf1.Execute();
            ekRtf1.ReportData.Clear();

            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "NufusCuzdanOrnegi.doc", true, "doc");
        }

        //İkametgah İl Muhaberi Yazdirma
        private void IkametgahIlmuhaberiYazdir(TNS.KPM.Istek istek)
        {
            ObjectArray ikametgahList = servisKPM.IkametgahRaporla(kullanan, istek);

            TNS.KPM.Kisi ikametgah = new TNS.KPM.Kisi();

            if (!ikametgahList.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, ikametgahList.sonuc.hataStr);
                return;
            }
            else if (ikametgahList.ObjeSayisi > 0)
                ikametgah = (TNS.KPM.Kisi)ikametgahList.objeler[0];
            else
            {
                GenelIslemler.MesajKutusu(this, ikametgahList.sonuc.bilgiStr);
                return;
            }

            EkRtf ekRtf1 = new EkRtf();
            ekRtf1.InFile = Server.MapPath("~") + "\\RaporSablon\\KPM\\IkametgahIlmuhaberi.rtf";
            ekRtf1.CreateVar("ILI", ikametgah.adres.il);
            ekRtf1.CreateVar("ILCESI", ikametgah.adres.ilce);

            string bucak = "";
            try { bucak = ikametgah.adres.bucak; } catch { }

            ekRtf1.CreateVar("BUCAGI", bucak);
            ekRtf1.CreateVar("KOYU", ikametgah.adres.koy);
            ekRtf1.CreateVar("MAHALLESI", ikametgah.adres.mahalle);
            ekRtf1.CreateVar("ADISOYADI", ikametgah.ad + " " + ikametgah.soyad);
            ekRtf1.CreateVar("BABAADI", ikametgah.babaAd);
            ekRtf1.CreateVar("ANNEADI", ikametgah.anaAd);
            ekRtf1.CreateVar("DOGUMYERI", ikametgah.dogumYeri);
            ekRtf1.CreateVar("DOGUMYILI", ikametgah.dogumTarihi.Yil.ToString());
            ekRtf1.CreateVar("MEDENIHALI", ikametgah.medeniHalAciklama);
            ekRtf1.CreateVar("ISI", "");
            ekRtf1.CreateVar("SOKAK", ikametgah.adres.sokak);
            ekRtf1.CreateVar("NO", ikametgah.adres.numara);

            ekRtf1.CreateVar("DUZENLEYENAD", txtDuzenleyenAdSoyad.Text.Trim());
            ekRtf1.CreateVar("DUZENLEYENUNVAN", txtDuzenleyenUnvan.Text.Trim());
            ekRtf1.CreateVar("ONAYLAYANAD", txtOnaylayanAdSoyad.Text.Trim());
            ekRtf1.CreateVar("ONAYLAYANUNVAN", txtOnaylayanUnvan.Text.Trim());

            string sonucDosyaAd = ekRtf1.CreateTmpFileName();

            ekRtf1.OutFile = sonucDosyaAd;
            ekRtf1.Execute();
            ekRtf1.ReportData.Clear();

            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "IkametgahIlmuhaber.doc", true, "doc");
        }

        //Vukuatlı Nufus Kayit Ornegi Yazdirma
        private void VukuatliNufusKayitYazdir(TNS.KPM.Istek istek)
        {
            ObjectArray nufusList = servisKPM.VukuatliNufusKayitOrnekRaporla(kullanan, istek);

            TNS.KPM.Kisi nufusKisi = new TNS.KPM.Kisi();

            if (!nufusList.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, nufusList.sonuc.hataStr);
                return;
            }
            else if (nufusList.ObjeSayisi > 0)
                nufusKisi = (TNS.KPM.Kisi)nufusList.objeler[0];
            else
            {
                GenelIslemler.MesajKutusu(this, nufusList.sonuc.bilgiStr);
                return;
            }

            EkRtf ekRtf1 = new EkRtf();
            ekRtf1.InFile = Server.MapPath("~") + "\\RaporSablon\\KPM\\VukuatliNufusKayitOrnegi.rtf";
            ekRtf1.CreateVar("ILI", nufusKisi.kayitliOlduguYer.ilce.il.ad);
            ekRtf1.CreateVar("ILCESI", nufusKisi.kayitliOlduguYer.ilce.ad);
            ekRtf1.CreateVar("MAHALLE_KOY", nufusKisi.kayitliOlduguYer.mahalleKoy);
            ekRtf1.CreateVar("CILTNO", nufusKisi.kayitliOlduguYer.ciltNo.ToString());
            ekRtf1.CreateVar("ASIRANO", nufusKisi.kayitliOlduguYer.aileSiraNo.ToString());
            ekRtf1.CreateVar("SIRANO", nufusKisi.kayitliOlduguYer.bireySiraNo.ToString());

            DataTable dtKisiBilgi = new DataTable();
            dtKisiBilgi.Columns.Add("sira");
            dtKisiBilgi.Columns.Add("yakinlikDerecesi");
            dtKisiBilgi.Columns.Add("tCKimlikNo");
            dtKisiBilgi.Columns.Add("adi");
            dtKisiBilgi.Columns.Add("soyadi");
            dtKisiBilgi.Columns.Add("babaAdi");
            dtKisiBilgi.Columns.Add("anaAdi");

            string[] satirDegerler = new string[7];

            int index = 1;
            foreach (AileFerdi af in nufusKisi.aileFertleri.objeler)
            {
                satirDegerler[0] = index.ToString(); ;
                satirDegerler[1] = "";// AileFerdi.YakinlikDerecesiAdiDondur(af.yakinlikDerecesi);
                satirDegerler[2] = af.tcKimlikNo;
                satirDegerler[3] = af.ad;
                satirDegerler[4] = af.soyad;
                satirDegerler[5] = af.babaAd;
                satirDegerler[6] = af.anaAd;
                dtKisiBilgi.Rows.Add(satirDegerler);
                index++;
            }
            ekRtf1.ReportData.Add(dtKisiBilgi, "vnko");


            string sonucDosyaAd = ekRtf1.CreateTmpFileName();

            ekRtf1.OutFile = sonucDosyaAd;
            ekRtf1.Execute();
            ekRtf1.ReportData.Clear();

            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, "VukuatlıNufusKayitOrnegi.doc", true, "doc");
        }

        protected void btnListele_Click(object sender, EventArgs e)
        {
            Listele();
        }

        private void Listele()
        {
            TNS.KPM.Istek istek = new TNS.KPM.Istek();
            istek.tcKimlikNo = txtTCKimlikNo.Text.Trim();
            istek.islemYapan = kullanan.kullaniciKodu;
            istek.islemTarih.Yaz(DateTime.Today.Date);

            ObjectArray istekVAN = servisKPM.IstekListele(kullanan, istek);
            if (!istekVAN.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, istekVAN.sonuc.hataStr);
                dgListe.DataBind();
                lblKacKayit.Visible = false;
                return;
            }
            if (istekVAN.objeler.Count <= 0)
            {
                GenelIslemler.MesajKutusu(this, istekVAN.sonuc.bilgiStr);
                dgListe.DataBind();
                lblKacKayit.Visible = false;
                return;
            }

            DataTable table = new DataTable();
            table.Columns.Add("tcKimlikNo");
            table.Columns.Add("istekTur");
            table.Columns.Add("islemTarih");
            table.Columns.Add("islemYapan");

            foreach (TNS.KPM.Istek i in istekVAN.objeler)
            {
                string link = i.tcKimlikNo + " - " + i.adSoyad;
                table.Rows.Add(link, i.istekTurAd, i.islemTarih.ToLongString(), i.islemYapan);
            }

            dgListe.DataSource = table;
            dgListe.DataBind();

            lblKacKayit.Visible = true;
            lblKacKayit.Text = "Arama sonucunda " + istekVAN.objeler.Count.ToString() + " kayıt bulundu.";
        }

        protected void imgKimlik_Click(object sender, System.EventArgs e)
        {
            string adSoyad = AdSoyadGetir(txtTCKimlikNo.Text.Trim());
            if (!string.IsNullOrEmpty(adSoyad))
                lblMernisAd.Text = adSoyad;
        }

        private string AdSoyadGetir(string tcKimlikNo)
        {
            KullaniciVAN kVAN = servisKYM.MernisBilgiOku(new Kullanici(), tcKimlikNo, new TNSDateTime());

            if (kVAN.sonuc.islemSonuc && !string.IsNullOrEmpty(kVAN.kullanici.ad + kVAN.kullanici.soyad))
                return kVAN.kullanici.ad + " " + kVAN.kullanici.soyad;
            else
            {
                lblMernisAd.Text = "<b>Hata : </b>" + kVAN.sonuc.hataStr;
                return null;
            }
        }
    }
}
