﻿using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TNS;
using OrtakClass;
using TNS.KYM;
using TNS.KPM;
using jxl;
using Ext1.Net;

namespace KimlikPaylasim
{
    public partial class Sorgulama : istemciUzayi.GenelSayfa
    {
        IKPMServis servisKPM = TNS.KPM.Arac.Tanimla();
        IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "İşlem Kaydı Sorgulama";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                txtTarih1.Text = DateTime.Now.AddDays(-7).ToShortDateString();
                txtTarih2.Text = DateTime.Now.ToShortDateString();
            }
        }

        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
            Yazdir();
        }

        private void Yazdir()
        {
            if (string.IsNullOrEmpty(txtTarih1.Text) || string.IsNullOrEmpty(txtTarih2.Text))
            {
                GenelIslemler.HataYaz(this, "Tarih aralığı belirtiniz.");
                return;
            }

            TNS.KPM.Istek istek = new TNS.KPM.Istek();
            istek.tcKimlikNo = txtTCKimlikNo.Text.Trim();
            istek.sorguIslemYapan = txtIslemYapan.Text;
            istek.islemTarih = new TNSDateTime(txtTarih1.Text);
            istek.islemTarih2 = new TNSDateTime(txtTarih2.Text);

            ObjectArray istekVAN = servisKPM.IstekListele(kullanan, istek);
            if (!istekVAN.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, istekVAN.sonuc.hataStr);
                return;
            }
            if (istekVAN.objeler.Count <= 0)
            {
                GenelIslemler.MesajKutusu(this, istekVAN.sonuc.bilgiStr);
                return;
            }

            Tablo XLS = GenelIslemler.NewTablo();
            int satir = 0;
            int sutun = 0;
            int kaynakSatir = 0;

            string sonucDosyaAd = TNS.OrtakFonksiyonlar.GeciciDosyaAdBul();
            string sablonAd = string.Empty;

            sablonAd = Server.MapPath("~") + "\\RaporSablon\\KPM\\Sorgulama.xlt";
            XLS.DosyaAc(sablonAd, sonucDosyaAd);
            XLS.HucreAdAdresCoz("BaslaSatir", ref satir, ref sutun);
            kaynakSatir = satir;
            int baslaSatir = satir;
            satir++;

            foreach (TNS.KPM.Istek i in istekVAN.objeler)
            {
                XLS.SatirAc(satir, 1);
                XLS.HucreKopyala(kaynakSatir, sutun, kaynakSatir, sutun + 10, satir, sutun);
                XLS.HucreDegerYaz(satir, 0, i.tcKimlikNo);
                XLS.HucreDegerYaz(satir, 1, i.adSoyad);
                XLS.HucreDegerYaz(satir, 2, i.istekTurAd);
                XLS.HucreDegerYaz(satir, 3, i.islemTarih.ToLongString());
                XLS.HucreDegerYaz(satir, 4, i.islemYapan);
            }


            XLS.DosyaSaklaTamYol(); 
            OrtakClass.DosyaIslem.DosyaGonder(XLS.SonucDosyaAd(), sonucDosyaAd, true, "XLS");
        }
    }
}
