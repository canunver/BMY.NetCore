﻿<%@ Page Language="C#" CodeBehind="Istek.aspx.cs" Inherits="KimlikPaylasim.Istek" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <link href="../App_themes/popupDialog.css" type="text/css" rel="stylesheet" />
    <script language="javascript" type="text/javascript" src="../script/popupDialog.js?mc=03022015"></script>
    <script language="javascript" type="text/javascript" src="../script/popupDialog2.js?mc=03022015"></script>
    <script language="JavaScript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>
    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
    <script language="javascript" type="text/javascript" src="ModulScripts/Istek.js?mc=03022015"></script>
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:Store ID="ListeStore" runat="server">
        <Reader>
            <ext:JsonReader>
                <Fields>
                    <ext:RecordField Name="TC" />
                    <ext:RecordField Name="TUR" />
                    <ext:RecordField Name="TARIH" />
                    <ext:RecordField Name="KULLANAN" />
                </Fields>
            </ext:JsonReader>
        </Reader>
    </ext:Store>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center>
                    <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px"
                        Margins="104 20 10 20" Border="false">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnYazdir" runat="server" Text="Rapor Yazdır" Icon="Printer">
                                        <DirectEvents>
                                            <Click OnEvent="btnYazdir_Click" IsUpload="true" />
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Button ID="btnListele" runat="server" Text="Tarihçe Listele" Icon="ApplicationForm">
                                        <DirectEvents>
                                            <Click OnEvent="btnListele_Click" />
                                        </DirectEvents>
                                    </ext:Button>
                                    <ext:Label ID="lblKacKayit" runat="server" />
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:BorderLayout ID="BorderLayout2" runat="server">
                                <North>
                                    <ext:FormPanel ID="FormPanel1" runat="server" Frame="true" AutoScroll="true" Padding="5"
                                        LabelWidth="180" AutoHeight="true">
                                        <Items>
                                            <ext:CompositeField ID="CompositeField1" runat="server" FieldLabel="T.C. Kimlik No">
                                                <Items>
                                                    <ext:HyperLink ID="HyperLink1" runat="server" NavigateUrl="http://tckimlik.nvi.gov.tr/Web/" Target="_blank" TabTip="T.C. Kimlik Numarasını öğrenmek için lütfen buraya tıklayınız." ImageUrl="../App_themes/images/dunya.gif" />
                                                    <ext:TriggerField runat="server" ID="txtTCKimlikNo" MaxLength="11" Width="130">
                                                        <Triggers>
                                                            <ext:FieldTrigger Qtip="T.C. Kimlik Numarası girildikten sonra resme basıldığında adı ve soyadı otomatik olarak getirilecektir."
                                                                Icon="Search" />
                                                        </Triggers>
                                                        <DirectEvents>
                                                            <TriggerClick OnEvent="imgKimlik_Click" />
                                                        </DirectEvents>
                                                        <Listeners>
                                                            <Blur Handler="AdSil();" />
                                                        </Listeners>
                                                    </ext:TriggerField>
                                                    <ext:Label ID="lblMernisAd" runat="server" />
                                                    </Items>
                                                    <%--<a href="http://tckimlik.nvi.gov.tr/Web/" target="_blank">
                                                        <img alt="T.C. Kimlik Numarasını öğrenmek için lütfen buraya tıklayınız." src="../App_themes/images/dunya.gif" />T.C. Sorgulama</a>
                                                </Content>--%>
                                            </ext:CompositeField>
                                            <ext:RadioGroup runat="server" ID="rbIstekTur" FieldLabel="Rapor Türü" BoxMaxWidth="350">
                                                <Items>
                                                    <ext:Radio ID="rb1" runat="server" InputValue="1" Checked="true" />
                                                    <ext:Radio ID="rb2" runat="server" InputValue="2" />
                                                    <ext:Radio ID="rb3" runat="server" InputValue="3" Visible="false" Disabled="true" />
                                                </Items>
                                            </ext:RadioGroup>
                                            <ext:CompositeField ID="CompositeField2" runat="server">
                                                <Items>
                                                    <ext:TextField ID="txtDuzenleyenAdSoyad" runat="server" FieldLabel="Düzenleyen Adı Soyadı"
                                                        Width="150" />
                                                    <ext:TextField ID="txtDuzenleyenUnvan" runat="server" FieldLabel="Unvanı" Width="250" />
                                                </Items>
                                            </ext:CompositeField>
                                            <ext:CompositeField ID="CompositeField3" runat="server">
                                                <Items>
                                                    <ext:TextField ID="txtOnaylayanAdSoyad" runat="server" FieldLabel="Onaylayan Adı Soyadı"
                                                        Width="150" />
                                                    <ext:TextField ID="txtOnaylayanUnvan" runat="server" FieldLabel="Unvanı" Width="250" />
                                                </Items>
                                            </ext:CompositeField>
                                        </Items>
                                    </ext:FormPanel>
                                </North>
                                <Center Split="true">
                                    <ext:GridPanel ID="grdListe" runat="server" StripeRows="true" Header="false" TrackMouseOver="true"
                                        StoreID="ListeStore" Border="true" AutoExpandColumn="KULLANAN" Layout="FitLayout"
                                        Width="400">
                                        <ColumnModel ID="ColumnModel1" runat="server">
                                            <Columns>
                                                <ext:Column DataIndex="TC" Header="TC Kimlik No" Width="200" />
                                                <ext:Column DataIndex="TUR" Header="İstek Türü" Width="150" />
                                                <ext:Column DataIndex="TARIH" Header="En Son İşlem Tarihi" Width="120" />
                                                <ext:Column DataIndex="KULLANAN" Header="En Son İşlem Yapan" Width="100" />
                                            </Columns>
                                        </ColumnModel>
                                        <BottomBar>
                                            <ext:PagingToolbar ID="PagingToolbar1" runat="server" PageSize="25" HideRefresh="true" />
                                        </BottomBar>
                                    </ext:GridPanel>
                                </Center>
                                <South>
                                    <ext:Panel runat="server" ID="pnlAlt" Height="65">
                                        <Content>
                                            <div class="bilgiKutusu">
                                                <li>&nbsp;&nbsp;Sorgulama sonucunda elde edilen tüm nüfus ve adres bilgilerini sadece
                                                    Bakanlık iş süreçleri içerisinde kullanılmalıdır.</li>
                                                <li>&nbsp;&nbsp;Yapılan sorgulamalar, sorgulanan kişi, sorgulayan kişi ve sorgulama
                                                    tarihi olarak kayıt altına alınmaktadır.</li>
                                            </div>
                                        </Content>
                                    </ext:Panel>
                                </South>
                            </ext:BorderLayout>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
