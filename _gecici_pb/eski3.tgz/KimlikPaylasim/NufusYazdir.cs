﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TNS;
using TNS.KYM;
using TNS.KPM;
using EkRtfReport;
using System.Data;

namespace KimlikPaylasim
{
    public class NufusYazdir : TNS.Raporlama.IRapor
    {
        public string RaporAl(object o_kullanan, object servis, string sablonAd, string sonucDosyaAd, string ciktiYeri, System.Collections.Hashtable raporParam, string ekBilgi)
        {
            servisKPM = TNS.KPM.Arac.Tanimla();
            servisKYM = TNS.KYM.Arac.Tanimla();
            this.sablonAd = sablonAd;
            this.sonucDosyaAd = sonucDosyaAd + ".doc";
            kullanan = (Kullanici)o_kullanan;
            TNS.KPM.Istek istek = new TNS.KPM.Istek();
            istek.istekTur = OrtakFonksiyonlar.ConvertToInt(ekBilgi, 1);
            istek.tcKimlikNo = (string)raporParam["TCKimlikNo"];
            //istek.adSoyad = AdSoyadGetir(kullanan, servisKYM, istek.tcKimlikNo, out hata);
            istek.islemYapan = kullanan.kullaniciKodu;
            istek.islemTarih.Yaz(DateTime.Now);

            txtDuzenleyenAdSoyad = (string)raporParam["DUZENLEYENAD"];
            txtDuzenleyenUnvan = (string)raporParam["DUZENLEYENUNVAN"];
            txtOnaylayanAdSoyad = (string)raporParam["ONAYLAYANAD"];
            txtOnaylayanUnvan = (string)raporParam["ONAYLAYANUNVAN"];

            if (istek.istekTur == (int)ENUMIstekTur.IKAMETGAH)
                return IkametgahIlmuhaberiYazdir(istek);
            else if (istek.istekTur == (int)ENUMIstekTur.NUFUSCUZDANORNEK)
                return NufusKayitYazdir(istek);
            else if (istek.istekTur == (int)ENUMIstekTur.VUKUATLINUFUSKAYITORNEK)
                return VukuatliNufusKayitYazdir(istek);

            throw new Exception("Hatalı Parametre Geldi!");
        }

        //Nufus Kayit Ornegi Yazdirma
        private string NufusKayitYazdir(TNS.KPM.Istek istek)
        {
            ObjectArray nufusList = servisKPM.NufusKayitOrnekRaporla(kullanan, istek);

            TNS.KPM.Kisi nufusOrnek = new TNS.KPM.Kisi();

            if (!nufusList.sonuc.islemSonuc && nufusList.ObjeSayisi == 0)
            {
                throw new Exception(nufusList.sonuc.hataStr);
            }
            else if (nufusList.ObjeSayisi > 0)
                nufusOrnek = (TNS.KPM.Kisi)nufusList.objeler[0];
            else
            {
                throw new Exception(nufusList.sonuc.bilgiStr);
            }

            EkRtf ekRtf1 = new EkRtf();
            ekRtf1.InFile = this.sablonAd;
            ekRtf1.CreateVar("SERI", nufusOrnek.nufusCuzdani.nufusCuzdanSeri);
            ekRtf1.CreateVar("NUMARA", nufusOrnek.nufusCuzdani.nufusCuzdanNo);
            ekRtf1.CreateVar("TCKIMLIKNO", istek.tcKimlikNo);
            ekRtf1.CreateVar("CINSIYET", nufusOrnek.cinsiyetAciklama);
            ekRtf1.CreateVar("SOYADI", nufusOrnek.soyad);
            ekRtf1.CreateVar("ADI", nufusOrnek.ad);
            ekRtf1.CreateVar("BABAADI", nufusOrnek.babaAd);
            ekRtf1.CreateVar("ANAADI", nufusOrnek.anaAd);
            ekRtf1.CreateVar("DOGUMYERI", nufusOrnek.dogumYeri);
            ekRtf1.CreateVar("DOGUMTARIHI", nufusOrnek.dogumTarihi.Oku(), true);
            ekRtf1.CreateVar("MEDENIHALI", nufusOrnek.medeniHalAciklama);
            ekRtf1.CreateVar("DINI", "");
            ekRtf1.CreateVar("KANGRUBU", nufusOrnek.kanGrubu);
            ekRtf1.CreateVar("KIZLIKSOYADI", nufusOrnek.kizlikSoyad);
            ekRtf1.CreateVar("IL", nufusOrnek.kayitliOlduguYer.ilce.il.ad);
            ekRtf1.CreateVar("ILCE", nufusOrnek.kayitliOlduguYer.ilce.ad);
            ekRtf1.CreateVar("MAHALLEKOY", nufusOrnek.kayitliOlduguYer.mahalleKoy);
            ekRtf1.CreateVar("CILTNO", nufusOrnek.kayitliOlduguYer.ciltNo.ToString().PadLeft(4, '0'));
            ekRtf1.CreateVar("AILESIRA", nufusOrnek.kayitliOlduguYer.aileSiraNo.ToString().PadLeft(5, '0'));
            ekRtf1.CreateVar("BIREYSIRA", nufusOrnek.kayitliOlduguYer.bireySiraNo.ToString().PadLeft(4, '0'));
            ekRtf1.CreateVar("VERILDIGIYER", nufusOrnek.nufusCuzdani.verildigiYer);
            //ekRtf1.CreateVar("VERILISNEDENI", NufusCuzdani.VerilisNedeniAdiDondur(nufusOrnek.nufusCuzdani.verilisNedeni));
            ekRtf1.CreateVar("VERILISNEDENI", nufusOrnek.nufusCuzdani.verilisNedeniAciklama);
            ekRtf1.CreateVar("KAYITNO", nufusOrnek.nufusCuzdani.kayitNo);
            ekRtf1.CreateVar("VERILISTARIHI", nufusOrnek.nufusCuzdani.verilisTarihi.Oku(), true);

            ekRtf1.CreateVar("DUZENLEYENAD", txtDuzenleyenAdSoyad.Trim());
            ekRtf1.CreateVar("DUZENLEYENUNVAN", txtDuzenleyenUnvan.Trim());
            ekRtf1.CreateVar("ONAYLAYANAD", txtOnaylayanAdSoyad.Trim());
            ekRtf1.CreateVar("ONAYLAYANUNVAN", txtOnaylayanUnvan.Trim());

            ekRtf1.OutFile = sonucDosyaAd;
            ekRtf1.Execute();
            ekRtf1.ReportData.Clear();
            return sonucDosyaAd;
        }

        //İkametgah İl Muhaberi Yazdirma
        private string IkametgahIlmuhaberiYazdir(TNS.KPM.Istek istek)
        {
            ObjectArray ikametgahList = servisKPM.IkametgahRaporla(kullanan, istek);

            TNS.KPM.Kisi ikametgah = new TNS.KPM.Kisi();

            if (!ikametgahList.sonuc.islemSonuc && ikametgahList.ObjeSayisi == 0)
            {
                OrtakClass.GenelIslemler.MesajKutusu("Uyarı", "İkametgah bilgisi alınamadı<br>br>Hata:" + ikametgahList.sonuc.hataStr);
            }
            else if (ikametgahList.ObjeSayisi > 0)
                ikametgah = (TNS.KPM.Kisi)ikametgahList.objeler[0];
            else
            {
                OrtakClass.GenelIslemler.MesajKutusu("Bilgi", "İkametgah bilgisi alınamadı<br>br>Bilgi:" + ikametgahList.sonuc.bilgiStr);
            }

            bool servisVar = false;
            if (!string.IsNullOrWhiteSpace(ikametgah.adres.il))
                servisVar = true;
            else
                this.sablonAd = this.sablonAd.Replace("IkametgahIlmuhaberi.rtf", "IkametgahIlmuhaberiServisYok.rtf");

            EkRtf ekRtf1 = new EkRtf();
            ekRtf1.InFile = this.sablonAd;

            if (servisVar)
            {
                ekRtf1.CreateVar("ILI", ikametgah.adres.il);
                ekRtf1.CreateVar("ILCESI", ikametgah.adres.ilce);

                string bucak = "";
                try { bucak = ikametgah.adres.bucak; } catch { }

                ekRtf1.CreateVar("BUCAGI", bucak);
                ekRtf1.CreateVar("KOYU", ikametgah.adres.koy);
                ekRtf1.CreateVar("MAHALLESI", ikametgah.adres.mahalle);
                ekRtf1.CreateVar("SOKAK", ikametgah.adres.sokak);
                ekRtf1.CreateVar("NO", ikametgah.adres.numara);
                ekRtf1.CreateVar("DUZENLEYENAD", txtDuzenleyenAdSoyad.Trim());
                ekRtf1.CreateVar("DUZENLEYENUNVAN", txtDuzenleyenUnvan.Trim());
                ekRtf1.CreateVar("ONAYLAYANAD", txtOnaylayanAdSoyad.Trim());
                ekRtf1.CreateVar("ONAYLAYANUNVAN", txtOnaylayanUnvan.Trim());
            }
            else
            {
                ekRtf1.CreateVar("ADRES", ikametgah.adres.sokak);
            }

            ekRtf1.CreateVar("ADISOYADI", ikametgah.ad + " " + ikametgah.soyad);
            ekRtf1.CreateVar("BABAADI", ikametgah.babaAd);
            ekRtf1.CreateVar("ANNEADI", ikametgah.anaAd);
            ekRtf1.CreateVar("DOGUMYERI", ikametgah.dogumYeri);
            ekRtf1.CreateVar("DOGUMYILI", ikametgah.dogumTarihi.Yil.ToString());
            ekRtf1.CreateVar("MEDENIHALI", ikametgah.medeniHalAciklama);
            ekRtf1.CreateVar("ISI", "");


            ekRtf1.OutFile = sonucDosyaAd;
            ekRtf1.Execute();
            ekRtf1.ReportData.Clear();

            return sonucDosyaAd;
        }

        //Vukuatlı Nufus Kayit Ornegi Yazdirma
        private string VukuatliNufusKayitYazdir(TNS.KPM.Istek istek)
        {
            ObjectArray nufusList = servisKPM.VukuatliNufusKayitOrnekRaporla(kullanan, istek);

            TNS.KPM.Kisi nufusKisi = new TNS.KPM.Kisi();

            if (!nufusList.sonuc.islemSonuc)
            {
                throw new Exception(nufusList.sonuc.hataStr);
            }
            else if (nufusList.ObjeSayisi > 0)
                nufusKisi = (TNS.KPM.Kisi)nufusList.objeler[0];
            else
            {
                throw new Exception(nufusList.sonuc.bilgiStr);
            }

            EkRtf ekRtf1 = new EkRtf();
            ekRtf1.InFile = this.sablonAd;
            ekRtf1.CreateVar("ILI", nufusKisi.kayitliOlduguYer.ilce.il.ad);
            ekRtf1.CreateVar("ILCESI", nufusKisi.kayitliOlduguYer.ilce.ad);
            ekRtf1.CreateVar("MAHALLE_KOY", nufusKisi.kayitliOlduguYer.mahalleKoy);
            ekRtf1.CreateVar("CILTNO", nufusKisi.kayitliOlduguYer.ciltNo.ToString());
            ekRtf1.CreateVar("ASIRANO", nufusKisi.kayitliOlduguYer.aileSiraNo.ToString());
            ekRtf1.CreateVar("SIRANO", nufusKisi.kayitliOlduguYer.bireySiraNo.ToString());

            DataTable dtKisiBilgi = new DataTable();
            dtKisiBilgi.Columns.Add("sira");
            dtKisiBilgi.Columns.Add("yakinlikDerecesi");
            dtKisiBilgi.Columns.Add("tCKimlikNo");
            dtKisiBilgi.Columns.Add("adi");
            dtKisiBilgi.Columns.Add("soyadi");
            dtKisiBilgi.Columns.Add("babaAdi");
            dtKisiBilgi.Columns.Add("anaAdi");

            string[] satirDegerler = new string[7];

            int index = 1;
            foreach (AileFerdi af in nufusKisi.aileFertleri.objeler)
            {
                satirDegerler[0] = index.ToString(); ;
                satirDegerler[1] = "";// AileFerdi.YakinlikDerecesiAdiDondur(af.yakinlikDerecesi);
                satirDegerler[2] = af.tcKimlikNo;
                satirDegerler[3] = af.ad;
                satirDegerler[4] = af.soyad;
                satirDegerler[5] = af.babaAd;
                satirDegerler[6] = af.anaAd;
                dtKisiBilgi.Rows.Add(satirDegerler);
                index++;
            }
            ekRtf1.ReportData.Add(dtKisiBilgi, "vnko");
            ekRtf1.OutFile = sonucDosyaAd;
            ekRtf1.Execute();
            ekRtf1.ReportData.Clear();

            return sonucDosyaAd;
        }

        public static string AdSoyadGetir(Kullanici kullanan, IKYMServis servisKYM, string tcKimlikNo, out string hata)
        {
            hata = "";
            KullaniciVAN kVAN = servisKYM.MernisBilgiOku(kullanan, tcKimlikNo, new TNSDateTime());

            if (kVAN.sonuc.islemSonuc && !string.IsNullOrEmpty(kVAN.kullanici.ad + kVAN.kullanici.soyad))
                return kVAN.kullanici.ad + " " + kVAN.kullanici.soyad;
            else
            {
                hata = "Hata : " + kVAN.sonuc.hataStr;
                return null;
            }
        }

        public IKYMServis servisKYM { get; set; }
        public IKPMServis servisKPM { get; set; }
        public Kullanici kullanan { get; set; }
        public string sablonAd { get; set; }
        public string txtDuzenleyenAdSoyad { get; set; }
        public string txtDuzenleyenUnvan { get; set; }
        public string txtOnaylayanAdSoyad { get; set; }
        public string txtOnaylayanUnvan { get; set; }
        public string sonucDosyaAd { get; set; }
    }
}