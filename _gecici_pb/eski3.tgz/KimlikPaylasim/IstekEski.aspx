﻿<%@ Page Language="C#" CodeBehind="IstekEski.aspx.cs" Inherits="KimlikPaylasim.IstekEski" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
    <link href="../App_themes/popupDialog.css" type="text/css" rel="stylesheet" />
    <script language="javascript" type="text/javascript" src="../script/popupDialog.js?mc=03022015"></script>
    <script language="javascript" type="text/javascript" src="../script/popupDialog2.js?mc=03022015"></script>
    <script language="JavaScript" type="text/javascript" src="../script/XmlHttp.js?mc=03022015"></script>
    <script language="JavaScript" type="text/javascript" src="../script/genel.js?mc=03022015"></script>
    <script language="javascript" type="text/javascript" src="ModulScripts/Istek.js?mc=03022015"></script>
</head>
<body onload="BolumleriBoyutlandir()" onresize="BolumleriBoyutlandir()" onblur="DugmeAktifYap('btnYazdir');">
    <form id="form1" runat="server">
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <div class="form">
        <div class="row">
            <div class="yaziAlanK">
                T.C. Kimlik No&nbsp;<a href="http://tckimlik.nvi.gov.tr/Web/" target="_blank" tabindex="100"><img
                    alt="T.C. Kimlik Numarasını öğrenmek için lütfen buraya tıklayınız." src="../App_themes/images/dunya.gif" /></a></div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtTCKimlikNo" runat="server" MaxLength="11" CssClass="veriAlan"></asp:TextBox></div>
            <div class="kolonArasi">
            </div>
            <div class="veriAlan">
                <input type="button" id="imgKimlik" title="T.C. Kimlik Numarası girildikten sonra resme basıldığında adı ve soyadı otomatik olarak getirilecektir."
                    tabindex="100" runat="server" class="dugme" style="height: 17px; width: 22px;
                    background-image: url('../App_themes/images/kimlik4.gif')" onserverclick="imgKimlik_Click" /></div>
            <div class="kolonArasi">
            </div>
            <div class="veriAlan">
                <asp:Label ID="lblMernisAd" runat="server" CssClass="veriAlan" Width="100%"></asp:Label></div>
        </div>
        <div class="row">
            <div class="yaziAlanK">
                Rapor Türü</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:RadioButtonList ID="rblIstekTur" runat="server" RepeatDirection="horizontal">
                    <asp:ListItem Selected="True"></asp:ListItem>
                    <asp:ListItem></asp:ListItem>
                    <asp:ListItem></asp:ListItem>
                </asp:RadioButtonList>
            </div>
        </div>
        <div class="footer">
            &nbsp;</div>
    </div>
    <br />
    <div class="form">
        <div class="row">
            <div class="yaziAlan">
                Düzenleyen Adı Soyadı</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtDuzenleyenAdSoyad" runat="server" CssClass="veriAlan"></asp:TextBox></div>
            <div class="kolonArasi">
            </div>
            <div class="yaziAlan">
                Unvanı</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtDuzenleyenUnvan" runat="server" CssClass="veriAlan"></asp:TextBox></div>
        </div>
        <div class="row">
            <div class="yaziAlan">
                Onaylayan Adı Soyadı</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtOnaylayanAdSoyad" runat="server" CssClass="veriAlan"></asp:TextBox></div>
            <div class="kolonArasi">
            </div>
            <div class="yaziAlan">
                Unvanı</div>
            <div class="ikiNokta">
                :</div>
            <div class="veriAlan">
                <asp:TextBox ID="txtOnaylayanUnvan" runat="server" CssClass="veriAlan"></asp:TextBox></div>
        </div>
        <div class="footer">
            &nbsp;</div>
    </div>
    <div style="float: left">
        <asp:Button ID="btnYazdir" OnClick="btnYazdir_Click" runat="server" Text="Rapor Yazdır"
            CssClass="dugme" />
        <asp:Button ID="btnListele" OnClick="btnListele_Click" runat="server" Text="Tarihçe Listele"
            CssClass="dugme" /></div>
    <div style="float: right">
        <asp:Label ID="lblKacKayit" runat="server" CssClass="veriAlan" /></div>
    <table width="100%" cellpadding="2" cellspacing="2">
        <tr>
            <td align="center">
                <div id="divListe" style="overflow: auto; height: 250px;">
                    <asp:DataGrid ID="dgListe" runat="server" AllowCustomPaging="false" AllowSorting="false"
                        AutoGenerateColumns="False" BorderWidth="0" CellPadding="3" Font-Bold="False"
                        Font-Italic="False" Font-Names="Tahoma" Font-Overline="False" Font-Size="8pt"
                        Font-Strikeout="False" Font-Underline="False" ForeColor="#333333" PageSize="1"
                        Width="97%">
                        <AlternatingItemStyle BackColor="White" ForeColor="#284775" />
                        <ItemStyle BackColor="#F7F6F3" ForeColor="#333333" HorizontalAlign="Left" />
                        <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" Font-Italic="False" Font-Names="Tahoma"
                            Font-Overline="False" Font-Size="8pt" Font-Strikeout="False" Font-Underline="False"
                            ForeColor="White" HorizontalAlign="Center" VerticalAlign="Middle" />
                        <Columns>
                            <asp:BoundColumn DataField="tcKimlikNo" HeaderText="TC Kimlik No" ItemStyle-Width="200">
                            </asp:BoundColumn>
                            <asp:BoundColumn DataField="istekTur" HeaderText="İstek Türü" ItemStyle-Width="150">
                            </asp:BoundColumn>
                            <asp:BoundColumn DataField="islemTarih" HeaderText="En Son İşlem Tarihi" ItemStyle-Width="120" />
                            <asp:BoundColumn DataField="islemYapan" HeaderText="En Son İşlem Yapan" ItemStyle-Width="100" />
                        </Columns>
                    </asp:DataGrid>
                </div>
            </td>
        </tr>
    </table>
    <br />
    <div class="bilgiKutusu">
        <li>&nbsp;&nbsp;Sorgulama sonucunda elde edilen tüm nüfus ve adres bilgilerini sadece
            Bakanlık iş süreçleri içerisinde kullanılmalıdır.</li>
        <li>&nbsp;&nbsp;Yapılan sorgulamalar, sorgulanan kişi, sorgulayan kişi ve sorgulama
            tarihi olarak kayıt altına alınmaktadır.</li>
    </div>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
    <script>
        function BolumleriBoyutlandir(frmID) {
            var scrWH = windowSize();
            var srcWHA = scrWH.split('x');
            var scrW = srcWHA[0];
            var scrH = srcWHA[1];
            var eleT = getElementTop("divListe");
            var h = Number(scrH) - Number(eleT) - 120;
            document.getElementById("divListe").style.height = h + "px";
        }
    </script>
</body>
</html>
