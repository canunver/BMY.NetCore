﻿<%@ Page Language="C#" CodeBehind="Sorgulama.aspx.cs" Inherits="KimlikPaylasim.Sorgulama" %>

<%@ Register Assembly="Ext1.Net" Namespace="Ext1.Net" TagPrefix="ext" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="../App_themes/Form.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <form id="form" runat="server">
    <ext:ResourceManager ID="ResourceManager1" runat="server" />
    <asp:Literal ID="ltlUstBolum" runat="server"></asp:Literal>
    <ext:Viewport ID="Viewport1" runat="server" StyleSpec="background-color: transparent;">
        <Items>
            <ext:BorderLayout ID="BorderLayout1" runat="server">
                <Center MarginsSummary="104 20 10 20">
                    <ext:Panel ID="tabPanelAna" runat="server" StyleSpec="background-color:white;padding:10px">
                        <TopBar>
                            <ext:Toolbar ID="Toolbar1" runat="server">
                                <Items>
                                    <ext:Button ID="btnYazdir" runat="server" Text="Yazdır" Icon="Printer">
                                        <DirectEvents>
                                            <Click OnEvent="btnYazdir_Click" IsUpload="true" />
                                        </DirectEvents>
                                    </ext:Button>
                                </Items>
                            </ext:Toolbar>
                        </TopBar>
                        <Items>
                            <ext:FormPanel ID="formPanelAna" runat="server" Frame="true" Padding="5" LabelWidth="120">
                                <Items>
                                    <ext:TextField runat="server" ID="txtTCKimlikNo" MaxLength="11" Width="100" FieldLabel="T.C. Kimlik No" />
                                    <ext:TextField runat="server" ID="txtIslemYapan" Width="155" FieldLabel="İşlem Yapan Kullanıcı" />
                                    <ext:CompositeField runat="server" FieldLabel="Tarih">
                                        <Items>
                                            <ext:DateField ID="txtTarih1" runat="server" />
                                            <ext:Label runat="server" Text="ile" Margins="3 3 0 0" />
                                            <ext:DateField ID="txtTarih2" runat="server" />
                                            <ext:Label ID="Label1" runat="server" Text="arasında" Margins="3 3 0 0" />
                                        </Items>
                                    </ext:CompositeField>
                                </Items>
                            </ext:FormPanel>
                        </Items>
                    </ext:Panel>
                </Center>
            </ext:BorderLayout>
        </Items>
    </ext:Viewport>
    <asp:Literal ID="ltlAltBolum" runat="server"></asp:Literal>
    </form>
</body>
</html>
