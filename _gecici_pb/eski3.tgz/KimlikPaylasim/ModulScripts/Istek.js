﻿function AdSil()
{
    if (document.getElementById('txtTCKimlikNo').value.length==0)
        document.getElementById('lblMernisAd').innerHTML="";
    else if (document.getElementById('txtTCKimlikNo').value.length==11 && document.getElementById('lblMernisAd').innerHTML.indexOf('<')==0)
        document.getElementById('lblMernisAd').innerHTML="";
    else if (document.getElementById('txtTCKimlikNo').value.length!=11)
        document.getElementById('lblMernisAd').innerHTML="<b>Hata : </b>Verilen kimlik numarası hatalı.";
}

//function Yazdir(satir)
//{
//    __doPostBack('Yazdir', satir);
//}

//function ListeSec()
//{
//    var kontrol=document.getElementById('dgListe');
//    
//    if (kontrol)
//    {
//	    for (var i=1; i<kontrol.rows.length ;i++)
//	    {
//            var chkId = "dgListe$ctl";

//	        var chkTemp ="";
//	        if(i<9)
//	            chkTemp = "0" + (i+1).toString();
//	        else
//	            chkTemp = (i+1).toString();
//	        
//	        chkId = chkId + chkTemp + "$chkSecim";
//	        if (i==1)
//        	    secim=!document.getElementById(chkId).checked;

//		    document.getElementById(chkId).checked=secim;
//		}
//    }
//}

function MuhasebeGoster()
{
    try{document.getElementById('lblHata').innerHTML="";}
    catch (e){}
    
    showPopWin("../ButceMuhasebe/ListeMuhasebeBirim.aspx", 500, 300, true, null);
}

function MuhasebeBirimGoster()
{
    try{document.getElementById('lblHata').innerHTML="";}
    catch (e){}

    var muhasebe=document.getElementById('txtMuhasebe').value;

    showPopWin("../ButceMuhasebe/ListeMuhasebeBirim.aspx?muhasebe=" + muhasebe, 500, 300, true, null);
}
