﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using TNS;
using OrtakClass;
using TNS.KYM;
using TNS.KPM;
using EkRtfReport;
using Ext1.Net;
using System.Collections.Generic;
using TNS.Raporlama;

namespace KimlikPaylasim
{
    public partial class Istek : istemciUzayi.GenelSayfa
    {
        IKPMServis servisKPM = TNS.KPM.Arac.Tanimla();
        IKYMServis servisKYM = TNS.KYM.Arac.Tanimla();

        protected void Page_Load(object sender, EventArgs e)
        {
            formAdi = "Kimlik Paylaşım";
            kullanan = OturumBilgisiIslem.KullaniciBilgiOku(true);
            SayfaUstAltBolumYaz(this);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "mainYok", "<style type='text/css'>#main{display: none;}</style>");

            //Sayfaya giriş izni varmı?
            if (!TNS.KPM.Yetki.TeftisPersoneliMi(kullanan))
                GenelIslemler.SayfayaGirisYapabilirMi(kullanan, this);

            if (!IsPostBack)
            {
                if (Request.QueryString["menuYok"] + "" != "")
                    tabPanelAna.Margins = "0 0 0 0";

                rb1.BoxLabel = TNS.KPM.Istek.IstekTurAdiDondur((int)ENUMIstekTur.IKAMETGAH);
                rb2.BoxLabel = TNS.KPM.Istek.IstekTurAdiDondur((int)ENUMIstekTur.NUFUSCUZDANORNEK);
                rb3.BoxLabel = TNS.KPM.Istek.IstekTurAdiDondur((int)ENUMIstekTur.VUKUATLINUFUSKAYITORNEK);

                txtDuzenleyenAdSoyad.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKDUZENLEYENAD");
                txtDuzenleyenUnvan.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKDUZENLEYENUNVAN");
                txtOnaylayanAdSoyad.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKONAYLAYANAD");
                txtOnaylayanUnvan.Text = GenelIslemler.KullaniciDegiskenGetir(kullanan.kullaniciKodu, "KIMLIKONAYLAYANUNVAN");
            }

            if (string.IsNullOrEmpty(txtTCKimlikNo.Text.Trim()))
                lblMernisAd.Text = "";
        }

        protected void btnYazdir_Click(object sender, DirectEventArgs e)
        {
            if (rbIstekTur.CheckedItems.Count <= 0)
            {
                GenelIslemler.HataYaz(this, "Rapor türünü seçiniz.");
                return;
            }

            GenelIslemler.KullaniciDegiskenSakla(kullanan, "KIMLIKDUZENLEYENAD", txtDuzenleyenAdSoyad.Text.Trim());
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "KIMLIKDUZENLEYENUNVAN", txtDuzenleyenUnvan.Text.Trim());
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "KIMLIKONAYLAYANAD", txtOnaylayanAdSoyad.Text.Trim());
            GenelIslemler.KullaniciDegiskenSakla(kullanan, "KIMLIKONAYLAYANUNVAN", txtOnaylayanUnvan.Text.Trim());

            int istekTur = OrtakFonksiyonlar.ConvertToInt(rbIstekTur.CheckedItems[0].InputValue, 1);

            System.Collections.Hashtable raporParam = new Hashtable();
            raporParam["TCKimlikNo"] = txtTCKimlikNo.Text.Trim();
            raporParam["DUZENLEYENAD"] = txtDuzenleyenAdSoyad.Text.Trim();
            raporParam["DUZENLEYENUNVAN"] = txtDuzenleyenUnvan.Text.Trim();
            raporParam["ONAYLAYANAD"] = txtOnaylayanAdSoyad.Text.Trim();
            raporParam["ONAYLAYANUNVAN"] = txtOnaylayanUnvan.Text.Trim();

            RaporlamaServis.TekRaporAl(500, istekTur, kullanan, null, raporParam);
        }

        protected void btnListele_Click(object sender, DirectEventArgs e)
        {
            Listele();
        }

        private void Listele()
        {
            TNS.KPM.Istek istek = new TNS.KPM.Istek();
            istek.tcKimlikNo = txtTCKimlikNo.Text.Trim();
            istek.islemYapan = kullanan.kullaniciKodu;
            istek.islemTarih.Yaz(DateTime.Today.Date);

            ObjectArray istekVAN = servisKPM.IstekListele(kullanan, istek);
            if (!istekVAN.sonuc.islemSonuc)
            {
                GenelIslemler.MesajKutusu(this, istekVAN.sonuc.hataStr);

                lblKacKayit.Visible = false;
                return;
            }
            if (istekVAN.objeler.Count <= 0)
            {
                GenelIslemler.MesajKutusu(this, istekVAN.sonuc.bilgiStr);

                lblKacKayit.Visible = false;
                return;
            }

            List<object> tipler = new List<object>();





            foreach (TNS.KPM.Istek i in istekVAN.objeler)
            {
                string link = i.tcKimlikNo + " - " + i.adSoyad;
                tipler.Add(new
                {
                    TC = link,
                    TUR = i.istekTurAd,
                    TARIH = i.islemTarih.ToString(),
                    KULLANAN = i.islemYapan
                });
            }

            ListeStore.DataSource = tipler;
            ListeStore.DataBind();

            lblKacKayit.Visible = true;
            lblKacKayit.Text = "Arama sonucunda " + istekVAN.objeler.Count.ToString() + " kayıt bulundu.";
        }

        protected void imgKimlik_Click(object sender, DirectEventArgs e)
        {
            string hata;
            string adSoyad = NufusYazdir.AdSoyadGetir(kullanan, servisKYM, txtTCKimlikNo.Text.Trim(), out hata);
            if (!string.IsNullOrEmpty(adSoyad))
                lblMernisAd.Text = adSoyad;
        }
    }
}