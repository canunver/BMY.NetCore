﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TNS.HRC;
using OrtakClass;
using TNS;
using System.Collections;
using System.Threading;
using TNS.KYM;
using TNS.IKY;
using Ext1.Net;
using TNS.Raporlama;

namespace HarcamaSurecleri
{
    public class DegiskenGrup
    {
        internal int yer;
        internal int yerTur;
        internal VariableType veriTipi;
        private string _tipStr = "";
        public string tipStr { get { return _tipStr; } set { _tipStr = value; VeriTipiOl(); } }

        public DegiskenGrup(string ad, string aciklama, string tipStr, bool islem)
        {
            this.ad = ad;
            this.aciklama = aciklama;
            this.tipStr = tipStr;

            this.islem = islem;
        }

        public DegiskenGrup()
        {
            this.ad = "";
            this.aciklama = "";
            this.tipStr = "";
            this.islem = false;
        }

        private void VeriTipiOl()
        {
            if (this.tipStr == "Tamsayı")
                veriTipi = VariableType.Integer;
            else if (this.tipStr == "Yazı")
                veriTipi = VariableType.String;
            else if (this.tipStr == "Para")
                veriTipi = VariableType.Money;
            else if (this.tipStr == "Tarih")
                veriTipi = VariableType.Date;
            else
                veriTipi = VariableType.Bilinmiyor;
        }

        public string ad { get; set; }
        public string aciklama { get; set; }
        public bool islem { get; set; }
    }

    public class NesneListesi : IComparable
    {
        ArrayList al = new ArrayList();

        public object this[int index]
        {
            get { return al[index]; }
            set { al[index] = value; }
        }

        public void Ekle(object o)
        {
            al.Add(o);
        }
        public int Length { get { return al.Count; } }

        public int CompareTo(object obj)
        {
            if (obj is NesneListesi)
            {
                NesneListesi gListe = (NesneListesi)obj;

                for (int i = 0; i < Math.Min(this.Length, gListe.Length); i++)
                {
                    int tut = Kiyasla(this[i], gListe[i]);
                    if (tut != 0) return tut;
                }
                return 0;
            }
            return 1;
        }

        private int Kiyasla(object p1, object p2)
        {
            if (p1 == null && p2 == null) return 0;
            if (p1 == null) return -1;
            if (p2 == null) return 1;
            if (p1.GetType() != p2.GetType()) return -1;
            if (p1 is int) return ((int)p1).CompareTo((int)p2);
            if (p1 is double) return ((double)p1).CompareTo((double)p2);
            if (p1 is string) return ((string)p1).CompareTo((string)p2);
            if (p1 is DateTime) return ((DateTime)p1).CompareTo((DateTime)p2);
            return 0;
        }

        private static object Topla(object p1, object p2)
        {
            if (p1 == null) return p2;
            if (p2 == null) return p1;
            if (p1.GetType() != p2.GetType()) return null;
            if (p1 is int) return ((int)p1 + (int)p2);
            if (p1 is double) return ((double)p1 + (double)p2);
            if (p1 is string) return null;
            if (p1 is DateTime) return null;
            return null;
        }

        internal void Topla(NesneListesi toplamlar)
        {
            for (int i = 0; i < this.Length; i++)
            {
                this[i] = Topla(this[i], toplamlar[i]);
            }
        }
    }

    public class BordroRaporlari : IRapor
    {
        public static Hashtable ht = new Hashtable();
        public static string[] genelAlanlar = { "Yil", "Ay", "AyAd", "SayKod", "SayAd", "BirKod", "BirAd", "SayBirAd", "SurecYil", "SurecNo", "BordroTur", "OdemeTarih", "DYil", "DAy", "DAyAd", "PersonelTipAd", "EPosta", "MuhasebatNo", "BordroIslemAd", "gorevYeri", "birimYeri", "SendikaKod", "SendikaAd", "SendikaAdres", "SendikaIBAN", "DIlkGun", "DSonGun", "Hazirlayan", "OnayaSunan", "Onaylayan" };
        public static string[] genelTipler = { "Tamsayı", "Tamsayı", "Yazı", "Tamsayı", "Yazı", "Yazı", "Yazı", "Yazı", "Tamsayı", "Yazı", "Tamsayı", "Tarih", "Tamsayı", "Tamsayı", "Yazı", "Yazı", "Yazı", "Yazı", "Yazı", "Yazı", "Yazı", "Tamsayı", "Yazı", "Yazı", "Yazı", "Tarih", "Tarih", "Yazı", "Yazı", "Yazı" };
        public static string[] genelEtiketler = { "Yıl", "Ay", "Ay Adı", "Saymanlık Kodu", "Saymanlık Adı", "Birim Kodu", "Birim Adı", "Saymanlık Birim Adı", "Sureç Yılı", "Sureç No", "Bordro Türü", "Ödeme Tarihi", "Dönem Yılı", "Dönem Ay", "Dönem Ay Adı", "Personel Tip Adı", "ePosta Adresi", "Muhasebat No", "Ödeme Türü", "Görev Yeri", "Kadro Yeri", "Sendika Kodu", "Sendika Adı", "Sendika Adresi", "Hesap No/IBAN", "Dönem İlk Günü", "Dönem Son Günü", "Hazırlayan", "Onaya Sunan", "Onaylayan" };

        public static bool PersonelAranacakMi(int genelAlanNo)//genelAlanNo
        {
            return (genelAlanNo == 15 || genelAlanNo == 16 || genelAlanNo == 17 || genelAlanNo == 19 || genelAlanNo == 20);
        }

        public static void OrtakDegerBul(int ii, KisiSatir kisiSatir, BordroYapi by, ref object o, ref VariableType vt, ObjectArray personeller, int sendikaBilgiYer)
        {
            if (kisiSatir.kisiSatirBilgi != null)
            {
                if (ii == 0) { o = kisiSatir.kisiSatirBilgi.odemeTarih.Yil; vt = VariableType.Integer; }
                else if (ii == 1) { o = kisiSatir.kisiSatirBilgi.odemeTarih.Ay; vt = VariableType.Integer; }
                else if (ii == 2) { o = GenelIslemler.AyAdDondur(kisiSatir.kisiSatirBilgi.odemeTarih.Ay); }
                else if (ii == 3) { o = kisiSatir.kisiSatirBilgi.muhasebeKod; vt = VariableType.Integer; }
                else if (ii == 4) { o = kisiSatir.kisiSatirBilgi.muhasebeAd; }
                else if (ii == 5) { o = kisiSatir.kisiSatirBilgi.birimKod; }
                else if (ii == 6) { o = kisiSatir.kisiSatirBilgi.birimAd; }
                else if (ii == 7) { o = TNS.MUH.Arac.BirimAdOl(kisiSatir.kisiSatirBilgi.muhasebeAd, kisiSatir.kisiSatirBilgi.birimAd); }
                else if (ii == 8) { o = kisiSatir.kisiSatirBilgi.surecYil; vt = VariableType.Integer; }
                else if (ii == 9) { o = kisiSatir.kisiSatirBilgi.surecNo; }
                else if (ii == 11) { o = kisiSatir.kisiSatirBilgi.odemeTarih.Oku(); vt = VariableType.Date; }
                else if (ii == 12) { o = kisiSatir.kisiSatirBilgi.oncBordroTarih.Yil; vt = VariableType.Integer; }
                else if (ii == 13) { o = kisiSatir.kisiSatirBilgi.oncBordroTarih.Ay; vt = VariableType.Integer; }
                else if (ii == 14) { o = GenelIslemler.AyAdDondur(kisiSatir.kisiSatirBilgi.oncBordroTarih.Ay); }
                else if (ii == 25) { o = kisiSatir.kisiSatirBilgi.oncBordroTarih.Oku(); }
                else if (ii == 26) { o = kisiSatir.kisiSatirBilgi.oncBordroTarih.Oku().AddMonths(1).AddDays(-1); }
                else if (ii == 27) { o = kisiSatir.kisiSatirBilgi.hazirlayan; }
                else if (ii == 28) { o = kisiSatir.kisiSatirBilgi.onayaSunan; }
                else if (ii == 29) { o = kisiSatir.kisiSatirBilgi.onaylayan; }

            }
            if (ii == 10) { o = by.bordroTur; vt = VariableType.Integer; }
            else if (PersonelAranacakMi(ii))
            {
                o = kisiselBilgiBul(kisiSatir, personeller, ii);
                vt = VariableType.String;
            }
            else if (ii == 18)
            {
                o = BordroIslemTur.TurYapiAdBul((BordroIslemTur.ENUMBordroIslemTurYapi)by.bordroIslemTur);
                vt = VariableType.String;
            }
            else if (ii == 21)
            {
                o = SendikaNoBul(kisiSatir, by, sendikaBilgiYer);
                vt = VariableType.Integer;
            }
            else if (ii == 22 || ii == 23 || ii == 24)
            {
                vt = VariableType.String;
                int sn = SendikaNoBul(kisiSatir, by, sendikaBilgiYer);
                SendikaBilgi sb = TNS.IKY.Arac.SendikaBilgi(sn);
                if (sb != null)
                {
                    switch (ii)
                    {
                        case 22:
                            o = sb.sendikaAd;
                            break;
                        case 23:
                            o = sb.adres;
                            break;
                        case 24:
                            o = sb.iBAN;
                            break;
                        default:
                            break;
                    }
                }
                else
                    o = null;
            }
        }

        private static int SendikaNoBul(KisiSatir kisiSatir, BordroYapi by, int sendikaBilgiYer)
        {
            if (sendikaBilgiYer >= 0)
            {
                string s = (string)kisiSatir.degerler[sendikaBilgiYer];
                return OrtakFonksiyonlar.ConvertToInt(s.Split('-')[0], 0);
            }
            return -1;
        }

        private static string kisiselBilgiBul(KisiSatir kisiSatir, ObjectArray personeller, int id)
        {
            if (personeller != null && personeller.objeler != null)
            {
                foreach (TNS.IKY.Personel item in personeller.objeler)
                {
                    if (item.tcKimlikNo == (string)kisiSatir.degerler[0])
                    {
                        if (id == 15)
                            return item.personelTipAd;
                        else if (id == 16)
                            return item.iletisim.eposta;
                        else if (id == 19)
                            return item.kadro.birimGorevAd;
                        else if (id == 20)
                            return item.birimAd;
                        else
                            return item.geldigiKurumSicili;
                    }
                }
            }
            return "";
        }

        //public static string PTipAdBul(KisiSatir kisiSatir, int pTip)
        //{
        //    if (pTip > 0)
        //    {
        //        TNS.IKY.PersonelTipi pt = TNS.IKY.Arac.PersonelTipBul(((int)kisiSatir.degerler[pTip]));
        //        if (pt != null) return pt.ad;
        //    }
        //    return "";
        //}

        public string RaporAl(object o_kullanan, object servis, string sablonAd, string sonucDosyaAd, string ciktiYeri, Hashtable raporParam, string ekBilgi)
        {

            Kullanici kullanan = (Kullanici)o_kullanan;
            IHRCServis servisHRC = TNS.HRC.Arac.Tanimla();
            sonucDosyaAd = DosyaIslem.DosyaAdUret("", "") + ".xlsx";

            BordroSablonDosya bsd = new BordroSablonDosya();

            bsd.bordroTur = 0;
            bsd.islemTur = 0;
            bsd.sablonKod = OrtakFonksiyonlar.ConvertToInt((string)raporParam["sablonNo"], 0);
            if (bsd.sablonKod > 0)
                sablonAd = System.IO.Path.Combine(BordroTanim.DosyaYol(false), bsd.SablonDosyaAd);

            BordroKistas bordroKistas = new BordroKistas(0, null, new TNSCollection((string)raporParam["tcKimlikNo"]));
            bordroKistas.donemYil = OrtakFonksiyonlar.ConvertToInt((string)raporParam["yil"], 0);
            bordroKistas.donemAy = OrtakFonksiyonlar.ConvertToInt((string)raporParam["ay"], 0);

            bordroKistas.bordroTur = OrtakFonksiyonlar.ConvertToInt((string)raporParam["bTur"], 0);
            bordroKistas.bordroIslem = OrtakFonksiyonlar.ConvertToInt((string)raporParam["bIslem"], 0);

            Tablo XLS = GenelIslemler.NewTablo();

            XLS.DosyaAc(sablonAd, sonucDosyaAd);

            try
            {

                int satir = 0;
                int sutun = 0;

                XLS.HucreAdBulYaz("Yil", bordroKistas.donemYil);
                XLS.HucreAdBulYaz("Ay", bordroKistas.donemAy);
                XLS.HucreAdBulYaz("AyAd", OrtakFonksiyonlar.AyAdiGetir(bordroKistas.donemAy));

                XLS.HucreAdAdresCoz("BaslaSatir", ref satir, ref sutun);

                int bordroSatBasla = 0, bordroSutBasla = 0, bordroSatBit = 0, bordroSutBit = 0;
                int bordroSatBasla2 = 0, bordroSutBasla2 = 0, bordroSatBit2 = 0, bordroSutBit2 = 0;
                int gtSatBasla = 0, gtSutBasla = 0, gtSatBit = 0, gtSutBit = 0;
                int stSatBasla = 0, stSutBasla = 0, stSatBit = 0, stSutBit = 0;
                int sheetNo = 0;
                int sheetNo2 = 0;
                XLS.HucreAdAdresCoz("BordroSatir", ref sheetNo, ref bordroSatBasla, ref bordroSutBasla, ref bordroSatBit, ref bordroSutBit);
                int satirSay = bordroSatBit - bordroSatBasla + 1;
                XLS.HucreAdAdresCoz("BordroSatir2", ref sheetNo2, ref bordroSatBasla2, ref bordroSutBasla2, ref bordroSatBit2, ref bordroSutBit2);
                if (bordroSatBasla2 < 1)
                {
                    sheetNo2 = sheetNo;
                    bordroSatBasla2 = bordroSatBasla;
                    bordroSutBasla2 = bordroSutBasla;
                    bordroSatBit2 = bordroSatBit;
                    bordroSutBit2 = bordroSutBit;
                }
                int siraSatir = 0, siraSutun = 0, siraSatirBit = 0, siraSutunBit = 0;
                XLS.HucreAdAdresCoz("SayfaToplam", ref sheetNo, ref stSatBasla, ref stSutBasla, ref stSatBit, ref stSutBit);
                XLS.HucreAdAdresCoz("GenelToplam", ref sheetNo, ref gtSatBasla, ref gtSutBasla, ref gtSatBit, ref gtSutBit);
                XLS.HucreAdAdresCoz("SiraNo", ref sheetNo, ref siraSatir, ref siraSutun, ref siraSatirBit, ref siraSutunBit);
                siraSatir = siraSatir - bordroSatBasla;
                siraSutun = siraSutun - bordroSutBasla;
                siraSatirBit = siraSatirBit - bordroSatBasla;
                siraSutunBit = siraSutunBit - bordroSutBasla;

                int satirYuk = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("SatirYuk"), -1);
                if (satirYuk > 0) satirYuk = satirYuk * 1010;
                int toplamAyniSayfada = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("ToplamAyniSayfada"), 0);
                string tut = XLS.HucreAdDegerAl("SayfaKisi");
                int sayfaKisi = OrtakFonksiyonlar.ConvertToInt(tut, 0);

                bordroKistas.siralama = XLS.HucreAdDegerAl("Siralama");
                ObjectArray oa;
                try
                {
                    oa = servisHRC.CalisanDinamikBordroListele(kullanan, bordroKistas);
                }
                catch (Exception e)
                {
                    XLS.HucreDegerYaz(0, 0, e.Message);
                    XLS.DosyaSaklaTamYol();
                    return sonucDosyaAd;
                }
                int[,] satirYerler = null;
                int[,] satirYerlerOnc = null;
                bool oncVar = false;
                BordroYapi by = null;
                int ilkSatir = satir;

                ToplamAl t = new ToplamAl(3, 200);
                ToplamAl tGrup = new ToplamAl(1, 200);
                bool tek = true;
                bool ilk = true;
                int j = 0;
                foreach (CalisanDinamikBordroDonem item in oa.objeler)
                {
                    if (ilk)
                    {
                        ilk = false;
                        XLS.HucreAdBulYaz("DYil", item.bordroDonemBasTarihDT.Year);
                        XLS.HucreAdBulYaz("DAy", item.bordroDonemBasTarihDT.Month);
                        XLS.HucreAdBulYaz("DAyAd", GenelIslemler.AyAdDondur(item.bordroDonemBasTarihDT.Month));

                        XLS.HucreAdBulYaz("SayKod", item.muhasebeKod);
                        XLS.HucreAdBulYaz("SayAd", item.muhasebeAd);
                        XLS.HucreAdBulYaz("BirKod", item.birimKod);
                        XLS.HucreAdBulYaz("BirAd", item.birimAd);
                        XLS.HucreAdBulYaz("SayBirAd", TNS.MUH.Arac.BirimAdOl(item.muhasebeAd, item.birimAd));
                        PSLDinBordroOrtak.TarihYaz(XLS, "DIlkGun", item.bordroDonemBasTarihDT);
                        PSLDinBordroOrtak.TarihYaz(XLS, "DSonGun", item.sonGunDT);
                    }
                    //bool pTipAdBul = false;
                    bool pKisiselBilgi = false;
                    ObjectArray personeller;

                    by = item.bordroYapi;
                    satirYerler = new int[by.hepsi.Length + 1 + genelAlanlar.Length, 12]; //+1 tckimlikno icin
                    satirYerlerOnc = new int[by.hepsi.Length + 1 + genelAlanlar.Length, 12]; //+1 tckimlikno icin
                    int sendikaBilgiYer = -1;
                    for (int i = 0; i < by.hepsi.Length + 1 + genelAlanlar.Length; i++)
                    {
                        string ad;
                        int genelAlanNo = i - (by.hepsi.Length + 1);
                        if (i == 0) ad = "tckimlikno";
                        else if (genelAlanNo >= 0) ad = genelAlanlar[genelAlanNo];
                        else ad = by.hepsi[i - 1].ad;

                        if (ad == "sendikaBilgi")
                            sendikaBilgiYer = i;

                        PSLDinBordroOrtak.AdresCoz(XLS, "a_" + ad, satirYerler, i, 0, bordroSatBasla, bordroSutBasla, bordroSatBit, bordroSutBit);
                        PSLDinBordroOrtak.AdresCoz(XLS, "s_" + ad, satirYerler, i, 4, stSatBasla, stSutBasla, stSatBit, stSutBit);
                        PSLDinBordroOrtak.AdresCoz(XLS, "t_" + ad, satirYerler, i, 8, gtSatBasla, gtSutBasla, gtSatBit, gtSutBit);

                        PSLDinBordroOrtak.AdresCoz(XLS, "o_a_" + ad, satirYerlerOnc, i, 0, bordroSatBasla, bordroSutBasla, bordroSatBit, bordroSutBit);
                        PSLDinBordroOrtak.AdresCoz(XLS, "o_s_" + ad, satirYerlerOnc, i, 4, stSatBasla, stSutBasla, stSatBit, stSutBit);
                        PSLDinBordroOrtak.AdresCoz(XLS, "o_t_" + ad, satirYerlerOnc, i, 8, gtSatBasla, gtSutBasla, gtSatBit, gtSutBit);
                        if (!oncVar && satirYerlerOnc[i, 0] >= 0) oncVar = true;
                        if ((satirYerler[i, 0] >= 0))
                        {
                            if (!pKisiselBilgi && PersonelAranacakMi(genelAlanNo))
                                pKisiselBilgi = true;
                        }
                    }
                    if (oncVar)
                    {
                        PSLDinBordroOrtak.OncekiIleBirlestir(servisHRC, kullanan, item.calisanDinamikBordro, by, item.yil, item.surecNo, null);
                    }

                    KisiselVerileriBul(kullanan, out personeller, item);

                    int alanNo = 0;
                    int kosulIndeks = -1;
                    double degerDbl = 0;
                    string kosulAlan = XLS.HucreAdDegerAl("DoluAlan");
                    if (!string.IsNullOrWhiteSpace(kosulAlan))
                    {
                        int kosulYer;
                        PSLDinBordroOrtak.YerBul(kosulAlan, PSLDinBordroOrtak.kosullar, out kosulIndeks, out kosulYer);
                        if (kosulIndeks >= 0 && kosulYer > 0)
                        {
                            string alan = kosulAlan.Substring(0, kosulYer);
                            alanNo = by.YerBul(alan, 0) + 1;
                            if (alanNo == 0) alanNo = -1000;
                            string deger = kosulAlan.Substring(kosulYer + PSLDinBordroOrtak.kosullar[kosulIndeks].Length);
                            degerDbl = OrtakFonksiyonlar.ConvertToDbl(deger);
                        }
                    }

                    for (int jj = 0; jj < item.calisanDinamikBordro.kisiDegerler.Count; jj++)
                    {
                        KisiSatir kisiSatir = (KisiSatir)item.calisanDinamikBordro.kisiDegerler[jj];
                        object[] degerler = kisiSatir.degerler;

                        if (!PSLDinBordroOrtak.YazilsinMi(degerler, alanNo, kosulIndeks, degerDbl)) continue;

                        if (tek)
                            XLS.HucreKopyala(bordroSatBasla, bordroSutBasla, bordroSatBit, bordroSutBit, satir, sutun);
                        else
                            XLS.HucreKopyala(bordroSatBasla2, bordroSutBasla2, bordroSatBit2, bordroSutBit2, satir, sutun);
                        tek = !tek;
                        if (siraSatir >= 0 && siraSutun >= 0)
                        {
                            XLS.HucreDegerYaz(satir + siraSatir, sutun + siraSutun, j + 1);
                        }

                        for (int i = by.hepsi.Length + genelAlanlar.Length; i >= 0; i--)
                        {
                            int simdOncSay = oncVar ? 2 : 1;
                            for (int simdOnc = 0; simdOnc < simdOncSay; simdOnc++)
                            {
                                int satIc = 0, sutIc = 0;
                                PSLDinBordroOrtak.AdresCoz(simdOnc == 0 ? satirYerler : satirYerlerOnc, i, 0, satir, sutun, ref satIc, ref sutIc);
                                if (satIc > 0)
                                {
                                    string ad;
                                    VariableType vt = VariableType.String;
                                    object o = (string)null;
                                    int ii = -1;
                                    if (i >= by.hepsi.Length + 1)
                                    {
                                        //if (kisiSatir.kisiSatirBilgi != null)
                                        {
                                            ii = i - (by.hepsi.Length + 1);
                                            ad = genelAlanlar[ii];
                                            OrtakDegerBul(ii, kisiSatir, by, ref o, ref vt, personeller, sendikaBilgiYer);
                                        }
                                    }
                                    else
                                    {
                                        if (simdOnc == 0 && degerler != null)
                                            o = degerler[i];
                                        else if (simdOnc == 1 && kisiSatir.degerlerOnc != null)
                                            o = kisiSatir.degerlerOnc[i];
                                        if (i == 0) ad = "tckimlikno";
                                        else
                                        {
                                            ad = by.hepsi[i - 1].ad;
                                            vt = by.hepsi[i - 1].tip;
                                        }
                                    }
                                    //if (ii > 0) OrtakFonksiyonlar.HataDosyaYaz("TopluYaz.txt", "Değer yaz:" + satIc.ToString() + " " + sutIc.ToString() + " " + ii.ToString() + " " + (o == null ? "null" : o.ToString()), false);
                                    PSLDinBordroOrtak.HucreyeYaz(XLS, satIc, sutIc, o, vt, t, i);
                                }
                            }
                        }
                        t.ToplamEkle(1, 2);
                        t.ToplamEkle(0, 2);
                        satir += satirSay;
                        if (sayfaKisi > 0)
                        {
                            if (((j + 1) % sayfaKisi) == 0)
                            {
                                PSLDinBordroOrtak.ToplamYaz(XLS, ref satir, sutun, "s_", satirYerler, 4, stSatBasla, stSutBasla, stSatBit, stSutBit, t, 1, by, 0);
                                t.SatirSifirla(1);
                                XLS.SayfaSonuKoy(satir);
                            }
                        }
                        j++;
                    }
                }

                if (oa.ObjeSayisi > 0)
                {
                    if (toplamAyniSayfada == 0)
                        XLS.SayfaSonuKoy(satir);
                    PSLDinBordroOrtak.ToplamYaz(XLS, ref satir, sutun, "t_", satirYerler, 8, gtSatBasla, gtSutBasla, gtSatBit, gtSutBit, t, 0, by, 0);
                    if (satirYuk > 0)
                    {
                        int baslamaSat = ilkSatir;
                        XLS.SatirYukseklikAyarla(baslamaSat, satir, satirYuk);
                    }
                }
                int satirSil = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("SatirSil"), -1);
                int sutunSil = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("SutunSil"), -1);

                if (satirSil > 0 || sutunSil > 0)
                {
                    XLS.FormulleriSil();
                    if (satirSil > 0)
                        XLS.SatirSil(0, satirSil - 1);
                    if (sutunSil > 0)
                        XLS.SutunSil(0, sutunSil - 1);
                }
            }
            catch (Exception ex2)
            {
                DebugYaz(kullanan, ex2.Message);
                XLS.HucreDegerYaz(0, 0, ex2.Message + " (Ana akış)");
            }
            if (sonucDosyaAd.EndsWith("pdf"))
            {
                XLS.DosyaSaklamaFormatAta("pdf");
            }
            try
            {
                XLS.DosyaSaklaTamYol();
            }
            catch (Exception ex3)
            {
                DebugYaz(kullanan, ex3.Message);
            }
            return sonucDosyaAd;
        }

        private static void DebugYaz(Kullanici kullanan, string yazi, bool sifirla = false)
        {
            //if (kullanan.KullaniciTipiIceriyorMu((int)ENUMKullaniciTipi.SISTEMYONETICISI))
            //    OrtakFonksiyonlar.HataDosyaYaz("Debug.txt", new TNSDateTime(DateTime.Now).ToTimeStamp() + ": " + yazi, sifirla);
        }

        public static void DosyaUretDinamik(IHRCServis servisHRC, TNS.KYM.Kullanici kullanan, BordroKistas bordroKistas, DegiskenGrup[] alanListe, string sonucDosyaAd)
        {
            SortedDictionary<NesneListesi, NesneListesi> tc = new SortedDictionary<NesneListesi, NesneListesi>();
            ObjectArray calisanBordro = servisHRC.CalisanDinamikBordroListele(kullanan, bordroKistas);
            foreach (CalisanDinamikBordroDonem donem in calisanBordro.objeler)
            {
                int pTipYer = -1;
                ObjectArray personeller = null;

                foreach (DegiskenGrup item in alanListe)
                {
                    if (!item.ad.StartsWith("_"))
                    {
                        item.yerTur = 1;
                        if (item.ad == "tckimlikno")
                        {
                            item.yer = 0;
                        }
                        else
                        {
                            item.yer = donem.bordroYapi.YerBul(item.ad, 0) + 1;
                            if (item.yer == 0) item.yer = -1;
                        }
                    }
                }

                bool pKisiselBilgiBul = false;

                foreach (DegiskenGrup item in alanListe)
                {
                    if (item.ad.StartsWith("_"))
                    {
                        item.yerTur = 3;
                        item.yer = Array.IndexOf(BordroRaporlari.genelAlanlar, item.ad.Substring(1));
                        if (PersonelAranacakMi(item.yer))
                            pKisiselBilgiBul = true;
                    }
                }
                if (pKisiselBilgiBul)
                    KisiselVerileriBul(kullanan, out personeller, donem);

                for (int jj = 0; jj < donem.calisanDinamikBordro.kisiDegerler.Count; jj++)
                {
                    KisiSatir kisiSatir = (KisiSatir)donem.calisanDinamikBordro.kisiDegerler[jj];
                    object[] degerler = (object[])kisiSatir.degerler;
                    NesneListesi anahtarlar = new NesneListesi();
                    NesneListesi toplamlar = new NesneListesi();
                    foreach (DegiskenGrup item in alanListe)
                    {
                        object o = null;

                        if (item.yerTur == 3)
                        {
                            VariableType vt = VariableType.Bilinmiyor;
                            OrtakDegerBul(item.yer, kisiSatir, donem.bordroYapi, ref o, ref vt, personeller, -1);
                        }
                        else if (item.yerTur == 1)
                        {
                            if (item.yer >= 0)
                            {
                                o = degerler[item.yer];
                            }
                        }
                        if (item.islem)
                            toplamlar.Ekle(o);
                        else
                            anahtarlar.Ekle(o);
                    }
                    NesneListesi eskiDegerler = null;
                    try
                    {
                        eskiDegerler = tc[anahtarlar];
                    }
                    catch { }
                    if (eskiDegerler == null)
                        eskiDegerler = toplamlar;
                    else
                    {
                        eskiDegerler.Topla(toplamlar);
                    }
                    tc[anahtarlar] = eskiDegerler;
                }
            }

            Tablo XLS = GenelIslemler.NewTablo();

            XLS.BosDosyaAc(sonucDosyaAd);

            int satir = 0;
            int sutun = 0;

            XLS.HucreDegerYaz(satir, sutun, "#");
            for (int i = 0; i < alanListe.Length; i++)
            {
                DegiskenGrup item = (DegiskenGrup)alanListe[i];

                XLS.HucreDegerYaz(satir + 0, sutun + 1 + i, item.aciklama);
            }
            satir = 1;
            int j = 0;
            foreach (KeyValuePair<NesneListesi, NesneListesi> kvp in tc)
            {
                NesneListesi anahtarlar = kvp.Key;
                NesneListesi toplamlar = kvp.Value;
                XLS.HucreDegerYaz(satir, sutun, ++j);
                int sayA = 0;
                int sayT = 0;
                for (int i = 0; i < alanListe.Length; i++)
                {
                    DegiskenGrup item = (DegiskenGrup)alanListe[i];
                    object o = null;
                    if (item.islem)
                        o = toplamlar[sayA++];
                    else
                        o = anahtarlar[sayT++];
                    if (o != null)
                        PSLDinBordroOrtak.HucreyeYaz(XLS, satir, sutun + i + 1, o, item.veriTipi, null, i);
                }
                satir++;
            }

            if (sonucDosyaAd.EndsWith("pdf"))
            {
                XLS.DosyaSaklamaFormatAta("pdf");
            }
            XLS.DosyaSaklaTamYol();

        }

        static void KisiselVerileriBul(Kullanici kullanan, out ObjectArray personeller, CalisanDinamikBordroDonem donem)
        {
            //personeller = null;

            //Personel pSorgu = new Personel();
            //pSorgu.tcList = new TNSCollection();
            //for (int jj = 0; jj < donem.calisanDinamikBordro.kisiDegerler.Count; jj++)
            //{
            //    KisiSatir kisiSatir = (KisiSatir)donem.calisanDinamikBordro.kisiDegerler[jj];
            //    object[] degerler = (object[])kisiSatir.degerler;
            //    string tcNo = (string)degerler[0];
            //    if (!pSorgu.tcList.Contains(tcNo)) pSorgu.tcList.Add(tcNo);
            //}
            //pSorgu.bordroDisiDahil = false;

            //personeller = TNS.IKY.Arac.Tanimla().PersonelListele(kullanan, pSorgu, false, true);

            personeller = new ObjectArray();

            Personel pSorgu = new Personel();
            pSorgu.tcList = new TNSCollection();
            pSorgu.bordroDisiDahil = false;

            int parcaBoyutu = 5000;

            for (int jj = 0; jj < donem.calisanDinamikBordro.kisiDegerler.Count; jj++)
            {
                KisiSatir kisiSatir = (KisiSatir)donem.calisanDinamikBordro.kisiDegerler[jj];
                object[] degerler = (object[])kisiSatir.degerler;
                string tcNo = (string)degerler[0];

                if (!pSorgu.tcList.Contains(tcNo))
                    pSorgu.tcList.Add(tcNo);

                if (pSorgu.tcList.Count >= parcaBoyutu)
                {
                    SorguYapVeEkle(kullanan, pSorgu, personeller);

                    pSorgu.tcList = new TNSCollection();
                    pSorgu.bordroDisiDahil = false;
                }
            }

            if (pSorgu.tcList.Count > 0)
            {
                SorguYapVeEkle(kullanan, pSorgu, personeller);
            }

        }

        private static void SorguYapVeEkle(Kullanici kullanan, Personel pSorgu, ObjectArray personeller)
        {
            ObjectArray gelenPersoneller =
                TNS.IKY.Arac.Tanimla().PersonelListele(kullanan, pSorgu, false, true);

            if (gelenPersoneller == null)
                return;

            personeller.objeler.AddRange(gelenPersoneller.objeler);
        }

        private static void PTipAdEMailBul(int yer, KisiSatir kisiSatir, ref object o, ref VariableType vt)
        {
        }
    }

    public class PSLDinBordroOrtak
    {
        public static string[] kosullar = { "<=", ">=", "!=", "=", "<", ">" };
        public static bool YazilsinMi(object[] degerler, int alanNo, int kosulIndeks, double degerDbl)
        {
            if (alanNo == -1000) return false;
            if (degerler == null)
            {
                if (kosulIndeks == -1) return true;
                else return false;
            }
            if (alanNo >= 0 && alanNo < degerler.Length)
            {
                double d = 0;
                object o = degerler[alanNo];
                if (o.GetType() == typeof(double))
                {
                    d = (double)o;
                }
                else if (o.GetType() == typeof(int))
                {
                    d = (int)o;
                }
                else
                    return true;
                if (kosulIndeks == 0) return (d <= degerDbl);
                else if (kosulIndeks == 1) return (d >= degerDbl);
                else if (kosulIndeks == 2) return (d != degerDbl);
                else if (kosulIndeks == 3) return (d == degerDbl);
                else if (kosulIndeks == 4) return (d < degerDbl);
                else if (kosulIndeks == 5) return (d > degerDbl);
            }
            return true;
        }

        public static void GonderHepsi(string sablonKod, int personelTip, int bordroIslem, CalisanDinamikBordroDonem bordroDonem, IHRCServis servisHRC, TNS.KYM.Kullanici kullanan, int surecYil, string surecNo, BordroYapi by)
        {
            string sonucDosyaAd = DosyaIslem.DosyaAdUret("Brd", "") + ".xlsx";
            DosyaUret(sablonKod, personelTip, bordroIslem, bordroDonem, servisHRC, kullanan, surecYil, surecNo, by, null, sonucDosyaAd);
            OrtakClass.DosyaIslem.DosyaGonder(sonucDosyaAd, System.IO.Path.GetFileName(sonucDosyaAd), true, GenelIslemler.ExcelTur());
        }

        public static void DosyaUret(string sablonKod, int personelTip, int bordroIslem, CalisanDinamikBordroDonem bordroDonem, IHRCServis servisHRC, TNS.KYM.Kullanici kullanan, int surecYil, string surecNo, BordroYapi by, TNSCollection tcListe, string sonucDosyaAd)
        {
            Tablo XLS = GenelIslemler.NewTablo();

            BordroSablonDosya bsd = new BordroSablonDosya();

            bsd.bordroTur = personelTip;
            bsd.islemTur = bordroIslem;
            bsd.sablonKod = OrtakFonksiyonlar.ConvertToInt(sablonKod, 0);
            if (bsd.sablonKod > 0)
                sablonKod = bsd.SablonDosyaAd;
            string sablonAd = System.IO.Path.Combine(BordroTanim.DosyaYol(false), sablonKod);

            XLS.DosyaAc(sablonAd, sonucDosyaAd);

            int satir = 0;
            int sutun = 0;
            XLS.HucreAdAdresCoz("BaslaSatir", ref satir, ref sutun);
            int ilkSatir = satir;

            int sheetNo = 0;
            int sheetNo2 = 0;
            int bordroSatBasla = 0, bordroSutBasla = 0, bordroSatBit = 0, bordroSutBit = 0;
            int bordroSatBasla2 = 0, bordroSutBasla2 = 0, bordroSatBit2 = 0, bordroSutBit2 = 0;
            int gtSatBasla = 0, gtSutBasla = 0, gtSatBit = 0, gtSutBit = 0;
            int stSatBasla = 0, stSutBasla = 0, stSatBit = 0, stSutBit = 0;
            XLS.HucreAdAdresCoz("BordroSatir", ref sheetNo, ref bordroSatBasla, ref bordroSutBasla, ref bordroSatBit, ref bordroSutBit);

            int grupSheetNo = 0, grupSatBasla = 0, grupSutBasla = 0, grupSatBit = 0, grupSutBit = 0, grupAdSat = 0, grupAdSut = 0;

            XLS.HucreAdAdresCoz("BordroSatir2", ref sheetNo2, ref bordroSatBasla2, ref bordroSutBasla2, ref bordroSatBit2, ref bordroSutBit2);
            if (bordroSatBasla2 < 1)
            {
                sheetNo2 = sheetNo;
                bordroSatBasla2 = bordroSatBasla;
                bordroSutBasla2 = bordroSutBasla;
                bordroSatBit2 = bordroSatBit;
                bordroSutBit2 = bordroSutBit;
            }
            int siraSatir = 0, siraSutun = 0, siraSatirBit = 0, siraSutunBit = 0;
            XLS.HucreAdAdresCoz("SayfaToplam", ref sheetNo, ref stSatBasla, ref stSutBasla, ref stSatBit, ref stSutBit);
            XLS.HucreAdAdresCoz("GenelToplam", ref sheetNo, ref gtSatBasla, ref gtSutBasla, ref gtSatBit, ref gtSutBit);
            XLS.HucreAdAdresCoz("SiraNo", ref sheetNo, ref siraSatir, ref siraSutun, ref siraSatirBit, ref siraSutunBit);

            siraSatir = siraSatir - bordroSatBasla;
            siraSutun = siraSutun - bordroSutBasla;
            siraSatirBit = siraSatirBit - bordroSatBasla;
            siraSutunBit = siraSutunBit - bordroSutBasla;

            XLS.HucreAdBulYaz("Yil", bordroDonem.odemeTarihDT.Year);
            XLS.HucreAdBulYaz("Ay", bordroDonem.odemeTarihDT.Month);
            XLS.HucreAdBulYaz("AyAd", GenelIslemler.AyAdDondur(bordroDonem.odemeTarihDT.Month));
            XLS.HucreAdBulYaz("SayKod", bordroDonem.muhasebeKod);
            XLS.HucreAdBulYaz("SayAd", bordroDonem.muhasebeAd);
            XLS.HucreAdBulYaz("BirKod", bordroDonem.birimKod);
            XLS.HucreAdBulYaz("BirAd", bordroDonem.birimAd);
            XLS.HucreAdBulYaz("SayBirAd", TNS.MUH.Arac.BirimAdOl(bordroDonem.muhasebeAd, bordroDonem.birimAd));
            TarihYaz(XLS, "DIlkGun", bordroDonem.bordroDonemBasTarihDT);
            TarihYaz(XLS, "DSonGun", bordroDonem.sonGunDT);
            XLS.HucreAdBulYaz("Hazirlayan", bordroDonem.hazirlayan);
            XLS.HucreAdBulYaz("OnayaSunan", bordroDonem.onayaSunan);
            XLS.HucreAdBulYaz("Onaylayan", bordroDonem.onaylayan);

            //XLS.HucreAdBulYaz();
            //XLS.HucreAdBulYaz("", bordroDonem.sonGunDT.ToString("dd MMMM yyyy"));

            XLS.HucreAdBulYaz("DYil", bordroDonem.bordroDonemBasTarihDT.Year);
            XLS.HucreAdBulYaz("DAy", bordroDonem.bordroDonemBasTarihDT.Month);
            XLS.HucreAdBulYaz("DAyAd", GenelIslemler.AyAdDondur(bordroDonem.bordroDonemBasTarihDT.Month));

            XLS.HucreAdBulYaz("SurecYil", surecYil);
            XLS.HucreAdBulYaz("SurecNo", surecNo);
            int SurecNoYer = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("SurecNoYer"), -1);
            if (SurecNoYer > 0)
            {
                int yanasik = 2;
                if (SurecNoYer == 1 || SurecNoYer == 4) yanasik = 0;
                else if (SurecNoYer == 2 || SurecNoYer == 5) yanasik = 1;
                XLS.HFDegerAta(SurecNoYer == 1 || SurecNoYer == 2 || SurecNoYer == 3 ? 0 : 1, yanasik, "Süreç No: " + surecYil + "/" + surecNo);
            }
            //bordroDonem
            string tut = XLS.HucreAdDegerAl("SayfaKisi");
            int satirYuk = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("SatirYuk"), -1);
            if (satirYuk > 0) satirYuk = satirYuk * 1010;
            int toplamAyniSayfada = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("ToplamAyniSayfada"), 0);
            int sayfaKisi = OrtakFonksiyonlar.ConvertToInt(tut, 0);

            int[,] satirYerler = new int[by.hepsi.Length + 1 + BordroRaporlari.genelAlanlar.Length, 12]; //+1 tckimlikno icin
            int[,] satirYerlerOnc = new int[by.hepsi.Length + 1 + BordroRaporlari.genelAlanlar.Length, 12]; //+1 tckimlikno icin
            bool oncVar = false;
            bool pKisiselBilgi = false;
            int sendikaBilgiYer = -1;
            for (int i = 0; i < by.hepsi.Length + 1 + BordroRaporlari.genelAlanlar.Length; i++)
            {
                string ad;
                int genelAlanNo = i - (by.hepsi.Length + 1);
                if (i == 0) ad = "tckimlikno";
                else if (genelAlanNo >= 0) ad = BordroRaporlari.genelAlanlar[genelAlanNo];
                else ad = by.hepsi[i - 1].ad;

                if (ad == "sendikaBilgi")
                    sendikaBilgiYer = i;


                AdresCoz(XLS, "a_" + ad, satirYerler, i, 0, bordroSatBasla, bordroSutBasla, bordroSatBit, bordroSutBit);
                AdresCoz(XLS, "s_" + ad, satirYerler, i, 4, stSatBasla, stSutBasla, stSatBit, stSutBit);
                AdresCoz(XLS, "t_" + ad, satirYerler, i, 8, gtSatBasla, gtSutBasla, gtSatBit, gtSutBit);

                AdresCoz(XLS, "o_a_" + ad, satirYerlerOnc, i, 0, bordroSatBasla, bordroSutBasla, bordroSatBit, bordroSutBit);
                AdresCoz(XLS, "o_s_" + ad, satirYerlerOnc, i, 4, stSatBasla, stSutBasla, stSatBit, stSutBit);
                AdresCoz(XLS, "o_t_" + ad, satirYerlerOnc, i, 8, gtSatBasla, gtSutBasla, gtSatBit, gtSutBit);
                if (!oncVar && satirYerlerOnc[i, 0] >= 0) oncVar = true;
                if ((satirYerler[i, 0] >= 0))
                {
                    if (!pKisiselBilgi && BordroRaporlari.PersonelAranacakMi(genelAlanNo))
                        pKisiselBilgi = true;
                }
            }

            int satirSay = bordroSatBit - bordroSatBasla + 1;
            string siralama = XLS.HucreAdDegerAl("Siralama");
            by.siralamaStr = siralama;
            CalisanDinamikBordro calisanBordro = servisHRC.CalisanDinamikBordroOku(kullanan, by, new BordroKistas(surecYil, surecNo, tcListe));

            int simdOncSay;
            if (oncVar)
            {
                simdOncSay = 2;
                OncekiIleBirlestir(servisHRC, kullanan, calisanBordro, by, surecYil, surecNo, tcListe);
            }
            else
                simdOncSay = 1;

            by.siralamaStr = null;

            int alanNo = 0;
            int kosulIndeks = -1;
            double degerDbl = 0;
            string kosulAlan = XLS.HucreAdDegerAl("DoluAlan");
            if (!string.IsNullOrWhiteSpace(kosulAlan))
            {
                int kosulYer;
                YerBul(kosulAlan, kosullar, out kosulIndeks, out kosulYer);
                if (kosulIndeks >= 0 && kosulYer > 0)
                {
                    string alan = kosulAlan.Substring(0, kosulYer);
                    alanNo = by.YerBul(alan, 0) + 1;
                    string deger = kosulAlan.Substring(kosulYer + kosullar[kosulIndeks].Length);
                    degerDbl = OrtakFonksiyonlar.ConvertToDbl(deger);
                }
            }
            DegiskenFormul grupAlanTanim = null;
            int grupAlanNo = -1;
            int grupAlanOrtak = -1;
            int[] grupSatYuk = null;
            string grupAlan = XLS.HucreAdDegerAl("GrupAlan");
            if (!string.IsNullOrWhiteSpace(grupAlan))
            {
                grupAlanOrtak = -1;
                grupAlanNo = by.YerBul(grupAlan, 0);
                if (grupAlanNo >= 0)
                {
                    grupAlanTanim = by.hepsi[grupAlanNo];
                    grupAlanNo++;
                }
                else
                {
                    grupAlanTanim = null;
                    grupAlanOrtak = Array.IndexOf(BordroRaporlari.genelAlanlar, grupAlan);
                }
                XLS.HucreAdAdresCoz("GrupBaslik", ref grupSheetNo, ref grupSatBasla, ref grupSutBasla, ref grupSatBit, ref grupSutBit);
                XLS.HucreAdAdresCoz("GrupAd", ref grupAdSat, ref grupAdSut);
                string[] grupYuk = XLS.HucreAdDegerAl("GrupYuk").Split(';');
                grupSatYuk = new int[grupSatBit - grupSatBasla + 1];
                for (int i = 0; i <= grupSatBit - grupSatBasla; i++)
                {
                    grupSatYuk[i] = OrtakFonksiyonlar.ConvertToInt(OrtakFonksiyonlar.DiziElemanAl(grupYuk, i, "-1"), -1);
                    if (grupSatYuk[i] > 0) grupSatYuk[i] = grupSatYuk[i] * 1010;
                }
            }

            string eskiGrupAlanDeger = null;
            ToplamAl t = new ToplamAl(3, by.hepsi.Length + 1 + BordroRaporlari.genelAlanlar.Length);
            ToplamAl tGrup = new ToplamAl(1, by.hepsi.Length + 1 + BordroRaporlari.genelAlanlar.Length);
            int j = 0;
            bool tek = true;
            int grupIlkSatir = 0;

            for (int jj = 0; jj < calisanBordro.kisiDegerler.Count; jj++)
            {
                KisiSatir kisiSatir = (KisiSatir)calisanBordro.kisiDegerler[jj];
                object[] degerler = (object[])kisiSatir.degerler;
                if (!YazilsinMi(degerler, alanNo, kosulIndeks, degerDbl)) continue;
                if (grupAlanTanim != null || grupAlanOrtak >= 0)
                {
                    object o_grupAlanDeger;
                    VariableType vt = VariableType.Bilinmiyor;
                    if (grupAlanTanim != null)
                    {
                        o_grupAlanDeger = degerler[grupAlanNo];
                        vt = grupAlanTanim.tip;
                    }
                    else
                    {
                        o_grupAlanDeger = null;
                        BordroRaporlari.OrtakDegerBul(grupAlanOrtak, kisiSatir, by, ref o_grupAlanDeger, ref vt, null, sendikaBilgiYer);
                    }

                    if (o_grupAlanDeger == null) continue;

                    string grupAlanDeger = o_grupAlanDeger.ToString();
                    if (eskiGrupAlanDeger != grupAlanDeger)
                    {
                        j = 0;
                        if (eskiGrupAlanDeger != null)
                        {
                            ToplamYaz(XLS, ref satir, sutun, "s_", satirYerler, 4, stSatBasla, stSutBasla, stSatBit, stSutBit, t, 1, by, 0);
                            t.SatirSifirla(1);
                            if (satirYuk > 0)
                                XLS.SatirYukseklikAyarla(grupIlkSatir, satir, satirYuk);

                            XLS.SayfaSonuKoy(satir);
                        }

                        eskiGrupAlanDeger = grupAlanDeger;
                        XLS.HucreKopyala(grupSatBasla, grupSutBasla, grupSatBit, grupSutBit, satir, sutun);

                        for (int i = 0; i < grupSatYuk.Length; i++)
                        {
                            XLS.SatirYukseklikAyarla(satir + i, satir + i, grupSatYuk[i]);
                        }

                        for (int iSat = satir; iSat <= satir + (grupSatBit - grupSatBasla); iSat++)
                        {
                            for (int jSut = grupSutBasla; jSut <= grupSutBit; jSut++)
                            {
                                string hucreDeger = XLS.HucreDegerAl(iSat, jSut);
                                if (hucreDeger.StartsWith("@"))
                                {
                                    object oYerine = null;
                                    VariableType vtIc = VariableType.String;

                                    BordroRaporlari.OrtakDegerBul(Array.IndexOf(BordroRaporlari.genelAlanlar, hucreDeger.Substring(1)), kisiSatir, by, ref oYerine, ref vtIc, null, sendikaBilgiYer);
                                    HucreyeYaz(XLS, iSat, jSut, oYerine, vtIc, null, 0);
                                }
                            }
                        }

                        HucreyeYaz(XLS, satir, 0, o_grupAlanDeger, vt, null, 0);
                        satir += (grupSatBit - grupSatBasla) + 1;
                        grupIlkSatir = satir;
                        tek = true;
                    }
                }
                if (tek)
                    XLS.HucreKopyala(bordroSatBasla, bordroSutBasla, bordroSatBit, bordroSutBit, satir, sutun);
                else
                    XLS.HucreKopyala(bordroSatBasla2, bordroSutBasla2, bordroSatBit2, bordroSutBit2, satir, sutun);
                tek = !tek;
                if (siraSatir >= 0 && siraSutun >= 0)
                {
                    XLS.HucreDegerYaz(satir + siraSatir, sutun + siraSutun, j + 1);
                }

                for (int i = 0; i < by.hepsi.Length + 1 + BordroRaporlari.genelAlanlar.Length; i++)
                {
                    simdOncSay = oncVar ? 2 : 1;
                    for (int simdOnc = 0; simdOnc < simdOncSay; simdOnc++)
                    {
                        string ad;
                        int ii = -1;
                        VariableType vt = VariableType.String;
                        object o = (string)null;
                        if (i >= by.hepsi.Length + 1)
                        {
                            //if (kisiSatir.kisiSatirBilgi != null)
                            {
                                ii = i - (by.hepsi.Length + 1);
                                ad = BordroRaporlari.genelAlanlar[ii];
                                BordroRaporlari.OrtakDegerBul(ii, kisiSatir, by, ref o, ref vt, null, sendikaBilgiYer);
                            }
                        }
                        else
                        {
                            if (simdOnc == 0 && degerler != null)
                                o = degerler[i];
                            else if (simdOnc == 1 && kisiSatir.degerlerOnc != null)
                                o = kisiSatir.degerlerOnc[i];
                            if (i == 0) ad = "tckimlikno";
                            else
                            {
                                ad = by.hepsi[i - 1].ad;
                                vt = by.hepsi[i - 1].tip;
                            }
                        }
                        int satIc = 0, sutIc = 0;
                        PSLDinBordroOrtak.AdresCoz(simdOnc == 0 ? satirYerler : satirYerlerOnc, i, 0, satir, sutun, ref satIc, ref sutIc);
                        if (satIc > 0)
                        {
                            //if (ii > 0) OrtakFonksiyonlar.HataDosyaYaz("TopluYaz.txt", "Değer yaz:" + satIc.ToString() + " " + sutIc.ToString() + " " + ii.ToString() + " " + (o == null ? "null" : o.ToString()), false);
                            PSLDinBordroOrtak.HucreyeYaz(XLS, satIc, sutIc, o, vt, t, i);
                        }
                    }
                }
                t.ToplamEkle(1, 2);
                t.ToplamEkle(0, 2);
                satir += satirSay;
                if (sayfaKisi > 0)
                {
                    if (((j + 1) % sayfaKisi) == 0)
                    {
                        ToplamYaz(XLS, ref satir, sutun, "s_", satirYerler, 4, stSatBasla, stSutBasla, stSatBit, stSutBit, t, 1, by, 0);
                        t.SatirSifirla(1);
                        XLS.SayfaSonuKoy(satir);
                    }
                }
                j++;
            }

            if (grupAlanTanim != null && eskiGrupAlanDeger != null || grupAlanOrtak >= 0)
            {
                ToplamYaz(XLS, ref satir, sutun, "s_", satirYerler, 4, stSatBasla, stSutBasla, stSatBit, stSutBit, t, 1, by, 0);
                t.SatirSifirla(1);
                satir++;
            }
            if (toplamAyniSayfada == 0)
                XLS.SayfaSonuKoy(satir);
            ToplamYaz(XLS, ref satir, sutun, "t_", satirYerler, 8, gtSatBasla, gtSutBasla, gtSatBit, gtSutBit, t, 0, by, j);
            if (satirYuk > 0)
            {
                int baslamaSat = 0;
                if (grupAlanTanim == null && grupAlanOrtak < 0)
                    baslamaSat = ilkSatir;
                else
                    baslamaSat = grupIlkSatir;
                XLS.SatirYukseklikAyarla(baslamaSat, satir, satirYuk);
            }
            int satirSil = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("SatirSil"), -1);
            int sutunSil = OrtakFonksiyonlar.ConvertToInt(XLS.HucreAdDegerAl("SutunSil"), -1);

            if (satirSil > 0 || sutunSil > 0)
            {
                XLS.FormulleriSil();
                if (satirSil > 0)
                    XLS.SatirSil(0, satirSil - 1);
                if (sutunSil > 0)
                    XLS.SutunSil(0, sutunSil - 1);
            }

            if (sonucDosyaAd.EndsWith("pdf"))
            {
                XLS.DosyaSaklamaFormatAta("pdf");
            }
            XLS.DosyaSaklaTamYol();
        }

        public static void OncekiIleBirlestir(IHRCServis servisHRC, Kullanici kullanan, CalisanDinamikBordro calisanBordro, BordroYapi by, int surecYil, string surecNo, TNSCollection tcListe)
        {
            CalisanDinamikBordroDonem oncDonem = servisHRC.OncekiDonemBul(surecYil, surecNo);
            if (oncDonem != null)
            {
                BordroKistas bk = new BordroKistas(oncDonem.yil, oncDonem.surecNo, tcListe);

                CalisanDinamikBordro calisanBordroOnc = servisHRC.CalisanDinamikBordroOku(kullanan, by, bk);
                if (calisanBordroOnc != null && calisanBordroOnc.kisiDegerler != null)
                {
                    foreach (KisiSatir oncKisi in calisanBordroOnc.kisiDegerler)
                    {
                        KisiSatir simdKisi = calisanBordro.KisiBul(oncKisi);
                        if (simdKisi == null)
                        {
                            calisanBordro.kisiDegerler.Add(oncKisi);
                            oncKisi.degerlerOnc = oncKisi.degerler;
                            oncKisi.degerler = null;
                        }
                        else
                            simdKisi.degerlerOnc = oncKisi.degerler;
                    }
                }
            }
        }

        public static void TarihYaz(Tablo XLS, string alanAd, DateTime tarih)
        {
            int sat = 0, sut = 0;
            XLS.HucreAdAdresCoz(alanAd, ref sat, ref sut);
            if (sat >= 0 && sut >= 0)
            {
                XLS.HucreDegerYaz(sat, sut, tarih);
            }
        }

        public static void HucreyeYaz(Tablo XLS, int satIc, int sutIc, object o, VariableType vt, ToplamAl t, int i)
        {
            if (o == null) return;
            try
            {
                if (vt == VariableType.Integer)
                {
                    XLS.HucreDegerYaz(satIc, sutIc, (int)o);
                    if (t != null)
                        t.DegerAta(2, i, (int)o);
                }
                else if (vt == VariableType.Money)
                {
                    XLS.HucreDegerYaz(satIc, sutIc, (double)o);
                    if (t != null)
                        t.DegerAta(2, i, (double)o);
                }
                else if (vt == VariableType.Date)
                {
                    XLS.HucreDegerYaz(satIc, sutIc, (DateTime)o);
                    if (t != null)
                        t.DegerAta(2, i, 0);
                }
                else
                {
                    XLS.HucreDegerYaz(satIc, sutIc, (string)o);
                    if (t != null)
                        t.DegerAta(2, i, 0);
                }
            }
            catch (Exception ex)
            {
                XLS.HucreDegerYaz(satIc, sutIc, (o == null ? "NULL" : o.ToString()) + "(" + ex.Message + ")");
            }
        }

        public static void YerBul(string kosulAlan, string[] kosullar, out int kosulIndeks, out int kosulYer)
        {
            kosulIndeks = -1;
            kosulYer = -1;
            if (string.IsNullOrWhiteSpace(kosulAlan)) return;
            if (kosullar == null) return;
            for (int i = 0; i < kosullar.Length; i++)
            {
                kosulYer = kosulAlan.IndexOf(kosullar[i]);
                if (kosulYer >= 0)
                {
                    kosulIndeks = i;
                    return;
                }
            }
        }

        public static void ToplamYaz(Tablo XLS, ref int satir, int sutun, string alanEkle, int[,] satirYerler, int yerIndeks, int satBasla, int sutBasla, int satBit, int sutBit, ToplamAl t, int toplamSat, BordroYapi by, int toplaSay)
        {
            if (satBasla > 0)
            {
                bool ilk = true;
                for (int i = 0; i < by.hepsi.Length + 1; i++)
                {
                    string ad;
                    VariableType vt = VariableType.String;
                    if (i == 0) ad = "tckimlikno";
                    else
                    {
                        ad = by.hepsi[i - 1].ad;
                        vt = by.hepsi[i - 1].tip;
                    }

                    int satIc = 0, sutIc = 0;
                    AdresCoz(satirYerler, i, yerIndeks, satir, sutun, ref satIc, ref sutIc);
                    if (satIc > 0)
                    {
                        if (ilk)
                        {
                            XLS.HucreKopyala(satBasla, sutBasla, satBit, sutBit, satir, sutun);
                            ilk = false;
                        }

                        XLS.HucreDegerYaz(satIc, sutIc, t.toplam[toplamSat, i]);
                        if (alanEkle == "t_")
                        {
                            int btSat = 0, btSut = 0;
                            XLS.HucreAdAdresCoz("bt_" + ad, ref btSat, ref btSut);
                            if (btSat > 0 && btSut > 0)
                                XLS.HucreDegerYaz(btSat, btSut, t.toplam[toplamSat, i]);
                        }
                    }
                }
                if (!ilk)
                {
                    if (alanEkle == "t_")
                    {
                        int btSat = 0, btSut = 0;
                        XLS.HucreAdAdresCoz("bt_" + "SiraNo", ref btSat, ref btSut);
                        if (btSat > 0 && btSut > 0)
                            XLS.HucreDegerYaz(btSat, btSut, toplaSay);
                    }
                }
                satir += (satBit - satBasla + 1);
            }
        }

        public static void AdresCoz(int[,] satirYerler, int dSat, int dSut, int aktifSat, int aktifSut, ref int satIc, ref int sutIc)
        {
            int d1 = satirYerler[dSat, dSut + 0];
            if (d1 >= 0)
            {
                satIc = aktifSat + d1;
                sutIc = aktifSut + satirYerler[dSat, dSut + 1];
            }
            else
            {
                satIc = -1;
                sutIc = -1;
            }
        }

        public static void AdresCoz(Tablo XLS, string ad, int[,] satirYerler, int dSat, int dSut, int satBasla_off, int sutBasla_off, int satBit_off, int sutBit_off)
        {
            int sheetNo = 0;
            int satBasla = 0, sutBasla = 0, satBit = 0, sutBit = 0;
            XLS.HucreAdAdresCoz(ad, ref sheetNo, ref satBasla, ref sutBasla, ref satBit, ref sutBit);
            if (sheetNo >= 0)
            {
                satirYerler[dSat, dSut + 0] = satBasla - satBasla_off;
                satirYerler[dSat, dSut + 1] = sutBasla - sutBasla_off;
                satirYerler[dSat, dSut + 2] = satBit - satBit_off;
                satirYerler[dSat, dSut + 3] = sutBit - sutBit_off;
            }
            else
            {
                satirYerler[dSat, dSut + 0] = -1;
                satirYerler[dSat, dSut + 1] = -1;
                satirYerler[dSat, dSut + 2] = -1;
                satirYerler[dSat, dSut + 3] = -1;
            }
        }

        public static string _yol = null; //@"C:\sources\asp.net\Sgb.NETv2\Istemci\Dosyalar\Bordro";
        public static string yol
        {
            get
            {
                if (_yol == null)
                {
                    _yol = System.Configuration.ConfigurationManager.AppSettings.Get("BordroYol") + "";
                }
                return _yol;
            }
        }

        internal static string DosyaAdUret(int surecYil, string surecNo, int personelTip, string tc)
        {
            return System.IO.Path.Combine(yol, surecYil.ToString(), surecNo, tc + "_" + personelTip.ToString() + ".pdf");
        }

        internal static void DosyaYolKontrol(int surecYil, string surecNo)
        {
            if (!System.IO.Directory.Exists(System.IO.Path.Combine(yol, surecYil.ToString(), surecNo)))
            {
                System.IO.Directory.CreateDirectory(System.IO.Path.Combine(yol, surecYil.ToString()));
                System.IO.Directory.CreateDirectory(System.IO.Path.Combine(yol, surecYil.ToString(), surecNo));
            }
        }

        public static string PostalariAt(Kullanici kullanan)
        {
            try
            {
                ParameterizedThreadStart paraThread = new ParameterizedThreadStart(MailAtThreadFunction);
                Thread th = new Thread(paraThread);
                th.Name = "BordroMailAt";
                th.Start(kullanan);
                //Thread.Sleep(15000);
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public static void MailAtThreadFunction(object obj)
        {
            try
            {
                Kullanici kullanan = (Kullanici)obj;
                IHRCServis servisHrc = TNS.HRC.Arac.Tanimla();
                string from = System.Configuration.ConfigurationManager.AppSettings.Get("YazilimMailAdresi");

                int sayac = 0;
                string TahakkukBirimAd = TNS.DEG.Arac.DegiskenDegerBul(0, "PersonelTahakkukBirimAd");
                if (string.IsNullOrEmpty(TahakkukBirimAd)) TahakkukBirimAd = "Personel Tahakkuk Birimi";
                while (true)
                {
                    ObjectArray oa = servisHrc.BordroMailiBekleyenListele(kullanan);
                    if (!oa.sonuc.islemSonuc)
                    {
                        break;
                    }
                    else if (oa.ObjeSayisi == 0)
                    {
                        break;
                    }
                    BordroMail bm = (BordroMail)oa.objeler[0];
                    TNSCollection ekDosyaIsimleri = new TNSCollection();
                    string dosyaAd = DosyaYoksaUret(kullanan, servisHrc, bm.surecYil, bm.surecNo, bm.bordroTur, bm.bordroIslemTur, bm.tc);
                    if (string.IsNullOrWhiteSpace(dosyaAd))
                        servisHrc.BordroMailBirak(kullanan, bm);
                    else
                    {
                        ekDosyaIsimleri.Add(dosyaAd);

                        try
                        {
                            bm.sonucStr = OrtakFonksiyonlar.MailAt(from + "|" + TahakkukBirimAd, bm.ePosta, $"{bm.isinAdi}", $"Sayın <b>{bm.ad} {bm.soyad}<b/>,<br />Bordronuz e-posta ekinde yer almaktadır.<br />Bilgilerinize.", true, false, ekDosyaIsimleri);
                        }
                        catch (Exception ex)
                        {
                            bm.sonucStr = ex.Message;
                            TNS.OrtakFonksiyonlar.HataDosyaYaz("WebServis.txt", "Bordro Mail At Exc Ic" + "::" + dosyaAd + "::" + bm.ePosta + "::" + ex.Message, false);
                        }
                        bm.sonucZamani = new TNSDateTime(DateTime.Now);
                        servisHrc.BordroMailBirak(kullanan, bm);
                    }
                    sayac++;
                    if (sayac == 40)
                    {
                        Thread.Sleep(TimeSpan.FromMinutes(5));
                        sayac = 0;
                    }
                    else
                        Thread.Sleep(TimeSpan.FromSeconds(2));
                }
            }
            catch (Exception ex2)
            {
                TNS.OrtakFonksiyonlar.HataDosyaYaz("WebServis.txt", "Bordro Mail At Exc" + "::" + ex2.Message, false);
            }
        }

        public static string DosyaYoksaUret(Kullanici kullanan, IHRCServis servisHrc, int surecYil, string surecNo, int bordroTur, int bordroIslemTur, string tc)
        {
            string dosyaAd = PSLDinBordroOrtak.DosyaAdUret(surecYil, surecNo, bordroTur, tc);
            if (!System.IO.File.Exists(dosyaAd))
            {
                CalisanDinamikBordroDonem bordroDonem = null;
                ObjectVAN ov = servisHrc.CalisanDinamikBordroDonemOku(kullanan, new CalisanDinamikBordroDonem(surecYil, surecNo));
                if (ov.sonuc.islemSonuc)
                {
                    bordroDonem = (CalisanDinamikBordroDonem)ov.o;
                }
                else
                {
                    throw new Exception(surecYil + "-" + surecNo + " nolu sürecin bordro dönemi okunamadı" + ov.sonuc.hataStr);
                }
                BordroYapi by = null;
                try
                {
                    by = servisHrc.BordroYapiOku(kullanan, bordroTur, bordroIslemTur, false);
                }
                catch (Exception ex)
                {
                    throw new Exception(bordroTur + "-" + bordroIslemTur + " nolu bordro bilgisi okunamadı" + ex.Message);
                }
                TNSCollection tcListe = new TNSCollection();
                tcListe.Add(tc);
                PSLDinBordroOrtak.DosyaYolKontrol(surecYil, surecNo);
                PSLDinBordroOrtak.DosyaUret("99", bordroTur, bordroIslemTur, bordroDonem, servisHrc, kullanan, surecYil, surecNo, by, tcListe, dosyaAd);
            }
            return dosyaAd;
        }

        public static void DosyaYukle(FileUploadField fuDosya, ComboBox cmbAnahtar, ComboBox cmbVeri, BordroYapi by, ArrayList satirlar, out string hata, out string eksikler)
        {
            hata = "";
            eksikler = "";
            Tablo XLS = GenelIslemler.NewTablo();

            if (!fuDosya.HasFile)
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen Dosya Seçiniz");
                return;
            }
            int anahAlan = OrtakFonksiyonlar.ConvertToInt(cmbAnahtar.SelectedItem.Value, 0);
            if (anahAlan < 1 || anahAlan > 2)
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen Anahtar Alanı Seçiniz");
                return;
            }

            int kol = 0;
            string anahAlanAd = "";
            if (anahAlan == 1) { kol = 0; anahAlanAd = "TCKimlikNo"; }
            else { kol = by.YerBul("sicilNo", 0) + 1; anahAlanAd = "sicilNo"; }
            if (kol < 0)
            {
                GenelIslemler.MesajKutusu("Hata", "Sicil alanı bulunamadı!");
                return;
            }

            string veriAlan = cmbVeri.SelectedItem.Value;
            if (string.IsNullOrWhiteSpace(veriAlan))
            {
                GenelIslemler.MesajKutusu("Hata", "Lütfen Veri Alanını Seçiniz");
                return;
            }

            int alanYer = by.YerBul(veriAlan, 0);
            if (alanYer < 1)
            {
                GenelIslemler.MesajKutusu("Hata", "Veri alanı bulunamadı!");
                return;
            }

            DegiskenFormul df = by.hepsi[alanYer];
            alanYer++;

            XLS.DosyaOkuAc(fuDosya.FileContent);
            int sat = 0;
            string alanA = "";
            while (true)
            {
                alanA = XLS.HucreDegerAl(sat, 0);
                if (!string.IsNullOrWhiteSpace(alanA)) break;
                sat++;
                if (sat > 100)
                {
                    hata = "Başlık satırı bulunamad!";
                    return;
                }
            }

            int aKol = KolonBul(XLS, sat, new string[] { anahAlanAd });
            if (aKol < 0)
            {
                hata = string.Format("{0} başlığı olan sütun bulunamadı!", anahAlanAd);
                return;
            }

            int vKol = KolonBul(XLS, sat, new string[] { veriAlan, df.kisaEtiket, df.uzunEtiket });
            if (vKol < 0)
            {
                hata = string.Format("{0} başlığı olan sütun bulunamadı!", df.kisaEtiket);
                return;
            }

            foreach (KisiSatir item in satirlar)
            {
                item.degerler[alanYer] = df.Bos();
            }

            sat++;
            int bosSay = 0;
            while (true)
            {
                string anah = XLS.HucreDegerAl(sat, aKol);
                string veriS = XLS.HucreDegerAl(sat, vKol);
                double veriD = XLS.HucreDegerAlDbl(sat, vKol);
                if (string.IsNullOrWhiteSpace(anah))
                {
                    bosSay++;
                    if (bosSay == 20) break;
                    sat++;
                    continue;
                }
                bosSay = 0;
                KisiSatir ilkSatir = SatirBul(satirlar, kol, anah);
                if (ilkSatir != null)
                    ilkSatir.degerler[alanYer] = df.DegerBul(veriS, veriD, ilkSatir.degerler[alanYer]);
                else
                {
                    eksikler += "<br />" + anah + " kodlu personel bulunamadı!";
                }
                sat++;
            }
            fuDosya.Reset();
            fuDosya.Clear();
        }

        private static int KolonBul(Tablo XLS, int sat, string[] arananDeger)
        {
            int kol = 0;
            while (true)
            {
                string hucreDeger = XLS.HucreDegerAl(sat, kol).Replace(" ", "").ToLower();
                if (VarMi(arananDeger, hucreDeger)) return kol;
                kol++;
                if (kol > 100) break;
            }
            return -1;
        }

        private static bool VarMi(string[] arananDeger, string hucreDeger)
        {
            foreach (var item in arananDeger)
            {
                if (item.Replace(" ", "").ToLower() == hucreDeger)
                    return true;
            }
            return false;
        }

        private static KisiSatir SatirBul(ArrayList satirlar, int kol, string anah)
        {
            foreach (KisiSatir item in satirlar)
            {
                object o = item.degerler[kol];
                if (o == null) continue;
                if (o.ToString() == anah)
                    return item;
                int a = OrtakFonksiyonlar.ConvertToInt(o.ToString(), -1);
                int b = OrtakFonksiyonlar.ConvertToInt(anah, -1);
                if (a > 0 && b > 0 && a == b)
                    return item;
            }
            return null;
        }

        internal static void HucreyeYaz(Tablo xLS, int satir, int sutun, object o, object veriTipi, object p, int i)
        {
            throw new NotImplementedException();
        }
    }
}